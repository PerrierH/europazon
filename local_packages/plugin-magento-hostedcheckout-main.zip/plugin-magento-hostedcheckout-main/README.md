# Worldline Online Payments

Change log:

1.1.1
- PWA improvements and support
- General code improvements

1.1.0
- Waiting page has been added after payment is done to correctly process webhooks and create the order
- Asyncronic order creation through get calls when webhooks suffer delay
- Refund flow is improved for multi-website instances
- Bancontact payment method implementation has been improved
- General improvements and bug fixes

1.0.0
- Initial MVP version 
