# Worldline Online Payments

Change log:

1.1.1
- Hide the checkbox "save card" for iFrame checkout (Credit Card payment method) for guests and when the vault is disabled
- PWA improvements and support
- Bug fixes and general code improvements

1.1.0
- Waiting page has been added after payment is done to correctly process webhooks and create the order
- Asyncronic order creation through get calls when webhooks suffer delay
- Refund flow is improved for multi-website instances
- General improvements and bug fixes

1.0.0
- Initial MVP version 
