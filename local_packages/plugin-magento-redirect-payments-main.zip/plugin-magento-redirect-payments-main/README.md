# Worldline Redirect Payment

Change log:

1.0.1
- PWA improvements and support
- Bug fixes and general code improvements

1.0.0
- New Redirect payments: integrate single payment buttons directly on Magento checkout
