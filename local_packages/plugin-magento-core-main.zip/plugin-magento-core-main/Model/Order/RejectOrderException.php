<?php
declare(strict_types=1);

namespace Worldline\PaymentCore\Model\Order;

use Magento\Framework\Exception\LocalizedException;

class RejectOrderException extends LocalizedException
{

}
