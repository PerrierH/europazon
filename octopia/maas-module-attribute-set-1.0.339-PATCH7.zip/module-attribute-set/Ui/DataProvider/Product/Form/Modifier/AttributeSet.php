<?php

namespace Maas\AttributeSet\Ui\DataProvider\Product\Form\Modifier;

use InvalidArgumentException;
use Maas\Catalog\Model\ResourceModel\Product;
use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Eav\Model\Cache\Type;
use Magento\Eav\Model\Entity\Attribute;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\UrlInterface;

/**
 * Class AttributeSet
 *
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 */
class AttributeSet extends \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AttributeSet
{
    const CACHE_KEY_CORE = 'maas_product_edit_core_attribute_sets';

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var Product
     */
    protected $productResource;

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @param LocatorInterface $locator
     * @param CollectionFactory $attributeSetCollectionFactory
     * @param UrlInterface $urlBuilder
     * @param ProductMetadataInterface $productMetadata
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param Product $productResource
     */
    public function __construct(
        LocatorInterface $locator,
        CollectionFactory $attributeSetCollectionFactory,
        UrlInterface $urlBuilder,
        ProductMetadataInterface $productMetadata,
        CacheInterface $cache,
        SerializerInterface $serializer,
        Product $productResource
    ) {
        $this->productMetadata = $productMetadata;
        $this->cache = $cache;
        $this->productResource = $productResource;
        $this->serializer = $serializer;
        parent::__construct($locator, $attributeSetCollectionFactory, $urlBuilder);
    }

    /**
     * Return options for select, depending on the context
     *
     * @return array
     * @since 101.0.0
     */
    public function getOptions()
    {
        $product = $this->locator->getProduct();
        if ($product->getId() && $product->getData('maas_is_maas_product')) {
            /** @var Collection $collection */
            $collection = $this->attributeSetCollectionFactory->create();
            $collection->setEntityTypeFilter($this->productResource->getTypeId())
                ->addFieldToSelect('attribute_set_id', 'value')
                ->addFieldToSelect('attribute_set_name', 'label')
                ->addFieldToFilter('attribute_set_id', $product->getAttributeSetId())
                ->setOrder(
                    'attribute_set_name',
                    Collection::SORT_ORDER_ASC
                );
            $collectionData = $collection->getData() ?? [];
            $this->addDisableTmpl($collectionData);
            return $collectionData;
        } else {
            $cached = $this->cache->load(self::CACHE_KEY_CORE);
            if ($cached) {
                try {
                    return $this->serializer->unserialize($cached);
                } catch (InvalidArgumentException $e) {
                    // do nothing
                }
            }
            /** @var Collection $collection */
            $collection = $this->attributeSetCollectionFactory->create();
            $collection->setEntityTypeFilter($this->productResource->getTypeId())
                ->addFieldToSelect('attribute_set_id', 'value')
                ->addFieldToSelect('attribute_set_name', 'label')
                ->addFieldToFilter('attribute_set_name', ['nlike' => 'Maas %'])
                ->addFieldToFilter('attribute_set_name', ['neq' => 'Maas'])
                ->setOrder(
                    'attribute_set_name',
                    Collection::SORT_ORDER_ASC
                );
            $collectionData = $collection->getData() ?? [];

            $this->addDisableTmpl($collectionData);

            $this->cache->save($this->serializer->serialize($collectionData), self::CACHE_KEY_CORE, [
                Attribute::CACHE_TAG,
                Type::CACHE_TAG,
                Set::ATTRIBUTES_CACHE_ID
            ]);

            return $collectionData;
        }
    }

    /**
     * Add this property in 2.2 and 2.3 only
     *
     * @param array $collectionData
     */
    protected function addDisableTmpl(&$collectionData)
    {
        $versionParts = explode('.', $this->productMetadata->getVersion());
        if ($versionParts[0] == 2 && $versionParts[1] < 4) {
            array_walk(
                $collectionData,
                function (&$attribute) {
                    $attribute['__disableTmpl'] = true;
                }
            );
        }
    }
}
