<?php

namespace Maas\AttributeSet\Plugin;

use Maas\AttributeSet\Api\AttributeSetInfoRepositoryInterface;
use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Eav\Api\Data\AttributeSetExtensionFactory;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Maas\AttributeSet\Model\AttributeSetInfoFactory;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class AttributeSetGetPlugin
 * @package Maas\AttributeSet\Plugin
 */
class AttributeSetGetPlugin
{
    private AttributeSetInfoRepositoryInterface $attributeSetInfoRepository;
    private AttributeSetInfoFactory $attributeSetInfoFactory;
    private AttributeSetExtensionFactory $attributeSetExtensionFactory;

    /**
     * @param AttributeSetInfoRepositoryInterface $attributeSetInfoRepository
     * @param AttributeSetInfoFactory $attributeSetInfoFactory
     * @param AttributeSetExtensionFactory $attributeSetExtensionFactory
     */
    public function __construct(
        AttributeSetInfoRepositoryInterface $attributeSetInfoRepository,
        AttributeSetInfoFactory $attributeSetInfoFactory,
        \Magento\Eav\Api\Data\AttributeSetExtensionFactory $attributeSetExtensionFactory
    ) {
        $this->attributeSetInfoRepository = $attributeSetInfoRepository;
        $this->attributeSetInfoFactory = $attributeSetInfoFactory;
        $this->attributeSetExtensionFactory = $attributeSetExtensionFactory;
    }

    /**
     * @param AttributeSetRepositoryInterface $subject
     * @param AttributeSetInterface $resultAttributeSet
     * @return AttributeSetInterface
     */
    public function afterGet(
        AttributeSetRepositoryInterface $subject,
        AttributeSetInterface $resultAttributeSet
    ): AttributeSetInterface {
        return $this->getExtraInfo($resultAttributeSet);;
    }

    /**
     * @param AttributeSetInterface $attributeSet
     * @return AttributeSetInterface
     */
    private function getExtraInfo(
        AttributeSetInterface $attributeSet
    ): AttributeSetInterface {
        try {
            $attributeSetInfo = $this->attributeSetInfoRepository->get($attributeSet->getId());
        } catch (NoSuchEntityException $e) {
            return $attributeSet;
        }
        $attributeSetExtensionAttributes = $attributeSet->getExtensionAttributes();
        $attributeSetExtensionAttributes = $attributeSetExtensionAttributes ? $attributeSetExtensionAttributes : $this->attributeSetExtensionFactory->create();
        //create the extra info
        $extraInfo = $this->attributeSetInfoFactory->create();
        $extraInfo->setMaasCategoryId($attributeSetInfo->getMaasCategoryId());
        $attributeSetExtensionAttributes->setData('extra_info', $extraInfo);
        $attributeSet->setExtensionAttributes($attributeSetExtensionAttributes);

        return $attributeSet;
    }
}
