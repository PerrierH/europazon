<?php

namespace Maas\AttributeSet\Plugin;

use Maas\AttributeSet\Api\AttributeSetInfoRepositoryInterface;
use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;

/**
 * Class AttributeSetSavePlugin
 * @package Maas\AttributeSet\Plugin
 */
class AttributeSetSavePlugin
{
    /**
     * @var AttributeSetInfoRepositoryInterface
     */
    private AttributeSetInfoRepositoryInterface $attributeSetInfoRepository;

    /**
     * @param AttributeSetInfoRepositoryInterface $attributeSetInfoRepository
     */
    public function __construct(AttributeSetInfoRepositoryInterface $attributeSetInfoRepository)
    {
        $this->attributeSetInfoRepository = $attributeSetInfoRepository;
    }

    /**
     * @param AttributeSetRepositoryInterface $subject
     * @param AttributeSetInterface $resultAttributeSet
     * @return AttributeSetInterface
     */
    public function afterSave(
        AttributeSetRepositoryInterface $subject,
        AttributeSetInterface $resultAttributeSet
    ): AttributeSetInterface {
        return $this->saveExtraInfo($resultAttributeSet);
    }

    /**
     * @param AttributeSetInterface $attributeSet
     * @return AttributeSetInterface
     */
    private function saveExtraInfo(
        AttributeSetInterface $attributeSet
    ): AttributeSetInterface {
        $extensionAttributes = $attributeSet->getExtensionAttributes();
        if (
            null !== $extensionAttributes &&
            null !== $extensionAttributes->getExtraInfo()
        ) {
            $extraInfoAttributeValue = $extensionAttributes->getExtraInfo();
            $extraInfoAttributeValue->setId($attributeSet->getId());
            try {
                $this->attributeSetInfoRepository->save($extraInfoAttributeValue);
            } catch (\Exception $e) {
                throw new CouldNotSaveException(
                    __('Could not add attribute to attribute set: "%1"', $e->getMessage()),
                    $e
                );
            }
        }
        return $attributeSet;
    }
}
