<?php

namespace Maas\AttributeSet\Plugin;

use Magento\Catalog\Controller\Adminhtml\Product\Set\Save;
use Magento\Catalog\Api\AttributeSetRepositoryInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;

/**
 * Class AttributeSetPlugin
 * @package Maas\AttributeSet\Plugin
 */
class AttributeSetPlugin
{
    /**
     * @var AttributeSetRepositoryInterface
     */
    protected $attributeSetRepository;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * AttributeSetPlugin constructor.
     *
     * @param AttributeSetRepositoryInterface $attributeSetRepository
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
        AttributeSetRepositoryInterface $attributeSetRepository,
        JsonFactory $resultJsonFactory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->attributeSetRepository = $attributeSetRepository;
    }

    /**
     * @param Save $subject
     * @param callable $proceed
     *
     * @return Json
     */
    public function aroundExecute(Save $subject, callable $proceed)
    {
        $attributeSetId = $subject->getRequest()->getParam('id', false);
        $attributeSet = $this->getAttributeSetById($attributeSetId);
        if ($attributeSet && $this->isMaasAttributeSet($attributeSet)) {
            $response['error'] = 0;
            $response['url'] = $subject->getUrl('catalog/*/');
            return $this->resultJsonFactory->create()->setData($response);

        }
        return $proceed();
    }

    /**
     * @param $id
     *
     * @return bool|AttributeSetInterface
     */
    private function getAttributeSetById($id)
    {
        try {
            $attributeSet = $this->attributeSetRepository->get($id);
        } catch (\Exception $exception) {
            $attributeSet = false;
        }
        return $attributeSet;
    }

    /**
     * @param $attributeSet
     *
     * @return bool
     */
    private function isMaasAttributeSet($attributeSet)
    {
        $pos = strpos(mb_strtolower($attributeSet->getAttributeSetName()), 'maas');
        if (($pos !== false)) {
            return true;
        }
        return false;
    }
}
