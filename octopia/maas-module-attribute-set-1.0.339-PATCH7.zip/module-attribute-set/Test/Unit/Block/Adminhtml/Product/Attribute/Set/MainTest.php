<?php

namespace Maas\AttributeSet\Test\Unit\Block\Adminhtml\Product\Attribute\Set;

use Maas\AttributeSet\Block\Adminhtml\Product\Attribute\Set\Main as AttributeSet;
use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Model\Entity\Product\Attribute\Group\AttributeMapperInterface;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;
use Magento\Eav\Model\Entity\Attribute\GroupFactory;
use Magento\Eav\Model\Entity\Attribute\Set as EavAttributeSet;
use Magento\Eav\Model\Entity\TypeFactory;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\Serializer\Json;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

/**
 * Class MainTest
 * @package Maas\AttributeSet\Test\Unit\Block\Adminhtml\Product\Attribute\Set
 */
class MainTest extends TestCase
{
    const PARENT_RETURN = 'serialized parent return';

    /**
     * @var ObjectManager
     */
    private $objectManager;
    /**
     * @var Context
     */
    private $context;
    /**
     * @var TypeFactory
     */
    private $typeFactory;
    /**
     * @var GroupFactory
     */
    private $groupFactory;
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;
    /**
     * @var AttributeMapperInterface
     */
    private $attributeMapperInterface;

    /**
     * set up
     */
    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->context = $this->createMock(Context::class);
        $this->typeFactory = $this->createMock(TypeFactory::class);
        $this->groupFactory = $this->createMock(GroupFactory::class);
        $this->collectionFactory = $this->createMock(CollectionFactory::class);
        $this->registry = $this->createMock(Registry::class);
        $this->attributeMapperInterface = $this->createMock(AttributeMapperInterface::class);
    }

    /**
     * @param $attributes
     *
     * @return MockObject
     */
    private function getAttributSet($attributes)
    {
        $eavAttributeSet = $this->createMock(EavAttributeSet::class);
        $eavAttributeSet->expects($this->any())->method('getAttributeSetName')->willReturn($attributes['attributeSetName']);

        $registry = $this->createMock(Registry::class);
        $registry->expects($this->any())->method('registry')->willReturn($eavAttributeSet);

        $serializer = $this->createMock(Json::class);
        if (isset($attributes['unserialize'])) {
            $serializer->expects($this->any())->method('unserialize')->willReturn($attributes['unserialize']);
        }

        $encoder = $this->createMock(EncoderInterface::class);
        if (isset($attributes['encode'])) {
            $encoder->expects($this->any())->method('encode')->willReturn($attributes['encode']);
        }

        $attributeSet = $this->getMockBuilder(AttributeSet::class)
            ->setConstructorArgs([
                'context' => $this->context,
                'encoderInterface' => $encoder,
                'typeFactory' => $this->typeFactory,
                'groupFactory' => $this->groupFactory,
                'collectionFactory' => $this->collectionFactory,
                'registry' => $registry,
                'attributeMapperInterface' => $this->attributeMapperInterface,
                'serializer' => $serializer
            ])
            ->setMethods(['callParentGetGroupTreeJson', 'callParentGetAttributeTreeJson'])
            ->getMock();

        $attributeSet->expects($this->any())->method('callParentGetGroupTreeJson')
            ->willReturn(self::PARENT_RETURN);
        $attributeSet->expects($this->any())->method('callParentGetAttributeTreeJson')
            ->willReturn(self::PARENT_RETURN);

        return $attributeSet;
    }

    /**
     * @dataProvider getGroupTreeJsonProvider
     *
     * @param $attributes
     * @param $expected
     */
    public function testGetGroupTreeJson($attributes, $expected)
    {
        $attributeSet = $this->getAttributSet($attributes);

        $this->assertEquals($expected, $attributeSet->getGroupTreeJson());
    }

    /**
     * @return array[]
     */
    public function getGroupTreeJsonProvider()
    {
        return [
            'attribut set is maas but is not editable' => [
                [
                    'attributeSetName' => 'maas',
                    'editAttributeSet' => true,
                ]
                ,
                self::PARENT_RETURN
            ],
            'attribut set is not maas' => [
                [
                    'attributeSetName' => 'default',
                    'editAttributeSet' => false,
                ]
                ,
                self::PARENT_RETURN
            ],
            'attribut set is maas and is editable' => [
                [
                    'attributeSetName' => 'maas',
                    'editAttributeSet' => false,
                    'unserialize' => [
                        123456 => [
                            'allowDrop' => true,
                            'allowDrag' => true,
                        ]
                    ],
                    'encode' => 'encode result',
                ],
                'encode result'
            ],
        ];
    }

    /**
     * @dataProvider getAttributeTreeJsonProvider
     *
     * @param $attributes
     * @param $expected
     */
    public function testGetAttributeTreeJson($attributes, $expected)
    {
        $attributeSet = $this->getAttributSet($attributes);

        $this->assertEquals($expected, $attributeSet->getAttributeTreeJson());
    }

    /**
     * @return array[]
     */
    public function getAttributeTreeJsonProvider()
    {
        return [
            'attribut set is maas but is not editable' => [
                [
                    'attributeSetName' => 'maas',
                    'editAttributeSet' => true,
                ]
                ,
                self::PARENT_RETURN
            ],
            'attribut set is not maas' => [
                [
                    'attributeSetName' => 'default',
                    'editAttributeSet' => false,
                ]
                ,
                self::PARENT_RETURN
            ],
            'attribut set is maas and is editable' => [
                [
                    'attributeSetName' => 'maas',
                    'editAttributeSet' => false,
                    'unserialize' => [
                        123456 => [
                            'allowDrop' => true,
                            'allowDrag' => true,
                            'cls' => 'test',
                        ]
                    ],
                    'encode' => 'encode result',
                ],
                'encode result'
            ],
        ];
    }
}
