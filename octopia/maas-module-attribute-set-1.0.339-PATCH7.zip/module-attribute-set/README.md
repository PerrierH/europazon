# Overview
## Purpose of module

The Maas module convert your e-commerce website into a marketplace. 
After defining the catalog of products to insert in Magento in the "sales channel interface", these products will be imported using this module. 
Then, the rule engine will automatically add products to the front office categories of your choice.

# Deployment
## System requirements

The Maas_Core module does not have any specific system requirements.

## Install
##### 1 - Manually
Copy module source to the app/code/ Directory

##### 2 - Via Composer
```bash
composer require maas/module-maas
```
Enter the following at the command line
```
php bin/magento setup:upgrade
```

## Dependencies
You can find the list of modules that have dependencies on Maas_Core module, in the `require` section of the `composer.json` file located in the same directory as this `README.md` file.

if you install the module Maas_Core manually, you have to install Commonmark module :
```bash
composer require league/commonmark
```

## Uninstall

### Actions
Uninstall Maas Plugin modules command will execute the following actions:

* Disable Maas plugin modules on the backend
* Remove all Maas categories ans products
* Remove all Maas attributes from attribute sets
* Delete all Maas attributes
* Remove Maas attribute set
* Drop Maas plugins tables
* Delete Maas System Configuration
* Remove Maas Order Status

N.B: Maas plugins source code will not be removed from app/code directory

### Commands
To uninstall all Mass plugin modules, execute the following command:

```bash
php bin/magento maas:uninstall
```
if you want to uninstall specific modules:
```bash
php bin/magento maas:uninstall Module_A Module_B
```