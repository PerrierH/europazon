<?php

namespace Maas\AttributeSet\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface AttributeSetInfoInterface
 * @package Maas\AttributeSet\Api\Data
 */
interface AttributeSetInfoInterface extends ExtensibleDataInterface
{
    const MAIN_TABLE = 'maas_eav_attribute_set_info';

    const ATTRIBUTE_SET_ID = 'attribute_set_id';
    const MAAS_CATEGORY_ID = 'maas_category_id';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return AttributeSetInfoInterface
     */
    public function setId($id);

    /**
     * @return string
     */
    public function getMaasCategoryId(): string;

    /**
     * @param string $categoryMaasId
     * @return AttributeSetInfoInterface
     */
    public function setMaasCategoryId(string $categoryMaasId): AttributeSetInfoInterface;
}
