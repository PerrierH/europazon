<?php

namespace Maas\AttributeSet\Api;

use Maas\AttributeSet\Api\Data\AttributeSetInfoInterface;
use Maas\AttributeSet\Api\Data\AttributeSetInfoSearchResultsInterface;
use Maas\Core\Model\Service\Instantiate;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Interface AttributeSetInfoRepositoryInterface
 * @package Maas\AttributeSet\Api
 */
interface AttributeSetInfoRepositoryInterface
{
    /**
     * @param int $id
     * @return \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface
     * @throws NoSuchEntityException
     */
    public function get(int $id): \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface;

    /**
     * @param \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface $attributeSetInfo
     * @return AttributeSetInfoInterface
     */
    public function save(\Maas\AttributeSet\Api\Data\AttributeSetInfoInterface $attributeSetInfo): \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface;
}
