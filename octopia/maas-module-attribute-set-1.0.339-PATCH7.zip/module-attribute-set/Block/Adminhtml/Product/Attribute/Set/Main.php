<?php

namespace Maas\AttributeSet\Block\Adminhtml\Product\Attribute\Set;

use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Block\Adminhtml\Product\Attribute\Set\Main as ParentMain;
use Magento\Catalog\Model\Entity\Product\Attribute\Group\AttributeMapperInterface;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;
use Magento\Eav\Model\Entity\Attribute\GroupFactory;
use Magento\Eav\Model\Entity\TypeFactory;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\Serialize\SerializerInterface;

/**
 * Class Main
 * @package Maas\AttributeSet\Block\Adminhtml\Product\Attribute\Set
 */
class Main extends ParentMain
{
    /**
     * @var Json
     */
    private $serializer;

    /**
     * Main constructor.
     * @param Context $context
     * @param EncoderInterface $jsonEncoder
     * @param TypeFactory $typeFactory
     * @param GroupFactory $groupFactory
     * @param CollectionFactory $collectionFactory
     * @param Registry $registry
     * @param AttributeMapperInterface $attributeMapper
     * @param SerializerInterface $serializer
     * @param array $data
     */
    public function __construct(
        Context $context,
        EncoderInterface $jsonEncoder,
        TypeFactory $typeFactory,
        GroupFactory $groupFactory,
        CollectionFactory $collectionFactory,
        Registry $registry,
        AttributeMapperInterface $attributeMapper,
        SerializerInterface $serializer,
        array $data = []
    )
    {
        parent::__construct($context, $jsonEncoder, $typeFactory, $groupFactory, $collectionFactory, $registry, $attributeMapper, $data);
        $this->serializer = $serializer;
    }

    /**
     * Prepare Global Layout
     *
     * @codeCoverageIgnore
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        if (!$this->isMaasAttributeSet()) {
            return parent::_prepareLayout();
        }
        $this->addChild('group_tree', \Magento\Catalog\Block\Adminhtml\Product\Attribute\Set\Main\Tree\Group::class);
        $this->addChild('edit_set_form', \Magento\Catalog\Block\Adminhtml\Product\Attribute\Set\Main\Formset::class);
        $this->getToolbar()->addChild(
            'back_button',
            \Magento\Backend\Block\Widget\Button::class,
            [
                'label' => __('Back'),
                'onclick' => 'setLocation(\'' . $this->getUrl('catalog/*/') . '\')',
                'class' => 'back'
            ]
        );
        return $this;
    }

    /**
     * @return string
     */
    public function getGroupTreeJson()
    {
        if (!$this->isMaasAttributeSet()) {
            return $this->callParentGetGroupTreeJson();
        }
        $items = $this->serializer->unserialize($this->callParentGetGroupTreeJson());
        foreach ($items as $key => $item) {
            $items[$key]['allowDrop'] = false;
            $items[$key]['allowDrag'] = false;
            $items[$key]['cls'] = 'system-leaf';
        }
        return $this->_jsonEncoder->encode($items);
    }

    /*
     * This method is here for unit test purposes
     *
     * @return string
     * @codeCoverageIgnore
     */
    public function callParentGetGroupTreeJson()
    {
        return parent::getGroupTreeJson();
    }

    /**
     * Retrieve Unused in Attribute Set Attribute Tree as JSON
     *
     * @return string
     */
    public function getAttributeTreeJson()
    {
        if (!$this->isMaasAttributeSet()) {
            return $this->callParentGetAttributeTreeJson();
        }
        $items = $this->serializer->unserialize($this->callParentGetAttributeTreeJson());
        foreach ($items as $key => $item) {
            $items[$key]['allowDrop'] = false;
            $items[$key]['allowDrag'] = false;
        }
        return $this->_jsonEncoder->encode($items);
    }

    /*
     * This method is here for unit test purposes
     *
     * @return string
     * @codeCoverageIgnore
     */
    public function callParentGetAttributeTreeJson()
    {
        return parent::getAttributeTreeJson();
    }

    /**
     * @return bool
     */
    private function isMaasAttributeSet()
    {
        $pos = strpos(mb_strtolower($this->_getAttributeSet()->getAttributeSetName()), 'maas');
        if (($pos !== false)) {
            return true;
        }
        return false;
    }

    /**
     * Retrieve Attribute Set Edit Form HTML
     *
     * @return string
     */
    public function getSetFormHtml()
    {
        $attributeSet = $this->_getAttributeSet();
        $attributeSetExtensionAttributes = $attributeSet->getExtensionAttributes();
        if ($attributeSetExtensionAttributes) {
            $extraInfo = $attributeSetExtensionAttributes->getExtraInfo();
            if ($extraInfo)  {
                return __('Maas Category Id: %1', $extraInfo->getMaasCategoryId());
            }
        }
        return parent::getSetFormHtml();
    }
}
