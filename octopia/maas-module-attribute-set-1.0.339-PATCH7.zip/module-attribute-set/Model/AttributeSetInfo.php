<?php

namespace Maas\AttributeSet\Model;

use Maas\AttributeSet\Api\Data\AttributeSetInfoInterface;;
use Magento\Framework\Model\AbstractModel;

/**
 * Class AttributeSetInfo
 * @package Maas\AttributeSet\Model
 */
class AttributeSetInfo extends AbstractModel implements AttributeSetInfoInterface
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Maas\AttributeSet\Model\ResourceModel\AttributeSetInfo::class);
    }

    /**
     * @inheritDoc
     */
    public function getMaasCategoryId(): string
    {
        return $this->getData(self::MAAS_CATEGORY_ID);
    }

    /**
     * @inheritDoc
     */
    public function setMaasCategoryId(string $categoryMaasId): AttributeSetInfoInterface
    {
        return $this->setData(self::MAAS_CATEGORY_ID, $categoryMaasId);
    }
}
