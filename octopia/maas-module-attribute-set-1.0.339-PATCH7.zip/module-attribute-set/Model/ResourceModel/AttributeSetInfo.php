<?php

namespace Maas\AttributeSet\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class AttributeSetInfo
 * @package Maas\AttributeSet\Model\ResourceModel
 */
class AttributeSetInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface::MAIN_TABLE,
            \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface::ATTRIBUTE_SET_ID
        );
        $this->_isPkAutoIncrement = false;
    }
}
