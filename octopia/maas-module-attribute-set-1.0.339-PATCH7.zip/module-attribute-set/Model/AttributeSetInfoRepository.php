<?php

namespace Maas\AttributeSet\Model;

use Maas\AttributeSet\Model\ResourceModel\AttributeSetInfo;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class AttributeSetInfoRepository
 * @package Maas\AttributeSet\Model
 */
class AttributeSetInfoRepository implements \Maas\AttributeSet\Api\AttributeSetInfoRepositoryInterface
{
    protected AttributeSetInfo $resource;
    private AttributeSetInfoFactory $modelFactory;

    /**
     * AttributeSetInfoRepository constructor.
     *
     * @param AttributeSetInfo $resource
     * @param AttributeSetInfoFactory $modelFactory
     */
    public function __construct(
        AttributeSetInfo $resource,
        \Maas\AttributeSet\Model\AttributeSetInfoFactory $modelFactory
    ) {
        $this->resource = $resource;
        $this->modelFactory = $modelFactory;
    }

    /**
     * @inheritDoc
     */
    public function get(int $id): \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface
    {
        $model = $this->modelFactory->create();
        $this->resource->load($model, $id);
        if (!$model->getId()) {
            throw NoSuchEntityException::singleField('id', $id);
        }
        return $model;
    }

    /**
     * @inheritDoc
     */
    public function save(\Maas\AttributeSet\Api\Data\AttributeSetInfoInterface $attributeSetInfo): \Maas\AttributeSet\Api\Data\AttributeSetInfoInterface
    {
        try {
            $this->resource->save($attributeSetInfo);
        } catch (\Exception $e) {

        }
        return $attributeSetInfo;
    }
}
