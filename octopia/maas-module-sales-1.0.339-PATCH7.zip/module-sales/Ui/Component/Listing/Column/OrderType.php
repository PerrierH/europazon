<?php

namespace Maas\Sales\Ui\Component\Listing\Column;

use Maas\Core\Model\Config;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class OrderType
 *
 * @package Maas\Sales\Ui\Component\Listing\Column
 */
class OrderType extends Column
{
    /**
     * @var OrderRepositoryInterface
     */
    protected $_orderRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $_searchCriteria;

    /**
     * @var Config
     */
    private $configModel;

    /**
     * OrderType constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param SearchCriteriaBuilder $criteria
     * @param array $components
     * @param Config $configModel
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder $criteria,
        Config $configModel,
        array $components = [],
        array $data = []
    ) {
        $this->_orderRepository = $orderRepository;
        $this->_searchCriteria = $criteria;
        $this->configModel = $configModel;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $order = $this->_orderRepository->get($item["entity_id"]);
                $type = $order->getExtensionAttributes()->getExtraInfo()->getOrderType();
                if ($type == SalesOrderInfo::ORDER_TYPE_MAAS) {
                    $orderType = __('Octopia');
                } else {
                        $orderType = __('Core');
                }

                $item[$this->getData('name')] = $orderType;
            }
        }

        return $dataSource;
    }

    /**
     * @codeCoverageIgnore
     * disable maas order type if module disabled
     */
    public function prepare()
    {
        if (!$this->configModel->isModuleEnabled()) {
            $config = $this->getData('config');
            $config['componentDisabled'] = true;
            $this->setData('config', $config);
        }
        parent::prepare();
    }
}
