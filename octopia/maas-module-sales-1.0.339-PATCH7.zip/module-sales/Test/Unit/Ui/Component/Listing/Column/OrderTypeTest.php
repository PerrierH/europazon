<?php

namespace Maas\Sales\Test\Unit\Ui\Component\Column;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Ui\Component\Listing\Column\OrderType;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;


class OrderTypeTest extends AbstractTestCase
{

    /** @var OrderRepositoryInterface */
    private $orderRepository;

    /** @var OrderType */
    private $instance;

    /** @var MockObject */
    private $orderMock;

    /** @var OrderExtensionInterface */
    private $orderExtensionAttribute;

    /** @var OrderExtensionInterface */
    private $orderExtensionAttributeExtraInfo;

    public function testPrepareDataSourceCore()
    {
        $dataSource = [
            'data' => [
                'items' => [
                    [
                        'entity_id' => 1
                    ]
                ]
            ]
        ];

        $this->orderExtensionAttributeExtraInfo->expects($this->any())->method('getOrderType')->willReturn(SalesOrderInfo::ORDER_TYPE_CORE);

        $newDataSource = $this->instance->prepareDataSource($dataSource);

        $this->assertEquals('Core', $newDataSource['data']['items'][0]['order_type']);
    }

    public function testPrepareDataSourceMaas()
    {
        $dataSource = [
            'data' => [
                'items' => [
                    [
                        'entity_id' => 1
                    ]
                ]
            ]
        ];

        $this->orderExtensionAttributeExtraInfo->expects($this->any())->method('getOrderType')->willReturn(SalesOrderInfo::ORDER_TYPE_MAAS);

        $newDataSource = $this->instance->prepareDataSource($dataSource);

        $this->assertEquals('Octopia', $newDataSource['data']['items'][0]['order_type']);
    }

    protected function setUp()
    {
        $objectManager = new ObjectManager($this);

        $this->orderExtensionAttributeExtraInfo = $this->createMock(SalesOrderInfoInterface::class);

        $this->orderExtensionAttribute = $this->createMock(OrderExtensionInterface::class);
        $this->orderExtensionAttribute->expects($this->any())->method('getExtraInfo')->willReturn($this->orderExtensionAttributeExtraInfo);


        $this->orderMock = $this->createMock(Order::class);
        $this->orderMock->expects($this->any())->method('getExtensionAttributes')->willReturn($this->orderExtensionAttribute);

        $this->orderRepository = $this->createMock(OrderRepositoryInterface::class);
        $this->orderRepository->expects($this->any())->method('get')->willReturn($this->orderMock);


        $this->instance = $objectManager->getObject(OrderType::class, [
            'orderRepository' => $this->orderRepository
        ]);
        $this->instance->setData('name', 'order_type');
    }
}