<?php

namespace Maas\Sales\Test\Unit\Observer;

use Generator;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\RegisterOfferAndSellerDuringOrderProcess;
use Maas\Sales\Observer\OrderAdditionalOptions;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class OrderItemAdditionalOptionsTest
 *
 * @package Maas\Sales\Test\Unit\Observer
 */
class OrderAdditionalOptionsTest extends AbstractTestCase
{

    /**
     * @var object
     */
    private $register;
    /**
     * @var OrderAdditionalOptions
     */
    private $sut;

    /**
     *
     */
    public function testHandleOrderDataValidationOnExecute()
    {
        $orderMock = $this->buildOrder();
        $quoteMock = $this->buildQuote();
        //Arrange prepare data
        $observer = $this->buildObserver(
            [
                ['order', null, $orderMock],
                ['quote', null, $quoteMock],
            ]
        );

        $this->register->expects($this->once())->method('validateOrderData')->with($orderMock, $quoteMock);
        //Act call function
        $this->sut->execute($observer);
    }

    /**
     * @return MockObject
     */
    private function buildOrder()
    {
        return $this->getMockBuilder(OrderInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildQuote()
    {
        return $this->getMockBuilder(CartInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @param array $eventDataReturnMap
     *
     * @return Observer|PHPUnit_Framework_MockObject_MockObject
     */
    private function buildObserver(array $eventDataReturnMap)
    {
        /** @var Observer|PHPUnit_Framework_MockObject_MockObject $observerMock */
        $observerMock = $this->createMock(Observer::class);
        /** @var Event|PHPUnit_Framework_MockObject_MockObject $eventMock */
        $eventMock = $this->getMockBuilder(Event::class)->disableOriginalConstructor()
            ->setMethods(['getData'])
            ->getMock();
        $observerMock->expects($this->once())->method('getEvent')->willReturn($eventMock);
        $eventMock->expects($this->any())->method('getData')
            ->willReturnMap(
                $eventDataReturnMap
            );
        return $observerMock;
    }

    /**
     * @param CartInterface|null $quote
     * @param OrderInterface|null $order
     *
     * @dataProvider eventDataReturnProvider
     */
    public function testDoNotCallOrderDataValidationOnExecuteWhen(?CartInterface $quote, ?OrderInterface $order)
    {
        //Arrange prepare data
        $observer = $this->buildObserver(
            [
                ['order', null, $order],
                ['quote', null, $quote],
            ]
        );
        // Assert
        $this->register->expects($this->never())->method('validateOrderData');
        //Act call function
        $this->sut->execute($observer);
    }

    /**
     * @return Generator
     */
    public function eventDataReturnProvider()
    {
        yield from [
            'quote is null' => [null, $this->buildOrder()],
            'order is null' => [$this->buildQuote(), null],
            'order and quote are null' => [null, null],
        ];
    }

    /**
     * Set Up
     *
     * @return void
     */
    protected function setUp()
    {
        //$objectManager = new ObjectManager($this);
        $this->register = $this->createMock(RegisterOfferAndSellerDuringOrderProcess::class);
        $this->sut = new OrderAdditionalOptions(
            $this->register
        );
    }
}
