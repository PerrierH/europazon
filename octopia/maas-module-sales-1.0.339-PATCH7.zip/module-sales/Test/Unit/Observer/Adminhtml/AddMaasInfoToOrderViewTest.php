<?php

namespace Maas\Sales\Test\Unit\Observer\Adminhtml;

use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\Exception\InputException;
use PHPUnit\Framework\TestCase;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\App\RequestInterface;
use Maas\Sales\Observer\Adminhtml\AddMaasInfoToOrderView;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Framework\View\Layout;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\View\Layout\ProcessorInterface;

class AddMaasInfoToOrderViewTest extends TestCase
{

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $requestInterface;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $orderRepositoryInterface;
    /**
     * @var AddMaasInfoToOrderView
     */
    private $stub;

    public function setUp()
    {
        $this->orderRepositoryInterface = AnyBuilder::createForClass($this, OrderRepositoryInterface::class)
            ->build();
        $this->requestInterface = AnyBuilder::createForClass($this, RequestInterface::class, [
            'getParam' => [$this->any(), 7, AnyBuilder::RETURN_VALUE, 'order_id']
        ])->build();
        $this->stub = new AddMaasInfoToOrderView(
            $this->orderRepositoryInterface,
            $this->requestInterface
        );
    }

    /**
     * @dataProvider wrongFullActionName
     */
    public function testWrongFullNameAction($fullNameAction)
    {
        $observer = $this->createMockObserver($fullNameAction, $this->never(), false);
        $this->stub->execute($observer);
    }


    public function testWithFullNameActionAndNoExtensionAttributes()
    {
        $this->createMockExtensionAttribute($this->never(), false);
        $layout = $this->createMockLayout($this->never());
        $order = $this->createMockOrder();
        $this->orderRepositoryInterface->expects($this->once())->method('get')->willReturn($order);
        $observer = $this->createMockObserver('sales_order_view', $this->once(), $layout);
        $this->stub->execute($observer);
    }

    public function testWithFullNameActionAndWithExtensionAttributesNoExtraInfo()
    {
        $extensionAttribute = $this->createMockExtensionAttribute($this->once(), null);
        $order = $this->createMockOrder($extensionAttribute);
        $layout = $this->createMockLayout($this->never());
        $this->createMockLayout($this->never());
        $this->orderRepositoryInterface->expects($this->any())->method('get')->willReturn($order);
        $observer = $this->createMockObserver('sales_order_view', $this->once(), $layout);
        $this->stub->execute($observer);
    }

    public function testWithFullNameActionAndWithExtensionAttributesWithExtraInfo()
    {
        $extensionAttribute = $this->createMockExtensionAttribute($this->once(), SalesOrderInfo::ORDER_TYPE_MAAS);
        $order = $this->createMockOrder($extensionAttribute);
        $layout = $this->createMockLayout($this->once(), $this->createMockProcessor());
        $this->orderRepositoryInterface->expects($this->any())->method('get')->willReturn($order);
        $observer = $this->createMockObserver('sales_order_view', $this->once(), $layout);
        $this->stub->execute($observer);
    }

    public function testInputException()
    {
        $layout = $this->createMockLayout($this->never());
        $this->createMockLayout($this->never());
        $this->orderRepositoryInterface->expects($this->any())->method('get')->willThrowException(
            new InputException(__('An ID is needed. Set the ID and try again.'))
        );
        $observer = $this->createMockObserver('sales_order_view', $this->once(), $layout);
        $this->stub->execute($observer);
    }

    private function createMockObserver($fullNameAction, $numberOfCalls, $returnValue)
    {
        return AnyBuilder::createForClass(
            $this,
            Observer::class,
            [
                'getEvent' => [
                    $this->any(),
                    $this->createMockEvent($fullNameAction, $numberOfCalls, $returnValue)
                ]
            ]
        )
            ->build();
    }

    private function createMockEvent($fullNameAction, $numberOfCalls, $returnValue)
    {
        return AnyBuilder::createForClass($this, Event::class, [
            'getFullActionName' => [
                $this->once(),
                $fullNameAction,
                AnyBuilder::RETURN_VALUE
            ],
            'getLayout' => [
                $numberOfCalls,
                $returnValue,
                AnyBuilder::RETURN_VALUE
            ]

        ])
            ->build();
    }

    private function createMockLayout($numberOfCalls, $value = null)
    {
        return AnyBuilder::createForClass(
            $this,
            Layout::class,
            [
                'getUpdate' => [
                    $numberOfCalls,
                    $value,
                    AnyBuilder::RETURN_VALUE
                ]
            ]
        )
            ->build();
    }

    public function wrongFullActionName()
    {
        yield from [
            'full name action is not sales_order_view' => ['not_sales_order_view'],
            'full name action is null' => [null],
        ];
    }

    private function createMockOrder($returnValue = false)
    {
        return OrderBuilder::create($this, [
            'getExtensionAttributes' => [
                $this->any(),
                $returnValue,
                OrderBuilder::RETURN_VALUE
            ]
        ])->build();
    }

    private function createMockExtensionAttribute($nbTimes, $value)
    {
        return AnyBuilder::createForClass($this, OrderExtensionInterface::class, [
            'getExtraInfo' => [$nbTimes, $this->createMockSalesOrderInfo($value), AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    private function createMockSalesOrderInfo($returnValue)
    {
        return AnyBuilder::createForClass($this, SalesOrderInfo::class, [
            'getOrderType' => [$this->any(), $returnValue, AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    private function createMockProcessor()
    {
        return AnyBuilder::createForClass($this, ProcessorInterface::class)->build();
    }
}
