<?php


namespace Maas\Sales\Test\Unit\Observer;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Observer\CreateQuoteItemInfoAfterCartItemAdd;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Quote\Api\Data\CartItemExtensionInterface;
use Magento\Quote\Api\Data\CartItemInterface;

/**
 * Class ResetIdInExtraInfoOnCartItemAddTest
 *
 * @package Maas\Sales\Test\Unit\Observer
 */
class ResetIdInExtraInfoOnCartItemAddTest extends AbstractTestCase
{
    /**
     * @var object
     */
    protected $instance;

    protected $item1id = 101;
    protected $item2id = 102;
    protected $extItem1id = 103;
    protected $extItem2id = 102;

    public function testResetId()
    {
        $quoteItem1 = $this->getInstanceMock(CartItemInterface::class, [], [
            'getId' => [2, $this->item1id],
            'getExtensionAttributes' => [
                1,
                $this->getInstanceMock(CartItemExtensionInterface::class, [], [
                    'getExtraInfo' => [
                        3,
                        $this->getInstanceMock(SalesQuoteItemInfoInterface::class, [], [
                            'getId' => [1, $this->extItem1id, self::RETURN_REFERENCE],
                            'setId' => [
                                1,
                                function ($param) {
                                    $this->extItem1id = $param;
                                },
                                self::RETURN_CALLBACK
                            ],
                        ], false)
                    ]
                ], false)
            ]
        ], false);

        $quoteItem2 = $this->getInstanceMock(CartItemInterface::class, [], [
            'getId' => [1, $this->item2id],
            'getExtensionAttributes' => [
                1,
                $this->getInstanceMock(CartItemExtensionInterface::class, [], [
                    'getExtraInfo' => [
                        2,
                        $this->getInstanceMock(SalesQuoteItemInfoInterface::class, [], [
                            'getId' => [1, $this->extItem2id, self::RETURN_REFERENCE]
                        ], false)
                    ]
                ], false)
            ]
        ], false);

        $observer1 = $this->getInstanceMock(Observer::class, [], [
            'getEvent' => [
                1,
                $this->getInstanceMock(
                    Event::class, [], [
                        'getData' => [1, $quoteItem1, self::RETURN_REFERENCE, ['quote_item']]
                    ]
                ),
                self::RETURN_REFERENCE
            ]
        ]);
        $observer2 = $this->getInstanceMock(Observer::class, [], [
            'getEvent' => [
                1,
                $this->getInstanceMock(
                    Event::class, [], [
                        'getData' => [1, $quoteItem2, self::RETURN_REFERENCE, ['quote_item']]
                    ]
                ),
                self::RETURN_REFERENCE
            ]
        ]);

        $this->instance->execute($observer1);
        $this->instance->execute($observer2);

        $this->assertEquals($this->item1id, $this->extItem1id);
        $this->assertEquals($this->item2id, $this->extItem2id);
    }

    protected function setUp()
    {
        $this->instance = $this->getObject(CreateQuoteItemInfoAfterCartItemAdd::class, []);
    }
}
