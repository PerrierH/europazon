<?php

namespace Maas\Sales\Test\Unit\Observer\Order;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Sales\Observer\Order\ViewMarketplace;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\View\Layout\ProcessorInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\LayoutInterface;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Magento\Sales\Model\Order;
use Magento\Framework\Event;
use PHPUnit\Framework\TestCase;

class ViewMarketplaceTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $coreRegistry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributesService;
    /**
     * @var ViewMarketplace
     */
    private $stub;

    public function iniTest($nbCallsRegistry, $nbCallsExtension, $order = null, $orderType = null)
    {
        $salesOrderInfoInterface = AnyBuilder::createForClass($this, SalesOrderInfoInterface::class, [
            'getOrderType' => [$nbCallsExtension, $orderType]
        ])->build();
        $orderExtensionInterface = AnyBuilder::createForClass($this, OrderExtensionInterface::class, [
            'getExtraInfo' => [$nbCallsExtension, $salesOrderInfoInterface]
        ])->build();
        $this->coreRegistry = AnyBuilder::createForClass($this, Registry::class, [
            'registry' => [$nbCallsRegistry, $order]
        ])->build();
        $this->extensionAttributesService = AnyBuilder::createForClass($this, ExtensionAttributes::class, [
            'getOrderExtensionAttributes' => [$nbCallsExtension , $orderExtensionInterface]
        ])->build();
        $this->stub = new ViewMarketplace(
            $this->coreRegistry,
            $this->extensionAttributesService
        );
    }

    public function testActionDoesNotExist()
    {
        $this->iniTest($this->never(), $this->never());
        $event = AnyBuilder::createForClass($this, Event::class, [
            'getData' => [
                $this->any(),
                [['full_action_name', null, 'catalog_product_view'], ['layout', null, 'no layout']],
                AnyBuilder::RETURN_MAP
            ]
        ])->build();
        $observer = AnyBuilder::createForClass($this, Observer::class, [
            'getEvent' => [$this->any(), $event]
        ])->build();
        $this->stub->execute($observer);
    }

    /**
     * @dataProvider getActionList
     */
    public function testActionExistAndOrderDoesNotExist($actionList)
    {
        $this->iniTest($this->once(), $this->never());
        $event = AnyBuilder::createForClass($this, Event::class, [
            'getData' => [
                $this->any(),
                [['full_action_name', null, $actionList], ['layout', null, 'no layout']],
                AnyBuilder::RETURN_MAP
            ]
        ])->build();
        $observer = AnyBuilder::createForClass($this, Observer::class, [
            'getEvent' => [$this->any(), $event]
        ])->build();
        $this->stub->execute($observer);
    }


    /**
     * @dataProvider getActionList
     */
    public function testActionExistAndOrderExistWrongOrderType($actionList)
    {
        $this->iniTest($this->once(), $this->atLeastOnce(), $this->getMockOrder());
        $layout = AnyBuilder::createForClass($this, LayoutInterface::class, [
            'getUpdate' => [$this->never()]
        ])->build();
        $event = AnyBuilder::createForClass($this, Event::class, [
            'getData' => [
                $this->any(),
                [['full_action_name', null, $actionList], ['layout', null , $layout]],
                AnyBuilder::RETURN_MAP
            ]
        ])->build();
        $observer = AnyBuilder::createForClass($this, Observer::class, [
            'getEvent' => [$this->any(), $event]
        ])->build();
        $this->stub->execute($observer);
    }

    /**
     * @dataProvider getActionList
     */
    public function testActionExistAndOrderExistMaasOrderType($actionList)
    {
        $this->iniTest($this->once(), $this->atLeastOnce(), $this->getMockOrder(), 2);
        $processorInterface = AnyBuilder::createForClass($this, ProcessorInterface::class, [
            'addHandle' => [$this->once()]
        ])->build();
        $layout = AnyBuilder::createForClass($this, LayoutInterface::class, [
            'getUpdate' => [$this->once(), $processorInterface]
        ])->build();
        $event = AnyBuilder::createForClass($this, Event::class, [
            'getData' => [
                $this->any(),
                [['full_action_name', null, $actionList], ['layout', null , $layout]],
                AnyBuilder::RETURN_MAP
            ]
        ])->build();
        $observer = AnyBuilder::createForClass($this, Observer::class, [
            'getEvent' => [$this->any(), $event]
        ])->build();
        $this->stub->execute($observer);
    }

    private function getMockOrder()
    {
        return AnyBuilder::createForClass($this, Order::class)->build();
    }

    public function getActionList()
    {
        yield from [
            'sales_order_view' => ['sales_order_view'],
            'sales_order_print' => ['sales_order_print'],
            'sales_order_invoice' => ['sales_order_invoice'],
            'sales_order_printInvoice' => ['sales_order_printInvoice'],
            'sales_order_creditmemo' => ['sales_order_creditmemo'],
            'sales_order_printCreditmemo' => ['sales_order_printCreditmemo'],
        ];
    }
}
