<?php

namespace Maas\Sales\Test\Unit\Block\Checkout\Onepage;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Block\Checkout\Onepage\Success;
use Maas\Sales\Model\Session;
use Magento\Checkout\Model\Session as checkoutSession;
use Magento\Customer\Model\Context;
use Magento\Framework\App\Http\Context as httpContext;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Config;

class SuccessTest extends AbstractTestCase
{
    /**
     * @var Success
     */
    protected $success;

    /** @var Session */
    protected $maasSession;

    /** @var Order */
    protected $order;

    /** @var Order */
    protected $order2;

    public function testPrepareBlockDataMulti()
    {
        $this->maasSession->expects($this->once())
            ->method('hasMultipleOrders')
            ->willReturn(true);

        $incrementId = 'test01';
        $this->order->method('getIncrementId')
            ->willReturn($incrementId);

        $this->maasSession->expects($this->once())
            ->method('getOrders')
            ->willReturn([$this->order]);

        $this->success->setMaasSession($this->maasSession);

        $this->success->toHtml();

        $ordersData = $this->success->getData('orders_data');
        $hasMultipleOrders = $this->success->getData('hasMultipleOrders');

        $this->assertTrue($hasMultipleOrders);
        $this->assertEquals($incrementId, $ordersData[0]['order_id']);
    }

    public function testPrepareBlockDataSimple()
    {
        $this->maasSession->expects($this->once())
            ->method('hasMultipleOrders')
            ->willReturn(false);

        $this->success->setMaasSession($this->maasSession);

        $this->success->toHtml();

        $hasMultipleOrders = $this->success->getData('hasMultipleOrders');

        $this->assertFalse($hasMultipleOrders);
    }

    public function testGetOrdersIdList()
    {
        $this->maasSession->expects($this->once())
            ->method('hasMultipleOrders')
            ->willReturn(true);

        $incrementId = 'test';
        $this->order->method('getIncrementId')
            ->willReturn($incrementId . '01');

        $this->order2->method('getIncrementId')
            ->willReturn($incrementId . '02');
        $this->order2->method('getStatus')
            ->willReturn('test');

        $this->maasSession->expects($this->once())
            ->method('getOrders')
            ->willReturn([$this->order, $this->order2]);

        $this->success->setMaasSession($this->maasSession);

        $this->success->toHtml();

        $ordersData = $this->success->getOrdersIdList();

        $this->assertEquals('<span><a href=""><strong>' . $incrementId . '01</strong></a></span>, <span>' . $incrementId . '02</span>',
            $ordersData);
    }

    public function testHasMultipleOrdersTrue()
    {
        $this->maasSession->expects($this->once())
            ->method('hasMultipleOrders')
            ->willReturn(true);

        $this->success->setMaasSession($this->maasSession);
        $this->assertTrue($this->success->hasMultipleOrders());
    }

    public function testHasMultipleOrdersFalse()
    {
        $this->maasSession->expects($this->once())
            ->method('hasMultipleOrders')
            ->willReturn(false);

        $this->success->setMaasSession($this->maasSession);
        $this->assertFalse($this->success->hasMultipleOrders());
    }

    /**
     * Set up
     */
    protected function setUp()
    {
        $this->maasSession = $this->getMockBuilder(Session::class)
            ->setMethods(['hasMultipleOrders', 'getOrders'])
            ->disableOriginalConstructor()
            ->getMock();

        $this->order = $this->getMockBuilder(Order::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->order2 = $this->getMockBuilder(Order::class)
            ->disableOriginalConstructor()
            ->getMock();

        $config = $this->getMockBuilder(Config::class)
            ->setMethods(['getInvisibleOnFrontStatuses'])
            ->disableOriginalConstructor()
            ->getMock();
        $config->method('getInvisibleOnFrontStatuses')
            ->willReturn(['test']);

        $checkoutSession = $this->getMockBuilder(checkoutSession::class)
            ->setMethods(['getLastRealOrder'])
            ->disableOriginalConstructor()
            ->getMock();
        $checkoutSession->method('getLastRealOrder')
            ->willReturn($this->order);

        $httpContext = (new ObjectManager($this))->getObject(
            httpContext::class,
            [
                'data' => [
                    Context::CONTEXT_AUTH => true
                ]
            ]
        );

        $this->success = (new ObjectManager($this))->getObject(
            Success::class,
            [
                'orderConfig' => $config,
                'checkoutSession' => $checkoutSession,
                'httpContext' => $httpContext
            ]
        );
    }

}
