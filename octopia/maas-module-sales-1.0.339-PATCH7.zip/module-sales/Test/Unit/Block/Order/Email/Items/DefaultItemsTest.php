<?php

namespace Maas\Sales\Test\Unit\Block\Order\Email\Items;

use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Core\Model\Config;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\Service\OrderType;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\View\Element\Template\Context;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Maas\Sales\Block\Order\Email\Items\DefaultItems;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderItemExtensionInterface;
use Magento\Sales\Model\Order\Item;
use Magento\Sales\Model\Order\Invoice\Item as InvoiceItem;
use PHPUnit\Framework\TestCase;
use DateTime;

class DefaultItemsTest extends AbstractTestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $config;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productDeliveryService;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $timezone;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $orderTypeService;
    /**
     * @var DefaultItems
     */
    private $stub;

    public function initTest($order, $enableModule = false, $orderIsMarketplace = false, $stubMethodOptional = [])
    {
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->productRepository = AnyBuilder::createForClass($this, ProductRepositoryInterface::class)->build();
        $this->config = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->any(), $enableModule]
        ])->build();
        $this->productDeliveryService = AnyBuilder::createForClass($this, ProductDelivery::class, [
            'getDeliveryEstimatedDates' => [$this->any(), true]
        ])->build();
        $dateTime = AnyBuilder::createForClass($this, DateTime::class)->build();
        $this->timezone = AnyBuilder::createForClass($this, TimezoneInterface::class, [
            'date' => [$this->any(), $dateTime]
        ])->build();
        $this->orderTypeService = $this->getInstanceMock(OrderType::class, [], [
            'isOrderMarketplace' => [$this->any(), function(OrderInterface $order) use($enableModule, $orderIsMarketplace) {
                return $enableModule && $orderIsMarketplace;
            }, self::RETURN_CALLBACK]
        ]);
        $this->stub = AnyBuilder::createForClass($this, DefaultItems::class, [
            'getOrder' => [$this->atMost(2), $order]
        ])
            ->setConstructorArgs(
                [
                    $this->context,
                    $this->productRepository,
                    $this->config,
                    $this->productDeliveryService,
                    $this->timezone,
                    $this->orderTypeService,
                    []
                ]
            )->build();
    }

    /**
     * @dataProvider getDataCondition
     */
    public function testShouldDisplaySellerName($sellerId, $moduleEnable, $expectedValue)
    {
        $order =  AnyBuilder::createForClass($this, Order::class, [])->build();
        $this->initTest($order, $moduleEnable, $sellerId != null);
        $returnValueBool = $this->stub->isRenderSellerName();
        $this->assertEquals($returnValueBool, $expectedValue, 'should return a boolean');
    }

    public function getDataCondition()
    {
        yield from [
            'Module is disable and seller id exist' => [6, false, false],
            'Module is enable and seller id null' => [null, true, false],
            'Module is disable and seller id null' => [null, false, false],
            'Module is enable and seller id exist' => [6, true, true]
        ];
    }

    /**
     * @dataProvider getDeliveryDateCondition
     *
     * @param $item
     * @param $moduleEnable
     * @param $expectedValue
     */
    public function testIsRenderDeliveryDates($item, $moduleEnable, $expectedValue)
    {
        $this->initTest(null, $moduleEnable);
        $returnValueBool = $this->stub->isRenderDeliveryDates($item);
        $this->assertEquals($returnValueBool, $expectedValue, 'should return a boolean');
    }

    public function getDeliveryDateCondition()
    {
        yield from [
            'Module is disable, no min and max date' => [$this->getSalesOrderItem(), false, false],
            'Module is enable,  min date exist and no max date' => [$this->getSalesOrderItem('06/02/2021'), true, false],
            'Module is enable, no min date and  max date exist' => [$this->getSalesOrderItem(null, '06/02/2021'), true, false],
            'Module is enable, no min and max date' => [$this->getSalesOrderItem(), true, false],
            'Module is enable,  min and max date exist' => [$this->getSalesOrderItem('06/02/2021', '08/02/2021'), true, true],
        ];
    }

    private function getSalesOrderItem($minDate = null, $maxDate = null)
    {
        $maasSalesOrderItem = AnyBuilder::createForClass($this, SalesOrderItemInfoInterface::class, [
            'getDeliveryDateMin' => [$this->any(), $minDate],
            'getDeliveryDateMax' => [$this->any(), $maxDate],
        ])->build();
        $orderExtensionInterface =  AnyBuilder::createForClass($this, OrderItemExtensionInterface::class, [
            'getExtraInfo' => [$this->any(), $maasSalesOrderItem]
        ])->build();
        return AnyBuilder::createForClass($this, Item::class, [
            'getExtensionAttributes' => [$this->any(), $orderExtensionInterface]
        ])->build();
    }

    /**
     * @dataProvider getDeliveryDate
     *
     * @param $item
     * @param $moduleEnable
     * @param $expectedValue
     */
    public function testIsRenderDeliveryDatesOrderItem($item, $expectedValue)
    {
        $this->initTest(null, true);
        $returnValueBool = $this->stub->isRenderDeliveryDates($item);
        $this->assertEquals($returnValueBool, $expectedValue, 'should return a boolean');
    }

    public function getDeliveryDate()
    {
        yield from[
            'Max and min delivery date null' => [$this->getSalesOrderItem(), false],
            'Max delivery date null and  min delivery date exist' => [$this->getSalesOrderItem('06/02/2021'), false],
            'Min delivery date null and  max delivery date exist' => [$this->getSalesOrderItem(null, '06/02/2021'), false],
            'Min and  max delivery date exist' => [$this->getSalesOrderItem('06/02/2021', '16/02/2021'), true],
            'Min and  max delivery date exist for an invoice Item' => [$this->getSalesInvoiceOrderItem('06/02/2021', '16/02/2021'), true],
        ];
    }

    private function getSalesInvoiceOrderItem($minDate = null, $maxDate = null)
    {
        $orderItem = $this->getSalesOrderItem($minDate, $maxDate);
        return AnyBuilder::createForClass($this, InvoiceItem::class, [
            'getOrderItem' => [$this->any(), $orderItem]
        ])->build();
    }

    /**
     * @dataProvider getDate
     */
    public function testGetDeliveryDate($minDate, $maxDate, $expectedValue)
    {
        $this->initTest(null);
        $item = $this->getSalesOrderItem($minDate, $maxDate);
        $bool = $this->stub->getDeliveryDates($item);
        $this->assertEquals($bool, $expectedValue, 'Should retur a bool');
    }

    public function getDate()
    {
        yield from [
            'Min date does not exist and Max date exist' => [null, '29/03/2021', false],
            'Min date exist and Max date does not exist' => ['28/03/2021', null, false],
            'Min date does not exist and Max date does not exist' => [null, null, false],
            'Min date and Max date exist' => ['28/03/2021', '29/03/2021', true],
        ];
    }
}
