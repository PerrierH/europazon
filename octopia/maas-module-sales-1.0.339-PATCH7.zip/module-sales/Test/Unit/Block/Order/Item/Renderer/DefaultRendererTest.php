<?php

namespace Maas\Sales\Test\Unit\Block\Order\Item\Renderer;

use IntlDateFormatter;
use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Model\Service\OrderType;
use Magento\Catalog\Model\Product\OptionFactory;
use Magento\Framework\Stdlib\StringUtils;
use Magento\Framework\View\Element\Template\Context;
use Maas\Sales\Block\Order\Item\Renderer\DefaultRenderer;
use PHPUnit\Framework\TestCase;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Item;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderItemExtensionInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

class DefaultRendererTest extends AbstractTestCase
{
    /** @var DefaultRenderer */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $string;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productOptionFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $config;

    /** @var ProductDelivery */
    private $productDelivery;

    /** @var TimezoneInterface */
    private $timezone;

    private $sellerId;
    private $isModuleEnabled;
    private $deliveryDateMin;
    private $deliveryDateMax;

    public function setUp()
    {
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->string = AnyBuilder::createForClass($this, StringUtils::class)->build();
        $this->productOptionFactory = AnyBuilder::createForClass($this, OptionFactory::class)->build();
        $this->config = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [
                $this->any(),
                function () {
                    return $this->isModuleEnabled;
                },
                AnyBuilder::RETURN_CALLBACK
            ]
        ])->build();
        $this->productDelivery = AnyBuilder::createForClass($this, ProductDelivery::class)->build();
        $this->timezone = AnyBuilder::createForClass($this, TimezoneInterface::class,
            [
                'date' => [
                    $this->any(),
                    function ($date) {
                        $return = new \DateTime(null, new \DateTimeZone(date_default_timezone_get()));
                        $return->setTimestamp($date);
                        return $return;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $salesOrderInfoInterface = AnyBuilder::createForClass($this, SalesOrderInfoInterface::class, [
            'getSellerId' => [
                $this->any(),
                function () {
                    return $this->sellerId;
                },
                AnyBuilder::RETURN_CALLBACK
            ]
        ])->build();
        $orderExtensionInterface = AnyBuilder::createForClass($this, OrderExtensionInterface::class, [
            'getExtraInfo' => [$this->atMost(2), $salesOrderInfoInterface]
        ])->build();
        $order = AnyBuilder::createForClass($this, Order::class, [
            'getExtensionAttributes' => [$this->atMost(2), $orderExtensionInterface]
        ])->build();

        $salesOrderItemInfoInterface = AnyBuilder::createForClass($this, SalesOrderItemInfoInterface::class, [
            'getDeliveryDateMin' => [
                $this->any(),
                function () {
                    return $this->deliveryDateMin;
                },
                AnyBuilder::RETURN_CALLBACK
            ],
            'getDeliveryDateMax' => [
                $this->any(),
                function () {
                    return $this->deliveryDateMax;
                },
                AnyBuilder::RETURN_CALLBACK
            ],
        ])->build();
        $orderItemExtensionInterface = AnyBuilder::createForClass($this, OrderItemExtensionInterface::class, [
            'getExtraInfo' => [$this->any(), $salesOrderItemInfoInterface]
        ])->build();
        $item = AnyBuilder::createForClass($this, Item::class, [
            'getExtensionAttributes' => [$this->any(), $orderItemExtensionInterface]
        ])->build();
        $this->orderTypeService = $this->getInstanceMock(OrderType::class, [], [
            'isOrderMarketplace' => [$this->any(), function(Order $order){
                return $this->isModuleEnabled && $this->sellerId;
            }, self::RETURN_CALLBACK]
        ]);
        $this->stub = AnyBuilder::createForClass($this, DefaultRenderer::class, [
            'getOrder' => [$this->atMost(2), $order],
            'getItem' => [$this->any(), $item]
        ])
            ->setConstructorArgs(
                [
                    $this->context,
                    $this->string,
                    $this->productOptionFactory,
                    $this->config,
                    $this->productDelivery,
                    $this->timezone,
                    $this->orderTypeService,
                    []
                ]
            )->build();
    }

    /**
     * @dataProvider providerIsRenderSellerName
     *
     * @param $isModuleEnable
     * @param $sellerId
     */
    public function testIsRenderSellerName($isModuleEnable, $sellerId, $expected)
    {
        $this->isModuleEnabled = $isModuleEnable;
        $this->sellerId = $sellerId;

        $returnValue = $this->stub->isRenderSellerName();
        $this->assertEquals($expected, $returnValue);
    }

    public function providerIsRenderSellerName()
    {
        yield from [
            'Module is disabled seller id exists' => [false, 5, false],
            'Module is enabled seller id is empty' => [true, null, false],
            'Module is enabled seller id is exists' => [true, 5, true],
        ];
    }

    /**
     * @dataProvider providerIsRenderDeliveryDates
     *
     * @param $isModuleEnable
     * @param $sellerId
     */
    public function testIsRenderDeliveryDates($isModuleEnable, $deliveryDateMin, $deliveryDateMax, $expected)
    {
        $this->isModuleEnabled = $isModuleEnable;
        $this->deliveryDateMin = $deliveryDateMin;
        $this->deliveryDateMax = $deliveryDateMax;

        $returnValue = $this->stub->isRenderDeliveryDates();
        $this->assertEquals($expected, $returnValue);
    }

    public function providerIsRenderDeliveryDates()
    {
        yield from [
            'Module is disabled, deliveryDateMin exists, deliveryDateMax exists' => [
                false,
                '2021-03-01 00:00:00',
                '2021-03-07 00:00:00',
                false
            ],
            'Module is enabled, deliveryDateMin exists, no deliveryDateMax' => [
                true,
                '2021-03-01 00:00:00',
                null,
                false
            ],
            'Module is enabled, no deliveryDateMin, deliveryDateMax exists' => [
                true,
                null,
                '2021-03-07 00:00:00',
                false
            ],
            'Module is enabled, deliveryDateMin exists, deliveryDateMax exists' => [
                true,
                '2021-03-01 00:00:00',
                '2021-03-07 00:00:00',
                true
            ]
        ];
    }

    /**
     * @dataProvider providerGetDeliveryDates
     * TODO 1671 : re-activate test
    public function testGetDeliveryDates($dateMin, $dateMax, $expected)
    {
        $this->deliveryDateMin = $dateMin;
        $this->deliveryDateMax = $dateMax;

        if ($expected) {
            $minDate = $this->timezone->date(strtotime($dateMin));
            $maxDate = $this->timezone->date(strtotime($dateMax));

            $expected = sprintf(
                __("%5\$sDelivery between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                __(date('l', $minDate->getTimestamp())),
                $this->timezone->formatDate($minDate, IntlDateFormatter::LONG, false),
                __(date('l', $maxDate->getTimestamp())),
                $this->timezone->formatDate($maxDate, IntlDateFormatter::LONG, false),
                ''
            );
        }

        $this->assertEquals($expected, $this->stub->getDeliveryDates());
    }
    */

    public function providerGetDeliveryDates()
    {

        $dateMin = '2021-03-01 00:00:00';
        $dateMax = '2021-03-07 00:00:00';

        yield from [
            'deliveryDateMin exists no deliveryDateMax' => ['2021-03-01 00:00:00', null, false],
            'no deliveryDateMin exists deliveryDateMax exists' => [null, '2021-03-01 00:00:00', false],
            'deliveryDateMin and DeliveryDateMax exists' => [$dateMin, $dateMax, true],
        ];
    }
}
