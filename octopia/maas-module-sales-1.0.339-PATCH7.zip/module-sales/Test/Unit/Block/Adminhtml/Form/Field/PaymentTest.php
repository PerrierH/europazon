<?php

namespace Maas\Sales\Test\Unit\Block\Adminhtml\Form\Field;

use Exception;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Block\Adminhtml\Form\Field\Payment;
use Maas\Sales\Block\Adminhtml\Form\Field\StatusColumn;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\LayoutInterface;
use Magento\Payment\Api\Data\PaymentMethodInterface;
use Magento\Payment\Api\PaymentMethodListInterface;
use PHPUnit\Framework\MockObject\MockObject;

/**
 * Class PaymentTest
 *
 * @package Maas\Sales\Test\Unit\Block\Adminhtml\Form\Field
 */
class PaymentTest extends AbstractTestCase
{
    /**
     * @var MockObject
     */
    private $context;
    /**
     * @var MockObject
     */
    private $paymentMethodList;
    /**
     * @var Payment
     */
    private $sut;
    /**
     * @var MockObject
     */
    private $scopeConfigMock;
    /**
     * @var array
     */
    private $paymentMethod;
    /**
     * @var MockObject
     */
    private $layout;
    /**
     * @var MockObject
     */
    private $statusColumn;

    /**
     *
     * @throws LocalizedException
     */

    public function testGetRowDataObjectWithNoConfigValues()
    {
        $paymentMethodsNumber = 5;
        $count = 0;
        $this->initTest($paymentMethodsNumber);

        $rows = $this->sut->getArrayRows();

        $this->assertEquals($paymentMethodsNumber, count($rows));
        foreach ($rows as $row) {
            $this->assertArrayHasKey('payment_methods', $row);
            $this->assertArrayHasKey('status', $row);
            $this->assertArrayHasKey('payment_code', $row);
            $this->assertArrayHasKey('column_values', $row);
            $this->assertArrayHasKey('_id', $row);
            $this->assertEquals('processing', $row['status']);
            $this->assertEquals('Payment title' . $count, $row['payment_methods']);
            $this->assertEquals('payment_code_' . $count, $row['payment_code']);
            $count++;
        }
    }

    /**
     * @param $paymentMethodsNumber
     */
    public function initTest($paymentMethodsNumber)
    {
        for ($i = 0; $i < $paymentMethodsNumber; $i++) {
            $paymentMethod = $this->getPaymentMethodMock();
            $paymentMethod
                ->expects($this->atMost($paymentMethodsNumber))
                ->method('getCode')
                ->willReturn('payment_code_' . $i);
            $paymentMethod
                ->expects($this->atMost(2))
                ->method('getTitle')
                ->willReturn('Payment title' . $i);
            $this->paymentMethod[] = $paymentMethod;
        }
        $paymentMethod = $this->getPaymentMethodMock();
        $paymentMethod
            ->expects($this->never())
            ->method('getCode')
            ->willReturn('payment_code_');
        $paymentMethod
            ->expects($this->once())
            ->method('getTitle')
            ->willReturn(null);
        $this->paymentMethod[] = $paymentMethod;
        $this->paymentMethodList
            ->expects($this->once())
            ->method('getList')
            ->with(0)
            ->willReturn($this->paymentMethod);
    }

    /**
     * @return MockObject
     */
    private function getPaymentMethodMock()
    {
        return $this->createMock(PaymentMethodInterface::class);
    }

    /**
     *
     * @throws LocalizedException
     */

    public function testGetRowDataObjectWithConfigValues()
    {

        $coreConfigDataArray = [];
        $paymentMethodsNumber = 6;
        $count = 0;
        for ($i = 0; $i < $paymentMethodsNumber; $i++) {
            $coreConfigDataArray["1597159339_" . $i] = [
                "payment_code" => "payment_code_" . $i,
                "status" => ($i % 2 == 0) ? "processing" : "cancelled"
            ];
        }
        $coreConfigDataArray["1597159339_0"]['random_ignored_field'] = 1;

        $coreConfigDataJson = json_encode($coreConfigDataArray);
        $this->scopeConfigMock
            ->expects($this->once())
            ->method('getValue')
            ->willReturn($coreConfigDataJson);
        $this->initTest($paymentMethodsNumber);
        $rows = $this->sut->getArrayRows();
        $this->assertEquals($paymentMethodsNumber, count($rows));
        foreach ($rows as $row) {
            $this->assertArrayHasKey('payment_methods', $row);
            $this->assertArrayHasKey('status', $row);
            $this->assertArrayHasKey('payment_code', $row);
            $this->assertArrayHasKey('column_values', $row);
            $this->assertArrayHasKey('_id', $row);
            $this->assertEquals(($count % 2 == 0) ? "processing" : "cancelled", $row['status']);
            $this->assertEquals('Payment title' . $count, $row['payment_methods']);
            $this->assertEquals('payment_code_' . $count, $row['payment_code']);
            $count++;
        }
    }

    /**
     * @throws LocalizedException
     */
    public function testGetRowDataObjectWithArrayRowsCache()
    {
        $paymentMethodsNumber = 5;
        $this->initTest($paymentMethodsNumber);

        $this->sut->getArrayRows();
        $this->sut->getArrayRows();
        $this->scopeConfigMock
            ->expects($this->never())
            ->method('getValue');
    }

    /**
     * @dataProvider columnsValueAndResult
     *
     * @param $columnValue
     * @param $result
     *
     * @throws Exception
     */
    public function testRenderInputWithColumnName($columnValue, $result)
    {
        $element = $this->createMock(AbstractElement::class);
        $this->sut->setElement($element);
        $this->sut->addColumn($columnValue, []);
        $inputValue = $this->sut->renderCellTemplate($columnValue);
        $this->assertEquals($result, $inputValue);
    }

    /**
     * @throws Exception
     */
    public function testRenderInputWithoutColumnNamePaymentMethod()
    {
        $this->expectException(Exception::class);
        $this->expectExceptionMessage('Wrong column name specified.');
        $this->sut->renderCellTemplate('');
    }

    public function testGetCellInputElementName()
    {
        $this->sut->setElement(new DataObject(['name' => 'test_name']));

        $name1 = $this->invokeMethod($this->sut, '_getCellInputElementName', ['random_name']);
        $name2 = $this->invokeMethod($this->sut, '_getCellInputElementName',
            [Payment::COLUMN_CODE_STATUS]);
        $this->assertnotFalse(preg_match('/^.*\\[random_name\\]$/', $name1));
        $this->assertnotFalse(preg_match('/^.*\\['.Payment::COLUMN_CODE_STATUS.'\\]$/', $name2));
    }


    /**
     * @return string[][]
     */
    public function columnsValueAndResult()
    {
        return [
            'column value code is payment_methods' => [
                'columnValue' => 'payment_methods',
                'result' => '<%- payment_methods %>'
            ],
            'column value code is payment_code' => [
                'columnValue' => 'payment_code',
                'result' => '<input type="hidden" id="<%- _id %>_payment_code"' .
                    ' name="[<%- _id %>][payment_code]" value="<%- payment_code %>"  class="input-text" readonly/>'
            ],
        ];
    }

    /**
     * Set up
     */
    protected function setUp()
    {
        $data = [];
        $helper = new ObjectManager($this);
        $this->context = $this->createMock(Context::class);
        $this->layout = $this->createMock(LayoutInterface::class);
        $this->statusColumn = $this->createMock(StatusColumn::class);

        $this->context->expects($this->any())
            ->method('getLayout')
            ->willReturn($this->layout);
        $this->layout->expects($this->any())
            ->method('createBlock')
            ->willReturn($this->statusColumn);
        $this->paymentMethodList = $this->createMock(PaymentMethodListInterface::class);
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);

        $serializer = $helper->getObject(Json::class);

        $this->sut = $helper->getObject(
            Payment::class,
            [
                'context' => $this->context,
                'paymentMethodList' => $this->paymentMethodList,
                'data' => $data,
                '_scopeConfig' => $this->scopeConfigMock,
                'serializer' => $serializer
            ]
        );
    }
}
