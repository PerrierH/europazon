<?php

namespace Maas\Sales\Test\Unit\Block\Adminhtml\Order\View;

use PHPUnit\Framework\TestCase;
use Maas\Core\Model\Config;
use Magento\Backend\Block\Template\Context;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Registry;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Sales\Block\Adminhtml\Order\View\Items;
use Magento\Sales\Model\Order\Item;
use Maas\Core\Test\Builder\Order\OrderBuilder;

class ItemsTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockRegistry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockConfiguration;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $registry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var Items
     */
    private $stub;

    public function initTest($dataFromTest, $isEnable = false, $isMaasSeller = null)
    {
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->stockRegistry = AnyBuilder::createForClass($this, StockRegistryInterface::class)->build();
        $this->stockConfiguration = AnyBuilder::createForClass($this, StockConfigurationInterface::class)->build();
        $this->registry = AnyBuilder::createForClass($this, Registry::class)->build();
        $this->configModel = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->any(), $isEnable, AnyBuilder::RETURN_VALUE],
        ])->build();
        $order = OrderBuilder::create($this, [])->withSalesOrderInfo([
            'getSellerId' => [$this->any(), $isMaasSeller, AnyBuilder::RETURN_VALUE]
        ])->build();
        $item = AnyBuilder::createForClass($this, Item::class, [
            'getOrder' => [$this->any(), $order, AnyBuilder::RETURN_VALUE]
        ])->build();
        $data = [
            'item' => $item
        ];
        $data = array_merge($data, $dataFromTest);
        $this->stub = new Items(
            $this->context,
            $this->stockRegistry,
            $this->stockConfiguration,
            $this->registry,
            $this->configModel,
            $data
        );
    }

    /**
     * @dataProvider getColumns
     *
     * @param $columnDatas
     * @param $isEnable
     * @param $isMaasSeller
     *
     * @throws LocalizedException
     */
    public function testWithNoColumnKeyOfferIdOrSellerId($columnDatas, $isEnable, $isMaasSeller)
    {
        $returnValue = [
            'maas_offer_id' => [],
            'maas_seller_id' => [],
            'maas_seller_name' => [],
            'maas_shipping_method' => [],
            'maas_original_taxes' => []
        ];
        $this->initTest($columnDatas, $isEnable, $isMaasSeller);
        $columns = $this->stub->getColumns();
        $this->assertEquals($isEnable ? $returnValue : [], $columns, 'should an array');
    }

    public function testWithColumnKeyOfferIdOrSellerId()
    {
        $data = [
            'columns' => ['maas_offer_id' => [], 'maas_seller_id' => [], 'maas_seller_name' => [], 'maas_shipping_method' => [], 'maas_original_taxes' => []]
        ];
        $this->initTest($data);
        $columns = $this->stub->getColumns();
        $this->assertEquals(['maas_seller_id' => []], $columns, 'should empty array');
    }

    public function getColumns()
    {
        yield from [
            'maas_offer_id and and maas_seller_id is not initialised' => [
                [
                    'columns' => []
                ],
                false,
                null
            ],
            'Module is enable and have seller id' => [
                [
                    'columns' => [
                        'maas_offer_id' => [],
                        'maas_seller_id' => [],
                        'maas_seller_name' => [],
                        'maas_shipping_method' => [],
                        'maas_original_taxes' => []
                    ]
                ]
                ,
                true,
                5
            ]
        ];
    }
}
