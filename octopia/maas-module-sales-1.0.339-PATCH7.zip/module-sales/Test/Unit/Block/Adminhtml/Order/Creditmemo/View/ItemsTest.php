<?php

namespace Maas\Sales\Test\Unit\Block\Adminhtml\Order\Creditmemo\View;

use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Magento\Backend\Block\Template\Context;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Registry;
use Maas\Sales\Block\Adminhtml\Order\Creditmemo\View\Items;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use PHPUnit\Framework\TestCase;


class ItemsTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockRegistry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockConfiguration;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $registry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var Items
     */
    private $stub;

    public function initTest($order, $isModuleEnable = false){
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->stockRegistry = AnyBuilder::createForClass($this, StockRegistryInterface::class)->build();
        $this->stockConfiguration = AnyBuilder::createForClass($this, StockConfigurationInterface::class)->build();
        $this->registry = AnyBuilder::createForClass($this, Registry::class)->build();
        $this->configModel = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->once(), $isModuleEnable]
        ])->build();
        $this->stub =  AnyBuilder::createForClass($this, Items::class, [
                'getOrder' => [$this->once(), $order]
        ])
            ->setConstructorArgs([
                $this->context,
                $this->stockRegistry,
                $this->stockConfiguration,
                $this->registry,
                $this->configModel,
                []
            ])
            ->build();
    }


    /**
     * @dataProvider getCondition
     * @return bool
     */
    public function testShowShippingMethod($order, $isModuleEnable, $expected)
    {
        $this->initTest($order, $isModuleEnable);
        $returnBool = $this->stub->getHead();
        $this->assertEquals($returnBool, $expected, 'Should return a boolean');
    }

    public function getCondition()
    {
        yield from[
          'Module disable and seller id exist' => [$this->getOrderBulider(8), false, false],
          'Module enable and seller id does not exist' => [$this->getOrderBulider(null), true, false],
          'Module enable and seller id exist' => [$this->getOrderBulider(8), true, true],
     ];
    }

    private function getOrderBulider($sellerId = null){
        $salesOrderInfoInterface = AnyBuilder::createForClass($this, SalesOrderInfoInterface::class, [
            'getSellerId' => [$this->once(), $sellerId]
        ])->build();
        $orderExtensionInterface = AnyBuilder::createForClass($this, OrderExtensionInterface::class, [
            'getExtraInfo' => [$this->once(), $salesOrderInfoInterface]
        ])->build();
        return AnyBuilder::createForClass($this, Order::class, [
            'getExtensionAttributes' => [$this->once(), $orderExtensionInterface]
        ])->build();
    }
}
