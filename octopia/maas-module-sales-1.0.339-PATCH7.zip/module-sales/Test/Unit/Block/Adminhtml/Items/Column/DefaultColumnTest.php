<?php

namespace Maas\Sales\Test\Unit\Block\Adminhtml\Items\Column;

use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Magento\Backend\Block\Template\Context;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\Framework\Registry;
use Magento\Catalog\Model\Product\OptionFactory;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Order\OrderItemBuilder;
use Maas\Sales\Block\Adminhtml\Items\Column\DefaultColumn;
use Magento\Sales\Api\Data\OrderItemExtensionInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;

class DefaultColumnTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockRegistry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockConfiguration;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $registry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $optionFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var DefaultColumn
     */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $item;

    public function initTest($item, $isMaasModuleEnable = false)
    {
        $helper = new ObjectManager($this);
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->stockRegistry = AnyBuilder::createForClass($this, StockRegistryInterface::class)->build();
        $this->stockConfiguration = AnyBuilder::createForClass($this, StockConfigurationInterface::class)->build();
        $this->registry = AnyBuilder::createForClass($this, Registry::class)->build();
        $this->optionFactory = AnyBuilder::createForClass($this, OptionFactory::class)->build();

        $this->configModel = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->any(), $isMaasModuleEnable, AnyBuilder::RETURN_VALUE]
        ])->build();
        $itemFromExtend = OrderItemBuilder::create($this, [
            'getOrderItem' => [
                $this->any(),
                $item ?: null,
                OrderItemBuilder::RETURN_VALUE
            ]
        ])->build();

        $this->stub = $helper->getObject(
            DefaultColumn::class,
            [
                'context' => $this->context,
                'stockRegistry' => $this->stockRegistry,
                'stockConfiguration' => $this->stockConfiguration,
                'registry' => $this->registry,
                'optionFactory' => $this->optionFactory,
                'configModel' => $this->configModel,
                '_data' => ['item' => $itemFromExtend]
            ]
        );
    }

    /**
     * @dataProvider itemOrMaasEnable
     */
    public function testIsNotItemOrMaasNotEnable($item, $moduleIsEnable)
    {
        $this->initTest($item, $moduleIsEnable);
        $returnValue = $this->stub->getOfferId();
        $this->assertEquals('', $returnValue, 'should return empty');
    }

    public function testIsItemAndMaasEnable()
    {
        $item = $this->createMockItem($this->once());
        $this->initTest($item, true);
        $returnValue = $this->stub->getOfferId();
        $this->assertEquals(2, $returnValue, 'should return the id of the offer');
    }


    public function testIsNoOrderAndMaasNotEnable()
    {
        $item = $this->createMockItem($this->any());
        $this->initTest($item, false);
        $returnValue = $this->stub->getSellerName();
        $this->assertEquals('', $returnValue, 'should retun empty');
    }

    public function testIsOrderAndMaasEnable()
    {
        $item = $this->createMockItem($this->any());
        $this->initTest($item, true);
        $returnValue = $this->stub->getSellerName();
        $this->assertEquals('Cdiscount', $returnValue, 'should seller name');
    }

    private function createMockItem($nbTimes, $shippingMethod = null)
    {
        $extraInfo = AnyBuilder::createForClass($this, SalesOrderItemInfoInterface::class, [
            'getOfferMaasId' => [$this->any(), 2, AnyBuilder::RETURN_VALUE],
            'getShippingMethod' => [$this->any(), $shippingMethod, AnyBuilder::RETURN_VALUE],
        ])->build();
        $extensionAttributes = AnyBuilder::createForClass($this, OrderItemExtensionInterface::class, [
            'getExtraInfo' => [$this->any(), $extraInfo, AnyBuilder::RETURN_VALUE]
        ])->build();
        return OrderItemBuilder::create($this, [
            'getExtensionAttributes' => [$nbTimes, $extensionAttributes, OrderItemBuilder::RETURN_VALUE],
            'getOrder' => [
                $this->any(),
                OrderBuilder::create($this)->withSalesOrderInfo([
                    'getSellerName' => [
                        $this->any(),
                        'Cdiscount'
                    ]
                ])->build()
            ]
        ])->build();
    }

    public function itemOrMaasEnable()
    {
        yield from [
            'Module is disable' => [$this->createMockItem($this->never()), false],
            'No item ' => ['', true],
            'No item and module is disable' => ['', false]
        ];
    }

    /**
     * @dataProvider getConditionShipping
     */
    public function testShouldRenderShippingMethod($isModuleEnable, $item, $expected)
    {
        $this->initTest($item, $isModuleEnable);
        $shippingMethod = $this->stub->getShippingMethod();
        $this->assertEquals($shippingMethod, $expected, 'Should return a shipping method or empty string');
    }

    public function getConditionShipping()
    {
        yield from [
            'module disable and item exist' => [false,  $this->createMockItem($this->any()), ''],
            'module enable and item does not exist' => [true, null, ''],
            'module enable and item  exist' => [true, $this->createMockItem($this->any(), 'Maas shipping method'), 'Maas shipping method'],
        ];
    }
}
