<?php

namespace  Maas\Sales\Test\Unit\Block\Adminhtml\Items\Renderer;

use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Sales\Model\Order;
use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Registry;
use Magento\Sales\Model\Order\Shipment\Item;
use Maas\Sales\Block\Adminhtml\Items\Renderer\DefaultRenderer;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use PHPUnit\Framework\TestCase;

class DefaultRendererTest extends TestCase
{


    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockRegistry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stockConfiguration;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $registry;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $stub;


    public function initTest($item, $order, $sellerId = null, $isModuleEnabled = false)
    {
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->stockRegistry = AnyBuilder::createForClass($this, StockRegistryInterface::class)->build();
        $this->stockConfiguration = AnyBuilder::createForClass($this, StockConfigurationInterface::class)->build();
        $this->registry = AnyBuilder::createForClass($this, Registry::class)->build();
        $this->configModel = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' =>  [$this->any(), $isModuleEnabled]
        ])->build();
        $product = AnyBuilder::createForClass($this, ProductInterface::class, [
            'getMaasOfferSellerId' => [$this->any(), $sellerId]
        ])->build();
        $this->productRepository = AnyBuilder::createForClass($this, ProductRepositoryInterface::class, [
            'get' => [$this->any(), $product]
        ])->build();
        $this->stub = AnyBuilder::createForClass($this, DefaultRenderer::class, [
            'getItem' => [$this->any(), $item],
            'getOrder' => [$this->any(), $order]
        ])
            ->setConstructorArgs([
                $this->context,
                $this->stockRegistry,
                $this->stockConfiguration,
                $this->registry,
                $this->configModel,
                $this->productRepository,
                []
            ])->build();
    }

    /**
     * @dataProvider getConditions
     */
    public function testShouldRenderShippingMethodColumn($order, $item , $sellerId, $isModuleEnable, $expected)
    {
        $this->initTest($item, $order, $sellerId, $isModuleEnable);
        $returnBoolValue = $this->stub->getHead();
        $this->assertEquals($returnBoolValue, $expected, 'Should return a boolean');
    }

    public function getConditions()
    {
        yield from [
            'item is not shipping item, no sellerId, module disable' => [$this->creatMockOrder(null), null,null, false, false],
            'item is not shipping item, no sellerId , module enable' => [$this->creatMockOrder(null), null,null, true, false],
            'item is not shipping item, sellerId exist, module enable' => [$this->creatMockOrder(10), null, 10, true, true],
            'item is not shipping item, sellerId exist, module disable' => [$this->creatMockOrder(10), null, 10, false, false],
            'item is shipping item, no sellerId, module disable' => [null, $this->createMockShippingItem(),null, false, false],
            'item is shipping item, no sellerId, module enable' => [null,$this->createMockShippingItem(),null, true, false],
            'item is shipping item, sellerId exist, module enable' => [null,$this->createMockShippingItem(),10, true, true],
            'item is shipping item, sellerId exist, module disable' => [null,$this->createMockShippingItem(),10, false, false],
        ];
    }

    private function createMockShippingItem()
    {
        return AnyBuilder::createForClass($this, Item::class, [
            'getSku' => [$this->any(), 'my sku']
        ])->build();
    }

    private function creatMockOrder($sellerId)
    {
        $salesOrderInfoInterface = AnyBuilder::createForClass($this, SalesOrderInfoInterface::class, [
         'getSellerId' => [$this->any(), $sellerId]
        ])
         ->build();
        $orderExtensionInterface = AnyBuilder::createForClass($this, OrderExtensionInterface::class, [
            'getExtraInfo' => [$this->any(), $salesOrderInfoInterface]
        ])
            ->build();
        return AnyBuilder::createForClass($this, Order::class, [
            'getExtensionAttributes' => [$this->any(), $orderExtensionInterface]
        ])
            ->build();
    }
}
