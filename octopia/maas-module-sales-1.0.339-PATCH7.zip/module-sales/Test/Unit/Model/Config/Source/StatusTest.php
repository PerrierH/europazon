<?php

namespace Maas\Sales\Test\Unit\Model\Config\Source;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\Config\Source\Status;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit_Framework_MockObject_MockObject;
use Magento\Sales\Model\ResourceModel\Order\Status\CollectionFactory;
use Magento\Sales\Model\ResourceModel\Order\Status\Collection;
use Maas\Core\Test\Builder\AnyBuilder;

/**
 * Class StatusTest
 *
 * @package Maas\Sales\Test\Unit\Model\Config\Source
 */
class StatusTest extends AbstractTestCase
{
    /** @var \Magento\Sales\Model\Config\Source\Order\Status */
    protected $object;

    /** @var ObjectManager */
    protected $objectManager;

    /** @var Status|PHPUnit_Framework_MockObject_MockObject */
    protected $config;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionfactory;

    /**
     * setup function
     */
    protected function initTest($optionArray)
    {
        $collection = AnyBuilder::createForClass($this,Collection::class, [
            'toOptionArray' => [$this->any(), $optionArray ,AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->collectionfactory = AnyBuilder::createForClass($this,CollectionFactory::class, [
            'create' => [$this->any(),$collection ,AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->config = new Status(
            $this->collectionfactory
        );
    }

    /**
     * test of toOptionArray method of all status
     */
    public function testToOptionArrayWithValues()
    {
        $optionArray = [
            ['value' => '', 'label' => '-- Please Select --'],
            ['value' => 0, 'label' => 'status1'],
            ['value' => 1, 'label' => 'status2']
        ];
        $this->initTest($optionArray);
        $optionReturned = $this->config->toOptionArray();
        $this->assertEquals($optionArray, $optionReturned, 'should returned option');
    }

    /**
     * test of toOptionArray method of all status
     */
    public function testToOptionArrayWithNoValues()
    {
        $optionArray = [
        ];
        $this->initTest($optionArray);
        $optionReturned = $this->config->toOptionArray();
        $this->assertEquals([['value' => '', 'label' => '']], $optionReturned, 'should not returned option');
    }
}
