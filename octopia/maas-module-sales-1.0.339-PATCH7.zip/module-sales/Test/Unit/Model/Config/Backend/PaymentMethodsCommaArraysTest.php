<?php

namespace Maas\Sales\Test\Unit\Model\Config\Backend;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\Config\Backend\PaymentMethodsCommaArrays;
use Magento\Framework\DataObject;

/**
 * Class PaymentMethodsCommaArraysTest
 *
 * @package Maas\Sales\Test\Unit\Model\Config\Backend
 */
class PaymentMethodsCommaArraysTest extends AbstractTestCase
{
    protected $instance;

    public function testBeforeSave()
    {
        $instance = $this->getObject(\Maas\Sales\Model\Config\Backend\PaymentMethodsCommaArrays::class);

        $instance->setValue(['test1' => ['payment_code' => 'test_mode_1', 'status' => ['status1', 'status2', 'status3']]]);
        $this->invokeMethod($instance, 'flattenStatusValues', []);

        $this->assertEquals(['test1' => ['payment_code' => 'test_mode_1', 'status' => 'status1,status2,status3']], $instance->getValue());
    }
}