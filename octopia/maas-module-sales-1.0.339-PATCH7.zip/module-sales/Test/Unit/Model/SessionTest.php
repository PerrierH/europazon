<?php

namespace Maas\Sales\Test\Unit\Model;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\Session;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Session\Storage;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderRepository;

/**
 * Class SessionTest
 * @package Maas\Sales\Test\Unit\Model
 */
class SessionTest extends AbstractTestCase
{

    /** @var Session */
    protected $session;

    /** @var Storage */
    protected $storage;

    /** @var OrderRepository */
    protected $orderRepository;

    /**
     * @return void
     */
    public function testAddOrder()
    {
        $this->session->addOrder(12);
        $nbOrders = count($this->storage->getData('orders'));
        $this->assertEquals(1, $nbOrders);

        $this->session->addOrder(20);
        $nbOrders = count($this->storage->getData('orders'));
        $this->assertEquals(2, $nbOrders);

        $this->session->addOrder(12);
        $nbOrders = count($this->storage->getData('orders'));
        $this->assertEquals(2, $nbOrders);
    }

    /**
     * @return void
     */
    public function testHasMultipleOrders()
    {
        $data = [];
        $this->storage->setData('orders', $data);

        $this->assertFalse($this->session->hasMultipleOrders());

        $data = [12, 20, 23];
        $this->storage->setData('orders', $data);

        $this->assertTrue($this->session->hasMultipleOrders());
    }

    /**
     * @return void
     */
    public function testGetOrders()
    {
        $data = [12, 20, 23];
        $this->storage->setData('orders', $data);

        $orders = $this->session->getOrders();

        $this->assertEquals(count($data), count($orders));
    }

    /**
     * @return void
     */
    public function testSetOrders()
    {
        $data = [12, 20, 23];
        $this->storage->setData('orders', $data);

        $orders = $this->session->getOrders();

        $this->assertEquals(count($data), count($orders));
    }

    /**
     * @return void
     */
    public function testClearOrders()
    {
        $data = [12, 20, 23];
        $this->storage->setData('orders', $data);

        $this->session->clearOrders();
        $orders = $this->session->getOrders();

        $this->assertEquals(0, count($orders));
    }

    /**
     * Set up
     */
    protected function setUp(): void
    {
        $this->storage = (new ObjectManager($this))->getObject(
            Storage::class
        );

        $order = $this->getMockBuilder(Order::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->orderRepository = $this->getMockBuilder(OrderRepository::class)
            ->setMethods(['get'])
            ->disableOriginalConstructor()
            ->getMock();
        $this->orderRepository->method('get')
            ->willReturn($order);

        $this->session = (new ObjectManager($this))->getObject(
            Session::class,
            [
                'storage' => $this->storage,
                'orderRepository' => $this->orderRepository
            ]
        );
    }

    /**
     * @return void
     */
    public function testSetFirstOrderId()
    {
        $this->session->setFirstOrderId(42);

        $this->assertEquals(42, $this->storage->getData('firstOrderId'));
    }

    /**
     * @return void
     */
    public function testGetFirstOrderId()
    {
        $this->storage->setData('firstOrderId', 42);

        $this->assertEquals(42, $this->session->getFirstOrderId());
    }

    /**
     * @return void
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function testGetFirstOrder()
    {
        $order = $this->session->getFirstOrder();
        $this->assertNotNull($order);
    }

    /**
     * @return void
     */
    public function testUnsOriginalCartId()
    {
        $originalCartId = 100;
        $originalCartItems = [1, 15, 17, 8];
        $this->storage->setData('original_cart_id', $originalCartId);
        $this->storage->setData('original_cart_items', $originalCartItems);
        $this->session->unsOriginalCartId();
        $this->assertNull($this->storage->getData('original_cart_id'));
        $this->assertNull($this->storage->getData('original_cart_items'));
    }

    /**
     * @return void
     */
    public function testHasOriginalCartId()
    {
        $originalCartId = 100;
        $this->storage->setData('original_cart_id', $originalCartId);
        $this->assertTrue($this->session->hasOriginalCartId());
    }

    /**
     * @return void
     */
    public function testGetOriginalCartId()
    {
        $originalCartId = 100;
        $this->storage->setData('original_cart_id', $originalCartId);
        $this->assertEquals($originalCartId, $this->session->getOriginalCartId());
    }

    /**
     * @return void
     */
    public function testSetOriginalCartId()
    {
        $originalCartId = 100;
        $this->session->setOriginalCartId($originalCartId);
        $this->assertEquals($originalCartId, $this->storage->getData('original_cart_id'));
    }
}
