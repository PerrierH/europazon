<?php

namespace Maas\Sales\Test\Unit\Model;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Api\SalesOrderInfoRepositoryInterface;
use Maas\Sales\Api\SalesOrderItemInfoRepositoryInterface;
use Maas\Sales\Model\RegisterOfferAndSellerDuringOrderProcess;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Sales\Observer\OrderAdditionalOptions;
use Maas\Seller\Api\Data\SellerInterface;
use Maas\Seller\Api\SellerRepositoryInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Sales\Api\Data\OrderExtension;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderItemExtension;
use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Sales\Model\Order\Item;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use ReflectionClass;

/**
 * Class RegisterOfferAndSellerDuringOrderProcessTest
 *
 * @package Maas\Sales\Test\Unit\Model
 */
class RegisterOfferAndSellerDuringOrderProcessTest extends AbstractTestCase
{

    const SELLER_ID = 1;
    const SELLER_MAAS_ENTITY_ID = 86910;
    const SELLER_NAME = '1001Pneus';
    const ORDER_ID = 1;
    const OFFER_MAAS_ENTITY_ID_1 = 1337202;
    const OFFER_MAAS_ENTITY_ID_2 = 226445051;

    /**
     * @var MockObject
     */
    private $salesOrderInfoRepository;
    /**
     * @var MockObject
     */
    private $salesOrderItemInfoRepository;
    /**
     * @var MockObject
     */
    private $sellerRepository;
    /**
     * @var MockObject
     */
    private $offerRepository;
    /**
     * @var OrderAdditionalOptions
     */
    private $sut;
    /**
     * @var object
     */
    private $order;
    /**
     * @var MockObject
     */
    private $quoteMock;
    /**
     * @var MockObject
     */
    private $quoteItemMock;
    /**
     * @var MockObject[]
     */
    private $quoteItems = [];
    /**
     * @var MockObject
     */
    private $orderMock;
    /**
     * @var MockObject
     */
    private $orderItemsMock;
    /**
     * @var MockObject[]
     */
    private $orderItems = [];
    /**
     * @var MockObject
     */
    private $offer;
    /**
     * @var MockObject
     */
    private $seller;
    /**
     * @var MockObject
     */
    private $salesOrderInfo;
    /**
     * @var MockObject
     */
    private $salesOrderItemInfo;
    /**
     * @var MockObject
     */
    private $orderExtensionAttribute;
    /**
     * @var MockObject
     */
    private $orderItemExtensionAttribute;
    /**
     * @var MockObject
     */
    private $extensionAttributesService;
    /**
     * @var array
     */
    private $cartItemExtensionAttributeContainer = [];
    /**
     * @var array
     */
    private $orderItemExtensionAttributeContainer = [];

    /**
     * @dataProvider eventDataReturnProvider
     *
     * @param $offerIdIsNotNull
     * @param $quoteItemNumber
     * @param $orderItemNumber
     */
    public function testSaveWhenOfferidIsProvidedOnExecute($offerIdIsNotNull, $quoteItemNumber, $orderItemNumber)
    {
        //Arrange we declare all mocks needs dor the execution of the test
        $this->initTest($offerIdIsNotNull, $quoteItemNumber, $orderItemNumber);

        //We return different cartItemExtensionAttribute for the getOfferId
        // Limitation phpunit we put differnt argument for the method and want different object return
        $this->extensionAttributesService
            ->expects($this->any())
            ->method('getQuoteItemExtensionAttributes')
            ->withConsecutive(...array_map(function ($quoteItem) {
                return [$quoteItem];
            }, $this->quoteItems))
            ->willReturn(...$this->cartItemExtensionAttributeContainer);

        $this->sellerRepository->expects($this->once())->method('get')->willReturn($this->seller);
        $this->seller->expects($this->once())->method('getMaasEntityId')->willReturn(self::SELLER_MAAS_ENTITY_ID);
        $this->seller->expects($this->once())->method('getName')->willReturn(self::SELLER_NAME);

        $this->offer->expects($this->any())->method('getSellerId')->willReturn(self::SELLER_ID);

        $this->offer
            ->expects($this->any())
            ->method('getId')
            ->willReturnOnConsecutiveCalls(...range(1, $quoteItemNumber));
        $this->offer
            ->expects($this->any())
            ->method('getMaasEntityId')
            ->willReturn(self::OFFER_MAAS_ENTITY_ID_1, self::OFFER_MAAS_ENTITY_ID_2);

        $this->offerRepository
            ->expects($this->any())
            ->method('get')
            ->willReturn($this->offer);

        //we do the same as quote item but with differents methods (orderItems)
        foreach ($this->orderItems as $key => $orderItem) {
            $orderItemExtraInfo = $this->buildOrderItemExtraInfo();
            $orderItemExtraInfo->expects($this->any())
                ->method('setItemId')
                ->willReturn($orderItemExtraInfo);
            $orderItemExtraInfo->expects($this->any())
                ->method('setOfferId')
                ->willReturn($orderItemExtraInfo);
            $orderItemExtraInfo->expects($this->any())
                ->method('setSellerId')
                ->willReturn($orderItemExtraInfo);
            $orderItemExtraInfo->expects($this->any())
                ->method('setOfferMaasId')
                ->willReturn($orderItemExtraInfo);
            $orderItemExtraInfo->expects($this->any())
                ->method('setOriginalTaxes')
                ->willReturn($orderItemExtraInfo);

            $orderItemExtensionAttribute = $this->buildOrderItemExtensionAttribute();

            $orderItemExtraInfo
                ->expects($this->any())
                ->method('setShippingMethod')
                ->willReturnSelf();
            $orderItemExtraInfo
                ->expects($this->any())
                ->method('setShippingAmount')
                ->willReturnSelf();
            $orderItemExtraInfo
                ->expects($this->any())
                ->method('setDeliveryDateMin')
                ->willReturnSelf();
            $orderItemExtraInfo
                ->expects($this->any())
                ->method('setDeliveryDateMax')
                ->willReturnSelf();
            $orderItemExtensionAttribute
                ->expects($this->any())
                ->method('getExtraInfo')
                ->willReturn($orderItemExtraInfo);

            $this->orderItemExtensionAttributeContainer[] = $orderItemExtensionAttribute;
        }

        $this->extensionAttributesService
            ->expects($this->any())
            ->method('getOrderItemExtensionAttributes')
            ->withConsecutive(...array_map(function ($orderItem) {
                return [$orderItem];
            }, $this->orderItems))
            ->willReturn(...$this->orderItemExtensionAttributeContainer);


        $this->salesOrderInfoRepository->expects($this->any())->method('save');
        //Act invocation of the method we test
        $this->sut->validateOrderData($this->orderMock, $this->quoteMock);
    }

    protected function invokeMethod(&$object, $methodName, array $parameters = [])
    {
        $reflection = new ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }

    public function testAddItemsWithItemInstanceOfQuoteItem(){
        $this->initTest();
        $abstractItem = AnyBuilder::createForClass($this, AbstractItem::class, [
            'getItemId' => [$this->once(), 5]
        ])->build();
        $item = AnyBuilder::createForClass($this, QuoteItem::class, [
            'getChildren' => [$this->once(), [$abstractItem]]
        ])->build();
        $quote = AnyBuilder::createForClass($this, CartInterface::class, [
            'getItems' => [$this->once(), [$item]]
        ])->build();
        $returnThis = $this->invokeMethod($this->sut, 'addItemsFromQuote',  [$quote]);
        $this->assertEquals($returnThis, $this->sut, "should return self");
    }

    public function testGetCartItemWithQuoteItemIdNotTheSameAsCartItem() {
        $this->initTest();
        $orderItem =  AnyBuilder::createForClass($this, OrderItemInterface::class, [
            'getQuoteItemId' => [$this->once(), 9]
        ])->build();
        $item = AnyBuilder::createForClass($this, QuoteItem::class, [
            'getItemId' => [$this->once(), 7]
        ])->build();
        $quote = AnyBuilder::createForClass($this, CartInterface::class, [
            'getItems' => [$this->once(), [$item]]
        ])->build();
        $returnNull = $this->invokeMethod($this->sut, 'getCartItemFromOrderItem',  [$orderItem,  $quote]);
        $this->assertNull($returnNull, "should return null");
    }

    /**
     * @param bool $offerIdsIsnull
     * @param int $quoteItemNumber
     * @param int $orderItemNumber
     */
    private function initTest($offerIdsIsnull = true, $quoteItemNumber = 2, $orderItemNumber = 2)
    {
        $this->orderExtensionAttribute = $this->buildOrderExtensionAttribute();
        $this->quoteMock = $this->buildQuote();
        $this->quoteItemMock = $this->buildQuoteItem();
        $this->orderMock = $this->buildOrder();
        $this->orderItemsMock = $this->buildOrderItem();

        //We create multiple item (object) quote, salesQuoteItemInfo, cartItemExtensionAttribute
        for ($i = 1; $i < $quoteItemNumber + 1; $i++) {
            //create quote item and apply method getItem id for the first loop
            $quoteItem = $this->buildQuoteItem();
            $quoteItem
                ->expects($this->any())
                ->method('getItemId')
                ->willReturn($i);
            $this->quoteItems[] = $quoteItem;
            //Then we create a mutiple salesQuoteItemInfo with method get offeId in get getOfferId method
            //We start by the end of the function and go up
            $quoteItemExtraInfo = $this->buildSalesQuoteItemInfo();
            $quoteItemExtraInfo
                ->expects($this->any())
                ->method('getOfferId')
                ->willReturn($offerIdsIsnull ? null : $i);
            $quoteItemExtraInfo
                ->expects($this->any())
                ->method('getDeliveryDelayMin')
                ->willReturn($offerIdsIsnull ? null : $i+1);
            $quoteItemExtraInfo
                ->expects($this->any())
                ->method('getDeliveryDelayMax')
                ->willReturn($offerIdsIsnull ? null : $i+3);

            //Creation of quoteItemExtensionAttribute who should return a salesQuoteItemInfo
            $cartItemExtensionAttribute = $this->buildQuoteItemExtensionAttribute();
            $cartItemExtensionAttribute
                ->expects($this->any())
                ->method('getExtraInfo')
                ->willReturn($quoteItemExtraInfo);
            $this->cartItemExtensionAttributeContainer[] = $cartItemExtensionAttribute;
        }

        // Creation of mutliple orderItem
        for ($i = 1; $i < $orderItemNumber + 1; $i++) {
            $orderItem = $this->buildOrderItem();
            $orderItem
                ->expects($this->any())
                ->method('getQuoteItemId')
                ->willReturn($i);
            $orderItem
                ->expects($this->any())
                ->method('getItemId')
                ->willReturn($i);
            $this->orderItems[] = $orderItem;
        }
        //get items for foreach in quote and order
        $this->quoteMock->expects($this->any())->method('getItems')->willReturn($this->quoteItems);
        $this->orderMock->expects($this->any())->method('getItems')->willReturn($this->orderItems);
        //create offer seller salesOderInfo and sales orderItemOrderInfo
        $this->offer = $this->buildOffer();
        $this->seller = $this->buildSeller();
        $this->salesOrderInfo = $this->buildSalesOrderInfo();
        $this->salesOrderItemInfo = $this->buildSalesItemOrderInfo();

        //creation of salesOrderInfoInterface for the method insertDataOrderInfo
        $orderExtraInfo = $this->buildOrderExtraInfo();
        //call the service of extension attributes for order which should return an orderExtensionAttribute
        $this->extensionAttributesService
            ->expects($this->any())
            ->method('getOrderExtensionAttributes')
            ->with($this->orderMock)
            ->willReturn($this->orderExtensionAttribute);
        $this->orderExtensionAttribute
            ->expects($this->any())
            ->method('getExtraInfo')
            ->willReturn($orderExtraInfo);
        $this->orderMock->expects($this->any())->method('getEntityId')->willReturn(self::ORDER_ID);
        $orderExtraInfo
            ->expects($this->any())
            ->method('setOrderId')
            ->with(self::ORDER_ID)
            ->willReturn($orderExtraInfo);
        $orderExtraInfo->expects($offerIdsIsnull ? $this->never() : $this->once())
            ->method('setSellerId')
            ->with($offerIdsIsnull ? null : self::SELLER_ID)
            ->willReturn($orderExtraInfo);
        $orderExtraInfo->expects($offerIdsIsnull ? $this->never() : $this->once())
            ->method('setSellerMaasId')
            ->with($offerIdsIsnull ? null : self::SELLER_MAAS_ENTITY_ID)
            ->willReturn($orderExtraInfo);
        $orderExtraInfo->expects($offerIdsIsnull ? $this->never() : $this->once())
            ->method('setSellerName')
            ->with($offerIdsIsnull ? null : self::SELLER_NAME)
            ->willReturn($orderExtraInfo);
        $orderExtraInfo->expects($this->any())
            ->method('setOrderType');
    }

    /**
     * @return MockObject
     */
    private function buildOrderExtensionAttribute()
    {
        return $this->getMockBuilder(OrderExtension::class)
            ->setMethods([
                'getExtraInfo',
                'setSalesOrderInfo'
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildQuote()
    {
        return $this->getMockBuilder(CartInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildQuoteItem()
    {
        return $this->getMockBuilder(CartItemInterface::class)
            ->setMethods(['getOfferId'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildOrder()
    {
        return $this->getMockBuilder(OrderInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildOrderItem()
    {
        // Used class instead of interface in order to be able to use getChildrenItems()
        return $this->getMockBuilder(Item::class)
            ->disableOriginalConstructor()
            ->setMethods(['getItemId', 'getQuoteItemId'])
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildSalesQuoteItemInfo()
    {
        return $this->getMockBuilder(SalesQuoteItemInfoInterface::class)
            ->disableOriginalConstructor()
            ->setMethods(['getOfferId'])
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildQuoteItemExtensionAttribute()
    {
        return $this->getMockBuilder(CartItemExtension::class)
            ->setMethods(['getExtraInfo'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildOffer()
    {
        return $this->getMockBuilder(OfferInterface::class)
            ->setMethods(['getId'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildSeller()
    {
        return $this->getMockBuilder(SellerInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildSalesOrderInfo()
    {
        return $this->getMockBuilder(SalesOrderInfoInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildSalesItemOrderInfo()
    {
        return $this->getMockBuilder(SalesOrderItemInfoInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildOrderExtraInfo()
    {
        return $this->getMockBuilder(SalesOrderInfoInterface::class)
            ->setMethods([
                'setOrderId',
                'setSellerId',
                'setSellerName',
                'setSellerMaasId',
                'setOrderType'
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildOrderItemExtraInfo()
    {
        return $this->getMockBuilder(SalesOrderItemInfoInterface::class)
            ->setMethods([
                'setSalesOrderItemInfo',
                'getExtraInfo',
                'setItemId',
                'setOfferId',
                'setOfferMaasId',
                'setOriginalTaxes'
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function buildOrderItemExtensionAttribute()
    {
        return $this->getMockBuilder(OrderItemExtension::class)
            ->setMethods([
                'getExtraInfo'
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * test with no offer ID
     */
    public function testDoNotSaveWhenOfferidIsNotProvidedOnExecute()
    {
        //Arrange we declare all mocks needs for the execution of the test
        $this->initTest();

        $this->extensionAttributesService
            ->expects($this->once())
            ->method('getQuoteItemExtensionAttributes')
            ->withConsecutive(...array_map(function ($quoteItem) {
                return [$quoteItem];
            }, $this->quoteItems))
            ->willReturn(...$this->cartItemExtensionAttributeContainer);
        $this->offerRepository->expects($this->never())->method('get')->willReturn($this->offer);

        //Act invocation of the method we test
        $this->sut->validateOrderData($this->orderMock, $this->quoteMock);
    }

    /**
     * @return array[]
     */
    public function eventDataReturnProvider()
    {
        return [
            'offer id is not null' => [
                'offerIdIsNull' => false,
                'quoteItemNumber' => 2,
                'orderItemNumber' => 2
            ],
            'offer one offer id not null' => [
                'offerIdIsNull' => false,
                'quoteItemNumber' => 1,
                'orderItemNumber' => 1
            ],
        ];
    }

    /**
     * Set Up
     *
     * @return void
     */
    protected function setUp()
    {
        $this->salesOrderInfoRepository = $this->createMock(SalesOrderInfoRepositoryInterface::class);
        $this->salesOrderItemInfoRepository = $this->createMock(SalesOrderItemInfoRepositoryInterface::class);
        $this->sellerRepository = $this->createMock(SellerRepositoryInterface::class);
        $this->offerRepository = $this->createMock(OfferRepositoryInterface::class);
        $this->extensionAttributesService = $this->createMock(ExtensionAttributes::class);
        $eventManagerMock = $this->createMock(ManagerInterface::class);
        $this->sut = new RegisterOfferAndSellerDuringOrderProcess(
            $this->salesOrderInfoRepository,
            $this->salesOrderItemInfoRepository,
            $this->sellerRepository,
            $this->offerRepository,
            $this->extensionAttributesService,
            $eventManagerMock
        );
    }
}
