<?php


namespace Maas\Sales\Test\Unit\Model;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressItemInfoRepositoryInterface;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Sales\Model\Service\AddressItem;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\NoSuchEntityException;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteria;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Item;
use PHPUnit\Framework\TestCase;
use ReflectionClass;

class AddressItemTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $salesQuoteAddressItemInfoFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $salesQuoteAddressItemInfoRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $searchCriteriaBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $extensionAttributes;

    /** @var \Maas\Sales\Model\Service\AddressItem */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $salesQuoteAddressItemInfo;


    public function initTest($exception = null , $shippingMethod = null)
    {
        $this->salesQuoteAddressItemInfo =  AnyBuilder::createForClass($this, SalesQuoteAddressItemInfoInterface::class, [
            'setId' => [$this->atMost(1)],
            'getShippingMethod' => [$this->atMost(1), $shippingMethod],
            'getId' => [$this->atMost(1), 8]
        ])->build();
        $this->salesQuoteAddressItemInfoFactory = AnyBuilder::createForClass($this, SalesQuoteAddressItemInfoInterfaceFactory::class, [
            'create' => [$this->atMost(1), $this->salesQuoteAddressItemInfo]
        ])->build();
        $salesQuoteAddressItemInfoSearchResultsInterface = AnyBuilder::createForClass($this, SalesQuoteAddressItemInfoSearchResultsInterface::class, [
            'getItems' => [$this->atMost(1), [$this->salesQuoteAddressItemInfo]]
        ])->build();
        $this->salesQuoteAddressItemInfoRepository =  AnyBuilder::createForClass($this, SalesQuoteAddressItemInfoRepositoryInterface::class, [
            'get' =>  [$this->atMost(1), $exception ?? $this->salesQuoteAddressItemInfo, $exception ? AnyBuilder::THROW_EXCEPTION : AnyBuilder::RETURN_VALUE],
            'getList' => [$this->atMost(1), $salesQuoteAddressItemInfoSearchResultsInterface]
        ])->build();
        $searchCriteria = AnyBuilder::createForClass($this, SearchCriteria::class)->build();
        $this->searchCriteriaBuilder =  AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'addFilter' => [$this->atMost(1), null , AnyBuilder::RETURN_SELF],
            'create' => [$this->atMost(1), $searchCriteria]
        ])->build();
        $this->extensionAttributes =  AnyBuilder::createForClass($this, ExtensionAttributes::class)->build();
        $this->stub = AnyBuilder::createForClass($this, AddressItem::class)
            ->setConstructorArgs([
                $this->salesQuoteAddressItemInfoFactory,
                $this->salesQuoteAddressItemInfoRepository,
                $this->searchCriteriaBuilder,
                $this->extensionAttributes
            ])
            ->build();
    }

    public function testLoadExtraInfoByIdDoesNotExist()
    {
        $this->initTest();
        $salesQuoteAddressItem = $this->stub->loadExtraInfoById(5);
        $this->assertEquals($salesQuoteAddressItem, $this->salesQuoteAddressItemInfo , 'should return a salesQuoteAddressItemInfo');
    }

    public function testLoadExtraInfoByIdExist()
    {
        $this->initTest();
        $this->stub->loadExtraInfoById(15);
        $salesQuoteAddressItem = $this->stub->loadExtraInfoById(15);
        $this->assertEquals($salesQuoteAddressItem, $this->salesQuoteAddressItemInfo, 'should return a salesQuoteAddressItemInfo');
    }

    public function testLoadExtraInfoByIdNosuchEntityException()
    {
        $exception = new NoSuchEntityException();
        $this->initTest($exception);
        $salesQuoteAddressItem = $this->stub->loadExtraInfoById(5);
        $this->assertEquals($salesQuoteAddressItem, $this->salesQuoteAddressItemInfo, 'should return a salesQuoteAddressItemInfo');
    }
}

