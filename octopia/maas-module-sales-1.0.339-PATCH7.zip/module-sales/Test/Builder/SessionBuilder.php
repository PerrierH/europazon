<?php

namespace Maas\Sales\Test\Builder;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Sales\Model\Session;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class SessionBuilder
 *
 * @package Maas\Sales\Test\Builder
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class SessionBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];
        return $this->createMock(Session::class, $defaultData);
    }
}