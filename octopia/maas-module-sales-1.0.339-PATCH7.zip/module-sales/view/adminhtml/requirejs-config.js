var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Maas_Sales/js/system/config/payment-status-mixin': true
            }
        }
    }
};
