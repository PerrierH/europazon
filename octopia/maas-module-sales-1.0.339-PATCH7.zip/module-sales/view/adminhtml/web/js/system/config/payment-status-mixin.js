define([
    'jquery'
], function ($) {
    'use strict';

    return function (target) {
        $.validator.addMethod(
            'maas-payment-status-validator',
            function (value) {
                var allValid = true;
                $('#maas_orders_general_synchro_status_by_payment_method select').each(function () {
                    var options = $(this).val();
                    if((!options) || (Array.isArray(options) && options.length === 0))
                    {
                        allValid = false
                    }
                });
                return allValid;
            },
            $.mage.__('At least one status should be set for each payment method')
        );
        return target;
    };
});
