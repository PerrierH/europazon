var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/summary/item/details' : {
                'Maas_Sales/js/view/summary/item/details/mixin': true
            }
        }
    }
};
