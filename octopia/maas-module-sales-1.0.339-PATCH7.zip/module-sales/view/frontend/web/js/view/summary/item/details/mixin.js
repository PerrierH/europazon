define([
    'ko',
    'Maas_Shipping/js/model/summary-seller'
], function (ko, summarySeller) {
    'use strict';

    const mixin = {
        defaults: {
            template: 'Maas_Sales/summary/item/details'
        },
        getSeller: function (quoteItem) {
            if(quoteItem.hasOwnProperty('extension_attributes')
                && quoteItem.extension_attributes.hasOwnProperty('maas_seller_name')
                && quoteItem.extension_attributes.maas_seller_name)
            {
                return quoteItem.extension_attributes.maas_seller_name;
            }
            return false;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
