<?php

namespace Maas\Sales\Plugin\Restrictions;

use Maas\Sales\Model\Service\Restrictions;
use Magento\Backend\App\Action;
use Magento\Framework\App\RequestInterface;

/**
 * Class EnableOnController
 *
 * @package Maas\Sales\Plugin\Restrictions
 * @codeCoverageIgnore delegates to Restrictions
 */
class EnableOnController
{
    /**
     * @var Restrictions
     */
    protected $restrictions;

    /**
     * EnableOnController constructor.
     *
     * @param Restrictions $restrictions
     */
    public function __construct(
        Restrictions $restrictions
    ) {
        $this->restrictions = $restrictions;
    }

    /**
     * The restriction remains enabled after the dispatch, so it is applied while rendering pages
     *
     * @param Action $subject
     * @param RequestInterface $request
     *
     * @return array
     */
    public function beforeDispatch(Action $subject, RequestInterface $request)
    {
        $this->restrictions->enableIfPossible($request);
        return [$request];
    }
}