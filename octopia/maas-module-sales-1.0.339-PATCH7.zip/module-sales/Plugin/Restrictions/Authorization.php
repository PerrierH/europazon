<?php

namespace Maas\Sales\Plugin\Restrictions;

use Maas\Sales\Model\Service\Restrictions;
use Magento\Framework\AuthorizationInterface;

/**
 * Class Authorization
 *
 * @package Maas\Sales\Plugin\Restrictions
 * @codeCoverageIgnore delegates to Restrictions
 */
class Authorization
{
    /**
     * @var Restrictions
     */
    protected $restrictionsService;

    /**
     * Authorisation constructor.
     *
     * @param Restrictions $restrictionsService
     */
    public function __construct(
        Restrictions $restrictionsService
    ) {
        $this->restrictionsService = $restrictionsService;
    }

    /**
     * @param AuthorizationInterface $subject
     * @param $result
     * @param $resource
     * @param null $privilege
     *
     * @return bool|mixed
     */
    public function afterIsAllowed(
        AuthorizationInterface $subject,
        $result,
        $resource,
        $privilege = null
    ) {
        return $this->restrictionsService->isAllowed($resource, $result);
    }
}