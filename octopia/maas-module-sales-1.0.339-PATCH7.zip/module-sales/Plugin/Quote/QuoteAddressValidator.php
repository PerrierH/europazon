<?php

namespace Maas\Sales\Plugin\Quote;

use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\CartInterface;

/**
 * Class QuoteAddressValidator
 * @codeCoverageIgnore
 * @package Maas\Sales\Plugin\Quote
 */
class QuoteAddressValidator
{
    /**
     * @param \Magento\Quote\Model\QuoteAddressValidator $subject
     * @param cartInterface $cart
     * @param \Magento\Quote\Api\Data\AddressInterface $address
     * @return void
     */
    public function beforeValidateForCart(
        \Magento\Quote\Model\QuoteAddressValidator $subject,
        cartInterface $cart,
        AddressInterface $address
    ): void {
        if ($cart->getCustomer()->getId()) {
            $cart->setCustomerIsGuest(0);
        }
    }
}
