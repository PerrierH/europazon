<?php

namespace Maas\Sales\Plugin\Quote;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Quote\Model\Quote\Config;
use Magento\Quote\Model\Quote\Item;

/**
 * Class SetInfoToParentProductFromChildProduct
 * @codeCoverageIgnore
 * @package Maas\Sales\Plugin\Quote
 */
class SetInfoToParentProductFromChildProduct
{
    protected Config $quoteConfig;

    /**
     * @param Config $quoteConfig
     */
    public function __construct(Config $quoteConfig)
    {
        $this->quoteConfig = $quoteConfig;
    }

    /**
     * @param Item $subject
     * @param $product
     * @return ProductInterface
     */
    public function afterGetProduct(Item $subject, $product)
    {
        if ($subject->getHasChildren()) {
            $attributes = $this->quoteConfig->getProductAttributes();
            foreach ($subject->getChildren() as $child) {
                foreach ($attributes as $attribute) {
                    if (strpos($attribute, 'maas') !== false ) {
                        $product->setData($attribute, $child->getProduct()->getData($attribute));
                    }
                }
            }
        }
        return $product;
    }
}
