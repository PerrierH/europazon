<?php

namespace Maas\Sales\Plugin\Checkout;

use Maas\Sales\Model\Service\SellerNamesOnTotalItems;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\CartTotalRepositoryInterface;
use Magento\Quote\Api\Data\TotalsInterface;

/**
 * Class AddSellersToTotalItems
 * @codeCoverageIgnore
 * @package Maas\Sales\Plugin\Checkout
 */
class AddSellersToTotalItems
{
    /** @var CartRepositoryInterface */
    protected $cartRepository;

    /** @var SellerNamesOnTotalItems */
    protected $sellerNamesOnTotalItems;

    /**
     * AddSellersToTotalItems constructor.
     *
     * @param CartRepositoryInterface $cartRepository
     * @param SellerNamesOnTotalItems $sellerNamesOnTotalItems
     */
    public function __construct(
        CartRepositoryInterface $cartRepository,
        SellerNamesOnTotalItems $sellerNamesOnTotalItems
    ) {
        $this->cartRepository = $cartRepository;
        $this->sellerNamesOnTotalItems = $sellerNamesOnTotalItems;
    }

    /**
     * @param CartTotalRepositoryInterface $subject
     * @param TotalsInterface $result
     * @param int $cartId
     *
     * @return TotalsInterface
     */
    public function afterGet(CartTotalRepositoryInterface $subject, $result, $cartId)
    {
        $this->sellerNamesOnTotalItems->executeWithQuoteItems($this->cartRepository->get($cartId), $result->getItems());
        return $result;
    }
}
