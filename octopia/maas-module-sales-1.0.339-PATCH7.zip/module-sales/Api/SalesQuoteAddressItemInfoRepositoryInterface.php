<?php

namespace Maas\Sales\Api;

use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesQuoteAddressItemInfoRepositoryInterface
 *
 * @package Maas\Sales\Api
 */
interface SalesQuoteAddressItemInfoRepositoryInterface
{

    /**
     * @param SalesQuoteAddressItemInfoInterface $salesOrderInfo
     *
     * @return SalesQuoteAddressItemInfoInterface
     */
    public function save(SalesQuoteAddressItemInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesQuoteAddressItemInfoInterface
     */
    public function get($id);

    /**
     * @param SalesQuoteAddressItemInfoInterface $salesOrderInfo
     */
    public function delete(SalesQuoteAddressItemInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesQuoteAddressItemInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
