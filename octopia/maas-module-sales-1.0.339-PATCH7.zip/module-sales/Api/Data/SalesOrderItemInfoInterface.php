<?php

namespace Maas\Sales\Api\Data;

/**
 * Interface SalesOrderItemInfoInterface
 * @package Maas\Sales\Api\Data
 */
interface SalesOrderItemInfoInterface
{
    const OFFER_ID = 'offer_id';
    const SELLER_ID = 'seller_id';
    const OFFER_MASS_ID = 'offer_maas_id';
    const STATUS = 'status';
    const SHIPPING_METHOD = 'shipping_method';
    const SHIPPING_AMOUNT = 'shipping_amount';
    const ORIGINAL_SHIPPING_AMOUNT = 'original_shipping_amount';
    const DISCOUNTED_SHIPPING_AMOUNT = 'discounted_shipping_amount';
    const DELIVERY_DATE_MIN = 'delivery_date_min';
    const DELIVERY_DATE_MAX = 'delivery_date_max';
    const ORIGINAL_TAXES = 'original_taxes';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return int
     */
    public function getOfferId();

    /**
     * @param int $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId);

    /**
     * @return int
     */
    public function getSellerId();

    /**
     * @param int $offerId
     *
     * @return $this
     */
    public function setSellerId($offerId);

    /**
     * @return string
     */
    public function getOfferMaasId();

    /**
     * @param string $maasOfferId
     *
     * @return $this
     */
    public function setOfferMaasId($maasOfferId);

    /**
     * @return string
     */
    public function getStatus();

    /**
     * @param string $status
     *
     * @return $this
     */
    public function setStatus($status);

    /**
     * @return string
     */
    public function getShippingMethod();

    /**
     * @param string $shippingMethod
     *
     * @return $this
     */
    public function setShippingMethod($shippingMethod);

    /**
     * @return float
     */
    public function getShippingAmount();

    /**
     * @param float $shippingAmount
     * @return $this
     */
    public function setShippingAmount($shippingAmount);

    /**
     * @return float
     */
    public function getOriginalShippingAmount();

    /**
     * @param float $originalShippingAmount
     * @return $this
     */
    public function setOriginalShippingAmount($originalShippingAmount);

    /**
     * @return float
     */
    public function getDiscountedShippingAmount();

    /**
     * @param float $discountedShippingAmount
     * @return $this
     */
    public function setDiscountedShippingAmount($discountedShippingAmount);

    /**
     * @return string
     */
    public function getDeliveryDateMin();

    /**
     * @param int $deliveryDateMin
     * @return $this
     */
    public function setDeliveryDateMin($deliveryDateMin);

    /**
     * @return int
     */
    public function getDeliveryDateMax();

    /**
     * @param int $deliveryDateMax
     * @return $this
     */
    public function setDeliveryDateMax($deliveryDateMax);

    /**
     * @return string
     */
    public function getOriginalTaxes();

    /**
     * @param string $originalTaxes
     * @return $this
     */
    public function setOriginalTaxes($originalTaxes);
}
