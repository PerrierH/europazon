<?php

namespace Maas\Sales\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesOrderItemInfoSearchResultsInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesOrderItemInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return SalesOrderItemInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param SalesOrderItemInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}