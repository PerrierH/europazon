<?php

namespace Maas\Sales\Api\Data;

/**
 * Interface SalesQuoteAddressInfoInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteAddressInfoInterface
{
    const TOTAL_ROUND_FIXES = 'total_round_fixes';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return string
     */
    public function getTotalRoundFixes();


    /**
     * @param string $totalRoundFixes
     *
     * @return $this
     */
    public function setTotalRoundFixes($totalRoundFixes);
}
