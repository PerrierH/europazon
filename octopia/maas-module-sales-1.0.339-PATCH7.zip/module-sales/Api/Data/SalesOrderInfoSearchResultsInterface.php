<?php

namespace Maas\Sales\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesOrderInfoSearchResultsInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesOrderInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return SalesOrderInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param SalesOrderInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}