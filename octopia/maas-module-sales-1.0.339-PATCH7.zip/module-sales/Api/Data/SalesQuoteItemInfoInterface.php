<?php

namespace Maas\Sales\Api\Data;

/**
 * Interface SalesQuoteItemInfoInterface
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteItemInfoInterface
{
    const OFFER_ID = 'offer_id';
    const SELLER_ID = 'seller_id';
    const SHIPPING_METHOD = 'shipping_method';
    const SHIPPING_AMOUNT = 'shipping_amount';
    const ORIGINAL_SHIPPING_AMOUNT = 'original_shipping_amount';
    const DISCOUNTED_SHIPPING_AMOUNT = 'discounted_shipping_amount';
    const DELIVERY_DELAY_MIN = 'delivery_delay_min';
    const DELIVERY_DELAY_MAX = 'delivery_delay_max';
    const ORIGINAL_TAXES = 'original_taxes';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     * @return $this
     */
    public function setId($id);

    /**
     * @return int
     */
    public function getOfferId();

    /**
     * @param int $offerId
     * @return $this
     */
    public function setOfferId($offerId);

    /**
     * @return int
     */
    public function getSellerId();

    /**
     * @param int $offerId
     * @return $this
     */
    public function setSellerId($offerId);

    /**
     * @return string
     */
    public function getShippingMethod();

    /**
     * @param string $shippingMethod
     * @return $this
     */
    public function setShippingMethod($shippingMethod);

    /**
     * @return float
     */
    public function getShippingAmount();

    /**
     * @param float $shippingAmount
     *
     * @return $this
     */
    public function setShippingAmount($shippingAmount);

    /**
     * @return float
     */
    public function getOriginalShippingAmount();

    /**
     * @param float $originalShippingAmount
     * @return $this
     */
    public function setOriginalShippingAmount($originalShippingAmount);

    /**
     * @return float
     */
    public function getDiscountedShippingAmount();

    /**
     * @param float $discountedShippingAmount
     * @return $this
     */
    public function setDiscountedShippingAmount($discountedShippingAmount);

    /**
     * @return int
     */
    public function getDeliveryDelayMin();

    /**
     * @param int $shippingDelayMin
     * @return $this
     */
    public function setDeliveryDelayMin($shippingDelayMin);

    /**
     * @return int
     */
    public function getDeliveryDelayMax();

    /**
     * @param int $shippingDelayMax
     * @return $this
     */
    public function setDeliveryDelayMax($shippingDelayMax);

    /**
     * @return string
     */
    public function getOriginalTaxes();

    /**
     * @param string $originalTaxes
     * @return $this
     */
    public function setOriginalTaxes($originalTaxes);

}
