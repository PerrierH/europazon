<?php

namespace Maas\Sales\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesQuoteItemInfoSearchResultsInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteItemInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return SalesQuoteItemInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param SalesQuoteItemInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}