<?php

namespace Maas\Sales\Api\Data;

/**
 * Interface SalesQuoteInfoInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteInfoInterface
{
    const ORIGINAL_QUOTE_ID = 'original_quote_id';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);


    /**
     * @return int
     */
    public function getOriginalQuoteId(): int;

    /**
     * @param int $originalQuoteId
     * @return $this
     */
    public function setOriginalQuoteId(int $originalQuoteId): SalesQuoteInfoInterface;
}
