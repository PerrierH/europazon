<?php

namespace Maas\Sales\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesQuoteAddressItemInfoSearchResultsInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteAddressItemInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return SalesQuoteAddressItemInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param SalesQuoteAddressItemInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
