<?php

namespace Maas\Sales\Api\Data;

/**
 * Interface SalesOrderInfoInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesOrderInfoInterface
{
    const SELLER_ID = 'seller_id';
    const MAAS_SELLER_ID = 'seller_maas_id';
    const MAAS_SELLER_NAME = 'maas_seller_name';
    //order_type 1 for Core and 2 for Maas
    const MAAS_ORDER_TYPE = 'order_type';
    // IDs of the mai order used for payments
    const MAIN_ORDER_ID = 'main_order_id';
    const MAIN_ORDER_INCREMENT_ID = 'main_order_increment_id';
    const EXPORTED = 'exported';
    const OCTOPIA_PAYMENT_CODE = 'octopia_payment_code';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return int
     */
    public function getSellerId();

    /**
     * @param int $sellerId
     *
     * @return $this
     */
    public function setSellerId($sellerId);

    /**
     * @return string
     */
    public function getSellerMaasId();

    /**
     * @param string $maasSellerId
     *
     * @return $this
     */
    public function setSellerMaasId($maasSellerId);

    /**
     * @return string
     */
    public function getMaasSellerName();

    /**
     * @param string $maasSellerName
     *
     * @return $this
     */
    public function setMaasSellerName($maasSellerName);

    /**
     * @return int
     */
    public function getOrderType();

    /**
     * @param int $orderType
     *
     * @return $this
     */
    public function setOrderType($orderType);

    /**
     * @return int
     */
    public function getMainOrderId();

    /**
     * @param int $mainOrderId
     *
     * @return $this
     */
    public function setMainOrderId($mainOrderId);

    /**
     * @return string
     */
    public function getMainOrderIncrementId();

    /**
     * @param string $mainOrderIncrementId
     *
     * @return $this
     */
    public function setMainOrderIncrementId($mainOrderIncrementId);

    /**
     * @return boolean
     */
    public function getExported();

    /**
     * @param bool $exported
     *
     * @return $this
     */
    public function setExported($exported);

    /**
     * @return string
     */
    public function getOctopiaPaymentCode();

    /**
     * @param string $octopiaPaymentCode
     *
     * @return $this
     */
    public function setOctopiaPaymentCode($octopiaPaymentCode);
}
