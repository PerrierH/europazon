<?php

namespace Maas\Sales\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesQuoteInfoSearchResultsInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return SalesQuoteInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param SalesQuoteInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
