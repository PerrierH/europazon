<?php

namespace Maas\Sales\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesQuoteAddressInfoSearchResultsInterface
 *
 * @package Maas\Sales\Api\Data
 */
interface SalesQuoteAddressInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return SalesQuoteAddressInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param SalesQuoteAddressInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
