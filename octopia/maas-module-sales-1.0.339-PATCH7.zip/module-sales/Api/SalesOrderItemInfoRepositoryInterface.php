<?php

namespace Maas\Sales\Api;

use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesOrderItemInfoRepositoryInterface
 *
 * @package Maas\Sales\Api
 */
interface SalesOrderItemInfoRepositoryInterface
{

    /**
     * @param SalesOrderItemInfoInterface $salesOrderInfo
     *
     * @return SalesOrderItemInfoInterface
     */
    public function save(SalesOrderItemInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesOrderItemInfoInterface
     */
    public function get($id);

    /**
     * @param SalesOrderItemInfoInterface $salesOrderInfo
     */
    public function delete(SalesOrderItemInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesOrderItemInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}