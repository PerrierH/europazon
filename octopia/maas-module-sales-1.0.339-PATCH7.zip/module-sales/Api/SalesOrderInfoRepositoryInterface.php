<?php

namespace Maas\Sales\Api;

use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Api\Data\SalesOrderInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesOrderInfoRepositoryInterface
 *
 * @package Maas\Sales\Api
 */
interface SalesOrderInfoRepositoryInterface
{

    /**
     * @param SalesOrderInfoInterface $salesOrderInfo
     *
     * @return SalesOrderInfoInterface
     */
    public function save(SalesOrderInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesOrderInfoInterface
     */
    public function get($id);

    /**
     * @param SalesOrderInfoInterface $salesOrderInfo
     */
    public function delete(SalesOrderInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesOrderInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}