<?php

namespace Maas\Sales\Api;

use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesQuoteAddressInfoRepositoryInterface
 *
 * @package Maas\Sales\Api
 */
interface SalesQuoteAddressInfoRepositoryInterface
{

    /**
     * @param SalesQuoteAddressInfoInterface $salesOrderInfo
     *
     * @return SalesQuoteAddressInfoInterface
     */
    public function save(SalesQuoteAddressInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesQuoteAddressInfoInterface
     */
    public function get($id);

    /**
     * @param SalesQuoteAddressInfoInterface $salesOrderInfo
     */
    public function delete(SalesQuoteAddressInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesQuoteAddressInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
