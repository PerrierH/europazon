<?php

namespace Maas\Sales\Api;

use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteItemInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesQuoteItemInfoRepositoryInterface
 *
 * @package Maas\Sales\Api
 */
interface SalesQuoteItemInfoRepositoryInterface
{

    /**
     * @param SalesQuoteItemInfoInterface $salesOrderInfo
     *
     * @return SalesQuoteItemInfoInterface
     */
    public function save(SalesQuoteItemInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesQuoteItemInfoInterface
     */
    public function get($id);

    /**
     * @param SalesQuoteItemInfoInterface $salesOrderInfo
     */
    public function delete(SalesQuoteItemInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesQuoteItemInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}