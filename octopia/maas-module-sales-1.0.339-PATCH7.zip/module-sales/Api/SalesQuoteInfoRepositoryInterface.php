<?php

namespace Maas\Sales\Api;

use Maas\Sales\Api\Data\SalesQuoteInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesQuoteInfoRepositoryInterface
 *
 * @package Maas\Sales\Api
 */
interface SalesQuoteInfoRepositoryInterface
{

    /**
     * @param SalesQuoteInfoInterface $salesOrderInfo
     *
     * @return SalesQuoteInfoInterface
     */
    public function save(SalesQuoteInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesQuoteInfoInterface
     */
    public function get($id);

    /**
     * @param SalesQuoteInfoInterface $salesOrderInfo
     */
    public function delete(SalesQuoteInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesQuoteInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
