<?php

use Magento\Framework\Component\ComponentRegistrar;

/**
 * @codeCoverageIgnore
 */
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Maas_Sales', __DIR__);
