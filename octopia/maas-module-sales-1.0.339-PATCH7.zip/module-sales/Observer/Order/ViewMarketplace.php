<?php

namespace Maas\Sales\Observer\Order;

use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\LayoutInterface;
use Magento\Sales\Model\Order;

/**
 * Class ViewMarketplace
 *
 * The use of the deprecated Registry is necessary because Magento uses it too.
 *
 * @package Maas\Sales\Observer\Order
 */
class ViewMarketplace implements ObserverInterface
{
    /** @var Registry */
    protected $coreRegistry;

    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    private $actionList = [
        'sales_order_view',
        'sales_order_print',
        'sales_order_invoice',
        'sales_order_printInvoice',
        'sales_order_creditmemo',
        'sales_order_printCreditmemo',
        ];


    /**
     * ViewMarketplace constructor.sales/order/creditmemo
     *
     * @param Registry $coreRegistry
     * @param ExtensionAttributes $extensionAttributesService
     */
    public function __construct(
        Registry $coreRegistry,
        ExtensionAttributes $extensionAttributesService
    ) {
        $this->coreRegistry = $coreRegistry;
        $this->extensionAttributesService = $extensionAttributesService;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        if (in_array($observer->getEvent()->getData('full_action_name'), $this->actionList)) {
            /** @var Order $order */
            $order = $this->coreRegistry->registry('current_order');
            if ($order) {
                $extension = $this->extensionAttributesService->getOrderExtensionAttributes($order);
                if ($extension->getExtraInfo()->getOrderType() == SalesOrderInfo::ORDER_TYPE_MAAS) {
                    /** @var LayoutInterface $layout */
                    $layout = $observer->getEvent()->getData('layout');

                    $layout->getUpdate()->addHandle('sales_order_view_marketplace');
                }
            }
        }
    }
}
