<?php

namespace Maas\Sales\Observer;

use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Quote\Model\Quote\Item;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Seller\Api\SellerRepositoryInterface;

/**
 * Class CreateQuoteItemInfoAfterCartItemAdd
 * @package Maas\Sales\Observer
 */
class CreateQuoteItemInfoAfterCartItemAdd implements ObserverInterface
{
    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributesService;

    /**
     * @var SellerRepositoryInterface
     */
    protected $sellerRepository;

    /**
     * @var OfferRepositoryInterface
     */
    protected $offerRepository;

    /**
     * CreateQuoteItemInfoAfterCartItemAdd constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     * @param SellerRepositoryInterface $sellerRepository
     * @param OfferRepositoryInterface $offerRepository
     */
    public function __construct(
        ExtensionAttributes $extensionAttributesService,
        SellerRepositoryInterface $sellerRepository,
        OfferRepositoryInterface $offerRepository
    ) {
        $this->extensionAttributesService = $extensionAttributesService;
        $this->sellerRepository = $sellerRepository;
        $this->offerRepository = $offerRepository;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        /** @var CartItemInterface $item */
        $item = $observer->getEvent()->getData('quote_item');
        if ($item->getProductType() == 'simple') {
            $this->populateInfo($item);
        }
    }

    /**
     * @param Item $item
     * @return void
     * @throws LocalizedException
     */
    protected function populateInfo(Item $item)
    {
        $itemProduct = $item->getProduct();
        $parentItem = $itemProduct->getStickWithinParent();
        if ($parentItem) {
            $parentExtensionAttribute = $this->extensionAttributesService->getQuoteItemExtensionAttributes($parentItem);
            $parentExtraInfo = $parentExtensionAttribute->getExtraInfo();
            $parentExtraInfo->setId($item->getId());
        }

        $extensionAttribute = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
        $extraInfo = $extensionAttribute->getExtraInfo();
        $extraInfo->setId($item->getId());
        $offerId = $item->getProduct()->getMaasOfferId();

        $offerSellerId = null;
        if ($offerId) {
            $offer = $this->offerRepository->get($offerId);
            if ($offer && $offer->getId()) {
                $offerSellerId = $offer->getSellerId();
                $extraInfo->setOfferId($offerId);
                $extraInfo->setCondition($offer->getCondition());
                $extraInfo->setOfferMaasId($offer->getMaasEntityId());
                if ($parentItem) {
                    $parentExtraInfo->setOfferId($offerId);
                    $parentExtraInfo->setCondition($offer->getCondition());
                    $parentExtraInfo->setOfferMaasId($offer->getMaasEntityId());
                }
            } else {
                throw new LocalizedException(__("The offer %1 no longer exists", $offerId));
            }
        }

        $sellerId = $item->getProduct()->getMaasOfferSellerId();
        if ($sellerId) {
            $seller = $this->sellerRepository->get($sellerId);
            if ($seller && $seller->getId()) {
                $extraInfo->setSellerId($sellerId);
                if ($offerSellerId && $offerSellerId != $seller->getMaasEntityId()) {
                    throw new LocalizedException(__("The seller %1 does not match the offer %2", $seller->getMaasEntityId(), $offerId));
                }
                $extraInfo->setSellerMaasId($seller->getMaasEntityId());
                $extraInfo->setSellerName($seller->getName());
                if ($parentItem) {
                    $parentExtraInfo->setSellerId($sellerId);
                    $parentExtraInfo->setSellerMaasId($seller->getMaasEntityId());
                    $parentExtraInfo->setSellerName($seller->getName());
                }
            } else {
                throw new LocalizedException(__("The seller %1 no longer exists", $sellerId));
            }
        }
    }
}
