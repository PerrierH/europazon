<?php

namespace Maas\Sales\Observer;

use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote\Address\Item;

/**
 * Class CopyQuoteItemInfoToQuoteAddressItemInfo
 * @package Maas\Sales\Plugin
 */
class CopyQuoteItemInfoToQuoteAddressItemInfo implements ObserverInterface
{
    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributesService;

    /**
     * @var AddressItem
     */
    private $addressItemService;

    /**
     * CreateQuoteItemInfoAfterCartItemAdd constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     * @param AddressItem $addressItemService
     */
    public function __construct(ExtensionAttributes $extensionAttributesService, AddressItem $addressItemService) {
        $this->extensionAttributesService = $extensionAttributesService;
        $this->addressItemService = $addressItemService;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        /** @var Item $item */
        $quoteAddressItem = $observer->getEvent()->getData('object');
        if ($quoteAddressItem instanceof Item) {
            $extensionAttribute = $this->extensionAttributesService->getQuoteItemExtensionAttributes($quoteAddressItem->getQuoteItem());
            $extraInfo = $extensionAttribute->getExtraInfo();
            $extraInfoAddressItem = $this->addressItemService->loadExtraInfo($quoteAddressItem);
            if ($extraInfoAddressItem->getQuoteAddressItemId()) {
                $extraInfoData = $extraInfo->getData();
                unset($extraInfoData['quote_item_id']);
                $extraInfoData['quote_address_item_id'] = $quoteAddressItem->getId();
                try {
                    $extraInfoAddressItem->setData($extraInfoData);
                    $this->addressItemService->saveExtraInfo($extraInfoAddressItem);
                } catch (\Exception $e) {
                }
            }
        }
    }
}
