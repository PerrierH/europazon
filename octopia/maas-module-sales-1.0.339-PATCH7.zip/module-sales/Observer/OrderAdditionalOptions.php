<?php

namespace Maas\Sales\Observer;

use Maas\Sales\Model\RegisterOfferAndSellerDuringOrderProcess;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;

/**
 * Class OrderItemAdditionalOptions
 *
 * @package Maas\Sales\Observer
 */
class OrderAdditionalOptions implements ObserverInterface
{
    /**
     * @var RegisterOfferAndSellerDuringOrderProcess
     */
    protected $registerOfferAndSeller;

    /**
     * OrderAdditionalOptions constructor.
     *
     * @param RegisterOfferAndSellerDuringOrderProcess $registerOfferAndSeller
     */
    public function __construct(
        RegisterOfferAndSellerDuringOrderProcess $registerOfferAndSeller
    ) {
        $this->registerOfferAndSeller = $registerOfferAndSeller;
    }


    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $event = $observer->getEvent();
        /** @var OrderInterface $order */
        $order = $event->getData('order');
        /** @var CartInterface $quote */
        $quote = $event->getData('quote');
        if ($order !== null && $quote !== null) {
            $this->registerOfferAndSeller->setSaveEnabled(false);
            $this->registerOfferAndSeller->validateOrderData($order, $quote);
        }
    }
}
