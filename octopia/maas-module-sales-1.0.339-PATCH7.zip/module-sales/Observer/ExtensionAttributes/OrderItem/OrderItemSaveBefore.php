<?php

namespace Maas\Sales\Observer\ExtensionAttributes\OrderItem;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterfaceFactory;
use Maas\Sales\Api\SalesOrderItemInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\OrderItemExtensionInterfaceFactory;

/**
 * Class OrderItemSaveBefore
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\OrderItem
 * @codeCoverageIgnore
 */
class OrderItemSaveBefore implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var OrderItemExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesOrderItemInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesOrderItemInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * OrderItemSaveBefore constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param OrderItemExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesOrderItemInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesOrderItemInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        OrderItemExtensionInterfaceFactory $modelExtensionFactory,
        SalesOrderItemInfoRepositoryInterface $extensionAttributeRepository,
        SalesOrderItemInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getData('item');

        $this->extensionAttributeCrudManager->saveBefore(
            $quoteItem, 'extra_info', $this->extensionAttributeFactory
        );
    }
}
