<?php

namespace Maas\Sales\Observer\ExtensionAttributes\OrderItem;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterfaceFactory;
use Maas\Sales\Api\SalesOrderItemInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\OrderItemExtensionInterfaceFactory;

/**
 * Class OrderItemLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\OrderItem
 * @codeCoverageIgnore
 */
class OrderItemLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var OrderItemExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesOrderItemInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesOrderItemInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * OrderItemLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param OrderItemExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesOrderItemInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesOrderItemInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        OrderItemExtensionInterfaceFactory $modelExtensionFactory,
        SalesOrderItemInfoRepositoryInterface $extensionAttributeRepository,
        SalesOrderItemInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $item = $observer->getEvent()->getData('item');

        $this->extensionAttributeCrudManager->loadAfter(
            $item, $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
