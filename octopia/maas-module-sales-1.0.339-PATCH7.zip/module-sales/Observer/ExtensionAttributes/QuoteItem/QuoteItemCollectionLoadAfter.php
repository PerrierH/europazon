<?php

namespace Maas\Sales\Observer\ExtensionAttributes\QuoteItem;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\CartItemExtensionInterfaceFactory;
use Magento\Quote\Model\ResourceModel\Quote\Item\Collection;

/**
 * Class QuoteItemCollectionLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\QuoteItem
 * @codeCoverageIgnore
 */
class QuoteItemCollectionLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var CartItemExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteItemInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteItemInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteItemCollectionLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param CartItemExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteItemInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteItemInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        CartItemExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteItemInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteItemInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $collection = $observer->getEvent()->getData('collection');
        if ($collection instanceof Collection) {
            $this->extensionAttributeCrudManager->loadCollectionAfter(
                $collection, 'quote_item_id', $this->modelExtensionFactory, 'extra_info',
                $this->extensionAttributeRepository, $this->extensionAttributeFactory
            );
        }
    }
}
