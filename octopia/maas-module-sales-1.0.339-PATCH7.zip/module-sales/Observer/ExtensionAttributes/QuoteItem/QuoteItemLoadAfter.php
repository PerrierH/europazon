<?php

namespace Maas\Sales\Observer\ExtensionAttributes\QuoteItem;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Core\Observer\ExtensionAttributes\LoadAfterAbstract;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\CartItemExtensionInterfaceFactory;

/**
 * Class QuoteItemLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\QuoteItem
 * @codeCoverageIgnore
 */
class QuoteItemLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var CartItemExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteItemInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteItemInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteItemLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param CartItemExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteItemInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteItemInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        CartItemExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteItemInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteItemInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getData('item');

        $this->extensionAttributeCrudManager->loadAfter(
            $quoteItem, $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
