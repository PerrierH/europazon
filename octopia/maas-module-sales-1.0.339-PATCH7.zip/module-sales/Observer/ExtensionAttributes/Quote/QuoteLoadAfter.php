<?php

namespace Maas\Sales\Observer\ExtensionAttributes\Quote;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Core\Observer\ExtensionAttributes\LoadAfterAbstract;
use Maas\Sales\Api\Data\SalesQuoteInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\CartExtensionInterfaceFactory;

/**
 * Class QuoteLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\Quote
 * @codeCoverageIgnore
 */
class QuoteLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var CartExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param CartItemExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        CartExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getData('quote');

        $this->extensionAttributeCrudManager->loadAfter(
            $quoteItem, $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
