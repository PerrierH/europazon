<?php

namespace Maas\Sales\Observer\ExtensionAttributes\Quote;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesQuoteInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\CartItemExtensionInterfaceFactory;
use Magento\Quote\Model\ResourceModel\Quote\Collection;

/**
 * Class QuoteCollectionLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\Quote
 * @codeCoverageIgnore
 */
class QuoteCollectionLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var CartItemExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteCollectionLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param CartItemExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        CartItemExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $collection = $observer->getEvent()->getData('collection');
        if ($collection instanceof Collection) {
            $this->extensionAttributeCrudManager->loadCollectionAfter(
                $collection, 'entity_id', $this->modelExtensionFactory, 'extra_info',
                $this->extensionAttributeRepository, $this->extensionAttributeFactory
            );
        }
    }
}
