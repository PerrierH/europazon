<?php

namespace Maas\Sales\Observer\ExtensionAttributes\Quote;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesQuoteInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\CartExtensionInterfaceFactory;

/**
 * Class QuoteSaveBefore
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\Quote
 * @codeCoverageIgnore
 */
class QuoteSaveBefore implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var CartExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteSaveBefore constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param CartExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        CartExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getData('quote');

        $this->extensionAttributeCrudManager->saveBefore(
            $quoteItem, 'extra_info', $this->extensionAttributeFactory
        );
    }
}
