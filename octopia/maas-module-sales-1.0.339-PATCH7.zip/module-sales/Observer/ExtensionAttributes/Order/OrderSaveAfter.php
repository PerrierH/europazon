<?php

namespace Maas\Sales\Observer\ExtensionAttributes\Order;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesOrderInfoInterfaceFactory;
use Maas\Sales\Api\SalesOrderInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\OrderExtensionInterfaceFactory;

/**
 * Class OrderSaveAfter\ExtensionAttributes\Order
 *
 * @package Maas\Sales\Observer
 * @codeCoverageIgnore
 */
class OrderSaveAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var OrderExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesOrderInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesOrderInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * OrderSaveAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param OrderExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesOrderInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesOrderInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        OrderExtensionInterfaceFactory $modelExtensionFactory,
        SalesOrderInfoRepositoryInterface $extensionAttributeRepository,
        SalesOrderInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getData('order');

        $this->extensionAttributeCrudManager->saveAfter(
            $order, $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
