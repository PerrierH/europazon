<?php

namespace Maas\Sales\Observer\ExtensionAttributes\QuoteAddress;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Core\Observer\ExtensionAttributes\LoadAfterAbstract;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\AddressExtensionInterfaceFactory;

/**
 * Class QuoteAddressSaveAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\QuoteAddress
 * @codeCoverageIgnore
 */
class QuoteAddressSaveAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var AddressExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteSaveAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param AddressExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        AddressExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteAddressInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteAddressInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getData('quote_address');

        $this->extensionAttributeCrudManager->saveAfter(
            $quoteItem, $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
