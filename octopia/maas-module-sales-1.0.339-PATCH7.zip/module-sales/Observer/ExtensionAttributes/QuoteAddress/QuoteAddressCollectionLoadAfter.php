<?php

namespace Maas\Sales\Observer\ExtensionAttributes\QuoteAddress;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\AddressExtensionInterfaceFactory;
use Magento\Quote\Model\ResourceModel\Quote\Address\Collection;

/**
 * Class QuoteAddressCollectionLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\Quote
 * @codeCoverageIgnore
 */
class QuoteAddressCollectionLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var AddressExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteAddressInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteAddressInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteAddressCollectionLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param AddressExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteAddressInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteAddressInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        AddressExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteAddressInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteAddressInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $collection = $observer->getEvent()->getData('quote_address_collection');
        if ($collection instanceof Collection) {
            $this->extensionAttributeCrudManager->loadCollectionAfter(
                $collection, 'quote_address_id', $this->modelExtensionFactory, 'extra_info',
                $this->extensionAttributeRepository, $this->extensionAttributeFactory
            );
        }
    }
}
