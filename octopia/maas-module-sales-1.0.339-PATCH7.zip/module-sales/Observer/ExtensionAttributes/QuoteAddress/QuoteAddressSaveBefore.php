<?php

namespace Maas\Sales\Observer\ExtensionAttributes\QuoteAddress;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\Data\AddressExtensionInterfaceFactory;

/**
 * Class QuoteSaveBefore
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\QuoteAddress
 * @codeCoverageIgnore
 */
class QuoteAddressSaveBefore implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var AddressExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesQuoteInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesQuoteAddressInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * QuoteSaveBefore constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param AddressExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesQuoteAddressInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesQuoteAddressInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        AddressExtensionInterfaceFactory $modelExtensionFactory,
        SalesQuoteAddressInfoRepositoryInterface $extensionAttributeRepository,
        SalesQuoteAddressInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $quoteItem = $observer->getEvent()->getData('quote_address');

        $this->extensionAttributeCrudManager->saveBefore(
            $quoteItem, 'extra_info', $this->extensionAttributeFactory
        );
    }
}
