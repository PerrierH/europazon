<?php

namespace Maas\Sales\Observer\Adminhtml;

use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Layout;
use Magento\Sales\Api\OrderRepositoryInterface;

/**
 * Class AddMaasInfoToOrderView
 *
 * @package Maas\Sales\Observer\Adminhtml
 */
class AddMaasInfoToOrderView implements ObserverInterface
{
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * AddMaasInfoToOrderView constructor.
     *
     * @param OrderRepositoryInterface $orderRepository
     * @param RequestInterface $request
     */
    public function __construct(
        OrderRepositoryInterface $orderRepository,
        RequestInterface $request
    ) {
        $this->orderRepository = $orderRepository;
        $this->request = $request;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        // ['full_action_name' => $this->request->getFullActionName(), 'layout' => $this->layout]
        if ($observer->getEvent()->getFullActionName() == 'sales_order_view') {
            /** @var Layout $layout */
            $layout = $observer->getEvent()->getLayout();
            $id = $this->request->getParam('order_id');
            try {
                $order = $this->orderRepository->get($id);
                $extensionAttributes = $order->getExtensionAttributes();
                if ($extensionAttributes) {
                    $extraInfo = $extensionAttributes->getExtraInfo();
                    if ($extraInfo && $extraInfo->getOrderType() == SalesOrderInfo::ORDER_TYPE_MAAS) {
                        $layout->getUpdate()->addHandle('sales_order_view_marketplace');
                    }
                }
            } catch (NoSuchEntityException $e) {
                // do nothing
            } catch (InputException $e) {
                // do nothing
            }
        }
    }
}
