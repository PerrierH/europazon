<?php

namespace Maas\Sales\Block\Adminhtml\Form\Field;

use Maas\Sales\Exception\WrongColumnName;
use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\View\Element\BlockInterface;
use Magento\Payment\Api\Data\PaymentMethodInterface;
use Magento\Payment\Api\PaymentMethodListInterface;

/**
 * Class Payment
 *
 * @package Maas\Sales\Block\Adminhtml\Form\Field
 */
class MatchingPayments extends AbstractFieldArray
{
    const COLUMN_CODE_OCTOPIA_PAYMENT_METHOD = 'octopia_payment_code';
    const COLUMN_CODE_MAGENTO_PAYMENT_METHOD = 'magento_payment_methods';
    const COLUMN_CODE_PAYMENT_CODE = 'payment_code';
    const CONFIG_PATH_ORDER_MATCHING_BETWEEN_MAGENTO_AND_OCTOPIA_PAYMENTS = 'maas_orders/general/matching_between_octopia_and_magento_payment_methods';

    /**
     * @var string
     */
    protected $_template = 'Maas_Sales::system/config/form/field/array.phtml';
    /**
     * @var OctopiaPaymentColumn
     */
    private $octopiaPaymentRenderer;
    /**
     * Rows cache
     *
     * @var array|null
     */
    private $_arrayRowsCache;
    /**
     * @var PaymentMethodListInterface
     */
    private $paymentMethodList;

    /** @var SerializerInterface */
    private $serializer;

    /**
     * Payment constructor.
     *
     * @param Context $context
     * @param PaymentMethodListInterface $paymentMethodList
     * @param SerializerInterface $serializer
     * @param array $data
     */
    public function __construct(
        Context                    $context,
        PaymentMethodListInterface $paymentMethodList,
        SerializerInterface        $serializer,
        array                      $data = []
    )
    {
        parent::__construct($context, $data);
        $this->paymentMethodList = $paymentMethodList;
        $this->serializer = $serializer;
    }

    /**
     * Obtain existing data from form element
     *
     * Each row will be instance of \Magento\Framework\DataObject
     *
     * @return array
     * @throws LocalizedException
     */
    public function getArrayRows()
    {
        if (null !== $this->_arrayRowsCache) {
            return $this->_arrayRowsCache;
        }
        $result = [];
        $rowData = [];
        $count = 0;
        $columnCode = [self::COLUMN_CODE_PAYMENT_CODE, self::COLUMN_CODE_MAGENTO_PAYMENT_METHOD, self::COLUMN_CODE_OCTOPIA_PAYMENT_METHOD];
        $configValues = $this->_scopeConfig->getValue(self::CONFIG_PATH_ORDER_MATCHING_BETWEEN_MAGENTO_AND_OCTOPIA_PAYMENTS);
        $refactoredConfigValues = $this->_refactorConfigValues($configValues);
        foreach ($this->paymentMethodList->getList(0) as $paymentMethod) {
            $rowId = time() . '_' . $count;
            $rowColumnValues = [];
            if (empty($paymentMethod->getTitle())) {
                continue;
            }
            foreach ($columnCode as $value) {
                if ($this->_addValueToRowData($rowData, $value, $refactoredConfigValues, $paymentMethod) && array_key_exists($value, $rowData)) {
                    $rowColumnValues[$this->_getCellInputElementId($rowId, $value)] = $rowData[$value];
                }
            }
            $rowData['_id'] = $rowId;
            $rowData['column_values'] = $rowColumnValues;
            $result[$rowId] = new DataObject($rowData);
            $this->_prepareArrayRow($result[$rowId]);
            $count++;
        }
        $this->_arrayRowsCache = $result;
        return $this->_arrayRowsCache;
    }

    /**
     * @param string $configValues
     *
     * @return array
     */
    private function _refactorConfigValues($configValues)
    {
        $refactorConfigValue = [];
        if ($configValues !== null) {
            $unserializedConfigValue = $this->serializer->unserialize($configValues);
            foreach ($unserializedConfigValue as $data) {
                $refactorConfigValue[$data['payment_code']] = $data['octopia_payment_code'] ?? '';
            }
        }
        return $refactorConfigValue;
    }

    /**
     * @param array $rowData
     * @param string $value
     * @param array $refactoredConfigValues
     * @param PaymentMethodInterface $paymentMethod
     *
     * @return bool
     */
    private function _addValueToRowData(&$rowData, $value, $refactoredConfigValues, $paymentMethod)
    {
        if ($value == self::COLUMN_CODE_MAGENTO_PAYMENT_METHOD) {
            $rowData[$value] = $paymentMethod->getTitle();
        } elseif ($value == self::COLUMN_CODE_OCTOPIA_PAYMENT_METHOD) {
            if (empty($refactoredConfigValues) || (array_key_exists($paymentMethod->getCode(), $refactoredConfigValues) && $refactoredConfigValues[$paymentMethod->getCode()] === null)) {
                $rowData[$value] = null;
            } elseif (array_key_exists($paymentMethod->getCode(), $refactoredConfigValues)) {
                $rowData[$value] = $refactoredConfigValues[$paymentMethod->getCode()];
            }
        } elseif ($value == self::COLUMN_CODE_PAYMENT_CODE) {
            $rowData[$value] = $paymentMethod->getCode();
        }
        return in_array($value,
            [self::COLUMN_CODE_MAGENTO_PAYMENT_METHOD, self::COLUMN_CODE_OCTOPIA_PAYMENT_METHOD, self::COLUMN_CODE_PAYMENT_CODE]);
    }

    /**
     * Prepare existing row data object
     *
     * @param DataObject $row
     *
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     * @throws LocalizedException
     */
    protected function _prepareArrayRow(DataObject $row)
    {
        $options = [];
        $octopiaPaymentCode = $row->getOctopiaPaymentCode();
        if ($octopiaPaymentCode !== null) {
            foreach (explode(',', $octopiaPaymentCode) as $opc) {
                $options['option_' . $this->getOctopiaPaymentTypeRenderer()->calcOptionHash($opc)] = 'selected="selected"';
            }
        }

        $row->setData('option_extra_attrs', $options);
    }

    /**
     * @return OctopiaPaymentColumn |BlockInterface
     * @throws LocalizedException
     */
    private function getOctopiaPaymentTypeRenderer()
    {
        if (!$this->octopiaPaymentRenderer) {
            $this->octopiaPaymentRenderer = $this->getLayout()->createBlock(
                OctopiaPaymentColumn::class,
                '',
                ['data' => ['is_render_to_js_template' => true]]
            );
        }
        return $this->octopiaPaymentRenderer;
    }

    /**
     * Render array cell for prototypeJS template
     *
     * @param string $columnName
     *
     * @return string
     * @throws WrongColumnName
     */
    public function renderCellTemplate($columnName)
    {
        if (empty($this->_columns[$columnName])) {
            throw new WrongColumnName('Wrong column name specified.');
        }
        $column = $this->_columns[$columnName];
        $inputName = $this->_getCellInputElementName($columnName);
        // @codeCoverageIgnoreStart
        if ($column['renderer']) {
            return $column['renderer']->setInputName(
                $inputName
            )->setInputId(
                $this->_getCellInputElementId('<%- _id %>', $columnName)
            )->setColumnName(
                $columnName
            )->setColumn(
                $column
            )->toHtml();
        }
        // @codeCoverageIgnoreEnd
        if ($columnName === self::COLUMN_CODE_MAGENTO_PAYMENT_METHOD) {
            return sprintf(
                "<%%- %s %%>",
                $columnName
            );
        } else {
            return sprintf(
                "<input type=\"hidden\" id=\"%s\" name=\"%s\" value=\"<%%- %s %%>\"  class=\"%s\" readonly/>",
                $this->_getCellInputElementId(
                    '<%- _id %>',
                    $columnName
                ),
                $inputName,
                $columnName,
                'input-text'
            );
        }
    }

    /**
     * Get id for cell element
     *
     * @param string $columnName
     *
     * @return string
     */
    protected function _getCellInputElementName($columnName)
    {
        if ($columnName == self::COLUMN_CODE_OCTOPIA_PAYMENT_METHOD) {
            return parent::_getCellInputElementName($columnName) . '[]';
        }
        return parent::_getCellInputElementName($columnName);
    }

    /**
     * Prepare rendering the new field by adding all the needed columns
     *
     * @codeCoverageIgnore
     * @throws LocalizedException
     */
    protected function _prepareToRender()
    {
        $this->addColumn(self::COLUMN_CODE_PAYMENT_CODE, ['label' => ' ']);
        $this->addColumn(self::COLUMN_CODE_MAGENTO_PAYMENT_METHOD, ['label' => __('Magento Payment methods')]);
        $this->addColumn(self::COLUMN_CODE_OCTOPIA_PAYMENT_METHOD, [
            'label' => __('Octopia Payment methods'),
            'renderer' => $this->getOctopiaPaymentTypeRenderer()
        ]);
        $this->_addAfter = false;
    }
}
