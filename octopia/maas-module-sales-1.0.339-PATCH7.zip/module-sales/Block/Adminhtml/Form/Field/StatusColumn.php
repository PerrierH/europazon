<?php


namespace Maas\Sales\Block\Adminhtml\Form\Field;

use Maas\Sales\Model\Config\Source\Status;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Html\Select;

/**
 * Class StatusColumn
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Block\Adminhtml\Form\Field
 */
class StatusColumn extends Select
{

    /**
     * @var Status
     */
    private $status;

    /**
     * StatusColumn constructor.
     *
     * @param Context $context
     * @param Status $status
     * @param array $data
     */
    public function __construct(
        Context $context,
        Status $status,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->status = $status;
    }


    /**
     * Set "name" for <select> element
     *
     * @param string $value
     *
     * @return $this
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * Set "id" for <select> element
     *
     * @param $value
     *
     * @return $this
     */
    public function setInputId($value)
    {
        return $this->setId($value);
    }

    /**
     * Render block HTML
     *
     * @return string
     */
    public function _toHtml(): string
    {
        $this->setExtraParams('multiple');
        if (!$this->getOptions()) {
            $this->setOptions($this->getSourceOptions());
        }
        return parent::_toHtml();
    }

    /**
     * @return array
     */
    private function getSourceOptions(): array
    {
        $orderStatus = $this->status->toOptionArray();
        foreach ($orderStatus as $key => $status) {
            if (strpos($status['value'], 'maas') !== false) {
                unset($orderStatus[$key]);
            }
        }
        return $orderStatus;
    }
}

