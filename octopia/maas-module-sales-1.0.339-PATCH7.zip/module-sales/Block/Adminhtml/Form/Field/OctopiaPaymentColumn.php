<?php


namespace Maas\Sales\Block\Adminhtml\Form\Field;

use Maas\Sales\Model\Config\Source\OctopiaPaymentType;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Html\Select;

/**
 * Class OctopiaPaymentColumn
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Block\Adminhtml\Form\Field
 */
class OctopiaPaymentColumn extends Select
{

    /**
     * @var OctopiaPaymentType
     */
    private $octopiaPaymentType;

    /**
     * OctopiaPaymentColumn constructor.
     *
     * @param Context $context
     * @param OctopiaPaymentType $octopiaPaymentType
     * @param array $data
     */
    public function __construct(
        Context            $context,
        OctopiaPaymentType $octopiaPaymentType,
        array              $data = []
    )
    {
        parent::__construct($context, $data);
        $this->octopiaPaymentType = $octopiaPaymentType;
    }


    /**
     * Set "name" for <select> element
     *
     * @param string $value
     *
     * @return $this
     */
    public function setInputName($value)
    {
        return $this->setName($value);
    }

    /**
     * Set "id" for <select> element
     *
     * @param $value
     *
     * @return $this
     */
    public function setInputId($value)
    {
        return $this->setId($value);
    }

    /**
     * Render block HTML
     *
     * @return string
     */
    public function _toHtml(): string
    {
        if (!$this->getOptions()) {
            $this->setOptions($this->getSourceOptions());
        }
        return parent::_toHtml();
    }

    /**
     * @return array
     */
    private function getSourceOptions(): array
    {
        return $this->octopiaPaymentType->toOptionArray();
    }
}

