<?php

namespace Maas\Sales\Block\Adminhtml\Items\Column;

/**
 * Class ShippingMethod
 * @codeCoverageIgnore
 * @package Maas\Sales\Block\Adminhtml\Items\Column
 */
class ShippingMethod extends DefaultColumn
{

}
