<?php

namespace Maas\Sales\Block\Adminhtml\Items\Column;

use Maas\Core\Model\Config;
use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Model\Product\OptionFactory;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Registry;

/**
 * Class DefaultColumn
 *
 * @package Maas\Sales\Block\Adminhtml\Items\Column
 */
class DefaultColumn extends \Magento\Sales\Block\Adminhtml\Items\Column\DefaultColumn
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * DefaultColumn constructor.
     * @param Context $context
     * @param StockRegistryInterface $stockRegistry
     * @param StockConfigurationInterface $stockConfiguration
     * @param Registry $registry
     * @param OptionFactory $optionFactory
     * @param Config $configModel
     * @param array $data
     */
    public function __construct(
        Context $context,
        StockRegistryInterface $stockRegistry,
        StockConfigurationInterface $stockConfiguration,
        Registry $registry,
        OptionFactory $optionFactory,
        Config $configModel,
        array $data = []
    ) {
        $this->configModel = $configModel;
        parent::__construct($context, $stockRegistry, $stockConfiguration, $registry, $optionFactory, $data);
    }

    /**
     * @return string
     * @throws LocalizedException
     */
    public function getOfferId()
    {
        if ($this->getItem() && $this->isMaasModuleEnabled()) {
            $extensionAttribute = $this->getItem()->getExtensionAttributes()->getExtraInfo();
            return $extensionAttribute->getOfferMaasId();
        }
        return '';
    }

    /**
     * @return string
     * @throws LocalizedException
     */
    public function getSellerName()
    {
        if ($this->getOrder() && $this->isMaasModuleEnabled()) {
            $extensionAttribute = $this->getOrder()->getExtensionAttributes()->getExtraInfo();
            return $extensionAttribute->getSellerName();
        }
        return '';
    }

    /**
     * @return string
     * @throws LocalizedException
     */
    public function getStatus()
    {
        if ($this->getItem() && $this->isMaasModuleEnabled()) {
            $extensionAttribute = $this->getItem()->getExtensionAttributes()->getExtraInfo();
            return $extensionAttribute->getStatus();
        }
        return '';
    }

    /**
     * @return bool
     */
    private function isMaasModuleEnabled()
    {
        return $this->configModel->isModuleEnabled();
    }

    /**
     * @return string
     */
    public function getShippingMethod()
    {
        if ($this->getItem() && $this->isMaasModuleEnabled()) {
            return ucfirst($this->getExtraInfoItem()->getShippingMethod() ?? '');
        }
        return '';
    }

    /**
     * @return mixed
     */
    private function getExtraInfoItem()
    {
        return $this->getItem()->getExtensionAttributes()->getExtraInfo();
    }
}
