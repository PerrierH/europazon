<?php

namespace  Maas\Sales\Block\Adminhtml\Items\Renderer;

use Maas\Core\Model\Config;
use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;
use Magento\Sales\Model\Order\Shipment\Item;

/**
 * Class DefaultRenderer
 *
 * @package Maas\Sales\Block\Adminhtml\Items\Renderer
 */
class DefaultRenderer extends \Magento\Sales\Block\Adminhtml\Items\Renderer\DefaultRenderer
{
    /**
     * @var Config
     */
    private $configModel;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * DefaultRenderer constructor.
     *
     * @param Context $context
     * @param StockRegistryInterface $stockRegistry
     * @param StockConfigurationInterface $stockConfiguration
     * @param Registry $registry
     * @param Config $configModel
     * @param ProductRepositoryInterface $productRepository
     * @param array $data
     */
    public function __construct(
        Context $context,
        StockRegistryInterface $stockRegistry,
        StockConfigurationInterface $stockConfiguration,
        Registry $registry,
        Config $configModel,
        ProductRepositoryInterface $productRepository,
        array $data = []
    ) {
        $this->configModel = $configModel;
        $this->productRepository = $productRepository;
        parent::__construct($context, $stockRegistry, $stockConfiguration, $registry, $data);
    }


    /**
     * @return bool
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getHead()
    {
        $sellerId = '';
        if ($this->getItem() instanceof Item) {
            $product = $this->productRepository->get($this->getItem()->getSku());
            $sellerId = $product->getMaasOfferSellerId();
        } else {
            $sellerId = $this->getOrder()->getExtensionAttributes()->getExtraInfo()->getSellerId();
        }
        return $this->configModel->isModuleEnabled() && !empty($sellerId);
    }
}
