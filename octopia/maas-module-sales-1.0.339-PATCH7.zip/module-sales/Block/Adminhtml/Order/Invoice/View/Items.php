<?php

namespace Maas\Sales\Block\Adminhtml\Order\Invoice\View;

use Maas\Core\Model\Config;
use Magento\Backend\Block\Template\Context;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Registry;

/**
 * Class Items
 * @codeCoverageIgnore
 * No need here already test on /Creditmemo/View/Items
 * @package Maas\Sales\Block\Adminhtml\Order\Invoice\View
 */
class Items extends \Magento\Sales\Block\Adminhtml\Order\Invoice\View\Items
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * Items constructor.
     *
     * @param Context $context
     * @param StockRegistryInterface $stockRegistry
     * @param StockConfigurationInterface $stockConfiguration
     * @param Registry $registry
     * @param Config $configModel
     * @param array $data
     */
    public function __construct(
        Context $context,
        StockRegistryInterface $stockRegistry,
        StockConfigurationInterface $stockConfiguration,
        Registry $registry,
        Config $configModel,
        array $data = []
    ) {
        $this->configModel = $configModel;
        parent::__construct($context, $stockRegistry, $stockConfiguration, $registry, $data);
    }


    /**
     * @return bool
     */
    public function getHead()
    {
        $sellerId = $this->getOrder()->getExtensionAttributes()->getExtraInfo()->getSellerId();
        return $this->configModel->isModuleEnabled() && $sellerId;
    }
}
