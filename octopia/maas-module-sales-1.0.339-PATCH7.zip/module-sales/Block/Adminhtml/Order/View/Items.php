<?php

namespace Maas\Sales\Block\Adminhtml\Order\View;

use Maas\Core\Model\Config;
use Magento\Backend\Block\Template\Context;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Registry;

/**
 * Class Items
 * @package Maas\Sales\Block\Adminhtml\Order\View
 */
class Items extends \Magento\Sales\Block\Adminhtml\Order\View\Items
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * Items constructor.
     * @param Context $context
     * @param StockRegistryInterface $stockRegistry
     * @param StockConfigurationInterface $stockConfiguration
     * @param Registry $registry
     * @param Config $configModel
     * @param array $data
     */
    public function __construct(
        Context $context,
        StockRegistryInterface $stockRegistry,
        StockConfigurationInterface $stockConfiguration,
        Registry $registry,
        Config $configModel,
        array $data = []
    ) {
        $this->configModel = $configModel;
        parent::__construct($context, $stockRegistry, $stockConfiguration, $registry, $data);
    }

    /**
     * @return array
     * @throws LocalizedException
     */
    public function getColumns()
    {
        $columns = $this->_data['columns'];
        $extensionAttribute = $this->getOrder()->getExtensionAttributes()->getExtraInfo();
        if ((isset($columns['maas_offer_id']) || isset($columns['maas_seller_id'])) &&
            (!$this->configModel->isModuleEnabled() || !$extensionAttribute->getSellerId())) {
                unset($columns['maas_offer_id']);
                unset($columns['maas_seller_name']);
                unset($columns['maas_shipping_method']);
                $this->_data['columns'] = $columns;
        }
        return parent::getColumns();
    }
}
