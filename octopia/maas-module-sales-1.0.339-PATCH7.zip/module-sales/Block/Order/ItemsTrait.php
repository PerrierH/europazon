<?php

namespace Maas\Sales\Block\Order;

use Exception;
use Magento\Sales\Model\Order\Item;

/**
 * Trait ItemsTrait
 *
 * @codeCoverageIgnore Delegates to service model
 * @package Maas\Sales\Block\Order
 */
trait ItemsTrait
{
    /**
     * @return bool
     */
    public function isRenderSellerName()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());
    }

    /**
     * @return string|null
     */
    public function displaySellerName()
    {
        return $this->getExtensionAttributes()->getSellerName();
    }

    /**
     * @return mixed
     */
    private function getExtensionAttributes()
    {
        return $this->getOrder()->getExtensionAttributes()->getExtraInfo();
    }

    /**
     * @return bool
     */
    public function isRenderDeliveryDates($item)
    {
        return !empty($this->getMinDeliveryDate($item))
            && !empty($this->getMaxDeliveryDate($item))
            && $this->config->isModuleEnabled();
    }

    /**
     * @param $item
     *
     * @return mixed
     */
    private function getMinDeliveryDate($item)
    {
        return $this->getExtensionItemAttributes($item)->getDeliveryDateMin();
    }

    /**
     * @return mixed
     */
    private function getExtensionItemAttributes($item)
    {
        if ($item instanceof Item) {
            return $item->getExtensionAttributes()->getExtraInfo();
        }
        return $item->getOrderItem()->getExtensionAttributes()->getExtraInfo();
    }

    /**
     * @param $item
     *
     * @return mixed
     */
    private function getMaxDeliveryDate($item)
    {
        return $this->getExtensionItemAttributes($item)->getDeliveryDateMax();
    }

    /**
     * @param $item
     *
     * @return false|string
     * @throws Exception
     */
    public function getDeliveryDates($item)
    {
        if (($this->getMinDeliveryDate($item) === null) || ($this->getMaxDeliveryDate($item) === null)) {
            return false;
        }
        $minDate = $this->timezone->date(strtotime($this->getMinDeliveryDate($item)));
        $maxDate = $this->timezone->date(strtotime($this->getMaxDeliveryDate($item)));

        return $this->productDeliveryService->getDeliveryEstimatedDates(
            null,
            $this->timezone,
            $minDate,
            $maxDate
        );
    }
}