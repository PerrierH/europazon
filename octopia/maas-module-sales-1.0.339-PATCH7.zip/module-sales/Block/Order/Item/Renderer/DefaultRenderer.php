<?php

namespace Maas\Sales\Block\Order\Item\Renderer;

use Maas\Core\Model\Config;
use Maas\Sales\Model\Service\OrderType;
use Magento\Catalog\Model\Product\OptionFactory;
use Magento\Framework\Stdlib\StringUtils;
use Magento\Framework\View\Element\Template\Context;
use Maas\Catalog\Model\Service\ProductDelivery;
use Magento\Sales\Block\Order\Item\Renderer\DefaultRenderer as MagentoDefaultRenderer;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

/**
 * Class DefaultRenderer
 *
 * @package Maas\Sales\Block\Order\Item\Renderer
 */
class DefaultRenderer extends MagentoDefaultRenderer
{
    /**
     * @var Config
     */
    private $config;

    /** @var ProductDelivery */
    private $productDelivery;

    /** @var TimezoneInterface */
    private $timezone;

    /** @var OrderType */
    private $orderTypeService;

    /**
     * DefaultRenderer constructor.
     *
     * @param Context $context
     * @param StringUtils $string
     * @param OptionFactory $productOptionFactory
     * @param Config $config
     * @param ProductDelivery $productDelivery
     * @param TimezoneInterface $timezone
     * @param OrderType $orderTypeService
     * @param array $data
     */
    public function __construct(
        Context $context,
        StringUtils $string,
        OptionFactory $productOptionFactory,
        Config $config,
        ProductDelivery $productDelivery,
        TimezoneInterface $timezone,
        OrderType $orderTypeService,
        array $data = []
    ) {
        $this->config = $config;
        $this->productDelivery = $productDelivery;
        $this->timezone = $timezone;
        $this->orderTypeService = $orderTypeService;
        parent::__construct($context, $string, $productOptionFactory, $data);
    }

    /**
     * @return mixed
     * @codeCoverageIgnore
     */
    private function getExtensionAttributes()
    {
        return $this->getOrder()->getExtensionAttributes()->getExtraInfo();
    }

    /**
     * @return bool
     */
    public function isRenderSellerName()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());
    }

    /**
     * @return bool
     */
    public function isOrderMarketplace()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());
    }
    
    /**
     * @return string|null
     * @codeCoverageIgnore
     */
    public function displaySellerName()
    {
        return $this->getExtensionAttributes()->getSellerName();
    }

    /**
     * @return string|null
     * @codeCoverageIgnore
     */
    public function getRicStatus()
    {
        return $this->getItemExtensionAttributes()->getStatus();
    }

    /**
     * @return mixed
     */
    private function getItemExtensionAttributes()
    {
        return $this->getOrderItem()->getExtensionAttributes()->getExtraInfo();
    }

    /**
     * @return bool
     */
    public function isRenderDeliveryDates()
    {
        return !empty($this->getItemExtensionAttributes()->getDeliveryDateMin())
            && !empty($this->getItemExtensionAttributes()->getDeliveryDateMax())
            && $this->config->isModuleEnabled();
    }

    public function getDeliveryDates()
    {
        if (($this->getItemExtensionAttributes()->getDeliveryDateMin() === null) || ($this->getItemExtensionAttributes()->getDeliveryDateMax() === null)) {
            return false;
        }
        $minDate = $this->timezone->date(strtotime($this->getItemExtensionAttributes()->getDeliveryDateMin()));
        $maxDate = $this->timezone->date(strtotime($this->getItemExtensionAttributes()->getDeliveryDateMax()));

        return $this->productDelivery->getDeliveryEstimatedDates(
            null,
            $this->timezone,
            $minDate,
            $maxDate,
            $this->getItemExtensionAttributes()->getShippingMethod()
        );
    }

}
