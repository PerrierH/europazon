<?php

namespace Maas\Sales\Block\Order\Email\Items\Order;

use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Core\Model\Config;
use Maas\Sales\Block\Order\ItemsTrait;
use Maas\Sales\Model\Service\OrderType;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Block\Order\Email\Items\Order\DefaultOrder as MagentoDefaultOrder;

/**
 * Class DefaultOrder
 *
 * @package Maas\Sales\Block\Order\Email\Items\Order
 * @codeCoverageIgnore
 */
class DefaultOrder extends MagentoDefaultOrder
{
    use ItemsTrait;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var Config
     */
    private $config;

    /**
     * @var ProductDelivery
     */
    private $productDeliveryService;
    /**
     * @var TimezoneInterface
     */
    private $timezone;

    /**
     * @var OrderType
     */
    private $orderTypeService;

    /**
     * DefaultOrder constructor.
     *
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param Config $config
     * @param ProductDelivery $productDeliveryService
     * @param TimezoneInterface $timezone
     * @param array $data
     */
    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        Config $config,
        ProductDelivery $productDeliveryService,
        TimezoneInterface $timezone,
        OrderType $orderTypeService,
        array $data = []
    ) {
        $this->productRepository = $productRepository;
        $this->config = $config;
        $this->productDeliveryService = $productDeliveryService;
        $this->timezone = $timezone;
        $this->orderTypeService = $orderTypeService;
        parent::__construct($context, $data);
    }

}
