<?php

namespace Maas\Sales\Block\Order\Email\Items;

use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Core\Model\Config;
use Maas\Sales\Block\Order\ItemsTrait;
use Maas\Sales\Model\Service\OrderType;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Block\Order\Email\Items\DefaultItems as MagentoDefaultItems;

/**
 * Class DefaultItems
 *
 * @package Maas\Sales\Block\Order\Email\Items
 * @codeCoverageIgnore
 */
class DefaultItems extends MagentoDefaultItems
{
    use ItemsTrait;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var Config
     */
    private $config;
    /**
     * @var ProductDelivery
     */
    private $productDeliveryService;
    /**
     * @var TimezoneInterface
     */
    private $timezone;
    /**
     * @var OrderType
     */
    private $orderTypeService;

    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        Config $config,
        ProductDelivery $productDeliveryService,
        TimezoneInterface $timezone,
        OrderType $orderTypeService,
        array $data = []
    ) {
        $this->productRepository = $productRepository;
        $this->config = $config;
        $this->productDeliveryService = $productDeliveryService;
        $this->timezone = $timezone;
        $this->orderTypeService = $orderTypeService;
        parent::__construct($context, $data);
    }

}
