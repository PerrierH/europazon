<?php

namespace Maas\Sales\Block\Order\Invoice;

use Maas\Core\Model\Config;
use Maas\Sales\Model\Service\OrderType;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Block\Order\Invoice\Items as MagentoItems;
use Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory;

/**
 * Class Items
 *
 * @package Maas\Sales\Block\Order\Invoice
 * @codeCoverageIgnore delegates all logic
 */
class Items extends MagentoItems
{
    /**
     * @var OrderType
     */
    private $orderTypeService;

    /**
     * Items constructor.
     * @param Context $context
     * @param Registry $registry
     * @param Config $config
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        OrderType $orderType,
        array $data = []
    ) {
        $this->orderTypeService = $orderType;
        parent::__construct($context, $registry, $data);
    }

    /**
     * @return bool
     */
    public function isRenderColumnSeller()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());
    }
}
