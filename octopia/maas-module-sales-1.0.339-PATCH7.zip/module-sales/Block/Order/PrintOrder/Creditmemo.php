<?php

namespace Maas\Sales\Block\Order\PrintOrder;

use Maas\Sales\Model\Service\OrderType;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Payment\Helper\Data;
use Magento\Sales\Block\Order\PrintOrder\Creditmemo as MagentoPrintCreditmemo;
use Magento\Sales\Model\Order\Address\Renderer;
use Maas\Core\Model\Config;

/**
 * Class Creditmemo
 *
 * @package Maas\Sales\Block\Order\PrintOrder
 * @codeCoverageIgnore delegates all logic
 */
class Creditmemo extends MagentoPrintCreditmemo
{
    /**
     * @var OrderType
     */
    private $orderTypeService;

    /**
     * Creditmemo constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Data $paymentHelper
     * @param Renderer $addressRenderer
     * @param Config $config
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Data $paymentHelper,
        Renderer $addressRenderer,
        OrderType $orderTypeService,
        array $data = []
    ) {
        $this->orderTypeService = $orderTypeService;
        parent::__construct($context, $registry, $paymentHelper, $addressRenderer, $data);
    }


    /**
     * @return bool
     */
    public function isRenderColumnSellerPrintCreditMemo()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());
    }
}
