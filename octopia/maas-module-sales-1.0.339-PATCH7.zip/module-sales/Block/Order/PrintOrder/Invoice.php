<?php

namespace Maas\Sales\Block\Order\PrintOrder;

use Maas\Core\Model\Config;
use Maas\Sales\Model\Service\OrderType;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Payment\Helper\Data;
use Magento\Sales\Block\Order\PrintOrder\Invoice as MagentoInvoice;
use Magento\Sales\Model\Order\Address\Renderer;

/**
 * Class Invoice
 *
 * @package Maas\Sales\Block\Order\PrintOrder
 * @codeCoverageIgnore delegates all logic
 */
class Invoice extends MagentoInvoice
{
    /**
     * @var OrderType
     */
    private $orderTypeService;

    /**
     * Invoice constructor.
     * @param Context $context
     * @param Registry $registry
     * @param Data $paymentHelper
     * @param Renderer $addressRenderer
     * @param Config $config
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Data $paymentHelper,
        Renderer $addressRenderer,
        OrderType $orderTypeService,
        array $data = []
    )
    {
        $this->orderTypeService = $orderTypeService;
        parent::__construct($context, $registry, $paymentHelper, $addressRenderer, $data);
    }

    /**
     * @return bool
     */
    public function isRenderColumnSeller()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());
    }
}
