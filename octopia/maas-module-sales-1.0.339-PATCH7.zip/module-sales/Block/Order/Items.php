<?php

namespace Maas\Sales\Block\Order;

use Maas\Sales\Model\Service\OrderType;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Block\Order\Items as MagentoItems;
use Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory;

/**
 * Class Items
 *
 * @codeCoverageIgnore Delegates to service model
 * @package Maas\Sales\Block\Order
 */
class Items extends MagentoItems
{
    /**
     * @var OrderType
     */
    private $orderType;

    /**
     * Items constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param OrderType $orderType
     * @param array $data
     * @param CollectionFactory|null $itemCollectionFactory
     */
    public function __construct(
        Context $context,
        Registry $registry,
        OrderType $orderType,
        array $data = [],
        CollectionFactory $itemCollectionFactory = null
    ) {
        $this->orderType = $orderType;
        parent::__construct($context, $registry, $data, $itemCollectionFactory);
    }

    /**
     * @return bool
     */
    public function isRenderColumnSeller()
    {
        return $this->orderType->isOrderMarketplace($this->getOrder());
    }

    /**
     * @return bool
     */
    public function isOrderMarketplace()
    {
        return $this->orderType->isOrderMarketplace($this->getOrder());
    }
}
