<?php

namespace Maas\Sales\Block\Order\Creditmemo;

use Maas\Core\Model\Config;
use Maas\Sales\Model\Service\OrderType;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Block\Order\Creditmemo\Items as MagentoCreditMemoItem;

/**
 * Class Items
 *
 * @package Maas\Sales\Block\Order\Creditmemo
 * @codeCoverageIgnore delegates all logic
 */
class Items extends MagentoCreditMemoItem
{
    /**
     * @var OrderType
     */
    private $orderType;

    /**
     * Items constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Config $config
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        OrderType $orderType,
        array $data = []
    ) {
        $this->orderType = $orderType;
        parent::__construct($context, $registry, $data);
    }


    /**
     * @return bool
     */
    public function isRenderColumnSellerCreditmemo()
    {
        return $this->orderType->isOrderMarketplace($this->getOrder());
    }
}
