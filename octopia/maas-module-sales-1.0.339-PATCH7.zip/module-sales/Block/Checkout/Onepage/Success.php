<?php

namespace Maas\Sales\Block\Checkout\Onepage;

/**
 * Class Success
 *
 * @package Maas\Sales\Block\Checkout\Onepage
 */
class Success extends \Magento\Checkout\Block\Onepage\Success
{

    /**
     * Return list of orders' ids
     *
     * @return string
     */
    public function getOrdersIdList()
    {
        $orders = [];
        foreach ($this->getOrdersData() as $order) {
            $str = $order['order_id'];
            if ($order['can_view_order']) {
                $str = '<a href="' . $this->escapeUrl($order['view_order_url']) . '"><strong>' . $str . '</strong></a>';
            }
            $orders[] = '<span>' . $str . '</span>';
        }

        return implode(', ', $orders);
    }

    /**
     * Prepares block data
     *
     * @return void
     */
    protected function prepareBlockData()
    {
        if (!$this->hasMultipleOrders()) {
            $this->addData(
                [
                    'hasMultipleOrders' => false
                ]
            );
            parent::prepareBlockData();
        } else {
            $ordersData = [];
            foreach ($this->getMaasSession()->getOrders() as $order) {
                $ordersData[] = [
                    'is_order_visible' => $this->isVisible($order),
                    'view_order_url' => $this->getUrl(
                        'sales/order/view/',
                        ['order_id' => $order->getEntityId()]
                    ),
                    'print_url' => $this->getUrl(
                        'sales/order/print',
                        ['order_id' => $order->getEntityId()]
                    ),
                    'can_print_order' => $this->isVisible($order),
                    'can_view_order' => $this->canViewOrder($order),
                    'order_id' => $order->getIncrementId()
                ];
            }
            $this->addData(
                [
                    'hasMultipleOrders' => true,
                    'orders_data' => $ordersData
                ]
            );
        }
    }

    /**
     * @return bool
     */
    public function hasMultipleOrders()
    {
        return $this->getMaasSession()->hasMultipleOrders();
    }
}
