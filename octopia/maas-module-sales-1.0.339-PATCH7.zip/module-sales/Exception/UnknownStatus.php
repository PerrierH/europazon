<?php

namespace Maas\Sales\Exception;

use Exception;

class UnknownStatus extends Exception
{

}
