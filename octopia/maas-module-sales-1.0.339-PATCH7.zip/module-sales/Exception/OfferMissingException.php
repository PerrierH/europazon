<?php

namespace Maas\Sales\Exception;

use Magento\Framework\Exception\LocalizedException;

class OfferMissingException extends LocalizedException
{

}
