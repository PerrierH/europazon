<?php

namespace Maas\Sales\Exception;

use Exception;

class NoMatchingOctopiaPaymentCode extends Exception
{

}
