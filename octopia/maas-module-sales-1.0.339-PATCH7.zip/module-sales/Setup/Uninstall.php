<?php

namespace Maas\Sales\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 *
 * @package Maas\Sales\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    const  TABLE_MAAS_SALES_ORDER_INFO = 'maas_sales_order_info';
    const  TABLE_MAAS_SALES_ORDER_ITEM_INFO = 'maas_sales_order_item_info';
    const  TABLE_MAAS_SALES_QUOTE_ITEM_INFO = 'maas_sales_quote_item_info';
    const  TABLE_MAAS_SALES_QUOTE_ADDRESS_INFO = 'maas_sales_quote_address_info';
    const  TABLE_MAAS_SALES_QUOTE_INFO = 'maas_sales_quote_info';
    const  TABLE_SALES_ORDER_STATUS = 'sales_order_status';
    const TABLE_MAAS_SALES_QUOTE_ADDRESS_ITEM_INFO = 'maas_sales_quote_address_item_info';

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connexion = $setup->getConnection();
        $connexion->dropTable(self::TABLE_MAAS_SALES_ORDER_INFO);
        $connexion->dropTable(self::TABLE_MAAS_SALES_ORDER_ITEM_INFO);
        $connexion->dropTable(self::TABLE_MAAS_SALES_QUOTE_ITEM_INFO);
        $connexion->dropTable(self::TABLE_MAAS_SALES_QUOTE_ADDRESS_ITEM_INFO);
        $connexion->dropTable(self::TABLE_MAAS_SALES_QUOTE_ADDRESS_INFO);
        $connexion->dropTable(self::TABLE_MAAS_SALES_QUOTE_INFO);
        $maasSalesOrderStatusTable = $setup->getTable(self::TABLE_SALES_ORDER_STATUS);
        $connexion->delete($maasSalesOrderStatusTable, ['`status` LIKE ?' => 'maas_%']);
        $connexion->dropColumn('sales_order_grid', 'order_type');
    }
}
