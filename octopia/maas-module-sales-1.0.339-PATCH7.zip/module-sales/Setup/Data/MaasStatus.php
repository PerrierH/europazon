<?php

namespace Maas\Sales\Setup\Data;

use Maas\Sales\Model\Service\Data\OrderStatus;

/**
 * Class MaasSatus
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Setup\Data
 */
class MaasStatus
{
    public function getMaasOrderStatus()
    {
        return [
            [
                'status' => OrderStatus::STATUS_EXPORTED,
                'label' => 'Order exported'
            ],
            [
                'status' => OrderStatus::STATUS_PROCESSING,
                'label' => 'Processing'
            ],
            [
                'status' => OrderStatus::STATUS_ACCEPTED,
                'label' => 'Accepted'
            ],
            [
                'status' => OrderStatus::STATUS_IN_PREPARATION,
                'label' => 'InPreparation'
            ],
            [
                'status' => OrderStatus::STATUS_SHIPPED,
                'label' => 'Shipped'
            ],
            [
                'status' => OrderStatus::STATUS_DELIVERED,
                'label' => 'Delivered'
            ],
            [
                'status' => OrderStatus::STATUS_REJECTED,
                'label' => 'Rejected'
            ],
            [
                'status' => OrderStatus::STATUS_CANCELED,
                'label' => 'Cancelled'
            ]
        ];
    }
}
