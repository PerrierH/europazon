<?php

namespace Maas\Sales\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;


class UpgradeSchema extends AbstractInstaller implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $setup->getConnection()->addColumn(
                $setup->getTable('maas_sales_order_info'),
                'order_maas_id',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => 255,
                    'nullable' => true,
                    'comment' => 'Order Maas ID'
                ]
            );
        }

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            $this->addSalesOrderItemStatus($setup, $setup->getConnection());
        }

        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            $this->removeForeignKeys($setup, $setup->getConnection());
        }

        if (version_compare($context->getVersion(), '1.0.4', '<')) {
            $this->addNewShippingAmountInfo($setup, $setup->getConnection());
        }

        if (version_compare($context->getVersion(), '1.0.5', '<')) {
            $this->addNewShippingAmountInfoToAdressItem($setup, $setup->getConnection());
        }

        if (version_compare($context->getVersion(), '1.0.6', '<')) {
            $this->addMaasInfoToAdressItem($setup, $setup->getConnection());
        }

        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function addSalesOrderItemStatus($setup, $connection)
    {
        if ($setup->tableExists('maas_sales_order_item_info')) {
            $connection->addColumn(
                $connection->getTableName('maas_sales_order_item_info'),
                'original_taxes',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => 640,
                    'comment' => 'Original Taxes'
                ]
            );
        }
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function removeForeignKeys($setup, $connection)
    {
        if ($setup->tableExists('maas_sales_order_item_info')) {
            /** Remove offer_id foreignKey */
            $offerForeignKeyName = $connection->getForeignKeyName(
                $setup->getTable('maas_sales_order_item_info'),
                'offer_id',
                $setup->getTable('maas_offer'),
                'entity_id'
            );
            $connection->dropForeignKey('maas_sales_order_item_info', $offerForeignKeyName);
        }

        if ($setup->tableExists('maas_sales_quote_item_info')) {
            /** Remove offer_id foreignKey */
            $offerForeignKeyName = $connection->getForeignKeyName(
                $setup->getTable('maas_sales_quote_item_info'),
                'offer_id',
                $setup->getTable('maas_offer'),
                'entity_id'
            );

            $connection->dropForeignKey('maas_sales_quote_item_info', $offerForeignKeyName);

            /** Remove seller_id foreignKey */
            $sellerForeignKeyName = $connection->getForeignKeyName(
                $setup->getTable('maas_sales_quote_item_info'),
                'seller_id',
                $setup->getTable('maas_seller_entity'),
                'entity_id'
            );
            $connection->dropForeignKey('maas_sales_quote_item_info', $sellerForeignKeyName);
        }
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function addNewShippingAmountInfo($setup, $connection)
    {
        if ($setup->tableExists('maas_sales_quote_item_info')) {
            $connection->addColumn(
                $connection->getTableName('maas_sales_quote_item_info'),
                'original_shipping_amount',
                [
                    'type' => Table::TYPE_DECIMAL,
                    'length' => '12,4',
                    'comment' => 'Quote Item Original Shipping amount',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );

            $connection->addColumn(
                $connection->getTableName('maas_sales_quote_item_info'),
                'discounted_shipping_amount',
                [
                    'type' => Table::TYPE_DECIMAL,
                    'length' => '12,4',
                    'comment' => 'Quote Item Discounted Shipping amount',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );
        }

        if ($setup->tableExists('maas_sales_order_item_info')) {
            $connection->addColumn(
                $connection->getTableName('maas_sales_order_item_info'),
                'original_shipping_amount',
                [
                    'type' => Table::TYPE_DECIMAL,
                    'length' => '12,4',
                    'comment' => 'Order Item Original Shipping amount',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );

            $connection->addColumn(
                $connection->getTableName('maas_sales_order_item_info'),
                'discounted_shipping_amount',
                [
                    'type' => Table::TYPE_DECIMAL,
                    'length' => '12,4',
                    'comment' => 'Order Item Discounted Shipping amount',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );
        }
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function addNewShippingAmountInfoToAdressItem($setup, $connection)
    {
        if ($setup->tableExists('maas_sales_quote_address_item_info')) {
            $connection->addColumn(
                $connection->getTableName('maas_sales_quote_address_item_info'),
                'original_shipping_amount',
                [
                    'type' => Table::TYPE_DECIMAL,
                    'length' => '12,4',
                    'comment' => 'Quote Address Item Original Shipping amount',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );

            $connection->addColumn(
                $connection->getTableName('maas_sales_quote_address_item_info'),
                'discounted_shipping_amount',
                [
                    'type' => Table::TYPE_DECIMAL,
                    'length' => '12,4',
                    'comment' => 'Quote Address Item Discounted Shipping amount',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );
        }
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function addMaasInfoToAdressItem($setup, $connection)
    {
        if ($setup->tableExists('maas_sales_quote_address_item_info')) {
            $connection->addColumn(
                $connection->getTableName('maas_sales_quote_address_item_info'),
                'offer_id',
                [
                    'type' => Table::TYPE_INTEGER,
                    'comment' => 'Quote Address Item Offer Id',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );

            $connection->addColumn(
                $connection->getTableName('maas_sales_quote_address_item_info'),
                'seller_id',
                [
                    'type' => Table::TYPE_INTEGER,
                    'comment' => 'Quote Address Item Seller Id',
                    'nullable' => true,
                    'unsigned' => true
                ]
            );
        }
    }
}
