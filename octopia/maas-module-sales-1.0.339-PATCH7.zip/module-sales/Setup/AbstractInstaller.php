<?php

namespace Maas\Sales\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class AbstractInstaller
{

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     * @param $tableName
     * @param $columns
     * @param $foreignKeys
     * @param $comment
     */
    protected function createTableWithForeignKeys(
        SchemaSetupInterface $setup,
        $connection,
        $tableName,
        $columns,
        $foreignKeys,
        $comment
    )
    {
        if ($this->createTableIfNotExists($setup, $connection, $tableName, $columns, $comment)) {

            $this->createForeignKeys($setup, $connection, $tableName, $foreignKeys);
        }
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     * @param $tableName
     * @param $columns
     * @param $comment
     * @return bool
     */
    protected function createTableIfNotExists(SchemaSetupInterface $setup, $connection, $tableName, $columns, $comment)
    {
        if ($setup->tableExists($tableName)) {
            return false;
        }
        $table = $connection->newTable(
            $setup->getTable($tableName)
        );
        foreach ($columns as $colName => $colData) {
            list($type, $size, $properties, $colComment) = $colData;
            $table->addColumn(
                $colName,
                $type,
                $size,
                $properties,
                $colComment
            );
        }
        $table->setComment($comment);
        $connection->createTable($table);
        return true;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     * @param $tableName
     * @param $foreignKeys
     */
    protected function createForeignKeys(SchemaSetupInterface $setup, $connection, $tableName, $foreignKeys)
    {
        foreach ($foreignKeys as $foreignKeyData) {
            list($col, $refTable, $refCol, $onDelete) = $foreignKeyData;
            if (!$onDelete) {
                $onDelete = AdapterInterface::FK_ACTION_CASCADE;
            }
            $connection->addForeignKey(
                $connection->getForeignKeyName($tableName,
                    $col, $refTable,
                    $refCol
                ),
                $setup->getTable($tableName),
                $col,
                $setup->getTable($refTable),
                $refCol,
                $onDelete
            );
        }
    }

}
