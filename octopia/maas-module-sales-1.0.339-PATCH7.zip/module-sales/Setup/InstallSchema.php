<?php


namespace Maas\Sales\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 *
 * @package Maas\Sales\Setup
 * @codeCoverageIgnore
 */
class InstallSchema extends AbstractInstaller implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        /** @var AdapterInterface $connection */
        $connection = $setup->getConnection();
        $this->createTableSalesOrderInfo($setup, $connection);
        $this->createTableSalesOrderItemInfo($setup, $connection);
        $this->createTableQuoteInfo($setup, $connection);
        $this->createTableQuoteItemInfo($setup, $connection);
        $this->createTableQuoteAddressItemInfo($setup, $connection);
        $this->createTableQuoteAddressInfo($setup, $connection);
        $this->addSalesOrderItemStatus($setup, $connection);
        $this->addOrderTypeToSalesOrderGrid($connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableSalesOrderInfo(SchemaSetupInterface $setup, $connection)
    {
        $this->createTableWithForeignKeys($setup, $connection,
            'maas_sales_order_info', [
                'order_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Order Id'
                ],
                'seller_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Seller ID'
                ],
                'seller_maas_id' => [
                    Table::TYPE_TEXT,
                    25,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Seller MaaS ID'
                ],
                'seller_name' => [
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true
                    ],
                    'Seller name to display'
                ],
                'order_type' => [
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable => false'],
                    'Order type: 1 for Core, 2 for MaaS'
                ],
                'main_order_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => true],
                    'ID of main order of the batch'
                ],
                'main_order_increment_id' => [
                    Table::TYPE_TEXT,
                    32,
                    ['nullable => false'],
                    'Increment ID of main order of the batch'
                ],
                'exported' => [
                    Table::TYPE_BOOLEAN,
                    null,
                    ['default => false'],
                    'Is the order exported'
                ]
            ], [
                ['order_id', 'sales_order', 'entity_id', null],
                ['seller_id', 'maas_seller_entity', 'entity_id', AdapterInterface::FK_ACTION_SET_NULL],
                ['main_order_id', 'sales_order', 'entity_id', AdapterInterface::FK_ACTION_SET_NULL]
            ], 'maas_sales_order_info Table');
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableSalesOrderItemInfo(SchemaSetupInterface $setup, $connection)
    {
        $this->createTableWithForeignKeys($setup, $connection,
            'maas_sales_order_item_info',
            [
                'order_item_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Order Item Id'
                ],
                'offer_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Offer id'
                ],
                'seller_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Seller id'
                ],
                'offer_maas_id' => [
                    Table::TYPE_TEXT,
                    64,
                    [
                        'nullable' => false,
                        'unsigned' => true
                    ],
                    'Offer  maas id'
                ],
                'shipping_method' => [
                    Table::TYPE_TEXT,
                    64,
                    [
                        'nullable' => true
                    ],
                    'Order Item Marketplace Shipping method'
                ],
                'shipping_amount' => [
                    Table::TYPE_DECIMAL,
                    '12,4',
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Order Item Marketplace Shipping amount'
                ],
                'delivery_date_min' => [
                    Table::TYPE_DATETIME,
                    null,
                    [
                        'nullable' => true,
                    ],
                    'Marketplace minimum delivery date'
                ],
                'delivery_date_max' => [
                    Table::TYPE_DATETIME,
                    null,
                    [
                        'nullable' => true,
                    ],
                    'Marketplace maximum delivery date'
                ]
            ],
            [
                [
                    'order_item_id',
                    'sales_order_item',
                    'item_id',
                    null
                ],
                [
                    'offer_id',
                    'maas_offer',
                    'entity_id',
                    Table::ACTION_CASCADE
                ]
            ],
            'maas_sales_order_item_info Table'
        );
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableQuoteInfo(SchemaSetupInterface $setup, $connection)
    {
        $this->createTableWithForeignKeys($setup, $connection,
            'maas_sales_quote_info',
            [
                'quote_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Quote Id'
                ]
            ],
            [
                [
                    'quote_id',
                    'quote',
                    'entity_id',
                    null
                ]
            ],
            'maas_sales_quote_info Table'
        );
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableQuoteItemInfo(SchemaSetupInterface $setup, $connection)
    {
        $this->createTableWithForeignKeys($setup, $connection,
            'maas_sales_quote_item_info',
            [
                'quote_item_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Item Id'
                ],
                'offer_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Offer id'
                ],
                'seller_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Seller id'
                ],
                'shipping_method' => [
                    Table::TYPE_TEXT,
                    25,
                    [
                        'nullable' => true
                    ],
                    'Quote Item Marketplace Shipping method'
                ],
                'shipping_amount' => [
                    Table::TYPE_DECIMAL,
                    '12,4',
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Quote Item Marketplace Shipping amount'
                ],
                'delivery_delay_min' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'unsigned' => true,
                        'nullable' => true
                    ],
                    'Marketplace minimum delivery delay'
                ],
                'delivery_delay_max' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'unsigned' => true,
                        'nullable' => true
                    ],
                    'Marketplace maximum delivery delay'
                ]
            ],
            [
                ['offer_id', 'maas_offer', 'entity_id', Table::ACTION_CASCADE],
                ['seller_id', 'maas_seller_entity', 'entity_id', Table::ACTION_CASCADE],
                ['quote_item_id', 'quote_item', 'item_id', null]
            ],
            'maas_sales_quote_item_info Table'
        );
    }


    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableQuoteAddressItemInfo(SchemaSetupInterface $setup, $connection)
    {
        $this->createTableWithForeignKeys($setup, $connection, 'maas_sales_quote_address_item_info', [
            'quote_address_item_id' => [
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary' => true,
                    'unsigned' => true
                ],
                'Item Id'
            ],
            'shipping_method' => [
                Table::TYPE_TEXT,
                25,
                [
                    'nullable' => true
                ],
                'Quote Address Item Marketplace Shipping method'
            ],
            'shipping_amount' => [
                Table::TYPE_DECIMAL,
                '12,4',
                [
                    'nullable' => true,
                    'unsigned' => true
                ],
                'Quote Address Item Marketplace Shipping amount'
            ],
            'delivery_delay_min' => [
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Marketplace minimum delivery delay'
            ],
            'delivery_delay_max' => [
                Table::TYPE_INTEGER,
                null,
                [
                    'unsigned' => true,
                    'nullable' => true
                ],
                'Marketplace maximum delivery delay'
            ]
        ], [
            [
                'quote_address_item_id',
                'quote_address_item',
                'address_item_id',
                null
            ]
        ], 'maas_sales_quote_address_item_info Table');
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableQuoteAddressInfo(SchemaSetupInterface $setup, $connection)
    {
        $this->createTableWithForeignKeys(
            $setup, $connection, 'maas_sales_quote_address_info',
            [
                'quote_address_id' => [
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Address Id'
                ],
                'total_round_fixes' => [
                    Table::TYPE_TEXT,
                    null,
                    [
                        'nullable' => true
                    ],
                    'Rounding fixes'
                ]
            ],
            [
                [
                    'quote_address_id',
                    'quote_address',
                    'address_id',
                    null
                ]
            ],
            'maas_sales_quote_address_info Table'
        );
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function addSalesOrderItemStatus($setup, $connection)
    {
        if ($setup->tableExists('maas_sales_order_item_info')) {
            $connection->addColumn(
                $connection->getTableName('maas_sales_order_item_info'),
                'status',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => 50,
                    'comment' => 'Item Status'
                ]
            );
        }
    }


    /**
     * @param AdapterInterface $connection
     */
    protected function addOrderTypeToSalesOrderGrid($connection)
    {
        $connection->addColumn(
            $connection->getTableName('sales_order_grid'),
            'order_type',
            [
                'type' => Table::TYPE_INTEGER,
                'length' => 50,
                'nullable => false',
                'comment' => 'Order type: 1 for Core, 2 for MaaS'
            ]
        );
    }
}
