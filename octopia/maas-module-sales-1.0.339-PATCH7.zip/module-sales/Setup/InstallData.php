<?php

namespace Maas\Sales\Setup;

use Exception;
use Maas\Sales\Model\Service\Data\OrderStatus as DataStatus;
use Maas\Sales\Setup\Data\MaasStatus;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Status;
use Magento\Sales\Model\Order\StatusFactory;
use Magento\Sales\Model\ResourceModel\Order\Status as StatusResourceModel;
use Magento\Sales\Model\ResourceModel\Order\StatusFactory as StatusResourceFactory;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    const VISBLE_ON_FRONT = true;
    const IS_DEFAULT = false;
    /**
     * @var StatusFactory
     */
    private $statusFactory;
    /**
     * @var StatusResourceFactory
     */
    private $statusResourceFactory;
    /**
     * @var MaasStatus
     */
    private $maasStatus;

    /**
     * UpgradeData constructor.
     *
     * @param StatusFactory $statusFactory
     * @param StatusResourceFactory $statusResourceFactory
     * @param MaasStatus $maasSatus
     */
    public function __construct(
        StatusFactory $statusFactory,
        StatusResourceFactory $statusResourceFactory,
        MaasStatus $maasSatus
    )
    {
        $this->statusFactory = $statusFactory;
        $this->statusResourceFactory = $statusResourceFactory;
        $this->maasStatus = $maasSatus;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFunctionParameter)
     * @throws Exception
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $this->addNewStatusMaas();
        $setup->endSetup();
    }

    /**
     * @throws Exception
     */
    private function addNewStatusMaas()
    {
        /** @var StatusResourceModel $status */
        $statusResource = $this->statusResourceFactory->create();

        foreach ($this->maasStatus->getMaasOrderStatus() as $status) {
            /** @var Status $statusModel */
            $statusModel = $this->statusFactory->create();
            $statusModel->setData($status);
            try {
                $statusResource->save($statusModel);
            } catch (AlreadyExistsException $exception) {
                return;
            }
            if ($status['status'] === DataStatus::STATUS_SHIPPED) {
                $statusModel->assignState(Order::STATE_PROCESSING, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
            } elseif ($status['status'] === DataStatus::STATUS_CANCELED) {
                $statusModel->assignState(Order::STATE_CANCELED, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
                $statusModel->assignState(Order::STATE_CLOSED, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
            } elseif ($status['status'] === DataStatus::STATUS_DELIVERED) {
                $statusModel->assignState(Order::STATE_PROCESSING, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
                $statusModel->assignState(Order::STATE_COMPLETE, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
            } else {
                $statusModel->assignState(Order::STATE_NEW, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
                $statusModel->assignState(Order::STATE_HOLDED, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
                $statusModel->assignState(Order::STATE_PENDING_PAYMENT, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
                $statusModel->assignState(Order::STATE_PROCESSING, self::IS_DEFAULT, self::VISBLE_ON_FRONT);
            }
        }
    }
}
