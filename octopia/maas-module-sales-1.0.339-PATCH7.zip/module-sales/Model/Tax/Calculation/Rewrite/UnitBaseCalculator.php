<?php

namespace Maas\Sales\Model\Tax\Calculation\Rewrite;

use Magento\Tax\Model\Calculation\AbstractCalculator;

/**
 * Class UnitBaseCalculator
 * @package Maas\Sales\Model
 */
class UnitBaseCalculator extends \Magento\Tax\Model\Calculation\UnitBaseCalculator
{

    /**
     * Prevent round price based on previous rounding operation delta
     *
     * @param float $price
     * @param string $rate
     * @param bool $direction
     * @param string $type
     * @param bool $round
     * @return float
     */
    protected function deltaRound($price, $rate, $direction, $type = AbstractCalculator::KEY_REGULAR_DELTA_ROUNDING, $round = true)
    {
        return parent::deltaRound($price, $rate, $direction, $type, false);
    }
}
