<?php

namespace Maas\Sales\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoSearchResultsInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressItemInfoRepositoryInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteAddressItemInfo;
use Maas\Sales\Model\ResourceModel\SalesQuoteAddressItemInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class SalesQuoteAddressItemInfoRepository
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
class SalesQuoteAddressItemInfoRepository extends AbstractRepository implements SalesQuoteAddressItemInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesQuoteAddressItemInfoInterface $salesQuoteAddressItemInfo)
    {
        return $this->_save($salesQuoteAddressItemInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesQuoteAddressItemInfoInterface $salesQuoteAddressItemInfo)
    {
        $this->_delete($salesQuoteAddressItemInfo);
    }
}
