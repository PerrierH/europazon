<?php

namespace Maas\Sales\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Model\ResourceModel\OfferFactory;
use Maas\Sales\Api\Data\SalesQuoteInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteInfoSearchResultsInterfaceFactory;
use Maas\Sales\Api\SalesQuoteInfoRepositoryInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteInfo;
use Maas\Sales\Model\ResourceModel\SalesQuoteInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class SalesQuoteInfoRepository
 * @codeCoverageIgnore
 * @package Maas\Sales\Model
 */
class SalesQuoteInfoRepository extends AbstractRepository implements SalesQuoteInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesQuoteInfoInterface $salesOrderInfo)
    {
        return $this->_save($salesOrderInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesQuoteInfoInterface $salesOrderInfo)
    {
        $this->_delete($salesOrderInfo);
    }
}
