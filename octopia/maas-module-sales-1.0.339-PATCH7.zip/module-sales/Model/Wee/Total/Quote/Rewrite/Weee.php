<?php

namespace Maas\Sales\Model\Wee\Total\Quote\Rewrite;

use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Total;

/**
 * Class Weee
 * @package Maas\Sales\Model\Wee\Total\Quote\Rewrite
 */
class Weee extends \Magento\Weee\Model\Total\Quote\Weee
{

    /**
     * Prevent issue multi addresses collect Weee amounts for the quote / order
     *
     * @param Quote $quote
     * @param ShippingAssignmentInterface $shippingAssignment
     * @param Total $total
     * @return Weee
     */
    public function collect(
        Quote $quote,
        ShippingAssignmentInterface $shippingAssignment,
        Total $total
    ) {
        $this->weeeCodeToItemMap = [];
        return parent::collect($quote, $shippingAssignment, $total);
    }
}
