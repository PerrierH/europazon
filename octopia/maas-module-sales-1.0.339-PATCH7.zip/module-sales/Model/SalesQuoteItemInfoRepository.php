<?php

namespace Maas\Sales\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteItemInfoSearchResultsInterfaceFactory;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo;
use Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class OfferRepository
 *
 * @package Maas\Offer\Model
 * @codeCoverageIgnore
 */
class SalesQuoteItemInfoRepository extends AbstractRepository implements SalesQuoteItemInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesQuoteItemInfoInterface $salesOrderInfo)
    {
        return $this->_save($salesOrderInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesQuoteItemInfoInterface $salesOrderInfo)
    {
        $this->_delete($salesOrderInfo);
    }
}
