<?php

namespace Maas\Sales\Model;

use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo as MSalesQuoteItemInfo;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesQuoteItemInfo
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
class SalesQuoteItemInfo extends AbstractModel implements SalesQuoteItemInfoInterface
{
    use SalesQuoteItemTrait;


    /**
     * @inheritDoc
     */
    public function getOfferId()
    {
        return $this->getData(self::OFFER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setOfferId($offerId)
    {
        return $this->setData(self::OFFER_ID, $offerId);
    }

    /**
     * @inheritDoc
     */
    public function getSellerId()
    {
        return $this->getData(self::SELLER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * @inheritDoc
     */
    public function getOriginalShippingAmount()
    {
        return $this->getData(self::ORIGINAL_SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setOriginalShippingAmount($shippingAmount)
    {
        return $this->setData(self::ORIGINAL_SHIPPING_AMOUNT, $shippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getDiscountedShippingAmount()
    {
        return $this->getData(self::DISCOUNTED_SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setDiscountedShippingAmount($shippingAmount)
    {
        return $this->setData(self::DISCOUNTED_SHIPPING_AMOUNT, $shippingAmount);
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(MSalesQuoteItemInfo::class);
    }
}
