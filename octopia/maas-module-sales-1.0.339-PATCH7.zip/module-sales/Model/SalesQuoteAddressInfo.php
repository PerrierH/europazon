<?php

namespace Maas\Sales\Model;

use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteAddressInfo as MSalesQuoteAddressInfo;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesQuoteAddressInfo
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
class SalesQuoteAddressInfo extends AbstractModel implements SalesQuoteAddressInfoInterface
{
    /**
     * @inheritDoc
     */
    public function getTotalRoundFixes()
    {
        return $this->getData(self::TOTAL_ROUND_FIXES);
    }

    /**
     * @inheritDoc
     */
    public function setTotalRoundFixes($totalRoundFixes)
    {
        return $this->setData(self::TOTAL_ROUND_FIXES, $totalRoundFixes);
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(MSalesQuoteAddressInfo::class);
    }
}
