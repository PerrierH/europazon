<?php

namespace Maas\Sales\Model;

/**
 * Trait SalesQuoteItemTrait
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
trait SalesQuoteItemTrait
{
    /**
     * @inheritDoc
     */
    public function getShippingMethod()
    {
        return $this->getData(self::SHIPPING_METHOD);
    }

    /**
     * @inheritDoc
     */
    public function setShippingMethod($shippingMethod)
    {
        return $this->setData(self::SHIPPING_METHOD, $shippingMethod);
    }

    /**
     * @inheritDoc
     */
    public function getShippingAmount()
    {
        return $this->getData(self::SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setShippingAmount($shippingAmount)
    {
        return $this->setData(self::SHIPPING_AMOUNT, $shippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getOriginalShippingAmount()
    {
        return $this->getData(self::ORIGINAL_SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setOriginalShippingAmount($originalShippingAmount)
    {
        return $this->setData(self::ORIGINAL_SHIPPING_AMOUNT, $originalShippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getDiscountedShippingAmount()
    {
        return $this->getData(self::DISCOUNTED_SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setDiscountedShippingAmount($discountedShippingAmount)
    {
        return $this->setData(self::DISCOUNTED_SHIPPING_AMOUNT, $discountedShippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryDelayMin()
    {
        return $this->getData(self::DELIVERY_DELAY_MIN);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryDelayMin($deliveryDelayMin)
    {
        return $this->setData(self::DELIVERY_DELAY_MIN, $deliveryDelayMin);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryDelayMax()
    {
        return $this->getData(self::DELIVERY_DELAY_MAX);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryDelayMax($deliveryDelayMax)
    {
        return $this->setData(self::DELIVERY_DELAY_MAX, $deliveryDelayMax);
    }

    /**
     * @inheritDoc
     */
    public function getOriginalTaxes()
    {
        return $this->getData(self::ORIGINAL_TAXES);
    }

    /**
     * @inheritDoc
     */
    public function setOriginalTaxes($originalTaxes)
    {
        return $this->setData(self::ORIGINAL_TAXES, $originalTaxes);
    }
}
