<?php

namespace Maas\Sales\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Model\ResourceModel\OfferFactory;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoSearchResultsInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressInfoRepositoryInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteAddressInfo;
use Maas\Sales\Model\ResourceModel\SalesQuoteAddressInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class OfferRepository
 *
 * @package Maas\Offer\Model
 * @codeCoverageIgnore
 */
class SalesQuoteAddressInfoRepository extends AbstractRepository implements SalesQuoteAddressInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesQuoteAddressInfoInterface $salesOrderInfo)
    {
        return $this->_save($salesOrderInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesQuoteAddressInfoInterface $salesOrderInfo)
    {
        $this->_delete($salesOrderInfo);
    }
}
