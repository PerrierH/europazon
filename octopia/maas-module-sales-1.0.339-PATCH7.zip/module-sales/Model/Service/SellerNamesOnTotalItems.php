<?php

namespace Maas\Sales\Model\Service;

use Maas\Seller\Api\SellerRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\TotalsItemInterface;
use Magento\Quote\Api\Data\TotalsItemExtensionInterfaceFactory;

/**
 * Class SellerNamesOnTotalItems
 *
 * @package Maas\Sales\Model\Service
 */
class SellerNamesOnTotalItems
{
    /** @var ExtensionAttributes */
    protected $extensionAttributes;

    /** @var SellerRepositoryInterface */
    protected $sellerRepository;

    /** @var SearchCriteriaBuilder */
    protected $searchCriteriaBuilder;

    /** @var TotalsItemExtensionInterfaceFactory  */
    protected $totalsItemExtensionFactory;

    /**
     * SellerNamesOnTotalItems constructor.
     *
     * @param ExtensionAttributes $extensionAttributes
     * @param SellerRepositoryInterface $sellerRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param TotalsItemExtensionInterfaceFactory $totalsItemExtensionInterfaceFactory
     */
    public function __construct(
        ExtensionAttributes $extensionAttributes,
        SellerRepositoryInterface $sellerRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        TotalsItemExtensionInterfaceFactory $totalsItemExtensionInterfaceFactory
    ) {
        $this->extensionAttributes = $extensionAttributes;
        $this->sellerRepository = $sellerRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->totalsItemExtensionFactory = $totalsItemExtensionInterfaceFactory;
    }

    /**
     * @codeCoverageIgnore
     * @param CartInterface $cart
     * @param TotalsItemInterface[] $totalItems
     */
    public function executeWithQuoteItems($cart, $totalItems)
    {
        $totalItemsById = $this->organizeTotalItemsByItemId($totalItems);
        $totalItemsBySellerId = $this->organizeTotalItemsBySellerId($cart, $totalItemsById);
        $this->addSellerNamesToTotalItems($totalItemsBySellerId);
    }

    /**
     * @param TotalsItemInterface[] $totalItems
     *
     * @return TotalsItemInterface[]
     */
    protected function organizeTotalItemsByItemId($totalItems)
    {
        $totalItemsByItemId = [];
        foreach ($totalItems as $totalItem) {
            $totalItemsByItemId[$totalItem->getItemId()] = $totalItem;
        }
        return $totalItemsByItemId;
    }

    /**
     * @param CartInterface $cart
     * @param TotalsItemInterface[] $totalItemsByItemId
     *
     * @return TotalsItemInterface[][]
     */
    protected function organizeTotalItemsBySellerId($cart, $totalItemsByItemId)
    {
        $cartItems = $cart->getItems();
        $totalItemsBySellerId = [];
        foreach ($cartItems as $cartItem) {
            $extension = $this->extensionAttributes->getQuoteItemExtensionAttributes($cartItem);
            if ($extension->getExtraInfo()->getSellerId() && isset($totalItemsByItemId[$cartItem->getItemId()])) {
                $sellerId = $extension->getExtraInfo()->getSellerId();
                if (!isset($totalItemsBySellerId[$sellerId])) {
                    $totalItemsBySellerId[$sellerId] = [];
                }
                $totalItemsBySellerId[$sellerId][] = $totalItemsByItemId[$cartItem->getItemId()];
            }
        }
        return $totalItemsBySellerId;
    }

    /**
     * @param TotalsItemInterface[][] $totalItemsBySellerId
     */
    protected function addSellerNamesToTotalItems($totalItemsBySellerId)
    {
        $sellerIds = array_keys($totalItemsBySellerId);
        $searchCriteria = $this->searchCriteriaBuilder->addFilter('entity_id', $sellerIds, 'in')->create();
        $sellers = $this->sellerRepository->getList($searchCriteria)->getItems();
        foreach ($sellers as $seller) {
            foreach ($totalItemsBySellerId[$seller->getId()] as $sellerItem) {
                $extension = $sellerItem->getExtensionAttributes();
                if($extension === null){
                    $extension = $this->totalsItemExtensionFactory->create();
                }
                $extension->setMaasSellerName($seller->getName());
                $sellerItem->setExtensionAttributes($extension);
            }
        }
    }
}
