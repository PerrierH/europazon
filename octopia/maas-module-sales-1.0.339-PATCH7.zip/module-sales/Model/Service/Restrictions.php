<?php

namespace Maas\Sales\Model\Service;

use Maas\Sales\Model\OrderRestrictions\Converter;
use Maas\Sales\Model\OrderRestrictions\Reader;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Backend\Model\Session\Quote;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\OrderRepositoryInterface;

/**
 * Class Restrictions
 *
 * @package Maas\Sales\Model\Service
 */
class Restrictions
{
    const TEMPLATE_EXPORTED = '%s_exported';

    const TEMPLATE_NOT_EXPORTED = '%s_not_exported';

    /**
     * @var bool
     */
    protected $enabled = false;

    /**
     * @var Reader
     */
    protected $reader;

    /**
     * @var null|array
     */
    protected $disabledPermissions = null;

    /**
     * @var Quote
     */
    protected $sessionQuote;

    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * Restrictions constructor.
     *
     * @param Reader $reader
     * @param Quote $sessionQuote
     * @param OrderRepositoryInterface $orderRepository
     * @param ExtensionAttributes $extensionAttributesService
     */
    public function __construct(
        Reader $reader,
        Quote $sessionQuote,
        OrderRepositoryInterface $orderRepository,
        ExtensionAttributes $extensionAttributesService
    ) {
        $this->reader = $reader;
        $this->sessionQuote = $sessionQuote;
        $this->orderRepository = $orderRepository;
        $this->extensionAttributesService = $extensionAttributesService;
    }

    /**
     * @param RequestInterface $request
     *
     * @return $this
     */
    public function enableIfPossible($request)
    {
        if ($request instanceof Http) {
            $fullPath = $request->getFullActionName();
            $config = $this->reader->read();
            $orderId = $this->initializeOrderId($request, $config);
            if ($orderId) {
                try {
                    $order = $this->orderRepository->get($orderId);
                    $extension = $this->extensionAttributesService->getOrderExtensionAttributes($order)->getExtraInfo();
                    if ($extension->getOrderType() == SalesOrderInfo::ORDER_TYPE_MAAS) {
                        $this->disabledPermissions = $this->getPermissionsForPath($config, $fullPath, $extension->getExported());
                        $this->enabled = true;
                    }
                } catch (NoSuchEntityException $nsee) {
                    // do nothing
                }
            }
        }
        return $this;
    }

    /**
     * @param array $config
     * @param string $fullPath
     * @param null $isExported
     *
     * @return array
     */
    protected function getPermissionsForPath(&$config, $fullPath, $isExported = null)
    {
        $genericPermissions = isset($config[$fullPath]) ? $config[$fullPath][Converter::DISABLED_PERMISSIONS] : [];
        $exportSpecificKey = sprintf($isExported ? self::TEMPLATE_EXPORTED : self::TEMPLATE_NOT_EXPORTED, $fullPath);
        $exportSpecificPermissions = isset($config[$exportSpecificKey]) ? $config[$exportSpecificKey][Converter::DISABLED_PERMISSIONS] : [];
        return array_merge(array_values($genericPermissions), array_values($exportSpecificPermissions));
    }


    /**
     * @param RequestInterface $request
     * @param array $config
     *
     * @return int|null
     */
    private function initializeOrderId(RequestInterface $request, $config)
    {
        $orderId = null;
        $fullPath = $request->getFullActionName();
        // At this point we don't know whether the order is exported or not, so keys are tested in fixed order
        $key = $fullPath;
        if(!isset($config[$key]))
        {
            $key = sprintf(self::TEMPLATE_NOT_EXPORTED, $fullPath);
            if(!isset($config[$key]))
            {
                $key = sprintf(self::TEMPLATE_EXPORTED, $fullPath);
                if(!isset($config[$key]))
                {
                    $key = null;
                }
            }
        }
        if ($key) {
            $source = $config[$key][Converter::ORDER_ID_SOURCE];
            if ($source == '_session_order_get_id') {
                $orderId = $this->sessionQuote->getOrder()->getId();
            } else {
                $orderId = $request->getParam($source);
            }
        }
        return $orderId;
    }

    /**
     * @return int|null
     *
     * @codeCoverageIgnore simple getter
     */
    public function isEnabled()
    {
        return $this->enabled;
    }

    /**
     * @param string $action
     * @param bool $standardResult
     *
     * @return bool
     */
    public function isAllowed($action, $standardResult)
    {
        if ($this->enabled && in_array($action, $this->disabledPermissions)) {
            return false;
        }
        return $standardResult;
    }
}