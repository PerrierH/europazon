<?php

namespace Maas\Sales\Model\Service;

use Maas\Core\Model\Service\AbstractExtensionAttributes;
use Maas\Sales\Api\Data\SalesOrderInfoInterfaceFactory;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterfaceFactory;
use Maas\Sales\Api\Data\SalesQuoteAddressInfoInterfaceFactory;
use Maas\Sales\Api\Data\SalesQuoteInfoInterfaceFactory;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterfaceFactory;
use Magento\Quote\Api\Data\AddressExtensionInterface;
use Magento\Quote\Api\Data\AddressExtensionInterfaceFactory;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\CartExtensionInterface;
use Magento\Quote\Api\Data\CartExtensionInterfaceFactory;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\CartItemExtensionInterface;
use Magento\Quote\Api\Data\CartItemExtensionInterfaceFactory;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderExtensionInterfaceFactory;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderItemExtension;
use Magento\Sales\Api\Data\OrderItemExtensionFactory;
use Magento\Sales\Api\Data\OrderItemExtensionInterfaceFactory;
use Magento\Sales\Api\Data\OrderItemInterface;


/**
 * Class ExtensionAttributes
 *
 * @package Maas\Sales\Model\Service
 */
class ExtensionAttributes extends AbstractExtensionAttributes
{
    /**
     * @var CartExtensionInterfaceFactory
     */
    private $cartExtensionFactory;

    /**
     * @var CartItemExtensionInterfaceFactory
     */
    private $cartItemExtensionFactory;

    /**
     * @var AddressExtensionInterfaceFactory
     */
    private $cartAddressExtensionFactory;

    /**
     * @var OrderExtensionInterfaceFactory
     */
    private $orderExtensionFactory;

    /**
     * @var OrderItemExtensionFactory
     */
    private $orderItemExtensionFactory;

    /**
     * @var SalesQuoteInfoInterfaceFactory
     */
    private $salesQuoteInfoFactory;

    /**
     * @var SalesQuoteAddressInterfaceFactory
     */
    private $salesQuoteAddressInfoFactory;

    /**
     * @var SalesQuoteItemInfoInterfaceFactory
     */
    private $salesQuoteItemInfoFactory;

    /**
     * @var SalesOrderInfoInterfaceFactory
     */
    private $salesOrderInfoFactory;

    /**
     * @var SalesOrderItemInfoInterfaceFactory
     */
    private $salesOrderItemInfoFactory;

    /**
     * ExtensionAttributes constructor.
     *
     * @param CartExtensionInterfaceFactory $cartExtensionFactory
     * @param CartItemExtensionInterfaceFactory $cartItemExtensionFactory
     * @param AddressExtensionInterfaceFactory $cartAddressExtensionFactory
     * @param OrderExtensionInterfaceFactory $orderExtensionFactory
     * @param OrderItemExtensionInterfaceFactory $orderItemExtensionFactory
     * @param SalesQuoteInfoInterfaceFactory $salesQuoteInfoFactory
     * @param SalesQuoteAddressInfoInterfaceFactory $salesQuoteAddressInfoFactory
     * @param SalesQuoteItemInfoInterfaceFactory $salesQuoteItemInfoFactory
     * @param SalesOrderInfoInterfaceFactory $salesOrderInfoFactory
     * @param SalesOrderItemInfoInterfaceFactory $salesOrderItemInfoFactory
     */
    public function __construct(
        CartExtensionInterfaceFactory $cartExtensionFactory,
        CartItemExtensionInterfaceFactory $cartItemExtensionFactory,
        AddressExtensionInterfaceFactory $cartAddressExtensionFactory,
        OrderExtensionInterfaceFactory $orderExtensionFactory,
        OrderItemExtensionInterfaceFactory $orderItemExtensionFactory,
        SalesQuoteInfoInterfaceFactory $salesQuoteInfoFactory,
        SalesQuoteAddressInfoInterfaceFactory $salesQuoteAddressInfoFactory,
        SalesQuoteItemInfoInterfaceFactory $salesQuoteItemInfoFactory,
        SalesOrderInfoInterfaceFactory $salesOrderInfoFactory,
        SalesOrderItemInfoInterfaceFactory $salesOrderItemInfoFactory
    ) {
        $this->cartExtensionFactory = $cartExtensionFactory;
        $this->cartItemExtensionFactory = $cartItemExtensionFactory;
        $this->cartAddressExtensionFactory = $cartAddressExtensionFactory;
        $this->orderExtensionFactory = $orderExtensionFactory;
        $this->orderItemExtensionFactory = $orderItemExtensionFactory;
        $this->salesQuoteInfoFactory = $salesQuoteInfoFactory;
        $this->salesQuoteAddressInfoFactory = $salesQuoteAddressInfoFactory;
        $this->salesQuoteItemInfoFactory = $salesQuoteItemInfoFactory;
        $this->salesOrderInfoFactory = $salesOrderInfoFactory;
        $this->salesOrderItemInfoFactory = $salesOrderItemInfoFactory;
    }

    /**
     * @param CartInterface $cart
     *
     * @return CartExtensionInterface
     */
    public function getQuoteExtensionAttributes(CartInterface $cart)
    {
        return $this->getObjectExtensionAttributes($cart, $this->cartExtensionFactory, $this->salesQuoteInfoFactory);
    }

    /**
     * @param CartItemInterface $cartItem
     *
     * @return CartItemExtensionInterface
     */
    public function getQuoteItemExtensionAttributes(CartItemInterface $cartItem)
    {
        return $this->getObjectExtensionAttributes($cartItem, $this->cartItemExtensionFactory,
            $this->salesQuoteItemInfoFactory);
    }

    /**
     * @param AddressInterface $cartAddress
     *
     * @return AddressExtensionInterface
     */
    public function getQuoteAddressExtensionAttributes(AddressInterface $cartAddress)
    {
        return $this->getObjectExtensionAttributes($cartAddress, $this->cartAddressExtensionFactory,
            $this->salesQuoteAddressInfoFactory);
    }

    /**
     * @param OrderInterface $order
     *
     * @return OrderExtensionInterface
     */
    public function getOrderExtensionAttributes(OrderInterface $order)
    {
        return $this->getObjectExtensionAttributes($order, $this->orderExtensionFactory, $this->salesOrderInfoFactory);
    }

    /**
     * @param OrderItemInterface $orderItem
     *
     * @return OrderItemExtension
     */
    public function getOrderItemExtensionAttributes(OrderItemInterface $orderItem)
    {
        return $this->getObjectExtensionAttributes($orderItem, $this->orderItemExtensionFactory,
            $this->salesOrderItemInfoFactory);
    }
}
