<?php

namespace Maas\Sales\Model\Service;

use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteAddressItemInfoRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote\Address\Item;

/**
 * Class AddressItem
 * @package Maas\Sales\Model\Service
 */
class AddressItem
{
    /** @var SalesQuoteAddressItemInfoInterfaceFactory */
    protected $salesQuoteAddressItemInfoFactory;

    /** @var SalesQuoteAddressItemInfoRepositoryInterface */
    protected $salesQuoteAddressItemInfoRepository;

    /**
     * @var array
     */
    protected $loadedExtensionItems = [];

    /**
     * AddressItem constructor.
     *
     * @param SalesQuoteAddressItemInfoInterfaceFactory $salesQuoteAddressItemInfoFactory
     * @param SalesQuoteAddressItemInfoRepositoryInterface $salesQuoteAddressItemInfoRepository
     */
    public function __construct(
        SalesQuoteAddressItemInfoInterfaceFactory $salesQuoteAddressItemInfoFactory,
        SalesQuoteAddressItemInfoRepositoryInterface $salesQuoteAddressItemInfoRepository
    ) {
        $this->salesQuoteAddressItemInfoFactory = $salesQuoteAddressItemInfoFactory;
        $this->salesQuoteAddressItemInfoRepository = $salesQuoteAddressItemInfoRepository;
    }

    /**
     * @param Item $addressItem
     * @codeCoverageIgnore
     * @return SalesQuoteAddressItemInfoInterface
     */
    public function loadExtraInfo(Item $addressItem)
    {
        return $this->loadExtraInfoById($addressItem->getId());
    }

    /**
     * @param int $id
     *
     * @return SalesQuoteAddressItemInfoInterface
     */
    public function loadExtraInfoById($id)
    {
        if (isset($this->loadedExtensionItems[$id])) {
            return $this->loadedExtensionItems[$id];
        }
        try {
            $this->loadedExtensionItems[$id] = $this->salesQuoteAddressItemInfoRepository->get($id);
        } catch (NoSuchEntityException $nsee) {
            $info = $this->salesQuoteAddressItemInfoFactory->create();
            $info->setId($id);
            $this->loadedExtensionItems[$id] = $info;
        }
        return $this->loadedExtensionItems[$id];
    }

    /**
     * @param SalesQuoteAddressItemInfoInterface $salesQuoteAddressItemInfo
     * @codeCoverageIgnore
     * @return SalesQuoteAddressItemInfoInterface
     */
    public function saveExtraInfo(SalesQuoteAddressItemInfoInterface $salesQuoteAddressItemInfo)
    {
        return $this->salesQuoteAddressItemInfoRepository->save($salesQuoteAddressItemInfo);
    }
}
