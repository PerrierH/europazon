<?php

namespace Maas\Sales\Model\Service\Data;

use Maas\Sales\Exception\UnknownStatus;

class OrderStatus
{
    const PROCESSING = 'Processing';
    const IN_PREPARATION = 'InPreparation';
    const SHIPPED = 'Shipped';
    const DELIVERED = 'Delivered';
    const REJECTED = 'Rejected';
    const CANCELED = 'Cancelled';
    const ACCEPTED = 'Accepted';

    const STATUS_EXPORTED = 'maas_order_exported';
    const STATUS_PROCESSING = 'maas_processing';
    const STATUS_ACCEPTED = 'maas_accepted';
    const STATUS_IN_PREPARATION = 'maas_in_preparation';
    const STATUS_SHIPPED = 'maas_shipped';
    const STATUS_DELIVERED = 'maas_delivered';
    const STATUS_REJECTED = 'maas_rejected';
    const STATUS_CANCELED = 'maas_cancelled';

    /**
     * For each maas_order_status, this table gives the previous expected status of a fulfillment order
     *
     * @var string[]
     */
    private $reversedFulfillmentOrderStatusWorkflow = [
        self::STATUS_PROCESSING => self::STATUS_EXPORTED,
        self::STATUS_ACCEPTED => self::STATUS_PROCESSING,
        self::STATUS_REJECTED => self::STATUS_PROCESSING,
        self::STATUS_SHIPPED => self::STATUS_IN_PREPARATION,
        self::STATUS_CANCELED => self::STATUS_ACCEPTED,
        self::STATUS_DELIVERED => self::STATUS_SHIPPED,
        self::STATUS_IN_PREPARATION => self::STATUS_ACCEPTED
    ];

    /**
     * For each maas_order_status, this table gives the previous expected status of a marketplace order
     *
     * @var string[]
     */
    private $reversedOrderStatusWorkflow = [
        self::STATUS_PROCESSING => self::STATUS_EXPORTED,
        self::STATUS_ACCEPTED => self::STATUS_PROCESSING,
        self::STATUS_REJECTED => self::STATUS_PROCESSING,
        self::STATUS_SHIPPED => self::STATUS_ACCEPTED,
        self::STATUS_CANCELED => self::STATUS_ACCEPTED,
        self::STATUS_DELIVERED => self::STATUS_SHIPPED,
        self::STATUS_IN_PREPARATION => self::STATUS_ACCEPTED
    ];

    /**
     * Mapping table: Octopia status -> Magento status
     *
     * @var string[]
     */
    private $maasStatusByStatus = [
        self::PROCESSING => self::STATUS_PROCESSING,
        self::IN_PREPARATION => self::STATUS_IN_PREPARATION,
        self::SHIPPED => self::STATUS_SHIPPED,
        self::DELIVERED => self::STATUS_DELIVERED,
        self::REJECTED => self::STATUS_REJECTED,
        self::CANCELED => self::STATUS_CANCELED,
        self::ACCEPTED => self::STATUS_ACCEPTED
    ];

    /**
     * Mapping table: Magento status -> Octopia status
     *
     * @var string[]
     */
    private $statusByMaasStatus = [
        self::STATUS_PROCESSING => self::PROCESSING,
        self::STATUS_IN_PREPARATION => self::IN_PREPARATION,
        self::STATUS_SHIPPED => self::SHIPPED,
        self::STATUS_DELIVERED => self::DELIVERED,
        self::STATUS_REJECTED => self::REJECTED,
        self::STATUS_CANCELED => self::CANCELED,
        self::STATUS_ACCEPTED => self::ACCEPTED
    ];

    /**
     * returns the list of transitional status
     *
     * @param string $initialStatus
     * @param string $targetStatus
     *
     * @return array
     */
    public function getStatusWorkflow($initialStatus, $targetStatus, $isFulfillment = false)
    {
        if ($initialStatus == $targetStatus) {
            return [];
        }

        $statusWorkflowList = [];
        while ($initialStatus != $targetStatus) {
            if ($targetStatus == self::STATUS_CANCELED) {
                array_unshift($statusWorkflowList, self::STATUS_CANCELED);
                $targetStatus = $initialStatus;
            } elseif (!$isFulfillment && array_key_exists($targetStatus, $this->reversedOrderStatusWorkflow)) {
                array_unshift($statusWorkflowList, $targetStatus);
                $targetStatus = $this->reversedOrderStatusWorkflow[$targetStatus];
            } elseif ($isFulfillment && array_key_exists($targetStatus, $this->reversedFulfillmentOrderStatusWorkflow)) {
                array_unshift($statusWorkflowList, $targetStatus);
                $targetStatus = $this->reversedFulfillmentOrderStatusWorkflow[$targetStatus];
            } else {
                throw new UnknownStatus('Unknown status: ' . $targetStatus);
            }
        }

        return $statusWorkflowList;
    }

    public function getMaasStatusByStatus($status){
        return $this->maasStatusByStatus[$status] ?? null;
    }

    public function getStatusByMaasStatus($status){
        return $this->statusByMaasStatus[$status] ?? null;
    }
}
