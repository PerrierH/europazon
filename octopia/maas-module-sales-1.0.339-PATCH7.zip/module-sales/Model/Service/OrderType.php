<?php

namespace Maas\Sales\Model\Service;

use Maas\Core\Model\Config;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Sales\Api\Data\OrderInterface;

/**
 * Class OrderType
 * @package Maas\Sales\Model\Service
 */
class OrderType
{
    /**
     * @var Config
     */
    protected $config;

    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /**
     * OrderType constructor.
     *
     * @param Config $config
     * @param ExtensionAttributes $extensionAttributesService
     */
    public function __construct(
        Config $config,
        ExtensionAttributes $extensionAttributesService
    ) {
        $this->config = $config;
        $this->extensionAttributesService = $extensionAttributesService;
    }

    /**
     * @param OrderInterface $order
     * @return bool
     */
    public function isOrderMarketplace(OrderInterface $order)
    {
        if (!$this->config->isModuleEnabled())  {
            return false;
        }
        /** @var $extraInfo SalesOrderInfoInterface */
        $extraInfo = $this->extensionAttributesService->getOrderExtensionAttributes($order)->getExtraInfo();
        return ($extraInfo->getOrderType() == SalesOrderInfo::ORDER_TYPE_MAAS) && (!empty($extraInfo->getSellerId()));
    }
}
