<?php

namespace Maas\Sales\Model\Service\SplitCartService\Onepage;

use Maas\Sales\Model\Session as MaasSession;
use Magento\Checkout\Model\Session as StandardSession;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;

/**
 * Class SessionUpdater
 *
 * @package Maas\Sales\Model\Service\SplitCartService\Onepage
 */
class SessionUpdater
{
    /**
     * @var StandardSession
     */
    private $standardSession;

    /**
     * @var MaasSession
     */
    private $maasSession;

    /**
     * SessionUpdater constructor.
     *
     * @param StandardSession $standardSession
     * @param MaasSession $maasSession
     */
    public function __construct(
        StandardSession $standardSession,
        MaasSession $maasSession
    ) {
        $this->standardSession = $standardSession;
        $this->maasSession = $maasSession;
    }

    /**
     * @param CartInterface[] $quotes
     * @param OrderInterface[] $orders
     *
     * @codeCoverageIgnore Delegates to two other methods
     *
     * @return $this
     */
    public function execute($quotes, $orders)
    {
        $this->updateStandardSession($quotes, $orders);
        return $this;
    }

    /**
     * @param CartInterface[] $quotes
     * @param OrderInterface[] $orders
     *
     * @return $this
     */
    public function updateStandardSession($quotes, $orders)
    {
        $quoteIds = array_keys($quotes);
        $orderIds = array_keys($orders);

        $firstQuoteId = reset($quoteIds);
        $firstOrderId = reset($orderIds);
        $firstOrder = reset($orders);
        $firstQuote = reset($quotes);

        $this->standardSession->setLastSuccessQuoteId($firstQuoteId);
        $this->standardSession->setLastQuoteId($firstQuoteId);
        $this->standardSession->setLastOrderId($firstOrderId);

        $redirectUrl = $firstQuote->getPayment()->getOrderPlaceRedirectUrl();

        $this->standardSession
            ->setLastOrderId($firstOrder->getId())
            ->setRedirectUrl($redirectUrl)
            ->setLastRealOrderId($firstOrder->getIncrementId())
            ->setLastOrderStatus($firstOrder->getStatus());
        return $this;
    }

    /**
     * @return $this
     */
    public function clearMaasSession()
    {
        $this->maasSession->clearOrders();
        return $this;
    }

    /**
     * @param int $orderId
     *
     * @return $this
     */
    public function setFirstOrderId(int $orderId)
    {
        $this->maasSession->setFirstOrderId($orderId);
        return $this;
    }
}
