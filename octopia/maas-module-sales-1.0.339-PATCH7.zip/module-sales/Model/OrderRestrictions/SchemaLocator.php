<?php

namespace Maas\Sales\Model\OrderRestrictions;

use Magento\Framework\Config\SchemaLocatorInterface;
use Magento\Framework\Module\Dir;
use Magento\Framework\Module\Dir\Reader;

/**
 * Class SchemaLocator
 *
 * @package Maas\Sales\Model\OrderRestrictions
 * @codeCoverageIgnore No logic in this class
 */
class SchemaLocator implements SchemaLocatorInterface
{
    /**
     * @var string
     */
    protected $_schema = null;

    /**
     * @var string
     */
    protected $_perFileSchema = null;

    /**
     * @param Reader $moduleReader
     */
    public function __construct(Reader $moduleReader)
    {
        $this->_schema = $moduleReader->getModuleDir(Dir::MODULE_ETC_DIR, 'Maas_Sales') . '/order_restrictions.xsd';
    }

    /**
     * @return string|null
     */
    public function getSchema()
    {
        return $this->_schema;
    }

    /**
     * @return string|null
     */
    public function getPerFileSchema()
    {
        return $this->_perFileSchema;
    }
}
