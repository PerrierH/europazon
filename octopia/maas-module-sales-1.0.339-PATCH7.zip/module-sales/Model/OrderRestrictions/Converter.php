<?php

namespace Maas\Sales\Model\OrderRestrictions;

use DOMDocument;
use DOMElement;
use Magento\Framework\Config\ConverterInterface;

/**
 * Class Converter
 *
 * @package Maas\Sales\Model\OrderRestrictions
 * @codeCoverageIgnore relies on extenal XML files
 */
class Converter implements ConverterInterface
{
    const ORDER_ID_SOURCE = 'order_id_source';
    const DISABLED_PERMISSIONS = 'disabled_permissions';

    /**
     * Converts xml to appropriate array
     *
     * @param DOMDocument $dom
     *
     * @return array
     */
    public function convert($dom)
    {
        $result = [];
        $mainNode = $dom->childNodes[0];
        foreach ($this->getChildNodes($mainNode) as $pageNode) {
            $permissions = [];

            foreach ($this->getChildNodes($pageNode) as $permissionNode) {
                /** @var DOMElement $permissionNode */
                $permissions[$permissionNode->tagName] = $permissionNode->nodeValue;
            }
            /** @var DOMElement $pageNode */
            $result[$pageNode->tagName] = [
                self::ORDER_ID_SOURCE => $pageNode->getAttribute('order-id-source') ?: 'order_id',
                self::DISABLED_PERMISSIONS => $permissions
            ];
        }
        return $result;
    }

    /**
     * @param DOMElement $node
     *
     * @return array
     */
    protected function getChildNodes($node)
    {
        $nodes = [];
        foreach ($node->childNodes as $childNode) {
            if (!($childNode instanceof DOMElement)) {
                continue;
            }
            $nodes[] = $childNode;
        }
        return $nodes;
    }
}
