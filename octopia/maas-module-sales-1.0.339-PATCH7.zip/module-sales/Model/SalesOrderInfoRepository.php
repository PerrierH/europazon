<?php

namespace Maas\Sales\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Model\ResourceModel\OfferFactory;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Api\Data\SalesOrderInfoSearchResultsInterfaceFactory;
use Maas\Sales\Api\SalesOrderInfoRepositoryInterface;
use Maas\Sales\Model\ResourceModel\SalesOrderInfo;
use Maas\Sales\Model\ResourceModel\SalesOrderInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class SalesOrderInfoRepository
 * @codeCoverageIgnore
 * @package Maas\Sales\Model
 */
class SalesOrderInfoRepository extends AbstractRepository implements SalesOrderInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesOrderInfoInterface $salesOrderInfo)
    {
        return $this->_save($salesOrderInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesOrderInfoInterface $salesOrderInfo)
    {
        $this->_delete($salesOrderInfo);
    }
}
