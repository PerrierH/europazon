<?php

namespace Maas\Sales\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class SalesQuoteAddressInfo
 *
 * @package Maas\Sales\Model\ResourceModel
 * @codeCoverageIgnore
 */
class SalesQuoteAddressInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_sales_quote_address_info', 'quote_address_id');
        $this->_isPkAutoIncrement = false;
    }
}
