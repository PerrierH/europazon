<?php

namespace Maas\Sales\Model\ResourceModel\SalesQuoteAddressItemInfo;

use Maas\Sales\Model\ResourceModel\SalesQuoteAddressItemInfo as SalesQuoteAddressItemInfoResource;
use Maas\Sales\Model\SalesQuoteAddressItemInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Sales\Model\ResourceModel\SalesQuoteAddressItemInfo
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            SalesQuoteAddressItemInfo::class,
            SalesQuoteAddressItemInfoResource::class
        );
    }
}
