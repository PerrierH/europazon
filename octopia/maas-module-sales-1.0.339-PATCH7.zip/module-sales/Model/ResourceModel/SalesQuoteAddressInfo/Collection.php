<?php

namespace Maas\Sales\Model\ResourceModel\SalesQuoteAddressInfo;

use Maas\Sales\Model\ResourceModel\SalesQuoteAddressInfo as ResourceModelSalesQuoteAddressInfo;
use Maas\Sales\Model\SalesQuoteAddressInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Sales\Model\ResourceModel\SalesQuoteAddressInfo
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            SalesQuoteAddressInfo::class,
            ResourceModelSalesQuoteAddressInfo::class
        );
    }
}
