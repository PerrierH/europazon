<?php

namespace Maas\Sales\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class SalesOrderItemInfo
 *
 * @package Maas\Sales\Model\ResourceModel
 * @codeCoverageIgnore
 */
class SalesOrderItemInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_sales_order_item_info', 'order_item_id');
        $this->_isPkAutoIncrement = false;
    }
}
