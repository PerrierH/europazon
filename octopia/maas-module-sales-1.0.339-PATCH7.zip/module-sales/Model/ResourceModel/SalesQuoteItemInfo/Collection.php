<?php

namespace Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo;

use Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo as ResourceModelSalesQuoteItemInfo;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            SalesQuoteItemInfo::class,
            ResourceModelSalesQuoteItemInfo::class
        );
    }
}
