<?php

namespace Maas\Sales\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class SalesOrderInfo
 *
 * @package Maas\Sales\Model\ResourceModel
 * @codeCoverageIgnore
 */
class SalesQuoteInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_sales_quote_info', 'quote_id');
        $this->_isPkAutoIncrement = false;
    }
}
