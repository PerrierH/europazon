<?php

namespace Maas\Sales\Model\ResourceModel\SalesOrderInfo;

use Maas\Sales\Model\ResourceModel\SalesOrderInfo as ResourceModelSalesOrderInfo;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Sales\Model\ResourceModel\SalesOrderInfo
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            SalesOrderInfo::class,
            ResourceModelSalesOrderInfo::class
        );
    }
}
