<?php

namespace Maas\Sales\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class SalesOrderInfo
 *
 * @package Maas\Sales\Model\ResourceModel
 * @codeCoverageIgnore
 */
class SalesOrderInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_sales_order_info', 'order_id');
        $this->_isPkAutoIncrement = false;
    }
}
