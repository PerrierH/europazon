<?php

namespace Maas\Sales\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class SalesQuoteAddressItemInfo
 *
 * @package Maas\Sales\Model\ResourceModel
 * @codeCoverageIgnore
 */
class SalesQuoteAddressItemInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_sales_quote_address_item_info', 'quote_address_item_id');
        $this->_isPkAutoIncrement = false;
    }
}
