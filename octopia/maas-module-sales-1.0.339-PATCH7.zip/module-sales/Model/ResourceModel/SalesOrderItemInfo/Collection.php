<?php

namespace Maas\Sales\Model\ResourceModel\SalesOrderItemInfo;

use Maas\Sales\Model\ResourceModel\SalesOrderItemInfo as ResourceModelSalesOrderItemInfo;
use Maas\Sales\Model\SalesOrderItemInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Sales\Model\ResourceModel\SalesOrderItemInfo
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            SalesOrderItemInfo::class,
            ResourceModelSalesOrderItemInfo::class
        );
    }
}
