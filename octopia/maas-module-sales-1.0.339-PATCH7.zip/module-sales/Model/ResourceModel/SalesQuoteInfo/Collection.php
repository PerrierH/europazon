<?php

namespace Maas\Sales\Model\ResourceModel\SalesQuoteInfo;

use Maas\Sales\Model\ResourceModel\SalesQuoteItemInfo as ResourceModelSalesQuoteInfo;
use Maas\Sales\Model\SalesQuoteInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\Sales\Model\ResourceModel\SalesQuoteInfo
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            SalesQuoteInfo::class,
            ResourceModelSalesQuoteInfo::class
        );
    }
}
