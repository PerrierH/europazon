<?php

namespace Maas\Sales\Model;

use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Sales\Api\SalesOrderInfoRepositoryInterface;
use Maas\Sales\Api\SalesOrderItemInfoRepositoryInterface;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Seller\Api\SellerRepositoryInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Event\ManagerInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderItemInterface;

/**
 * Class RegisterOfferAndSellerDuringOrderProcess
 *
 * @package Maas\Sales\Model
 */
class RegisterOfferAndSellerDuringOrderProcess
{
    /**
     * @var SalesOrderInfoRepositoryInterface
     */
    protected $salesOrderInfoRepository;
    /**
     * @var SalesOrderItemInfoRepositoryInterface
     */
    protected $salesOrderItemInfoRepository;
    /**
     * @var SellerRepositoryInterface
     */
    protected $sellerRepository;
    /**
     * @var OfferRepositoryInterface
     */
    protected $offerRepository;

    /**
     * @var CartItemInterface[]|null
     */
    protected $quoteItems = [];
    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /**
     * @var ManagerInterface
     */
    protected $eventManager;

    /**
     * @var bool
     */
    protected $saveEnabled = true;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @param SalesOrderInfoRepositoryInterface $salesOrderInfoRepository
     * @param SalesOrderItemInfoRepositoryInterface $salesOrderItemInfoRepository
     * @param SellerRepositoryInterface $sellerRepository
     * @param OfferRepositoryInterface $offerRepository
     * @param ExtensionAttributes $extensionAttributesService
     * @param ManagerInterface $eventManager
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     */
    public function __construct(
        SalesOrderInfoRepositoryInterface     $salesOrderInfoRepository,
        SalesOrderItemInfoRepositoryInterface $salesOrderItemInfoRepository,
        SellerRepositoryInterface             $sellerRepository,
        OfferRepositoryInterface              $offerRepository,
        ExtensionAttributes                   $extensionAttributesService,
        ManagerInterface                      $eventManager,
        SearchCriteriaBuilder                 $searchCriteriaBuilder,
        FilterBuilder                         $filterBuilder
    )
    {
        $this->salesOrderInfoRepository = $salesOrderInfoRepository;
        $this->salesOrderItemInfoRepository = $salesOrderItemInfoRepository;
        $this->sellerRepository = $sellerRepository;
        $this->offerRepository = $offerRepository;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->eventManager = $eventManager;
        $this->saveEnabled = true;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * @param OrderInterface $order
     * @param CartInterface $quote
     *
     * @dataProvider eventDataReturnProvider
     */
    public function validateOrderData(OrderInterface $order, CartInterface $quote)
    {
        foreach ($order->getItems() as $orderItem) {
            $quoteItem = $this->getCartItemFromOrderItem($orderItem, $quote);
            $extraInfo = $this->extensionAttributesService->getQuoteItemExtensionAttributes($quoteItem)->getExtraInfo();
            // @TODO store original taxes in maas_quote_item
            $this->insertDataOrderInfoItem(
                $orderItem,
                array_merge(
                    $extraInfo->getData(),
                    ['original_taxes' => $quoteItem->getProduct()->getData('maas_original_taxes')]
                )
            );
            $this->eventManager->dispatch('maas_sales_quote_item_to_order_item_copy', [
                'order_item' => $orderItem,
                'quote_item' => $quoteItem
            ]);
            if ($orderItem->getOriginalPrice() == 0) {
                $orderItem->setOriginalPrice($orderItem->getProduct()->getPrice());
            }
        }
        $this->insertDataOrderInfo($order, $extraInfo->getData());
    }

    /**
     * @param OrderInterface $order
     * @param array $sellerData
     */
    protected function insertDataOrderInfo(
        OrderInterface $order,
        array $itemData
    ) {
        $orderExtension = $this->extensionAttributesService->getOrderExtensionAttributes($order);
        $extraInfo = $orderExtension->getExtraInfo();
        $extraInfo->setOrderId($order->getEntityId());
        if (array_key_exists('seller_maas_id', $itemData) && $itemData['seller_maas_id']) {
            $extraInfo
                ->setOrderType(SalesOrderInfo::ORDER_TYPE_MAAS)
                ->setSellerId($itemData['seller_id'])
                ->setSellerMaasId($itemData['seller_maas_id'])
                ->setSellerName($itemData['seller_name']);
        } else {
            $extraInfo->setOrderType(SalesOrderInfo::ORDER_TYPE_CORE);
        }
        $order->setExtensionAttributes($orderExtension);
        if ($this->saveEnabled) {
            $this->salesOrderInfoRepository->save($extraInfo);
        }
    }

    /**
     * @param OrderItemInterface $orderItem
     * @param array $itemData
     */
    protected function insertDataOrderInfoItem(
        OrderItemInterface $orderItem,
        array $itemData
    ) {
        $orderItemExtension = $this->extensionAttributesService->getOrderItemExtensionAttributes($orderItem);
        $extraInfo = $orderItemExtension->getExtraInfo();

        $extraInfo->setItemId($orderItem->getItemId());

        if (array_key_exists('original_taxes', $itemData)) {
            $extraInfo
                ->setOriginalTaxes($itemData['original_taxes']);
        }

        if (array_key_exists('offer_maas_id', $itemData)) {
            $extraInfo
                ->setOfferId($itemData['offer_id'])
                ->setOfferMaasId($itemData['offer_maas_id'])
                ->setCondition($itemData['condition']);
        }

        if (array_key_exists('seller_maas_id', $itemData)) {
            $extraInfo
                ->setSellerId($itemData['seller_id'])
                ->setSellerMaasId($itemData['seller_maas_id'])
                ->setSellerName($itemData['seller_name']);
        }

        $extraInfo->setOriginalPrice($orderItem->getProduct()->getFinalPrice())
            ->setBaseOriginalPrice($orderItem->getProduct()->getFinalPrice());

        $orderItem->setExtensionAttributes($orderItemExtension);
        if ($this->saveEnabled) {
            $this->salesOrderItemInfoRepository->save($extraInfo);
        }
    }

    /**
     * @param OrderItemInterface $orderItem
     * @param CartInterface $quote
     *
     * @return CartItemInterface|mixed|null
     */
    protected function getCartItemFromOrderItem(OrderItemInterface $orderItem, CartInterface $quote)
    {
        foreach ($quote->getAllItems() as $cartItem) {
            if ($orderItem->getQuoteItemId() == $cartItem->getItemId()) {
                return $cartItem;
            }
        }
        return null;
    }

    /**
     * @return bool
     */
    public function getSaveEnabled()
    {
        return $this->saveEnabled;
    }

    /**
     * @param bool $saveEnabled
     *
     * @return $this
     */
    public function setSaveEnabled($saveEnabled)
    {
        $this->saveEnabled = $saveEnabled;
        return $this;
    }
}
