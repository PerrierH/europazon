<?php

namespace Maas\Sales\Model;

use Magento\Framework\App\Request\Http;
use Magento\Framework\App\State;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\SessionException;
use Magento\Framework\Session\Config\ConfigInterface;
use Magento\Framework\Session\SaveHandlerInterface;
use Magento\Framework\Session\SessionManager;
use Magento\Framework\Session\SessionStartChecker;
use Magento\Framework\Session\SidResolverInterface;
use Magento\Framework\Session\StorageInterface;
use Magento\Framework\Session\ValidatorInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\View\Element\Block\ArgumentInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\OrderRepository;

/**
 * Class Session
 *
 * @package Maas\Sales\Model
 */
class Session extends SessionManager implements ArgumentInterface
{

    /** @var OrderRepository */
    protected $orderRepository;

    /**
     * @var array
     */
    protected $orders = [];

    /**
     * @param Http $request
     * @param SidResolverInterface $sidResolver
     * @param ConfigInterface $sessionConfig
     * @param SaveHandlerInterface $saveHandler
     * @param ValidatorInterface $validator
     * @param StorageInterface $storage
     * @param CookieManagerInterface $cookieManager
     * @param CookieMetadataFactory $cookieMetadataFactory
     * @param State $appState
     * @param SessionStartChecker|null $sessionStartChecker
     * @param OrderRepository $orderRepository
     *
     * @throws SessionException
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Http $request,
        SidResolverInterface $sidResolver,
        ConfigInterface $sessionConfig,
        SaveHandlerInterface $saveHandler,
        ValidatorInterface $validator,
        StorageInterface $storage,
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        State $appState,
        OrderRepository $orderRepository,
        SessionStartChecker $sessionStartChecker = null
    ) {
        parent::__construct(
            $request,
            $sidResolver,
            $sessionConfig,
            $saveHandler,
            $validator,
            $storage,
            $cookieManager,
            $cookieMetadataFactory,
            $appState,
            $sessionStartChecker
        );
        $this->orderRepository = $orderRepository;
    }

    /**
     * Add an order to the orders' list
     *
     * @param OrderInterface $order
     */
    public function addOrder(OrderInterface $order)
    {
        $ordersIds = $this->storage->getData('orders');
        if ($ordersIds == null) {
            $ordersIds = [];
        }
        if (!in_array($order->getIncrementId(), $ordersIds)) {
            $ordersIds[$order->getId()] = $order->getIncrementId();
        }
        $this->storage->setData('orders', $ordersIds);
    }

    /**
     * set orders list
     *
     * @param array $ordersIds
     */
    public function setOrders(array $ordersIds)
    {
        $this->storage->setData('orders', $ordersIds);
    }


    /**
     * get orders ids list
     *
     * @return array
     */
    public function getOrdersIds()
    {
        return $this->storage->getData('orders');
    }

    /**
     * Returns true if there is more than one order in the list
     *
     * @return bool
     */
    public function hasMultipleOrders()
    {
        if ($this->getOrders() == null) {
            return false;
        }
        return (count($this->getOrders()) > 1);
    }

    /**
     * Return the orders' list
     *
     * @return OrderInterface[]
     */
    public function getOrders()
    {
        $orderIds = $this->getOrdersIds();
        if ($orderIds) {
            foreach ($orderIds as $orderId => $orderIncrementId) {
                if (!array_key_exists($orderId, $this->orders)) {
                    try {
                        $this->orders[$orderId] = $this->orderRepository->get($orderId);
                    } catch (\Exception $e) {
                        //Do noting
                    }
                }
            }
        }

        return $this->orders;
    }

    /**
     * Clear the stored orders list
     *
     * @return $this
     */
    public function clearOrders()
    {
        $this->storage->setData('orders', null);
        $this->storage->setData('firstOrderId', null);
        return $this;
    }

    /**
     * @param int $orderId
     *
     * @return $this
     */
    public function setFirstOrderId(int $orderId)
    {
        $this->storage->setData('firstOrderId', $orderId);
        return $this;
    }

    /**
     * @return mixed
     */
    public function getFirstOrderId()
    {
        return $this->storage->getData('firstOrderId');
    }

    /**
     * @return OrderInterface
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function getFirstOrder()
    {
        return $this->orderRepository->get($this->getFirstOrderId());
    }

    /**
     * Clear all information about original cart
     *
     * @return $this
     */
    public function unsOriginalCartId()
    {
        $this->storage->setData('original_cart_id', null);
        $this->storage->setData('original_cart_items', null);
        return $this;
    }


    /**
     * Check if the session has original cart id
     *
     * @return bool
     */
    public function hasOriginalCartId()
    {
        return $this->storage->hasData('original_cart_id');
    }

    /**
     * Get the original cart id
     *
     * @return int
     */
    public function getOriginalCartId()
    {
        return $this->storage->getData('original_cart_id');
    }

    /**
     * Store the original cart id in the session
     *
     * @param int $cartId
     * @return $this
     */
    public function setOriginalCartId($cartId)
    {
        $this->storage->setData('original_cart_id', $cartId);
        return $this;
    }
}
