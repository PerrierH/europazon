<?php

namespace Maas\Sales\Model;

use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteAddressItemInfo as SalesQuoteAddressItemInfoResource;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesQuoteAddressItemInfo
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
class SalesQuoteAddressItemInfo extends AbstractModel implements SalesQuoteAddressItemInfoInterface
{
    use SalesQuoteItemTrait;

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(SalesQuoteAddressItemInfoResource::class);
    }
}
