<?php

namespace Maas\Sales\Model;

use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Model\ResourceModel\SalesOrderItemInfo as MSalesOrderItemInfo;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesOrderItemInfo
 * @package Maas\Sales\Model
 */
class SalesOrderItemInfo extends AbstractModel implements SalesOrderItemInfoInterface
{
    /**
     * @inheritDoc
     */
    public function getOfferId()
    {
        return $this->getData(self::OFFER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setOfferId($offerId)
    {
        return $this->setData(self::OFFER_ID, $offerId);
    }

    /**
     * @inheritDoc
     */
    public function getSellerId()
    {
        return $this->getData(self::SELLER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * @inheritDoc
     */
    public function getOfferMaasId()
    {
        return $this->getData(self::OFFER_MASS_ID);
    }

    /**
     * @inheritDoc
     */
    public function setOfferMaasId($maasOfferId)
    {
        return $this->setData(self::OFFER_MASS_ID, $maasOfferId);
    }

    /**
     * @inheritDoc
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * @inheritDoc
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * @inheritDoc
     */
    public function getShippingMethod()
    {
        return $this->getData(self::SHIPPING_METHOD);
    }

    /**
     * @inheritDoc
     */
    public function setShippingMethod($shippingMethod)
    {
        return $this->setData(self::SHIPPING_METHOD, $shippingMethod);
    }

    /**
     * @inheritDoc
     */
    public function getShippingAmount()
    {
        return $this->getData(self::SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setShippingAmount($shippingAmount)
    {
        return $this->setData(self::SHIPPING_AMOUNT, $shippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getOriginalShippingAmount()
    {
        return $this->getData(self::ORIGINAL_SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setOriginalShippingAmount($originalShippingAmount)
    {
        return $this->setData(self::ORIGINAL_SHIPPING_AMOUNT, $originalShippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getDiscountedShippingAmount()
    {
        return $this->getData(self::DISCOUNTED_SHIPPING_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function setDiscountedShippingAmount($discountedShippingAmount)
    {
        return $this->setData(self::DISCOUNTED_SHIPPING_AMOUNT, $discountedShippingAmount);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryDateMin()
    {
        return $this->getData(self::DELIVERY_DATE_MIN);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryDateMin($deliveryDateMin)
    {
        return $this->setData(self::DELIVERY_DATE_MIN, $deliveryDateMin);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryDateMax()
    {
        return $this->getData(self::DELIVERY_DATE_MAX);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryDateMax($deliveryDateMax)
    {
        return $this->setData(self::DELIVERY_DATE_MAX, $deliveryDateMax);
    }

    /**
     * @return string
     */
    public function getOriginalTaxes()
    {
        return $this->getData(self::ORIGINAL_TAXES);
    }

    /**
     * @param string $originalTaxes
     *
     * @return $this
     */
    public function setOriginalTaxes($originalTaxes)
    {
        return $this->setData(self::ORIGINAL_TAXES, $originalTaxes);
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(MSalesOrderItemInfo::class);
    }
}
