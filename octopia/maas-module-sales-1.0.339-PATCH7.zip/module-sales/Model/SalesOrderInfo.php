<?php

namespace Maas\Sales\Model;

use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Sales\Model\ResourceModel\SalesOrderInfo as MSalesOrderInfo;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesOrderInfo
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
class SalesOrderInfo extends AbstractModel implements SalesOrderInfoInterface
{
    const ORDER_TYPE_CORE = 1;
    const ORDER_TYPE_MAAS = 2;

    /**
     * @inheritDoc
     */
    public function getSellerId()
    {
        return $this->getData(self::SELLER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * @inheritDoc
     */
    public function getSellerMaasId()
    {
        return $this->getData(self::MAAS_SELLER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSellerMaasId($maasSellerId)
    {
        return $this->setData(self::MAAS_SELLER_ID, $maasSellerId);
    }

    /**
     * @inheritDoc
     */
    public function getMaasSellerName()
    {
        return $this->getData(self::MAAS_SELLER_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setMaasSellerName($maasSellerName)
    {
        return $this->setData(self::MAAS_SELLER_NAME, $maasSellerName);
    }

    /**
     * @inheritDoc
     */
    public function getOrderType()
    {
        return $this->getData(self::MAAS_ORDER_TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setOrderType($orderType)
    {
        return $this->setData(self::MAAS_ORDER_TYPE, $orderType);
    }

    /**
     * @inheritDoc
     */
    public function getMainOrderId()
    {
        return $this->getData(self::MAIN_ORDER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setMainOrderId($mainOrderId)
    {
        return $this->setData(self::MAIN_ORDER_ID, $mainOrderId);
    }

    /**
     * @inheritDoc
     */
    public function getMainOrderIncrementId()
    {
        return $this->getData(self::MAIN_ORDER_INCREMENT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setMainOrderIncrementId($mainOrderIncrementId)
    {
        return $this->setData(self::MAIN_ORDER_INCREMENT_ID, $mainOrderIncrementId);
    }

    /**
     * @inheritDoc
     */
    public function getExported()
    {
        return $this->getData(self::EXPORTED);
    }

    /**
     * @inheritDoc
     */
    public function setExported($exported)
    {
        return $this->setData(self::EXPORTED, $exported);
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(MSalesOrderInfo::class);
    }

    /**
     * @inheritDoc
     */
    public function getOctopiaPaymentCode()
    {
        return $this->getData(self::OCTOPIA_PAYMENT_CODE);
    }

    /**
     * @inheritDoc
     */
    public function setOctopiaPaymentCode($octopiaPaymentCode)
    {
        return $this->setData(self::OCTOPIA_PAYMENT_CODE, $octopiaPaymentCode);
    }
}
