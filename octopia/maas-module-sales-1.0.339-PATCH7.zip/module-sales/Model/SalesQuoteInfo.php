<?php

namespace Maas\Sales\Model;

use Maas\Sales\Api\Data\SalesQuoteInfoInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteInfo as MSalesQuoteInfo;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesQuoteInfo
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore
 */
class SalesQuoteInfo extends AbstractModel implements SalesQuoteInfoInterface
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(MSalesQuoteInfo::class);
    }

    public function getOriginalQuoteId() : int
    {
        return $this->getData(static::ORIGINAL_QUOTE_ID);
    }

    public function setOriginalQuoteId(int $originalQuoteId) : SalesQuoteInfo
    {
        return $this->setData(static::ORIGINAL_QUOTE_ID, $originalQuoteId);
    }
}
