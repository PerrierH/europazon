<?php

namespace Maas\Sales\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;
use Magento\Sales\Model\ResourceModel\Order\Status\CollectionFactory;

/**
 * Class Status
 *
 * @package Maas\Sales\Model\Config\Source
 */
class Status implements ArrayInterface
{
    /**
     * @var CollectionFactory
     */
    protected $statusCollectionFactory;

    /**
     * Status constructor.
     *
     * @param CollectionFactory $statusCollectionFactory
     */
    public function __construct(
        CollectionFactory $statusCollectionFactory
    ) {
        $this->statusCollectionFactory = $statusCollectionFactory;
    }

    /**
     * Get status options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options = $this->statusCollectionFactory->create()->toOptionArray();
        $key = array_search('pending', array_column($options, 'value'));
        if ($key === false) {
            array_unshift($options, ['value' => "", 'label' => ""]);
        }
        return $options;
    }
}
