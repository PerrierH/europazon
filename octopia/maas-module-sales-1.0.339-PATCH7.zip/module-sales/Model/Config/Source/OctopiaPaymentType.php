<?php

namespace Maas\Sales\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Status
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Model\Config\Source
 */
class OctopiaPaymentType implements ArrayInterface
{

    const TYPE_CARD = 'Card';
    const TYPE_SEPA = 'Sepa';
    const TYPE_OUTSTANDING = 'Outstanding';
    const TYPE_CHECK = 'Check';
    const TYPE_CASHONDELIVERY = 'CashOnDelivery';

    /**
     * Get Octopia Payment Type options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => '',
                'value' => null
            ],
            [
                'label' => __(self::TYPE_CARD),
                'value' => self::TYPE_CARD
            ],
            [
                'label' => __(self::TYPE_SEPA),
                'value' => self::TYPE_SEPA
            ],
            [
                'label' => __(self::TYPE_OUTSTANDING),
                'value' => self::TYPE_OUTSTANDING
            ],
            [
                'label' => __(self::TYPE_CHECK),
                'value' => self::TYPE_CHECK
            ],
            [
                'label' => __(self::TYPE_CASHONDELIVERY),
                'value' => self::TYPE_CASHONDELIVERY
            ]
        ];
    }
}
