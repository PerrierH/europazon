<?php

namespace Maas\Sales\Model\Config\Source;

use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class Status
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Model\Config\Source
 */
class OrderType implements ArrayInterface
{

    /**
     * Get status options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'label' => __('Core'),
                'value' => SalesOrderInfo::ORDER_TYPE_CORE
            ],
            [
                'label' => __('Octopia'),
                'value' => SalesOrderInfo::ORDER_TYPE_MAAS
            ]
        ];
    }
}
