<?php

namespace Maas\Sales\Model\Config\Backend;

use Magento\Config\Model\Config\Backend\Serialized\ArraySerialized;

/**
 * Class PaymentMethodsCommaArrays
 *
 * @package Maas\Sales\Model\Config\Backend
 */
class PaymentMethodsMatchingCommaArrays extends ArraySerialized
{
    /**
     * Unset array element with '__empty' key
     *
     * @return $this
     * @codeCoverageIgnore delegates to other methods
     */
    public function beforeSave()
    {
        $this->flattenStatusValues();
        return parent::beforeSave();
    }

    protected function flattenStatusValues()
    {
        $value = $this->getValue();
        foreach ($value as $rowId => $data) {
            if (isset($data['octopia_payment_code']) && is_array($data['octopia_payment_code'])) {
                $data['octopia_payment_code'] = implode(',', $data['octopia_payment_code']);
            }
            $value[$rowId] = $data;
        }
        $this->setValue($value);
    }
}