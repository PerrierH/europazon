<?php

namespace Maas\Sales\Model\Config\Backend;

use Magento\Config\Model\Config\Backend\Serialized\ArraySerialized;

/**
 * Class PaymentMethodsCommaArrays
 *
 * @package Maas\Sales\Model\Config\Backend
 */
class PaymentMethodsStatusCommaArrays extends ArraySerialized
{
    /**
     * Unset array element with '__empty' key
     *
     * @return $this
     * @codeCoverageIgnore delegates to other methods
     */
    public function beforeSave()
    {
        $this->flattenStatusValues();
        return parent::beforeSave();
    }

    protected function flattenStatusValues()
    {
        $value = $this->getValue();
        foreach ($value as $rowId => $data) {
            if (isset($data['status']) && is_array($data['status'])) {
                $data['status'] = implode(',', $data['status']);
            }
            $value[$rowId] = $data;
        }
        $this->setValue($value);
    }
}