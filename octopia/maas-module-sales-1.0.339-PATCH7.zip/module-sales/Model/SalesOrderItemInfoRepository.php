<?php

namespace Maas\Sales\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Model\ResourceModel\OfferFactory;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoSearchResultsInterfaceFactory;
use Maas\Sales\Api\SalesOrderItemInfoRepositoryInterface;
use Maas\Sales\Model\ResourceModel\SalesOrderItemInfo;
use Maas\Sales\Model\ResourceModel\SalesOrderItemInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class OfferRepository
 *
 * @package Maas\Offer\Model
 * @codeCoverageIgnore
 */
class SalesOrderItemInfoRepository extends AbstractRepository implements SalesOrderItemInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesOrderItemInfoInterface $salesOrderInfo)
    {
        return $this->_save($salesOrderInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesOrderItemInfoInterface $salesOrderInfo)
    {
        $this->_delete($salesOrderInfo);
    }
}
