<?php

namespace Maas\Sales\Helper;

use Maas\Sales\Model\Service\OrderType;

/**
 * Class Data
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /** @var OrderType */
    private $orderTypeService;

    /**
     * Data constructor.
     *
     * @param Context $context
     * @param OrderType $orderTypeService
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        OrderType $orderTypeService
    ){
        parent::__construct($context);
        $this->orderTypeService = $orderTypeService;
    }

    /**
     * @return string
     */
    public function getCustomLabelProperties($order)
    {
        if($this->isRenderSellerName($order) && $this->isOrderMarketplace($order)){
            $colspan = 6;
        }elseif ($this->isRenderSellerName($order) || $this->isOrderMarketplace($order)){
            $colspan = 5;
        }else{
            $colspan = 4;
        }
        return "colspan='$colspan' class='mark'";
    }

    /**
     * @return bool
     */
    public function isRenderSellerName($order)
    {
        return $this->orderTypeService->isOrderMarketplace($order);
    }

    /**
     * @return bool
     */
    public function isOrderMarketplace($order)
    {
        return $this->orderTypeService->isOrderMarketplace($order);
    }
}
