# Maas InternationalTelephoneInput
## Purpose

A module used to manage the insertion of international telephone numbers.
