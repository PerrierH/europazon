<?php

namespace Maas\InternationalTelephoneInput\Plugin\Block\Checkout;

use Magento\Checkout\Block\Checkout\LayoutProcessor as MageLayoutProcessor;
use Maas\InternationalTelephoneInput\Model\Config;

/**
 * Class LayoutProcessor
 */
class LayoutProcessor
{
    /**
     * @var Config
     */
    protected $config;

    /**
     * @param Config $config
     */
    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    /**
     * @param MageLayoutProcessor $subject
     * @param $jsLayout
     * @return array
     */
    public function afterProcess(MageLayoutProcessor $subject, $jsLayout): array
    {
        if (isset($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children']
        )) {
            $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children']
            ['telephone'] = $this->config->telephoneFieldConfig("shippingAddress");
        }

        /* config: checkout/options/display_billing_address_on = payment_method */
        if (isset($jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
            ['payment']['children']['payments-list']['children']
        )) {
            $paymentMethodRenders = $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']
            ['children']['payment']['children']['payments-list']['children'];
            if (\is_array($paymentMethodRenders)) {
                foreach ($paymentMethodRenders as $name => $renderer) {

                    if (isset($renderer['children']) && array_key_exists('form-fields', $renderer['children'])) {
                        $method = substr($name, 0, -5);

                        /* telephone */
                        $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
                        ['payment']['children']['payments-list']['children'][$name]['children']['form-fields']['children']
                        ['telephone'] = $this->config->telephoneFieldConfig("billingAddress", $method);
                    }
                }
            }
        }

        /* config: checkout/options/display_billing_address_on = payment_page */
        if (isset($jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
            ['payment']['children']['afterMethods']['children']['billing-address-form']
        )) {

            $method = 'shared';

            /* telephone */
            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
            ['payment']['children']['payments-list']['children'][$key]['children']['form-fields']['children']
            ['telephone'] = $this->config->telephoneFieldConfig("billingAddress", $method);
        }

        return $jsLayout;
    }
}
