<?php

namespace Maas\InternationalTelephoneInput\Plugin\Model\Address\Validator;

use Magento\Customer\Model\Address\AbstractAddress;
use Magento\Customer\Model\Address\Validator\General as MagentoGeneral;

/**
 * Class General
 * @codeCoverageIgnore
 * @package Maas\InternationalTelephoneInput\Plugin\Model\Address\Validator
 */
class General
{
    /**
     * @param MagentoGeneral $subject
     * @param $result
     * @param AbstractAddress $address
     *
     * @return array
     */
    public function afterValidate(MagentoGeneral $subject, $result, AbstractAddress $address)
    {
        return array_merge(
            $result,
            $this->validatePhone($address)
        );
    }

    /**
     * @param AbstractAddress $address
     *
     * @return array
     */
    private function validatePhone(AbstractAddress $address)
    {
        $errors = [];
        if (
            strpos($address->getTelephone(), '+') !== 0 ||
            strpos($address->getTelephone(), '+') === false
        ) {
            $errors[] = __('The country code is mandatory in field "%fieldName".', ['fieldName' => 'telephone']);
        }
        return $errors;
    }
}
