define([
    'jquery',
    'Magento_Ui/js/lib/validation/utils'
], function ($, utils) {
    'use strict';

    return function () {
        $.validator.addMethod(
            'pattern-phone',
            function (value) {
                return utils.isEmpty(value) || /^\+/.test(value);
            },
            $.mage.__('The country code is mandatory in field phone')
        )
    }
});
