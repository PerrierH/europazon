define([
    'jquery',
    'Magento_Ui/js/lib/validation/utils',
    'moment',
], function ($, utils, moment) {
    'use strict';

    return function (validator) {

        validator.addRule(
            'pattern-phone',
            function (value, param) {
                return utils.isEmpty(value) || new RegExp(param).test(value);
            },
            $.mage.__("The country code is mandatory in field phone.")
        );

        return validator;
    };
});
