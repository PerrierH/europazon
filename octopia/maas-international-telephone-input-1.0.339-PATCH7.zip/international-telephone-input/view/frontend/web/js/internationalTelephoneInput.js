define([
    'jquery',
    'intlTelInput'
], function ($) {
    return function (config, node) {
        const nodeElement = $(node);
        nodeElement.intlTelInput(config);

        nodeElement.blur(function(){
            nodeElement.intlTelInput("setNumber", nodeElement.val());
        });
    };
});
