var config = {
    config: {
        mixins: {
            'Magento_Ui/js/lib/validation/validator': {
                'Maas_InternationalTelephoneInput/js/validator-mixin': true
            },
            'mage/validation': {
                'Maas_InternationalTelephoneInput/js/account/validation-mixin': true
            }
        }
    },
    paths: {
        "intlTelInput": 'Maas_InternationalTelephoneInput/js/intlTelInput',
        "intlTelInputUtils": 'Maas_InternationalTelephoneInput/js/utils',
        "internationalTelephoneInput": 'Maas_InternationalTelephoneInput/js/internationalTelephoneInput'
    },

    shim: {
        'intlTelInput': {
            'deps': ['jquery', 'knockout']
        },
        'internationalTelephoneInput': {
            'deps': ['jquery', 'intlTelInput']
        }
    }
};
