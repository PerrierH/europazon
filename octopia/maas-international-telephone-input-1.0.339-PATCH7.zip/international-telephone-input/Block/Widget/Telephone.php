<?php

namespace Maas\InternationalTelephoneInput\Block\Widget;

/**
 * Class Telephone
 * @codeCoverageIgnore
 * @package Maas\InternationalTelephoneInput\Block\Widget
 */
class Telephone extends \Magento\Customer\Block\Widget\Telephone
{

    /**
     * @return void
     */
    public function _construct()
    {
        parent::_construct();

        // default template location
        $this->setTemplate('Maas_InternationalTelephoneInput::widget/telephone.phtml');
    }

}
