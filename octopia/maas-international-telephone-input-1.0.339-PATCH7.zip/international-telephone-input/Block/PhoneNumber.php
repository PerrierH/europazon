<?php
namespace Maas\InternationalTelephoneInput\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Serialize\Serializer\Json;
use Maas\InternationalTelephoneInput\Model\Config;
use Magento\Directory\Api\CountryInformationAcquirerInterface;

/**
 * Class PhoneNumber
 *
 * @package Maas\InternationalTelephoneInput\Block
 * @codeCoverageIgnore
 */
class PhoneNumber extends Template
{

    /**
     * @var Json
     */
    protected $jsonHelper;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var CountryInformationAcquirerInterface
     */
    protected $countryInformation;

    /**
     * PhoneNumber constructor.
     *
     * @param Context $context
     * @param Json $jsonHelper
     * @param CountryInformationAcquirerInterface $countryInformation
     * @param Config $config
     */
    public function __construct(
        Context $context,
        Json $jsonHelper,
        CountryInformationAcquirerInterface $countryInformation,
        Config $config
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->config = $config;
        $this->countryInformation = $countryInformation;
        parent::__construct($context);
    }

    /**
     * @return bool|string
     */
    public function phoneConfig()
    {
        $phoneConfig = [
            "nationalMode" => false,
            "utilsScript" => $this->getViewFileUrl('Maas_InternationalTelephoneInput::js/utils.js'),
            "preferredCountries" => [$this->config->preferedCountry()]
        ];

        if ($this->config->allowedCountries()) {
            $phoneConfig["onlyCountries"] = explode(",", $this->config->allowedCountries());
        }

        return $this->jsonHelper->serialize($phoneConfig);
    }
}
