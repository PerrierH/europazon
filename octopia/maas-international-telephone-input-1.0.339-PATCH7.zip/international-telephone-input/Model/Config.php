<?php

namespace Maas\InternationalTelephoneInput\Model;

use Maas\Core\Model\Config as CoreConfig;

/**
 * Class Config
 *
 * @package Maas\InternationalTelephoneInput\Model\Service
 * @codeCoverageIgnore
 */
class Config extends CoreConfig
{
    const XML_PATH_INTERNATIONAL_TELEPHONE_MULTISELECT_COUNTRIES_ALLOWED = 'maas_offers/advanced/allowed_countries';

    const XML_PATH_PREFERED_COUNTRY = 'general/country/default';


    /**
     * @return mixed
     */
    public function allowedCountries()
    {
        return $this->getValue(self::XML_PATH_INTERNATIONAL_TELEPHONE_MULTISELECT_COUNTRIES_ALLOWED);
    }

    /**
     * @return mixed
     */
    public function preferedCountry()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_PREFERED_COUNTRY);
    }

    /**
     * Prepare telephone field config according to the Magento default config
     *
     * @param $addressType
     * @param string $method
     *
     * @return array
     */
    public function telephoneFieldConfig($addressType, $method = '')
    {
        return [
            'component' => 'Magento_Ui/js/form/element/abstract',
            'config' => [
                'customScope' => $addressType . $method,
                'customEntry' => null,
                'template' => 'ui/form/field',
                'elementTmpl' => 'Maas_InternationalTelephoneInput/form/element/telephone',
                'tooltip' => [
                    'description' => 'For delivery questions.',
                    'tooltipTpl' => 'ui/form/element/helper/tooltip'
                ],
            ],
            'dataScope' => $addressType . $method . '.telephone',
            'dataScopePrefix' => $addressType . $method,
            'label' => __('Phone Number'),
            'provider' => 'checkoutProvider',
            'sortOrder' => 120,
            'validation' => [
                "required-entry" => true,
                "max_text_length" => 255,
                "min_text_length" => 1,
                "pattern-phone" => '^\+'
            ],
            'options' => [],
            'filterBy' => null,
            'customEntry' => null,
            'visible' => true,
            'focused' => false,
        ];
    }
}
