<?php

namespace Maas\Checkout\Test\Unit\Block\Checkout;

use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Magento\Quote\Model\Quote\TotalsCollector;
use Magento\Quote\Model\Quote\TotalsReader;
use Magento\Tax\Helper\Data;
use Maas\Checkout\Block\Checkout\Overview;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Item;
use Magento\Catalog\Model\Product;
use PHPUnit\Framework\TestCase;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Api\Data\ProductInterface;

class OverviewTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $multishipping;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $taxHelper;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $priceCurrency;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $totalsCollector;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $totalsReader;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /** @var ProductInterface */
    private $product;
    /** @var ProductRepository */
    private $productRepository;
    /** @var Address */
    private $quoteAddress;
    /**
     * @var Overview
     */
    private $stub;

    private $productSellerName = null;

    public function initTest($isEnable = false, $items = [])
    {
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->multishipping = AnyBuilder::createForClass($this, Multishipping::class)->build();
        $this->taxHelper = AnyBuilder::createForClass($this, Data::class)->build();
        $this->priceCurrency = AnyBuilder::createForClass($this, PriceCurrencyInterface::class)->build();
        $this->totalsCollector = AnyBuilder::createForClass($this, TotalsCollector::class)->build();
        $this->totalsReader = AnyBuilder::createForClass($this, TotalsReader::class)->build();
        $this->configModel = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->any(), $isEnable]
        ])->build();
        $this->product = AnyBuilder::createForClass(
            $this,
            ProductInterface::class,
            [
                'getMaasOfferSellerName' => [
                    $this->any(),
                    function () {
                        return $this->productSellerName;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->productRepository = AnyBuilder::createForClass(
            $this,
            ProductRepository::class,
            [
                'getById' => [
                    $this->any(),
                    function () {
                        return $this->product;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->quoteAddress = AnyBuilder::createForClass($this, Address::class)->build();

        $this->stub = $this->getMockBuilder(Overview::class)
            ->setConstructorArgs([
                $this->context,
                $this->multishipping,
                $this->taxHelper,
                $this->priceCurrency,
                $this->totalsCollector,
                $this->totalsReader,
                $this->configModel,
                $this->productRepository,
                []
            ])
            ->setMethods(['getShippingAddressItems'])
            ->getMock();
        $this->stub->expects($this->any())->method('getShippingAddressItems')->willReturn($items);
    }

    /**
     * @dataProvider shouldDisplaySellerNameProvider
     */
    public function testShouldDisplaySellerName($isModuleEnabled, $items, $sellerName, $expected){
        $this->initTest($isModuleEnabled, $items);
        $this->productSellerName= $sellerName;

        $result = $this->stub->shouldDisplaySellerName($this->quoteAddress);

        $this->assertEquals($expected, $result);
    }

    public function shouldDisplaySellerNameProvider(){
        $product = AnyBuilder::createForClass($this, Product::class, [
            'getId' => [$this->any(), 1]
        ])->build();
        $item = AnyBuilder::createForClass($this, Item::class, [
            'getProduct' => [$this->any(), $product]
        ])->build();
        yield from [
            'Module not enabled' => [false, [], null, false],
            'Module enabled, no seller name' => [true, [$item], null, false],
            'Module enabled, no seller name' => [true, [$item], 'Test Vendor', true]
        ];
    }
}
