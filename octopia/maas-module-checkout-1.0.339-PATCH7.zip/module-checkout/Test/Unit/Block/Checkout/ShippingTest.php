<?php

namespace Maas\Checkout\Test\Unit\Block\Checkout;

use Maas\Checkout\Block\Checkout\Shipping;
use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Filter\DataObject\GridFactory;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Magento\Quote\Model\Quote\Item;
use Magento\Tax\Helper\Data;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

class ShippingTest extends TestCase
{
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $multishipping;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $taxHelper;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $priceCurrency;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $gridFactory;
    /** @var ProductInterface */
    private $product;
    /** @var ProductRepository */
    private $productRepository;
    /**
     * @var Shipping
     */
    private $stub;

    private $productSellerName = null;

    public function testConfigDisable()
    {
        $this->initTest();
        $item = AnyBuilder::createForClass($this, Item::class, [
            'getProduct' => [$this->never()]
        ])->build();
        $this->stub->displaySellerNameMultishipping($item);
    }

    public function initTest($isEnable = false)
    {
        $this->context = AnyBuilder::createForClass($this, Context::class)->build();
        $this->gridFactory = AnyBuilder::createForClass($this, GridFactory::class)->build();
        $this->multishipping = AnyBuilder::createForClass($this, Multishipping::class)->build();
        $this->taxHelper = AnyBuilder::createForClass($this, Data::class)->build();
        $this->priceCurrency = AnyBuilder::createForClass($this, PriceCurrencyInterface::class)->build();
        $this->configModel = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->any(), $isEnable]
        ])->build();
        $this->product = AnyBuilder::createForClass(
            $this,
            ProductInterface::class,
            [
                'getMaasOfferSellerName' => [
                    $this->any(),
                    function () {
                        return $this->productSellerName;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->productRepository = AnyBuilder::createForClass(
            $this,
            ProductRepository::class,
            [
                'getById' => [
                    $this->any(),
                    function () {
                        return $this->product;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->stub = new Shipping(
            $this->context,
            $this->gridFactory,
            $this->multishipping,
            $this->taxHelper,
            $this->priceCurrency,
            $this->configModel,
            $this->productRepository,
            []
        );
    }

    public function testConfigEnableAndNoSellerId()
    {
        $this->initTest(true);
        $product = AnyBuilder::createForClass($this, Product::class, [])->build();

        $item = AnyBuilder::createForClass($this, Item::class, [
            'getProduct' => [$this->any(), $product],
            'getSellerId' => [$this->once(), false]
        ])->build();
        $this->stub->displaySellerNameMultishipping($item);
    }

    public function testConfigEnableAndSellerId()
    {
        $this->initTest(true);
        $product = AnyBuilder::createForClass($this, Product::class, [])->build();
        $this->productSellerName = 'Cdiscount';

        $item = AnyBuilder::createForClass($this, Item::class, [
            'getProduct' => [$this->once(), $product],
            'getSellerId' => [$this->once(), 10]
        ])->build();
        $sellerName = $this->stub->displaySellerNameMultishipping($item);
        $this->assertEquals("<div class='content'>Sold by Cdiscount</div>", $sellerName,
            'should return a div with seller Name');
    }
}
