<?php

namespace Maas\Checkout\Test\Unit\Block\Checkout\Cart\Item;

use Maas\Checkout\Block\Checkout\Cart\Item\RendererDeliveryInfo;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\Element\Template\Context;
use Maas\Core\Model\Config;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Catalog\Model\Service\ProductDelivery;
use Magento\Framework\View\LayoutInterface;
use Magento\Checkout\Block\Cart\Additional\Info;
use Magento\Quote\Model\Quote\Item\AbstractItem;


/**
 * Class DisplaySellerTest
 *
 * @package Maas\Catalog\Test\Unit\Block
 */
class RendererDeliveryInfoTest extends TestCase
{
    /**
     * @var MockObject
     */
    private $context;
    /**
     * @var MockObject
     */
    private $productRepositoryInterface;
    /**
     * @var MockObject
     */
    private $config;

    /** @var RendererDeliveryInfo */
    private $instance;
    /** @var ObjectManager  */
    private $objectManager;
    /**
     * @var MockObject
     */
    private $request;

    private $productDeliveryService;

    private $product;
    private $item;
    private $block;
    private $layout;

    private $configIsModuleEnabled = true;
    private $productDeliveryEstimatedDates;

    const DUMMYDATESSTRING = 'dummyDatesString';

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->context = AnyBuilder::createForClass(
            $this,
            Context::class,
            [
                'getRequest' => [
                    $this->any(),
                    $this->request
                ],
                'getLocaleDate' => [
                    $this->any(),
                    AnyBuilder::createForClass(
                        $this,
                        TimezoneInterface::class
                    )->build()
                ]
            ]
        )->build();
        $this->product = AnyBuilder::createForClass(
            $this,
            ProductInterface::class,
            [
                'getMaasDeliveryExpressMin' => [
                    $this->any(),
                    function(){
                        return $this->productGetMaasDeliveryExpressMin;
                    },
                    AnyBuilder::RETURN_CALLBACK

                ],
                'getMaasDeliveryExpressMax' => [$this->any(), 5],
                'getMaasIsMaasProduct' => [
                    $this->any(),
                    function(){
                        return $this->productMaasIsMaasProduct;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->productRepositoryInterface = AnyBuilder::createForClass(
            $this,
            ProductRepository::class,
            [
                'getById' => [
                    $this->any(),
                    function () {
                        return $this->product;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->productDeliveryService = AnyBuilder::createForClass(
            $this,
            ProductDelivery::class,
            [
                'getDeliveryEstimatedDates' => [
                    $this->any(),
                    function(){
                        return $this->productDeliveryEstimatedDates;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->config = AnyBuilder::createForClass(
            $this,
            Config::class,
            [
                'isModuleEnabled' => [
                    $this->any(),
                    function(){
                        return $this->configIsModuleEnabled;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->item = AnyBuilder::createForClass(
            $this,
            AbstractItem::class,
            [
                'getProduct' => [
                    $this->any(),
                    $this->product
                ]
            ]
        )->build();
        $this->block = AnyBuilder::createForClass(
            $this,
            Info::class,
            [
                'getItem' => [
                    $this->any(),
                    $this->item
                ]
            ]
        )->build();
        $this->layout = AnyBuilder::createForClass(
            $this,
            LayoutInterface::class,
            [
                'getBlock' => [
                    $this->any(),
                    $this->block
                ]
            ]
        )->build();
    }


    public function testGetDeliveryInfo()
    {
        $this->productDeliveryEstimatedDates = self::DUMMYDATESSTRING;
        $this->getInstance();

        $this->instance->getDeliveryInfo();
    }

    private function getInstance()
    {
        $this->instance = $this->getMockBuilder(RendererDeliveryInfo::class)
            ->setConstructorArgs(
                [
                    'config' => $this->config,
                    'context' => $this->context,
                    'productRepository' => $this->productRepositoryInterface,
                    'productDeliveryService' => $this->productDeliveryService,
                    'data' => []
                ]
            )
            ->setMethods(['getLayout'])
            ->getMock();

        $this->instance->expects($this->any())
            ->method('getLayout')
            ->willReturn($this->layout);
    }
}
