<?php

namespace Maas\Checkout\Test\Unit\Block\Checkout\Cart\Item;

use Maas\Checkout\Block\Checkout\Cart\Item\RendererSellerInfo;
use Maas\Core\Model\Config;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Phrase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\Element\Template\Context;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Psr\Log\LoggerInterface;
use Magento\Framework\View\LayoutInterface;
use Magento\Checkout\Block\Cart\Additional\Info;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Quote\Api\Data\CartItemExtensionInterface;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;

/**
 * Class RendererSellerInfoTest
 *
 * @package Maas\Checkout\Test\Unit\Block\Checkout\Cart\Item
 */
class RendererSellerInfoTest extends TestCase
{
    /**
     * @var MockObject
     */
    private $context;
    /**
     * @var RendererSellerInfo
     */
    private $sut;
    /**
     * @var MockObject
     */
    private $_logger;
    /**
     * @var MockObject
     */
    private $_layout;
    /**
     * @var MockObject
     */
    private $configModel;
    /**
     * @var MockObject
     */
    private $productRepository;

    /** @var MockObject */
    private $productInterface;


    public function setUp()
    {
        $objectManager = new ObjectManager($this);
        $this->productRepository = $this->createMock(ProductRepository::class);
        $this->configModel = $this->createMock(Config::class);
        $this->context = $this->createMock(Context::class);
        $this->_logger = $this->createMockLogger();
        $this->_layout = $this->createMock(LayoutInterface::class);
        $data = [];
        $this->sut = $objectManager->getObject(
            RendererSellerInfo::class,
            [
                'productRepository' => $this->productRepository,
                'configModel' => $this->configModel,
                'context' => $this->context,
                'data' => $data,
                '_logger' => $this->_logger,
            ]
        );
    }

    /**
     * @param $offerId
     *
     * @return MockObject
     */
    private function initTest($offerId)
    {
        $this->productInterface = $this->createProductInterface();
        $this->productInterface->expects($this->any())->method('getTypeId')->willReturn('simple');
        $this->productInterface->expects($this->any())->method('getMaasOfferSellerName')->willReturn('Cdiscount');
        $this->productRepository->expects($this->any())->method('getById')->willReturn($this->productInterface);

        $blockInfo = $this->createMockBlockInfo();
        $abstractQuoteItem = $this->creatMockAbstractQuoteItem();
        $abstractQuoteItem->expects($this->any())->method('getProduct')->willReturn($this->productInterface);
        $cartItemExtensionInterface = $this->createMockCartItemExtensionInterface();
        $salesQuoteItemInfoInterface = $this->createSalesQuoteItemInfoInterface();
        $blockInfo->expects($this->any())->method('getItem')->willReturn($abstractQuoteItem);
        $abstractQuoteItem
            ->expects($this->any())
            ->method('getExtensionAttributes')
            ->willReturn($cartItemExtensionInterface);
        $this->_layout->expects($this->any())->method('getBlock')->willReturn($blockInfo);
        $cartItemExtensionInterface
            ->expects($this->any())
            ->method('getExtraInfo')
            ->willReturn($salesQuoteItemInfoInterface);
        $salesQuoteItemInfoInterface->expects($this->any())->method('getOfferId')->willReturn($offerId);
        $this->sut->setLayout($this->_layout);
        return $abstractQuoteItem;
    }

    /**
     * @return MockObject
     */
    private function createMockLogger()
    {
        return $this->getMockBuilder(LoggerInterface::class)
            ->setMethods(['critical'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    public function testLayoutNotInitialized()
    {
        $noLayout = $this->sut->getSellerName();
        $this->assertEquals('' , $noLayout, 'the should not be present');
    }

    public function testNoBlockExist()
    {
        $this->sut->setLayout($this->_layout);
        $noBlock = $this->sut->getSellerName();
        $this->assertEquals('', $noBlock, 'The block additional data should not exist');
    }

    public function testNoOfferIdWithNoChildrenItem()
    {
        $this->initTest(0);
        $sellerName = $this->sut->getSellerName();
        $this->assertEquals('', $sellerName, 'OfferId should not exist');
    }

    public function testNoOfferIdWithChildrenItemShouldReturnOneSeller()
    {
        $this->productInterface = $this->createProductInterface();
        $this->productInterface->expects($this->any())->method('getTypeId')->willReturn('configurable');
        $this->productInterface->expects($this->any())->method('getMaasOfferSellerName')->willReturn(null);

        $childProduct = $this->createProductInterface();
        $childProduct->expects($this->any())->method('getTypeId')->willReturn('simple');
        $childProduct->expects($this->any())->method('getMaasOfferSellerName')->willReturn('1001 Pneus');

        $this->productRepository->expects($this->any())->method('getById')->willReturnOnConsecutiveCalls($this->productInterface,
            $childProduct);

        $blockInfo = $this->createMockBlockInfo();
        $abstractItemWithChildren = $this->creatMockAbstractQuoteItem();
        $abstractItemWithChildren->expects($this->any())->method('getProduct')->willReturn($this->productInterface);
        $cartItemExtensionInterface = $this->createMockCartItemExtensionInterface();
        $salesQuoteItemInfoInterface = $this->createSalesQuoteItemInfoInterface();
        $blockInfo->expects($this->any())->method('getItem')->willReturn($abstractItemWithChildren);
        $abstractItemWithChildren
            ->expects($this->any())
            ->method('getExtensionAttributes')
            ->willReturn($cartItemExtensionInterface);
        $this->_layout->expects($this->any())->method('getBlock')->willReturn($blockInfo);
        $cartItemExtensionInterface
            ->expects($this->any())
            ->method('getExtraInfo')
            ->willReturn($salesQuoteItemInfoInterface);
        $salesQuoteItemInfoInterface->expects($this->any())->method('getOfferId')->willReturn(0);
        $this->sut->setLayout($this->_layout);

        $childrenItem = $this->creatMockAbstractQuoteItem();
        $cartItemExtensionInterface = $this->createMockCartItemExtensionInterface();
        $salesQuoteItemInfoInterface = $this->createSalesQuoteItemInfoInterface();
        $childrenItem
            ->expects($this->any())
            ->method('getExtensionAttributes')
            ->willReturn($cartItemExtensionInterface);
        $cartItemExtensionInterface
            ->expects($this->any())
            ->method('getExtraInfo')
            ->willReturn($salesQuoteItemInfoInterface);
        $childrenItem->expects($this->any())->method('getProduct')->willReturn($childProduct);
        $salesQuoteItemInfoInterface->expects($this->any())->method('getOfferId')->willReturn(15);

        $abstractItemWithChildren->expects($this->any())->method('getChildren')->willReturn([$childrenItem]);
        $this->configModel->method('isModuleEnabled')
            ->will($this->returnValue(true));

        $sellerExpected = $this->sut->getSellerName();

        $this->assertEquals($sellerExpected, '1001 Pneus');
    }


    public function testWithOfferId()
    {
        $this->initTest(10);
        $this->configModel->method('isModuleEnabled')
            ->will($this->returnValue(true));
        $sellerExpected = $this->sut->getSellerName() ;
        $this->assertEquals($sellerExpected, 'Cdiscount');
    }

    private function createMockBlockInfo()
    {
        return $this->getMockBuilder(Info::class)
            ->setMethods(['getItem'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    private function creatMockAbstractQuoteItem()
    {
        return $this->getMockBuilder(AbstractItem::class)
            ->setMethods(['getExtensionAttributes', 'getChildren', 'getProduct'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    private function createMockCartItemExtensionInterface()
    {
        return $this->getMockBuilder(CartItemExtensionInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    private function createSalesQuoteItemInfoInterface()
    {
        return $this->getMockBuilder(SalesQuoteItemInfoInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function createProductInterface()
    {
        $productInterface = $this->getMockBuilder(ProductInterface::class)
            ->setMethods([
                'getMaasOfferId',
                'getTypeInstance',
                'getMaasIsMaasProduct',
                'getMaasOfferSellerName',
                'getId'
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
        $productInterface->expects($this->any())->method('getMaasOfferId')->willReturn(5);
        $productInterface->expects($this->any())->method('getId')->willReturn(5);
        return $productInterface;
    }

}
