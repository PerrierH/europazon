<?php

namespace Maas\Checkout\ViewModel;

use Maas\Core\Model\Config;
use Magento\Framework\View\Element\Block\ArgumentInterface;
use Magento\Quote\Model\Quote\Item\AbstractItem;

class Seller implements ArgumentInterface
{
    protected Config $configModel;
    protected AbstractItem $item;

    public function __construct(Config $configModel)
    {
        $this->configModel = $configModel;
    }

    /**
     * Check if I should display seller
     *
     * @return bool
     */
    public function shouldDisplaySeller(): bool
    {
        return $this->configModel->isModuleEnabled() && $this->displaySellerName();
    }

    /**
     *  Display seller name overview
     *
     * @return false|string
     */
    public function displaySellerName()
    {
        $product = $this->item->getProduct();
        if ($product) {
            return $product->getMaasOfferSellerFrontName();
        }
        return false;
    }

    /**
     * Set quote item
     *
     * @param AbstractItem $item
     * @return void
     */
    public function setItem(AbstractItem $item)
    {
        $this->item = $item;
    }
}
