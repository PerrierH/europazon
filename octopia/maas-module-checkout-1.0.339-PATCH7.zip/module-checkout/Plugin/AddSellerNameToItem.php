<?php

namespace Maas\Checkout\Plugin;

use Maas\Core\Model\Config;
use Magento\Checkout\CustomerData\DefaultItem;
use Magento\Quote\Model\Quote\Item;

/**
 * Class AddSellerNameToItem
 *
 * @package Maas\Checkout\Plugin
 * @codeCoverageIgnore
 */
class AddSellerNameToItem
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * AddSellerNameToItem constructor.
     *
     * @param Config $configModel
     */
    public function __construct(
        Config $configModel
    )
    {
        $this->configModel = $configModel;
    }

    /**
     * @param DefaultItem $subject
     * @param $result
     * @param $item
     * @return array
     */
    public function afterGetItemData(DefaultItem $subject, $result, $item)
    {
        if (!$this->configModel->isModuleEnabled()) {
            return $result;
        }
        /** @var Item $item */
        $sellerName = $this->getSellerName($item);
        if ($sellerName !== null) {
            $atts = [
                "maas_item_seller_name" => $sellerName,
                "display_seller_name" => true,
            ];
        } else {
            $atts = [
                "display_seller_name" => false,
            ];
            if ($item->getChildren()) {
                foreach($item->getChildren() as $childItem)
                {
                    if ($this->getSellerName($childItem) !== null) {
                        $atts = [
                            "maas_item_seller_name" => $this->getSellerName($childItem),
                            "display_seller_name" => true,
                        ];
                        break;
                    }
                }
            }
        }
        return array_merge($result, $atts);
    }

    /**
     * @param Item $item
     *
     * @return mixed|null
     */
    public function getSellerName(Item $item)
    {
        return $item->getProduct()->getMaasOfferSellerFrontName();
    }
}
