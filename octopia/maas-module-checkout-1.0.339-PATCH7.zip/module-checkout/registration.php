<?php

use Magento\Framework\Component\ComponentRegistrar;

/**
 * @codeCoverageIgnore
 */
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Maas_Checkout', __DIR__);
