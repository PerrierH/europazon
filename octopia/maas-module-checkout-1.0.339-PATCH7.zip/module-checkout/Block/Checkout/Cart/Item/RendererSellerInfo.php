<?php

namespace Maas\Checkout\Block\Checkout\Cart\Item;

use Maas\Core\Model\Config;
use Magento\Checkout\Block\Cart\Additional\Info;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Quote\Model\Quote\Item;

/**
 * Class RendererSellerInfo
 *
 * @package Block\Checkout\Cart\Item
 */
class RendererSellerInfo extends Template
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * RendererSellerInfo constructor.
     *
     * @param Config $configModel
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Config $configModel,
        Context $context,
        array $data = []
    ) {
        $this->configModel = $configModel;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getSellerName()
    {
        $sellerName = '';
        if ($this->configModel->isModuleEnabled()) {
            $item = $this->getItem();
            $sellerName = $item->getProduct()->getMaasOfferSellerFrontName();
            if ($sellerName === null) {
                $children = $item->getChildren();
                if ($children) {
                    foreach ($children as $child) {
                        $sellerName = $child->getProduct()->getMaasOfferSellerFrontName();
                        if ($sellerName !== null) {
                            return $sellerName;
                        }
                    }
                }
            }
        }

        return $sellerName;
    }

    /**
     * @return bool|AbstractItem
     *
     * @codeCoverageIgnore
     */
    private function getItem()
    {
        try {
            $layout = $this->getLayout();
        } catch (LocalizedException $e) {
            $this->_logger->critical($e->getMessage());
            return false;
        }
        $block = $layout->getBlock('additional.product.info');
        if ($block instanceof Info) {
            return $block->getItem();
        }
        return false;
    }
}
