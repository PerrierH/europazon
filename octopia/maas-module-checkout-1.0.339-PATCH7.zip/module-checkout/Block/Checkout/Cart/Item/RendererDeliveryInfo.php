<?php

namespace Maas\Checkout\Block\Checkout\Cart\Item;

use Maas\Core\Model\Config;
use Magento\Checkout\Block\Cart\Additional\Info;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Quote\Model\Quote\Item;
use Maas\Catalog\Model\Service\ProductDelivery;

/**
 * Class RendererDeliveryInfo
 *
 * @package Maas\Checkout\Block\Checkout\Cart\Item
 */
class RendererDeliveryInfo extends Template
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /** @var ProductDelivery */
    private $productDeliveryService;

    /**
     * RendererSellerInfo constructor.
     *
     * @param Config $configModel
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param array $data
     */
    public function __construct(
        Config $configModel,
        Context $context,
        ProductRepositoryInterface $productRepository,
        ProductDelivery $productDeliveryService,
        array $data = []
    ) {
        $this->configModel = $configModel;
        $this->productRepository = $productRepository;
        $this->productDeliveryService = $productDeliveryService;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getDeliveryInfo()
    {
        $delivery = '';
        if ($this->configModel->isModuleEnabled()) {
            $product = $this->getProductFromItem($this->getItem());
            $delivery = $this->productDeliveryService->getDeliveryEstimatedDates($product, $this->_localeDate);
        }

        return $delivery;
    }

    /**
     * @param AbstractItem $item
     *
     * @return mixed
     * @throws NoSuchEntityException
     * @codeCoverageIgnore
     */
    private function getProductFromItem(AbstractItem $item)
    {
        return $this->productRepository->getById($item->getProduct()->getId());
    }

    /**
     * @return bool|AbstractItem
     *
     * @codeCoverageIgnore
     */
    private function getItem()
    {
        try {
            $layout = $this->getLayout();
        } catch (LocalizedException $e) {
            $this->_logger->critical($e->getMessage());
            return false;
        }
        $block = $layout->getBlock('additional.product.info');
        if ($block instanceof Info) {
            return $block->getItem();
        }
        return false;
    }
}
