<?php


namespace Maas\Checkout\Block\Checkout;

use Maas\Core\Model\Config;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Multishipping\Block\Checkout\Overview as MagentoOverView;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Quote\Model\Quote\TotalsCollector;
use Magento\Quote\Model\Quote\TotalsReader;
use Magento\Tax\Helper\Data;

/**
 * Class Overview
 *
 * @package Maas\Checkout\Block\Checkout
 */
class Overview extends MagentoOverView
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * Overview constructor.
     *
     * @param Context $context
     * @param Multishipping $multishipping
     * @param Data $taxHelper
     * @param PriceCurrencyInterface $priceCurrency
     * @param TotalsCollector $totalsCollector
     * @param TotalsReader $totalsReader
     * @param Config $configModel
     * @param array $data
     */
    public function __construct(
        Context $context,
        Multishipping $multishipping,
        Data $taxHelper,
        PriceCurrencyInterface $priceCurrency,
        TotalsCollector $totalsCollector,
        TotalsReader $totalsReader,
        Config $configModel,
        array $data = []
    ) {
        $this->configModel = $configModel;
        parent::__construct(
            $context,
            $multishipping,
            $taxHelper,
            $priceCurrency,
            $totalsCollector,
            $totalsReader,
            $data
        );
    }

    /**
     * @param $address
     *
     * @return bool
     */
    public function shouldDisplaySellerName($address)
    {
        if ($this->configModel->isModuleEnabled()) {
            foreach ($this->getShippingAddressItems($address) as $item) {
                if ($this->getSellerNameFromItem($item)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param AbstractItem $item
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    private function getSellerNameFromItem(AbstractItem $item)
    {
        return $item->getProduct()->getMaasOfferSellerFrontName();
    }

    /**
     * @param Address $address
     *
     * @return string
     * @codeCoverageIgnore Logic contained in applied plugin
     */
    public function renderAddressAdditionalInfo(Address $address)
    {
        return '';
    }

    /**
     * @param array $totals
     * @param int|null $colspan
     *
     * @return string
     * @codeCoverageIgnore Logic delegated to parent
     */
    public function renderTotals($totals, $colspan = null)
    {
        if(is_null($colspan))
        {
            $colspan = 4;
        }
        return parent::renderTotals($totals, $colspan);
    }
}
