<?php

namespace Maas\Checkout\Block\Checkout;

use Maas\Core\Model\Config;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filter\DataObject\GridFactory;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Multishipping\Block\Checkout\Shipping as MagentoMultishippingCheckout;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Tax\Helper\Data;

/**
 * Class Shipping
 *
 * @package Maas\Checkout\Block\Checkout
 */
class Shipping extends MagentoMultishippingCheckout
{
    /**
     * @var Config
     */
    private $configModel;

    /**
     * Shipping constructor.
     *
     * @param Context $context
     * @param GridFactory $filterGridFactory
     * @param Multishipping $multishipping
     * @param Data $taxHelper
     * @param PriceCurrencyInterface $priceCurrency
     * @param Config $configModel
     * @param array $data
     */
    public function __construct(
        Context $context,
        GridFactory $filterGridFactory,
        Multishipping $multishipping,
        Data $taxHelper,
        PriceCurrencyInterface $priceCurrency,
        Config $configModel,
        array $data = []
    ) {
        $this->configModel = $configModel;
        parent::__construct($context, $filterGridFactory, $multishipping, $taxHelper, $priceCurrency, $data);
    }

    /**
     * @param $item
     *
     * @return string
     */
    public function displaySellerNameMultishipping($item)
    {
        if ($this->configModel->isModuleEnabled() && $item->getSellerId()) {
            return "<div class='content'>" . __('Sold by %1', $this->getSellerNameFromItem($item)) . "</div>";
        }
        return '';
    }

    /**
     * @param AbstractItem $item
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    private function getSellerNameFromItem(AbstractItem $item)
    {
        return $item->getProduct()->getMaasOfferSellerFrontName();
    }

    /**
     * @param Address $address
     *
     * @return bool
     */
    public function getDisplayNoMethodsMessage(Address $address)
    {
        return true;
    }
}
