<?php

namespace Maas\CatalogRule\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Zend_Db_Exception;

/**
 * Class InstallSchema
 *
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    const CATALOG_RULE_ENGINE_TABLE_NAME = 'maas_catalog_rule_engine';

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        $this->createCatalogRuleEngineTable($setup, $connection);
        $this->createCatalogRuleEngineWebsiteTable($setup, $connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     *
     * @throws Zend_Db_Exception
     */
    private function createCatalogRuleEngineTable(
        SchemaSetupInterface $setup,
        AdapterInterface $connection
    )
    {

        if (!$setup->tableExists(self::CATALOG_RULE_ENGINE_TABLE_NAME)) {
            $catalogRuleEngineTable = $connection->newTable(
                $setup->getTable(self::CATALOG_RULE_ENGINE_TABLE_NAME)
            )
                ->addColumn(
                    'rule_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Technical ID for the rule'
                )
                ->addColumn(
                    'name',
                    Table::TYPE_TEXT,
                    100,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Name defined by administrator'
                )->addColumn(
                    'description',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Name defined by administrator'
                )->addColumn(
                    'status',
                    Table::TYPE_BOOLEAN,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Rule status'
                )->addColumn(
                    'priority',
                    Table::TYPE_TEXT,
                    10,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Priority defined by administrator for the execution rule'
                )->addColumn(
                    'last_execution_date',
                    Table::TYPE_DATETIME,
                    255,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Date of the last execution of the rule'
                )->addColumn(
                    'conditions_serialized',
                    Table::TYPE_TEXT,
                    '2M',
                    [],
                    'Conditions Serialized'
                )
                ->addColumn(
                    'category_ids',
                    Table::TYPE_TEXT,
                    '255',
                    [],
                    'Category Action'
                )->addColumn(
                    'product_status',
                    Table::TYPE_BOOLEAN,
                    null,
                    [
                        'nullable' => true,
                        'unsigned' => true
                    ],
                    'Product status action'
                );
            $connection->createTable($catalogRuleEngineTable);
        }
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     *
     * @throws Zend_Db_Exception
     */
    private function createCatalogRuleEngineWebsiteTable(SchemaSetupInterface $setup, AdapterInterface $connection)
    {
        /**
         * Create table 'maas_catalog_rule_engine_website'
         */
        $catalogRuleEngineWebsiteTableName = 'maas_catalog_rule_engine_website';
        if (!$setup->tableExists($catalogRuleEngineWebsiteTableName)) {
            $catalogRuleEngineTable = $connection->newTable(
                $setup->getTable($catalogRuleEngineWebsiteTableName)
            )
                ->addColumn(
                    'rule_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Rule Id'
                )
                ->addColumn(
                    'website_id',
                    Table::TYPE_SMALLINT,
                    null,
                    ['unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Website Id'
                )
                ->addIndex(
                    $setup->getIdxName($catalogRuleEngineWebsiteTableName, ['website_id']),
                    ['website_id']
                )
                ->addForeignKey(
                    $setup
                        ->getFkName(
                            $catalogRuleEngineWebsiteTableName,
                            'rule_id',
                            self::CATALOG_RULE_ENGINE_TABLE_NAME, 'rule_id'
                        ),
                    'rule_id',
                    $setup->getTable(self::CATALOG_RULE_ENGINE_TABLE_NAME),
                    'rule_id',
                    Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $setup->getFkName($catalogRuleEngineWebsiteTableName, 'website_id', 'store_website', 'website_id'),
                    'website_id',
                    $setup->getTable('store_website'),
                    'website_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Maas Commercial categorization To Websites Relations');

            $connection->createTable($catalogRuleEngineTable);
        }
    }
}
