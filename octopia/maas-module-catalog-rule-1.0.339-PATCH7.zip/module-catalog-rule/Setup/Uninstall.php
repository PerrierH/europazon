<?php

namespace Maas\CatalogRule\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Setup
 */
class Uninstall implements UninstallInterface
{
    const TABLE_MAAS_CATALOG_RULE_ENGINE = 'maas_catalog_rule_engine';
    const TABLE_MAAS_CATALOG_RULE_ENGINE_WEBSITE = 'maas_catalog_rule_engine_website';

    /**
     * @inheritdoc
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $setup->getConnection()->dropTable(self::TABLE_MAAS_CATALOG_RULE_ENGINE);
        $setup->getConnection()->dropTable(self::TABLE_MAAS_CATALOG_RULE_ENGINE_WEBSITE);
        $setup->endSetup();
    }
}
