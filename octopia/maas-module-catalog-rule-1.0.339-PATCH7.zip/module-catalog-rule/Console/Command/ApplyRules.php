<?php

namespace Maas\CatalogRule\Console\Command;

use Exception;
use Maas\CatalogRule\Model\ApplyRules as ApplyRulesProxy;
use Maas\Core\Console\Command\AbstractParallelEntityProcess;
use Maas\Core\Model\Parallelization\Parallelization;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Logger\Logger;
use Maas\Log\Model\Report;
use Magento\Framework\App\Area;
use Magento\Framework\App\State;
use Magento\Store\Model\App\Emulation;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Maas\ImportExport\Model\Config\Proxy as ConfigModel;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime as DateTime;

/**
 * Class ApplyRules
 *
 * @package Maas\CatalogRule\Console\Command
 * @codeCoverageIgnore
 */
class ApplyRules extends AbstractParallelEntityProcess
{
    use Parallelization;

    const SEGMENT_SIZE = 1;
    const BATCH_SIZE = 1;
    protected $commandName = 'maas:apply:rules';
    protected $commandDescription = 'Apply catalog rules.';

    /**
     * @var ApplyRulesProxy
     */
    protected $applyRules;

    /**
     * @var Emulation
     */
    private $emulation;

    /** @var State * */
    private $state;

    private array $rules = [];
    private ErrorLogger $errorLogger;

    /**
     * ApplyRules constructor.
     *
     * @param ApplyRulesProxy $applyRules
     * @param Emulation $emulation
     * @param State $state
     * @param ErrorLogger $errorLogger
     * @param SerializerInterface $serializer
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param DateTime $dateTime
     * @param CacheInterface $cache
     * @param ConfigModel $configModel
     */
    public function __construct(
        ApplyRulesProxy $applyRules,
        Emulation $emulation,
        State $state,
        ErrorLogger $errorLogger,
        SerializerInterface $serializer,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        DateTime $dateTime,
        CacheInterface $cache,
        ConfigModel $configModel
    )
    {
        $this->emulation = $emulation;
        $this->state = $state;
        $this->applyRules = $applyRules;
        $this->errorLogger = $errorLogger;
        parent::__construct($serializer, $reportRepository, $reportManagement, $dateTime, $cache, $configModel);
    }

    /**
     * We don't need to test for this function
     * @codeCoverageIgnore
     * @return bool
     */
    protected function isModuleEnabled()
    {
        return $this->configModel->isModuleEnabled();
    }

    /**
     * @param null $scheduleId
     *
     * @return Report
     * @throws Exception
     */
    protected function startReport(?int $scheduleId = null) : ReportInterface
    {
        return $this->applyRules->startProcess($this->getArgsScheduleId($scheduleId));
    }

    /**
     * @param $item
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function runSingleCommand($item, InputInterface $input, OutputInterface $output): void
    {
        $report = $this->getReport();
        $counter = count($item);
        try {
            if ($counter) {
                $this->applyRules->apply($report, $item);
            } else {
                $this->stopReport($report);
            }
        } catch (Exception $e) {
            $errorMessage = __("Error occurred detail: %1. See logs file for more details.", $e->getMessage());
            $errorLogMessage = __('Trace: %1', $e->getTraceAsString());
            if ($report->getId()) {
                $report->log(__('%1 products not assigned', $counter),false, Logger::ERROR);
                $report->log($errorMessage, false, Logger::ERROR);
                $report->setMessage($errorMessage);
                $report->setDeltaErrorItemsCount($counter);
                $this->stopReport($report);
            }
            $this->errorLogger->error($errorMessage);
            $this->errorLogger->error($errorLogMessage);
            $output->writeln('<error>' . $errorMessage->__toString() . '</error>');
        }
        if ($report->getId()) {
            $this->reportRepository->save($report);
        }
    }

    /**
     * Executes the parallelized command.
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $report = $this->initReport($input);
            $this->rules = $this->applyRules->getRules($this->getMax());
            $count = count($this->rules);
            $process = $this->beforeNextProcess($report, '%1 Rules to execute', $input, $count);
            if ($process) {
                $this->state->setAreaCode(Area::AREA_ADMINHTML);
                $storeId = 0;
                $this->emulation->startEnvironmentEmulation($storeId, Area::AREA_ADMINHTML);
                $execute = parent::execute($input, $output);
                $this->emulation->stopEnvironmentEmulation();
                $this->afterNextProcess('%1 Rules are executed successfully', '%1 Rules not executed error');
                return $execute;
            }
        } catch (\Magento\Framework\Exception\AlreadyExistsException $e) {
            //Nothing to do
            $output->writeln('<error>' . $e->getMessage() .'</error>');
        } catch (\Exception $e) {
            //IF there is an error
            $errorMessage = __("Error occurred detail: %1. See logs file for more details.", $e->getMessage());
            $errorLogMessage = __('Trace: %1', $e->getTraceAsString());
            $report = $this->getReport();
            if ($report->getId()) {
                $report->log("Error occurred.", false, Logger::ERROR);
                $report->log($errorMessage, false, Logger::ERROR);
                $report->setMessage($errorMessage, false, Logger::ERROR);
                $report->setErrorItemsCount($report->getItemsCount() - ($report->getSuccessItemsCount() + $report->getWarningItemsCount()));
            }
            $this->errorLogger->error($errorMessage);
            $this->errorLogger->error($errorLogMessage);
            $output->writeln('<error>' . $errorMessage->__toString() . '</error>');
        }
        return 0;
    }

    protected function fetchItems(InputInterface $input, OutputInterface $output): array
    {
        if ($this->getLimit() == 0) {
            return [$this->rules];
        }
        return array_chunk($this->rules, $this->getLimit());
    }

    /**
     * @return int
     */
    protected function getLimit() : int
    {
        return 0;
    }

    /**
     * @inheirtDoc
     */
    protected function getMax() : int
    {
        return 0;
    }

    /**
     * @return int
     */
    protected function getProcessesNumber() : int
    {
        return 1;
    }

    protected function getReportIdKey() : string
    {
        return ApplyRulesProxy::CACHE_KEY_MAAS_REPORT_ID;
    }

    protected function getStartedImportReportObject() : ?ReportInterface
    {
        return $this->applyRules->getStartedImportReportObject();
    }
}
