<?php


namespace Maas\CatalogRule\Plugin;

use Magento\Rule\Model\Condition\Combine;

/**
 * Class LoadAggregatorOptionTranslator
 * No need to be tested. setAggregatorOption is a magic method
 * and no logic
 *
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Plugin
 */
class LoadAggregatorOptionTranslator
{
    /**
     * @param Combine $subject
     * @param $result
     *
     * @return Combine
     */
    public function afterLoadAggregatorOptions(Combine $subject, $result)
    {
        $subject->setAggregatorOption(['all' => __('MAAS_ALL'), 'any' => __('MAAS_ANY')]);
        return $subject;
    }
}
