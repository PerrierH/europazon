<?php


namespace Maas\CatalogRule\Test\Unit\Block\Adminhtml\Edit;

use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Block\Adminhtml\Edit\DeleteButton;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use PHPUnit\Framework\TestCase;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Exception\NoSuchEntityException;

class DeleteButtonTest extends TestCase
{
    /**
     * @var DeleteButton
     */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $catalogRepository;

    public function setUp()
    {
        $this->catalogRepository = $this->createMock(CatalogRuleRepositoryInterface::class);
        $this->context = $this->createMock(Context::class);
        $this->stub = new DeleteButton(
            $this->context,
            $this->catalogRepository
        );
    }

    public function testReturnDeletButtonArray()
    {
        $expectedButtonValue = [
            'label' => __('Delete'),
            'class' => 'delete',
            'on_click' => 'deleteConfirm(\'' . __(
                'Are you sure you want to delete this rule? Please note, this action is irreversible.'
            ) . '\', \'http://magento.local:8221/delete\', {data: {}})',
            'sort_order' => 20,
        ];
        $requestInterface = $this->getMockRequestInterface();
        $catalogRuleInterface = $this->getMockCatalogRuleInterface();
        $urlInterface = $this->getMockUrlInterface();
        $urlInterface->expects($this->once())->method('getUrl')->willReturn('http://magento.local:8221/delete');
        $this->context->expects($this->once())->method('getUrlBuilder')->willReturn($urlInterface);
        $catalogRuleInterface->expects($this->atMost(2))->method('getRuleId')->willReturn(4);
        $this->catalogRepository->expects($this->atMost(2))->method('getById')->willReturn($catalogRuleInterface);
        $requestInterface->expects($this->atMost(2))->method('getParam')->willReturn(2);
        $this->context->expects($this->atMost(2))->method('getRequest')->willReturn($requestInterface);
        $button = $this->stub->getButtonData();
        $this->assertEquals($expectedButtonValue, $button, 'Should return array with all property need for the button');
    }

    public function testRuleIdDoesNotExistShouldReturAnEmptyArray()
    {
        $requestInterface = $this->getMockRequestInterface();
        $this->catalogRepository
            ->method('getById')
            ->willThrowException(
                new NoSuchEntityException(__('CatalogRule with id 2 does not exist.'))
            );

        $this->context->expects($this->once())->method('getRequest')->willReturn($requestInterface);
        $button = $this->stub->getButtonData();
        $this->assertEquals([], $button, 'When no rule is provided the button should not be display');
    }

    private function getMockCatalogRuleInterface()
    {
        return $this->createMock(CatalogRuleInterface::class);
    }

    private function getMockUrlInterface()
    {
        return $this->createMock(UrlInterface::class);
    }

    private function getMockRequestInterface()
    {
        return $this->createMock(RequestInterface::class);
    }
}
