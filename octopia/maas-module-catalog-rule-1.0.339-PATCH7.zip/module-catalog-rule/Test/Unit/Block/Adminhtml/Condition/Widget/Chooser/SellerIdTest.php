<?php


namespace Maas\CatalogRule\Test\Unit\Block\Adminhtml\Condition\Widget\Chooser;

use Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser\SellerId;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Backend\Block\Template\Context;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Maas\Seller\Api\SellerRepositoryInterface;
use Magento\Framework\Api\SearchCriteria;
use Maas\Seller\Api\Data\SellerSearchResultsInterface;
use Maas\Seller\Api\Data\SellerInterface;
use PHPUnit\Framework\TestCase;

class SellerIdTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $sellerRepository;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $searchCriteriaBuilder;
    /**
     * @var SellerId
     */
    private $stub;

    public function setUp()
    {
        $this->context = $this->createMock(Context::class);
        $this->attributeRepository = $this->createMock(AttributeRepositoryInterface::class);
        $this->sellerRepository = $this->createMock(SellerRepositoryInterface::class);
        $this->searchCriteriaBuilder = $this->createMock(SearchCriteriaBuilder::class);
        $this->stub = new SellerId(
            $this->context,
            $this->attributeRepository,
            $this->sellerRepository,
            $this->searchCriteriaBuilder,
            []
        );
    }

    private function initTest()
    {
        $searCriteria = $this->getMockSearchCriteria();
        $this->searchCriteriaBuilder
            ->expects($this->any())
            ->method('create')
            ->willReturn($searCriteria);
    }

    public function testNoSeller()
    {
        $expectedValue = ['attributeCode' => 'maas_offer_seller_id'];
        $this->initTest();
        $sellerValues = $this->stub->getAttributes();
        $this->assertEquals($expectedValue, $sellerValues, 'Should return only an array with attribute code maas_offer_seller_id');
    }

    public function testWithSeller()
    {
        $expectedValue = [
            [
                'value' => 1,
                'label' => 'Name1',
            ],
            [
                'value' => 2,
                'label' => 'Name2',
            ],
            'attributeCode' => 'maas_offer_seller_id'
        ];
        $this->initTest();
        $sellerSearchResultsInterface = $this->getMockSellerSearchResultsInterface();
        $sellers = [];

        $sellerInterface = $this->getMockSellerInterface();
        $sellerInterface->expects($this->any())->method('getData')->willReturnCallback(function($attribute){
            if($attribute == 'name'){
                return 'Name1';
            }else{
                return 1;
            }
        });
        $sellers[] = $sellerInterface;

        $sellerInterface = $this->getMockSellerInterface();
        $sellerInterface->expects($this->any())->method('getData')->willReturnCallback(function($attribute){
            if($attribute == 'name'){
                return 'Name2';
            }else{
                return 2;
            }
        });
        $sellers[] = $sellerInterface;

        $sellerSearchResultsInterface->expects($this->any())->method('getItems')->willReturn($sellers);
        $this->sellerRepository->expects($this->any())->method('getList')->willReturn($sellerSearchResultsInterface);
        $sellerValues = $this->stub->getAttributes();
        $this->assertEquals($expectedValue, $sellerValues, 'Should return seller with name attribute and id');
    }

    private function getMockSearchCriteria()
    {
        return $this->createMock(SearchCriteria::class);
    }

    private function getMockSellerSearchResultsInterface()
    {
        return $this->createMock(SellerSearchResultsInterface::class);
    }

    private function getMockSellerInterface()
    {
        return $this->getMockBuilder(SellerInterface::class)
            ->setMethods(['getId', 'getData'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }
}
