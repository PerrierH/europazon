<?php

namespace Maas\CatalogRule\Test\Unit\Block\Adminhtml\Condition\Widget\Chooser;

use Maas\CatalogRule\Model\BrandAttributeRepository;
use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser\Brand;
use PHPUnit\Framework\TestCase;

class BrandTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $brandNames;
    /**
     * @var Brand
     */
    private $stub;

    public function setUp()
    {
        $this->context = $this->createMock(Context::class);
        $this->attributeRepository = $this->createMock(AttributeRepositoryInterface::class);
        $this->brandNames = $this->createMock(BrandAttributeRepository::class);
        $this->stub = new Brand(
            $this->context,
            $this->attributeRepository,
            $this->brandNames,
            []
        );
    }

    public function testNoAttributesBrand()
    {
        $expectedValue = ['attributeCode' => 'maas_brand'];
        $attributeValues = $this->stub->getAttributes();
        $this->assertEquals($expectedValue, $attributeValues, 'Should return only an array with attribute code');
    }

    public function testWithAttributesBrand()
    {
        $products = [];
        for ($i = 1; $i<3; $i++) {
            $product = $this->getMockProduct();
            $product->expects($this->any())->method('getMaasBrand')->willReturn(1001+$i . ' Pneu');
            $products[] = $product;
        }
        $expectedValue = [
            [
                'value' => '1002 Pneu',
                'label' => '1002 Pneu',
            ],
            [
                'value' => '1003 Pneu',
                'label' => '1003 Pneu',
            ],
            'attributeCode' => 'maas_brand'
        ];
        $this->brandNames
            ->expects($this->any())
            ->method('getBrandNames')
            ->willReturn(
                $products
            );
        $attributeValues = $this->stub->getAttributes();
        $this->assertEquals(
            $expectedValue,
            $attributeValues,
            'Should return an array with attribute code and array with values and label'
        );
    }

    private function getMockProduct()
    {
        return $this->getMockBuilder(ProductInterface::class)
            ->setMethods(['getMaasBrand'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }
}
