<?php

namespace Maas\CatalogRule\Test\Unit\Block\Adminhtml\Condition\Widget\Chooser;

use Magento\Backend\Block\Template\Context;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser\Status;
use Magento\Eav\Api\Data\AttributeInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use PHPUnit\Framework\TestCase;

class StatusTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $context;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeRepository;
    /**
     * @var Brand
     */
    private $stub;

    public function setUp()
    {
        $this->context = $this->createMock(Context::class);
        $this->attributeRepository = $this->createMock(AttributeRepositoryInterface::class);
        $this->stub = new Status(
            $this->context,
            $this->attributeRepository,
            []
        );
    }

    public function testNoAttributesStatus()
    {
        $expectedValue = ['attributeCode' => 'status'];
        $attributeInterface = $this->getMockAttributeInterface();
        $this->attributeRepository->expects($this->any())->method('get')->willReturn($attributeInterface);
        $attributeValues = $this->stub->getAttributes();
        $this->assertEquals($expectedValue, $attributeValues, 'Should return only an array with attribute code status');
    }

    public function testWithAttributesStatus()
    {
        $expectedValue = [
            [
                'value' => 2,
                'label' => 'OptionLabel2',
            ],
            [
                'value' => 3,
                'label' => 'OptionLabel3',
            ],
            'attributeCode' => 'status'
        ];
        $attributeInterface = $this->getMockAttributeInterface();
        $attributeOtpions =[];
        for ($i = 1; $i<3; $i++) {
            $attributeOtpionInterface = $this->getMockAttributeOptionInterface();
            $attributeOtpionInterface->expects($this->any())->method('getValue')->willReturn($i+1);
            $attributeOtpionInterface->expects($this->any())->method('getLabel')->willReturn('OptionLabel'.($i+1));
            $attributeOtpions [] = $attributeOtpionInterface;
        }
        $attributeInterface->expects($this->any())->method('getOptions')->willReturn($attributeOtpions);
        $this->attributeRepository->expects($this->any())->method('get')->willReturn($attributeInterface);
        $attributeValues = $this->stub->getAttributes();
        $this->assertEquals($expectedValue, $attributeValues, 'Should return only an array with attribute code status');
    }

    private function getMockAttributeInterface()
    {
        return $this->createMock(AttributeInterface::class);
    }

    private function getMockAttributeOptionInterface()
    {
        return $this->createMock(AttributeOptionInterface::class);
    }
}
