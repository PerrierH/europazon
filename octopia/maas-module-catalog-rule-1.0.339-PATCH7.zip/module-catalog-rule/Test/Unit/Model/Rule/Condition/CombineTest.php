<?php

namespace Maas\CatalogRule\Test\Unit\Model\Rule\Condition;

use PHPUnit\Framework\TestCase;
use Maas\CatalogRule\Model\Rule\Condition\Combine;
use Magento\Rule\Model\Condition\Combine as CombineFromRule;
use Maas\CatalogRule\Model\Rule\Condition\ProductFactory;
use Maas\CatalogRule\Model\Rule\Condition\Product;
use Magento\Rule\Model\Condition\Context;

class CombineTest extends TestCase
{
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $context;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $conditionFactory;
    /**
     * @var Combine
     */
    private $setUp;

    public function setUp()
    {
        $this->conditionFactory = $this->createPartialMock(
            ProductFactory::class,
            ['create']
        );
        $this->context = $this->createMock(Context::class);

        $this->setUp = new Combine(
            $this->context,
            $this->conditionFactory,
            []
        );
    }

    public function testGetChildSelection()
    {
        $expectedCondition = [
            [
                'value' => '',
                'label' => __('Please choose a condition to add.')
            ],
            [
                'value' => 'Maas\CatalogRule\Model\Rule\Condition\Combine',
                'label' => __('Conditions Combination')
            ],
            [
                'value' => [[
                    'label' => 'Status',
                    'value' => 'Maas\CatalogRule\Model\Rule\Condition\Product|status'
                ]],
                'label' => __('Product Attribute')
            ]
        ];
        $product = $this->getMockConditionProduct();
        $this->conditionFactory->expects($this->any())->method('create')->willReturn($product);
        $product->expects($this->any())->method('loadAttributeOptions')->willReturnSelf();
        $product->expects($this->any())->method('getAttributeOption')->willReturn([
            'status' => 'Status',
        ]);
        $conditions = $this->setUp->getNewChildSelectOptions();
        $this->assertEquals($expectedCondition, $conditions, 'Should be an arry with mutiple dimension');
    }

    private function getMockConditionProduct()
    {
        return $this->getMockBuilder(Product::class)
            ->setMethods(['getAttributeOption', 'loadAttributeOptions'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }
}
