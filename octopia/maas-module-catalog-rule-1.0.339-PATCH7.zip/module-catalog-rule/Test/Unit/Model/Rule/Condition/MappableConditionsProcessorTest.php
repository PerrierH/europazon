<?php


namespace Maas\CatalogRule\Test\Unit\Model\Rule\Condition;

use PHPUnit\Framework\TestCase;
use Magento\Framework\Api\SearchCriteria\CollectionProcessor\ConditionProcessor\CustomConditionProvider;
use Magento\Eav\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\CatalogRule\Model\Rule\Condition\MappableConditionsProcessor;
use Magento\Eav\Model\Entity\Attribute\AbstractAttribute;
use Maas\CatalogRule\Model\Rule\Condition\Combine as CombinedCondition;
use Maas\CatalogRule\Model\Rule\Condition\Product as SimpleCondition;

class MappableConditionsProcessorTest extends TestCase
{
    const RETURN_VALUE = 0;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $customConditionProvider;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $eavConfig;
    /**
     * @var MappableConditionsProcessor
     */
    private $stub;

    public function initTest($processorForField = false, $backendType = null)
    {
        $this->customConditionProvider = $this->createMockCustomConditionProvider($processorForField);
        $this->eavConfig = $this->createMockEavConfig($backendType);
        $this->stub = new MappableConditionsProcessor(
            $this->customConditionProvider,
            $this->eavConfig
        );
    }

    /**
     * @dataProvider contionType
     */
    public function testWrongConditionType($type)
    {
        $this->initTest();
        $condition = $this->createMockCondition($type, []);
        $conditions = $this->createMockCondition($type, [$condition]);
        $this->expectExceptionMessage('Undefined condition type "' . $type . '" passed in.');
        $this->stub->rebuildConditionsTree($conditions);
    }


    /**
     * @dataProvider dataAggregator
     */
    public function testWithCombinedConditionTypeAndCountNotSuperiorToZero($aggregator)
    {
        $this->initTest();
        $condition = $this->createMockCondition(CombinedCondition::class, [], $aggregator);
        $conditions = $this->createMockCondition(CombinedCondition::class, [$condition], $aggregator);
        $originalCondition = $this->stub->rebuildConditionsTree($conditions);
        $conditions->setData(['conditions' => []]);
        $this->assertEquals($conditions, $originalCondition, 'Should get a condition');
    }


    public function testWithCombinedConditionTypeAndCountSuperiorToZero()
    {
        $this->initTest();
        $condition1 = $this->createMockCondition(CombinedCondition::class, []);
        $condition2 = $this->createMockCondition(CombinedCondition::class, [$condition1]);
        $conditions = $this->createMockCondition(CombinedCondition::class, [$condition1, $condition2]);
        $originalCondition = $this->stub->rebuildConditionsTree($conditions);
        $condition2->setData(['conditions' => []]);
        $conditions->setData(['conditions' => [$condition2]]);
        $this->assertEquals($conditions, $originalCondition, 'Should get a condition');
    }

    public function testWithSimpleConditionTypeAndCountSuperiorToZeroAndFieldForMappingFalse()
    {
        $this->initTest();
        $condition = $this->createMockSimpleCondition(SimpleCondition::class);
        $conditions = $this->createMockCondition(SimpleCondition::class, [$condition]);
        $originalCondition = $this->stub->rebuildConditionsTree($conditions);
        $conditions->setData(['conditions' => []]);
        $this->assertEquals($conditions, $originalCondition, 'Should get a condition');
    }

    /**
     * @dataProvider dataProcessorFieldAndBAckendType
     */
    public function testWithSimpleConditionTypeAndCountSuperiorToZeroAndFieldForMappingTrue($processorForField , $backendType )
    {
        $this->initTest($processorForField, $backendType);
        $condition = $this->createMockSimpleCondition(SimpleCondition::class);
        $conditions = $this->createMockCondition(SimpleCondition::class, [$condition]);
        $this->customConditionProvider->expects($this->any())->method('hasProcessorForField')->willReturn(true);
        $originalCondition = $this->stub->rebuildConditionsTree($conditions);
        $conditions->setData(['conditions' => [$condition]]);
        $this->assertEquals($conditions, $originalCondition, 'Should get a condition');
    }

    public function contionType()
    {
        yield from [
            'type contion null' => [null],
            'type condition is not CombinedConditon and SimpleCondition' => ['TypeNotExist']
        ];
    }

    public function dataAggregator()
    {
        yield from [
            'aggreator is not any' => ['some'],
            'aggreator is any' => ['any'],
        ];
    }

    public function dataProcessorFieldAndBAckendType()
    {
        yield from [
            'processor field different de false' => [true, false],
            'backendType different de null' => [false, true]
        ];
    }

    private function createMockSimpleCondition($type, $aggregator = '')
    {
        return AnyBuilder::createForClass($this, SimpleCondition::class, [
            'getConditions' => [$this->any(), [], self::RETURN_VALUE],
            'getType' => [$this->any(), $type, self::RETURN_VALUE],
            'getAggregator' => [$this->any(), $aggregator, self::RETURN_VALUE],
            'getAttribute' => [$this->any(), 'test', self::RETURN_VALUE]
        ])->build();
    }


    private function createMockCondition($type, $conditons, $aggregator = '')
    {
        return AnyBuilder::createForClass($this, CombinedCondition::class, [
            'getConditions' => [$this->any(), $conditons, self::RETURN_VALUE],
            'getType' => [$this->any(), $type, self::RETURN_VALUE],
            'getAggregator' => [$this->any(), $aggregator, self::RETURN_VALUE]
        ])->build();
    }

    private function createMockCustomConditionProvider($processorForField)
    {
        return AnyBuilder::createForClass($this, CustomConditionProvider::class, [
            'hasProcessorForField' => [$this->any(), $processorForField, self::RETURN_VALUE],
        ])->build();
    }



    private function createMockEavConfig($backendType)
    {
        return AnyBuilder::createForClass($this, Config::class, [
            'getAttribute' => [$this->any(), $this->createMockAbstractAttribute($backendType), self::RETURN_VALUE],
        ])->build();
    }

    private function createMockAbstractAttribute($backendType)
    {
        return AnyBuilder::createForClass($this, AbstractAttribute::class, [
            'getBackendType' => [$this->any(), $backendType, self::RETURN_VALUE],
        ])->build();
    }

}
