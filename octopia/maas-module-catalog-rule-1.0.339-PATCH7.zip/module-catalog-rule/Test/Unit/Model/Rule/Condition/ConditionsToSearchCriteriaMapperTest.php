<?php


namespace Maas\CatalogRule\Test\Unit\Model\Rule\Condition;

use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\CatalogRule\Model\Rule\Condition\ConditionsToSearchCriteriaMapper;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\CombinedFilterGroupFactory;
use Magento\Framework\Api\FilterFactory;
use Magento\Framework\Api\Filter;
use Maas\CatalogRule\Model\Rule\Condition\Combine as CombinedCondition;
use Maas\CatalogRule\Model\Rule\Condition\Product as SimpleCondition;
use Magento\Framework\Api\SearchCriteria;

class ConditionsToSearchCriteriaMapperTest extends TestCase
{
    const RETURN_VALUE = 0;
    const  OPERATOR_MAP = [
        '==' => 'eq',    // is
        '!=' => 'neq',   // is not
        '>=' => 'gteq',  // equals or greater than
        '<=' => 'lteq',  // equals or less than
        '>' => 'gt',    // greater than
        '<' => 'lt',    // less than
        '{}' => 'like',  // contains
        '!{}' => 'nlike', // does not contains
        '()' => 'in',    // is one of
        '!()' => 'nin',   // is not one of
        '<=>' => 'is_null'
    ];
    const OPERATOR_AGGREGATOR_MAP = [
       'all' => 'AND',
       'any' => 'OR'
    ];
    /**
     * @var AnyBuilder
     */
    private $searchCriteriaBuilderFactory;
    /**
     * @var AnyBuilder
     */
    private $combinedFilterGroupFactory;
    /**
     * @var AnyBuilder
     */
    private $filterFactory;
    /**
     * @var ConditionsToSearchCriteriaMapper
     */
    private $stub;

    public function initTest($filter = null, $groupFilter = null)
    {
        $this->searchCriteriaBuilderFactory = AnyBuilder::createForClass($this, SearchCriteriaBuilderFactory::class, [
            'create' => [$this->any(), $this->createMockSearchCriteriaBuilder(), self::RETURN_VALUE]
        ])->build();
        $this->combinedFilterGroupFactory = AnyBuilder::createForClass(
            $this,
            CombinedFilterGroupFactory::class,
            [
            'create' => [
                $this->any(),
                $groupFilter,
                self::RETURN_VALUE
            ]
            ]
        )->build();
        $this->filterFactory = AnyBuilder::createForClass($this, FilterFactory::class, [
            'create' => [$this->any(), $filter, self::RETURN_VALUE]
        ])->build();
        $this->stub = new ConditionsToSearchCriteriaMapper(
            $this->searchCriteriaBuilderFactory,
            $this->combinedFilterGroupFactory,
            $this->filterFactory
        );
    }

    public function testFilterGroupNullAndFiltersCountZero()
    {
        $this->initTest();
        $conditions = $this->createMockCondition();
        $searchCriteria = $this->stub->mapConditionsToSearchCriteria($conditions);
        $this->assertEquals($this->createMockSearchCriteria(), $searchCriteria, 'should return a searchCriteria empty');
    }

    public function testInputExceptionUndefinedCondition()
    {
        $this->initTest();
        $condition = $this->createMockCondition();
        $conditions = $this->createMockCondition(CombinedCondition::class, [$condition]);
        $this->expectExceptionMessage('Undefined condition type "" passed in.');
        $this->stub->mapConditionsToSearchCriteria($conditions);
    }

    public function testCombinedCondition()
    {
        $this->initTest();
        $condition = $this->createMockCondition(CombinedCondition::class, [], CombinedCondition::class);
        $conditions = $this->createMockCondition(CombinedCondition::class, [$condition]);

        $searchCriteria = $this->stub->mapConditionsToSearchCriteria($conditions);
        $this->assertEquals($this->createMockSearchCriteria(), $searchCriteria, 'should return a searchCriteria empty');
    }

    public function testSimpleConditionNotExist()
    {
        $this->initTest();
        $errorSecondArgument = implode(',', array_keys(self::OPERATOR_MAP));
        $operator = '??';
        $condition = $this->createMockCondition(SimpleCondition::class, [], SimpleCondition::class, $operator);
        $conditions = $this->createMockCondition(CombinedCondition::class, [$condition]);
        $this->expectExceptionMessage(
            'Undefined rule operator "' . $operator . '" passed in. Valid operators are: ' . $errorSecondArgument
        );
        $this->stub->mapConditionsToSearchCriteria($conditions);
    }

    public function testSimpleConditionExistWrongAggretor()
    {
        $errorSecondArgument = implode(',', array_keys(self::OPERATOR_AGGREGATOR_MAP));
        $filter = $this->mockCreateFilter();
        $this->initTest($filter);
        $operator = '{}';
        $condition = $this->createMockCondition(SimpleCondition::class, [], SimpleCondition::class, $operator);
        $conditions = $this->createMockCondition(CombinedCondition::class, [$condition]);
        $this->expectExceptionMessage(
            'Undefined rule aggregator "" passed in. Valid operators are: '.$errorSecondArgument
        );
         $this->stub->mapConditionsToSearchCriteria($conditions);
    }

    public function testSimpleConditionExist()
    {
        $filter = $this->mockCreateFilter();
        $this->initTest($filter);
        $operator = '{}';
        $condition = $this->createMockCondition(SimpleCondition::class, [], SimpleCondition::class, $operator);
        $conditions = $this->createMockCondition(
            CombinedCondition::class,
            [$condition],
            CombinedCondition::class,
            $operator,
            'all'
        );
        $searchCriteria = $this->stub->mapConditionsToSearchCriteria($conditions);
        $this->assertEquals($this->createMockSearchCriteria(), $searchCriteria, 'should return a searchCriteria empty');
    }

    private function createMockCondition(
        $testClass = CombinedCondition::class,
        $conditions = [],
        $type = '',
        $operator = '',
        $aggregator = '',
        $attribute = '',
        $value = ''
    ) {
        return AnyBuilder::createForClass($this, $testClass, [
            'getConditions' => [$this->any(), $conditions, self::RETURN_VALUE],
            'getType' => [$this->any(), $type, self::RETURN_VALUE],
            'getAttribute' => [$this->any(), $attribute, self::RETURN_VALUE],
            'getValue' => [$this->any(), $value, self::RETURN_VALUE],
            'getOperator' => [$this->any(), $operator, self::RETURN_VALUE],
            'getAggregator' => [$this->any(), $aggregator, self::RETURN_VALUE],
        ])->build();
    }

    private function createMockSearchCriteriaBuilder()
    {
        return AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'create' => [$this->any(), $this->createMockSearchCriteria(), self::RETURN_VALUE]
        ])->build();
    }

    private function createMockSearchCriteria()
    {
        return AnyBuilder::createForClass($this, SearchCriteria::class)->build();
    }

    private function mockCreateFilter()
    {
        return AnyBuilder::createForClass($this, Filter::class)->build();
    }
}
