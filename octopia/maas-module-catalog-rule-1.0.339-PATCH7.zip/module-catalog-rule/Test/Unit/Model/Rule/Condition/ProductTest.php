<?php

namespace Maas\CatalogRule\Test\Unit\Model\Rule\Condition;

use PHPUnit\Framework\TestCase;
use Magento\Backend\Helper\Data;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Maas\CatalogRule\Model\Rule\Condition\Product as ProductMaas;
use Magento\Catalog\Model\ProductCategoryList;
use Magento\Catalog\Model\ProductFactory;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Model\Config;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Locale\FormatInterface;
use Magento\Rule\Model\Condition\Context;
use Magento\Catalog\Model\ResourceModel\Product;
use Magento\Eav\Api\Data\AttributeInterface;
use Magento\Framework\Api\Filter;
use Magento\Eav\Api\Data\AttributeSearchResultsInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Api\AbstractSimpleObject;

class ProductTest extends TestCase
{
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $context;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $backendData;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $config;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $productFactory;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $productRepository;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $productResource;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $attrSetCollection;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $localeFormat;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $attributeRepository;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $searchCriteriaBuilder;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $filterBuilder;
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject
     */
    private $categoryList;
    /**
     * @var ProductMaas
     */
    private $stub;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    private $objectManager;
    /**
     * @var object
     */
    private $filterGroupBuilder;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->context = $this->createMock(Context::class);
        $this->backendData = $this->createMock(Data::class);
        $this->config = $this->createMock(Config::class);
        $this->productFactory = $this->createMock(ProductFactory::class);
        $this->productRepository = $this->createMock(ProductRepositoryInterface::class);
        $this->productResource = $this->createMock(Product::class);
        $this->attrSetCollection = $this->createMock(Collection::class);
        $this->localeFormat = $this->createMock(FormatInterface::class);
        $this->attributeRepository = $this->createMock(AttributeRepositoryInterface::class);
        $attributeSearchResultsInterface = $this->createMock(AttributeSearchResultsInterface::class);
        $this->attributeRepository->expects($this->any())->method('getList')->willReturn($attributeSearchResultsInterface);
        $attributeInterface = $this->getMockBuilder(AttributeInterface::class)
            ->setMethods(['getAttributeCode', 'getFrontendLabel'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
        $attributeSearchResultsInterface->expects($this->any())->method('getItems')->willReturn([$attributeInterface]);
        $this->searchCriteriaBuilder = $this->createMock(SearchCriteriaBuilder::class);
        $searchCriteriaInterface = $this->createMock(SearchCriteriaInterface::class);
        $this->searchCriteriaBuilder->expects($this->any())->method('create')->willReturn($searchCriteriaInterface);
        $this->filterBuilder = $this->objectManager->getObject(FilterBuilder::class);
        $this->filterGroupBuilder = $this->objectManager->getObject(FilterGroupBuilder::class);
        $this->categoryList = $this->createMock(ProductCategoryList::class);
        $this->stub = new ProductMaas(
            $this->context,
            $this->backendData,
            $this->config,
            $this->productFactory,
            $this->productRepository,
            $this->productResource,
            $this->attrSetCollection,
            $this->localeFormat,
            $this->attributeRepository,
            $this->searchCriteriaBuilder,
            $this->filterBuilder,
            $this->filterGroupBuilder,
            [],
            $this->categoryList
        );
    }

    public function testOperatorArray()
    {
        $expectedOperators = [
            'string' => ['==', '!=', '{}', '!{}'],
            'numeric' => ['>=', '>', '<=', '<'],
            'date' => ['==', '>=', '<='],
            'select' => ['==', '!='],
            'boolean' => ['==', '!='],
            'multiselect' => ['{}', '!{}', '()', '!()'],
            'grid' => ['()', '!()'],
            'category' => ['==', '!=', '{}', '!{}', '()', '!()'],
        ];

        $operators = $this->stub->getDefaultOperatorInputByType();
        $this->assertEquals($expectedOperators, $operators, 'should be our operators from product');
    }

    public function testGetExplicitApplyWithAttribute()
    {
        $this->stub->setAttribute('status');
        $this->assertTrue($this->stub->getExplicitApply(), 'should return true');
    }

    public function testGetExplicitApplyNoAttribute()
    {
        $this->assertFalse($this->stub->getExplicitApply(), 'should return false');
    }


    public function testGetValueAfterElementHtmlNoAttribute()
    {
        $this->assertEquals('', $this->stub->getValueAfterElementHtml(), 'Should return an empty string');
    }

    public function testGetValueElementChooserUrlNoAttribute()
    {
        $this->assertEquals('', $this->stub->getValueElementChooserUrl(), 'Should return an empty string');
    }


    public function testGetInputTypeNoAttribute()
    {
        $this->assertEquals('string', $this->stub->getInputType(), 'Should return an empty string');
    }

    public function testGetInputTypeWithAttribute()
    {
        $this->stub->setAttribute('weight');
        $this->assertEquals('numeric', $this->stub->getInputType(), 'Should return an empty string');
    }

}
