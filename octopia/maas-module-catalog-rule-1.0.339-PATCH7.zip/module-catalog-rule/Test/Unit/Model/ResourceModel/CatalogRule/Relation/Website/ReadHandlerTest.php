<?php

namespace Maas\CatalogRule\Test\Unit\Model\ResourceModel\CatalogRule\Relation\Website;

use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\Relation\Website\ReadHandler;
use Magento\Framework\EntityManager\EntityMetadata;
use Magento\Framework\EntityManager\MetadataPool;
use PHPUnit\Framework\TestCase;

class ReadHandlerTest extends TestCase
{
    /**
     * @var ReadHandler
     */
    protected $subject;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $resourceMock;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $metadataMock;

    protected function setUp()
    {
        $this->resourceMock = $this->createMock(CatalogRule::class);
        $this->metadataMock = $this->createMock(MetadataPool::class);
        $this->subject = new ReadHandler(
            $this->resourceMock,
            $this->metadataMock
        );
    }

    public function testExecute()
    {
        $entityId = 100;
        $entityType = CatalogRuleInterface::class;
        $entityData = [
            'entity_id' => $entityId
        ];

        $customerGroupIds = [1, 2, 3];
        $websiteIds = [4, 5, 6];

        $metadataMock = $this->createPartialMock(
            EntityMetadata::class,
            ['getLinkField']
        );
        $this->metadataMock->expects($this->once())
            ->method('getMetadata')
            ->with($entityType)
            ->willReturn($metadataMock);

        $metadataMock->expects($this->once())->method('getLinkField')->willReturn('entity_id');

        $this->resourceMock->expects($this->once())
            ->method('getWebsiteIds')
            ->with($entityId)
            ->willReturn($websiteIds);

        $expectedResult = [
            'entity_id' => $entityId,
            'website_ids' => $websiteIds
        ];

        $this->assertEquals($expectedResult, $this->subject->execute($entityType, $entityData));
    }
}
