<?php

namespace Maas\CatalogRule\Test\Unit\Model\ResourceModel\CatalogRule\Relation\Website;

use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\Relation\Website\SaveHandler;
use Magento\Framework\EntityManager\EntityMetadata;
use Magento\Framework\EntityManager\MetadataPool;

class SaveHandlerTest extends \PHPUnit\Framework\TestCase
{
    /**
     * @var SaveHandler
     */
    protected $subject;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $resourceMock;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    protected $metadataMock;

    protected function setUp()
    {
        $this->resourceMock = $this->createMock(CatalogRule::class);
        $this->metadataMock = $this->createMock(MetadataPool::class);
        $this->subject = new SaveHandler(
            $this->resourceMock,
            $this->metadataMock
        );
    }

    public function testExecute()
    {
        $entityId = 100;
        $entityType = CatalogRuleInterface::class;
        $websiteIds = '4, 5, 6';
        $entityData = [
            'entity_id' => $entityId,
            'website_ids' => $websiteIds,
        ];

        $metadataMock = $this->createPartialMock(
            EntityMetadata::class,
            ['getLinkField']
        );
        $this->metadataMock->expects($this->once())
            ->method('getMetadata')
            ->with($entityType)
            ->willReturn($metadataMock);
        $metadataMock->expects($this->once())->method('getLinkField')->willReturn('entity_id');

        $this->resourceMock->expects($this->at(0))
            ->method('bindRuleToEntity')
            ->with($entityId, explode(',', (string)$websiteIds), 'website')
            ->willReturnSelf();


        $this->assertEquals($entityData, $this->subject->execute($entityType, $entityData));
    }
}
