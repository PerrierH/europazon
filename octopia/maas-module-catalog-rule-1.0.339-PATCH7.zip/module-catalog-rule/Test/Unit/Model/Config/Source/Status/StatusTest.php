<?php

namespace Maas\CatalogRule\Test\Unit\Model\Config\Source\Status;

use Maas\CatalogRule\Model\Config\Source\Status\Status;
use PHPUnit\Framework\TestCase;

class StatusTest extends TestCase
{

    /**
     * @var Status
     */
    private $stub;

    public function setUp()
    {
        $this->stub = new Status();
    }

    public function testGetAllOptionForSelect()
    {
        $expectedValue = [
            ['value' => 1, 'label' => 'Active'],
            ['value' => 0, 'label' => 'Inactive']
        ];
        $this->assertEquals($expectedValue, $this->stub->getAllOptions(), 'Wrong value diplayed');
    }

    /**
     * @dataProvider eventDataOptionId
     *
     * @param $optionId
     */
    public function testRetrieveOptionTextByOptionValue($optionId)
    {
        $this->assertEquals( ($optionId === 0)?'Inactive' : 'Active' ,$this->stub->getOptionText($optionId), 'Should display active or inactive');
    }

    /**
     * @dataProvider eventDataWrongOptionId
     *
     * @param $optionId
     */
    public function testRetrieveOptionTextByOptionValueWithWrongOptionId($optionId)
    {
       $this->assertEquals( null ,$this->stub->getOptionText($optionId), 'Should display null');
    }

    public function eventDataWrongOptionId()
    {
        return [
            'Option Id null' => [null],
            'Option Id does not exist' => [3],
        ];
    }

    public function eventDataOptionId()
    {
        return [
            'Option Id inactive' => [0],
            'Option Id active' => [1],
        ];
    }
}
