<?php
namespace Maas\CatalogRule\Cron;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class ApplyRule
 * @package Maas\CatalogRule\Cron
 * @codeCoverageIgnore
 */
class ApplyRule extends CommandRunner
{
    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:apply:rules";
    }
}
