<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Condition\Widget;

use Maas\CatalogRule\Model\Rule\Condition\Product;
use Magento\Backend\App\Action;
use \Maas\CatalogRule\Block\Adminhtml\Category\Checkboxes\Tree;
use Magento\Framework\App\Request\Http as HttpRequest;

/**
 * Class Chooser
 * Controller is not tested in magento
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Controller\Adminhtml\Condition\Widget
 */
class Chooser extends Action
{
    /**
     * Prepare block for chooser
     *
     * @return void
     */
    public function execute()
    {
        $request = $this->getRequest();
        foreach (Product::ATTIBUTE_WITH_CHECKBOX_SELECTION as $attribute) {
            switch ($request->getParam('attribute')) {
                case $attribute:
                    $block = $this->_view->getLayout()->createBlock(
                        $this->getAttributeClassPath($attribute),
                        'promo_widget_chooser_status',
                        ['data' => ['js_form_object' => $request->getParam('form')]]
                    );
                    break;
                case 'category_ids':
                    $block = $this->_view->getLayout()->createBlock(
                        Tree::class,
                        'promo_widget_chooser_category_ids',
                        ['data' => ['js_form_object' => $request->getParam('form')]]
                    )->setCategoryIds(
                        $this->getSelectedIdsFromRequest($request)
                    );
                    break;

                default:
                    $block = false;
                    break;
            }
            if ($block) {
                $this->getResponse()->setBody($block->toHtml());
                return;
            }
        }
    }

    /**
     * @param HttpRequest $request
     *
     * @return int[]
     */
    protected function getSelectedIdsFromRequest($request)
    {
        $ids = $this->getSelectedIdsAsArray($request);
        if (is_array($ids)) {
            foreach ($ids as $key => &$id) {
                $id = (int)$id;
                if ($id <= 0) {
                    unset($ids[$key]);
                }
            }

            $ids = array_unique($ids);
        } else {
            $ids = [];
        }
        return $ids;
    }

    /**
     * @param HttpRequest $request
     *
     * @return string[]|null
     */
    protected function getSelectedIdsAsArray($request)
    {
        $ids = $request->getParam('selected', []);
        if(is_string($ids))
        {
            $ids = explode(' ', $ids);
        }
        return $ids;
    }

    /**
     * @param string $attribute
     *
     * @return string
     */
    protected function getAttributeClassPath($attribute)
    {
        if ($attribute == "maas_offer_seller_id") {
            $attribute = "maas_sellerId";
        } elseif ($attribute == "maas_offer_seller_name") {
            $attribute = "maas_sellerName";
        }
        $explodeAttibute = explode('_', $attribute);
        $className = array_key_exists(1, $explodeAttibute) ? $explodeAttibute[1] : $explodeAttibute[0];
        return 'Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser\\' . ucfirst($className ?? '');
    }
}
