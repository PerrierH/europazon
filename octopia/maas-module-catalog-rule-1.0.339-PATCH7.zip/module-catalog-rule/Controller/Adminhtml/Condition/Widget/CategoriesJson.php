<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Condition\Widget;

use Magento\Catalog\Controller\Adminhtml\Category\Widget\CategoriesJson as MagentoCategoriesJson;

/**
 * Class CategoriesJson
 *
 * @package Maas\CatalogRule\Controller\Adminhtml\Condition\Widget
 */
class CategoriesJson extends MagentoCategoriesJson
{
}


