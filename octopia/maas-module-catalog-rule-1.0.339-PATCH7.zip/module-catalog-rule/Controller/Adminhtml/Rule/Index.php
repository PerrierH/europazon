<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Maas\CatalogRule\Model\Service\IsApplying;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 *
 * @method \Magento\Framework\App\Request\Http getRequest()
 * @method \Magento\Framework\App\Response\Http getResponse()
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Controller\Adminhtml\CatalogRule
 */
class Index extends Action
{

    private $isApplying;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param IsApplying $isApplying
     */
    public function __construct(
        Context $context,
        IsApplying $isApplying
    ){
        $this->isApplying = $isApplying;

        parent::__construct($context);
    }


    /**
     * @inheritdoc
     */
    public function execute()
    {
        if($this->isApplying->execute()) {
            $this->messageManager->addComplexSuccessMessage(
                'addCatalogRuleMessage',
                [
                    'message' => "Your rules are currently running. You can see the details of this execution in <a href='%1'>%2</a>.",
                    "url" => $this->getUrl('maaslog/report'),
                    "page_name" => 'the reports page'
                ]
            );
        }
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $this->_setActiveMenu('Maas_CatalogRule::catalogrule');
        $resultPage->addBreadcrumb(__('Core'), __('Commercial categorization'));
        $resultPage->getConfig()->getTitle()->prepend(__('Commercial categorization'));

        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Maas_CatalogRule::rule');
    }
}
