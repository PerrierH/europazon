<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Magento\Backend\App\Action;
use Maas\Core\Model\Service\RunCli;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Maas\CatalogRule\Model\Service\IsApplying;


/**
 * Class Apply
 *
 * @package Maas\CatalogRule\Controller\Adminhtml\Rule
 * @codeCoverageIgnore
 */
class Apply extends Action
{
    /** @var RunCli */
    private $runCli;

    /** @var IsApplying */
    private $isApplying;

    /**
     * Apply constructor.
     *
     * @param Action\Context $context
     * @param RunCli $runCli
     */
    public function __construct(
        Action\Context $context,
        RunCli $runCli,
        IsApplying $isApplying
    ){
        $this->runCli = $runCli;
        $this->isApplying = $isApplying;

        parent::__construct($context);
    }

    /**
     * @return ResultInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        if (!$this->isApplying->execute()) {
            $this->runCli->addToQueue('maas:apply:rules');
            $this->messageManager->addSuccessMessage(__('The rules will be executed in 1 minute. You will be able to see it from the report page'));
        } else {
            $this->messageManager->addErrorMessage(__('Rules applier is already in progress'));
        }

        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/');
    }
}
