<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;

/**
 * Class Edit
 * @codeCoverageIgnore
 * @method \Magento\Framework\App\Request\Http getRequest()
 * @method Http getResponse()
 *
 * @package Maas\CatalogRule\Controller\Adminhtml\CatalogRule
 */
class Edit extends Action
{
    /** @var CatalogRuleRepositoryInterface */
    private $entityRepository;
    /**
     * @var CatalogRuleInterface
     */
    private $catalogRule;

    private $registry = null;

    /**
     * Edit constructor.
     *
     * @param Context        $context
     * @param CatalogRuleRepositoryInterface $entityRepository
     */
    public function __construct(
        Context $context,
        CatalogRuleRepositoryInterface $entityRepository,
        CatalogRuleInterface $catalogRule,
        Registry $registry
    ) {
        $this->entityRepository = $entityRepository;
        $this->catalogRule = $catalogRule;
        $this->registry = $registry;
        parent::__construct($context);
    }


    /**
     * @inheritdoc
     */
    public function execute()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu(
            'Maas_CatalogRule::catalogrule'
        )->_addBreadcrumb(__('New catalog rule'), __('New catalog rule'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('New catalog rule'));
        $id = $this->getRequest()->getParam('id');
        if ($id === null) {
            /** @var  CatalogRuleInterface $rule */
            $rule = $this->catalogRule;
        } else {
            try {
                /** @var  CatalogRuleInterface $rule */
                $rule = $this->entityRepository->getById($id);

                $this->_view->getPage()->getConfig()->getTitle()->prepend($rule->getRule());
            } catch (NoSuchEntityException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                $resultRedirect = $this->resultRedirectFactory->create();
                return $resultRedirect->setPath('*/*/');
            }
        }
        $rule->getConditions()->setFormName('maas_catalog_rule_form');
        $rule->getConditions()->setJsFormObject(
            $rule->getConditionsFieldSetId($rule->getConditions()->getFormName())
        );

        $this->registry->register('current_condition_catalog_rule', $rule);
        return $this->resultFactory->create(ResultFactory::TYPE_PAGE);
    }
}
