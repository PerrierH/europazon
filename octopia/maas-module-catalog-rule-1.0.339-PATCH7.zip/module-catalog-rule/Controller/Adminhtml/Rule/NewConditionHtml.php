<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Maas\CatalogRule\Model\CatalogRule;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Rule\Model\Condition\AbstractCondition;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Maas\CatalogRule\Model\Rule\Condition\CombineFactory;
use Maas\CatalogRule\Model\Rule\Condition\ProductFactory;

/**
 * Class NewConditionHtml
 *
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Controller\Adminhtml\Rule
 */
class NewConditionHtml extends Action
{
    /**
     * @var CatalogRule
     */
    private $catalogRule;
    /**
     * @var CombineFactory
     */
    private $combineFactory;
    /**
     * @var ProductFactory
     */
    private $productFactory;

    public function __construct(
        Context $context,
        CatalogRule $catalogRule,
        CombineFactory $combineFactory,
        ProductFactory $productFactory
    ) {
        $this->combineFactory = $combineFactory;
        $this->productFactory = $productFactory;
        $this->catalogRule = $catalogRule;
        parent::__construct($context);
    }

    /**
     * @return void
     */
    public function execute()
    {
        $typeObject = null;
        $id = $this->getRequest()->getParam('id');
        $formName = $this->getRequest()->getParam('form_namespace');
        $typeArr = explode('|', str_replace('-', '/', $this->getRequest()->getParam('type')));
        $type = $typeArr[0];
        if ($type == 'Maas\CatalogRule\Model\Rule\Condition\Combine') {
            $typeObject = $this->combineFactory->create();
        } else {
            $typeObject = $this->productFactory->create();
        }
        $model = $typeObject
            ->setId($id)
            ->setType($type)
            ->setRule($this->catalogRule)
            ->setPrefix('conditions');

        if (!empty($typeArr[1])) {
            $model->setAttribute($typeArr[1]);
        }

        if ($model instanceof AbstractCondition) {
            $model->setJsFormObject($this->getRequest()->getParam('form'));
            $model->setFormName($formName);
            $html = $model->asHtmlRecursive();
        } else {
            $html = '';
        }
        $this->getResponse()->setBody($html);
    }
}
