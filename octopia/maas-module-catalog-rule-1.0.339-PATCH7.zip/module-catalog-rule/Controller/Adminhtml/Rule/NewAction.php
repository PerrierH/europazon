<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\Result\Forward;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class NewAction
 * @codeCoverageIgnore
 * @method \Magento\Framework\App\Request\Http getRequest()
 * @method \Magento\Framework\App\Response\Http getResponse()
 *
 * @package Maas\CatalogRule\Controller\Adminhtml\CatalogRule
 */
class NewAction extends Action
{
    /**
     * @inheritdoc
     */
    public function execute()
    {
        /** @var Forward $resultForward */
        $resultForward = $this->resultFactory->create(ResultFactory::TYPE_FORWARD);
        return $resultForward->forward('edit');
    }
}
