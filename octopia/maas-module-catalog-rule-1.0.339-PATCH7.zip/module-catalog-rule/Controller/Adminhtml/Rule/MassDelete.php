<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Backend\App\Action\Context;

/**
 * Class MassDelete
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Controller\Adminhtml\Rule
 */
class MassDelete extends Action
{
    /**
     * @var CatalogRuleRepositoryInterface
     */
    private $catalogRuleRepository;
    /**
     * @var FilterBuilder
     */
    private $filterBuilder;
    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * MassDelete constructor.
     *
     * @param Context $context
     * @param CatalogRuleRepositoryInterface $catalogRuleRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     */
    public function __construct(
        Context $context,
        CatalogRuleRepositoryInterface $catalogRuleRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder
    ) {
        $this->filterBuilder = $filterBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->catalogRuleRepository = $catalogRuleRepository;
        parent::__construct($context);
    }


    /**
     * Delete one or more rule(s) action
     *
     * @return void
     * @throws NotFoundException
     */
    public function execute()
    {
        if (!$this->getRequest()->isPost()) {
            throw new NotFoundException(__('Page not found.'));
        }

        $ruleIds = $this->getRequest()->getParam('rule');
        if (!is_array($ruleIds)) {
            $this->messageManager->addErrorMessage(__('Please select one or more subscribers.'));
        } else {
            try {
                $rules = $this->catalogRuleRepository->getList($this->getSearchCriteria($ruleIds));
                foreach ($rules->getItems() as $rule) {
                    $this->catalogRuleRepository->delete($rule);
                }
                $this->messageManager->addSuccessMessage(
                    __('Total of %1 record(s) were deleted.', count($ruleIds))
                );
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }

        $this->_redirect('*/*/index');
    }

    /**
     * @param $criteria
     *
     * @return SearchCriteria
     */
    protected function getSearchCriteria($ruleIds)
    {
        $filter = $this->filterBuilder
            ->setField('rule_id')
            ->setConditionType('in')
            ->setValue($ruleIds)
            ->create();
        $this->searchCriteriaBuilder->addFilters([$filter]);
        return $this->searchCriteriaBuilder->create();
    }
}
