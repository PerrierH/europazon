<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Maas\CatalogRule\Api\Data\CatalogRuleInterfaceFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;

/**
 * Class Save
 *
 * @method \Magento\Framework\App\Request\Http getRequest()
 * @method \Magento\Framework\App\Response\Http getResponse()
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Controller\Adminhtml\CatalogRule
 */
class Save extends Action
{
    /** @inheritdoc */
    protected $resultRedirectFactory;
    /** @var DataPersistorInterface */
    private $dataPersistor;
    /** @var CatalogRuleRepositoryInterface */
    private $entityRepository;

    /** @var CatalogRuleInterfaceFactory */
    private $entityFactory;

    /** @var DataObjectHelper */
    private $dataObjectHelper;
    private SerializerInterface $serializer;

    /**
     * Save constructor.
     *
     * @param Context $context
     * @param DataPersistorInterface $dataPersistor
     * @param CatalogRuleRepositoryInterface $entityRepository
     * @param CatalogRuleInterfaceFactory $entityFactory
     * @param DataObjectHelper $dataObjectHelper
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        CatalogRuleRepositoryInterface $entityRepository,
        CatalogRuleInterfaceFactory $entityFactory,
        DataObjectHelper $dataObjectHelper,
        SerializerInterface $serializer
    )
    {
        $this->dataPersistor = $dataPersistor;
        $this->entityRepository = $entityRepository;
        $this->entityFactory = $entityFactory;
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context);
        $this->serializer = $serializer;
    }

    /**
     * @inheritdoc
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        try {
            if (!empty($data)) {
                $id = $this->getRequest()->getPost('rule_id');
                $entity = ($id === null) ? $this->entityFactory->create() : $this->entityRepository->getById($id);

                if (isset($data['rule'])) {
                    $data['conditions'] = $data['rule']['conditions'];
                    unset($data['rule']);
                }

                $categories = '';
                if (isset($data['category_ids']) && is_array($data['category_ids'])) {
                    $categories = implode(',', $data['category_ids']);
                }
                $data['category_ids'] = $categories;
                unset($data['conditions_serialized']);
                unset($data['actions_serialized']);

                $entity->loadPost($data);

                $this->dataPersistor->set('maas_catalog_rule_engine', $data);
                $this->entityRepository->save($entity);
                $this->messageManager->addSuccessMessage(__('Your rule has been saved'));
                $this->dataPersistor->clear('maas_catalog_rule_engine');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $entity->getId()]);
                }
            }

            return $resultRedirect->setPath('*/*/');
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the entity.'));
        }

        $this->dataPersistor->set('maas_catalog_rule_engine', $data);
        return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
    }
}
