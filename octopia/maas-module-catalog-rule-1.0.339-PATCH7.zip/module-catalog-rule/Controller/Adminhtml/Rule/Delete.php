<?php

namespace Maas\CatalogRule\Controller\Adminhtml\Rule;

use Exception;
use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\App\Response\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;

/**
 * Class Delete
 *
 * @codeCoverageIgnore
 * @method \Magento\Framework\App\Request\Http getRequest()
 * @method Http getResponse()
 *
 * @package Maas\CatalogRule\Controller\Adminhtml\CatalogRule
 */
class Delete extends Action
{
    /** @var CatalogRuleRepositoryInterface */
    private $entityRepository;

    /**
     * Delete constructor.
     *
     * @param Context $context
     * @param CatalogRuleRepositoryInterface $entityRepository
     */
    public function __construct(
        Context $context,
        CatalogRuleRepositoryInterface $entityRepository
    ) {
        $this->entityRepository = $entityRepository;
        parent::__construct($context);
    }


    /**
     * @return Redirect|ResponseInterface|ResultInterface
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        if ($id === null) {
            $this->messageManager->addErrorMessage(__('We can\'t find a rule to delete.'));

            return $resultRedirect->setPath('*/*/');
        }
        try {
            $this->entityRepository->deleteById($id);
            $this->messageManager->addSuccessMessage(__('The rule has been deleted.'));

            return $resultRedirect->setPath('*/*/');
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());

            return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
        }
    }
}
