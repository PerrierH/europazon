<?php

namespace Maas\CatalogRule\Model;

use Maas\Core\Model\Config as CoreConfig;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 *
 * @package Maas\Catalog\Model
 * @codeCoverageIgnore
 */
class Config extends CoreConfig
{
    public const XML_PATH_MAAS_CATALOG_RULE_RUNNING = 'catalogrule/running';

    /**
     * @param null $scopeCode
     *
     * @return string|null
     */
    public function getCatalogRuleRunning($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_MAAS_CATALOG_RULE_RUNNING);
    }
}
