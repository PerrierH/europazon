<?php

namespace Maas\CatalogRule\Model;

use Exception;
use Maas\Catalog\Model\Config;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\Collection;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\CollectionFactory;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Catalog\Model\Indexer\Product\Eav\Processor as EavProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\Processor as FlatProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\State as FlatState;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product as ProductResourceModel;
use Magento\Catalog\Model\ResourceModel\Product\Action as ProductAction;
use Magento\Catalog\Model\ResourceModel\Product\Collection as ProductCollection;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\CatalogInventory\Model\Indexer\Stock\Processor as StockProcessor;
use Magento\Framework\App\Cache\Frontend\Pool;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Adapter\Pdo\Mysql;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Indexer\BatchSizeManagementInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Store\Api\StoreWebsiteRelationInterface;
use DateInterval;
use DateTime as PhpDateTime;
use Maas\Core\Model\TokenFactory;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\DataObject;
use Zend_Http_Response;
use Magento\Catalog\Model\Indexer\Product\Category\Processor as CategoryProductsIndexer;

/**
 * Class ApplyRules
 * @package Maas\CatalogRule\Controller\Adminhtml\Rule
 * @codeCoverageIgnore
 */
class ApplyRules
{
    const MAAS_LOG_ACTION = 'Product_Categorization';

    const MAAS_LOG_MODULE = 'Maas_CatalogRule';

    const MAAS_LOG_OPERATION_TYPE = 'Update';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_catalog_rule_update_report_id';

    /**
     * @var Collection
     */
    protected $catalogRulesFactory;

    /**
     * @var ProductCollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * @var Config
     */
    protected $maasCatalogConfig;

    /**
     * @var CategoryCollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var TypeListInterface
     */
    protected $cacheTypeList;

    /**
     * @var Pool
     */
    protected $cacheFrontendPool;

    /**
     * @var ProductAction
     */
    private $productAction;

    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;

    /**
     * @var ReportFactory
     */
    protected $reportFactory;

    /**
     * @var int
     */
    private $scheduleId;

    /**
     * @var DateTime
     */
    private $dateTime;

    /**
     * @var StoreWebsiteRelationInterface
     */
    private $storeWebsiteRelation;

    /**
     * @var ProductResourceModel
     */
    private $productResource;

    /**
     * @var Report
     */
    private $report;

    /**
     * @var array
     */
    private $massCategorieIds = [];

    /**
     * @var EavProcessor
     */
    protected $indexerEavProcessor;

    /**
     * @var StockProcessor
     */
    protected $stockIndexerProcessor;

    /**
     * @var FlatState
     */
    private $flatState;

    /**
     * @var FlatProcessor
     */
    protected $productFlatIndexerProcessor;

    /**
     * @var array
     */
    private $batchRowsCount;

    /**
     * @var BatchSizeManagementInterface
     */
    private $batchSizeManagement;

    /**
     * @var ResourceConnection
     */
    private $resource;

    /**
     * @var ReportCollectionFactory
     */
    private $reportCollectionFactory;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    protected \Maas\ImportExport\Model\Config $configProvider;
    protected CacheInterface $cache;
    protected ReportManagementInterface $reportManagement;
    protected CategoryProductsIndexer $categoryProductsIndexer;

    /**
     * @var EventManager
     */
    private $eventManager;

    /**
     * @param ResourceConnection $resource
     * @param CollectionFactory $catalogRulesFactory
     * @param Config $maasCatalogConfig
     * @param ProductAction $productAction
     * @param ProductCollectionFactory $productCollectionFactory
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param TypeListInterface $cacheTypeList
     * @param Pool $cacheFrontendPool
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param ReportFactory $reportFactory
     * @param DateTime $dateTime
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param StoreWebsiteRelationInterface $storeWebsiteRelation
     * @param ProductResourceModel $productResource
     * @param EavProcessor $indexerEavProcessor
     * @param StockProcessor $stockIndexerProcessor
     * @param FlatState $flatState
     * @param FlatProcessor $productFlatIndexerProcessor
     * @param CategoryProductsIndexer $categoryProductsIndexer
     * @param SerializerInterface $serializer
     * @param \Maas\ImportExport\Model\Config $configProvider
     * @param CacheInterface $cache
     * @param EventManager $eventManager
     * @param BatchSizeManagementInterface|null $batchSizeManagement
     * @param array $batchRowsCount
     */
    public function __construct(
        ResourceConnection              $resource,
        CollectionFactory               $catalogRulesFactory,
        Config                          $maasCatalogConfig,
        ProductAction                   $productAction,
        ProductCollectionFactory        $productCollectionFactory,
        CategoryCollectionFactory       $categoryCollectionFactory,
        TypeListInterface               $cacheTypeList,
        Pool                            $cacheFrontendPool,
        ReportRepositoryInterface       $reportRepository,
        ReportManagementInterface       $reportManagement,
        ReportFactory                   $reportFactory,
        DateTime                        $dateTime,
        ReportCollectionFactory         $reportCollectionFactory,
        StoreWebsiteRelationInterface   $storeWebsiteRelation,
        ProductResourceModel            $productResource,
        EavProcessor                    $indexerEavProcessor,
        StockProcessor                  $stockIndexerProcessor,
        FlatState                       $flatState,
        FlatProcessor                   $productFlatIndexerProcessor,
        CategoryProductsIndexer         $categoryProductsIndexer,
        SerializerInterface             $serializer,
        \Maas\ImportExport\Model\Config $configProvider,
        CacheInterface                  $cache,
        EventManager                    $eventManager,
        BatchSizeManagementInterface    $batchSizeManagement = null,
        array                           $batchRowsCount = []
    )
    {
        $this->resource = $resource;
        $this->productAction = $productAction;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->catalogRulesFactory = $catalogRulesFactory;
        $this->maasCatalogConfig = $maasCatalogConfig;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->cacheFrontendPool = $cacheFrontendPool;
        $this->cacheTypeList = $cacheTypeList;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->reportFactory = $reportFactory;
        $this->dateTime = $dateTime;
        $this->reportCollectionFactory = $reportCollectionFactory;
        $this->storeWebsiteRelation = $storeWebsiteRelation;
        $this->productResource = $productResource;
        $this->indexerEavProcessor = $indexerEavProcessor;
        $this->stockIndexerProcessor = $stockIndexerProcessor;
        $this->flatState = $flatState;
        $this->productFlatIndexerProcessor = $productFlatIndexerProcessor;
        $this->categoryProductsIndexer = $categoryProductsIndexer;
        $this->serializer = $serializer;
        $this->configProvider = $configProvider;
        $this->cache = $cache;
        $this->batchSizeManagement = $batchSizeManagement ?: ObjectManager::getInstance()->get(
            BatchSizeManagement::class
        );
        $this->batchRowsCount = $batchRowsCount;
        $this->eventManager = $eventManager;
    }

    /**
     * @param $module
     * @param $action
     * @param $status
     * @return bool
     */
    protected function checkIfCommandLaunched($module, $action, $status)
    {
        $collection = $this->reportCollectionFactory->create();
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', $status)
            ->setPageSize(1);

        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }

        return false;
    }

    /**
     * @throws Exception
     */
    public function startProcess(array $args = null): Report
    {
        /* Empecher l'execution simultanee de la meme commande CLI */
        $isCommandLaunched = $this->checkIfCommandLaunched(
            static::MAAS_LOG_MODULE,
            static::MAAS_LOG_ACTION,
            Report::STATUS_STARTED
        );
        if ($isCommandLaunched) {
            $report = $isCommandLaunched;
            /* check if job timeout exceeded */
            if ($this->isJobTimeoutExceeded($report)) {
                $report->setMessage("Job timeout exceeded");
                $this->reportManagement->close($report);
            } elseif ($report->isJobOver()) {
                $this->reportManagement->close($report);
            } else {
                throw new AlreadyExistsException(__('%1 operation is already launched', static::MAAS_LOG_ACTION));
            }
        }
        /* Init Maas Log */
        $report = $this->initLog($args);
        /* Save Report ID in cache */
        $this->saveReportIdInCache($report->getId());
        return $report;
    }

    /**
     *
     * @return DataObject|bool
     */
    public function getStartedImportReportObject()
    {
        return $this->reportCollectionFactory->create()
            ->addFieldToFilter('module', static::MAAS_LOG_MODULE)
            ->addFieldToFilter('action', static::MAAS_LOG_ACTION)
            ->addFieldToFilter('status', Report::STATUS_STARTED)
            ->getFirstItem();
    }

    /**
     * @return int|null
     */
    public function loadReportIdFromCache()
    {
        $reportId = $this->cache->load(static::CACHE_KEY_MAAS_REPORT_ID);
        return $reportId ?? null;
    }


    /**
     * @param int $reportId
     *
     * @codeCoverageIgnore
     */
    public function saveReportIdInCache(int $reportId)
    {
        $this->cache->save($reportId, static::CACHE_KEY_MAAS_REPORT_ID);
    }


    /**
     * @param array|null $args
     * @param bool $echo
     *
     * @return Report
     */
    protected function initLog(array $args = null, bool $echo = true)
    {
        /** @var Report $newReport */
        $newReport = $this->reportFactory->create();
        $newReport->setEcho($echo);
        if (($args != null) && array_key_exists('scheduleId', $args)) {
            $newReport->setScheduleId($args['scheduleId']);
        }

        return $this->reportRepository->generateLogReport(
            $newReport,
            static::MAAS_LOG_MODULE,
            static::MAAS_LOG_ACTION,
            static::MAAS_LOG_OPERATION_TYPE
        );
    }

    /**
     * Check if Import Job Timout expired
     * @param Report $report
     * @return bool
     * @throws Exception
     */
    protected function isJobTimeoutExceeded(Report $report)
    {
        $jobTimeout = $this->configProvider->getJobTimeout();
        if (is_null($jobTimeout)) {
            return false;
        }
        $reportUpdatedAt = new PhpDatetime($report->getData('updated_at'));
        $reportUpdatedAt->add(new DateInterval('PT' . $jobTimeout . 'M'));
        $dateNow = new PhpDatetime('NOW');
        return $reportUpdatedAt < $dateNow;
    }

    public function getRules(int $limit = 0): array
    {
        /** @var @var Collection $catalogRulesCollection */
        $catalogRulesCollection = $this->catalogRulesFactory->create();
        $catalogRulesCollection->addFieldToFilter("status", 1);
        if ($limit) {
            $catalogRulesCollection->setPageSize($limit);
        }
        return $catalogRulesCollection->getItems();
    }

    /**
     * @param ReportInterface $report
     * @param array $rules
     * @return void|null
     * @throws Exception
     */
    public function apply(&$report, $rules)
    {
        $warnings = [];
        $productsToAssign = $allProducts = $productIds = [];
        $oldProductIds = [];
        /**
         * @var \Maas\CatalogRule\Model\CatalogRule $rule
         */
        foreach ($rules as $rule) {
            if ($rule->getConditionsSerialized() == '' || !$rule->getConditionsSerialized()) {
                $warnings[] = $rule->getId();
                $report->warning(__("The conditions to the rule %1 is empty", $rule->getName()));
                continue;
            }
            $conditions = $this->serializer->unserialize($rule->getConditionsSerialized());
            if (!isset($conditions['conditions'])) {
                $warnings[] = $rule->getId();
                $report->warning(__("The conditions to the rule %1 is empty", $rule->getName()));
                continue;
            }

            $productCollection = $this->productCollectionFactory->create();
            $productCollection->addCategoriesFilter(['in' => $rule['category_ids']]);
            if ($rule->getLastExecutionDate()) {
                $productCollection->addAttributeToFilter('updated_at', ['gteq' => $rule->getLastExecutionDate()]);
            }
            $this->filterOnlyMaasProducts($productCollection);
            $oldProductIds = $productCollection->getAllIds();
            $productIds = [];
            $maasProductsCollection = $rule->getMatchingProducts();
            if ($maasProductsCollection) {
                $this->filterOnlyMaasProducts($maasProductsCollection);
                $productIds = $maasProductsCollection->getAllIds();
            }
            $this->removeOldAssignedProducts($report, $rule, $oldProductIds, $productIds, $warnings);
            if (!count($productIds)) {
                $warnings[] = $rule->getId();
                $report->warning(__("There are no products related to the rule %1", $rule->getName()));
                continue;
            }
            if (!count(array_diff($productIds, $oldProductIds))) {
                $warnings[] = $rule->getId();
                $report->warning(__("All selected products are already linked by this rule %1", $rule->getName()));
                continue;
            }
            //Actions
            $this->addNewAssignedProducts(
                $rule, $oldProductIds, $productIds, $maasProductsCollection, $productsToAssign
            );
            //prevent to empty the condition
            $rule->loadPost(['last_execution_date' => date("Y-m-d H:i:s")]);
            $rule->save();
        }

        $allProducts = array_merge($allProducts, array_merge($oldProductIds, $productIds));
        $this->assignProductToCategories($report, $productsToAssign, $warnings);
        $this->reindexProductsCategory($allProducts);
        $this->eventManager->dispatch('maas_products_attributes_update_after_save', ['ids' => $allProducts]);
        $this->logInReport($report, $warnings);
    }

    protected function logInReport(&$report, $warnings)
    {
        $warningsCount = count(array_unique($warnings));
        $report->setWarningItemsCount($warningsCount);
        $report->setSuccessItemsCount($report->getItemsCount() - $warningsCount);
    }

    /**
     * @param $rule
     * @return array
     */
    protected function getStoreIdsForRule($rule)
    {
        $storeIds = [];
        foreach ($rule->getWebsiteIds() as $websiteId) {
            $storeIds = array_merge($storeIds, $this->storeWebsiteRelation->getStoreByWebsiteId($websiteId));
        }
        return $storeIds;
    }

    /**
     * @param ProductCollection|null $productCollection
     * @return void
     * @throws LocalizedException
     */
    private function filterOnlyMaasProducts(?ProductCollection &$productCollection)
    {
        if ($productCollection) {
            if (!count($this->massCategorieIds)) {
                $categoryCollection = $this->categoryCollectionFactory->create();
                $categoryCollection->addAttributeToSelect('maas_is_maas_category');
                $categoryCollection->addAttributeToFilter('maas_is_maas_category', ['eq' => 1]);
                $this->massCategorieIds = $categoryCollection->getAllIds();
            }
            $productCollection->addAttributeToSelect(['entity_id', 'sku', 'maas_offer_id']);
            $productCollection->addAttributeToSelect('category_ids', 'left');
            $productCollection->addAttributeToFilter('maas_is_maas_product', ['eq' => 1]);
            $productCollection->addCategoriesFilter(['in' => $this->massCategorieIds]);
        }
    }

    /**
     * Products re indexation
     * @param array $ids
     */
    private function reindexProductsCategory(array $ids)
    {
        if (count($ids)) {
            if ($this->categoryProductsIndexer->isIndexerScheduled()) {
                $this->categoryProductsIndexer->markIndexerAsInvalid();
            } else {
                $this->categoryProductsIndexer->reindexList($ids);
            }
        }
    }

    /**
     * @param int $scheduleId
     */
    public function setScheduleId(int $scheduleId)
    {
        $this->scheduleId = $scheduleId;
    }

    /**
     * Add the news Maas product to the category
     *
     * @param CatalogRule $rule
     * @param array $oldProductIds
     * @param array $newProductIds
     * @param ProductCollection $maasProductsCollection
     * @param array $productsToAssign
     */
    private function addNewAssignedProducts(
        CatalogRule       $rule,
        array             $oldProductIds,
        array             $newProductIds,
        ProductCollection $maasProductsCollection,
        array             &$productsToAssign
    )
    {
        $productToAdd = array_diff($newProductIds, $oldProductIds);
        if (count($productToAdd)) {
            if (empty($productsToAssign)) {
                $productsToAssign = array_fill_keys(
                    $productToAdd,
                    ['category_ids' => $this->maasCatalogConfig->getMaasRootCategory()]
                );
            }
            $this->prepareAssignmentOfProductToToCategories($maasProductsCollection, $rule, $productsToAssign);
        }
    }

    /**
     * Prepare the table of assignment of products to the categories defined by a rule
     *
     * @param ProductCollection $maasProductsCollection
     * @param CatalogRule $rule
     * @param array $productsToAssign
     */
    private function prepareAssignmentOfProductToToCategories(
        ProductCollection $maasProductsCollection,
        CatalogRule       $rule,
        array             &$productsToAssign
    )
    {
        /** @var Product $product */
        foreach ($maasProductsCollection->getItems() as $product) {
            $productId = $product->getId();
            $newCategories = explode(',', $rule->getCategoryIds());
            if (!array_key_exists($productId, $productsToAssign)) {
                $productsToAssign[$productId] = [];
                $productsToAssign[$productId]['category_ids'] = $product->getCategoryIds();
            }
            $productsToAssign[$productId]['category_ids'] = array_unique(
                array_merge((array)$productsToAssign[$productId]['category_ids'], $newCategories)
            );
            $productsToAssign[$productId]['sku'] = $product->getSku();
            $productsToAssign[$productId]['product_id'] = $product->getId();
            $productsToAssign[$productId]['ruleId'] = $rule->getId();
        }
    }

    /**
     * Remove old Maa product assigned to category
     *
     * @param $report
     * @param CatalogRule $rule
     * @param array $oldProductIds
     * @param array $newProductIds
     * @param array $warnings
     */
    private function removeOldAssignedProducts(
        $report,
        CatalogRule $rule,
        array $oldProductIds,
        array $newProductIds,
        array &$warnings
    )
    {
        $productToDelete = array_diff($oldProductIds, $newProductIds);
        if (count($productToDelete)) {
            /** @var Mysql $connection */
            $connection = $this->resource->getConnection();
            $batchRowCount = array_key_exists('remove', $this->batchRowsCount)
                ? $this->batchRowsCount['remove']
                : 1000;
            $this->batchSizeManagement->ensureBatchSize($connection, $batchRowCount);
            $productToDeleteBunches = array_chunk($productToDelete, $batchRowCount);
            foreach ($productToDeleteBunches as $productToDeleteBunche) {
                if (count($productToDeleteBunche)) {
                    try {
                        $connection->beginTransaction();
                        $categoriesIds = explode(',', $rule->getCategoryIds());
                        $whereConditions = [
                            $connection->quoteInto('product_id IN (?)', $productToDeleteBunche),
                            $connection->quoteInto('category_id IN (?)', $categoriesIds)
                        ];
                        $connection->delete(
                            $connection->getTableName('catalog_category_product'),
                            $whereConditions
                        );
                        $connection->commit();
                        $logData = [
                            $this->dateTime->date(),
                            $rule->getId(),
                            implode(',', $productToDeleteBunche),
                            implode(',', $categoriesIds)
                        ];
                        $report->success(__('%1 Rule %2 : sku %3 removed from specified categories %4', $logData));
                    } catch (\Exception $e) {
                        $connection->rollBack();
                        $logData = [$this->dateTime->date(), $rule->getId(), $rule->getCategoryIds()];
                        $report->warning(
                            __("%1 Rule %2 : error while removing product from the category %3", $logData)
                        );
                        $warnings[] = $rule->getId();
                    }
                }
            }
        }
    }

    /**
     * Assign products to the categories
     *
     * @param $report
     * @param $productsToAssign
     * @param array $warnings
     */
    private function assignProductToCategories(&$report, $productsToAssign, array &$warnings)
    {
        if (count($productsToAssign)) {
            /** @var Mysql $connection */
            $connection = $this->resource->getConnection();
            $batchRowCount = array_key_exists('assign', $this->batchRowsCount)
                ? $this->batchRowsCount['assign']
                : 1000;
            $this->batchSizeManagement->ensureBatchSize($connection, $batchRowCount);
            $productsToAssignsBunches = array_chunk($productsToAssign, $batchRowCount);
            foreach ($productsToAssignsBunches as $productsToAssignsBunche) {
                foreach ($productsToAssignsBunche as $product) {
                    if (array_key_exists('sku', $product) && array_key_exists('category_ids', $product)) {
                        try {
                            $connection->beginTransaction();
                            $bind = [];
                            foreach ($product['category_ids'] as $categoryId) {
                                $bind[] = [
                                    $product['product_id'],
                                    $categoryId
                                ];
                            }
                            $connection->insertArray(
                                $connection->getTableName('catalog_category_product'),
                                ['product_id', 'category_id'],
                                $bind,
                                AdapterInterface::INSERT_IGNORE
                            );
                            $connection->commit();
                            $logData = [
                                $this->dateTime->date(),
                                $product['ruleId'],
                                $product['sku'],
                                implode(',', $product['category_ids'])
                            ];
                            $report->success(__('%1 Rule %2 : sku %3 added to the cat: %4', $logData));
                        } catch (\Exception $e) {
                            $connection->rollBack();
                            $warnings[] = $product['ruleId'];
                            $warningItemsCount = $report->getWarningItemsCount() ?? 0;
                            $report->setWarningItemsCount($warningItemsCount + 1);
                            // TODO Hide error message log
                            $logData = [
                                $this->dateTime->date(),
                                $product['ruleId'],
                                $product['sku'],
                                implode(',', $product['category_ids'])
                            ];
                            $report->warning(__("%1 Rule %2 : error while adding product sku %3  to cat: %4", $logData));
                            $report->warning(__("Trace Error: %1", $e->getMessage()));
                        }
                    }
                }
            }
        }
    }
}
