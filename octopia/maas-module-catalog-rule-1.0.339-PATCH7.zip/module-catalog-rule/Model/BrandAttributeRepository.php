<?php


namespace Maas\CatalogRule\Model;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class BrandAttributeRepository
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model
 */
class BrandAttributeRepository
{
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * BrandAttributeRepository constructor.
     */
    public function __construct(
        CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * @codeCoverageIgnore
     * @return array
     * @throws NoSuchEntityException
     */
    public function getBrandNames()
    {
        $productCollection = $this->collectionFactory->create();
        /** @var Collection $productCollection */
        $productCollection->addAttributeToSelect('maas_brand')
            ->addAttributeToFilter('maas_brand', array('notnull' => true))
            ->getSelect()->group('maas_brand');
        return $productCollection->getItems();
    }
}
