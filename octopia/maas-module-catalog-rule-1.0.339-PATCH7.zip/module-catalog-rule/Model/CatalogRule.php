<?php

namespace Maas\CatalogRule\Model;

use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\Collection;
use Magento\Catalog\Model\ProductFactory;
use Maas\CatalogRule\Model\ResourceModel\Product\ConditionsToCollectionApplier;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Model\ResourceModel\Iterator;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Rule\Model\AbstractModel;
use Maas\CatalogRule\Model\Rule\Condition\CombineFactory;
use Maas\CatalogRule\Model\Rule\Condition\Combine;
use Magento\Rule\Model\Condition\Combine as RuleCombine;
use Magento\SalesRule\Model\Rule\Condition\Product\CombineFactory as ProductCombineFactory;
use Magento\Rule\Model\Action\Collection as ActionCollection;
use Magento\Catalog\Model\ResourceModel\Product\Collection as ProductCollection;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

/**
 * Class CatalogRule
 *
 * @method ResourceModel\CatalogRule getResource()
 * @method Collection getCollection()
 * @method Collection getResourceCollection()
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model
 */
class CatalogRule extends AbstractModel implements CatalogRuleInterface
{
    /**
     * @inheritdoc
     */
    protected $_eventPrefix = 'maas_catalogrule_rules';

    protected $_eventObject = 'rule';

    /** @var CombineFactory */
    protected $condCombineFactory;

    /** @var ProductCombineFactory */
    protected $productCombineFactory;

    /**
     * Store matched product Ids
     *
     * @var array
     */
    protected $_productIds;

    /**
     * @var CollectionFactory
     */
    protected $_productCollectionFactory;

    /**
     * @var ConditionsToCollectionApplier
     */
    private $conditionsToCollectionApplier;

    /**
     * @var ProductFactory
     */
    protected $_productFactory;

    /**
     * @var Iterator
     */
    protected $_resourceIterator;

    /**
     * @var ProductCollection|null
     */
    private $productCollection = null;

    /**
     * CatalogRule constructor.
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param TimezoneInterface $localeDate
     * @param CombineFactory $condCombineFactory
     * @param ProductCombineFactory $productCombineFactory
     * @param CollectionFactory $productCollectionFactory
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     * @param ExtensionAttributesFactory|null $extensionFactory
     * @param AttributeValueFactory|null $customAttributeFactory
     * @param Json|null $serializer
     * @param ConditionsToCollectionApplier|null $conditionsToCollectionApplier
     * @param Iterator $resourceIterator
     * @param ProductFactory $productFactory
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        TimezoneInterface $localeDate,
        CombineFactory $condCombineFactory,
        ProductCombineFactory $productCombineFactory,
        CollectionFactory $productCollectionFactory,
        ConditionsToCollectionApplier $conditionsToCollectionApplier,
        Iterator $resourceIterator,
        ProductFactory $productFactory,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = [],
        ExtensionAttributesFactory $extensionFactory = null,
        AttributeValueFactory $customAttributeFactory = null,
        Json $serializer = null
    ) {
        $this->_resourceIterator = $resourceIterator;
        $this->condCombineFactory = $condCombineFactory;
        $this->productCombineFactory = $productCombineFactory;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->conditionsToCollectionApplier = $conditionsToCollectionApplier;
        $this->_productFactory = $productFactory;
        parent::__construct(
            $context,
            $registry,
            $formFactory,
            $localeDate,
            $resource,
            $resourceCollection,
            $data,
            $extensionFactory,
            $customAttributeFactory,
            $serializer
        );
    }

    /**
     * @inheritdoc
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init(ResourceModel\CatalogRule::class);
        $this->setIdFieldName('rule_id');
    }

    /**
     * @return Combine
     */
    public function getConditionsInstance()
    {
        return $this->condCombineFactory->create();
    }

    /**
     * @return ActionCollection
     */
    public function getActionsInstance()
    {
        return $this->productCombineFactory->create();
    }


    /**
     * Getter for conditions field set ID
     *
     * @param string $formName
     *
     * @return string
     */
    public function getConditionsFieldSetId($formName = '')
    {
        return $formName . 'rule_conditions_fieldset_' . $this->getId();
    }

    /**
     * @inheritdoc
     */
    public function getRuleId()
    {
        return $this->_getData(self::RULE_ID);
    }

    /**
     * @inheritdoc
     */
    public function setRuleId($value)
    {
        $this->setData(self::RULE_ID, $value);

        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getName()
    {
        return $this->_getData(self::NAME);
    }

    /**
     * @inheritdoc
     */
    public function setName($value)
    {
        $this->setData(self::NAME, $value);

        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getStatus()
    {
        return $this->_getData(self::STATUS);
    }

    /**
     * @inheritdoc
     */
    public function setStatus($value)
    {
        $this->setData(self::STATUS, $value);

        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getPriority()
    {
        return $this->_getData(self::PRIORITY);
    }

    /**
     * @inheritdoc
     */
    public function setPriority($value)
    {
        $this->setData(self::PRIORITY, $value);

        return $this;
    }

    /**
     * @inheritdoc
     */
    public function getLastExecutionDate()
    {
        return $this->_getData(self::LAST_EXECUTION_DATE);
    }

    /**
     * @inheritdoc
     */
    public function setLastExecutionDate($value)
    {
        $this->setData(self::LAST_EXECUTION_DATE, $value);

        return $this;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->_getData(self::DESCRIPTION);
    }

    /**
     * @param string $value
     * @return $this
     */
    public function setDescription($value)
    {
        $this->setData(self::DESCRIPTION, $value);

        return $this;
    }

    /**
     * Get array of product ids which are matched by rule
     *
     * @return array
     * @throws InputException
     */
    public function getMatchingProductIds()
    {
        if ($this->_productIds === null) {
            $this->_productIds = $this->getMatchingProducts()->getAllIds();
        }
        return $this->_productIds;
    }

    /**
     * Get product collection which are matched by rule
     *
     * @return ProductCollection
     * @throws InputException
     */
    public function getMatchingProducts()
    {
        if (is_null($this->productCollection)) {
            if ($this->getWebsiteIds()) {
                $this->productCollection = $this->_productCollectionFactory->create();
                $this->productCollection->addAttributeToSelect('maas_offer_id');
                $this->productCollection->addWebsiteFilter($this->getWebsiteIds());
                $this->productCollection->addAttributeToFilter('maas_is_maas_product', ['eq' => 1]);
                if ($this->getLastExecutionDate()) {
                    $this->productCollection->addAttributeToFilter('updated_at', ['gteq' => $this->getLastExecutionDate()]);
                }
                if ($this->canPreMapProducts()) {
                    $this->getConditions()->collectValidatedAttributes($this->productCollection);
                    $this->productCollection = $this->conditionsToCollectionApplier
                        ->applyConditionsToCollection($this->getConditions(), $this->productCollection);
                }
            }
        }
        return $this->productCollection;
    }

    /**
     * Check if we can use mapping for rule conditions
     *
     * @return bool
     */
    public function canPreMapProducts()
    {
        $conditions = $this->getConditions();
        // No need to map products if there is no conditions in rule
        return $conditions && $conditions->getConditions();
    }

    /**
     * Retrieve rule combine conditions model
     *
     * @return RuleCombine
     */
    public function getConditions()
    {
        if (empty($this->_conditions)) {
            $this->_resetConditions();
        }

        $conditions = $this->getConditionsSerialized();
        if (!empty($conditions)) {
            $conditions = $this->serializer->unserialize($conditions);
            if (is_array($conditions) && !empty($conditions)) {
                $this->_conditions->loadArray($conditions);
            }
        }
        $this->unsConditionsSerialized();
        return $this->_conditions;
    }

    /**
     * @param string $value
     * @return $this
     */
    public function setCategoryIds($value)
    {
        $this->setData(self::CATEGORY_IDS, $value);

        return $this;
    }

    /**
     * @return string
     */
    public function getCategoryIds()
    {
        return $this->_getData(self::CATEGORY_IDS);
    }


    /**
     * Initialize rule model data from array
     *
     * @param array $data
     * @return $this
     */
    public function loadPost(array $data)
    {
        $arr = $this->_convertFlatToRecursive($data);
        if (isset($arr['conditions'])) {
            $oldConditions = $this->getOrigData('conditions');
            $this->getConditions()->setConditions([])->loadArray($arr['conditions'][1]);
            if ($this->getConditions() != $oldConditions) {
                $this->setData('last_execution_date', null);
            }
        }
        if (isset($arr['actions'])) {
            $oldActions = $this->getOrigData('actions');
            $this->getActions()->setActions([])->loadArray($arr['actions'][1], 'actions');
            if ($this->getActions() != $oldActions) {
                $this->setData('last_execution_date', null);
            }
        }

        return $this;
    }
}
