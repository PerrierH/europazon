<?php

namespace Maas\CatalogRule\Model\Service;

use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class IsApplying
 *
 * @package Maas\CatalogRule\Model\Service
 * @codeCoverageIgnore
 */
class IsApplying
{
    /** @var SearchCriteriaBuilder */
    private $searchCriteriaBuilder;

    /** @var ReportRepositoryInterface */
    private $reportRepository;

    /**
     * IsApplying constructor.
     *
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param ReportRepositoryInterface $reportRepository
     */
    public function __construct(
        SearchCriteriaBuilder $searchCriteriaBuilder,
        ReportRepositoryInterface $reportRepository
    ) {
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->reportRepository = $reportRepository;
    }

    /**
     * @return bool
     */
    public function execute()
    {
        $criteria = $this->searchCriteriaBuilder
            ->addFilter('module', 'Maas_CatalogRule')
            ->addFilter('action', 'Product_Categorization')
            ->addFilter('status', 'started')
            ->create();
        $reports = $this->reportRepository->getList($criteria)->getItems();
        return (count($reports) > 0);
    }

}
