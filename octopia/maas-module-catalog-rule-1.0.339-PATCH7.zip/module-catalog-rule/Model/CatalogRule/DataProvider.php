<?php

namespace Maas\CatalogRule\Model\CatalogRule;

use Maas\CatalogRule\Model\ResourceModel\CatalogRule\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;

/**
 * Class DataProvider
 *
 * @package Maas\CatalogRule\Model\CatalogRule
 */
class DataProvider extends AbstractDataProvider
{
    /** @var DataPersistorInterface */
    private $dataPersistor;

    /** @var array */
    private $loadedData = [];

    /**
     * DataProvider constructor.
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    )
    {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritdoc
     */
    public function getData()
    {
        if ($this->loadedData) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();

        foreach ($items as $item) {
            $item->load($item->getId());
            $categoryIds = $item->getCategoryIds() ?? '';
            $categoryIds = explode(',', $categoryIds);
            $item->setCategoryIds($categoryIds);
            $this->loadedData[$item->getId()] = $item->getData();
        }
        
        $data = $this->dataPersistor->get('maas_catalog_rule_engine');
        if (!empty($data)) {
            $item = $this->collection->getNewEmptyItem();
            $item->setData($data);
            $this->loadedData[$item->getId()] = $item->getData();
            $this->dataPersistor->clear('maas_catalog_rule_engine');
        }

        return $this->loadedData;
    }
}
