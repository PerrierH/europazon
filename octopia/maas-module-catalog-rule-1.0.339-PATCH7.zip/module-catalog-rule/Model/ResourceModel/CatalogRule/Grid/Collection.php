<?php

namespace Maas\CatalogRule\Model\ResourceModel\CatalogRule\Grid;

use Maas\CatalogRule\Model\ResourceModel\CatalogRule\Collection as CatalogRuleCollection;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\Grid\Collection as CatalogRuleGridCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model\ResourceModel\CatalogRule\Grid
 */
class Collection extends CatalogRuleCollection
{
    /**
     * @return CatalogRuleGridCollection
     */
    protected function _initSelect()
    {
        parent::_initSelect();

        $this->addWebsitesToResult();

        return $this;
    }
}
