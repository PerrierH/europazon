<?php

namespace Maas\CatalogRule\Model\ResourceModel\CatalogRule\Relation\Website;

use Exception;
use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule;
use Magento\Framework\EntityManager\MetadataPool;
use Magento\Framework\EntityManager\Operation\AttributeInterface;

/**
 * Class ReadHandler
 */
class ReadHandler implements AttributeInterface
{
    /**
     * @var CatalogRule
     */
    protected $ruleResource;

    /**
     * @var MetadataPool
     */
    protected $metadataPool;

    /**
     * @param CatalogRule $ruleResource
     * @param MetadataPool $metadataPool
     */
    public function __construct(
        CatalogRule $ruleResource,
        MetadataPool $metadataPool
    )
    {
        $this->ruleResource = $ruleResource;
        $this->metadataPool = $metadataPool;
    }

    /**
     * @param string $entityType
     * @param array $entityData
     * @param array $arguments
     * @return array
     * @throws Exception
     */
    public function execute($entityType, $entityData, $arguments = [])
    {
        $linkField = $this->metadataPool->getMetadata(CatalogRuleInterface::class)->getLinkField();
        $entityId = $entityData[$linkField];

        $entityData['website_ids'] = $this->ruleResource->getWebsiteIds($entityId);

        return $entityData;
    }
}
