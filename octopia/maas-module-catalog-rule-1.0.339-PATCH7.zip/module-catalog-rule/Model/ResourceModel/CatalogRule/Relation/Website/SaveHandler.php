<?php
namespace Maas\CatalogRule\Model\ResourceModel\CatalogRule\Relation\Website;

use Exception;
use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule;
use Magento\Framework\EntityManager\MetadataPool;
use Magento\Framework\EntityManager\Operation\AttributeInterface;

/**
 * Class SaveHandler
 */
class SaveHandler implements AttributeInterface
{
    /**
     * @var CatalogRule
     */
    protected $ruleResource;

    /**
     * @var MetadataPool
     */
    protected $metadataPool;

    /**
     * @param CatalogRule $ruleResource
     * @param MetadataPool $metadataPool
     */
    public function __construct(
        CatalogRule $ruleResource,
        MetadataPool $metadataPool
    )
    {
        $this->ruleResource = $ruleResource;
        $this->metadataPool = $metadataPool;
    }

    /**
     * @param string $entityType
     * @param array $entityData
     * @param array $arguments
     * @return array
     * @throws Exception
     */
    public function execute($entityType, $entityData, $arguments = [])
    {
        $linkField = $this->metadataPool->getMetadata(CatalogRuleInterface::class)->getLinkField();
        if (isset($entityData['website_ids'])) {
            $websiteIds = $entityData['website_ids'];
            if (!is_array($websiteIds)) {
                $websiteIds = explode(',', (string)$websiteIds);
            }
            $this->ruleResource->bindRuleToEntity($entityData[$linkField], $websiteIds, 'website');
        }

        return $entityData;
    }
}
