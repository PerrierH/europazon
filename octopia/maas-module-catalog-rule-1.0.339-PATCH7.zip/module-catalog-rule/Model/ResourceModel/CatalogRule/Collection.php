<?php

namespace Maas\CatalogRule\Model\ResourceModel\CatalogRule;

use Maas\CatalogRule\Model\CatalogRule;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule as CatalogRuleAliasResourceModel;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Magento\Framework\DataObject;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Rule\Model\ResourceModel\Rule\Collection\AbstractCollection;
use Psr\Log\LoggerInterface;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @method CatalogRuleAliasResourceModel getResource()
 * @method CatalogRule[] getItems()
 * @method CatalogRule[] getItemsByColumnValue($column, $value)
 * @method CatalogRule getFirstItem()
 * @method CatalogRule getLastItem()
 * @method CatalogRule getItemByColumnValue($column, $value)
 * @method CatalogRule getItemById($idValue)
 * @method CatalogRule getNewEmptyItem()
 * @method CatalogRule fetchItem()
 * @property CatalogRule[] _items
 * @property CatalogRuleAliasResourceModel _resource
 *
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritdoc
     */
    protected $_eventPrefix = 'maas_catalogrule_catalogrule_collection';

    /**
     * @inheritdoc
     */
    protected $_eventObject = 'object';
    /**
     * Store associated with rule entities information map
     *
     * @var array
     */

    protected $_associatedEntitiesMap = [];

    /**
     * Collection constructor.
     * @param EntityFactoryInterface $entityFactory
     * @param LoggerInterface $logger
     * @param FetchStrategyInterface $fetchStrategy
     * @param ManagerInterface $eventManager
     * @param AdapterInterface|null $connection
     * @param AbstractDb|null $resource
     */
    public function __construct(
        EntityFactoryInterface $entityFactory,
        LoggerInterface $logger,
        FetchStrategyInterface $fetchStrategy,
        ManagerInterface $eventManager,
        DataObject $associatedEntityMap,
        AdapterInterface $connection = null,
        AbstractDb $resource = null
    ) {
        $this->_associatedEntitiesMap = $associatedEntityMap->getData();
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
    }


    protected function _construct()
    {
        $this->_init(CatalogRule::class, CatalogRuleAliasResourceModel::class);
        $this->_setIdFieldName($this->getResource()->getIdFieldName());
    }

    /**
     * @return Collection
     * @throws LocalizedException
     */
    protected function _afterLoad()
    {
        $this->mapAssociatedEntities('website', 'website_ids');

        $this->setFlag('add_websites_to_result', false);
        return parent::_afterLoad();
    }

    /**
     * @param string $entityType
     * @param string $objectField
     * @return void
     * @throws LocalizedException
     */
    protected function mapAssociatedEntities($entityType, $objectField)
    {
        if (!$this->_items) {
            return;
        }

        $entityInfo = $this->_getAssociatedEntityInfo($entityType);
        $ruleIdField = $entityInfo['rule_id_field'];
        $entityIds = $this->getColumnValues($ruleIdField);

        $select = $this->getConnection()->select()->from(
            $this->getTable($entityInfo['associations_table'])
        )->where(
            $ruleIdField . ' IN (?)',
            $entityIds
        );

        $associatedEntities = $this->getConnection()->fetchAll($select);

        array_map(function ($associatedEntity) use ($entityInfo, $ruleIdField, $objectField) {
            $item = $this->getItemByColumnValue($ruleIdField, $associatedEntity[$ruleIdField]);
            $itemAssociatedValue = $item->getData($objectField) === null ? [] : $item->getData($objectField);
            $itemAssociatedValue[] = $associatedEntity[$entityInfo['entity_id_field']];
            $item->setData($objectField, $itemAssociatedValue);
        }, $associatedEntities);
    }

    /**
     * Retrieve correspondent entity information of rule's associated entity by specified entity type
     *
     * (associations table name, columns names)
     *
     * @param string $entityType
     * @return array
     * @throws LocalizedException
     */
    protected function _getAssociatedEntityInfo($entityType)
    {
        if (isset($this->_associatedEntitiesMap[$entityType])) {
            return $this->_associatedEntitiesMap[$entityType];
        }

        throw new LocalizedException(
            __('There is no information about associated entity type "%1".', $entityType)
        );
    }
}
