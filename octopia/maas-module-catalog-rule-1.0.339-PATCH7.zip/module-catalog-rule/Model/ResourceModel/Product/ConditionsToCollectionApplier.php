<?php

namespace Maas\CatalogRule\Model\ResourceModel\Product;

use Magento\Catalog\Model\ResourceModel\Product\Collection as ProductCollection;
use Maas\CatalogRule\Model\Rule\Condition\Combine;
use Magento\Framework\Exception\InputException;
use Maas\CatalogRule\Model\Rule\Condition\ConditionsToSearchCriteriaMapper;
use Magento\Framework\Api\SearchCriteria\CollectionProcessor\AdvancedFilterProcessor;
use Maas\CatalogRule\Model\Rule\Condition\MappableConditionsProcessor;

/**
 * Class ConditionsToCollectionApplier
 * This does not have any logic
 * we will just mock the exist so it s useless
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model\ResourceModel\Product
 */
class ConditionsToCollectionApplier
{
    /**
     * @var ConditionsToSearchCriteriaMapper
     */
    private $conditionsToSearchCriteriaMapper;

    /**
     * @var AdvancedFilterProcessor
     */
    private $searchCriteriaProcessor;

    /**
     * @var MappableConditionsProcessor
     */
    private $mappableConditionsProcessor;

    /**
     * @param ConditionsToSearchCriteriaMapper $conditionsToSearchCriteriaMapper
     * @param AdvancedFilterProcessor $searchCriteriaProcessor
     * @param MappableConditionsProcessor $mappableConditionsProcessor
     */
    public function __construct(
        ConditionsToSearchCriteriaMapper $conditionsToSearchCriteriaMapper,
        AdvancedFilterProcessor $searchCriteriaProcessor,
        MappableConditionsProcessor $mappableConditionsProcessor
    ) {
        $this->conditionsToSearchCriteriaMapper = $conditionsToSearchCriteriaMapper;
        $this->searchCriteriaProcessor = $searchCriteriaProcessor;
        $this->mappableConditionsProcessor = $mappableConditionsProcessor;
    }

    /**
     * Transforms catalog rule conditions to search criteria
     * and applies them on product collection
     *
     * @param Combine $conditions
     * @param ProductCollection $productCollection
     * @return ProductCollection
     * @throws InputException
     */
    public function applyConditionsToCollection(
        Combine $conditions,
        ProductCollection $productCollection
    ) {
        // rebuild conditions to have only those that we know how to map them to product collection
        $mappableConditions = $this->mappableConditionsProcessor->rebuildConditionsTree($conditions);

        // transform conditions to search criteria
        $searchCriteria = $this->conditionsToSearchCriteriaMapper->mapConditionsToSearchCriteria($mappableConditions);

        $mappedProductCollection = clone $productCollection;

        // apply search criteria to new version of product collection
        $this->searchCriteriaProcessor->process($searchCriteria, $mappedProductCollection);

        // Management of the interrogation point used on the regex that is not authorized by the magento
        $wheres = $mappedProductCollection->getSelect()->getPart(\Zend_Db_Select::WHERE);
        foreach ($wheres as &$where) {
            $where = str_replace(
                ConditionsToSearchCriteriaMapper::MAAS_INTERROGATION_REPLACEMENT,
                "?",
                $where
            );
        }
        $mappedProductCollection->getSelect()->setPart(\Zend_Db_Select::WHERE, $wheres);

        return $mappedProductCollection;
    }
}
