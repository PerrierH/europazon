<?php

namespace Maas\CatalogRule\Model\ResourceModel;

use Exception;
use Magento\Framework\DataObject;
use Magento\Framework\EntityManager\EntityManager;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\Context;
use Magento\Rule\Model\ResourceModel\AbstractResource;

/**
 * Class CatalogRule
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model\ResourceModel
 */
class CatalogRule extends AbstractResource
{
    protected $_associatedEntitiesMap = [];

    private $entityManager;

    /**
     * CatalogRule constructor.
     *
     * @param Context $context
     * @param EntityManager $entityManager
     * @param AssociatedEntityMap $associatedEntityMap
     * @param null $connectionName
     */
    public function __construct(
        Context $context,
        EntityManager $entityManager,
        DataObject $associatedEntityMap,
        $connectionName = null
    ) {
        $this->entityManager = $entityManager;
        $this->_associatedEntitiesMap = $associatedEntityMap->getData();
        parent::__construct($context, $connectionName);
    }


    /**
     * @param AbstractModel $object
     *
     * @return $this|CatalogRule
     * @throws Exception
     */
    public function save(AbstractModel $object)
    {
        $object->beforeSave();
        $this->entityManager->save($object);
        return $this;
    }

    /**
     * @param AbstractModel $object
     * @param mixed $value
     * @param string $field
     * @return $this
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function load(AbstractModel $object, $value, $field = null)
    {
        $this->entityManager->load($object, $value);
        return $this;
    }

    /**
     * @inheritdoc
     */
    protected function _construct()
    {
        $this->_init('maas_catalog_rule_engine', 'rule_id');
    }
}
