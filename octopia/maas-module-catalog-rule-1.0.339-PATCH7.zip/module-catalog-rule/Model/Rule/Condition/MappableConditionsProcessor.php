<?php

namespace Maas\CatalogRule\Model\Rule\Condition;

use Magento\Eav\Model\Config;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Api\SearchCriteria\CollectionProcessor\ConditionProcessor\CustomConditionProvider;
use Maas\CatalogRule\Model\Rule\Condition\Combine as CombinedCondition;
use Maas\CatalogRule\Model\Rule\Condition\Product as SimpleCondition;
use Magento\Catalog\Model\Product as ProductEntity;
use Magento\Framework\Exception\LocalizedException;

/**
 * Rebuilds catalog price rule conditions tree
 * so only those conditions that can be mapped to search criteria are left
 *
 * Those conditions that can't be mapped are deleted from tree
 * If deleted condition is part of combined condition with OR aggregation all this group will be removed
 */
class MappableConditionsProcessor
{
    /**
     * @var CustomConditionProvider
     */
    private $customConditionProvider;

    /**
     * @var Config
     */
    private $eavConfig;

    /**
     * MappableConditionsProcessor constructor.
     * @param CustomConditionProvider $customConditionProvider
     * @param Config $eavConfig
     */
    public function __construct(
        CustomConditionProvider $customConditionProvider,
        Config $eavConfig
    ) {
        $this->customConditionProvider = $customConditionProvider;
        $this->eavConfig = $eavConfig;
    }

    /**
     * @param Combine $conditions
     * @return Combine
     * @throws InputException
     * @throws LocalizedException
     */
    public function rebuildConditionsTree(CombinedCondition $conditions)
    {
        return $this->rebuildCombinedCondition($conditions);
    }

    /**
     * @param Combine $originalConditions
     * @return Combine
     * @throws InputException
     * @throws LocalizedException
     */
    private function rebuildCombinedCondition(CombinedCondition $originalConditions)
    {
        $validConditions = [];
        $invalidConditions = [];

        foreach ($originalConditions->getConditions() as $condition) {
            if ($condition->getType() === CombinedCondition::class) {
                $rebuildSubCondition = $this->rebuildCombinedCondition($condition);

                if (count($rebuildSubCondition->getConditions()) > 0) {
                    $validConditions[] = $rebuildSubCondition;
                } else {
                    $invalidConditions[] = $rebuildSubCondition;
                }

                continue;
            }

            if ($condition->getType() === SimpleCondition::class) {
                if ($this->validateSimpleCondition($condition)) {
                    $validConditions[] = $condition;
                } else {
                    $invalidConditions[] = $condition;
                }

                continue;
            }

            throw new InputException(
                __('Undefined condition type "%1" passed in.', $condition->getType())
            );
        }

        // if resulted condition group has left no mappable conditions - we can remove it at all
        if (!empty($invalidConditions) && strtolower($originalConditions->getAggregator()) === 'any') {
            $validConditions = [];
        }

        $rebuildCondition = clone $originalConditions;
        $rebuildCondition->setConditions($validConditions);

        return $rebuildCondition;
    }

    /**
     * @param Product $originalConditions
     * @return bool
     * @throws LocalizedException
     */
    private function validateSimpleCondition(SimpleCondition $originalConditions)
    {
        return $this->canUseFieldForMapping($originalConditions->getAttribute());
    }

    /**
     * Checks if condition field is mappable
     *
     * @param string $fieldName
     * @return bool
     * @throws LocalizedException
     */
    private function canUseFieldForMapping(string $fieldName)
    {
        // We can map field to search criteria if we have custom processor for it
        if ($this->customConditionProvider->hasProcessorForField($fieldName)) {
            return true;
        }

        // Also we can map field to search criteria if it is an EAV attribute
        $attribute = $this->eavConfig->getAttribute(ProductEntity::ENTITY, $fieldName);

        // We have this weird check for getBackendType() to verify that attribute really exists
        // because due to eavConfig behavior even if pass non existing attribute code we still receive AbstractAttribute
        // getAttributeId() is not sufficient too because some attributes don't have it - e.g. attribute_set_id
        if ($attribute && $attribute->getBackendType() !== null) {
            return true;
        }

        // In any other cases we can't map field to search criteria
        return false;
    }
}
