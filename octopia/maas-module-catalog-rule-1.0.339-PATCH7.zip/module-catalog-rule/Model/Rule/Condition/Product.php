<?php

namespace Maas\CatalogRule\Model\Rule\Condition;

use Magento\Backend\Helper\Data;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ProductCategoryList;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Model\ResourceModel\Product as ProductResourceModel;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Model\Config;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Locale\FormatInterface;
use Magento\Rule\Model\Condition\Context;
use Magento\Rule\Model\Condition\Product\AbstractProduct;
use Magento\Framework\Api\Search\FilterGroupBuilder;

/**
 * @method string getAttribute() Returns attribute code
 */
class Product extends AbstractProduct
{

    const ATTIBUTE_WITH_CHECKBOX_SELECTION = [
        'status',
        'visibility',
        'maas_brand',
        'maas_offer_seller_id',
        'maas_offer_seller_name',
        'category_ids',
    ];
    /**
     * @var AttributeRepositoryInterface
     */
    private $attributeRepository;
    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;
    /**
     * @var FilterBuilder
     */
    private $filterBuilder;
    /**
     * @var FilterGroupBuilder
     */
    private $filterGroupBuilder;

    /**
     * Product constructor.
     *
     * @param Context $context
     * @param Data $backendData
     * @param Config $config
     * @param ProductFactory $productFactory
     * @param ProductRepositoryInterface $productRepository
     * @param ProductResourceModel $productResource
     * @param Collection $attrSetCollection
     * @param FormatInterface $localeFormat
     * @param AttributeRepositoryInterface $attributeRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param array $data
     * @param ProductCategoryList|null $categoryList
     */
    public function __construct(
        Context $context,
        Data $backendData,
        Config $config,
        ProductFactory $productFactory,
        ProductRepositoryInterface $productRepository,
        ProductResourceModel $productResource,
        Collection $attrSetCollection,
        FormatInterface $localeFormat,
        AttributeRepositoryInterface $attributeRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        FilterGroupBuilder $filterGroupBuilder,
        array $data = [],
        ProductCategoryList $categoryList = null
    )
    {
        $this->filterBuilder = $filterBuilder;
        $this->filterGroupBuilder = $filterGroupBuilder;
        $this->attributeRepository = $attributeRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        parent::__construct(
            $context,
            $backendData,
            $config,
            $productFactory,
            $productRepository,
            $productResource,
            $attrSetCollection,
            $localeFormat,
            $data,
            $categoryList
        );
    }


    /**
     * Load attribute options
     *
     * @return $this
     */
    public function loadAttributeOptions()
    {
        $attributesMaas = [];
        $attributeMaasDatas = $this->getAttributeCodeAndLabel();

        foreach ($attributeMaasDatas['code'] as $attributeId => $attributeValue) {
            $attributesMaas[$attributeMaasDatas['code'][$attributeId]] = __($attributeMaasDatas['label'][$attributeId]);
        }
        $attributesMagento = [
            'status' => __('Status'),
            'name' => __('Product name'),
            'sku' => __('SKU'),
            'price' => __('Price'),
            'weight' => __('Weight'),
            'visibility' => __('Visibility'),
            'category_ids' => __('Category'),
            'description' => __('Description'),
            'short_description' => __('Short Description'),
            'maas_offer_seller_id' => __('Seller Id'),
            'maas_offer_seller_name' => __('Seller Name')
        ];
        $attributes = array_merge($attributesMagento, $attributesMaas);
        $this->setAttributeOption($attributes);
        return $this;
    }


    /**
     * No logic in that function
     * @codeCoverageIgnore
     * @return AbstractElement
     */
    public function getAttributeElement()
    {
        $element = parent::getAttributeElement();
        $element->setShowAsText(true);
        return $element;
    }

    /**
     * Get input type
     *
     * @return string
     */
    public function getInputType()
    {
        switch ($this->getAttribute()) {
            case 'weight':
            case 'price':
                return 'numeric';
            default:
                return 'string';
        }
    }

    /**
     * Retrieve value element chooser URL
     *
     * @return string
     */
    public function getValueElementChooserUrl()
    {
        $url = false;
        foreach (self::ATTIBUTE_WITH_CHECKBOX_SELECTION as $attributeCode) {
            if ($this->isAttributeWithCheckbox($attributeCode)) {
                $url = 'maascatalog/condition_widget/chooser/attribute/' . $this->getAttribute();
                if ($this->getJsFormObject()) {
                    $url .= '/form/' . $this->getJsFormObject();
                }
                return $this->_backendData->getUrl($url);
            }
        }
        return '';
    }

    /**
     * Retrieve after element HTML
     *
     * @return string
     */
    public function getValueAfterElementHtml()
    {
        $html = '';
        foreach (self::ATTIBUTE_WITH_CHECKBOX_SELECTION as $attributeCode) {
            if ($this->isAttributeWithCheckbox($attributeCode)) {
                $image = $this->_assetRepo->getUrl('images/rule_chooser_trigger.gif');
            }
        }

        if (!empty($image)) {
            $html = '<a href="javascript:void(0)" class="rule-chooser-trigger"><img src="' .
                $image .
                '" alt="" class="v-middle rule-chooser-trigger" title="' .
                __(
                    'Open Chooser'
                ) . '" /></a>';
        }
        return $html;
    }

    /**
     * Retrieve Explicit Apply
     *
     * @return bool
     * @SuppressWarnings(PHPMD.BooleanGetMethodName)
     */
    public function getExplicitApply()
    {
        foreach (self::ATTIBUTE_WITH_CHECKBOX_SELECTION as $attributeCode) {
            if ($this->isAttributeWithCheckbox($attributeCode)) {
                return true;
            }
        }
        return false;
    }

    private function isAttributeWithCheckbox($attributeCode)
    {
        return $this->getAttribute() == $attributeCode;
    }

    /**
     * Get value element type
     *
     * @codeCoverageIgnore
     * @return string
     */
    public function getValueElementType()
    {
        return 'text';
    }


    /**
     * Get value select options
     *
     * @codeCoverageIgnore
     * @return array|mixed
     */
    public function getValueSelectOptions()
    {
        return $this->getData('value_select_options');
    }

    /**
     * @return array
     */
    private function getAttributeCodeAndLabel()
    {
        $attributes = [];
        $filter = $this->filterBuilder
            ->setField('attribute_code')
            ->setConditionType('like')
            ->setValue('maas_%')
            ->create();
        $filterNotMaasProduct = $this->filterBuilder
            ->setField('attribute_code')
            ->setConditionType('neq')
            ->setValue('maas_is_maas_product')
            ->create();
        $filterGroup = $this->filterGroupBuilder
            ->setFilters([$filter])
            ->create();
        $filterGroupNotMaasProduct = $this->filterGroupBuilder
            ->setFilters([$filterNotMaasProduct])
            ->create();
        $this->searchCriteriaBuilder->setFilterGroups([$filterGroup, $filterGroupNotMaasProduct]);
        $searchCriteria = $this->searchCriteriaBuilder->create();
        $attributeSearchResultsInterface = $this->attributeRepository->getList(
            'catalog_product',
            $searchCriteria
        );
        foreach ($attributeSearchResultsInterface->getItems() as $items) {
            $attributes['code'][$items->getAttributeId()] = $items->getAttributeCode();
            $attributes['label'][$items->getAttributeId()] = $items->getFrontendLabel();
        }
        return $attributes;
    }

    /**
     * Customize default operator input by type mapper for some types
     *
     * @return array
     */
    public function getDefaultOperatorInputByType()
    {
        if (null === $this->_defaultOperatorInputByType) {
            parent::getDefaultOperatorInputByType();
            /*
             * '{}' and '!{}' are left for back-compatibility and equal to '==' and '!='
             */
            $this->_defaultOperatorInputByType['string'] = ['==', '!=', '{}', '!{}'];
            //not working for unit test on 2.3.4 so i forced the value for select and bool type
            $this->_defaultOperatorInputByType['select'] = ['==', '!='];
            $this->_defaultOperatorInputByType['boolean'] = ['==', '!='];

            $this->_defaultOperatorInputByType['numeric'] = ['>=', '>', '<=', '<'];
        }
        return $this->_defaultOperatorInputByType;
    }
}
