<?php

namespace Maas\CatalogRule\Model\Rule\Condition;

use Magento\Rule\Model\Condition\Combine as CombineFromRule;
use Magento\Rule\Model\Condition\Context;

class Combine extends CombineFromRule
{


    /**
     * @var ProductFactory
     */
    protected $_productFactory;

    /**
     * @param Context $context
     * @param ProductFactory $conditionFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        ProductFactory $conditionFactory,
        array $data = []
    ) {
        $this->_productFactory = $conditionFactory;
        parent::__construct($context, $data);
        $this->setType(Combine::class);
    }

    /**
     * @return array
     */
    public function getNewChildSelectOptions()
    {
        $productAttributes = $this->_productFactory->create()->loadAttributeOptions()->getAttributeOption();
        $attributes = [];
        foreach ($productAttributes as $code => $label) {
            $attributes[] = [
                'value' => Product::class . '|' . $code,
                'label' => ucfirst($label ?? ''),
            ];
        }

        $this->attributesSortByLabel($attributes);

        $conditions = parent::getNewChildSelectOptions();
        return array_merge_recursive(
            $conditions,
            [
                [
                    'value' => Combine::class,
                    'label' => __('Conditions Combination'),
                ],
                ['label' => __('Product Attribute'), 'value' => $attributes]
            ]
        );
    }

    /**
     * @param array $productCollection
     * We do not have logic so it s useless test
     * @codeCoverageIgnore
     * @return $this
     */
    public function collectValidatedAttributes($productCollection)
    {
        foreach ($this->getConditions() as $condition) {
            /** @var Product|Combine $condition */
            $condition->collectValidatedAttributes($productCollection);
        }
        return $this;
    }

    /**
     * @param $attributes
     * @param $col
     * @return void
     */
    protected function attributesSortByLabel(&$attributes, $col = 'label')
    {
        usort($attributes, function ($a, $b) use ($col) {
            return $a[$col] <=> $b[$col];
        });
    }
}
