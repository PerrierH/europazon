<?php

namespace Maas\CatalogRule\Model\Config\Source\Priority;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Priority
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model\Config\Source\Priority
 */
class Priority implements ArrayInterface
{
    /**
     * Get available options
     *
     * @codeCoverageIgnore
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'low', 'label' => __('Low')],
            ['value' => 'medium', 'label' => __('Medium')],
            ['value' => 'high', 'label' => __('High')],
        ];
    }
}
