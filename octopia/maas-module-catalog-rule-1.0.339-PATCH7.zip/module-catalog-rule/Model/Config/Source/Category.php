<?php

namespace Maas\CatalogRule\Model\Config\Source;

use Maas\Catalog\Model\Config;
use Magento\Catalog\Model\Category as CategoryAlias;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Ui\Component\Product\Form\Categories\Options;
use Magento\Framework\App\Cache\Type\Block;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Serialize\SerializerInterface;

/**
 * Class Category
 * @package Maas\CatalogRule\Model\Config\Source
 */
class Category extends Options
{
    /**
     * Category tree cache id
     */
    const CATEGORY_TREE_ID = 'CATALOG_MAAS_RULE_CATEGORY_TREE';

    /**
     * @var Config
     */
    protected $catalogConfig;

    /**
     * @var CacheInterface
     */
    protected $cacheManager;

    /**
     * @var SerializerInterface
     */
    private $serializer;


    /**
     * Category constructor.
     *
     * @param CollectionFactory $categoryCollectionFactory
     * @param RequestInterface $request
     * @param Config $catalogConfig
     * @param CacheInterface $cacheManager
     * @param SerializerInterface $serializer
     */
    public function __construct(
        CollectionFactory $categoryCollectionFactory,
        RequestInterface $request,
        Config $catalogConfig,
        CacheInterface $cacheManager,
        SerializerInterface $serializer
    )
    {
        $this->serializer = $serializer;
        $this->cacheManager = $cacheManager;
        $this->catalogConfig = $catalogConfig;
        parent::__construct($categoryCollectionFactory, $request);
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {

        $storeId = (int)$this->request->getParam('store');

        $cachedCategoriesTree = $this->cacheManager
            ->load($this->getCategoriesTreeCacheId($storeId));
        if (!empty($cachedCategoriesTree)) {
            return $this->serializer->unserialize($cachedCategoriesTree);
        }

        $options = parent::toOptionArray();
        foreach ($options as $rootCategoryId => $option) {
            if ($option['value'] == $this->catalogConfig->getMaasRootCategory()) {
                unset($options[$rootCategoryId]);
            }
        }

        $this->cacheManager->save(
            $this->serializer->serialize($options),
            $this->getCategoriesTreeCacheId($storeId),
            [
                CategoryAlias::CACHE_TAG,
                Block::CACHE_TAG
            ]
        );

        return $options;
    }

    /**
     * Get cache id for categories tree.
     *
     * @param int $storeId
     * @return string
     */
    private function getCategoriesTreeCacheId(int $storeId): string
    {
        return self::CATEGORY_TREE_ID . '_' . (string)$storeId;
    }
}
