<?php

namespace Maas\CatalogRule\Model;

use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Api\Data\CatalogRuleInterfaceFactory;
use Maas\CatalogRule\Api\Data\CatalogRuleSearchResultsInterfaceFactory;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule;
use Maas\CatalogRule\Model\ResourceModel\CatalogRule\CollectionFactory;
use Maas\Core\Model\AbstractRepository;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class CatalogRuleRepository
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Model
 */
class CatalogRuleRepository extends AbstractRepository implements CatalogRuleRepositoryInterface
{
    /**
     * @inheritdoc
     */
    public function save(CatalogRuleInterface $catalogRule)
    {
        try {
            $this->_save($catalogRule);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $catalogRule;
    }

    /**
     * @inheritdoc
     */
    public function findById($catalogRuleId)
    {
        $catalogRule = $this->get($catalogRuleId);

        if (!$catalogRule->getId()) {
            return null;
        }

        return $catalogRule;
    }

    /**
     * @inheritdoc
     */
    public function deleteById($catalogRuleId)
    {
        $this->_delete($this->get($catalogRuleId));
    }

    /**
     * @inheritdoc
     */
    public function delete(CatalogRuleInterface $catalogRule)
    {
        try {
            $this->_delete($catalogRule);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }

        return true;
    }

    /**
     * @inheritdoc
     */
    public function getById($catalogRuleId)
    {
        $catalogRule = $this->get($catalogRuleId);
        if (!$catalogRule->getId()) {
            throw new NoSuchEntityException(__('CatalogRule with id "%1" does not exist.', $catalogRuleId));
        }

        return $catalogRule;
    }
}
