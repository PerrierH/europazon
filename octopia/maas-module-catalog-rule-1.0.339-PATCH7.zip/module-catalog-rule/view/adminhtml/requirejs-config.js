var config = {
    map: {
        '*': {
            checkbox: 'Maas_CatalogRule/js/maas-checkbox',
        }
    }
};
