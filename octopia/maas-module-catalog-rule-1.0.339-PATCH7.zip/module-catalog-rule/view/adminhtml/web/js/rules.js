define([
    'Magento_Rule/rules'
], function (rules) {
    'use strict';

    rules.prototype.showChooserElement = function (chooser) {
        this.chooserSelectedItems = $H({});

        if (chooser.hasClassName('no-split')) {
            this.chooserSelectedItems.set(this.updateElement.value, 1);
        } else {
            var values = this.updateElement.value.split(','),
                s = '';

            for (var i = 0; i < values.length; i++) {
                s = values[i].strip();

                if (s !== '') {
                    this.chooserSelectedItems.set(s, 1);
                }
            }
        }
        new Ajax.Request(chooser.getAttribute('url'), {
            evalScripts: true,
            parameters: {
                'form_key': FORM_KEY, 'selected': this.chooserSelectedItems.keys().join(' ')
            },
            onSuccess: function (transport) {
                if (this._processSuccess(transport)) {
                    jQuery(chooser).html(transport.responseText);
                    this.showChooserLoaded(chooser, transport);
                    jQuery(chooser).trigger('contentUpdated');
                }
            }.bind(this),
            onFailure: this._processFailure.bind(this)
        });
    };

    return rules;
});
