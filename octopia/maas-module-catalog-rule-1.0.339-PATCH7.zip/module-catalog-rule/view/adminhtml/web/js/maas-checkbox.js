define(['jquery'], function ($) {
    "use strict";
    return function initCheckbox(code)
    {
        $('.rule-chooser input[type=checkbox]').click(function (event) {
            event.stopPropagation();
            var values = [];
            var inputClass = `.rule-chooser .${code} input[type=checkbox]`;
            $.each($(inputClass), function () {
                if ($(this).prop('checked')) {
                    var test = $(this).val();
                    values.push(test);
                } else {
                    values = values.filter(function (value, index, arr) {
                        return value !== $(this).val();
                    });
                }
                $(".rule-param-edit input[id^='conditions__']").val(values.join(','));
            });
        });
    }
});
