define([
    'jquery',
    'prototype',
    'extjs/ext-tree-checkbox',
    'mage/adminhtml/form'
], function (jQuery) {
    'use strict';

    let root = {};
    let data = {};
    let parameters = {};
    let propagating = false;
    let lastClickedId = null;

    // moved outside of initCategoryLoader() to reduce detected complexity

    /**
     * @param {Object} parent
     * @param {Object} config
     * @param {Integer} i
     */
    const categoryLoaderProcessCategoryTree = function (parent, config, i) {// eslint-disable-line no-shadow
        var node,
            _node = {};

        config[i].uiProvider = Ext.tree.CheckboxNodeUI;// eslint-disable-line no-undef

        _node = Object.clone(config[i]);

        if (_node.children && !_node.children.length) {
            delete _node.children;
            node = new Ext.tree.AsyncTreeNode(_node);// eslint-disable-line no-undef
        } else {
            node = new Ext.tree.TreeNode(config[i]);// eslint-disable-line no-undef
        }
        parent.appendChild(node);
        node.loader = node.getOwnerTree().loader;

        if (_node.children) {
            this.buildCategoryTree(node, _node.children);
        }
    };

    /**
     * @param {Object} parent
     * @param {Object} config
     * @returns {void}
     */
    const categoryLoaderBuildCategoryTree = function (parent, config) {// eslint-disable-line no-shadow
        var i = 0;

        if (!config) {
            return;
        }

        if (parent && config && config.length) {
            for (i; i < config.length; i++) {
                this.processCategoryTree(parent, config, i);
            }
        }
    };

    /**
     * @param {Object} attributes
     * @returns {Object}
     */
    const categoryLoaderToArray = function (attributes) {
        data = {};

        for (const key in attributes) {

            if (attributes[key]) {
                data[key] = attributes[key];
            }
        }

        return data;
    };

    /**
     * @param {Object} config
     * @returns {Object}
     */
    const categoryLoaderCreateNode = function (config) {// eslint-disable-line no-shadow
        var node;

        config.uiProvider = Ext.tree.CheckboxNodeUI;// eslint-disable-line no-undef

        if (config.children && !config.children.length) {
            delete config.children;
            node = new Ext.tree.AsyncTreeNode(config);// eslint-disable-line no-undef
        } else {
            node = new Ext.tree.TreeNode(config);// eslint-disable-line no-undef
        }

        return node;
    };

    /**
     *
     * @param {Object} hash
     * @param {Object} node
     * @returns {Object}
     */
    const categoryLoaderBuildHashChildren = function (hash, node) {// eslint-disable-line no-shadow
        var i = 0,
            len;

        // eslint-disable-next-line no-extra-parens
        if ((node.childNodes.length > 0) || (node.loaded === false && node.loading === false)) {
            hash.children = [];

            for (i, len = node.childNodes.length; i < len; i++) {
                /* eslint-disable */
                if (!hash.children) {
                    hash.children = [];
                }
                /* eslint-enable */
                hash.children.push(this.buildHash(node.childNodes[i]));
            }
        }

        return hash;
    };

    const overrideExt = function(){

        /* eslint-disable */
        /**
         * Fix ext compatibility with prototype 1.6
         */
        Ext.lib.Event.getTarget = function (e) {// eslint-disable-line no-undef
            var ee = e.browserEvent || e;

            return ee.target ? Event.element(ee) : null;
        };

        /**
         * @param {Object} el
         * @param {Object} config
         */
        Ext.tree.TreePanel.Enhanced = function (el, config) {// eslint-disable-line no-undef
            Ext.tree.TreePanel.Enhanced.superclass.constructor.call(this, el, config);// eslint-disable-line no-undef
        };

        Ext.extend(Ext.tree.TreePanel.Enhanced, Ext.tree.TreePanel, {// eslint-disable-line no-undef
            /* eslint-enable */
            /**
             * @param {Object} config
             * @param {Boolean} firstLoad
             */
            loadTree: function (config, firstLoad) {// eslint-disable-line no-shadow
                parameters = config.parameters;
                data = config.data;
                root = new Ext.tree.TreeNode(parameters);// eslint-disable-line no-undef

                if (typeof parameters.rootVisible != 'undefined') {
                    this.rootVisible = parameters.rootVisible * 1;
                }

                this.nodeHash = {};
                this.setRootNode(root);

                if (firstLoad) {
                    this.addListener('click', this.categoryClick.createDelegate(this));
                }

                this.loader.buildCategoryTree(root, data);
                this.el.dom.innerHTML = '';
                // render the tree
                this.render();
            },

            /**
             * @param {Object} node
             */
            categoryClick: function (node) {
                node.getUI().check(!node.getUI().checked());
            }
        });
    };

    const initCategoryLoader = function(config){
        var categoryLoader = new Ext.tree.TreeLoader({// eslint-disable-line no-undef
            dataUrl: config.dataUrl
        });

        /**
         * @param {Object} response
         * @param {Object} parent
         * @param {Function} callback
         */
        categoryLoader.processResponse = function (response, parent, callback) {
            config = JSON.parse(response.responseText);

            this.buildCategoryTree(parent, config);

            if (typeof callback === 'function') {
                callback(this, parent);
            }
        };

        categoryLoader.createNode = categoryLoaderCreateNode

        categoryLoader.processCategoryTree = categoryLoaderProcessCategoryTree;

        categoryLoader.buildCategoryTree = categoryLoaderBuildCategoryTree;

        categoryLoader.buildHashChildren = categoryLoaderBuildHashChildren;

        /**
         * @param {Object} node
         * @returns {Object}
         */
        categoryLoader.buildHash = function (node) {
            var hash = {};

            hash = this.toArray(node.attributes);

            return categoryLoader.buildHashChildren(hash, node);
        };

        categoryLoader.toArray = categoryLoaderToArray;

        categoryLoader.on('beforeload', function (treeLoader, node) {
            treeLoader.baseParams.id = node.attributes.id;
            treeLoader.baseParams.selected = options.jsFormObject.updateElement.value;
        });

        /* eslint-disable */
        categoryLoader.on('load', function () {
            varienWindowOnload();
        });

        return [categoryLoader, config];
    };

    const propagateClick = function(node, value)
    {
        if(lastClickedId === node.id)
        {
            return;
        }
        var ui = node.getUI();
        if(ui !== undefined)
        {
            if(ui.checked() !== value)
            {
                ui.check(value, true, false);
            }
        }
        for(let i=0;i < node.childNodes.length; i++)
        {
            propagateClick(node.childNodes[i], value);
        }
        lastClickedId = node.id;
    };

    const handlePropagatedClick = function(node, config, options){
        if (propagating)
        {
            varienElementMethods.setHasChanges(node.getUI().checkbox);
            propagateClick(node, node.getUI().checked());
        }
        else
        {
            propagating = true;
            jQuery('#'+config.divId).loader("show");
            setTimeout(function() {
                return function (node) {
                    varienElementMethods.setHasChanges(node.getUI().checkbox);
                    lastClickedId = -1;
                    propagateClick(node, node.getUI().checked());
                    jQuery('#'+config.divId).loader("hide");
                    propagating = false;
                    options.jsFormObject.updateElement.value = this.getChecked().join(', ');
                }.bind(this)(node);
            }.bind(this), 5);
        }
    };

    return function (config) {

        jQuery('#'+config.divId).loader();

        var tree,
            options = {
                dataUrl: config.dataUrl,
                divId: config.divId,
                rootVisible: config.rootVisible,
                useAjax: config.useAjax,
                currentNodeId: config.currentNodeId,
                jsFormObject: window[config.jsFormObject],
                name: config.name,
                checked: config.checked,
                allowDrop: config.allowDrop,
                rootId: config.rootId,
                expanded: config.expanded,
                categoryId: config.categoryId,
                treeJson: config.treeJson
            };

        overrideExt();

        jQuery(function () {
            var initResult = initCategoryLoader(config);
            const categoryLoader = initResult[0];
            config = initResult[1];

            tree = new Ext.tree.TreePanel.Enhanced(options.divId, {
                animate: false,
                loader: categoryLoader,
                enableDD: false,
                containerScroll: true,
                selModel: new Ext.tree.CheckNodeMultiSelectionModel(),
                rootVisible: options.rootVisible,
                useAjax: options.useAjax,
                currentNodeId: options.currentNodeId,
                addNodeTo: false,
                rootUIProvider: Ext.tree.CheckboxNodeUI
            });
            tree.on('check', function (node) {
                handlePropagatedClick.bind(tree)(node, config, options);
            }, tree);
            // set the root node
            //jscs:disable requireCamelCaseOrUpperCaseIdentifiers
            parameters = {
                text: options.name,
                draggable: false,
                checked: options.checked,
                uiProvider: Ext.tree.CheckboxNodeUI,
                allowDrop: options.allowDrop,
                id: options.rootId,
                expanded: options.expanded,
                category_id: options.categoryId
            };
            //jscs:enable requireCamelCaseOrUpperCaseIdentifiers
            tree.loadTree({
                parameters: parameters, data: options.treeJson
            }, true);
            /* eslint-enable */
        });
    };
});
