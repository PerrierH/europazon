<?php

namespace Maas\CatalogRule\Api;

use Maas\CatalogRule\Api\Data\CatalogRuleInterface;
use Maas\CatalogRule\Api\Data\CatalogRuleSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Interface CatalogRuleRepositoryInterface
 *
 * @package Maas\CatalogRule\Api
 */
interface CatalogRuleRepositoryInterface
{
    /**
     * Save CatalogRule
     *
     * @param CatalogRuleInterface $catalogRule
     *
     * @return CatalogRuleInterface
     * @throws CouldNotSaveException
     */
    public function save(CatalogRuleInterface $catalogRule);

    /**
     * Get CatalogRule by id.
     *
     * @param int $catalogRuleId
     *
     * @return CatalogRuleInterface
     * @throws NoSuchEntityException
     */
    public function getById($catalogRuleId);

    /**
     * Find CatalogRule by id.
     *
     * @param int $catalogRuleId
     *
     * @return CatalogRuleInterface|null
     */
    public function findById($catalogRuleId);

    /**
     * Retrieve CatalogRule matching the specified criteria.
     *
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return CatalogRuleSearchResultsInterface
     * @throws LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * Delete CatalogRule
     *
     * @param CatalogRuleInterface $catalogRule
     *
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(CatalogRuleInterface $catalogRule);

    /**
     * Delete CatalogRule by ID.
     *
     * @param int $catalogRuleId
     *
     * @return bool
     * @throws NoSuchEntityException
     * @throws CouldNotDeleteException
     */
    public function deleteById($catalogRuleId);
}
