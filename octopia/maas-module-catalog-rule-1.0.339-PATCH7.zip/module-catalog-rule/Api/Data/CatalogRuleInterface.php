<?php

namespace Maas\CatalogRule\Api\Data;

use Maas\CatalogRule\Model\CatalogRule;
use Maas\Log\Model\Report;

/**
 * Interface CatalogRule
 *
 * @package Maas\CatalogRule\Api\Data
 */
interface CatalogRuleInterface
{
    /**
     * Constants for keys of data array.
     */
    const RULE_ID = 'rule_id';
    const NAME = 'name';
    const DESCRIPTION = 'description';
    const STATUS = 'status';
    const PRIORITY = 'priority';
    const LAST_EXECUTION_DATE = 'last_execution_date';
    const CATEGORY_IDS = 'category_ids';

    /**
     * Constant for catalog rule logger
     */

    public const MAAS_LOG_ACTION = 'Apply_Catalog_Rule';

    public const MAAS_LOG_MODULE = 'Maas_CatalogRule';

    public const MAAS_LOG_OPERATION_TYPE = 'apply rule';

    public const CSV_LOG_HEADERS = ['rule_id', 'operation', 'sku', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'catalog-rule';

    /**
     * Get RuleId value
     *
     * @return string
     */
    public function getRuleId();

    /**
     * Set RuleId value
     *
     * @param string $value
     *
     * @return $this
     */
    public function setRuleId($value);

    /**
     * Get Rule value
     *
     * @return string
     */
    public function getName();

    /**
     * Set Rule value
     *
     * @param string $value
     *
     * @return $this
     */
    public function setName($value);

    /**
     * Get Description value
     *
     * @return string
     */
    public function getDescription();

    /**
     * Set Description value
     *
     * @param string $value
     *
     * @return $this
     */
    public function setDescription($value);

    /**
     * Get Status value
     *
     * @return int
     */
    public function getStatus();

    /**
     * Set Status value
     *
     * @param int $value
     *
     * @return $this
     */
    public function setStatus($value);

    /**
     * Get Priority value
     *
     * @return string
     */
    public function getPriority();

    /**
     * Set Priority value
     *
     * @param string $value
     *
     * @return $this
     */
    public function setPriority($value);

    /**
     * Get LastExecutionDate value
     *
     * @return string
     */
    public function getLastExecutionDate();

    /**
     * set category ids
     *
     * @param $value
     * @return $this
     */
    public function setCategoryIds($value);

    /**
     * get category ids
     *
     * @return string
     */
    public function getCategoryIds();

    /**
     * Set LastExecutionDate value
     *
     * @param string $value
     *
     * @return $this
     */
    public function setLastExecutionDate($value);
}
