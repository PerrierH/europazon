<?php

namespace Maas\CatalogRule\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface CatalogRuleSearchResultsInterface
 *
 * @package Maas\CatalogRule\Api\Data
 */
interface CatalogRuleSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get CatalogRule list.
     *
     * @return CatalogRuleInterface[]
     */
    public function getItems();

    /**
     * Set CatalogRule list.
     *
     * @param CatalogRuleInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
