<?php

namespace Maas\CatalogRule\Block\Adminhtml\Edit;

use Maas\CatalogRule\Api\CatalogRuleRepositoryInterface;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Exception\NoSuchEntityException;

class GenericButton
{
    /**
     * @var CatalogRuleRepositoryInterface
     */
    private $catalogRuleRepository;
    /**
     * @var Context
     */
    private $context;

    /**
     * Constructor
     *
     * @param Context $context
     * @param CatalogRuleRepositoryInterface $catalogRuleRepository
     */
    public function __construct(
        Context $context,
        CatalogRuleRepositoryInterface $catalogRuleRepository
    ) {
        $this->context = $context;
        $this->catalogRuleRepository = $catalogRuleRepository;
    }

    /**
     * Return the current Catalog Rule Id.
     *
     * @return int|null
     */
    public function getRuleId()
    {
        try {
            return $this->catalogRuleRepository->getById(
                $this->context->getRequest()->getParam('id')
            )->getRuleId();
        } catch (NoSuchEntityException $e) {
            // do nothing
        }
        return null;
    }

    /**
     * Generate url by route and parameters
     *
     * @param string $route
     * @param array $params
     *
     * @return  string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }
}
