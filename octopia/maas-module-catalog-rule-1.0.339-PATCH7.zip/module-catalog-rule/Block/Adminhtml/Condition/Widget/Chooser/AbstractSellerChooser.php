<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

use Maas\Seller\Api\SellerRepositoryInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class SellerId
 * @package Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser
 */
class AbstractSellerChooser extends AbstractChooser
{
    /** @var string */
    protected $attributeCode;
    /**
     * @var SellerRepositoryInterface
     */
    private $sellerRepository;
    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /** @var string */
    protected $valueAttribute;

    /** @var string */
    protected $labelAttribute;

    /**
     * Seller constructor.
     *
     * @param Context $context
     * @param AttributeRepositoryInterface $attributeRepository
     * @param SellerRepositoryInterface $sellerRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param array $data
     */
    public function __construct(
        Context $context,
        AttributeRepositoryInterface $attributeRepository,
        SellerRepositoryInterface $sellerRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        array $data = []
    ) {
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->sellerRepository = $sellerRepository;
        parent::__construct($context, $attributeRepository, $data);
    }

    /**
     * @return array|AttributeOptionInterface[]|null
     */
    public function getAttributes()
    {
        $attributesValues = [];
        $sellerSearchResults = $this->sellerRepository->getList($this->searchCriteriaBuilder->create());
        if (!empty($sellerSearchResults)) {
            foreach ($sellerSearchResults->getItems() as $seller) {
                $attributesValues[] =
                    [
                        'value' => $seller->getData($this->valueAttribute),
                        'label' => $seller->getData($this->labelAttribute)
                    ];
            }
        }
        $attributesValues['attributeCode'] = $this->attributeCode;
        return $attributesValues;
    }
}
