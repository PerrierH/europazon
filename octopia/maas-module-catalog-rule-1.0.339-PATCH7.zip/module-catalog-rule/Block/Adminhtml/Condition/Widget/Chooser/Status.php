<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

class Status extends AbstractChooser
{
    protected $attributeCode = 'status';
}
