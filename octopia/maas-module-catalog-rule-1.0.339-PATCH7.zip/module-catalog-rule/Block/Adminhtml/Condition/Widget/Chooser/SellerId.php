<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

use Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser\AbstractSellerChooser;

/**
 * Class SellerId
 * @package Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser
 */
class SellerId extends AbstractSellerChooser
{
    protected $attributeCode = 'maas_offer_seller_id';
    protected $valueAttribute = 'id';
    protected $labelAttribute = 'name';
}
