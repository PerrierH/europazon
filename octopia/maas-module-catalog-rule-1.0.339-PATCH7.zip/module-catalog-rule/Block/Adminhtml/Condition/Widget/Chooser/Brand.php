<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

use Maas\CatalogRule\Model\BrandAttributeRepository;
use Magento\Backend\Block\Template\Context;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class Brand extends AbstractChooser
{
    protected $attributeCode = 'maas_brand';
    /**
     * @var BrandAttributeRepository
     */
    private $brandNames;


    /**
     * Brand constructor.
     *
     * @param Context $context
     * @param AttributeRepositoryInterface $attributeRepository
     * @param BrandAttributeRepository $brandNames
     * @param array $data
     */
    public function __construct(
        Context $context,
        AttributeRepositoryInterface $attributeRepository,
        BrandAttributeRepository $brandNames,
        array $data = []
    ) {
        $this->brandNames = $brandNames;
        parent::__construct($context, $attributeRepository, $data);
    }

    /**
     * @return array|AttributeOptionInterface[]|null
     * @throws NoSuchEntityException
     */
    public function getAttributes()
    {
        $attributesValues = [];
        $attributes = $this->brandNames->getBrandNames();
        if (!empty($attributes)) {
            foreach ($attributes as $attribute) {
                $attributesValues[] =
                    [
                        'value' => $attribute->getMaasBrand(),
                        'label' => $attribute->getMaasBrand(),

                    ];
            }
        }
        $attributesValues['attributeCode'] = $this->attributeCode;
        return $attributesValues;
    }
}
