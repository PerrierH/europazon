<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

use Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser\AbstractSellerChooser;

/**
 * Class SellerName
 * @package Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser
 */
class SellerName extends AbstractSellerChooser
{
    protected $attributeCode = 'maas_offer_seller_name';
    protected $valueAttribute = 'id';
    protected $labelAttribute = 'name';
}
