<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

/**
 * Class Visibility
 * Ignore because we already test status wich is the same test with different attribute code
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser
 */
class Visibility extends AbstractChooser
{
    protected $attributeCode = 'visibility';
}
