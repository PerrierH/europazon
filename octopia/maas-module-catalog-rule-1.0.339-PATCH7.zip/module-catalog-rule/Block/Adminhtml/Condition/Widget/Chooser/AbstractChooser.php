<?php

namespace Maas\CatalogRule\Block\Adminhtml\Condition\Widget\Chooser;

use Magento\Backend\Block\Template;
use Magento\Catalog\Model\Product;
use Magento\Backend\Block\Template\Context;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use Magento\Framework\Exception\NoSuchEntityException;

abstract class AbstractChooser extends Template
{
    protected $attributeCode = '';

    /**
     * @var AttributeRepositoryInterface
     */
    protected $attributeRepository;

    /**
     * Status constructor.
     *
     * @param Context $context
     * @param AttributeRepositoryInterface $attributeRepository
     * @param array $data
     */
    public function __construct(
        Context $context,
        AttributeRepositoryInterface $attributeRepository,
        array $data = []
    ) {
        $this->attributeRepository = $attributeRepository;
        parent::__construct($context, $data);
    }

    /**
     * @codeCoverageIgnore
     * @return void
     */
    protected function _prepareLayout()
    {
        $this->setTemplate('Maas_CatalogRule::widget/checkbox.phtml');
    }

    /**
     * @return AttributeOptionInterface[]|null
     * @throws NoSuchEntityException
     */
    public function getAttributes()
    {
        $attributesLabelCode = [];
        $attributes = $this->attributeRepository->get(Product::ENTITY, $this->attributeCode)->getOptions();
        if (!empty($attributes)) {
            foreach ($attributes as $attribute) {
                $attributesLabelCode [] =
                    [
                        'value' => $attribute->getValue(),
                        'label' => $attribute->getLabel(),

                    ];
            }
        }
        $attributesLabelCode['attributeCode'] = $this->attributeCode;
        return $attributesLabelCode;
    }
}
