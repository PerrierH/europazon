<?php
namespace Maas\CatalogRule\Block\Adminhtml;

use Magento\Backend\Block\Widget\Grid\Container;
use Maas\CatalogRule\Model\Service\IsApplying;
use \Magento\Backend\Block\Widget\Context;

/**
 * Class Rules
 * @codeCoverageIgnore
 * @package Maas\CatalogRule\Block\Adminhtml
 */
class Rules extends Container
{
    /** @var IsApplying  */
    private $isApplying;

    public function __construct(
        Context $context,
        IsApplying $isApplying,
        array $data = []
    ){
        $this->isApplying = $isApplying;

        parent::__construct($context, $data);
    }

    /**
     * @return void
     */
    protected function _construct(){
        $this->_blockGroup = 'Maas_CatalogRule';
        $this->_controller = 'adminhtml_rules';
        $this->_headerText = __('Commercial categorization');
        $buttonData = [
            'label' => __('Apply Rules'),
            'onclick' => 'setLocation(\'' . $this->getUrl('maascatalog/*/apply') . '\')',
        ];
        if($this->isApplying->execute()){
            $buttonData['disabled'] = ['disabled'];
        }
        $this->addButton('apply', $buttonData);
        $this->_addButtonLabel = __('Add New Rule');
        parent::_construct();
    }
}
