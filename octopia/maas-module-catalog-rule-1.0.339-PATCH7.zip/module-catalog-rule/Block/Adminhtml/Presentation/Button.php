<?php

namespace Maas\CatalogRule\Block\Adminhtml\Presentation;

use Maas\Core\Block\Adminhtml\Presentation\Buttons;

/**
 * Class Button
 * @codeCoverageIgnore
 * @package Maas\Log\Block\Adminhtml\Presentation
 */
class Button extends Buttons
{
    /**
     * Generate synchronize button html
     *
     * @return string
     */
    public function getButton()
    {
        $data = [
            'class' => self::CLASS_CSS,
            'href' => $this->getUrl('maascatalog/rule'),
            'title' => __('Commercial categorization')
        ];

        return $this->getButtonHtml($data);
    }
}
