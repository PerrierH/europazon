<?php

namespace Maas\CatalogRule\Block\Adminhtml\Category\Checkboxes;

use Magento\Catalog\Block\Adminhtml\Category\Checkboxes\Tree as DefaultTree;
use Magento\Framework\Data\Tree\Node;

/**
 * Class Tree
 *
 * @package Maas\CatalogRule\Block\Adminhtml\Category\Checkboxes
 */
class Tree extends DefaultTree
{
    /**
     * @return void
     */
    protected function _prepareLayout()
    {
        $this->setTemplate('Maas_CatalogRule::catalog/category/checkboxes/tree.phtml');
    }

    /**
     * @param null $parenNodeCategory
     *
     * @return string
     */
    public function getTreeJson($parenNodeCategory = null)
    {
        $catId = $this->getMaasRootCategory();
        $tree = $this->_categoryTree->load($catId, 2);
        $tree->addCollectionData($this->getCategoryCollection());

        $root = $tree->getNodeById($catId);
        $root->loadChildren(2);
        $result = $this->_getNodeJson($root);
        $result = $this->filterJson($result);

        return $this->_jsonEncoder->encode(isset($result['children']) ? $result['children'] : []);
    }

    /**
     * Oveerriden with a plugin so that the constructor is not affected
     *
     * @return string
     */
    public function getMaasRootCategory()
    {
        return $this->_scopeConfig->getValue(\Maas\Catalog\Model\Config::XML_PATH_MAAS_CATEGORY);
    }

    /**
     * Remove categories with level > 2 from the JSON result.
     *
     * @param array $jsonData
     *
     * @return array
     */
    protected function filterJson($jsonData)
    {
        $jsonData['children'] = $this->filterJsonRecursive($jsonData['children'] ?? [], 0);
        return $jsonData;
    }

    /**
     * @param array $jsonDataArray
     * @param int $level
     *
     * @return array
     */
    protected function filterJsonRecursive($jsonDataArray, $level)
    {
        if($level >= 2)
        {
            return [];
        }
        foreach($jsonDataArray as $index => $child)
        {
            if(isset($jsonDataArray[$index]['children']))
            {
                $children = $this->filterJsonRecursive($jsonDataArray[$index]['children'], $level + 1);
                if($children)
                {
                    $jsonDataArray[$index]['children'] = $children;
                }
                else
                {
                    unset($jsonDataArray[$index]['children']);
                }
            }
        }
        return $jsonDataArray;
    }
}