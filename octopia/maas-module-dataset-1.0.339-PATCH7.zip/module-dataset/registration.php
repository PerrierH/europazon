<?php

use Magento\Framework\Component\ComponentRegistrar;

/**
 * @codeCoverageIgnore
 */
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Maas_DataSet', __DIR__);
