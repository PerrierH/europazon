<?php

namespace Maas\DataSet\Block\Adminhtml;

use Exception;
use Maas\DataSet\Model\Service\DataSetType;
use Magento\Framework\View\Element\Template;
use Magento\Framework\Url;
use Magento\Framework\UrlInterface;

/**
 * Class Dataset
 *
 * @package Maas\DataSet\Block\Adminhtml
 * @codeCoverageIgnore
 */
class DataSet extends Template
{
    public const TYPE_FULL = 'full';
    public const TYPE_CATEGORIES = 'categories';

    /** @var string  */
    protected $_template = "Maas_DataSet::dataset.phtml";

    /** @var string */
    public $dataset;

    /** @var UrlInterface */
    public $url;

    /** @var Url */
    public $frontUrl;

    /**
     * @var \Maas\DataSet\Model\Service\DataSetType
     */
    protected $dataSetType;

    /**
     * DataSet constructor.
     *
     * @param Template\Context $context
     * @param Url $url
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Url $frontUrl,
        UrlInterface $url,
        \Maas\DataSet\Model\Service\DataSetType $dataSetType,
        $data = []
    ) {
        $this->dataset = $data;
        $this->url = $url;
        $this->frontUrl = $frontUrl;
        $this->dataSetType = $dataSetType;
        parent::__construct($context, $data);
    }

    public function getRunUrl(){
        return $this->url->getUrl('maasdataset/run/full', ['dataset' => $this->dataset['basename']]);
    }

    public function getFileUrl($file){
        return $this->url->getUrl('maasdataset/listing/download', ['dataset' => $this->dataset['basename'], 'file'=>$file]);
    }

    public function getCategoriesUrl(){
        return $this->url->getUrl('maasdataset/run/categories', ['dataset' => $this->dataset['basename']]);
    }

    public function getDatasetType() {
        $result = $this->dataSetType->execute($this->dataset['filename']);
        if(isset($result['type']))
        {
            $this->dataset['files'] = $result;
            return $result['type'];
        }
        return DataSetType::TYPE_FULL;
    }
}
