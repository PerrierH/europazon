require(
    [
        'Magento_Ui/js/lib/validation/validator',
        'jquery',
        'mage/translate'
    ], function (validator, $) {
        validator.addRule(
            'required-upload',
            function (value, element) {
               var file = $('input[name="general['+element+']"]').val();
                return file !== '';
            }
            , $.mage.__('This field is required.')
        );
        validator.addRule(
            'extension-upload',
            function (value, element) {
                var file = $('input[name="general['+element+']"]').val();
                var fileExtension = file.split('.').pop();
                return !(file !== '' && fileExtension !== 'json');
            }
            , $.mage.__('This file is not valid (must be in json format).')
        );
    });
