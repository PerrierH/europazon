<?php

namespace Maas\DataSet\Test\Unit\Model\Process;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\DataSet\Exception\StopException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;

use Maas\DataSet\Model\Process\Products;
use Maas\ImportExport\Exception\OperationAlreadyLaunch;
use Maas\DatabaseImport\Model\Import\Consumer\Product as Consumer;
use Maas\ImportExport\Model\Import\Catalog\Product\MessageBuilder;
use Maas\ImportExport\Model\Import\Catalog\Product\Data\Product;
use Maas\ImportExport\Api\Data\Catalog\ProductInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Serialize\Serializer\Json;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ReportRepository;
use \Exception;

class ProductsTest extends AbstractTestCase
{

    /** @var Products */
    private $instance;

    /** @var array */
    private $logs = [];

    private $fileContent = [];
    private $alreadyLaunchException = false;
    private $readFileException = false;
    private $lowLevelException = false;

    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->fileContent = [
            [
                'id' => 42
            ]
        ];
        $this->alreadyLaunchException = false;
        $this->readFileException = false;

        $consumerMock = AnyBuilder::createForClass(
            $this,
            Consumer::class,
            [
                'process' => [
                    $this->any(),
                    function () {
                        if ($this->alreadyLaunchException) {
                            throw new OperationAlreadyLaunch('OperationAlreadyLaunch Exception');
                        }
                        if ($this->lowLevelException) {
                            throw new Exception('Generic Exception');
                        }
                        return true;
                    },
                    self::RETURN_CALLBACK
                ]
            ]
        )->build();

        $serializer = $this->objectManager->getObject(Json::class);
        $dataObjectHelper = AnyBuilder::createForClass(
            $this,
            DataObjectHelper::class,
            [
                'populateWithArray' => [$this->any(), true]
            ]
        )->build();
        $report = AnyBuilder::createForClass(
            $this,
            Report::class,
            [

            ]
        )->build();
        $reportFactory = AnyBuilder::createForClass(
            $this,
            ReportFactory::class,
            [
                'create' => [$this->any(), $report]
            ]
        )->build();
        $reportRepository = AnyBuilder::createForClass(
            $this,
            ReportRepository::class,
            [
                'generateLogReport' => [$this->any(), $report],
                'save' => [$this->any(), true]
            ]
        )->build();
        $product = AnyBuilder::createForClass($this, Product::class)->build();
        $productInterfaceFactory = AnyBuilder::createForClass(
            $this,
            ProductInterfaceFactory::class,
            [
                'create' => [$this->any(), $product]
            ]
        )->build();
        $messageBuilder = AnyBuilder::createForClass(
            $this,
            MessageBuilder::class,
            [
                'build' => [$this->any(), true]
            ]
        )->build();

        $this->instance = AnyBuilder::createForClass(
            $this,
            Products::class,
            [
                'readFile' => [
                    $this->any(),
                    function(){
                        if($this->readFileException){
                            throw new Exception('readFile Exception');
                        }
                        return $this->fileContent;
                    },
                    self::RETURN_CALLBACK
                ]
            ]
        )->setConstructorArgs(
            [
                'serializerInterface' => $serializer,
                'dataObjectHelper' => $dataObjectHelper,
                'reportRepository' => $reportRepository,
                'reportFactory' => $reportFactory,
                'productImporter' => $consumerMock,
                'productInterfaceFactory' => $productInterfaceFactory,
                'messageBuilder' => $messageBuilder
            ]
        )->build();
    }

    public function testExecute()
    {
        $expected = [
            '<br />&bull; Processing products.json',
            '<br />&nbsp; - Reading file... ',
            'Ok',
            '<br />&nbsp; - Preparing data... ',
            'Ok',
            '<br />'.count($this->fileContent).' products',
            '<br />&nbsp; - Preparing report... ',
            'Ok',
            '<br />&nbsp; - Importing data... ',
            ''
        ];

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        $this->instance->execute('');
        ob_end_clean();

        $this->assertEquals($expected, $this->logs);
    }

    public function testExecuteNoItems()
    {
        $this->expectException(StopException::class);

        $this->fileContent = null;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    public function testExecuteExceptionReadFile()
    {
        $this->expectException(StopException::class);

        $this->readFileException = true;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    public function testExecuteLowLevelException()
    {
        $this->expectException(StopException::class);

        $this->lowLevelException = true;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }
}