<?php

namespace Maas\DataSet\Test\Unit\Model\Process;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\DataSet\Exception\StopException;
use Maas\DataSet\Model\Process\AbstractProcess;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;

use Maas\DataSet\Model\Process\Categories;
use Maas\ImportExport\Exception\OperationAlreadyLaunch;
use Maas\ImportExport\Model\Import\Catalog\Category;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Serialize\Serializer\Json;
use \Exception;

class AbstractProcessTest extends AbstractTestCase
{
    public function testLogWithoutException()
    {
        $outputBuffer = [];

        $instance = $this->getMockForAbstractClass(AbstractProcess::class, [], '', false, true,  true, ['readFile', 'log'], false);

        $reflection = new \ReflectionClass(AbstractProcess::class);
        $method = $reflection->getMethod('readFile');
        $method->setAccessible(true);

        $instance->expects($this->once())->method('readFile')->willThrowException(new \Exception('test'));
        $instance->expects($this->any())->method('log')->willReturnCallback(function($message, $br, $stop) use(&$outputBuffer) {
            $outputBuffer[] = $message;
        });

        $data = $instance->parseFile(null);
    }
}
