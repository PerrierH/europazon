<?php

namespace Maas\DataSet\Test\Unit\Model\Process;

use Maas\DataSet\Exception\StopException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;

use Maas\DataSet\Model\Process\Sellers;
use Maas\ImportExport\Exception\OperationAlreadyLaunch;
use Maas\ImportExport\Model\Import\Seller\Seller;
use Maas\ImportExport\Model\Import\Seller\Consumer as SellerConsumer;
use Maas\ImportExport\Model\Import\Seller\MessageBuilder as SellerMessageBuilder;
use Maas\ImportExport\Api\Data\Seller\SellerInterface;
use Maas\ImportExport\Api\Data\Seller\SellerInterfaceFactory;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Serialize\Serializer\Json;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ReportRepository;
use \Exception;

class SellersTest extends TestCase
{

    /**
     * @var ObjectManager
     */
    private $objectManager;

    /** @var Sellers */
    private $instance;

    /** @var array */
    private $logs = [];

    private $fileContent = [];
    private $readFileException = false;
    private $lowLevelException = false;

    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->fileContent = [
            [
                'sellerId' => 42,
                'isFulfillment' => 'false'
            ]
        ];
        $this->readFileException = false;
        $this->lowLevelException = false;

        $serializer = $this->objectManager->getObject(Json::class);
        $dataObjectHelper = AnyBuilder::createForClass(
            $this,
            DataObjectHelper::class,
            [
                'populateWithArray' => [$this->any(), true]
            ]
        )->build();
        $report = AnyBuilder::createForClass(
            $this,
            Report::class,
            [

            ]
        )->build();
        $reportFactory = AnyBuilder::createForClass(
            $this,
            ReportFactory::class,
            [
                'create' => [$this->any(), $report]
            ]
        )->build();
        $reportRepository = AnyBuilder::createForClass(
            $this,
            ReportRepository::class,
            [
                'generateLogReport' => [$this->any(), $report],
                'save' => [$this->any(), true]
            ]
        )->build();

        $sellerImporter = AnyBuilder::createForClass(
            $this,
            SellerConsumer::class,
            [
                'process' => [
                    $this->any(),
                    function () {
                        if($this->lowLevelException)
                        {
                            throw new \Exception('Low level exception');
                        }
                        return true;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $seller = AnyBuilder::createForClass($this, Seller::class, [
            'setIsFulfillment' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $sellerInterfaceFactory = AnyBuilder::createForClass(
            $this,
            SellerInterfaceFactory::class,
            [
                'create' => [$this->any(), $seller]
            ]
        )->build();
        $sellerMessageBuilder = AnyBuilder::createForClass(
            $this,
            SellerMessageBuilder::class,
            [
                'build' => [$this->any(), true]
            ]
        )->build();

        $this->instance = AnyBuilder::createForClass(
            $this,
            Sellers::class,
            [
                'readFile' => [
                    $this->any(),
                    function () {
                        if ($this->readFileException) {
                            throw new Exception('readFile Exception');
                        }
                        return $this->fileContent;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->setConstructorArgs(
            [
                'serializerInterface' => $serializer,
                'dataObjectHelper' => $dataObjectHelper,
                'reportRepository' => $reportRepository,
                'reportFactory' => $reportFactory,
                'sellerImporter' => $sellerImporter,
                'sellerInterfaceFactory' => $sellerInterfaceFactory,
                'messageBuilder' => $sellerMessageBuilder
            ]
        )->build();
    }

    public function testExecute()
    {
        $expected = [
            '<br />&bull; Processing sellers.json',
            '<br />&nbsp; - Reading file... ',
            'Ok',
            '<br />&nbsp; - Preparing data... ',
            'Ok',
            '<br />&nbsp; - '.count($this->fileContent).' sellers',
            '<br />&nbsp; - Preparing report... ',
            'Ok',
            '<br />&nbsp; - Importing data... ',
            ''
        ];

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });

        $this->instance->execute('');
        ob_end_clean();

        $this->assertEquals($expected, $this->logs);
    }

    public function testExecuteNoItems()
    {
        $this->expectException(StopException::class);

        $this->fileContent = null;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    public function testExecuteExceptionReadFile()
    {
        $this->expectException(StopException::class);

        $this->readFileException = true;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    public function testExecuteLowLevelException()
    {
        $this->expectException(StopException::class);

        $this->lowLevelException = true;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }
}