<?php

namespace Maas\DataSet\Test\Unit\Model\Process;

use Maas\DataSet\Exception\StopException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;

use Maas\DataSet\Model\Process\Offers;
use Maas\ImportExport\Exception\OperationAlreadyLaunch;
use Maas\ImportExport\Model\Import\Offer\Offer;
use Maas\ImportExport\Model\Import\Offer\Consumer as OfferConsumer;
use Maas\ImportExport\Model\Import\Offer\MessageBuilder as OfferMessageBuilder;
use Maas\ImportExport\Api\Data\Offer\OfferInterface;
use Maas\ImportExport\Api\Data\Offer\OfferInterfaceFactory;

use Maas\ImportExport\Model\Import\Price\Price;
use Maas\ImportExport\Model\Import\Price\Consumer as PriceConsumer;
use Maas\ImportExport\Model\Import\Price\MessageBuilder as PriceMessageBuilder;
use Maas\ImportExport\Api\Data\Offer\Price\PriceInterface;
use Maas\ImportExport\Api\Data\Offer\Price\PriceInterfaceFactory;

use Maas\ImportExport\Model\Import\Inventory\Inventory;
use Maas\ImportExport\Model\Import\Inventory\Consumer as InventoryConsumer;
use Maas\ImportExport\Model\Import\Inventory\MessageBuilder as InventoryMessageBuilder;
use Maas\ImportExport\Api\Data\Inventory\InventoryInterface;
use Maas\ImportExport\Api\Data\Inventory\InventoryInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Serialize\Serializer\Json;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ReportRepository;
use \Exception;

class OffersTest extends TestCase
{

    /**
     * @var ObjectManager
     */
    private $objectManager;

    /** @var Offers */
    private $instance;

    /** @var array */
    private $logs = [];

    private $fileContent = [];
    private $readFileException = false;
    private $lowLevelException = false;

    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->fileContent = [
            [
                'offerId' => 42,
                'price' => [
                    'value' => 27
                ],
                'inventory' => [
                    'stock' => 50
                ]
            ]
        ];
        $this->readFileException = false;
        $this->lowLevelException = false;

        $serializer = $this->objectManager->getObject(Json::class);
        $dataObjectHelper = AnyBuilder::createForClass(
            $this,
            DataObjectHelper::class,
            [
                'populateWithArray' => [$this->any(), true]
            ]
        )->build();
        $report = AnyBuilder::createForClass(
            $this,
            Report::class,
            [

            ]
        )->build();
        $reportFactory = AnyBuilder::createForClass(
            $this,
            ReportFactory::class,
            [
                'create' => [$this->any(), $report]
            ]
        )->build();
        $reportRepository = AnyBuilder::createForClass(
            $this,
            ReportRepository::class,
            [
                'generateLogReport' => [$this->any(), $report],
                'save' => [$this->any(), true]
            ]
        )->build();

        $offerImporter = AnyBuilder::createForClass(
            $this,
            OfferConsumer::class,
            [
                'process' => [
                    $this->any(),
                    function () {
                        if($this->lowLevelException)
                        {
                            throw new \Exception('Low level exception');
                        }
                        return true;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $offer = AnyBuilder::createForClass($this, Offer::class)->build();
        $offerInterfaceFactory = AnyBuilder::createForClass(
            $this,
            OfferInterfaceFactory::class,
            [
                'create' => [$this->any(), $offer]
            ]
        )->build();
        $offerMessageBuilder = AnyBuilder::createForClass(
            $this,
            OfferMessageBuilder::class,
            [
                'build' => [$this->any(), true]
            ]
        )->build();

        $priceImporter = AnyBuilder::createForClass(
            $this,
            PriceConsumer::class,
            [
                'process' => [
                    $this->any(),
                    function () {
                        return true;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $price = AnyBuilder::createForClass($this, Price::class)->build();
        $priceInterfaceFactory = AnyBuilder::createForClass(
            $this,
            PriceInterfaceFactory::class,
            [
                'create' => [$this->any(), $price]
            ]
        )->build();
        $priceMessageBuilder = AnyBuilder::createForClass(
            $this,
            PriceMessageBuilder::class,
            [
                'build' => [$this->any(), true]
            ]
        )->build();

        $inventoryImporter = AnyBuilder::createForClass(
            $this,
            InventoryConsumer::class,
            [
                'process' => [
                    $this->any(),
                    function () {
                        return true;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $inventory = AnyBuilder::createForClass($this, Inventory::class)->build();
        $inventoryInterfaceFactory = AnyBuilder::createForClass(
            $this,
            InventoryInterfaceFactory::class,
            [
                'create' => [$this->any(), $inventory]
            ]
        )->build();
        $inventoryMessageBuilder = AnyBuilder::createForClass(
            $this,
            InventoryMessageBuilder::class,
            [
                'build' => [$this->any(), true]
            ]
        )->build();

        $this->instance = AnyBuilder::createForClass(
            $this,
            Offers::class,
            [
                'readFile' => [
                    $this->any(),
                    function () {
                        if ($this->readFileException) {
                            throw new Exception('readFile Exception');
                        }
                        return $this->fileContent;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->setConstructorArgs(
            [
                'serializerInterface' => $serializer,
                'dataObjectHelper' => $dataObjectHelper,
                'reportRepository' => $reportRepository,
                'reportFactory' => $reportFactory,
                'offerImporter' => $offerImporter,
                'offerInterfaceFactory' => $offerInterfaceFactory,
                'offerMessageBuilder' => $offerMessageBuilder,
                'priceImporter' => $priceImporter,
                'priceInterfaceFactory' => $priceInterfaceFactory,
                'priceMessageBuilder' => $priceMessageBuilder,
                'inventoryImporter' => $inventoryImporter,
                'inventoryInterfaceFactory' => $inventoryInterfaceFactory,
                'inventoryMessageBuilder' => $inventoryMessageBuilder
            ]
        )->build();
    }

    public function testExecute()
    {
        $expected = [
            '<br />&bull; Processing offers.json',
            '<br />&nbsp; - Reading file... ',
            'Ok',
            '<br />&nbsp; - Preparing data... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;-&nbsp;'.count($this->fileContent).' offers',
            '<br />&nbsp;&nbsp;&nbsp;-&nbsp;'.count($this->fileContent).' prices',
            '<br />&nbsp;&nbsp;&nbsp;-&nbsp;'.count($this->fileContent).' inventories',
            '<br />&nbsp; - Offers import',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Preparing data... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Preparing report... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Importing data... ',
            '<br />&nbsp; - Prices import',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Preparing data... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Preparing report... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Importing data... ',
            '<br />&nbsp; - Inventories import',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Preparing data... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Preparing report... ',
            'Ok',
            '<br />&nbsp;&nbsp;&nbsp;&nbsp;- Importing data... ',
            ''
        ];

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        $this->instance->execute('');
        ob_end_clean();

        $this->assertEquals($expected, $this->logs);
    }

    public function testExecuteNoItems()
    {
        $this->expectException(StopException::class);

        $this->fileContent = null;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    public function testExecuteExceptionReadFile()
    {
        $this->expectException(StopException::class);

        $this->readFileException = true;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    public function testExecuteLowLevelException()
    {
        $this->expectException(StopException::class);

        $this->lowLevelException = true;

        ob_start(function ($log) {
            $this->logs[] = $log;
            return '';
        });
        try {
            $this->instance->execute('');
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }
}