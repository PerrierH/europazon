<?php

namespace Maas\DataSet\Test\Unit\Model\Service;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;

use Maas\DataSet\Model\Service\DataSetType;
use Magento\Framework\Data\Collection\FilesystemFactory;
use Magento\Framework\Data\Collection\Filesystem;


class DataSetTypeTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    private $objectManager;

    /** @var DataSetType */
    private $instance;

    /** @var Array */
    private $items;

    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $fileSystem = AnyBuilder::createForClass(
            $this,
            Filesystem::class,
            [
                'clear' => [$this->any(), true],
                'addTargetDir' => [$this->any(), true],
                'setCollectDirs' => [$this->any(), true],
                'setCollectFiles' => [$this->any(), true],
                'setCollectRecursively' => [$this->any(), true],
                'getItems' => [
                    $this->any(),
                    function () {
                        return $this->items;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
            ]
        )->build();

        $fileSystemFactory = AnyBuilder::createForClass(
            $this,
            FilesystemFactory::class,
            [
                'create' => [$this->any(), $fileSystem]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            DataSetType::class,
            [
                'fileSystemFactory' => $fileSystemFactory
            ]
        );
    }

    /**
     * @dataProvider executeProvider
     */
    public function testExecute($files)
    {
        $this->items = [];
        $expectedFiles = [
            'categories.json' => false,
            'products.json' => false,
            'offers.json' => false,
            'sellers.json' => false
        ];
        $correct = true;
        foreach ($files as $file => $res) {
            $expectedFiles[$file] = $res;
            $correct = $correct && $res;
            if ($res) {
                $this->items[] = AnyBuilder::createForClass(
                    $this,
                    \StdClass::class,
                    [
                        'getBaseName' => [$this->any(), $file]
                    ]
                )->build();
            }
        }

        $result = $this->instance->execute('', DataSetType::TYPE_FULL);

        $this->assertEquals($correct, $result['correct']);
        $this->assertEquals($expectedFiles['categories.json'], $result['files']['categories.json']);
        $this->assertEquals($expectedFiles['products.json'], $result['files']['products.json']);
        $this->assertEquals($expectedFiles['offers.json'], $result['files']['offers.json']);
        $this->assertEquals($expectedFiles['sellers.json'], $result['files']['sellers.json']);
    }

    public function executeProvider()
    {
        yield from [
            'all expected files' => [
                'files' => [
                    'categories.json' => true,
                    'products.json' => true,
                    'offers.json' => true,
                    'sellers.json' => true
                ]
            ],
            'missing files' => [
                'files' => [
                    'categories.json' => true,
                    'products.json' => false,
                    'offers.json' => true,
                    'sellers.json' => true
                ]
            ]
        ];
    }
}