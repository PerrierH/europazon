<?php

namespace Maas\DataSet\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Maas\DataSet\Model\Service\DataSetType;

/**
 * Class DataSet
 * @package Maas\DataSet\Ui\Component\Listing\Columns
 * @codeCoverageIgnore
 */
class DataSet extends Column
{

    /** @var DataSetType */
    private $checkFiles;

    /**
     * Constructor
     *
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        DataSetType $checkFiles,
        array $components = [],
        array $data = []
    ) {
        $this->checkFiles = $checkFiles;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $item['files'] = $this->checkFiles->execute($item['filename']);
                $item[$this->getData('name')] = $this->getContext()
                    ->getPageLayout()
                    ->createBlock('\Maas\DataSet\Block\Adminhtml\DataSet', 'dataset_' . $item['id'], ['data' => $item])
                    ->toHtml();
            }
        }
        return $dataSource;
    }

}
