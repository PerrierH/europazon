<?php
namespace Maas\DataSet\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class DataSetActions
 * @package Maas\DataSet\Ui\Component\Listing\Columns
 * @codeCoverageIgnore
 */
class DataSetActions extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                if(strpos($item['filename'], 'Maas/DataSet') === false) {
                    $item[$this->getData('name')]['run'] = [
                        'href' => $this->urlBuilder->getUrl(
                            'maasdataset/listing/delete',
                            ['basename' => $item['basename']]
                        ),
                        'label' => __('Delete'),
                        'hidden' => false,
                    ];
                    $item[$this->getData('name')]['edit'] = [
                        'href' => $this->urlBuilder->getUrl(
                            'maasdataset/listing/edit',
                            ['basename' => $item['basename']]
                        ),
                        'label' => __('Edit'),
                        'hidden' => false,
                    ];
                }
            }
        }
        return $dataSource;
    }
}
