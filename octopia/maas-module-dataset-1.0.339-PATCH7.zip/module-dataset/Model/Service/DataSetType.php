<?php

namespace Maas\DataSet\Model\Service;

use Magento\Framework\Data\Collection\FilesystemFactory;
use Exception;

/**
 * Class DataSetType
 *
 * @package Maas\DataSet\Model\Service
 */
class DataSetType
{
    public const TYPE_FULL = 'full';
    public const TYPE_CATEGORIES = 'categories';

    private $expectedFiles = [
        'categories.json',
        'products.json',
        'offers.json',
        'sellers.json'
    ];

    /** @var FilesystemFactory  */
    private $fileSystemFactory;

    /**
     * DataSetType constructor.
     *
     * @param FilesystemFactory $fileSystemFactory
     */
    public function __construct(
        FilesystemFactory $fileSystemFactory
    ) {
        $this->fileSystemFactory = $fileSystemFactory;
    }

    /**
     * @param string $dataset
     * @param string|null $expectedType
     *
     * @return array
     * @throws Exception
     */
    public function execute(string $path, $expectedType = null)
    {
        $return = [
            'files' => [],
            'correct' => true
        ];
        if((is_null($expectedType) || $expectedType == self::TYPE_FULL) && $this->isDatasetFull($path, $return))
        {
            $return['type'] = self::TYPE_FULL;
        }
        else
        {
            if((is_null($expectedType) || $expectedType == self::TYPE_CATEGORIES) && $this->isDatasetCategories($path, $return))
            {
                $return['type'] = self::TYPE_CATEGORIES;
            }
        }
        return $return;
    }

    protected function isDatasetFull($path, &$return)
    {
        $return['files'] = [];
        $files = $this->getFiles($path);
        foreach ($this->expectedFiles as $file) {
            $test = in_array($file, $files);
            $return['files'][$file] = $test;
            $return['correct'] = $return['correct'] && $test;
        }
        return $return['correct'];
    }

    protected function isDatasetCategories($path, &$return)
    {
        $return['files'] = [];
        $files = $this->getFiles($path);
        $allCategories = true;
        foreach($files as $file)
        {
            $isCategory = (substr($file, 0, 10) == 'categories' && substr($file, -5) == '.json');
            $return['files'][$file] = $isCategory;
            $allCategories = $allCategories & $isCategory;
        }
        if ($allCategories)
        {
            $return['correct'] = $allCategories;
        }
        return $allCategories;
    }

    /**
     * @param $dir
     *
     * @return array
     * @throws Exception
     */
    protected function getFiles($path)
    {
        $fileSystem = $this->fileSystemFactory->create();
        $fileSystem->clear();
        $fileSystem->addTargetDir($path);
        $fileSystem->setCollectDirs(false);
        $fileSystem->setCollectFiles(true);
        $fileSystem->setCollectRecursively(false);

        $files = [];

        foreach ($fileSystem->getItems() as $item) {
            $files[] = $item->getBasename();
        }

        return $files;
    }
}