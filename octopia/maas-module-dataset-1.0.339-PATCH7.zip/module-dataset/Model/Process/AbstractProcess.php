<?php


namespace Maas\DataSet\Model\Process;

use Maas\ImportExport\Model\Service\Import;
use Magento\Framework\Serialize\SerializerInterface;
use Maas\DataSet\Exception\StopException;

class AbstractProcess
{
    public $file = '';

    /**
     * @var SerializerInterface
     */
    public $serializer;

    public string $directory;
    protected Import $importService;

    public function __construct(
        SerializerInterface $serializer,
        Import $importService
    ){
        $this->serializer = $serializer;
        $this->importService = $importService;
    }

    /**
     * @throws StopException
     */
    protected function log($log, $br = true, $stop = false)
    {
        if ($br) {
            print_r('<br />');
        }
        print_r($log);
        ob_flush();
        if ($stop) {
            throw new StopException('stop');
        }
    }

    /**
     * @param $file
     * @return array|bool|float|int|string|null
     * @codeCoverageIgnore
     */
    protected function readFile($file)
    {
        $content = file_get_contents($this->directory . '/' . $file);

        return $this->serializer->unserialize($content);
    }

    /**
     * @throws StopException
     */
    public function parseFile($directory): array
    {
        $this->log('&bull; Processing ' . $this->file);
        $this->directory = $directory;
        $data = [];

        $this->log('&nbsp; - Reading file... ');
        try {
            $data['items'] = $this->readFile($this->file);
        } catch (\Exception $e) {
            $this->log('Error reading file', false, true);
        }
        if (!isset($data['items'])) {
            $this->log('Error parsing file content', false, true);
        }
        $this->log('Ok', false);

        return $data;
    }
}
