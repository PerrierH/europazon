<?php

namespace Maas\DataSet\Model\Process;

use Exception;
use Maas\ImportExport\Exception\OperationAlreadyLaunch;
use Maas\ImportExport\Model\Service\Import;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Api\DataObjectHelper;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\DataSet\Exception\StopException;
use Maas\ImportExport\Model\Import\Catalog\Category;
use Maas\ImportExport\Model\Import\Catalog\Category\Consumer;
use Maas\ImportExport\Model\Import\Catalog\Category\MessageBuilder;
use Maas\ImportExport\Api\Data\Catalog\CategoryInterface;
use Maas\ImportExport\Api\Data\Catalog\CategoryInterfaceFactory;

class Categories extends AbstractConsumerProcess
{
    public const MAAS_LOG_MODULE = 'Maas_DataSet';

    public $file = 'categories.json';

    /** @var Consumer  */
    private $categoryImporter;

    /** @var MessageBuilder  */
    private $messageBuilder;

    /** @var CategoryInterfaceFactory  */
    private $categoryInterfaceFactory;

    /**
     * Categorys constructor.
     *
     * @param SerializerInterface $serializer
     * @param Import $importService
     * @param DataObjectHelper $dataObjectHelper
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportFactory $reportFactory
     * @param Consumer $categoryImporter
     * @param CategoryInterfaceFactory $categoryInterfaceFactory
     * @param MessageBuilder $messageBuilder
     */
    public function __construct(
        SerializerInterface $serializer,
        Import $importService,
        DataObjectHelper $dataObjectHelper,
        ReportRepositoryInterface $reportRepository,
        ReportFactory $reportFactory,
        Consumer $categoryImporter,
        CategoryInterfaceFactory $categoryInterfaceFactory,
        MessageBuilder $messageBuilder
    ) {
        $this->categoryImporter = $categoryImporter;
        $this->categoryInterfaceFactory = $categoryInterfaceFactory;
        $this->messageBuilder = $messageBuilder;
        parent::__construct($serializer, $importService, $dataObjectHelper, $reportRepository, $reportFactory);
    }

    /**
     * @param $directory
     *
     * @throws OperationAlreadyLaunch|StopException
     */
    public function execute($directory)
    {
        try {
            $data = $this->parseFile($directory);

            $this->log('&nbsp; - Preparing data... ');
            $count = count($data['items']);
            $data['totalItemCount'] = $count;
            $data['count'] = $count;

            foreach ($data['items'] as $item) {
                $dataObject = $this->categoryInterfaceFactory->create();
                $this->importService->prepareDataKeys($item);
                $this->dataObjectHelper->populateWithArray(
                    $dataObject, $item, CategoryInterface::class
                );
                $this->messageBuilder->addEntity($dataObject);
            }

            $this->log('Ok', false);
            $this->log($count . ' categories');

            $this->log('&nbsp; - Preparing report... ');
            /** @var Report $report */
            $report = $this->reportFactory->create();

            $report = $this->reportRepository->generateLogReport(
                $report,
                self::MAAS_LOG_MODULE,
                Category::MAAS_LOG_ACTION,
                Category::MAAS_LOG_OPERATION_TYPE
            );
            $report->setItemsCount($count);
            $this->reportRepository->save($report);
            $this->messageBuilder->setReportId($report->getId());
            $this->log('Ok', false);

            $this->log('&nbsp; - Importing data... ');
            $message = $this->messageBuilder->build();
            $this->categoryImporter->process($message);
        }catch(StopException $e){
            throw $e;
        }catch(Exception $e){
            $this->log('Erreur: '.$e->getMessage(), true, true);
        }
    }
}
