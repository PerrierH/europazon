<?php

namespace Maas\DataSet\Model\Process;

use Exception;
use Maas\ImportExport\Model\Service\Import;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Api\DataObjectHelper;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\DataSet\Exception\StopException;
use Maas\ImportExport\Model\Import\Catalog\Product;
use Maas\DatabaseImport\Model\Import\Consumer\Product as ProductImporter;
use Maas\ImportExport\Model\Import\Catalog\Product\MessageBuilder;
use Maas\ImportExport\Api\Data\Catalog\ProductInterface;
use Maas\ImportExport\Api\Data\Catalog\ProductInterfaceFactory;


class Products extends AbstractConsumerProcess
{
    public const MAAS_LOG_MODULE = 'Maas_DataSet';

    public $file = 'products.json';

    /** @var ProductImporter */
    private $productImporter;

    /** @var MessageBuilder */
    private $messageBuilder;

    /** @var ProductInterfaceFactory */
    private $productInterfaceFactory;
    protected Product\Adapter\Converter\Product $productConverter;

    /**
     * @param SerializerInterface $serializer
     * @param Import $importService
     * @param DataObjectHelper $dataObjectHelper
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportFactory $reportFactory
     * @param ProductImporter $productImporter
     * @param ProductInterfaceFactory $productInterfaceFactory
     * @param MessageBuilder $messageBuilder
     * @param Product\Adapter\Converter\Product $productConverter
     */
    public function __construct(
        SerializerInterface $serializer,
        Import $importService,
        DataObjectHelper $dataObjectHelper,
        ReportRepositoryInterface $reportRepository,
        ReportFactory $reportFactory,
        ProductImporter $productImporter,
        ProductInterfaceFactory $productInterfaceFactory,
        MessageBuilder $messageBuilder,
        Product\Adapter\Converter\Product $productConverter
    ) {
        $this->productImporter = $productImporter;
        $this->productInterfaceFactory = $productInterfaceFactory;
        $this->messageBuilder = $messageBuilder;
        $this->productConverter = $productConverter;
        parent::__construct($serializer, $importService, $dataObjectHelper, $reportRepository, $reportFactory);
    }

    public function execute($directory)
    {
        try {
            $data = $this->parseFile($directory);

            $this->log('&nbsp; - Preparing data... ');
            $count = count($data['items']);
            $data['totalItemCount'] = $count;
            $data['count'] = $count;

            foreach ($data['items'] as $item) {
                $item = array_merge($item, $this->productConverter->convertItemData($item));
                $dataObject = $this->productInterfaceFactory->create();
                $this->importService->prepareDataKeys($item);
                $this->dataObjectHelper->populateWithArray(
                    $dataObject, $item, ProductInterface::class
                );
                $this->messageBuilder->addEntity($dataObject);
            }

            $this->log('Ok', false);
            $this->log($count . ' products');

            $this->log('&nbsp; - Preparing report... ');
            /** @var Report $report */
            $report = $this->reportFactory->create();

            $report = $this->reportRepository->generateLogReport(
                $report,
                self::MAAS_LOG_MODULE,
                Product::MAAS_LOG_ACTION,
                Product::MAAS_LOG_OPERATION_TYPE
            );
            $report->setItemsCount($count);
            $this->reportRepository->save($report);
            $this->messageBuilder->setReportId($report->getId());
            $this->log('Ok', false);

            $this->log('&nbsp; - Importing data... ');
            $message = $this->messageBuilder->build();
            $this->productImporter->process($message);
        } catch (StopException $e) {
            throw $e;
        } catch (Exception $e) {
            $this->log('Erreur: ' . $e->getMessage(), true, true);
        }
    }

}
