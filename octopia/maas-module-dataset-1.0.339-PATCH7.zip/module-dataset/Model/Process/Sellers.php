<?php

namespace Maas\DataSet\Model\Process;

use Exception;
use Maas\ImportExport\Model\Service\Import;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\App\ProductMetadataFactory;
use Magento\Framework\Api\DataObjectHelper;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\DataSet\Exception\StopException;
use Maas\ImportExport\Model\Import\Seller\Seller;
use Maas\ImportExport\Model\Import\Seller\Consumer;
use Maas\ImportExport\Model\Import\Seller\MessageBuilder;
use Maas\ImportExport\Api\Data\Seller\SellerInterface;
use Maas\ImportExport\Api\Data\Seller\SellerInterfaceFactory;

/**
 * Class Sellers
 *
 * @package Maas\DataSet\Model\Process
 */
class Sellers extends AbstractConsumerProcess
{
    public const MAAS_LOG_MODULE = 'Maas_DataSet';

    public $file = 'sellers.json';

    /** @var Consumer  */
    private $sellerImporter;

    /** @var MessageBuilder  */
    private $messageBuilder;

    /**
     * Sellers constructor.
     *
     * @param SerializerInterface $serializer
     * @param Import $importService
     * @param DataObjectHelper $dataObjectHelper
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportFactory $reportFactory
     * @param Consumer $sellerImporter
     * @param SellerInterfaceFactory $sellerInterfaceFactory
     * @param MessageBuilder $messageBuilder
     */
    public function __construct(
        SerializerInterface $serializer,
        Import $importService,
        DataObjectHelper $dataObjectHelper,
        ReportRepositoryInterface $reportRepository,
        ReportFactory $reportFactory,
        Consumer $sellerImporter,
        SellerInterfaceFactory $sellerInterfaceFactory,
        MessageBuilder $messageBuilder
    ) {
        $this->sellerImporter = $sellerImporter;
        $this->sellerInterfaceFactory = $sellerInterfaceFactory;
        $this->messageBuilder = $messageBuilder;
        parent::__construct($serializer, $importService, $dataObjectHelper, $reportRepository, $reportFactory);
    }

    /**
     * @param string $directory
     *
     * @throws StopException
     */
    public function execute($directory){
        try {
            $data = $this->parseFile($directory);

            $this->log('&nbsp; - Preparing data... ');
            $count = count($data['items']);
            $data['totalItemCount'] = $count;
            $data['count'] = $count;

            foreach ($data['items'] as $item) {
                $dataObject = $this->sellerInterfaceFactory->create();
                $this->importService->prepareDataKeys($item);
                $this->dataObjectHelper->populateWithArray(
                    $dataObject, $item, SellerInterface::class
                );
                // isFulfillment is a special case: it's a boolean that is imported as string
                if (is_string($item['isFulfillment']))
                {
                    $dataObject->setIsFulfillment(in_array($item['isFulfillment'], ['true', '1']));
                }
                $this->messageBuilder->addEntity($dataObject);
            }

            $this->log('Ok', false);
            $this->log('&nbsp; - '.$count . ' sellers');

            $this->log('&nbsp; - Preparing report... ');
            /** @var Report $report */
            $report = $this->reportFactory->create();

            $report = $this->reportRepository->generateLogReport(
                $report,
                self::MAAS_LOG_MODULE,
                Seller::MAAS_LOG_ACTION,
                Seller::MAAS_LOG_OPERATION_TYPE
            );
            $report->setItemsCount($count);
            $this->reportRepository->save($report);
            $this->messageBuilder->setReportId($report->getId());
            $this->log('Ok', false);

            $this->log('&nbsp; - Importing data... ');
            $message = $this->messageBuilder->build();
            $this->sellerImporter->process($message);
        }catch(StopException $e){
            throw $e;
        }catch(Exception $e){
            $this->log('Erreur: '.$e->getMessage(), true, true);
        }
    }

}
