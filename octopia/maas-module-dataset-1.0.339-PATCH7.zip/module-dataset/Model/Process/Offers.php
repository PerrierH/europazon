<?php

namespace Maas\DataSet\Model\Process;

use Exception;
use Maas\ImportExport\Model\Service\Import;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Api\DataObjectHelper;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\DataSet\Exception\StopException;
use Maas\DatabaseImport\Model\Import\Consumer\Offer;
use Maas\ImportExport\Model\Import\Offer\Offer as OriginalImportOffer;
use Maas\ImportExport\Model\Import\Offer\MessageBuilder as OfferMessageBuilder;
use Maas\ImportExport\Api\Data\Offer\OfferInterface;
use Maas\ImportExport\Api\Data\Offer\OfferInterfaceFactory;


class Offers extends AbstractConsumerProcess
{
    public const MAAS_LOG_MODULE = 'Maas_DataSet';

    public $file = 'offers.json';

    /** @var Offer */
    private $offerImporter;

    /** @var OfferMessageBuilder */
    private $offerMessageBuilder;

    /** @var OfferInterfaceFactory */
    private $offerInterfaceFactory;

    public function __construct(
        SerializerInterface   $serializer,
        Import $importService,
        DataObjectHelper      $dataObjectHelper,
        ReportRepositoryInterface      $reportRepository,
        ReportFactory         $reportFactory,
        Offer         $offerImporter,
        OfferInterfaceFactory $offerInterfaceFactory,
        OfferMessageBuilder   $offerMessageBuilder
    ) {
        $this->offerImporter = $offerImporter;
        $this->offerInterfaceFactory = $offerInterfaceFactory;
        $this->offerMessageBuilder = $offerMessageBuilder;
        parent::__construct($serializer, $importService, $dataObjectHelper, $reportRepository, $reportFactory);
    }

    /**
     * @param $directory
     * @return void
     * @throws StopException
     */
    public function execute($directory)
    {
        try {
            $data = $this->parseFile($directory);

            $this->log('&nbsp; - Preparing data... ');

            $offers = [
                'items' => []
            ];
            foreach ($data['items'] as $item) {
                $offerData = $item;
                $offers['items'][] = $offerData;
            }
            $offersCount = count($offers['items']);

            $this->log('Ok', false);
            $this->log('&nbsp;&nbsp;&nbsp;-&nbsp;' . $offersCount . ' offers');

            $this->offersImport($offers, $offersCount);
        } catch (StopException $e) {
            throw $e;
        } catch (Exception $e) {
            $this->log('Erreur: ' . $e->getMessage(), true, true);
        }
    }

    /**
     * @param $offers
     * @param $offersCount
     * @return void
     * @throws StopException
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @throws \Magento\Framework\Exception\FileSystemException
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Exception\StateException
     */
    public function offersImport($offers, $offersCount)
    {
        $this->log('&nbsp; - Offers import');
        $this->log('&nbsp;&nbsp;&nbsp;&nbsp;- Preparing data... ');
        foreach ($offers['items'] as $item) {
            $dataObject = $this->offerInterfaceFactory->create();
            $this->importService->prepareDataKeys($item);
            $this->dataObjectHelper->populateWithArray(
                $dataObject, $item, OfferInterface::class
            );
            $this->offerMessageBuilder->addEntity($dataObject);
        }
        $this->log('Ok', false);

        $this->log('&nbsp;&nbsp;&nbsp;&nbsp;- Preparing report... ');
        /** @var Report $report */
        $report = $this->reportFactory->create();
        $report = $this->reportRepository->generateLogReport(
            $report,
            self::MAAS_LOG_MODULE,
            OriginalImportOffer::MAAS_LOG_ACTION,
            OriginalImportOffer::MAAS_LOG_OPERATION_TYPE
        );
        $report->setItemsCount($offersCount);
        $this->reportRepository->save($report);
        $this->offerMessageBuilder->setReportId($report->getId());
        $this->log('Ok', false);

        $this->log('&nbsp;&nbsp;&nbsp;&nbsp;- Importing data... ');
        $message = $this->offerMessageBuilder->build();
        $this->offerImporter->process($message);
    }

}
