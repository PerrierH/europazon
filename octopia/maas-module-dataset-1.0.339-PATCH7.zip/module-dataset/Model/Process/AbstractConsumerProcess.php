<?php

namespace Maas\DataSet\Model\Process;

use Maas\ImportExport\Model\Service\Import;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Api\DataObjectHelper;
use Maas\Log\Model\ReportFactory;
use Magento\Framework\App\ProductMetadataFactory;

class AbstractConsumerProcess extends AbstractProcess
{
    public $file ='';

    /** @var SerializerInterface */
    public $serializer;

    /** @var string */
    public string $directory;

    /** @var DataObjectHelper  */
    public $dataObjectHelper;

    /** @var ReportRepositoryInterface  */
    public $reportRepository;

    /** @var ReportFactory  */
    public $reportFactory;

    /**
     * AbstractConsumerProcess constructor.
     *
     * @param SerializerInterface $serializer
     * @param DataObjectHelper $dataObjectHelper
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportFactory $reportFactory
     */
    public function __construct(
        SerializerInterface $serializer,
        Import $importService,
        DataObjectHelper $dataObjectHelper,
        ReportRepositoryInterface $reportRepository,
        ReportFactory $reportFactory
    ){
        $this->reportRepository = $reportRepository;
        $this->reportFactory = $reportFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($serializer, $importService);
    }

}
