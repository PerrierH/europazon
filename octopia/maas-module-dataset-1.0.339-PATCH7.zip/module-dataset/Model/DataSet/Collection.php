<?php

namespace Maas\DataSet\Model\DataSet;

use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Magento\Framework\Data\Collection\Filesystem;
use Magento\Framework\Module\Dir;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

/**
 * Class Collection
 * @package Maas\DataSet\Model\Dataset
 * @codeCoverageIgnore
 */
class Collection extends Filesystem
{

    protected $_idFieldName = 'basename';

    /**
     * Collection constructor.
     * @param EntityFactoryInterface $entityFactory
     * @param Dir $moduleDirectory
     * @param DirectoryList $directoryList
     * @param File $file
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(
        EntityFactoryInterface $entityFactory,
        Dir $moduleDirectory,
        DirectoryList $directoryList,
        File $file
    ) {
        parent::__construct($entityFactory);

        $moduleDir = $moduleDirectory->getDir('Maas_DataSet') . '/data';
        $this->addTargetDir($moduleDir);
        $varDir = (string) $directoryList->getPath('var') . '/Maas/dataset';
        if(!is_dir($varDir)){
            $file->checkAndCreateFolder($varDir);
        }
        $this->addTargetDir($varDir);
        $this->setCollectDirs(true);
        $this->setCollectFiles(false);
        $this->setCollectRecursively(false);
    }

    /**
     * Convert collection to array
     *
     * @param array $arrRequiredFields
     * @return array
     */
    public function toArray($arrRequiredFields = [])
    {
        $arrItems = [];
        $arrItems['totalRecords'] = $this->getSize();

        $arrItems['items'] = [];
        foreach ($this as $item) {
            $itemArray = $item->toArray($arrRequiredFields);
            $itemArray['id_field_name'] = $this->_idFieldName;
            $arrItems['items'][] = $itemArray;
        }
        return $arrItems;
    }

}
