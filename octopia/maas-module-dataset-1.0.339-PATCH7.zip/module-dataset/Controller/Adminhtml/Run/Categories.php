<?php

namespace Maas\DataSet\Controller\Adminhtml\Run;

use Maas\Core\Model\Service\RunCli;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Maas\DataSet\Model\Service\DataSetType;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Module\Dir;
use Magento\Framework\Filesystem\DirectoryList;

use Maas\DataSet\Exception\StopException;

/**
 * Class Index
 *
 * @package Maas\DataSet\Controller\Run
 * @codeCoverageIgnore
 */
class Categories extends Action
{

    /** @var string */
    private string $directory;

    /** @var */
    private $datasetType;

    /** @var Dir */
    private $moduleDirectory;


    /** @var DirectoryList */
    private $directoryList;

    /** @var RunCli */
    private $runCli;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param DataSetType $datasetType
     * @param Dir $moduleDirectory
     * @param DirectoryList $directoryList
     */
    public function __construct(
        Context $context,
        DataSetType $datasetType,
        Dir $moduleDirectory,
        DirectoryList $directoryList,
        ManagerInterface $messageManager,
        RunCli $runCli
    ) {
        $this->datasetType = $datasetType;
        $this->moduleDirectory = $moduleDirectory;
        $this->directoryList = $directoryList;
        $this->messageManager = $messageManager;
        $this->runCli = $runCli;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $params = $this->getRequest()->getParams();
            $dataset = $params['dataset'];

            $this->directory = $this->moduleDirectory->getDir('Maas_DataSet') . '/data/' . $dataset;
            if (!is_dir($this->directory)) {
                $this->directory = $this->directoryList->getPath('var') . '/Maas/dataset/' . $dataset;
                if (!is_dir($this->directory)) {
                    $this->messageManager->addErrorMessage(__('Invalid Dataset: %1', $dataset));
                    throw new StopException();
                }
            }

            $files = $this->datasetType->execute($this->directory);
            if ($files['type'] != DataSetType::TYPE_CATEGORIES) {
                $this->messageManager->addErrorMessage(__('Dataset type invalid'));
                throw new StopException();
            }
            if (!$files['correct']) {
                $this->messageManager->addErrorMessage(__('One or more files are invalid'));
                throw new StopException();
            }

            $this->messageManager->addSuccessMessage(__('Categories import started. Its progress can be tracked on the Reports page.'));

            $this->runCli->addToQueue('maas:dataset:import:categories', [$this->directory]);
        } catch (StopException $e) {
            // do nothing
        }

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
