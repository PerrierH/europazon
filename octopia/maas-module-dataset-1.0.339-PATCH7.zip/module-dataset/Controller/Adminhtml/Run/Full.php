<?php

namespace Maas\DataSet\Controller\Adminhtml\Run;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Maas\DataSet\Model\Service\DataSetType;
use Magento\Framework\Module\Dir;
use Magento\Framework\Filesystem\DirectoryList;
use Maas\DataSet\Model\Process\Categories;
use Maas\DataSet\Model\Process\Products;
use Maas\DataSet\Model\Process\Offers;
use Maas\DataSet\Model\Process\Sellers;
use Maas\DataSet\Exception\StopException;
use Magento\Framework\TranslateInterface;

/**
 * Class Index
 * @package Maas\DataSet\Controller\Run
 * @codeCoverageIgnore
 */
class Full extends Action
{

    /** @var string */
    private string $directory;

    /** @var */
    private $datasetType;

    /** @var Dir */
    private $moduleDirectory;

    /** @var Categories */
    private $categoriesProcessor;

    /** @var Products */
    private $productsProcessor;

    /** @var Offers */
    private $offersProcessor;

    /** @var Sellers */
    private $sellersProcessor;

    /** @var DirectoryList */
    private $directoryList;

    /**
     * @var TranslateInterface
     */
    private $_translator;

    /**
     * Index constructor.
     * @param Context $context
     * @param DataSetType $datasetType
     * @param Dir $moduleDirectory
     * @param Categories $categoriesProcessor
     * @param Products $productsProcessor
     * @param Offers $offersProcessor
     * @param Sellers $sellersProcessor
     * @param DirectoryList $directoryList
     * @param TranslateInterface $translator
     */
    public function __construct(
        Context $context,
        DataSetType $datasetType,
        Dir $moduleDirectory,
        Categories $categoriesProcessor,
        Products $productsProcessor,
        Offers $offersProcessor,
        Sellers $sellersProcessor,
        DirectoryList $directoryList,
        TranslateInterface $translator
    )
    {
        $this->datasetType = $datasetType;
        $this->moduleDirectory = $moduleDirectory;
        $this->categoriesProcessor = $categoriesProcessor;
        $this->productsProcessor = $productsProcessor;
        $this->offersProcessor = $offersProcessor;
        $this->sellersProcessor = $sellersProcessor;
        $this->directoryList = $directoryList;
        $this->_translator = $translator;
        parent::__construct($context);
    }

    public function execute()
    {
        ini_set('memory_limit', -1);
        try {
            $this->_translator->setLocale('en_US')->loadData(null, true);
            $params = $this->getRequest()->getParams();
            $dataset = $params['dataset'];

            ob_start();

            $this->log('&bull; Running data set: ' . $dataset);

            //Check dataset and files
            $this->log('&nbsp; - Checking directory... ');
            $this->directory = $this->moduleDirectory->getDir('Maas_DataSet') . '/data/' . $dataset;
            if (!is_dir($this->directory)) {
                $this->directory = $this->directoryList->getPath('var') . '/Maas/dataset/' . $dataset;
                if (!is_dir($this->directory)) {
                    $this->log('&nbsp; - Invalid Dataset', true, true);
                }
            }
            $this->log('Ok', false);

            $this->log('&nbsp; - Checking files... ');
            $files = $this->datasetType->execute($this->directory);
            if ($files['type'] != DataSetType::TYPE_FULL) {
                $this->log('&nbsp; - Dataset type invalid', true, true);
                throw new StopException();
            }
            if (!$files['correct']) {
                $this->log('&nbsp; - One or more invalid files', true, true);
            }
            $this->log('Ok', false);

            //Process files
            $this->categoriesProcessor->execute($this->directory);

            $this->productsProcessor->execute($this->directory);

            $this->sellersProcessor->execute($this->directory);

            $this->offersProcessor->execute($this->directory);

            ob_end_flush();

        } catch (StopException $e) {
            ob_end_flush();
        }
    }

    private function log($log, $br = true, $stop = false)
    {
        if ($br) {
            print_r('<br />');
        }
        print_r($log);
        ob_flush();
        if ($stop) {
            ob_end_clean();
            throw new StopException('Stop');
        }
    }

}
