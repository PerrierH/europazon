<?php

namespace Maas\DataSet\Controller\Adminhtml\Listing;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

/**
 * Class Delete
 *
 * @package Maas\DataSet\Controller\Adminhtml\Listing
 * @codeCoverageIgnore
 */
class Delete extends Action
{

    /** @var File */
    private $file;

    /** @var DirectoryList */
    private $directoryList;

    /**
     * NewAction constructor.
     *
     * @param Context $context
     * @param File $file
     * @param DirectoryList $directoryList
     */
    public function __construct(
        Context $context,
        File $file,
        DirectoryList $directoryList
    ) {
        $this->file = $file;
        $this->directoryList = $directoryList;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->renderLayout();

        $basename = $this->getRequest()->getParam('basename');

        $destDir = $this->directoryList->getPath('var') . '/Maas/dataset/' . $basename;
        if (is_dir($destDir)) {
            if ($this->file->rmdir($destDir, true)) {
                $this->messageManager->addSuccessMessage(__("The directory \"%1\" was deleted successfully.",
                    $basename));
            } else {
                $this->messageManager->addErrorMessage(__("The directory \"%1\" could not be deleted.", $basename));
            }
        } else {
            $this->messageManager->addWarningMessage(__("\"%1\" does not exist or is not a directory.", $basename));
        }


        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/index');
    }
}
