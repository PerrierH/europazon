<?php

namespace Maas\DataSet\Controller\Adminhtml\Listing;

use Magento\Framework\App\ResponseInterface;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Filesystem\DirectoryList;
use Maas\DataSet\Controller\Adminhtml\Listing\AbstractAction;

/**
 * Class Edit
 * @package Maas\DataSet\Controller\Adminhtml\Listing
 * @codeCoverageIgnore
 */
class Edit extends AbstractAction
{
    /** @var File */
    private $file;

    /** @var DirectoryList  */
    private $directoryList;

    /**
     * NewAction constructor.
     *
     * @param Context $context
     * @param Dir $moduleDir
     * @param File $file
     */
    public function __construct(
        Context $context,
        File $file,
        DirectoryList $directoryList
    ) {
        $this->file = $file;
        $this->directoryList = $directoryList;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->renderLayout();

        $datasetDatas = $this->getRequest()->getParam('general');
        if (is_array($datasetDatas)) {
            $oldBasename = $this->getRequest()->getParam('basename');
            $destDir = $this->directoryList->getPath('var') . '/Maas/dataset/' . $datasetDatas['basename'];
            if (($oldBasename == $datasetDatas['basename']) || !is_dir($destDir)) {
                $filesToMove = $this->getFiles($destDir);

                $this->file->checkAndCreateFolder($destDir);
                foreach ($filesToMove as $file){
                    move_uploaded_file($file['from'], $file['to']);
                }

            }

            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/index');
        }
    }
}
