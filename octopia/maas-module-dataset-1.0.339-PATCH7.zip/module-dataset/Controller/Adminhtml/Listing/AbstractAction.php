<?php

namespace Maas\DataSet\Controller\Adminhtml\Listing;

use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;

/**
 * Class AbstractAction
 * @package Maas\DataSet\Controller\Adminhtml\Listing
 * @codeCoverageIgnore
 */
abstract class AbstractAction extends Action
{

    abstract public function execute();


    /**
     * @param $destDir
     * @return array
     */
    protected function getFiles($destDir){
        $files = $_FILES['general'];
        $filesToMove = [];
        foreach ($files['name'] as $key =>$file) {
            if($file !='') {
                $result = $this->processFile($files, $key, $destDir);
                if (is_array($result)) {
                    $filesToMove[] = $result;
                }
            }
        }

        return $filesToMove;
    }

    /**
     * @param $data
     * @param $file
     * @param $dataset
     *
     * @return array|\Magento\Framework\Phrase
     */
    protected function processFile($data, $file, $destDir)
    {
        if($data['type'][$file] !== 'application/json'){
            return __('Bad file format');
        }

        $dest = $destDir . '/' . $file .  '.json';

        return [
            'from' => $data['tmp_name'][$file],
            'to' => $dest
        ];
    }
}