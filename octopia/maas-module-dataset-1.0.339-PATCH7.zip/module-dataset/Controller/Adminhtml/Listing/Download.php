<?php

namespace Maas\DataSet\Controller\Adminhtml\Listing;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Module\Dir;

/**
 * Class Download
 * @package Maas\DataSet\Controller\Adminhtml\Listing
 * @codeCoverageIgnore
 */
class Download extends Action
{

    /** @var RawFactory */
    private $resultRawFactory;

    /** @var FileFactory */
    private $fileFactory;

    /** @var DirectoryList */
    private $directoryList;

    /** @var Dir */
    private $moduleDir;

    /**
     * Download constructor.
     * @param RawFactory $resultRawFactory
     * @param FileFactory $fileFactory
     * @param Context $context
     * @param DirectoryList $directoryList
     * @param Dir $moduleDir
     */
    public function __construct(
        RawFactory $resultRawFactory,
        FileFactory $fileFactory,
        Context $context,
        DirectoryList $directoryList,
        Dir $moduleDir
    )
    {
        $this->resultRawFactory = $resultRawFactory;
        $this->fileFactory = $fileFactory;
        $this->directoryList = $directoryList;
        $this->moduleDir = $moduleDir;
        parent::__construct($context);
    }

    public function execute()
    {
        $filename = $this->getRequest()->getParam('file');
        $dataset = $this->getRequest()->getParam('dataset');

        $directory = $this->directoryList->getPath('var')
            . '/Maas/dataset/'
            . $dataset;
        if (!file_exists($directory . '/' . $filename)) {
            $directory = $this->moduleDir->getDir('Maas_DataSet')
                . '/data/'
                . $this->getRequest()->getParam('dataset');
        }
        $content = file_get_contents($directory . '/' . $filename);
        return $this->fileFactory->create(
            'Octopia_' . $dataset . '_' . $filename,
            $content,
            'tmp',
            'application/json',
            strlen($content)
        );
    }
}
