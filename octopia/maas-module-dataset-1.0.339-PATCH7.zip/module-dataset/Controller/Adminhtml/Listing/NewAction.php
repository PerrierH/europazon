<?php

namespace Maas\DataSet\Controller\Adminhtml\Listing;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Module\Dir;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Filesystem\DirectoryList;
use Maas\DataSet\Controller\Adminhtml\Listing\AbstractAction;

/**
 * Class NewAction
 * @package Maas\DataSet\Controller\Adminhtml\Listing
 * @codeCoverageIgnore
 */
class NewAction extends AbstractAction
{

    /** @var Dir */
    private $moduleDirectory;

    /** @var File */
    private $file;

    /** @var DirectoryList */
    private $directoryList;

    /**
     * NewAction constructor.
     * @param Context $context
     * @param Dir $moduleDir
     * @param File $file
     * @param DirectoryList $directoryList
     */
    public function __construct(
        Context       $context,
        Dir           $moduleDir,
        File          $file,
        DirectoryList $directoryList
    )
    {
        $this->moduleDirectory = $moduleDir;
        $this->file = $file;
        $this->directoryList = $directoryList;
        parent::__construct($context);
    }

    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->renderLayout();

        $datasetDatas = $this->getRequest()->getParam('general');
        if (is_array($datasetDatas)) {
            $resultRedirect = $this->resultRedirectFactory->create();
            $moduleDestDir = $this->moduleDirectory->getDir('Maas_DataSet') . '/data/' . $datasetDatas['basename'];
            $destDir = $this->directoryList->getPath('var') . '/Maas/dataset/' . $datasetDatas['basename'];
            if (!is_dir($destDir) && !is_dir($moduleDestDir)) {
                $filesToMove = $this->getFiles($destDir);

                $this->file->checkAndCreateFolder($destDir);
                foreach ($filesToMove as $file) {
                    move_uploaded_file($file['from'], $file['to']);
                }

            } else {
                $this->messageManager->addErrorMessage(__('The dataset with this name %1 already exists', $datasetDatas['basename']));
                return $resultRedirect->setPath('*/*/newAction');
            }

            return $resultRedirect->setPath('*/*/index');
        }
    }
}
