<?php

namespace Maas\DataSet\Console\Command;

use Exception;
use Maas\ImportExport\Model\Import\Catalog\Category;
use Maas\ImportExport\Model\Import\Catalog\Category\Cli\ImportModel\Proxy as ImportModelProxy;
use Maas\ImportExport\Model\Import\Catalog\Category\Cli\Publisher\Proxy as PublisherProxy;
use Maas\ImportExport\Model\Import\Catalog\Category\Consumer\Proxy as ConsumerProxy;
use Maas\Log\Model\ResourceModel\Report;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ImportCategories
 *
 * @package Maas\Fixture\Console\Command\RunCli
 * @codeCoverageIgnore
 */
class ImportCategories extends Command
{
    /**
     * @var ImportModelProxy
     */
    protected $category;

    /**
     * @var PublisherProxy
     */
    protected $publisher;

    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * @var ConsumerProxy
     */
    protected $consumer;

    /**
     * @var Report
     */
    protected $reportResource;

    /**
     * ImportCategories constructor.
     *
     * @param Filesystem $filesystem
     * @param ImportModelProxy $category
     * @param PublisherProxy $publisher
     * @param ConsumerProxy $consumer
     * @param Report $reportResource
     * @param string|null $name
     */
    public function __construct(
        Filesystem $filesystem,
        ImportModelProxy $category,
        PublisherProxy $publisher,
        ConsumerProxy $consumer,
        Report $reportResource,
        string $name = null
    ) {
        parent::__construct($name);
        $this->category = $category;
        $this->publisher = $publisher;
        $this->consumer = $consumer;
        $this->filesystem = $filesystem;
        $this->reportResource = $reportResource;
    }

    /**
     * @inheritdoc
     */
    protected function configure()
    {
        $this->setName('maas:dataset:import:categories')
            ->setDescription('Imports categories from location')
            ->addArgument(
                'dir-path',
                InputArgument::REQUIRED,
                'Directory'
            );
        parent::configure();
    }

    /**
     * @inheritdoc
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $directory = $this->filesystem->getDirectoryRead(DirectoryList::ROOT);
        $files = $directory->read($input->getArgument('dir-path'));
        foreach ($files as $file) {
            $output->write('<info>Importing ' . $file . '</info>');
            $fileData = json_decode(file_get_contents($directory->getAbsolutePath() . '/' . $file) ?? '', true);
            try {
                $this->category->setModeOverride("V1");
                $this->category->execute([
                    'items' => $fileData,
                    'totalItemCount' => count($fileData),
                    'itemsCount' => count($fileData),
                    'count' => count($fileData)
                ]);
                $report = $this->category->getReport();
                $this->reportResource->save($report);
                $reportId = $report->getId();
                $this->publisher->setEntityType('catalog_category');
                $this->publisher->setReportId($reportId);
                foreach ($fileData as &$item) {
                    $this->publisher->publish($item);
                }
                $this->publisher->publishRemaining();

                $messages = $this->publisher->getMessages();
                foreach ($messages as $message) {
                    $this->consumer->process($message);
                }
            } catch (Exception $e) {
                $output->write('<error>Importing ' . $e->getMessage() . '</error>');
            }
        }
    }
}
