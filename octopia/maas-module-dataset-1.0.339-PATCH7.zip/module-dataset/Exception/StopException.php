<?php
namespace Maas\DataSet\Exception;

use \Exception;

class StopException extends Exception
{

}