<?php

namespace Maas\Core\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface TokenInterface
 * @package Maas\Core\Api\Data
 * @codeCoverageIgnore
 */
interface TokenInterface extends ExtensibleDataInterface
{
    const ACCESS_TOKEN = 'access_token';

    const REFRESH_TOKEN = 'refresh_token';

    const TOKEN_TYPE = 'token_type';

    const EXPIRES_IN = 'expires_in';

    const REFRESH_EXPIRES_IN = 'refresh_expires_in';

    const SCOPE = 'scope';

    /**
     * @return String
     */
    public function getAccessToken();

    /**
     * @param string $token
     *
     * @return $this
     */
    public function setAccessToken($token);
    /**
     * @return String
     */
    public function getRefreshToken();

    /**
     * @param string $token
     *
     * @return $this
     */
    public function setRefreshToken($token);

    /**
     * @return string|null
     */
    public function getTokenType();

    /**
     * @param string $type
     *
     * @return $this
     */
    public function setTokenType($type);

    /**
     * @return string|null
     */
    public function getExpiredIn();

    /**
     * @param int $time
     *
     * @return $this
     */
    public function setExpiredIn($time);

    /**
     * @return string|null
     */
    public function getRefreshExpiredIn();

    /**
     * @param int $time
     *
     * @return $this
     */
    public function setRefreshExpiredIn($time);

    /**
     * @return string|null
     */
    public function getScope();

    /**
     * @param string $scope
     *
     * @return $this
     */
    public function setScope($scope);
}
