<?php

namespace Maas\Core\Api\Data;

/**
 * Interface Edition
 */
interface EditionInterface
{

    /**
     * Get Magento edition
     *
     * @return string
     */
    public function getEdition();

    /**
     * Get Link field
     *
     * @return string
     */
    public function getLinkField();

    /**
     * Is Enterprise edition
     *
     * @return string
     */
    public function isEnterprise();
}
