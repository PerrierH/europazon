<?php

namespace Maas\Core\Api;

use Maas\Core\Api\Data\TokenInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface TokenRepositoryInterface
 * @package Maas\Core\Api
 */
interface TokenRepositoryInterface
{
    /**
     * @param TokenInterface $token
     * @return TokenInterface
     */
    public function save(TokenInterface $token);

    /**
     * @param $id
     * @return TokenInterface
     */
    public function get($id);

    /**
     * @param TokenInterface $token
     */
    public function delete(TokenInterface $token);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return TokenInterface[]
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @return TokenInterface
     */
    public function getEnabledToken();
}
