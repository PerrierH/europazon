<?php
namespace Maas\Core\Api\RunCli;

use Maas\Core\Api\RunCli\MessageInterface;

/**
 * Interface ConsumerInterface
 *
 * @package Maas\Core\Api\RunCli
 */
interface ConsumerInterface
{

    /**
     * @param \Maas\Core\Api\RunCli\MessageInterface $message
     *
     * @return mixed
     */
    public function process(MessageInterface $message);
}
