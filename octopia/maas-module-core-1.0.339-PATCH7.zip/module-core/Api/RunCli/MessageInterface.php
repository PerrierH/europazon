<?php
namespace Maas\Core\Api\RunCli;

/**
 * Interface MessageInterface
 *
 * @package Maas\Core\Api\RunCli
 */
interface MessageInterface
{
    /**
     * @param string $message
     * @return void
     */
    public function setMessage(string $message);

    /**
     * @return string
     */
    public function getMessage();
}
