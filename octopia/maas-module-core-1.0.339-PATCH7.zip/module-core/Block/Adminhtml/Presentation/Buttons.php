<?php

namespace Maas\Core\Block\Adminhtml\Presentation;

use League\CommonMark\CommonMarkConverter;
use Maas\Core\Model\Config;
use Magento\Backend\Block\Widget\Button;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Filesystem\Directory\ReadFactory;
use Magento\Framework\Module\Dir\Reader;
use Magento\Framework\View\Element\Template;

/**
 * Class Buttons
 *
 * @package Maas\Core\Block\Adminhtml\Presentation
 */
class Buttons extends Template
{
    const CLASS_CSS = 'action-primary button-presentation';

    /**
     * @return string
     */
    public function getButton()
    {
        $data = [
            'class' => self::CLASS_CSS,
            'href' => $this->getUrl('adminhtml/system_config/edit/section/maas'),
            'title' => __('Configuration')
        ];
        return $this->getButtonHtml($data);
    }

    /**
     * Return custom button HTML
     *
     * @param array $data Button params
     *
     * @return string
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @codeCoverageIgnore
     */
    protected function getButtonHtml($data)
    {
        $html = '<a';
        $html .= ' class="' . (isset($data['class']) ? $data['class'] : '') . '"';
        $html .= isset($data['href']) ? ' href="' . $data['href'] . '"' : '';
        $html .= '>';
        $html .= isset($data['title']) ? $data['title'] : '';
        return $html . '</a>';
    }
}
