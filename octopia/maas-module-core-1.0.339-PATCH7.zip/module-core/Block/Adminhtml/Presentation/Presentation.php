<?php

namespace Maas\Core\Block\Adminhtml\Presentation;

use League\CommonMark\CommonMarkConverter;
use Maas\Core\Model\Config;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Filesystem\Directory\ReadFactory;
use Magento\Framework\Module\Dir\Reader;
use Magento\Framework\View\Element\Template;

/**
 * Class Presentation
 * @package Maas\Core\Block\Adminhtml\Presentation
 */
class Presentation extends Template
{
    /**
     * @var Reader
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $moduleReader;

    /**
     * @var ReadFactory
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    private $readFactory;

    /**
     * @var CommonMarkConverter
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $commonMarkConverter;

    /**
     * Releases constructor.
     * @param Template\Context $context
     * @param Reader $moduleReader
     * @param ReadFactory $readFactory
     * @param CommonMarkConverter $commonMarkConverter
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Reader $moduleReader,
        ReadFactory $readFactory,
        CommonMarkConverter $commonMarkConverter,
        $data = []
    ) {
        $this->moduleReader = $moduleReader;
        $this->readFactory = $readFactory;
        $this->commonMarkConverter = $commonMarkConverter;
        parent::__construct($context, $data);
    }

    /**
     * @param string $type
     * @return string
     */
    protected function getModuleDir($type = '')
    {
        return $this->moduleReader->getModuleDir($type, Config::MODULE_NAME);
    }

    /**
     * Function to read ChangeLog file
     * @return string
     * @throws LocalizedException
     * @throws FileSystemException
     * @throws ValidatorException
     */
    protected function getReleaseFilePath()
    {
        $directoryRead = $this->readFactory->create($this->getModuleDir());
        if (!$directoryRead->isExist(Config::MODULE_NAME) && !$directoryRead->isFile(Config::RELEASE_FILENAME)) {
            throw new LocalizedException(
                __('The "%1" file doesn\'t exist. Verify the file and try again.', Config::RELEASE_FILENAME)
            );
        }
        return $directoryRead->readFile(Config::RELEASE_FILENAME);
    }

    /**
     * Function to display file content in HTML format
     * @return string|null
     */
    public function displayRelease()
    {
        try {
            /* Get Changelog.md content */
            return $this->commonMarkConverter->convertToHtml($this->getReleaseFilePath());
        } catch (LocalizedException $e) {
            return null;
        }
    }
}
