<?php

namespace Maas\Core\Console\Command;

use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Core\Model\Parallelization\Parallelization;
use Maas\ImportExport\Model\Config\Proxy as ConfigModel;
use Maas\Log\Api\Data\ReportInterface;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime as DateTime;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class AbstractParallelEntityProcess
 *
 * @package Maas\Core\Console\Command
 * @codeCoverageIgnore No logic
 */
abstract class AbstractParallelEntityProcess extends Command
{
    use Parallelization;

    /**
     * @var string
     */
    protected $commandName = '';

    /**
     * @var string
     */
    protected $consumerCommand = '';

    /**
     * @var string
     */
    protected $commandDescription = '';

    /**
     * @var string
     */
    protected $entityType = '';

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;

    /**
     * @var DateTime
     */
    protected $dateTime;

    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var ConfigModel
     */
    protected $configModel;

    protected ReportManagementInterface $reportManagement;

    /**
     * @param SerializerInterface $serializer
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param DateTime $dateTime
     * @param CacheInterface $cache
     * @param ConfigModel $configModel
     */
    public function __construct(
        SerializerInterface $serializer,
        ReportRepositoryInterface    $reportRepository,
        ReportManagementInterface    $reportManagement,
        DateTime            $dateTime,
        CacheInterface      $cache,
        ConfigModel         $configModel
    )
    {
        parent::__construct();
        $this->serializer = $serializer;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->dateTime = $dateTime;
        $this->cache = $cache;
        $this->configModel = $configModel;
    }

    /**
     * Ctrl-C
     */
    public function doInterrupt()
    {
        $this->updateReportStatus();
        exit;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure(): void
    {
        parent::configure();
        self::configureParallelization($this);
        $this->setName($this->commandName)
            ->setDescription($this->commandDescription);
        $this->addOption(
            'limit',
            'l',
            InputOption::VALUE_OPTIONAL,
            'limit in api call',
            null
        )->addOption(
            'processes',
            'p',
            InputOption::VALUE_OPTIONAL,
            'The number of parallel processes to run',
            null
        )->addOption(
            'scheduleId',
            's',
            InputOption::VALUE_OPTIONAL,
            'The schedule id from cron',
            null
        );
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @throws LocalizedException
     */
    protected function runBeforeFirstCommand(InputInterface $input, OutputInterface $output): void
    {
        //Do nothing
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return int
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        pcntl_async_signals(true);
        pcntl_signal(SIGINT, [$this, 'doInterrupt']);
        pcntl_signal(SIGTERM, [$this, 'doInterrupt']);
        if ($this->isModuleEnabled()) {
            // @codeCoverageIgnoreStart
            if ($input->getOption('child')) {
                $this->executeChildProcess($input, $output);
            } else {
                $this->executeMasterProcess($input, $output);
            }
            // @codeCoverageIgnoreEnd
        } else {
            $output->writeln('<info>You cannot execute this command because Maas module is disabled </info>');
        }
        return 0;
    }

    /**
     * @return bool
     */
    protected function isModuleEnabled()
    {
        return false;
    }

    /**
     * @return null
     * @codeCoverageIgnore
     */
    protected function getContainer()
    {
        return null;
    }

    /**
     * @param int $count
     *
     * @return string
     */
    protected function getItemName(int $count): string
    {
        return 1 === $count ? 'page' : 'pages';
    }

    /**
     * Returns the number of items to process in a batch.
     */
    protected function getBatchSize(): int
    {
        $limit = $this->getLimit();
        if (!$limit) {
            return static::BATCH_SIZE;
        }
        return min($this->getLimit(), static::BATCH_SIZE);
    }

    /**
     * Returns the number of items to process per child process.
     */
    protected function getSegmentSize(): int
    {
        return static::SEGMENT_SIZE;
    }

    /**
     * @param $scheduleId
     *
     * @return array
     */
    protected function getArgsScheduleId($scheduleId)
    {
        if ($scheduleId == 0) {
            return null;
        }
        return [
            'scheduleId' => $scheduleId
        ];
    }

    /**
     * The method to start of report in the model
     */
    abstract protected function startReport(?int $scheduleId) : ReportInterface;

    /**
     * The report id key for cache
     */
    abstract protected function getReportIdKey() : string;

    /**
     * Returns the limit of items to process
     */
    abstract protected function getLimit() : int;

    /**
     * Returns the number of process to execute in parallelization
     */
    abstract protected function getProcessesNumber() : int;

    /**
     * Get the started job from database
     */
    abstract protected function getStartedImportReportObject() : ?ReportInterface;

    /**
     * Init of the report
     */
    protected function initReport(InputInterface $input) : ?ReportInterface
    {
        $scheduleId = $input->getOption('scheduleId');
        $report = $this->startReport($scheduleId);
        $this->saveReportIdInCache($report->getId());
        $limit = $input->getOption('limit') ?? $this->getLimit();
        $input->setOption('limit', (string)$limit);
        $process = $input->getOption('processes') ?? $this->getProcessesNumber();
        if ($limit) {
            $process = min($process, ceil($limit/$this->getBatchSize()));
        }
        $input->setOption('processes', (string)$process);
        return $report;
    }

    /**
     * Save the report id in the cache
     */
    protected function saveReportIdInCache(int $reportId) : void
    {
        $this->cache->save($reportId, $this->getReportIdKey());
    }

    /**
     * Load the report id from cache
     */
    public function loadReportIdFromCache(): ?int
    {
        $reportId = $this->cache->load($this->getReportIdKey());
        return $reportId ?? null;
    }

    /**
     * Stop the report
     */
    protected function stopReport(?ReportInterface $report) : void
    {
        if (!$report || !$report->getId()) {
            $report = $this->getReport();
        }
        if ($report->getId()) {
            $this->reportManagement->close($report);
        }
    }

    /**
     * Get started report from cache or from the database
     */
    protected function getReport() : ReportInterface
    {
        $reportId = $this->loadReportIdFromCache();
        if ($reportId == null || $reportId == 0) {
            $currentReport = $this->getStartedImportReportObject();
            $reportId = $currentReport->getId();
            $this->saveReportIdInCache($reportId);
            return $currentReport;
        }
        return $this->reportRepository->get($reportId);
    }

    /**
     * Set Report Status to Failed when Command Line interrupted or Processes Killed
     */
    private function updateReportStatus()
    {
        $report = $this->getReport();
        if ($report->getId()) {
            $report->setErrorItemsCount($report->getItemsCount() - ($report->getSuccessItemsCount() + $report->getWarningItemsCount()));
            $report->setMessage('Command interrupted');
            $this->stopReport($report);
        }
    }

    protected function beforeNextProcess(ReportInterface $report, string $message, InputInterface $input, ?int $count = 0): bool
    {
        $report->setItemsCount($count);
        $report->log(__($message, $count));
        $this->reportRepository->save($report);
        if (!$count) {
            $this->stopReport($report);
            return false;
        }
        return true;
    }

    protected function afterNextProcess(string $successMessage = '', string $errorMessage = ''): void
    {
        $report = $this->getReport();
        $errorItemCount = $report->getErrorItemsCount();
        $successItemCount = $report->getSuccessItemsCount();
        if ($successItemCount && $successMessage != '') {
            $report->log(__($successMessage, $successItemCount));
        }
        if ($errorItemCount && $errorMessage != '') {
            $report->log(__($errorMessage, $errorItemCount));
        }
        $this->stopReport($report);
    }
}
