<?php

namespace Maas\Core\Console\Command\RunCli;

use Maas\Core\Model\Parallelization\ProcessManager;
use Maas\Core\Model\Config\Proxy as ConfigProxy;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Process\Process;
use Symfony\Component\Console\Input\InputOption;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Catalog
 */
class Consumer extends Command
{
    const MAX_MESSAGES = 1;
    protected $commandName = 'maas:runcli:consumer';
    protected $commandDescription = 'Consumes scheduled cli messages already in queue';

    /**
     * @var array
     */
    protected $modules;
    /**
     * @var ProcessManager
     */
    protected $processManager;
    /**
     * @var ConfigProxy
     */
    private $configModel;

    /**
     * Consumer constructor.
     *
     * @param ModuleListProxy $moduleList
     * @param ConfigProxy $configModel
     * @param ProcessManager $processManager
     */
    public function __construct(
        ModuleListProxy $moduleList,
        ConfigProxy $configModel,
        ProcessManager $processManager,
        $name = null
    ) {
        $this->configModel = $configModel;
        $this->processManager = $processManager;
        $this->modules = $moduleList->getAll();
        parent::__construct($name);
    }

    /**
     * @inheritDoc
     */
    protected function configure()
    {
        $this->setName($this->commandName)
            ->setDescription($this->commandDescription)
            ->addOption(
                'scheduleId',
                's',
                InputOption::VALUE_OPTIONAL,
                'The schedule id from cron',
                null
            );
        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return int|void|null
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if ($this->configModel->isModuleEnabled()) {
            $processes = [];
            $consumerProcesses = 1;
            $connectionMethod = $this->configModel->getMessageQueueConnectionMethod();
            $cmd = 'queue:consumers:start';
            $mq_suffix = 'consumer';
            $limitOption = 'max-messages';

            $format = 'php bin/magento %s maas_core.run_cli.%s.%s --%s=%d';
            /** Processus to execute queue consumers start command */
            for ($i = 0; $i < $consumerProcesses; $i++) {
                $command = sprintf(
                    $format,
                    $cmd,
                    $connectionMethod,
                    $mq_suffix,
                    $limitOption,
                    self::MAX_MESSAGES
                );

                $newProcess = $this->newProcess($command);
                $newProcess->setTimeout(null);
                $processes [] = $newProcess;
            }
            if (count($processes) > 1) {
                $pollingInterval = 1000; // microseconds
                /** Run all processes */
                $this->processManager->runParallel($output, $processes, sizeof($processes), $pollingInterval);
            } else {
                /** @var Process $process */
                $process = reset($processes);
                $process->run();
            }
        }
    }

    /**
     * @param string $input
     *
     * @return Process
     */
    protected function newProcess(string $input)
    {
        return new Process($input);
    }
}
