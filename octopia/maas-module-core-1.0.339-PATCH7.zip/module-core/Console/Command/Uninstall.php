<?php

namespace Maas\Core\Console\Command;

use Exception;
use Maas\Core\Model\Uninstall\ModuleRegistryUninstaller;
use Maas\Core\Model\Uninstall\ModuleUninstaller\Proxy;
use Maas\Core\Model\Uninstall\Indexer;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\Console\MaintenanceModeEnabler;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Console\Cli;
use Magento\Framework\Module\DependencyChecker;
use Magento\Framework\Module\FullModuleList;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Question\ConfirmationQuestion;
use Throwable;

/**
 * Command to backup code base and user data
 * @package Maas\Core\Console\Command
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @codeCoverageIgnore
 */
class Uninstall extends Command
{
    /**
     * Names of input arguments or options
     */
    const INPUT_KEY_MODULES = 'module';
    /**
     * @var CacheInterface
     */
    protected $cache;
    /**
     * @var Indexer
     */
    protected $indexer;
    /**
     * @var ModuleRegistryUninstaller
     */
    private $moduleRegistryUninstaller;
    /**
     * @var Proxy
     */
    private $moduleUninstaller;
    /**
     * Dependency Checker
     *
     * @var DependencyChecker
     */
    private $dependencyChecker;
    /**
     * Full module list
     *
     * @var FullModuleList
     */
    private $fullModuleList;
    /**
     * @var MaintenanceModeEnabler
     */
    private $maintenanceModeEnabler;
    /**
     * @var ResourceConnection
     */
    private $resource;


    /**
     * Uninstall constructor.
     * @param FullModuleList $fullModuleList
     * @param DependencyChecker $dependencyChecker
     * @param MaintenanceModeEnabler $maintenanceModeEnabler
     * @param ResourceConnection $resource
     * @param ModuleRegistryUninstaller $moduleRegistryUninstaller
     * @param Proxy $moduleUninstaller
     * @param CacheInterface $cache
     * @param Indexer $indexer
     * @param string|null $name
     */
    public function __construct(
        FullModuleList $fullModuleList,
        DependencyChecker $dependencyChecker,
        MaintenanceModeEnabler $maintenanceModeEnabler,
        ResourceConnection $resource,
        ModuleRegistryUninstaller $moduleRegistryUninstaller,
        Proxy $moduleUninstaller,
        CacheInterface $cache,
        Indexer $indexer,
        string $name = null
    ) {
        $this->fullModuleList = $fullModuleList;
        $this->dependencyChecker = $dependencyChecker;
        $this->maintenanceModeEnabler = $maintenanceModeEnabler;
        $this->resource = $resource;
        $this->moduleRegistryUninstaller = $moduleRegistryUninstaller;
        $this->moduleUninstaller = $moduleUninstaller;
        $this->cache = $cache;
        $this->indexer = $indexer;
        parent::__construct($name);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->addArgument(
            self::INPUT_KEY_MODULES,
            InputArgument::IS_ARRAY | InputArgument::OPTIONAL,
            'Name of the module'
        );

        $this->setName('maas:uninstall')
            ->setDescription('Maas Catalog Uninstall command');

        parent::configure();
    }


    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|mixed|null
     * @throws Throwable
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        /* Select Maas modules from setup_modules table */
        $maas_modules = $this->getMaasModulesFromDb();
        /* Get maas uninstall modules argument */
        $modules = $input->getArgument(self::INPUT_KEY_MODULES) ?: $maas_modules;
        // check that modules in argument are Maas Modules
        $modules = array_intersect($maas_modules, $modules);
        if (empty($modules)) {
            $output->writeln('Cannot execute uninstall command because you try to uninstall no Maas module(s)');
        }

        // check dependencies
        $dependencyMessages = $this->checkDependencies($modules);
        if (!empty($dependencyMessages)) {
            $output->writeln($dependencyMessages);
        }

        if (empty($modules) || !empty($dependencyMessages)) {
            // we must have an exit code higher than zero to indicate something was wrong
            return Cli::RETURN_FAILURE;
        }

        $helper = $this->getHelper('question');
        $question = new ConfirmationQuestion(
            'You are about to remove module database data and/or tables. Are you sure?[y/N]',
            false
        );
        if (!$helper->ask($input, $output, $question) && $input->isInteractive()) {
            return Cli::RETURN_FAILURE;
        }

        /* Enable Maintenance Mode*/
        return $this->maintenanceModeEnabler->executeInMaintenanceMode(
            function () use ($output, $modules) {
                try {
                    $this->removeData($modules, $output);
                    $this->moduleRegistryUninstaller->removeModulesFromDb($output, $modules);
                    $this->moduleRegistryUninstaller->removeModulesFromDeploymentConfig($output, $modules);
                    $this->indexer->execute($output);
                    $output->writeln(
                        '<info>Cleaning Magento Cache</info>'
                    );
                    $this->cache->clean();
                    return Cli::RETURN_SUCCESS;
                } catch (Exception $e) {
                    $output->writeln('<error>' . $e->getMessage() . '</error>');
                    $output->writeln('<error>Please disable maintenance mode after you resolved above issues</error>');
                    return Cli::RETURN_FAILURE;
                }
            },
            $output,
            true
        );
    }

    /**
     * function to get all Maas modules from setup_module table
     * @return array
     */
    private function getMaasModulesFromDb()
    {
        $maas_modules = [];
        $connection = $this->resource->getConnection();
        $results = $connection->select()->from('setup_module')->where('module like ?', "Maas%")->query()->fetchAll();
        foreach ($results as $result) {
            $maas_modules[] = $result['module'];
        }

        return $maas_modules;
    }

    /**
     * Check for dependencies to module, return error messages
     *
     * @param string[] $modules
     * @return string[]
     */
    private function checkDependencies($modules)
    {
        $messages = [];
        $dependencies = $this->dependencyChecker->checkDependenciesWhenDisableModules(
            $modules,
            $this->fullModuleList->getNames()
        );
        foreach ($dependencies as $module => $dependingModules) {
            if (!empty($dependingModules)) {
                $messages[] =
                    "<error>Cannot uninstall module '$module' because the following module(s) depend on it:</error>" .
                    PHP_EOL . "\t<error>" . implode('</error>' . PHP_EOL . "\t<error>", array_keys($dependingModules)) .
                    "</error>";
            }
        }
        return $messages;
    }

    /**
     * Invoke remove data routine in each specified module
     *
     * @param string[] $modules
     * @param OutputInterface $output
     * @return void
     */

    private function removeData(array $modules, OutputInterface $output)
    {
        $output->writeln('<info>Removing data</info>');
        $this->moduleUninstaller->uninstallData($output, $modules);
    }
}
