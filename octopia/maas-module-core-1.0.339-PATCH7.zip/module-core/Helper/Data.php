<?php

namespace Maas\Core\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Exception\NotFoundException;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Data
 *
 * @package Maas\Core\Helper
 * We dont need to test autoloader
 * @codeCoverageIgnore
 */
class Data extends AbstractHelper
{
     const MAAS_ENABLED = 'maas_general/general/enable';

    /**
     * Function to check if CommanMark Library is installed
     * @return int
     * @throws NotFoundException
     */
    public function isCommonMarkLibExists()
    {
        if (!class_exists('League\CommonMark\CommonMarkConverter')) {
            throw new NotFoundException(
                (__('League\CommonMark library required to display Release notes for the Maas Module. Try running composer require league/commonmark.'))
            );
        }

        return 1;
    }
}
