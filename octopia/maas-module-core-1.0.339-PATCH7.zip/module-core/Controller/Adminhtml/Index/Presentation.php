<?php

namespace Maas\Core\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context as ContextAlias;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\View\Result\PageFactory;
use Maas\Core\Helper\Data as Helper;

/**
 * Class Presentation
 * @package Maas\Core\Controller\Adminhtml\Index
 */
class Presentation extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var Helper
     */
    protected $helper;

    /**
     * Presentation constructor.
     * @param ContextAlias $context
     * @param PageFactory $resultPageFactory
     * @param Helper $helper
     */
    public function __construct(
        ContextAlias $context,
        PageFactory $resultPageFactory,
        Helper $helper
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->helper = $helper;
    }

    /**
     * Core presentation page
     *
     * @return ResultInterface
     */
    public function execute()
    {
        /** @var Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        try {
            //check if CommanMark Library is installed
            if($this->helper->isCommonMarkLibExists()) {
                $resultPage->setActiveMenu('Maas_Core::presentation');
                $resultPage->addBreadcrumb(__('Octopia Marketplace for magento 2'), __('Presentation'));
                $resultPage->getConfig()->getTitle()->prepend(__('Octopia Marketplace for magento 2'));
            }
        } catch (NotFoundException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('adminhtml/*');
            return $resultRedirect;
        }
        return $resultPage;
    }

    /**
     * Acl check for admin
     * protected method and the function called
     * is already tested by magento
     * @codeCoverageIgnore
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Maas_Core::presentation');
    }
}
