<?php

namespace Maas\Core\Test;

/**
 * Interface ConstantsInterface
 *
 * Constants used in builders, both builders and abstract test cases implement this
 *
 * @package Maas\Core\Test
 * @codeCoverageIgnore Interface used in tests, will not be tested itself
 */
interface ConstantsInterface
{
    const RETURN_VALUE = 0;
    const RETURN_REFERENCE = 1;
    const RETURN_CALLBACK = 2;
    const RETURN_SELF = 3;
    const RETURN_ARGUMENT = 4;
    const RETURN_MAP = 5;
    const RETURN_CONSECUTIVE = 6;
    const THROW_EXCEPTION = 7;
}
