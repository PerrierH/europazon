<?php

namespace Maas\Core\Test\Builder;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class AnyBuilder
 * Generic builder for classes that are not frequently used
 *
 * @package Maas\Core\Test\Builder
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class AnyBuilder implements BuilderInterface
{
    use BuilderTrait;

    protected $className;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];
        return $this->createMock($this->className, $defaultData);
    }

    public static function create(TestCase $testCase, array $data = [])
    {
        throw new \Exception(__('This builder does not support create(). Call createForClass() instead.'));
    }

    public static function createForClass(TestCase $testCase, string $className, array $data = [])
    {
        $self = new static();
        $self->testCase = $testCase;
        $self->objectManager = new ObjectManager($self->testCase);
        $self->setClassName($className);
        $self->initData();
        $self->addConfig($data);
        return $self;
    }

    /**
     * @param string $className
     * @return $this
     */
    protected function setClassName(string $className)
    {
        $this->className = $className;
        return $this;
    }
}
