<?php

namespace Maas\Core\Test\Builder;

use Exception;
use Maas\Core\Model\Http\Client;
use Maas\Core\Model\Http\ClientFactory;
use PHPUnit\Framework\MockObject\MockObject;
use Zend_Http_Response;

/**
 * Class AbstractApiBuilder
 *
 * @package Maas\ImportExport\Test\Builder\Model
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class ZendClientFactoryBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @param array $data
     *
     * @return $this
     */
    public function addConfig(array $data)
    {
        $this->data = array_merge($this->data, $data);
        return $this;
    }

    /**
     * @return MockObject
     */
    public function build()
    {
        if (is_array($this->data['request_body'])) {
            $returnBodyValue = [$this->testCase->any(), $this->data['request_body'], AnyBuilder::RETURN_CONSECUTIVE];
        } else {
            $returnBodyValue = [$this->testCase->any(), $this->data['request_body']];
        }
        if (is_array($this->data['request_status'])) {
            $returnStatusValue = [
                $this->testCase->any(),
                $this->data['request_status'],
                AnyBuilder::RETURN_CONSECUTIVE
            ];
        } else {
            $returnStatusValue = [$this->testCase->any(), $this->data['request_status']];
        }


        $requestMock = AnyBuilder::createForClass(
            $this->testCase,
            Zend_Http_Response::class,
            [
                'getBody' => $returnBodyValue,
                'getStatus' => $returnStatusValue,
            ]
        )->build();

        $httpClient = $this->testCase->getMockBuilder(Client::class)
            ->disableOriginalConstructor()
            ->getMock();
        $httpClient->expects($this->testCase->any())->method('setUri')->willReturn('');
        $httpClient->expects($this->testCase->any())->method('setHeaders')->willReturn('');
        $httpClient->expects($this->testCase->any())->method('setMethod')->willReturn('');
        $httpClient->expects($this->testCase->any())->method('setRawData')->willReturn('');
        if ($this->data['request_throw_exception'] === true) {
            $httpClient->expects($this->testCase->any())->method('request')->willReturnCallback(function () {
                throw new Exception('Exception message');
            });
        } else {
            $httpClient->expects($this->testCase->any())->method('request')->willReturn($requestMock);
        }

        $lastResponseMock = AnyBuilder::createForClass(
            $this->testCase,
            Zend_Http_Response::class,
            [
                'getBody' => $returnBodyValue,
                'getStatus' => $returnStatusValue,
                'getMessage' => [$this->testCase->any(), 'Message']
            ]
        )->build();
        $httpClient->expects($this->testCase->any())->method('getLastResponse')->willReturn($lastResponseMock);

        $httpClientFactory = $this->testCase->getMockBuilder(ClientFactory::class)
            ->setMethods([
                'create'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $httpClientFactory->expects($this->testCase->any())->method('create')->willReturn($httpClient);

        return $httpClientFactory;
    }

    private function initData()
    {
        $this->data = [
            'request_throw_exception' => false,
            'request_body' => '["test","data"]',
            'request_status' => 200
        ];
    }
}
