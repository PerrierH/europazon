<?php

namespace Maas\Core\Test\Builder\Product;

use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\BuilderInterface;
use Magento\Catalog\Model\Product;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ProductBuilder
 *
 * @package Maas\Core\Test\Builder\Product
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class ProductBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [
            'getMaasSyncDate' => [$this->testCase->any(), '11/02/10'],
        ];

        return $this->createMock(Product::class, $defaultData);
    }
}
