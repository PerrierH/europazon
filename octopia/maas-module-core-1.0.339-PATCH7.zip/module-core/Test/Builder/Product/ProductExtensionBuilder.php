<?php

namespace Maas\Core\Test\Builder\Product;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Catalog\Api\Data\ProductExtensionInterface;
use Magento\Catalog\Model\Product;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ProductExtensionBuilder
 *
 * @package Maas\Core\Test\Builder\Product
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class ProductExtensionBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [];

        return $this->createMock(ProductExtensionInterface::class, $defaultData);
    }
}
