<?php

namespace Maas\Core\Test\Builder\Order;

use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\BuilderInterface;
use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Sales\Model\Order\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class OrderItemBuilder
 *
 * @package Maas\Core\Test\Builder\Order
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class OrderItemBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [
            'getProductId' => [$this->testCase->any(), 1],
            'getName' => [$this->testCase->any(), 'productName'],
            'getQtyOrdered' => [$this->testCase->any(), 2],
            'getPriceInclTax' => [$this->testCase->any(), 125],
            'getPrice' => [$this->testCase->any(), 104.2],
            'getTaxPercent' => [$this->testCase->any(), 20],
            'getTaxAmount' => [$this->testCase->any(), 0],
        ];
        return $this->createMock(
            $this->getClassToInstantiate(OrderItemInterface::class, Item::class),
            $defaultData
        );
    }
}
