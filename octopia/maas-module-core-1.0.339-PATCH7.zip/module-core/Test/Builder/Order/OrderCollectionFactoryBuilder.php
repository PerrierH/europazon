<?php

namespace Maas\Core\Test\Builder\Order;

use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\BuilderInterface;
use Magento\Sales\Model\ResourceModel\Order\Collection as OrderCollection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Maas\Core\Test\Builder\Order\OrderCollectionBuilder;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class OrderCollectionFactoryBuilder
 *
 * @package Maas\Core\Test\Builder\Order
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class OrderCollectionFactoryBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $mock = $this->createMock(OrderCollectionFactory::class, $this->data);
        $mock->expects($this->testCase->any())->method('create')->willReturn($this->data['create']);
        return $mock;
    }

    /**
     * @param OrderCollection|null $orderCollection
     *
     * @return $this
     */
    public function withCollection(OrderCollection $orderCollection = null)
    {
        if ($orderCollection == null) {
            $orderCollection = OrderCollectionBuilder::create($this->testCase)->withOrders()->build();
        }
        $this->addConfig([
            'create' => [$this->testCase->any(), $orderCollection]
        ]);

        return $this;
    }
}
