<?php

namespace Maas\Core\Test\Builder\Order;

use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Magento\Sales\Model\ResourceModel\Order\Collection as OrderCollection;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class OrderCollectionBuilder
 *
 * @package Maas\Core\Test\Builder\Order
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class OrderCollectionBuilder implements BuilderInterface
{
    use BuilderTrait;


    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        return $this->createMock(OrderCollection::class, $this->data);
    }

    /**
     * @param array|null $orders
     *
     * @return $this
     */
    public function withOrders(array $orders = null)
    {
        if (!is_array($orders)) {
            $orders = [
                OrderBuilder::create($this->testCase)->build()
            ];
        }
        $this->addConfig([
            'getItems' => [$this->testCase->any(), $orders],
            'addFieldToFilter' => []
        ]);

        return $this;
    }
}
