<?php

namespace Maas\Core\Test\Builder\Order;

use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\Address\AddressBuilder;
use Maas\Core\Test\Builder\Product\ProductBuilder;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment;
use PHPUnit_Framework_MockObject_MockObject;
use stdClass;

/**
 * Class OrderBuilder
 *
 * @package Maas\Core\Test\Builder\Order
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class OrderBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [
            'getId' => [$this->testCase->any(), '1'],
            'getIncrementId' => [$this->testCase->any(), 'IncrementId1'],
            'getCreatedAt' => [$this->testCase->any(), '28/08/2020'],
            'getOrderCurrencyCode' => [$this->testCase->any(), 'EUR'],
            'getDiscountAmount' => [$this->testCase->any(), '50'],
            'getGrandTotal' => [$this->testCase->any(), '250'],
            'getSubtotal' => [$this->testCase->any(), '208.33'],
            'getShippingAmount' => [$this->testCase->any(), '10'],
            'getCustomerId' => [$this->testCase->any(), 2],
            'getShippingMethod' => [$this->testCase->any(), 'Standard'],
            'addCommentToStatusHistory' => [$this->testCase->any(), true],
            'getStatus' => [$this->testCase->any(), 'processing'],
        ];

        return $this->createMock(
            $this->getClassToInstantiate(OrderInterface::class, Order::class),
            $defaultData
        );
    }

    /**
     * @param string $type
     * @param array $data
     *
     * @return $this
     */
    public function withAddress(string $type, $data = [])
    {
        $this->addConfig([
            'get' . $type => [
                $this->testCase->any(),
                AddressBuilder::create($this->testCase)->addConfig($data)->build()
            ]
        ]);

        return $this;
    }

    /**
     * @param array $datas
     *
     * @return $this
     */
    public function withItems(array $datas)
    {
        $items = [];
        foreach ($datas as $data) {
            $item = OrderItemBuilder::create($this->testCase)->addConfig(
                $data
            )->build();
            $items[] = $item;
        }

        $this->addConfig([
            'getItems' => [
                $this->testCase->any(),
                $items
            ]
        ]);
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return $this
     */
    public function withProductItems(array $datas = [['item' => [], 'product' => []]])
    {
        $items = [];
        foreach ($datas as $data) {
            $item = OrderItemBuilder::create($this->testCase)->addConfig(
                $data['item']
            )->addConfig(
                [
                    'getProduct' => [
                        $this->testCase->any(),
                        ProductBuilder::create($this->testCase)->addConfig(
                            $data['product']
                        )->build()
                    ]
                ]
            )->build();
            $items[] = $item;
        }
        $this->addConfig([
            'getItems' => [
                $this->testCase->any(),
                $items
            ]
        ]);
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    private function buildOrderExtensionInterface(array $datas)
    {
        $defaultData = [
            'getExtraInfo' => [$this->testCase->any(), $this->buildSalesOrderInfo($datas)],
        ];

        return $this->createMock(OrderExtensionInterface::class, $defaultData);
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    private function buildSalesOrderInfo(array $datas)
    {
        $defaultData = [
            'getMaasSellerId' => [$this->testCase->any(), 6],
            'getMaasSellerName' => [$this->testCase->any(), 'Cdiscount'],
        ];
        $data = array_merge($defaultData, $datas);
        $dataKeys = array_keys($data);
        $mock = $this->testCase->getMockBuilder(SalesOrderInfo::class)
            ->setMethods($dataKeys)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();

        foreach ($data as $methodName => list($frequency, $value)) {
            $mock->expects($frequency)->method($methodName)->willReturn($value);
        }

        return $mock;
    }

    /**
     * @param array $datas
     *
     * @return $this
     */
    public function withSalesOrderInfo(array $datas = [])
    {
        $this->addConfig([
            'getExtensionAttributes' => [$this->testCase->any(), $this->buildOrderExtensionInterface($datas)]
        ]);
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    private function builderPayment(array $datas)
    {
        $defaultData = [
            'getMethod' => [$this->testCase->any(), 'test_method'],
        ];

        $mock = $this->createMockFromDataArrays(
            Payment::class,
            $defaultData,
            $datas
        );

        return $mock;
    }

    /**
     * @param array $datas
     *
     * @return $this
     */
    public function withPayment(array $datas = [])
    {
        $this->addConfig([
            'getPayment' => [$this->testCase->any(), $this->builderPayment($datas)]
        ]);
        return $this;
    }
}
