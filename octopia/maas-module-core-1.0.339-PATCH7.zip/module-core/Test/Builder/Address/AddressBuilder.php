<?php

namespace Maas\Core\Test\Builder\Address;

use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\BuilderInterface;
use Magento\Sales\Model\Order\Address;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class AddressBuilder
 *
 * @package Maas\Core\Test\Builder\Address
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class AddressBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [
            'getPrefix' => [$this->testCase->any(), 'Mr'],
            'getLastname' => [$this->testCase->any(), 'Testeur'],
            'getFirstname' => [$this->testCase->any(), 'Test'],
            'getCompany' => [$this->testCase->any(), 'Clever'],
            'getStreetLine' => [$this->testCase->any(), '21 rue du test'],
            'getPostcode' => [$this->testCase->any(), '31000'],
            'getCity' => [$this->testCase->any(), 'Toulouse'],
            'getRegion' => [$this->testCase->any(), 'Haute Garonne'],
            'getCountryId' => [$this->testCase->any(), 'FR'],
            'getTelephone' => [$this->testCase->any(), '0650505050'],
            'getEmail' => [$this->testCase->any(), 't@test.mail'],
        ];
        return $this->createMock(Address::class, $defaultData);
    }
}
