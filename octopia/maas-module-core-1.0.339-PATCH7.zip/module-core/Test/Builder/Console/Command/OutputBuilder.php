<?php

namespace Maas\Core\Test\Builder\Console\Command;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Customer\Model\Customer;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class OutputBuilder
 *
 * @package Maas\Core\Test\Builder\Customer
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class OutputBuilder implements BuilderInterface
{
    use BuilderTrait;

    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(OutputInterface::class, OutputInterface::class),
            $defaultData
        );
    }
}
