<?php

namespace Maas\Core\Test\Builder\Customer;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Customer\Model\Customer;

/**
 * Class CustomerBuilder
 *
 * @package Maas\Core\Test\Builder\Customer
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CustomerBuilder implements BuilderInterface
{
    use BuilderTrait;

    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(CustomerInterface::class, Customer::class),
            $defaultData
        );
    }
}