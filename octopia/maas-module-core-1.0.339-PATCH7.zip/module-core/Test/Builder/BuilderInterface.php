<?php

namespace Maas\Core\Test\Builder;

use Maas\Core\Test\ConstantsInterface;

/***
 * Interface BuilderInterface
 *
 * @package Maas\Core\Test\Builder
 * @codeCoverageIgnore Interface used in tests, will not be tested itself
 */
interface BuilderInterface extends ConstantsInterface
{
    public function build();
}
