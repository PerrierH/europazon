<?php

namespace Maas\Core\Test\Builder\Cart;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\SalesQuoteInfo;
use Magento\Quote\Api\Data\CartExtensionInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Shipping;
use Magento\Quote\Model\ShippingAssignment;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CartBuilder
 *
 * @package Maas\Core\Test\Builder\Cart
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CartBuilder implements BuilderInterface
{
    use BuilderTrait;

    protected $extensionAttributesData = null;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(CartInterface::class, Quote::class),
            $defaultData);
    }

    /**
     * @param array $datas
     * @param array $expects
     *
     * @return $this
     */
    public function withQuoteInfo(array $datas = [], array $expects = [])
    {
        $this->addConfig([
            'getExtensionAttributes' => [$expects['getExtensionAttributes'] ?? $this->testCase->any(), $this->buildQuoteExtensionInterface($datas, $expects)]
        ]);
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function buildQuoteExtensionInterface(array $datas, $expects)
    {
        $defaultData = [];
        if(isset($datas['shipping_assignments_address']))
        {
            $shippingAddress = $datas['shipping_assignments_address'];
            unset($datas['shipping_assignments_address']);

            $shippingMock = $this->createMock(Shipping::class, [
                'getAddress' => [$expects['getAddress'] ?? $this->testCase->any(), $shippingAddress]
            ]);
            $assignmentMock = $this->createMock(ShippingAssignment::class, [
                'getShipping' => [$expects['getShipping'] ?? $this->testCase->any(), $shippingMock]
            ]);
            $defaultData['getShippingAssignments'] = [$expects['getShippingAssignments'] ?? $this->testCase->any(), [$assignmentMock]];
        }
        if($datas)
        {
            $defaultData['getExtraInfo'] = [$expects['getExtraInfoExpects'] ?? $this->testCase->any(), $this->buildQuoteInfo($datas)];
        }

        return $this->createMock(CartExtensionInterface::class, $defaultData);
    }


    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function buildQuoteInfo(array $datas)
    {
        $defaultData = [
            'getOfferId' => [$this->testCase->any(), null]
        ];
        $data = array_merge($defaultData, $datas);
        $dataKeys = array_keys($data);
        $mock = $this->testCase->getMockBuilder(SalesQuoteInfo::class)
            ->setMethods($dataKeys)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();

        foreach ($data as $methodName => $value) {
            $this->parseMockValue($mock, $methodName, $value);
        }

        return $mock;
    }
}
