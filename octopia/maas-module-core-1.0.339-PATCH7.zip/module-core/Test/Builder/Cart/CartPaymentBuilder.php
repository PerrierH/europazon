<?php

namespace Maas\Core\Test\Builder\Cart;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Quote\Model\Quote\Payment;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CartPaymentBuilder
 *
 * @package Maas\Core\Test\Builder\Cart
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CartPaymentBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(PaymentInterface::class, Payment::class), $defaultData);
    }
}