<?php

namespace Maas\Core\Test\Builder\Cart;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Quote\Api\Data\ShippingInterface;
use Magento\Quote\Model\Quote\Payment;
use Magento\Quote\Model\Shipping;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CartShippingBuilder
 *
 * @package Maas\Core\Test\Builder\Cart
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CartShippingBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(ShippingInterface::class, Shipping::class), $defaultData);
    }
}