<?php

namespace Maas\Core\Test\Builder\Cart;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Magento\Quote\Api\Data\AddressExtensionInterface;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Model\Quote\Address;
use PHPUnit_Framework_MockObject_MockObject;
use PHPUnit_Framework_MockObject_Matcher_Invocation;

/**
 * Class CartAddressBuilder
 *
 * @package Maas\Core\Test\Builder\Cart
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CartAddressBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @var PHPUnit_Framework_MockObject_Matcher_Invocation
     */
    protected $extensionAttributesFrequency = null;

    /**
     * @var PHPUnit_Framework_MockObject_Matcher_Invocation
     */
    protected $extraInfoFrequency = null;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(AddressInterface::class, Address::class),
            $defaultData
        );
    }

    /**
     * @param array $datas
     *
     * @return $this
     */
    public function withQuoteAddressInfo(array $datas = [], $getExtensionAttributeExpects = null, $getExtraInfoExpects = null)
    {
        $this->addConfig([
            'getExtensionAttributes' => [$getExtensionAttributeExpects ?: $this->testCase->any(), $this->buildQuoteAddressExtensionInterface($datas, $getExtraInfoExpects)]
        ]);
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function buildQuoteAddressExtensionInterface(array $datas, $getExtraInfoExpects = null)
    {
        $defaultData = [
            'getExtraInfo' => [$getExtraInfoExpects ?: $this->testCase->any(), $this->buildQuoteAddressInfo($datas)],
        ];

        return $this->createAssociatedMock(AddressExtensionInterface::class, $defaultData);
    }


    /**
     * @param PHPUnit_Framework_MockObject_Matcher_Invocation $freq
     * @return $this
     */
    public function setGetExtensionAttributesFrequency(PHPUnit_Framework_MockObject_Matcher_Invocation $freq)
    {
        $this->extensionAttributesFrequency = $freq;
        return $this;
    }

    /**
     * @param PHPUnit_Framework_MockObject_Matcher_Invocation $freq
     * @return $this
     */
    public function setGetExtraInfoFrequency(PHPUnit_Framework_MockObject_Matcher_Invocation $freq)
    {
        $this->extraInfoFrequency = $freq;
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function buildQuoteAddressInfo(array $datas)
    {
        $defaultData = [
            'getTotalRoundFixes' => [$this->testCase->any(), null]
        ];
        $data = array_merge($defaultData, $datas);
        $dataKeys = array_keys($data);
        $mock = $this->testCase->getMockBuilder(SalesQuoteItemInfo::class)
            ->setMethods($dataKeys)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();

        foreach ($data as $methodName => $value) {
            $this->parseMockValue($mock, $methodName, $value);
        }

        return $mock;
    }


}