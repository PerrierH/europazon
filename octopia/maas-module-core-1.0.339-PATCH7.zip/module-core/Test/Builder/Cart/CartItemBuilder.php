<?php

namespace Maas\Core\Test\Builder\Cart;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Sales\Model\SalesQuoteInfo;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Magento\Quote\Api\Data\CartExtensionInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Quote\Model\Quote\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CartItemBuilder
 *
 * @package Maas\Core\Test\Builder\Cart
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CartItemBuilder implements BuilderInterface
{

    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(CartItemInterface::class, Item::class), $defaultData);
    }

    /**
     * @param array $datas
     *
     * @return $this
     */
    public function withQuoteItemInfo(array $datas = [], $getExtensionAttributeExpects = null, $getExtraInfoExpects = null)
    {
        $this->addConfig([
            'getExtensionAttributes' => [$getExtensionAttributeExpects ?: $this->testCase->any(), $this->buildQuoteItemExtensionInterface($datas, $getExtraInfoExpects)]
        ]);
        return $this;
    }

    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function buildQuoteItemExtensionInterface(array $datas, $getExtraInfoExpects = null)
    {
        $defaultData = [
            'getExtraInfo' => [$getExtraInfoExpects ?: $this->testCase->any(), $this->buildQuoteItemInfo($datas)],
        ];

        return $this->createMock(CartExtensionInterface::class, $defaultData);
    }


    /**
     * @param array $datas
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function buildQuoteItemInfo(array $datas)
    {
        $defaultData = [];
        $data = array_merge($defaultData, $datas);
        $dataKeys = array_keys($data);
        $mock = $this->testCase->getMockBuilder(SalesQuoteItemInfo::class)
            ->setMethods($dataKeys)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();

        foreach ($data as $methodName => $value) {
            $this->parseMockValue($mock, $methodName, $value);
        }

        return $mock;
    }


}