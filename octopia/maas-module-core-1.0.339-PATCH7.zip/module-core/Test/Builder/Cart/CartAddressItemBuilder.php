<?php

namespace Maas\Core\Test\Builder\Cart;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Catalog\Model\Product\Configuration\Item\ItemInterface;
use Magento\Quote\Model\Quote\Address\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CartAddressItemBuilder
 *
 * @package Maas\Core\Test\Builder\Cart
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CartAddressItemBuilder implements BuilderInterface
{

    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];

        return $this->createMock(
            $this->getClassToInstantiate(ItemInterface::class, Item::class), $defaultData);
    }
}