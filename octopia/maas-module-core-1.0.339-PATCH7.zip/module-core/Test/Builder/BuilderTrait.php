<?php

namespace Maas\Core\Test\Builder;

use Maas\Core\Test\Unit\AbstractTestCase;
use PHPUnit_Framework_MockObject_Builder_InvocationMocker;
use PHPUnit_Framework_MockObject_MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;

/**
 * Trait BuilderTrait
 *
 * @package Maas\Core\Test\Builder
 * @codeCoverageIgnore Trait used in tests, will not be tested itself
 */
trait BuilderTrait
{
    /** @var TestCase */
    protected $testCase;
    /** @var array */
    protected $data;
    /** @var ObjectManager */
    protected $objectManager;
    /** @var bool */
    protected $useConcreteClass;
    /** @var bool */
    protected $classNameOverride;
    /** @var bool */
    protected $createAsFullMock;
    /** @var bool */
    protected $createFactoryMock;
    /** @var array|null */
    protected $constructorArgs;

    /**
     * @param TestCase $testCase
     * @param array $data
     *
     * @return static
     */
    public static function create(
        TestCase $testCase,
        array $data = []
    ) {
        $self = new static();
        $self->testCase = $testCase;
        $self->objectManager = new ObjectManager($self->testCase);
        $self->initData();
        $self->addConfig($data);
        $self->setUseConcreteClass(false);
        $self->setClassNameOverride(null);
        $self->setCreateAsFullMock(false);
        $self->setCreateFactoryMock(false);
        $self->setConstructorArgs(null);
        return $self;
    }

    private function initData()
    {
        $this->data = [];
    }

    /**
     * @param array $data
     *
     * @return $this
     */
    public function addConfig(array $data)
    {
        $this->data = array_merge($this->data, $data);
        return $this;
    }

    /**
     * Create the entity's main mock
     *
     * @param string $className
     * @param array $defaultData
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function createMock(string $className, array $defaultData = [])
    {
        return $this->createMockFromDataArrays($className, $defaultData, $this->data);
    }

    /**
     * Create a mock for an object associated to the entity
     *
     * @param string $className
     * @param array $defaultData
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function createAssociatedMock(string $className, array $defaultData = [])
    {
        return $this->createMockFromDataArrays($className, $defaultData);
    }

    /**
     * Create a mock using any two data arrays
     *
     * @param string $className
     * @param array $defaultData
     * @param array $accumulatedData
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function createMockFromDataArrays(string $className, array $defaultData = [], array $accumulatedData = [])
    {
        if ($this->createFactoryMock) {
            $className .= 'Factory';
        }
        $data = array_merge($defaultData, $accumulatedData);
        $dataKeys = array_keys($data);

        $mockBuilder = $this->testCase->getMockBuilder($className);
        $mockBuilder->setMethods($dataKeys);

        if (!is_array($this->constructorArgs)) {
            $mockBuilder->disableOriginalConstructor();
        } else {
            $mockBuilder->setConstructorArgs($this->constructorArgs);
        }

        $mock = $this->createAsFullMock ? $mockBuilder->getMock() : $mockBuilder->getMockForAbstractClass();

        foreach ($data as $methodName => $value) {
            $this->parseMockValue($mock, $methodName, $value);
        }
        return $mock;
    }

    /**
     * @param array|null $args
     */
    public function setConstructorArgs($args)
    {
        $this->constructorArgs = $args;
        return $this;
    }


    /**
     * Set TRUE to directly instantiate concrete classes for objects that need them
     *
     * @param bool $useConcreteClass
     *
     * @return $this
     */
    public function setUseConcreteClass(bool $useConcreteClass)
    {
        $this->useConcreteClass = $useConcreteClass;
        return $this;
    }

    /**
     * Set a class name override to use non-standard interface implementations
     *
     * @param string $classNameOverride
     *
     * @return $this
     */
    public function setClassNameOverride($classNameOverride)
    {
        $this->classNameOverride = $classNameOverride;
        return $this;
    }

    /**
     * Set TRUE to force the use of getMock instead of getMockForAbstractClass
     *
     * @param bool $createAsFullMock
     *
     * @return $this
     */
    public function setCreateAsFullMock(bool $createAsFullMock)
    {
        $this->createAsFullMock = $createAsFullMock;
        return $this;
    }

    /**
     * Set TRUE to crete a Factory instead of the class itself
     *
     * @param bool $createFactoryMock
     *
     * @return $this
     */
    public function setCreateFactoryMock(bool $createFactoryMock)
    {
        $this->createFactoryMock = $createFactoryMock;
        return $this;
    }

    /**
     * Use this in builder implementation to be able to automatically make use of $classNameOverride
     * and $useConcreteClass.
     *
     * @param string $interfaceClassName
     * @param string $implementationClassName
     *
     * @return bool
     */
    public function getClassToInstantiate(string $interfaceClassName, string $implementationClassName)
    {
        if (is_null($this->classNameOverride)) {
            return $this->useConcreteClass ? $implementationClassName : $interfaceClassName;
        } else {
            return $this->classNameOverride;
        }
    }

    /**
     * Advanced parsing for methods, allowing for setting with() and different return types.
     *
     * @param PHPUnit_Framework_MockObject_MockObject $mock
     * @param string $methodName
     * @param mixed $value
     */
    protected function parseMockValue(PHPUnit_Framework_MockObject_MockObject $mock, string $methodName, $value)
    {
        $count = count($value);
        if ($count >= 2) {
            if ($this->testCase instanceof AbstractTestCase) {
                $frequency = $this->testCase->parseFrequency($value[0]);
            } else {
                $frequency = $value[0];
            }
            $with = null;
            $willReturnValue = &$value[1];
            $willReturnType = BuilderInterface::RETURN_VALUE;

            if ($count > 2) {
                $willReturnType = $value[2];
            }
            if ($count > 3 && is_array($value[3])) {
                $with = $value[3];
            }
            /** @var PHPUnit_Framework_MockObject_Builder_InvocationMocker $invocation */
            $invocation = $mock->expects($frequency)->method($methodName);
            if (is_array($with)) {
                $invocation = call_user_func_array([$invocation, 'with'], $with);
            }
            switch ($willReturnType) {
                case BuilderInterface::RETURN_VALUE:
                    $invocation->willReturn($willReturnValue);
                    break;
                case BuilderInterface::RETURN_REFERENCE:
                    $invocation->willReturnReference($willReturnValue);
                    break;
                case BuilderInterface::RETURN_CALLBACK:
                    $invocation->willReturnCallback($willReturnValue);
                    break;
                case BuilderInterface::RETURN_SELF:
                    $invocation->willReturnSelf();
                    break;
                case BuilderInterface::RETURN_ARGUMENT:
                    $invocation->willReturnArgument($willReturnValue);
                    break;
                case BuilderInterface::RETURN_MAP:
                    $invocation->willReturnMap($willReturnValue);
                    break;
                case BuilderInterface::THROW_EXCEPTION:
                    $invocation->willThrowException($willReturnValue);
                    break;
                case BuilderInterface::RETURN_CONSECUTIVE:
                    if (is_array($willReturnValue)) {
                        call_user_func_array([$invocation, 'willReturnOnConsecutiveCalls'], $willReturnValue);
                    }
                    break;
            }
        } elseif ($count == 1) {
            if ($this->testCase instanceof AbstractTestCase) {
                $frequency = $this->testCase->parseFrequency($value[0]);
            } else {
                $frequency = $value[0];
            }
            $mock->expects($frequency)->method($methodName);
        }
    }
}
