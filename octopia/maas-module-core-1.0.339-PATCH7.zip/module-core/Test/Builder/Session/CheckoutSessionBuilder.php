<?php

namespace Maas\Core\Test\Builder\Session;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\Checkout\Model\Session;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CheckoutSessionBuilder
 *
 * @package Maas\Core\Test\Builder\Session
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class CheckoutSessionBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [
        ];

        return $this->createMock(Session::class, $defaultData);
    }
}
