<?php

namespace Maas\Core\Test\Builder\Inventory;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Magento\CatalogInventory\Model\Stock\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class StockItemBuilder
 *
 * @package Maas\Core\Test\Builder\Inventory
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class StockItemBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [];

        return $this->createMock(Item::class, $defaultData);
    }
}
