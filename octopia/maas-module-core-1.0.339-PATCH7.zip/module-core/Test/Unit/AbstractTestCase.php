<?php

namespace Maas\Core\Test\Unit;

use Amazon\Core\Helper\ClientIp\Proxy;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\ConstantsInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_Matcher_AnyInvokedCount;
use PHPUnit_Framework_MockObject_Matcher_InvokedCount;
use PHPUnit_Framework_MockObject_MockObject;
use ReflectionClass;
use ReflectionException;

/**
 * Class AbstractTestCase
 *
 * @package Maas\Core\Test\Unit
 */
abstract class AbstractTestCase extends TestCase implements ConstantsInterface
{
    /** @var ObjectManager */
    protected $objectManager = null;

    /**
     * Calls a protected or a private method
     *
     * @param object $object
     * @param string $methodName
     * @param array $parameters
     * @return mixed
     *
     * @throws ReflectionException
     */
    protected function invokeMethod(&$object, $methodName, array $parameters = [])
    {
        $reflection = new ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }

    /**
     * @param object $object
     * @param string $attributeName
     *
     * @return mixed
     * @throws ReflectionException
     */
    protected function getAttribute(&$object, $attributeName)
    {
        $reflection = new ReflectionClass(get_class($object));
        $attribute = $reflection->getProperty($attributeName);
        $attribute->setAccessible(true);

        return $attribute->getValue($object);
    }

    /**
     * @param object $object
     * @param string $attributeName
     * @param mixed $attributeValue
     *
     * @return $this
     * @throws ReflectionException
     */
    protected function setAttribute(&$object, $attributeName, $attributeValue)
    {
        $reflection = new ReflectionClass(get_class($object));
        $attribute = $reflection->getProperty($attributeName);
        $attribute->setAccessible(true);

        $attribute->setValue($object, $attributeValue);
        return $this;
    }

    /**
     * Add callbacks to an existing mock in cases where it needs an existing reference of an existing mock.
     *
     * @param PHPUnit_Framework_MockObject_MockObject $mock
     * @param array $callbacks
     */
    protected function addCallbacks(PHPUnit_Framework_MockObject_MockObject &$mock, $callbacks)
    {
        foreach($callbacks as $methodName => $callback)
        {
            if(count($callback) >= 2)
            {
                $with = null;
                $frequency = $this->parseFrequency($callback[0]);
                $callable = $callback[1];
                if(count($callback) > 2)
                {
                    $with = $callback[2];
                }
                $invocation = $mock->expects($frequency)->method($methodName);
                if(is_array($with))
                {
                    $invocation = call_user_func_array([$invocation, 'with'], $with);
                }
                $invocation->willReturnCallback($callable);
            }
            elseif(count($callback) == 1)
            {
                $frequency = $this->parseFrequency($callback[0]);
                $mock->expects($frequency)->method($methodName);
            }
        }
    }

    /**
     * Shorthand method for initializing the Object Manager and using it to return an instance of a given class
     *
     * @param string $className
     * @param array $arguments
     * @return object
     */
    protected function getObject($className, $arguments = [])
    {
        if(is_null($this->objectManager))
        {
            $this->objectManager = new ObjectManager($this);
        }
        return $this->objectManager->getObject($className, $arguments);
    }

    /**
     * Can allow to use an int instead of $this->exactly(), $this->once() and $this->never()
     *
     * @param PHPUnit_Framework_MockObject_Matcher_AnyInvokedCount|PHPUnit_Framework_MockObject_Matcher_InvokedCount|int $frequency
     *
     * @return PHPUnit_Framework_MockObject_Matcher_AnyInvokedCount|PHPUnit_Framework_MockObject_Matcher_InvokedCount
     */
    public function parseFrequency($frequency)
    {
        if(is_object($frequency) && $frequency instanceof PHPUnit_Framework_MockObject_Matcher_InvokedCount)
        {
            return $frequency;
        }
        elseif(is_int($frequency))
        {
            switch($frequency)
            {
                case -1:
                    $frequency = self::any();
                    break;
                default:
                    $frequency = self::exactly($frequency);
                    break;
            }
        }
        return $frequency;
    }

    /**
     * Create a full mock of an instance with overriden methods and constructor arguments
     *
     * @param string $classname
     * @param array $constructorArgumentsOverride
     * @param array $data
     * @param bool $fullMock
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function getInstanceMock($classname, $constructorArgumentsOverride, $data, $fullMock = true)
    {
        if(is_null($this->objectManager))
        {
            $this->objectManager = new ObjectManager($this);
        }
        $fullConstructorArgs = [];
        if(is_array($constructorArgumentsOverride))
        {
            $params = $this->objectManager->getConstructArguments($classname);
            foreach($params as $name => $object)
            {
                if(isset($constructorArgumentsOverride[$name]))
                {
                    $fullConstructorArgs[$name] = $constructorArgumentsOverride[$name];
                }
                else
                {
                    $fullConstructorArgs[$name] = $object;
                }
            }
        }
        else
        {
            $fullConstructorArgs = null;
        }

        return AnyBuilder::createForClass($this, $classname, $data)
            ->setConstructorArgs($fullConstructorArgs)
            ->setCreateAsFullMock($fullMock)
            ->build();
    }
}
