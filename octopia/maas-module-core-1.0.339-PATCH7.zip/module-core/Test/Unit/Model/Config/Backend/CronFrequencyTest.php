<?php

namespace Maas\Core\Test\Unit\Model\Source\Backend;

use Exception;
use Maas\Core\Model\Service\CronScheduleDelete;
use Magento\Config\Model\ResourceModel\Config\Data;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Maas\Core\Model\Config\Backend\CronFrequency;
use Magento\Framework\App\Config\ValueFactory;
use StdClass;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Value;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;

/**
 * Class CronFrequencyTest
 *
 * @package Maas\Core\Test\Unit\Model\Source\Backend
 */
class CronFrequencyTest extends TestCase
{

    /** @var array */
    public $config;
    /** @var string */
    public $currentPath;
    /** @var string */
    public $field = '';
    /** @var string */
    public $value = '';
    /** @var array */
    public $fieldConfig = [];
    public $valueMock;
    /** @var bool */
    public $throwException = false;
    /** @var CronFrequency */
    private $instance;
    /** @var ObjectManager */
    private $objectManager;

    /**
     * @throws Exception
     * @dataProvider afterSaveProvider
     */
    public function testAfterSave(
        $field,
        $value,
        $source,
        $expectedCronPath,
        $expectedCronValue
    ) {
        $this->initTest();
        $this->field = $field;
        $this->value = $value;
        $this->fieldConfig = ['source_model' => $source];

        $this->instance->afterSave();

        $keys = array_keys($this->config);
        $this->assertEquals($expectedCronPath, $this->config[$keys[0]]['path']);
        $this->assertEquals($expectedCronValue, $this->config[$keys[0]]['value']);
    }

    public function initTest($isCronEnable = true,  $saveCalled = true, $path = 'Maas/module/config_frequency')
    {
        $this->objectManager = new ObjectManager($this);

        $this->valueMock = AnyBuilder::createForClass(
            $this,
            Value::class,
            [
                'setValue' => [
                    $this->any(),
                    function ($v) {
                        if ($this->throwException) {
                            throw new Exception('Test exception');
                        }
                        $this->config[$this->currentPath]['value'] = $v;
                        return $this->valueMock;
                    }
                    ,
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setPath' => [
                    $this->any(),
                    function ($v) {
                        $this->config[$this->currentPath]['path'] = $v;
                        return $this->valueMock;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],]
        )->build();

        $configValueFactory = AnyBuilder::createForClass(
            $this,
            ValueFactory::class,
            [
                'create' => [$this->any(), $this->valueMock]
            ]
        )->build();

        $configValueResource = AnyBuilder::createForClass(
            $this,
            Data::class,
            [
                'load' => [$this->once(), function($object, $path, $pathLabel) {
                    $this->currentPath = $path;
                    $this->config[$path] = [];
                    return $this->valueMock;
                },  AnyBuilder::RETURN_CALLBACK],
                'save' => [$saveCalled ? $this->once() : $this->never(), null,  AnyBuilder::RETURN_SELF, [$this->valueMock]],
            ]
        )->build();

        $contextMock = AnyBuilder::createForClass($this, Context::class)->build();
        $registryMock = AnyBuilder::createForClass($this, Registry::class)->build();
        $configMock = AnyBuilder::createForClass($this, ScopeConfigInterface::class)->build();
        $cacheTypeListMock = AnyBuilder::createForClass($this, TypeListInterface::class)->build();
        $cronScheduleDelete = AnyBuilder::createForClass($this, CronScheduleDelete::class, [
            'execute' => [$isCronEnable ? $this->never() : $this->once(), null, AnyBuilder::RETURN_SELF]
        ])->build();

        $this->instance = $this->getMockBuilder(CronFrequency::class)
            ->setConstructorArgs(
                [
                    'context' => $contextMock,
                    'registry' => $registryMock,
                    'config' => $configMock,
                    'cacheTypeList' => $cacheTypeListMock,
                    'configValueFactory' => $configValueFactory,
                    'configValueResource' => $configValueResource,
                    'cronScheduleDelete' => $cronScheduleDelete
                ]
            )
            ->setMethods(
                [
                    'callParentAfterSave',
                    'getField',
                    'getValue',
                    'getFieldConfig',
                    'getPath',
                    'getGroups',
                ]
            )
            ->getMock();

        $this->instance->expects($this->any())->method('callParentAfterSave')->willReturn(true);
        $this->instance->expects($this->any())->method('getField')->willReturnCallback(function () {
            return $this->field;
        });
        $this->instance->expects($this->any())->method('getValue')->willReturnCallback(function () {
            return $this->value;
        });
        $this->instance->expects($this->any())->method('getFieldConfig')->willReturnCallback(function () {
            return $this->fieldConfig;
        });
        $this->instance->expects($this->any())->method('getPath')->willReturn($path);
        $this->instance->expects($this->any())->method('getGroups')->willReturn([
            'module' => [
                'fields' => [
                    'config_enabled' => [
                        'value' => $isCronEnable,
                    ]
                ]
            ]
        ]);
    }

    public function afterSaveProvider()
    {
        yield from [
            'Test offer 45' => [
                'offer_offer_import_frequency',
                45,
                CronFrequency::CONFIG_PATH_MINUTES,
                'crontab/maas_catalog/jobs/maas_offer_offer_import/schedule/cron_expr',
                '*/45 * * * *'
            ],
            'Test offer 60' => [
                'offer_offer_import_frequency',
                60,
                CronFrequency::CONFIG_PATH_MINUTES,
                'crontab/maas_catalog/jobs/maas_offer_offer_import/schedule/cron_expr',
                '0 */1 * * *'
            ],
            'Test BestOffer' => [
                'best_offer_update_frequency',
                2,
                CronFrequency::CONFIG_PATH_HOURS,
                'crontab/maas_core/jobs/maas_best_offer_update/schedule/cron_expr',
                '0 */2 * * *'
            ],
            'Test CatalogRule Categorization' => [
                'catalog_rule_categorization_frequency',
                2,
                CronFrequency::CONFIG_PATH_HOURS,
                'crontab/maas_core/jobs/maas_catalog_rule_categorization/schedule/cron_expr',
                '0 */2 * * *'
            ]
        ];
    }

    public function testAfterSaveException()
    {
        $this->initTest(true, false);
        $this->field = 'offer_offer_import_frequency';
        $this->value = 20;
        $this->fieldConfig = ['source_model' => CronFrequency::CONFIG_PATH_MINUTES];

        $this->throwException = true;
        $this->expectException(Exception::class);

        $this->instance->afterSave();
    }


    public function testAfterSaveDisabledCron()
    {
        $this->initTest(false);
        $this->field = 'offer_offer_import_frequency';
        $this->value = 20;
        $this->fieldConfig = ['source_model' => CronFrequency::CONFIG_PATH_MINUTES];
        $this->instance->afterSave();
    }

    public function testAfterSaveDisabledCronNoArrayKeys()
    {
        $this->initTest(false, true, 'bad/path/test_frequency');
        $this->field = 'offer_offer_import_frequency';
        $this->value = 20;
        $this->fieldConfig = ['source_model' => CronFrequency::CONFIG_PATH_MINUTES];
        $this->instance->afterSave();
    }

}
