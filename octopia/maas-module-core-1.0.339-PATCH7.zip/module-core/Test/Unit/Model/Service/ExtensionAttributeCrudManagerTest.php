<?php

namespace Maas\Core\Test\Unit\Model\Config\Service;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Sales\Api\Data\SalesQuoteInfoInterfaceFactory;
use Maas\Sales\Api\Data\SalesQuoteInfoSearchResultsInterface;
use Maas\Sales\Model\ResourceModel\SalesQuoteInfo\Collection;
use Maas\Sales\Model\SalesQuoteInfo;
use Maas\Sales\Model\SalesQuoteInfoRepository;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Quote\Api\Data\CartExtensionInterface;
use Magento\Quote\Api\Data\CartExtensionInterfaceFactory;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;

class ExtensionAttributeCrudManagerTest extends TestCase
{
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $searchCriteriaBuilder;
    /**
     * @var mixed
     */
    private $stub;
    /**
     * @var ObjectManager
     */
    private $objectManagerHelper;

    public function setUp()
    {
        $this->objectManagerHelper = new ObjectManager($this);
        $searchCriteria = AnyBuilder::createForClass($this, SearchCriteria::class)->build();
        $this->searchCriteriaBuilder = AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'addFilter' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'create' => [$this->any(), $searchCriteria, AnyBuilder::RETURN_VALUE],
        ])->build();
        $this->stub = new ExtensionAttributeCrudManager(
            $this->searchCriteriaBuilder
        );
    }

    public function testLoadAfterModelExtensionAndExtensionAttributeExists()
    {
        $model = $this->createMockModel();
        $modelExtensionFactory = AnyBuilder::createForClass($this, CartExtensionInterfaceFactory::class)->build();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class)->build();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class)->build();
        $this->stub->loadAfter(
            $model,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    private function createMockModel()
    {
        $modelExtension = $this->createMockCartExtensionInterface($this->createMockSalesQuoteInfo());
        return AnyBuilder::createForClass($this, SalesQuoteInfo::class, [
            'getExtensionAttributes' => [$this->once(), $modelExtension, AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    private function createMockCartExtensionInterface($salesInfo = false)
    {
        return AnyBuilder::createForClass($this, CartExtensionInterface::class, [
            'getSalesInfo' => [$this->atMost(2), $salesInfo, AnyBuilder::RETURN_VALUE],
            'setSalesInfo' => [$this->atMost(1), null, AnyBuilder::RETURN_SELF],
        ])->build();
    }

    private function createMockSalesQuoteInfo()
    {
        return AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
    }

    public function testLoadAfterModelExtensionNotExistAndExtensionAttributeExist()
    {
        $model = AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = $this->createMockExtensionAttributeRepository();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class)->build();
        $this->stub->loadAfter(
            $model,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    private function createMockModelExtensionFactory()
    {
        return AnyBuilder::createForClass($this, CartExtensionInterfaceFactory::class, [
            'create' => [$this->atMost(1), $this->createMockCartExtensionInterface(), AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    private function createMockExtensionAttributeRepository()
    {
        return AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'get' => [$this->atMost(1), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    public function testLoadAfterModelExtensionNotExistAndExtensionAttributeNotExists()
    {
        $model = AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = $this->createMockExtensionAttributeRepository();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class)->build();
        $this->stub->loadAfter(
            $model,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    public function testLoadAfterNoSuchEntityException()
    {
        $noSuchEntityException = AnyBuilder::createForClass($this, NoSuchEntityException ::class)->build();
        $model = AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = $this->createMockExtensionAttributeRepository();
        $extensionAttributeRepository->expects($this->once())->method('get')->willThrowException($noSuchEntityException);
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->once(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->loadAfter(
            $model,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    public function testSaveBeforeNoEntityToCache()
    {
        $model = AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->once(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->saveBefore($model, 'salesInfo', $extensionAttributeFactory);
    }

    public function testSaveBeforeWithEntityCache()
    {
        $model = $this->createMockModel();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->never(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->saveBefore($model, 'salesInfo', $extensionAttributeFactory);
    }

    public function testSaveAfterNoCachedEntitiesAndNoModelExtension()
    {
        $model = $this->createMockModel();
        $modelExtensionFactory = AnyBuilder::createForClass($this, CartExtensionInterfaceFactory::class)->build();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'save' => [$this->once(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->once(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->saveAfter($model, $modelExtensionFactory, 'salesInfo', $extensionAttributeRepository,
            $extensionAttributeFactory);
    }

    public function testSaveAfterNoCachedEntitiesAndModelExtension()
    {
        $model = AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'save' => [$this->once(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->once(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->saveAfter($model, $modelExtensionFactory, 'salesInfo', $extensionAttributeRepository,
            $extensionAttributeFactory);
    }

    public function testSaveAfterWithCachedEntitiesAndModelExtensionAndEntityToSaveIdFalse()
    {
        $model = AnyBuilder::createForClass(
            $this,
            SalesQuoteInfo::class,
            [
                'getId' => [$this->once(), true, AnyBuilder::RETURN_VALUE]
            ]
        )->build();
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'save' => [$this->once(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->atMost(2), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->saveBefore($model, 'salesInfo', $extensionAttributeFactory);
        $this->stub->saveAfter(
            $model,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    public function testSaveAfterWithCachedEntitiesAndModelExtension()
    {
        $model = AnyBuilder::createForClass($this, SalesQuoteInfo::class,
            [
                'getId' => [$this->exactly(2), false, AnyBuilder::RETURN_VALUE],
            ]
        )->build();
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'save' => [$this->once(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class, [
            'create' => [$this->once(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub->saveBefore($model, 'salesInfo', $extensionAttributeFactory);
        $this->stub->saveAfter($model, $modelExtensionFactory, 'salesInfo', $extensionAttributeRepository,
            $extensionAttributeFactory);
    }

    public function testloadCollectionAfterNoId()
    {
        $item = AnyBuilder::createForClass($this, SalesQuoteInfo::class)->build();
        $collection = $this->objectManagerHelper->getCollectionMock(Collection::class, [$item]);
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = $this->createMockExtensionAttributeRepository();

        $extensionAttributeFactory = AnyBuilder::createForClass($this, SalesQuoteInfoInterfaceFactory::class)->build();
        $this->stub->loadCollectionAfter(
            $collection,
            1,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    public function testloadCollectionAfterWithId()
    {
        $item = AnyBuilder::createForClass($this, SalesQuoteInfo::class, [
            'getId' => [$this->any(), 5, AnyBuilder::RETURN_VALUE]
        ])->build();
        $collection = $this->objectManagerHelper->getCollectionMock(Collection::class, [$item]);
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'getList' => [
                $this->any(),
                $this->createMockSalesQuoteInfoSearchResultsInterface(),
                AnyBuilder::RETURN_VALUE
            ]
        ])->build();
        $extensionAttributeFactory = $extensionAttributeFactory = AnyBuilder::createForClass($this,
            SalesQuoteInfoInterfaceFactory::class, [
                'create' => [$this->once(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
            ])->build();
        $this->stub->loadCollectionAfter(
            $collection,
            1,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }

    private function createMockSalesQuoteInfoSearchResultsInterface($id = null)
    {
        $item = AnyBuilder::createForClass($this, SalesQuoteInfo::class, [
            'getId' => [$this->any(), $id, AnyBuilder::RETURN_VALUE]
        ])->build();
        return AnyBuilder::createForClass($this, SalesQuoteInfoSearchResultsInterface::class, [
            'getItems' => [$this->any(), [$item], AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    public function testloadCollectionAfterWithIdAndItemById()
    {
        $item = AnyBuilder::createForClass($this, SalesQuoteInfo::class, [
            'getId' => [$this->any(), 5, AnyBuilder::RETURN_VALUE]
        ])->build();
        $collection = $this->objectManagerHelper->getCollectionMock(Collection::class, [$item]);
        $modelExtensionFactory = $this->createMockModelExtensionFactory();
        $extensionAttributeRepository = AnyBuilder::createForClass($this, SalesQuoteInfoRepository::class, [
            'getList' => [
                $this->any(),
                $this->createMockSalesQuoteInfoSearchResultsInterface(5),
                AnyBuilder::RETURN_VALUE
            ]
        ])->build();
        $extensionAttributeFactory = $extensionAttributeFactory = AnyBuilder::createForClass($this,
            SalesQuoteInfoInterfaceFactory::class, [
                'create' => [$this->never(), $this->createMockSalesQuoteInfo(), AnyBuilder::RETURN_VALUE]
            ])->build();
        $this->stub->loadCollectionAfter(
            $collection,
            1,
            $modelExtensionFactory,
            'salesInfo',
            $extensionAttributeRepository,
            $extensionAttributeFactory
        );
    }
}
