<?php

namespace Maas\Core\Test\Unit\Model\Config\Service;

use Maas\Core\Model\Service\AbstractExtensionAttributes;
use Maas\Core\Test\Unit\AbstractTestCase;
use Magento\Framework\DataObject;

class AbstractExtensionAttributesTest extends AbstractTestCase
{
    public function testGetObjectExtensionAtttributes()
    {
        $instance = $this->getMockForAbstractClass(AbstractExtensionAttributes::class);

        $objectExtensionExtraInfo = null;

        $extensionExtraInfo = $this->getInstanceMock(DataObject::class, [], []);

        $extension = $this->getInstanceMock(DataObject::class, [], [
            'getExtraInfo' => [1, function() use(&$objectExtensionExtraInfo) {
                return $objectExtensionExtraInfo;
            }, self::RETURN_CALLBACK],
            'setExtraInfo' => [1, function($ext) use(&$objectExtensionExtraInfo) {
                $objectExtensionExtraInfo = $ext;
            }, self::RETURN_CALLBACK],
        ]);

        $objectExtension = null;
        $object = $this->getInstanceMock(DataObject::class, [], [
            'getExtensionAttributes' => [1, function() use(&$objectExtension) {
                return $objectExtension;
            }, self::RETURN_CALLBACK],
            'setExtensionAttributes' => [1, function($ext) use(&$objectExtension) {
                $objectExtension = $ext;
            }, self::RETURN_CALLBACK],
        ]);

        $extensionFactory = $this->getInstanceMock(DataObject::class, [], [
            'create' => [1, $extension, self::RETURN_REFERENCE]
        ]);
        $extraInfoFactory = $this->getInstanceMock(DataObject::class, [], [
            'create' => [1, $extensionExtraInfo, self::RETURN_REFERENCE]
        ]);

        $returnedExt = $this->invokeMethod($instance, 'getObjectExtensionAttributes', [$object, $extensionFactory, $extraInfoFactory]);

        $this->assertSame($extension, $objectExtension);
        $this->assertSame($extension, $returnedExt);
        $this->assertSame($extensionExtraInfo, $objectExtensionExtraInfo);
    }
}