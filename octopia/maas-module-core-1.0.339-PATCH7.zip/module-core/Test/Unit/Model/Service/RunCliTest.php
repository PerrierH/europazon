<?php


namespace Maas\Core\Test\Unit\Model\Service;


use Maas\Core\Api\RunCli\MessageInterface;
use Maas\Core\Model\Service\MessageQueue\Publisher;
use Maas\Core\Test\Builder\AnyBuilder;
use PHPUnit\Framework\TestCase;
use Maas\Core\Model\Service\RunCli;

class RunCliTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $publisher;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $message;
    /**
     * @var RunCli
     */
    private $stub;

    public function setUp(){
        $this->publisher = AnyBuilder::createForClass($this, Publisher::class, [
            'publish'  => [$this->once()]
        ])->build();
        $this->message = AnyBuilder::createForClass($this, MessageInterface::class, [
            'setMessage' => [$this->once()]
        ])->build();
        $this->stub = new RunCli(
            $this->publisher,
            $this->message
        );
    }

    public function testExecuteIsNumeric(){
        $this->stub->addToQueue('catgeory_import_test', ['test1', 'test2']);
    }

    public function testExecuteIsNotNumeric(){
        $this->stub->addToQueue('catgeory_import_test', ['test1' => 'import cat 1', 'test2' => 'import cat 2']);
    }

}
