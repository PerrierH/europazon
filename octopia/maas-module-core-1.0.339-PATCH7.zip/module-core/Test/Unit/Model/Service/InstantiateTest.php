<?php
namespace Maas\Core\Test\Unit\Model\Service;

use PHPUnit\Framework\TestCase;
use Maas\Core\Model\Service\Instantiate;

/**
 * @covers \Maas\Core\Model\Service\Instantiate
 */
class InstantiateTest extends TestCase
{
    /**
     * Class to test instance
     *
     * @var Instantiate
     */
    private $instantiate;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->instantiate = new Instantiate();
    }

    /**
     * @return void
     */
    public function testGetInstanceIfArray() : void
    {
        $objectMock;
        $this->instantiate->getInstanceIfArray($objectMock);
    }
}
