<?php

namespace Maas\Core\Test\Unit\Model\Service\MessageQueue;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Model\Config;
use Maas\Core\Model\Service\MessageQueue\Publisher;
use Maas\ImportExport\Test\Unit\Model\AbstractMqTestCase;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\ObjectManagerInterface;
use Maas\Core\Model\Service\MessageQueue\Config as MqConfig;

/**
 * Class PublisherTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Service\MessageQueue
 */
class PublisherTest extends AbstractMqTestCase
{
    /**
     * @param string[] $modules
     * @param string $publisherClass
     * @param string $connectionMethod
     *
     * @return Publisher
     */
    protected function getInstance(
        $modules,
        $publisherClass,
        $connectionMethod,
        &$requestedQueue,
        &$requestedMessage,
        $callsCount,
        $callsCountValidateRequestedQueueName = null,
        $createCount = 1
    ) {
        $publisherMock = AnyBuilder::createForClass($this, $publisherClass, [
            'publish' => [
                $callsCount,
                function ($queue, $message) use (&$requestedQueue, &$requestedMessage) {
                    $requestedQueue = $queue;
                    $requestedMessage = $message;
                },
                self::RETURN_CALLBACK
            ]
        ])->setCreateAsFullMock(true)->build();

        $objectManagerMock = AnyBuilder::createForClass($this, ObjectManagerInterface::class, [
            'create' => [$createCount, $publisherMock, self::RETURN_REFERENCE, $publisherClass]
        ])->build();

        $configMock = AnyBuilder::createForClass($this, Config::class, [
            'getMessageQueueConnectionMethod' => [1, $connectionMethod]
        ])->build();

        $mqConfigMock = AnyBuilder::createForClass($this, MqConfig::class, [
            'validateRequestedQueueName' => [
                $callsCountValidateRequestedQueueName ?? $callsCount,
                function ($queueName) use ($publisherClass) {
                    switch ($publisherClass) {
                        case Publisher::RCASONMQ_PUBLISHER:
                            return in_array($queueName, $this->getRcasonMqQueues());
                        case Publisher::MAGENTO_PUBLISHER:
                            foreach ($this->getMagentoTopics() as $topic) {
                                if ($topic['name'] == $queueName) {
                                    return true;
                                }
                            }
                            return false;
                        default:
                            return false;
                    }
                },
                self::RETURN_CALLBACK
            ]
        ])->build();

        return $this->getObject(Publisher::class, [
            'objectManager' => $objectManagerMock,
            'moduleList' => $this->getModuleListMock($modules),
            'config' => $configMock,
            'mqConfig' => $mqConfigMock,
        ]);
    }

    public function testPublishWithRcasonMq()
    {
        foreach ([self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA] as $connectionMethod) {
            $requestedQueue = null;
            $requestedMessage = null;
            $sentMessage = 'Test message';

            $subjects = [self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4];

            $instance = $this->getInstance(
                [Publisher::RCASONMQ_MODULE],
                Publisher::RCASONMQ_PUBLISHER,
                $connectionMethod,
                $requestedQueue,
                $requestedMessage,
                count($subjects)
            );
            foreach ([self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4] as $queueSubject) {
                $instance->publish($queueSubject, $sentMessage);
            }

            $instance = $this->getInstance(
                [Publisher::MAGENTO_MODULE1, Publisher::MAGENTO_MODULE2],
                Publisher::MAGENTO_PUBLISHER,
                $connectionMethod,
                $requestedQueue,
                $requestedMessage,
                count($subjects)
            );
            foreach ([self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4] as $queueSubject) {
                $instance->publish($queueSubject, $sentMessage);
            }
        }
    }

    public function testPublishException()
    {
            $requestedQueue = null;
            $requestedMessage = null;
            $sentMessage = 'Test message';
            $instance = $this->getInstance(
                [Publisher::RCASONMQ_MODULE],
                '\\test\\other\\Model\\Publisher',
                self::CONNECTION_DB,
                $requestedQueue,
                $requestedMessage,
                0,
                1
            );
            $this->expectException(LocalizedException::class);
            $instance->publish(self::SUBJECT_1, $sentMessage);
    }

    public function testInitializeException()
    {
        $requestedQueue = null;
        $requestedMessage = null;
        $sentMessage = 'Test message';
        $instance = $this->getInstance(
            ['my module'],
            '\\test\\other\\Model\\Publisher',
            self::CONNECTION_DB,
            $requestedQueue,
            $requestedMessage,
            0,
            0,
            0
        );
        $this->expectException(LocalizedException::class);
        $instance->publish(self::SUBJECT_1, $sentMessage);

    }
}
