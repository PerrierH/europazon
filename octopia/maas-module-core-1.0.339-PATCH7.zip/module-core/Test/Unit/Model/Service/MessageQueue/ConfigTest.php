<?php

namespace Maas\Core\Test\Unit\Model\Service\MessageQueue;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Model\Service\MessageQueue\Config;
use Maas\ImportExport\Test\Unit\Model\AbstractMqTestCase;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class ConfigTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Service\MessageQueue
 */
class ConfigTest extends AbstractMqTestCase
{

    public function testRcasonClasses()
    {
        $configMock = AnyBuilder::createForClass(
            $this, Config::RCASONMQ_CONFIG, [
            'getQueueNames' => [2, $this->getRcasonMqQueues()]
        ])->setCreateAsFullMock(true)->build();

        $objectManagerMock = AnyBuilder::createForClass($this, \Magento\Framework\ObjectManagerInterface::class, [
            'create' => [1, $configMock, self::RETURN_REFERENCE, [Config::RCASONMQ_CONFIG]]
        ])->build();

        /** @var Config $instance */
        $instance = $this->getObject(Config::class, [
            'objectManager' => $objectManagerMock,
            'moduleList' => $this->getModuleListMock([Config::RCASONMQ_MODULE])
        ]);

        foreach($this->getValidRequestedQueues('queue') as $requestedQueue)
        {
            $this->assertTrue($instance->validateRequestedQueueName($requestedQueue));
        }
        foreach($this->getInvalidRequestedQueues('queue') as $requestedQueue)
        {
            $this->assertNotTrue($instance->validateRequestedQueueName($requestedQueue));
        }
        $this->assertSame([
            self::CONNECTION_DB,self::CONNECTION_RABBIT,self::CONNECTION_KAFKA
        ], $instance->getBrokerCodes());
    }

    public function testMagentoClasses()
    {
        $configMock = AnyBuilder::createForClass($this, Config::MAGENTO_CONFIG1, [
            'getTopics' => [1, $this->getMagentoTopics()]
        ])->setCreateAsFullMock(true)->build();

        $topologyConfigMock = AnyBuilder::createForClass($this, Config::MAGENTO_CONFIG2, [
            'getQueues' => [1, $this->getMagentoQueues()]
        ])->setCreateAsFullMock(true)->build();

        $objectManagerMock = AnyBuilder::createForClass($this, \Magento\Framework\ObjectManagerInterface::class, [
            'create' => [2, function($className) use (&$configMock, &$topologyConfigMock) {
                switch($className)
                {
                    case Config::MAGENTO_CONFIG1:
                        return $configMock;
                    case Config::MAGENTO_CONFIG2:
                        return $topologyConfigMock;
                    default:
                        return null;
                }
            }, self::RETURN_CALLBACK]
        ])->build();

        /** @var Config $instance */
        $instance = $this->getObject(Config::class, [
            'objectManager' => $objectManagerMock,
            'moduleList' => $this->getModuleListMock([Config::MAGENTO_MODULE1, Config::MAGENTO_MODULE2])
        ]);

        foreach($this->getValidRequestedQueues('topic') as $requestedQueue)
        {
            $this->assertTrue($instance->validateRequestedQueueName($requestedQueue));
        }
        foreach($this->getInvalidRequestedQueues('topic') as $requestedQueue)
        {
            $this->assertNotTrue($instance->validateRequestedQueueName($requestedQueue));
        }
        $this->assertSame([
            self::CONNECTION_DB,self::CONNECTION_RABBIT,self::CONNECTION_KAFKA
        ], $instance->getBrokerCodes());
    }

    public function testNoClassesFound()
    {
        $objectManagerMock = AnyBuilder::createForClass($this, \Magento\Framework\ObjectManagerInterface::class, [
            'create' => [0]
        ])->build();

        $instance = $this->getObject(Config::class, [
            'objectManager' => $objectManagerMock,
            'moduleList' => $this->getModuleListMock([])
        ]);

        /** @var Config $instance */
        $this->expectException(LocalizedException::class);
        $this->invokeMethod($instance, 'initialize', []);
    }
}
