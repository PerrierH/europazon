<?php
namespace Maas\Core\Test\Unit\Model;

use PHPUnit\Framework\TestCase;
use Maas\Core\Model\Edition;

/**
 * @covers \Maas\Core\Model\Edition
 */
class EditionTest extends TestCase
{
    /**
     * Class to test instance
     *
     * @var Edition
     */
    private $edition;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->edition = new Edition();
    }

    /**
     * @return void
     */
    public function testGetEdition() : void
    {
        $this->edition->getEdition();
    }

    /**
     * @return void
     */
    public function testGetLinkField() : void
    {
        $this->edition->getLinkField();
    }

    /**
     * @return void
     */
    public function testIsEnterprise() : void
    {
        $this->edition->isEnterprise();
    }
}
