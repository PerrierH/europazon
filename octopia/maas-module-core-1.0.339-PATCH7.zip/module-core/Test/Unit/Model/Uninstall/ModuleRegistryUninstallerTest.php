<?php

namespace Maas\Core\Test\Unit\Model\Uninstall;

use Magento\Framework\App\DeploymentConfig;
use Magento\Framework\Config\ConfigOptionsListConstants;
use Magento\Framework\Config\File\ConfigFilePool;
use Magento\Framework\Module\ModuleList\Loader;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Maas\Core\Model\Uninstall\ModuleRegistryUninstaller;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\DB\Adapter\Pdo\Mysql;


/**
 * Used to uninstall registry from the database and deployment config
 */
class ModuleRegistryUninstallerTest extends TestCase
{
    /**
     * @var MockObject|DeploymentConfig
     */
    private $deploymentConfig;

    /**
     * @var MockObject|DeploymentConfig\Writer
     */
    private $writer;

    /**
     * @var MockObject|Loader
     */
    private $loader;

    /**
     * @var MockObject|ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * @var MockObject|OutputInterface
     */
    private $output;

    /**
     * @var ModuleRegistryUninstaller
     */
    private $moduleRegistryUninstaller;

    /**
     * @var MockObject
     */
    private $connectionMock;

    protected function setUp()
    {
        $this->deploymentConfig = $this->createMock(DeploymentConfig::class);
        $this->writer = $this->createMock(DeploymentConfig\Writer::class);
        $this->loader = $this->createMock(Loader::class);
        $this->moduleDataSetup = $this->createMock(ModuleDataSetupInterface::class);
        $this->connectionMock = $this->createMock(Mysql::class);

        $this->output = $this->createMock(OutputInterface::class);
        $this->moduleRegistryUninstaller = new ModuleRegistryUninstaller(
            $this->deploymentConfig,
            $this->writer,
            $this->loader,
            $this->moduleDataSetup
        );
    }

    public function testRemoveModulesFromDb()
    {
        $this->output->expects($this->atLeastOnce())->method('writeln');
        $this->moduleDataSetup->method('getTable')->willReturn('setup_module');
        $this->moduleDataSetup->method('getConnection')->willReturn($this->connectionMock);
        $this->connectionMock->expects($this->any())->method('delete')->with('setup_module', "`module` LIKE 'moduleA'");
        $this->moduleRegistryUninstaller->removeModulesFromDb($this->output, ['moduleA']);
    }

    public function testRemoveModulesFromDeploymentConfig()
    {
        $this->output->expects($this->atLeastOnce())->method('writeln');
        $this->deploymentConfig->expects($this->once())
            ->method('getConfigData')
            ->willReturn(['moduleA' => 1, 'moduleB' => 1, 'moduleC' => 1, 'moduleD' => 1]);
        $this->loader->expects($this->once())->method('load')->willReturn(['moduleC' => [], 'moduleD' => []]);
        $this->writer->expects($this->once())
            ->method('saveConfig')
            ->with(
                [
                    ConfigFilePool::APP_CONFIG => [
                        ConfigOptionsListConstants::KEY_MODULES => ['moduleC' => 1, 'moduleD' => 1]
                    ]
                ]
            );
        $this->moduleRegistryUninstaller->removeModulesFromDeploymentConfig($this->output, ['moduleA', 'moduleB']);
    }
}