<?php
namespace Maas\Core\Test\Unit\Model\Http;

use PHPUnit\Framework\TestCase;
use Maas\Core\Model\Http\CurlAdapter;

/**
 * @covers \Maas\Core\Model\Http\CurlAdapter
 */
class CurlAdapterTest extends TestCase
{
    /**
     * Class to test instance
     *
     * @var CurlAdapter
     */
    private $curlAdapter;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->curlAdapter = new CurlAdapter();
    }

    /**
     * @return void
     */
    public function testWrite() : void
    {
        $methodMock;
        $urlMock;
        $http_verMock;
        $headersMock;
        $bodyMock;
        $this->curlAdapter->write($methodMock, $urlMock, $http_verMock, $headersMock, $bodyMock);
    }
}
