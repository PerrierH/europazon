<?php
namespace Maas\Core\Test\Unit\Model\Http;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Framework\ObjectManagerInterface;
use Maas\Core\Model\Http\ClientFactory;

/**
 * @covers \Maas\Core\Model\Http\ClientFactory
 */
class ClientFactoryTest extends TestCase
{
    /**
     * Mock ObjectManagerInterface
     *
     * @var ObjectManagerInterface|MockObject
     */
    private $objectManagerMock;

    /**
     * Class to test instance
     *
     * @var ClientFactory
     */
    private $clientFactory;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->objectManagerMock = $this->getMockBuilder(ObjectManagerInterface::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->clientFactory = new ClientFactory(
        	$this->objectManagerMock
        );
    }

    /**
     * @return void
     */
    public function testCreate() : void
    {
        $dataMock;
        $this->clientFactory->create($dataMock);
    }
}
