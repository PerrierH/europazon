<?php
namespace Maas\Core\Test\Unit\Model\Http;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Maas\Core\Model\Http\CurlAdapterFactory;
use Maas\Core\Model\Http\Client;
use Maas\Core\Model\Http\CurlAdapter;

/**
 * @covers \Maas\Core\Model\Http\Client
 */
class ClientTest extends TestCase
{
    /**
     * Mock CurlAdapterFactory
     *
     * @var CurlAdapterFactory|MockObject
     */
    private $curlAdapterFactoryMock;

    /**
     * Class to test instance
     *
     * @var Client
     */
    private $client;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $curlAdapterInstanceMock = $this->getMockBuilder(CurlAdapter::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->curlAdapterFactoryMock = $this->getMockBuilder(CurlAdapterFactory::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->curlAdapterFactoryMock
        	->expects($this->atMost(1))
        	->method('create')
        	->willReturn($curlAdapterInstanceMock);

        $this->client = new Client(
        	$this->curlAdapterFactoryMock
        );
    }

    /**
     * @return void
     */
    public function testSetAdapter() : void
    {
        $adapterMock;
        $this->client->setAdapter($adapterMock);
    }
}
