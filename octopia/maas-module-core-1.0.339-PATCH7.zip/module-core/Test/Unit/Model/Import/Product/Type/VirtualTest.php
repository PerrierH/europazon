<?php
namespace Maas\Core\Test\Unit\Model\Import\Product\Type;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory as AttributeCollectionFactory;
use Magento\Framework\App\ResourceConnection;
use Maas\Core\Model\Import\Product\Type\Virtual;

/**
 * @covers \Maas\Core\Model\Import\Product\Type\Virtual
 */
class VirtualTest extends TestCase
{
    /**
     * Mock CollectionFactory
     *
     * @var CollectionFactory|MockObject
     */
    private $attrSetColFacMock;

    /**
     * Mock AttributeCollectionFactory
     *
     * @var AttributeCollectionFactory|MockObject
     */
    private $prodAttrColFacMock;

    /**
     * Mock ResourceConnection
     *
     * @var ResourceConnection|MockObject
     */
    private $resourceMock;

    /**
     * Class to test instance
     *
     * @var Virtual
     */
    private $virtual;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->attrSetColFacMock = $this->getMockBuilder(CollectionFactory::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->prodAttrColFacMock = $this->getMockBuilder(AttributeCollectionFactory::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->resourceMock = $this->getMockBuilder(ResourceConnection::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->virtual = new Virtual(
        	$this->attrSetColFacMock,
        	$this->prodAttrColFacMock,
        	$this->resourceMock
        );
    }

    /**
     * @return void
     */
    public function testReinitAttributes() : void
    {
        $this->virtual->reinitAttributes();
    }
}
