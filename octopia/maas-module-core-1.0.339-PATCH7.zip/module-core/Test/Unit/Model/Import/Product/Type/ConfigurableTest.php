<?php
namespace Maas\Core\Test\Unit\Model\Import\Product\Type;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory as AttributeCollectionFactory;
use Magento\Framework\App\ResourceConnection;
use Magento\Catalog\Model\ProductTypes\ConfigInterface;
use Magento\ImportExport\Model\ResourceModel\Helper;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Maas\Core\Model\Import\Product\Type\Configurable;

/**
 * @covers \Maas\Core\Model\Import\Product\Type\Configurable
 */
class ConfigurableTest extends TestCase
{
    /**
     * Mock CollectionFactory
     *
     * @var CollectionFactory|MockObject
     */
    private $attrSetColFacMock;

    /**
     * Mock AttributeCollectionFactory
     *
     * @var AttributeCollectionFactory|MockObject
     */
    private $prodAttrColFacMock;

    /**
     * Mock ResourceConnection
     *
     * @var ResourceConnection|MockObject
     */
    private $resourceMock;

    /**
     * Mock ConfigInterface
     *
     * @var ConfigInterface|MockObject
     */
    private $productTypesConfigMock;

    /**
     * Mock Helper
     *
     * @var Helper|MockObject
     */
    private $resourceHelperMock;

    /**
     * Mock ProductCollectionFactory
     *
     * @var ProductCollectionFactory|MockObject
     */
    private $_productColFacMock;

    /**
     * Class to test instance
     *
     * @var Configurable
     */
    private $configurable;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->attrSetColFacMock = $this->getMockBuilder(CollectionFactory::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->prodAttrColFacMock = $this->getMockBuilder(AttributeCollectionFactory::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->resourceMock = $this->getMockBuilder(ResourceConnection::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->productTypesConfigMock = $this->getMockBuilder(ConfigInterface::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->resourceHelperMock = $this->getMockBuilder(Helper::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->_productColFacMock = $this->getMockBuilder(ProductCollectionFactory::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->configurable = new Configurable(
        	$this->attrSetColFacMock,
        	$this->prodAttrColFacMock,
        	$this->resourceMock,
        	$this->productTypesConfigMock,
        	$this->resourceHelperMock,
        	$this->_productColFacMock
        );
    }

    /**
     * @return void
     */
    public function testReinitAttributes() : void
    {
        $this->configurable->reinitAttributes();
    }
}
