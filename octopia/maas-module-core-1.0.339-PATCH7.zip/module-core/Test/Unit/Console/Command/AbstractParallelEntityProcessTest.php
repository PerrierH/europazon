<?php

namespace Maas\Core\Test\Unit\Console\Command;

use Maas\Core\Console\Command\AbstractParallelEntityProcess;
use Maas\Core\Model\Config\Proxy;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Console\Command\InputBuilder;
use Maas\Core\Test\Builder\Console\Command\OutputBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use PHPUnit_Framework_MockObject_MockObject;
use ReflectionException;

/**
 * Class AbstractParallelEntityProcessTest
 *
 * @package Maas\Core\Test\Unit\Console\Command
 */
class AbstractParallelEntityProcessTest extends AbstractTestCase
{
    /**
     * @throws ReflectionException
     */
    public function testExecuteModuleEnabledMaster()
    {
        $input = InputBuilder::create($this, [
            'getOption' => [$this->once(), false]
        ])->build();
        $output = OutputBuilder::create($this)->build();

        $instance = $this->getInstance([
            'executeMasterProcess' => [$this->once(), null, self::RETURN_VALUE, [$input, $output]],
            'executeChildProcess' => [$this->never(), null],
            'isModuleEnabled' => [1, true]
        ]);

        $this->invokeMethod($instance, 'execute', [$input, $output]);
    }

    /**
     * @param array $methods
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function getInstance($methods = [])
    {
        return AnyBuilder::createForClass($this, AbstractParallelEntityProcess::class, $methods)->build();
    }

    /**
     * @throws ReflectionException
     */
    public function testExecuteModuleEnabledChild()
    {
        $input = InputBuilder::create($this, [
            'getOption' => [$this->once(), true]
        ])->build();
        $output = OutputBuilder::create($this)->build();

        $instance = $this->getInstance([
            'executeMasterProcess' => [$this->never(), null],
            'executeChildProcess' => [$this->once(), null, self::RETURN_VALUE, [$input, $output]],
            'isModuleEnabled' => [1, true]
        ]);

        $this->invokeMethod($instance, 'execute', [$input, $output]);
    }

    /**
     * @throws ReflectionException
     */
    public function testExecuteModuleDisabled()
    {
        $input = InputBuilder::create($this, [
            'getOption' => [$this->never()]
        ])->build();
        $output = OutputBuilder::create($this, [
            'writeln' => [$this->once(), false]
        ])->build();

        $instance = $this->getInstance([
            'executeMasterProcess' => [$this->never(), null],
            'executeChildProcess' => [$this->never(), null],
            'isModuleEnabled' => [1, false]
        ]);

        $this->invokeMethod($instance, 'execute', [$input, $output]);
    }

    public function testScheduleIdZero(){
        $instance = $this->getInstance();
        $scheduleId = $this->invokeMethod( $instance, 'getArgsScheduleId', [0]);
        $this->assertNull($scheduleId, 'should be null');
    }
}
