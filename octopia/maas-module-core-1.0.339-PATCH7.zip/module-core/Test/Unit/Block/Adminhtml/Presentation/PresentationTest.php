<?php

namespace Maas\Core\Test\Unit\Block\Adminhtml\Presentation;

use Maas\Core\Block\Adminhtml\Presentation\Presentation;
use League\CommonMark\CommonMarkConverter;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\ReadFactory;
use Magento\Framework\Module\Dir\Reader;
use Magento\Framework\View\Element\Template\Context;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\Filesystem\Directory\Read;

class PresentationTest extends TestCase
{
    /**
     * @var Context|MockObject
     */
    protected $contextMock;

    /**
     * @var Reader|MockObject
     * */
    protected $moduleReaderMock;

    /**
     * @var ReadFactory|MockObject
     */
    protected $readFactoryMock;

    /**
     * @var CommonMarkConverter|MockObject
     */
    protected $commonMarkConverterMock;

    /**
     * @var Presentation
     */
    protected $block;

    protected function setUp()
    {
        $this->contextMock = $this->getMockBuilder(Context::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->moduleReaderMock = $this->getMockBuilder(Reader::class)
            ->setMethods(['getModuleDir'])
            ->disableOriginalConstructor()
            ->getMock();

        $this->readFactoryMock = $this->getMockBuilder(ReadFactory::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->commonMarkConverterMock = $this->getMockBuilder(CommonMarkConverter::class)
            ->disableOriginalConstructor()
            ->setMethods(['convertToHtml'])
            ->getMock();

        $this->block = new Presentation(
            $this->contextMock,
            $this->moduleReaderMock,
            $this->readFactoryMock,
            $this->commonMarkConverterMock
        );
    }

    public function testDisplayRelease()
    {
        $releaseFile = __DIR__ . '/_files/CHANGELOG.md';
        $mark = '<h3>0.74.0-beta8</h3>
                    <ul>
                        <li>Performance Toolkit improvements
                            <ul>
                                <li>Added order generator</li>
                                <li>Added indexer mode switcher via profile config</li>
                            </ul>
                        </li>
                        <li>UI Improvements
                            <ul>
                                <li>Added hide/show columns for CMS pages/blocks grid on backend</li>
                                <li>Updated the multi-select functionality &amp; UI for CMS pages/blocks grid on backend</li>
                                <li>Added the new look &amp; feel for Edit Order Page (view/edit order)</li>
                            </ul>
                        </li>
                        <li>Framework Improvements
                            <ul>
                                <li>Updated API framework to support different integration object ACLs</li>
                                <li>Updated unit and integration tests config files to include tests from the Updater Application</li>
                                <li>Exceptions caught and logged before reaching Phrase::__toString() method</li>
                            </ul>
                        </li>
                    </ul>';

        $this->moduleReaderMock
            ->expects($this->any())
            ->method('getModuleDir')
            ->with('', 'Maas_Core')
            ->will($this->returnValue(__DIR__ . '/_files/'));

        $modulesDirectory = $this->getMockBuilder(Read::class)
            ->disableOriginalConstructor()
            ->setMethods(['isExist', 'isFile', 'readFile'])
            ->getMock();

        $modulesDirectory->method('isExist')->willReturn(true);
        $modulesDirectory->method('isFile')->willReturn(true);
        $modulesDirectory->method('readFile')
            ->willReturn(file_get_contents($releaseFile));

        $this->readFactoryMock->method('create')
            ->willReturn($modulesDirectory);

        $this->commonMarkConverterMock->method('convertToHtml')
            ->willReturn($mark);

        $this->assertEquals($mark, $this->block->displayRelease());

    }

    public function testFileNotExist()
    {
        $releaseFile = __DIR__ . '/_files/CHANGELOG.md';

        $this->moduleReaderMock
            ->expects($this->any())
            ->method('getModuleDir')
            ->with('', 'Maas_Core')
            ->will($this->returnValue(__DIR__ . '/_files/'));

        $modulesDirectory = $this->getMockBuilder(Read::class)
            ->disableOriginalConstructor()
            ->setMethods(['isExist', 'isFile', 'readFile'])
            ->getMock();

        $modulesDirectory->method('isExist')->willReturn(false);
        $modulesDirectory->method('isFile')->willReturn(false);
        $modulesDirectory->expects($this->never())->method('readFile')
            ->willReturn(file_get_contents($releaseFile));

        $this->readFactoryMock->method('create')
            ->willReturn($modulesDirectory);

        $this->block->displayRelease();
    }
}