### 0.74.0-beta8
* Performance Toolkit improvements
    * Added order generator
    * Added indexer mode switcher via profile config
* UI Improvements
    * Added hide/show columns for CMS pages/blocks grid on backend
    * Updated the multi-select functionality & UI for CMS pages/blocks grid on backend
    * Added the new look & feel for Edit Order Page (view/edit order)
* Framework Improvements
    * Updated API framework to support different integration object ACLs
    * Updated unit and integration tests config files to include tests from the Updater Application
    * Exceptions caught and logged before reaching Phrase::__toString() method
