<?php


namespace Maas\Core\Test\Unit\Block\Adminhtml\Presentation;

use Maas\Core\Block\Adminhtml\Presentation\Buttons;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template\Context;
use PHPUnit\Framework\TestCase;

class ButtonsTest extends TestCase
{
    /**
     * @var Buttons
     */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockBuilder
     */
    private $mockContext;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $_urlBuilderMock;

    public function setUp()
    {
        $objectManager = new \Magento\Framework\TestFramework\Unit\Helper\ObjectManager($this);
        $this->mockContext = $this->getMockBuilder(Context::class)
            ->disableOriginalConstructor()
            ->getMock();
        $this->_urlBuilderMock = $this->createMock(UrlInterface::class);
        $this->stub = $objectManager->getObject(
            Buttons::class,
            [
                '_urlBuilder' => $this->_urlBuilderMock
            ]
        );
    }

    public function testGetButtonReturnLink()
    {
        $url = 'http://magento.local:8221/admin/admin/system_config/edit/section/maas';
        $path = 'adminhtml/system_config/edit/section/maas';
        $retUrnValueExpected =  '<a class="action-primary button-presentation"'.
            ' href="http://magento.local:8221/admin/admin/system_config/edit/section/maas">Configuration</a>';
        $this->_urlBuilderMock->expects($this->any())->method('getUrl')->with($path)->willReturn($url);
        $button = $this->stub->getButton();
        $this->assertEquals($retUrnValueExpected, $button);
    }
}
