<?php

namespace Maas\Core\Test\Unit\Controller\Adminhtml\Index;

use Maas\Core\Controller\Adminhtml\Index\Presentation;
use Maas\Core\Helper\Data as Helper;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\Page\Config;
use Magento\Framework\View\Page\Title;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

/**
 * @covers \Maas\Core\Controller\Adminhtml\Index\Presentation
 */
class PresentationTest extends TestCase
{
    /**
     * @var Presentation
     */
    protected $presentationController;

    /**
     * @var Context|MockObject
     */
    protected $contextMock;

    /**
     * @var PageFactory|MockObject
     */
    protected $resultPageFactoryMock;

    /**
     * @var Page|MockObject
     */
    protected $resultPageMock;

    /**
     * @var Config|MockObject
     */
    protected $pageConfigMock;

    /**
     * @var Title|MockObject
     */
    protected $pageTitleMock;
    /**
     * @var Http|MockObject
     */
    protected $requestMock;

    /**
     * @var Helper|MockObject
     */
    protected $helperMock;

    /**
     * @var RedirectFactory|MockObject
     */
    protected $resultRedirectFactoryMock;

    /**
     * @var Redirect|MockObject
     */
    protected $resultRedirectMock;

    /**
     * @var ManagerInterface|MockObject
     */
    protected $messageManagerMock;

    protected function setUp()
    {
        $this->contextMock = $this->getMockBuilder(Context::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->requestMock = $this->getMockBuilder(Http::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->resultPageFactoryMock = $this->getMockBuilder(PageFactory::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->resultPageMock = $this->getMockBuilder(Page::class)
            ->disableOriginalConstructor()
            ->setMethods(['setActiveMenu', 'getConfig', 'addBreadcrumb'])
            ->getMock();

        $this->pageConfigMock = $this->getMockBuilder(Config::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->pageTitleMock = $this->getMockBuilder(Title::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->helperMock = $this->getMockBuilder(Helper::class)
            ->disableOriginalConstructor()
            ->setMethods(['isCommonMarkLibExists'])
            ->getMock();

        $this->resultRedirectFactoryMock = $this->createPartialMock(
            RedirectFactory::class,
            ['create']
        );

        $this->messageManagerMock = $this->getMockForAbstractClass(
            ManagerInterface::class,
            [],
            '',
            false,
            true,
            true,
            ['addErrorMessage']
        );

        $this->resultRedirectMock = $this->createPartialMock(
            Redirect::class,
            ['setPath']
        );

        $objectManager = new ObjectManager($this);

        $this->presentationController = $objectManager->getObject(
            Presentation::class,
            [
                'context' => $this->contextMock,
                'resultPageFactory' => $this->resultPageFactoryMock,
                'helper' => $this->helperMock,
                'messageManager' => $this->messageManagerMock,
                'resultRedirectFactory' => $this->resultRedirectFactoryMock
            ]
        );
    }

    /**
     * @covers \Maas\Core\Controller\Adminhtml\Index\Presentation::execute
     */
    public function testExecute()
    {
        $this->resultPageFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($this->resultPageMock);

        $this->helperMock->expects($this->once())
            ->method('isCommonMarkLibExists')
            ->willReturn(1);

        $this->resultPageMock->expects($this->once())
            ->method('setActiveMenu')
            ->with('Maas_Core::presentation');
        $this->resultPageMock->expects($this->once())
            ->method('getConfig')
            ->willReturn($this->pageConfigMock);
        $this->pageConfigMock->expects($this->once())
            ->method('getTitle')
            ->willReturn($this->pageTitleMock);

        $this->resultPageMock->expects($this->atLeastOnce())
            ->method('addBreadcrumb')
            ->withConsecutive(
                ['Octopia Marketplace for magento 2', 'Presentation']
            );

        $this->assertInstanceOf(
            Page::class,
            $this->presentationController->execute()
        );
    }

    /**
     * Test if CommonMark Library is installed
     */
    public function testCommonMarkNotInstalled()
    {
        $message = __('League\CommonMark library required to display Release notes for the Maas Module. Try running composer require league/commonmark.');

        $this->helperMock->expects($this->once())
            ->method('isCommonMarkLibExists')
            ->willThrowException(new NotFoundException($message));

        $this->messageManagerMock->expects($this->once())
            ->method('addErrorMessage')
            ->with($message);
        $this->messageManagerMock->expects($this->never())
            ->method('addSuccessMessage');

        $this->resultRedirectFactoryMock->expects($this->once())
            ->method('create')
            ->willReturn($this->resultRedirectMock);

        $this->resultRedirectMock->expects($this->once())
            ->method('setPath')
            ->with('adminhtml/*')
            ->willReturnSelf();

        $this->assertSame($this->resultRedirectMock, $this->presentationController->execute());

    }
}
