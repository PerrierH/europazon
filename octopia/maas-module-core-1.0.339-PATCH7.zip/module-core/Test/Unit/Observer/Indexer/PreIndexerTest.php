<?php
namespace Maas\Core\Test\Unit\Observer\Indexer;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Catalog\Model\Indexer\Product\Eav\Processor;
use Magento\Catalog\Model\Indexer\Product\Flat\State;
use Magento\Catalog\Model\Indexer\Product\Flat\Processor as FlatProcessor;
use Magento\CatalogInventory\Model\Indexer\Stock\Processor as StockProcessor;
use Maas\Core\Observer\Indexer\PreIndexer;
use Magento\Framework\Event\Observer;

/**
 * @covers \Maas\Core\Observer\Indexer\PreIndexer
 */
class PreIndexerTest extends TestCase
{
    /**
     * Mock Processor
     *
     * @var Processor|MockObject
     */
    private $productEavProcessorMock;

    /**
     * Mock State
     *
     * @var State|MockObject
     */
    private $productFlatStateMock;

    /**
     * Mock FlatProcessor
     *
     * @var FlatProcessor|MockObject
     */
    private $productFlatProcessorMock;

    /**
     * Mock StockProcessor
     *
     * @var StockProcessor|MockObject
     */
    private $stockProcessorMock;

    /**
     * Class to test instance
     *
     * @var PreIndexer
     */
    private $preIndexer;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->productEavProcessorMock = $this->getMockBuilder(Processor::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->productFlatStateMock = $this->getMockBuilder(State::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->productFlatProcessorMock = $this->getMockBuilder(FlatProcessor::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->stockProcessorMock = $this->getMockBuilder(StockProcessor::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->preIndexer = new PreIndexer(
        	$this->productEavProcessorMock,
        	$this->productFlatStateMock,
        	$this->productFlatProcessorMock,
        	$this->stockProcessorMock
        );
    }

    /**
     * @return void
     */
    public function testExecute() : void
    {
        $observerMock = $this->getMockBuilder(Observer::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->preIndexer->execute($observerMock);
    }
}
