<?php
namespace Maas\Core\Test\Unit\Setup\Config;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Config\Model\ResourceModel\Config;
use Maas\Core\Setup\Config\Data;

/**
 * @covers \Maas\Core\Setup\Config\Data
 */
class DataTest extends TestCase
{
    /**
     * Mock Config
     *
     * @var Config|MockObject
     */
    private $configResourceMock;

    /**
     * Class to test instance
     *
     * @var Data
     */
    private $data;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->configResourceMock = $this->getMockBuilder(Config::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->data = new Data(
        	$this->configResourceMock
        );
    }

    /**
     * @return void
     */
    public function testDeleteMaasConfigurations() : void
    {
        $this->data->deleteMaasConfigurations();
    }
}
