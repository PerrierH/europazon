<?php
/**
 * ChangeMaasCoreStatus
 *
 * @copyright Copyright © 2020 Cdiscount. All rights reserved.
 * @author    aamouri@neosys.com
 */

namespace Maas\Core\Observer;

use Magento\Backend\Block\Menu;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;

/**
 * Class ChangeMaasCoreStatus
 *
 * @package Maas\Core\Observer
 * We only call magento function wich is already tested
 * @codeCoverageIgnore
 */
class ChangeMaasCoreStatus implements ObserverInterface
{
    /**
     * @var CacheInterface
     */
    protected $_cache;

    public function __construct(
        CacheInterface $cache
    ) {
        $this->_cache = $cache;
    }

    /**
     * Execute Observer
     *
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $this->_cache->clean(array(Menu::CACHE_TAGS));
    }
}
