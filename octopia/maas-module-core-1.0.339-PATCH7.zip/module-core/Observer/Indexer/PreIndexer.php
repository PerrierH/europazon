<?php

namespace Maas\Core\Observer\Indexer;

use Magento\Catalog\Model\Indexer\Product\Eav\Processor as EavProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\Processor as FlatProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\State as FlatState;
use Magento\CatalogInventory\Model\Indexer\Stock\Processor as StockProcessor;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;


class PreIndexer implements ObserverInterface
{
    /**
     * @var EavProcessor
     */
    private $productEavProcessor;
    /**
     * @var FlatState
     */
    private $productFlatState;
    /**
     * @var FlatProcessor
     */
    private $productFlatProcessor;
    /**
     * @var StockProcessor
     */
    private $stockProcessor;

    /**
     * @param EavProcessor $productEavProcessor
     * @param FlatState $productFlatState
     * @param FlatProcessor $productFlatProcessor
     * @param StockProcessor $stockProcessor
     */
    public function __construct(
        EavProcessor $productEavProcessor,
        FlatState $productFlatState,
        FlatProcessor $productFlatProcessor,
        StockProcessor $stockProcessor
    )
    {
        $this->productEavProcessor = $productEavProcessor;
        $this->productFlatState = $productFlatState;
        $this->productFlatProcessor = $productFlatProcessor;
        $this->stockProcessor = $stockProcessor;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer) {
        // Reindex current batch of products
        $this->reindexProducts($observer->getData('ids'));
    }

    /**
     * @param array $ids
     */
    private function reindexProducts(array $ids)
    {
        if (count($ids)) {
            if (!$this->productEavProcessor->isIndexerScheduled()) {
                $this->productEavProcessor->markIndexerAsInvalid();
            } else {
                $this->productEavProcessor->reindexList($ids);
            }

            if ($this->productFlatState->isFlatEnabled() && !$this->productFlatProcessor->isIndexerScheduled()) {
                $this->productFlatProcessor->markIndexerAsInvalid();
            }
            else {
                $this->productFlatProcessor->reindexList($ids);
            }

            if (!$this->stockProcessor->isIndexerScheduled()) {
                $this->stockProcessor->markIndexerAsInvalid();
            } else {
                $this->stockProcessor->reindexList($ids);
            }
        }
    }
}