<?php

namespace Maas\Core\Setup\Config;

use Magento\Config\Model\ResourceModel\Config;

/**
 * Class Data
 *
 * @package Maas\Core\Setup\Config
 */
class Data
{
    /**
     * @var Config
     */
    protected $configResource;

    /**
     * Data constructor.
     *
     * @param Config $configResource
     */
    public function __construct(
        Config $configResource
    ) {
        $this->configResource = $configResource;
    }

    public function deleteMaasConfigurations()
    {
        $connection = $this->configResource->getConnection();
        $connection->delete($this->configResource->getMainTable(), "path like 'maas_%/%'");
    }
}