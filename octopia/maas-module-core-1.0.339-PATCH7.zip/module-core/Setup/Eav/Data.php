<?php

namespace Maas\Core\Setup\Eav;

use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Model\Config;
use Magento\Eav\Model\ResourceModel\Entity\Attribute;
use Magento\Eav\Setup\EavSetup;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class Data
 *
 * @package Maas\Core\Setup\Schema
 * @codeCoverageIgnore Impact on database contents
 */
class Data
{
    /**
     * @var EavSetup
     */
    protected $eavSetup;

    /**
     * @var Config
     */
    protected $eavConfig;

    /**
     * @var AttributeRepositoryInterface
     */
    protected $attributeRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var Attribute
     */
    protected $entityAttributeResource;

    /**
     * Data constructor.
     *
     * @param EavSetup $eavSetup
     * @param Config $eavConfig
     * @param AttributeRepositoryInterface $attributeRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Attribute $entityAttributeResource
     */
    public function __construct(
        EavSetup $eavSetup,
        Config $eavConfig,
        AttributeRepositoryInterface $attributeRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Attribute $entityAttributeResource
    ) {
        $this->eavSetup = $eavSetup;
        $this->eavConfig = $eavConfig;
        $this->attributeRepository = $attributeRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->entityAttributeResource = $entityAttributeResource;
    }

    /**
     * @param string|int $entityType
     * @param array $entityTypeProperties
     *
     * @return mixed
     */
    public function createEntityType($entityType, $entityTypeProperties)
    {
        $addedEntityTypeProperties = [
            'entity_type_code' => $entityType,
            'attribute_model' => null,
            'table' => $entityType . '_entity',
            'entity_table' => $entityType . '_entity',
            'is_data_sharing' => 1,
            'data_sharing_key' => 'default',
            'increment_model' => null,
            'increment_per_store' => 0,
            'additional_attribute_table' => null
        ];

        $addedEntityTypeProperties = array_merge($addedEntityTypeProperties, $entityTypeProperties);

        $this->eavSetup->addEntityType(
            $entityType, $addedEntityTypeProperties
        );
        $this->eavSetup->addAttributeSet($entityType, 'Default');
        $attributeSetIds = $this->eavSetup->getAllAttributeSetIds($entityType);
        $attributeSetId = null;
        if ($attributeSetIds) {
            $attributeSetId = reset($attributeSetIds);
            $this->eavSetup->updateEntityType($entityType, 'default_attribute_set_id', $attributeSetId);
        }
        $this->eavSetup->cleanCache();
        $result = $this->eavSetup->getEntityType($entityType);
        if ($attributeSetId) {
            $result['default_attribute_set_id'] = $attributeSetId;
        }
        return $result;
    }

    /**
     * @param string|int $entityType
     *
     * @return $this
     */
    public function deleteData($entityType)
    {
        // eav_entity_attribute appears to lack a lot of foreign keys
        $entityTypeId = $this->eavConfig->getEntityType($entityType)->getId();
        $entityAttributeConnection = $this->entityAttributeResource->getConnection();
        $entityAttributeConnection->delete(
            $this->entityAttributeResource->getTable('eav_entity_attribute'),
            $entityAttributeConnection->quoteInto('entity_type_id = ?', $entityTypeId)
        );

        $attributeSetIds = $this->eavSetup->getAllAttributeSetIds($entityType);
        foreach ($attributeSetIds as $attributeSetId) {
            $group = $this->eavSetup->getAttributeGroup($entityType, $attributeSetId, 'General');
            $this->eavSetup->removeAttributeGroup($entityType, $attributeSetId, $group['attribute_group_id']);
            $this->eavSetup->removeAttributeSet($entityType, $attributeSetId);
        }
        $this->eavSetup->updateEntityType($entityType, 'additional_attribute_table', null);
        $this->eavConfig->clear();
        $this->deleteAllAttributes($entityType);

        $this->eavSetup->removeEntityType($entityType);
        return $this;
    }

    /**
     * @param string|int $entityType
     *
     * @return $this
     */
    protected function deleteAllAttributes($entityType)
    {
        $entityTypeData = $this->eavSetup->getEntityType($entityType);
        if ($entityTypeData && isset($entityTypeData['entity_type_code'])) {
            $searchCriteria = $this->searchCriteriaBuilder->addFilter('is_user_defined', 1)->create();
            $attributesList = $this->attributeRepository->getList($entityTypeData['entity_type_code'], $searchCriteria);
            foreach ($attributesList->getItems() as $attribute) {
                $this->attributeRepository->delete($attribute);
            }
        }
        return $this;
    }
}