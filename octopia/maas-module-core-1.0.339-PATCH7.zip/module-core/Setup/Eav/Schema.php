<?php

namespace Maas\Core\Setup\Eav;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Zend_Db_Exception;

/**
 * Class Schema
 *
 * @package Maas\Core\Setup\Schema
 * @codeCoverageIgnore Impact on database schema
 */
class Schema
{
    /**
     * @param SchemaSetupInterface $setup
     * @param int|string $entityType
     * @param array $additionalColumns
     * @param array $indexes
     * @param array $foreignKeys
     * @param string $entityNameInComment
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    public function createEntityTable(
        SchemaSetupInterface $setup,
        $entityType,
        $additionalColumns,
        $indexes,
        $foreignKeys,
        $entityNameInComment
    ) {
        $tableName = $entityType . '_entity';

        if (!$setup->getConnection()->isTableExists($setup->getTable($tableName))) {
            $table = $setup->getConnection()->newTable(
                $setup->getTable($tableName)
            )->addColumn(
                'entity_id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Entity Id'
            )->addColumn(
                'attribute_set_id',
                Table::TYPE_SMALLINT,
                null,
                ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                'Attribute Set ID'
            );

            $this->applyColumns($table, $additionalColumns);

            $table->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                'Creation Time'
            )
                ->addColumn(
                    'updated_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
                    'Update Time'
                );

            $table->addIndex(
                $setup->getIdxName($tableName, ['attribute_set_id']),
                ['attribute_set_id']
            );

            $this->applyIndexes($setup, $tableName, $table, $indexes);

            $table->addForeignKey(
                $setup->getFkName(
                    $tableName,
                    'attribute_set_id',
                    'eav_attribute_set',
                    'attribute_set_id'
                ),
                'attribute_set_id',
                $setup->getTable('eav_attribute_set'),
                'attribute_set_id',
                Table::ACTION_CASCADE
            );

            $table->setComment($entityNameInComment.' Entity Table');

            $this->applyForeignKeys($setup, $tableName, $table, $foreignKeys);

            $setup->getConnection()->createTable($table);
        }
        return $this;
    }

    /**
     * @param Table $table
     * @param array $additionalColumns
     *
     * @return $this
     */
    private function applyColumns($table, $additionalColumns)
    {
        foreach ($additionalColumns as $additionalColumn) {
            list($name, $type, $size, $options, $comment) = $additionalColumn;
            $table->addColumn($name, $type, $size, $options, $comment);
        }
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $tableName
     * @param Table $table
     * @param array $indexes
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    private function applyIndexes(SchemaSetupInterface $setup, $tableName, $table, $indexes)
    {
        foreach ($indexes as $index) {
            list($indexType, $fields, $options) = $index;
            $indexName = $setup->getIdxName($tableName, $fields, $indexType);
            $table->addIndex($indexName, $fields, $options);
        }
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $tableName
     * @param Table $table
     * @param array $foreignKeys
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    private function applyForeignKeys(SchemaSetupInterface $setup, $tableName, $table, $foreignKeys)
    {
        foreach ($foreignKeys as $foreignKey) {
            list($field, $referencedTable, $referencedField, $onDelete) = $foreignKey;
            $referencedTable = $setup->getTable($referencedTable);
            $table->addForeignKey(
                $setup->getFkName(
                    $tableName, $field, $referencedTable, $referencedField
                ),
                $field, $setup->getTable($referencedTable), $referencedField, $onDelete
            );
        }
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $propertiesTable
     * @param array $propertiesColumns
     * @param array $propertiesIndexes
     * @param string $entityNameInComment
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    public function createPropertiesTable(
        SchemaSetupInterface $setup,
        $propertiesTable,
        $propertiesColumns,
        $propertiesIndexes,
        $entityNameInComment
    ) {
        $propertiesTableName = $setup->getTable($propertiesTable);
        $table = $setup->getConnection()
            ->newTable(
                $propertiesTableName
            )
            ->addColumn(
                'attribute_id',
                Table::TYPE_SMALLINT,
                null,
                ['unsigned' => true, 'nullable' => false, 'primary' => true],
                'Attribute ID'
            );

        $this->applyColumns($table, $propertiesColumns);
        $this->applyIndexes($setup, $propertiesTableName, $table, $propertiesIndexes);

        $table->addForeignKey(
            $setup->getFkName($propertiesTableName, 'attribute_id', 'eav_attribute', 'attribute_id'),
            'attribute_id',
            $setup->getTable('eav_attribute'),
            'attribute_id',
            Table::ACTION_CASCADE
        )
            ->setComment(
                $entityNameInComment.' EAV Attribute Table'
            );
        $setup->getConnection()
            ->createTable($table);
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $propertiesScopeTable
     * @param array $propertiesScopeColumns
     * @param array $propertiesScopeIndexes
     * @param string $entityNameInComment
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    public function createPropertiesScopeTable(
        SchemaSetupInterface $setup,
        $propertiesScopeTable,
        $propertiesScopeColumns,
        $propertiesScopeIndexes,
        $entityNameInComment
    ) {
        $propertiesTableName = $setup->getTable($propertiesScopeTable);
        $table = $setup->getConnection()
            ->newTable(
                $propertiesTableName
            )
            ->addColumn(
                'attribute_id',
                Table::TYPE_SMALLINT,
                null,
                ['unsigned' => true, 'nullable' => false, 'primary' => true],
                'Attribute ID'
            )->addColumn(
                'website_id',
                Table::TYPE_SMALLINT,
                null,
                ['unsigned' => true, 'nullable' => false, 'primary' => true],
                'Website Id'
            )->addIndex(
                $setup->getIdxName($propertiesTableName, ['website_id']),
                ['website_id']
            );

        $this->applyColumns($table, $propertiesScopeColumns);
        $this->applyIndexes($setup, $propertiesTableName, $table, $propertiesScopeIndexes);

        $table->addForeignKey(
            $setup->getFkName($propertiesTableName, 'attribute_id', 'eav_attribute', 'attribute_id'),
            'attribute_id',
            $setup->getTable('eav_attribute'),
            'attribute_id',
            Table::ACTION_CASCADE
        )->addForeignKey(
            $setup->getFkName($propertiesTableName, 'website_id', 'store_website', 'website_id'),
            'website_id',
            $setup->getTable('store_website'),
            'website_id',
            Table::ACTION_CASCADE
        )
            ->setComment(
                $entityNameInComment.' EAV Attribute Scoped Table'
            );
        $setup->getConnection()
            ->createTable($table);
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $entityType
     * @param array $types
     * @param string $entityNameInComment
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    public function createAttributeTables(SchemaSetupInterface $setup, $entityType, $types, $entityNameInComment)
    {
        $entityTableName = $entityType . '_entity';
        foreach ($types as $typeCode => $typeDesc) {
            $tableName = $entityType . '_entity_' . $typeCode;

            list($valueType, $valueSize, $valueParam) = $typeDesc;

            $table = $setup->getConnection()
                ->newTable($setup->getTable($tableName))
                ->addColumn(
                    'value_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'nullable' => false, 'primary' => true],
                    'Value ID'
                )
                ->addColumn(
                    'attribute_id',
                    Table::TYPE_SMALLINT,
                    null,
                    ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                    'Attribute ID'
                )
                ->addColumn(
                    'store_id',
                    Table::TYPE_SMALLINT,
                    null,
                    ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                    'Store ID'
                )
                ->addColumn(
                    'entity_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                    'Entity ID'
                )
                ->addColumn(
                    'value',
                    $valueType,
                    $valueSize,
                    $valueParam,
                    'Value'
                )
                ->addIndex(
                    $setup->getIdxName(
                        $tableName,
                        ['entity_id', 'attribute_id', 'store_id'],
                        AdapterInterface::INDEX_TYPE_UNIQUE
                    ),
                    ['entity_id', 'attribute_id', 'store_id'],
                    ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
                )
                ->addIndex(
                    $setup->getIdxName($tableName, ['attribute_id']),
                    ['attribute_id']
                )
                ->addIndex(
                    $setup->getIdxName($tableName, ['store_id']),
                    ['store_id']
                )
                ->addForeignKey(
                    $setup->getFkName(
                        $tableName,
                        'attribute_id',
                        'eav_attribute',
                        'attribute_id'
                    ),
                    'attribute_id',
                    $setup->getTable('eav_attribute'),
                    'attribute_id',
                    Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $setup->getFkName(
                        $tableName,
                        'entity_id',
                        'catalog_product_entity',
                        'entity_id'
                    ),
                    'entity_id',
                    $setup->getTable($entityTableName),
                    'entity_id',
                    Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $setup->getFkName($tableName, 'store_id', 'store', 'store_id'),
                    'store_id',
                    $setup->getTable('store'),
                    'store_id',
                    Table::ACTION_CASCADE
                )
                ->setComment($entityNameInComment.' Attributes - ' . $typeCode);
            $setup->getConnection()->createTable($table);
        }
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $entityType
     * @param string $entityNameInComment
     *
     * @return $this
     * @throws Zend_Db_Exception
     */
    public function createFormTable(SchemaSetupInterface $setup, $entityType, $entityNameInComment)
    {
        $tableName = $setup->getTable($entityType . '_form_attribute');

        $table = $setup->getConnection()->newTable(
            $tableName
        )->addColumn(
            'form_code',
            Table::TYPE_TEXT,
            32,
            ['nullable' => false, 'primary' => true],
            'Form Code'
        )->addColumn(
            'attribute_id',
            Table::TYPE_SMALLINT,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true],
            'Attribute Id'
        )->addIndex(
            $setup->getIdxName($tableName, ['attribute_id']),
            ['attribute_id']
        )->addForeignKey(
            $setup->getFkName($tableName, 'attribute_id', 'eav_attribute', 'attribute_id'),
            'attribute_id',
            $setup->getTable('eav_attribute'),
            'attribute_id',
            Table::ACTION_CASCADE
        )->setComment(
            $entityNameInComment.' Form Attribute'
        );
        $setup->getConnection()->createTable($table);
        return $this;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param string $entityType
     * @param array $typeCodes
     * @param string|null $propertiesTable
     * @param string|null $propertiesScopeTable
     *
     * @return $this
     */
    public function deleteTables(
        SchemaSetupInterface $setup,
        $entityType,
        $typeCodes,
        $propertiesTable = null,
        $propertiesScopeTable = null
    ) {
        if ($propertiesTable) {
            $propertiesTableName = $setup->getTable($propertiesTable);
            if ($setup->tableExists($propertiesTableName)) {
                $setup->getConnection()->dropTable($propertiesTableName);
            }
        }
        if ($propertiesScopeTable) {
            $propertiesScopeTableName = $setup->getTable($propertiesScopeTable);
            if ($setup->tableExists($propertiesScopeTableName)) {
                $setup->getConnection()->dropTable($propertiesScopeTableName);
            }
        }
        foreach ($typeCodes as $typeCode) {
            $tableName = $setup->getTable($entityType . '_entity_' . $typeCode);

            if ($setup->tableExists($tableName)) {
                $setup->getConnection()->dropTable($tableName);
            }
        }
        $entityTableName = $setup->getTable($entityType . '_entity');
        if ($setup->tableExists($entityTableName)) {
            $setup->getConnection()->dropTable($entityTableName);
        }
        $formTableName = $setup->getTable($entityType . '_form_attribute');
        if ($setup->tableExists($formTableName)) {
            $setup->getConnection()->dropTable($formTableName);
        }
        return $this;
    }
}