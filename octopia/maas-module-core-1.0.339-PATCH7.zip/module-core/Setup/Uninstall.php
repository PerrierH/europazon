<?php

namespace Maas\Core\Setup;

use Maas\Core\Setup\Config\Data;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 *
 * @package Maas\Core\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    /**
     * @var Data
     */
    protected $configData;

    /**
     * Uninstall constructor.
     *
     * @param Data $configData
     */
    public function __construct(
        Data $configData
    )
    {
        $this->configData = $configData;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $connection = $setup->getConnection();
        /* Remove Maas_Core Token table */
        $connection->query('SET FOREIGN_KEY_CHECKS=0;');
        $connection->dropTable($setup->getTable('maas_auth_token_info'));
        $connection->query('SET FOREIGN_KEY_CHECKS=1;');

        $this->configData->deleteMaasConfigurations();

        $setup->endSetup();
    }
}
