<?php


namespace Maas\Core\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 * @codeCoverageIgnore
 * @package Maas\Core\Setup
 *
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        $this->createTableAuthTokenInfo($setup, $connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     *
     * @param $connection
     */
    protected function createTableAuthTokenInfo(SchemaSetupInterface $setup, $connection)
    {
            $table = $connection->newTable(
                $setup->getTable('maas_auth_token_info')
            )
                ->addColumn(
                    'token_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Token Id'
                )->addColumn(
                    'access_token',
                    Table::TYPE_TEXT,
                    null,
                    [
                        'nullable' => true
                    ],
                    'Access token'
                )
                ->addColumn(
                    'refresh_token',
                    Table::TYPE_TEXT,
                    null,
                    [
                        'nullable' => true
                    ],
                    'Refresh token'
                )
                ->addColumn(
                    'expires_in',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true,
                    ],
                    'Expires in'
                )
                ->addColumn(
                    'refresh_expires_in',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true,
                    ],
                    'Refresh expires in'
                )
                ->addColumn(
                    'token_type',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true
                    ],
                    'Token type'
                )
                ->addColumn(
                    'scope',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true
                    ],
                    'Scope'
                )
                ->addColumn(
                    'created_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => true, 'default' => new \Zend_Db_Expr('CURRENT_TIMESTAMP')],
                    'Created at'
                )
                ->setComment('maas_auth_token_info Table');
            $connection->createTable($table);
        }
}
