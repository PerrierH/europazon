<?php

namespace Maas\Core\Model;

use Exception;
use Maas\Core\Model\Service\Instantiate;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class AbstractRepository
 *
 * @package Maas\Core\Model
 * @codeCoverageIgnore
 */
abstract class AbstractRepository
{
    /**
     * @var object
     */
    protected $resource;

    /**
     * @var object
     */
    protected $modelFactory;

    /**
     * @var object
     */
    protected $searchResultsFactory;

    /**
     * @var object
     */
    protected $collectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * AbstractRepository constructor.
     *
     * @param $resource
     * @param $modelFactory
     * @param $searchResultsFactory
     * @param $collectionFactory
     * @param CollectionProcessorInterface $collectionProcessor
     * @param Instantiate $instantiateService
     */
    public function __construct(
        $resource,
        $modelFactory,
        $searchResultsFactory,
        $collectionFactory,
        CollectionProcessorInterface $collectionProcessor,
        Instantiate $instantiateService
    ) {
        $this->resource = $instantiateService->getInstanceIfArray($resource);
        $this->modelFactory = $instantiateService->getInstanceIfArray($modelFactory);
        $this->searchResultsFactory = $instantiateService->getInstanceIfArray($searchResultsFactory);
        $this->collectionFactory = $instantiateService->getInstanceIfArray($collectionFactory);
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @param int $id
     *
     * @throws NoSuchEntityException
     */
    public function deleteById($id)
    {
        $model = $this->get($id);
        $this->resource->delete($model);
    }

    /**
     * @param int $id
     *
     * @return object
     * @throws NoSuchEntityException
     */
    public function get($id)
    {
        $model = $this->modelFactory->create();
        $this->resource->load($model, $id);
        if (!$model->getId()) {
            throw NoSuchEntityException::singleField('id', $id);
        }
        return $model;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return object
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->collectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResult = $this->searchResultsFactory->create();
        $searchResult->setSearchCriteria($searchCriteria);
        $searchResult->setItems($collection->getItems());
        $searchResult->setTotalCount($collection->getSize());

        return $searchResult;
    }

    /**
     * @param mixed $entity
     *
     * @return mixed
     * @throws AlreadyExistsException
     */
    protected function _save($entity)
    {
        $this->resource->save($entity);
        return $entity;
    }

    /**
     * @param mixed $entity
     *
     * @throws Exception
     */
    protected function _delete($entity)
    {
        $this->resource->delete($entity);
    }
}
