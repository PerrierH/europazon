<?php

namespace Maas\Core\Model;

use DateTime;
use Maas\Core\Api\Data\TokenInterface;
use Maas\Core\Model\ResourceModel\Token as ResourceModel;
use Magento\Framework\Model\AbstractModel;
use Zend_Db_Expr;

/**
 * Class Token
 * @codeCoverageIgnore
 * @package Maas\Core\Model
 */
class Token extends AbstractModel implements TokenInterface
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @return mixed|String|null
     */
    public function getAccessToken()
    {
        return $this->_getData(self::ACCESS_TOKEN);
    }

    /**
     * @param string $token
     * @return $this|Token
     */
    public function setAccessToken($token)
    {
        $this->setData(self::ACCESS_TOKEN, $token);
        return $this;
    }

    /**
     * @return mixed|string|null
     */
    public function getTokenType()
    {
        return $this->_getData(self::TOKEN_TYPE);
    }

    /**
     * @param string $type
     * @return $this|Token
     */
    public function setTokenType($type)
    {
        $this->setData(self::ACCESS_TOKEN, $type);
        return $this;
    }

    /**
     * @return mixed|string|null
     */
    public function getExpiredIn()
    {
        return $this->_getData(self::EXPIRES_IN);
    }

    /**
     * @param int $time
     * @return $this|Token
     */
    public function setExpiredIn($time)
    {
        $this->setData(self::EXPIRES_IN, $time);
        return $this;
    }

    /**
     * @return mixed|string|null
     */
    public function getScope()
    {
        return $this->_getData(self::SCOPE);
    }

    /**
     * @param string $scope
     * @return $this|Token
     */
    public function setScope($scope)
    {
        $this->setData(self::SCOPE, $scope);
        return $this;
    }

    /**
     * @return mixed|String|null
     */
    public function getRefreshToken()
    {
        return $this->_getData(self::REFRESH_TOKEN);
    }

    /**
     * @param string $token
     * @return $this|Token
     */
    public function setRefreshToken($token)
    {
        $this->setData(self::REFRESH_TOKEN, $token);
        return $this;
    }

    /**
     * @return mixed|string|null
     */
    public function getRefreshExpiredIn()
    {
        return $this->_getData(self::REFRESH_EXPIRES_IN);
    }

    /**
     * @param int $time
     * @return $this|Token
     */
    public function setRefreshExpiredIn($time)
    {
        $this->setData(self::REFRESH_EXPIRES_IN, $time);
        return $this;
    }
}
