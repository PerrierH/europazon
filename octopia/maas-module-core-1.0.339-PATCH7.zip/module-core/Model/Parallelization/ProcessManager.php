<?php

namespace Maas\Core\Model\Parallelization;

use Symfony\Component\Process\Process;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * This ProcessManager is a simple wrapper to enable parallel processing using Symfony Process component.
 * @codeCoverageIgnore
 */

/**
 * Class ProcessManager
 *
 * @package Maas\Core\Model\Parallelization
 * @codeCoverageIgnore
 */
class ProcessManager
{

    /**
     * @param OutputInterface $output
     * @param array $processes
     * @param $maxParallel
     * @param int $poll
     */
    public function runParallel(OutputInterface $output, array $processes, $maxParallel, int $poll = 1000)
    {
        $this->validateProcesses($processes);

        // do not modify the object pointers in the argument, copy to local working variable
        $processesQueue = $processes;

        // fix maxParallel to be max the number of processes or positive
        $maxParallel = min(abs($maxParallel), count($processesQueue));

        // get the first stack of processes to start at the same time
        /** @var Process[] $currentProcesses */
        $currentProcesses = array_splice($processesQueue, 0, $maxParallel);
        // start the initial stack of processes
        foreach ($currentProcesses as $process) {
            $output->writeln('Starting ' . $process->getCommandLine());
            $process->start();
            $process->setTimeout(null);
            foreach ($process as $data) {
                echo $data;
            }
        }

        do {
            // wait for the given time
            usleep($poll);

            // remove all finished processes from the stack
            $currentProcesses = $this->removeFinishedProcesses($currentProcesses, $processesQueue, $output);

            // continue loop while there are processes being executed or waiting for execution
        } while (count($processesQueue) > 0 || count($currentProcesses) > 0);
    }

    /**
     * @param Process[] $processes
     */
    protected function validateProcesses(array $processes)
    {
        if (empty($processes)) {
            throw new \InvalidArgumentException('Can not run in parallel 0 commands');
        }

        foreach ($processes as $process) {
            if (!($process instanceof Process)) {
                throw new \InvalidArgumentException('Process in array need to be instance of Symfony Process');
            }
        }
    }

    /**
     * @param array $currentProcesses
     * @param array $processesQueue
     * @param OutputInterface $output
     *
     * @return array
     */
    private function removeFinishedProcesses(array $currentProcesses, array $processesQueue, OutputInterface $output)
    {
        foreach ($currentProcesses as $index => $process) {
            if (!$process->isRunning()) {
                unset($currentProcesses[$index]);
                // directly add and start new process after the previous finished
                if (!empty($processesQueue)) {
                    $nextProcess = array_shift($processesQueue);
                    $nextProcess->start();
                    $currentProcesses[] = $nextProcess;
                }

                $processOutput = $process->getOutput();
                if (!$process->isSuccessful()) {
                    $errorOutput = $process->getErrorOutput();
                    $output->writeln('Error occured:' . $errorOutput);
                } else {
                    $output->writeln($processOutput);
                }
            }
        }
        return $currentProcesses;
    }
}
