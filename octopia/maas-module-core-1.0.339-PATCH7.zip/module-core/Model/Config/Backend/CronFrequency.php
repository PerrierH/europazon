<?php

namespace Maas\Core\Model\Config\Backend;


use Exception;
use Maas\Core\Model\Config;
use Maas\Core\Model\Service\CronScheduleDelete;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Value;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\Registry;
use Magento\Framework\App\Cache\Manager;


/**
 * Class CronFrequency
 * @package Maas\Core\Model\Config\Backend
 */
class CronFrequency extends Value
{
    const IMPOSSIBLE_CRON_DATE = '0 0 30 2 *'; // run at 00:00 on the 30th of February !!!
    const CRON_PATH_PATTERN = 'crontab/%s/jobs/%s/schedule/cron_expr';
    const FREQUENCY_UNIT_TYPES = ['HOUR' => 'hour', 'MIN' => 'min'];
    const MAAS_CRONS = [ // MAAS_CRONS array structure: 'cron group' key => array of its 'cron job code' elements
        'maas_core' => [
            'maas_runcli',
            'maas_catalog_rule_categorization',
            'maas_best_offer_update'
        ],
        'maas_catalog' => [
            'maas_catalog_category_import',
            'maas_catalog_product_import',
            'maas_offer_offer_import',
            'maas_seller_seller_import'
        ],
        'maas_order' => [
            'maas_order_status_import',
            'maas_order_orders_export'
        ],
        'maas_log' => [
            'maas_flush_old_log',
            'maas_front_checker'
        ],
        'maas_grc' => [
            'maas_grc_notification'
        ]
    ];

    const MAAS_CRON_BO_RELATED_CONFIG = [
        ['path' => 'maas_catalog_rule/general/catalog_rule_categorization_enabled', 'unit' => 'hour'],
        ['path' => 'maas_products/general/catalog_product_import_enabled', 'unit' => 'hour'],
        ['path' => 'maas_offers/general/offer_offer_import_enabled', 'unit' => 'min'],
        ['path' => 'maas_orders/general/order_orders_export_enabled', 'unit' => 'min'],
        ['path' => 'maas_orders/general/order_status_import_enabled', 'unit' => 'min'],
        ['path' => 'maas_sellers/general/seller_seller_import_enabled', 'unit' => 'hour'],
        ['path' => 'maas_bestoffer/general/best_offer_update_enabled', 'unit' => 'min'],
        ['path' => 'maas_grc/email_new_message_notification/grc_notification_enabled', 'unit' => 'min']
    ];

    /**
     * @var CronScheduleDelete
     */
    protected $cronScheduleDelete;

    /**
     * @var WriterInterface
     */
    protected $configWriter;

    /**
     * @var Manager
     */
    protected $cacheManager;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var Config
     */
    protected $config;

    /**
     * CronFrequency constructor.
     * @param Context $context
     * @param Registry $registry
     * @param ScopeConfigInterface $scopeConfig
     * @param TypeListInterface $cacheTypeList
     * @param CronScheduleDelete $cronScheduleDelete
     * @param WriterInterface $configWriter
     * @param Manager $cacheManager
     * @param Config $config
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ScopeConfigInterface $scopeConfig,
        TypeListInterface $cacheTypeList,
        CronScheduleDelete $cronScheduleDelete,
        WriterInterface $configWriter,
        Manager $cacheManager,
        Config $config,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $scopeConfig, $cacheTypeList, $resource, $resourceCollection, $data);
        $this->cronScheduleDelete = $cronScheduleDelete;
        $this->configWriter = $configWriter;
        $this->cacheManager = $cacheManager;
        $this->scopeConfig = $scopeConfig;
        $this->config = $config;
    }

    /**
     * @return CronFrequency
     * @throws LocalizedException
     */
    public function afterSave()
    {
        $this->configCacheClean();

        if ( $this->getPath() === Config::MODULE_ENABLED) {
            // Here we target massive cron jobs configurations
            $this->getValue() ?
                $this->activateAllMaasCronJobs() :
                $this->deactivateAllMaasCronJobs();
        }
        else {
            $cronJobCode = 'maas_' . str_replace('_enabled', '', $this->getField());
            // Here we target related cron job configuration
            $this->getValue() ?
                $this->activateAssociatedMaasCronJob($cronJobCode) :
                $this->deactivateAssociatedMaasCronJob($cronJobCode);
        }

        return parent::afterSave();
    }

    /**
     * @param string $cronJobCode
     * @throws LocalizedException
     */
    private function deactivateAssociatedMaasCronJob(string $cronJobCode)
    {
        try {
            /*
             * Setting the cron to an impossible date, as advised here:
             * https://devdocs.magento.com/guides/v2.4/config-guide/cron/custom-cron-ref.html
             */
            $this->saveConfig($this->getAssociatedCronConfigPath($cronJobCode), self::IMPOSSIBLE_CRON_DATE);
        } catch (Exception $e) {
            throw new LocalizedException(__('We can\'t save the cron expression.'));
        }
        $this->cronScheduleDelete->execute([$cronJobCode]);
    }

    /**
     * @param string $cronJobCode
     * @throws LocalizedException
     */
    private function activateAssociatedMaasCronJob(string $cronJobCode)
    {
        if ($this->config->isModuleEnabled()) {
            $cronConfigPath = $this->getAssociatedCronConfigPath($cronJobCode);
            $relatedConfigPath = $this->getCronBORelatedConfigPath($cronJobCode);
            $frequencyField = str_replace('_enabled','_frequency',
                explode('/', $relatedConfigPath['path'])[2]);
            $relatedConfigValue = $this->getFieldsetDataValue($frequencyField);

            $cronExpr = $this->calculateCronExpression($relatedConfigValue, $relatedConfigPath['unit']);

            try {
                $this->saveConfig($cronConfigPath, $cronExpr);
            } catch (Exception $e) {
                throw new LocalizedException(__('We can\'t save the cron expression.'));
            }
        }
    }

    /**
     * @param string $cronJobCode
     * @return string
     */
    private function getAssociatedCronConfigPath(string $cronJobCode)
    {
        $cronGroup = $this->getCronGroupByJobCode($cronJobCode);

        return $this->getMaasCronConfigPath($cronGroup, $cronJobCode);
    }

    /**
     * @param string $cronJobCode
     * @return int|string
     */
    private function getCronGroupByJobCode(string $cronJobCode)
    {
        foreach (self::MAAS_CRONS as $group => $jobsCodes) {
            foreach ($jobsCodes as $jobCode) {
                if ($jobCode === $cronJobCode) {
                    return $group;
                }
            }
        }
        return '';
    }

    /**
     * @throws LocalizedException
     */
    private function deactivateAllMaasCronJobs()
    {
        $maasCronJobsCodes = [];

        try {
            foreach (self::MAAS_CRONS as $cronGroup => $cronJobsCodes) {
                foreach ($cronJobsCodes as $cronJobCode) {
                    /*
                    * Setting the cron to an impossible date, as advised here:
                    * https://devdocs.magento.com/guides/v2.4/config-guide/cron/custom-cron-ref.html
                    */
                    $cronConfigPath = $this->getMaasCronConfigPath($cronGroup, $cronJobCode);
                    $this->saveConfig($cronConfigPath,self::IMPOSSIBLE_CRON_DATE);

                    array_push($maasCronJobsCodes, $cronJobCode);
                }
            }
        } catch (Exception $e) {
            throw new LocalizedException(__('We can\'t save the cron expression.'));
        }

        if (count($maasCronJobsCodes)) {
            try {
                $this->cronScheduleDelete->execute($maasCronJobsCodes);
            }
            catch (Exception $e) {
                throw new LocalizedException(__('We can\'t delete scheduled deactivated jobs.'));
            }
        }
    }

    /**
     * @throws LocalizedException
     */
    private function activateAllMaasCronJobs()
    {
        try {
            foreach (self::MAAS_CRONS as $cronGroup => $cronJobsCodes) {
                foreach ($cronJobsCodes as $cronJobCode) {
                    $cronConfigPath = $this->getMaasCronConfigPath($cronGroup, $cronJobCode);
                    $relatedConfigPath = $this->getCronBORelatedConfigPath($cronJobCode);

                    if (!empty($relatedConfigPath)) {
                        $relatedConfigValues = $this->getCronBORelatedConfigValues($relatedConfigPath);

                        if (!empty($relatedConfigValues)) {

                            if (!$relatedConfigValues['status']) {
                                $this->saveConfig($cronConfigPath, self::IMPOSSIBLE_CRON_DATE);
                            } else {
                                if (!empty($relatedConfigValues['frequency'])) {

                                    $cronExpr = $this->calculateCronExpression($relatedConfigValues['frequency'],
                                        $relatedConfigValues['unit']);
                                    $this->saveConfig($cronConfigPath, $cronExpr);
                                }
                                else {
                                    $this->deleteConfig($cronConfigPath);
                                }
                            }
                        }
                        else {
                            $this->deleteConfig($cronConfigPath);
                        }
                    }
                    else {
                        $this->deleteConfig($cronConfigPath);
                    }
                }
            }
        } catch (Exception $e) {
            throw new LocalizedException(__('We can\'t restore the cron config.'));
        }
    }

    /**
     * @param string $maasCronGroup
     * @param string $maasCronJobcode
     * @return string
     */
    private function getMaasCronConfigPath(string $maasCronGroup, string $maasCronJobcode)
    {
        return sprintf(self::CRON_PATH_PATTERN, $maasCronGroup, $maasCronJobcode);
    }

    /**
     * @param string $path
     * @param string $value
     */
    private function saveConfig(string $path, string $value)
    {
        $this->configWriter->save($path, $value);
    }

    /**
     * @param string $path
     */
    private function deleteConfig(string $path)
    {
        $this->configWriter->delete($path);
    }

    /**
     * @param string $cronJobCode
     * @return string|string[]
     */
    private function getCronBORelatedConfigPath(string $cronJobCode)
    {
        foreach (self::MAAS_CRON_BO_RELATED_CONFIG as $configPath)
        {
            if (!empty($configPath['path'])
                && strpos($configPath['path'], str_replace('maas_','', $cronJobCode)) !== false) {

                return $configPath;
            }
        }
        return '';
    }

    /**
     * @param array $configPath
     * @return array
     */
    private function getCronBORelatedConfigValues(array $configPath)
    {
        $status = $this->scopeConfig->getValue($configPath['path']);
        $frequency = $this->scopeConfig->getValue(str_replace('_enabled', '_frequency', $configPath['path']));

        return ['status' => $status, 'frequency' => $frequency, 'unit' => $configPath['unit']];
    }

    /**
     * @param string $value
     * @param string $unit
     * @return string
     */
    private function calculateCronExpression(string $value, string $unit)
    {
        if ($unit === self::FREQUENCY_UNIT_TYPES['MIN']) {
            if ($value == '60') {
                $valMinutes = '0';
                $valHours = '*/1';
            } else {
                $valMinutes = '*/' . $value;
                $valHours = '*';
            }
        } else {
            $valMinutes = '0';
            $valHours = '*/' . $value;
        }

        $cronExprArray = [
            $valMinutes, //Minute
            $valHours, //Hour
            '*',
            '*',
            '*'
        ];

        return join(' ', $cronExprArray);
    }


    private function configCacheClean()
    {
        $this->cacheManager->clean(['config']);
    }
}
