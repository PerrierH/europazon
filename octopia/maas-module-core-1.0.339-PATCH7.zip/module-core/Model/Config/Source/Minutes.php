<?php

namespace Maas\Core\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Minutes
 *
 * @package Maas\Core\Model\Config\Source
 *
 * @codeCoverageIgnore
 */
class Minutes implements ArrayInterface
{

    /** @var array */
    protected $options;

    /**
     * Minutes constructor.
     */
    public function __construct()
    {
        $this->options = null;
    }

    /**
     * @inheritDoc
     */
    public function toOptionArray()
    {
        if ($this->options === null) {
            for ($i = 1; $i <= 60; $i++) {
                $this->options[] = [
                    'value' => $i,
                    'label' => $i
                ];
            }
        }

        return $this->options;
    }
}
