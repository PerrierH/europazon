<?php

namespace Maas\Core\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Hours
 *
 * @package Maas\Core\Model\Config\Source
 *
 * @codeCoverageIgnore
 */
class Hours implements ArrayInterface
{

    /** @var array */
    protected $options;

    /**
     * Minutes constructor.
     */
    public function __construct()
    {
        $this->options = null;
    }

    /**
     * @inheritDoc
     */
    public function toOptionArray()
    {
        if ($this->options === null) {
            for ($i = 1; $i <= 12; $i++) {
                $this->options[] = [
                    'value' => $i,
                    'label' => $i
                ];
            }
        }

        return $this->options;
    }
}
