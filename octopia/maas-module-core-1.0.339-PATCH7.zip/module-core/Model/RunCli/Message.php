<?php
namespace Maas\Core\Model\RunCli;

use Maas\Core\Api\RunCli\MessageInterface;

/**
 * Class Message
 * @codeCoverageIgnore
 * @package Maas\Core\Model\RunCli
 * @codeCoverageIgnore
 */
class Message implements MessageInterface
{

    /** @var string */
    private $message;

    /**
     * @param string $message
     */
    public function setMessage(string $message)
    {
        $this->message = $message;
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }
}
