<?php

namespace Maas\Core\Model\RunCli;

use Maas\Core\Api\RunCli\ConsumerInterface;
use Maas\Core\Api\RunCli\MessageInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Symfony\Component\Process\Process;

/**
 * Class Consumer
 * @codeCoverageIgnore
 * @package Maas\Core\Model\RunCli
 */
class Consumer implements ConsumerInterface
{
    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * Consumer constructor.
     * @param DirectoryList $directoryList
     */
    public function __construct(DirectoryList $directoryList)
    {
        $this->directoryList = $directoryList;
    }

    /**
     * @param MessageInterface $message
     *
     * @return mixed|void
     */
    public function process(MessageInterface $message)
    {
        $cmd = 'php bin/magento ' . $message->getMessage() . "\n";
        $rootPath = $this->directoryList->getRoot();
        $process = new Process($cmd, $rootPath);
        $process->setTimeout(null);
        $process->run();
    }
}
