<?php

namespace Maas\Core\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Payment\Api\PaymentMethodListInterface\Proxy as PaymentMethodListInterfaceProxy;

/**
 * Class Config
 *
 * @package Maas\Core\Model
 * We put an ignore because methods use scope config from magento
 * already tested by magento.
 * @codeCoverageIgnore
 */
class Config
{
    /* Module */
    public const MODULE_NAME = 'Maas_Core';
    public const PATH_PREFIX = 'maas';
    public const RELEASE_FILENAME = 'CHANGELOG.md';

    /* System Config -> General */
    public const MODULE_ENABLED = 'maas_general/general/enable';
    public const XML_PATH_PRESENTATION_VIDEO = 'maas_general/general/presentation_video';
    public const XML_DEVELOPER_MODE = 'maas_general/general/developer_mode';

    /*  System Config -> Advanced */
    public const XML_PATH_JOB_TIMEOUT = 'maas_general/advanced/job_timeout';

    /*  System Config -> Advanced Settings */
    public const XML_PATH_MAAS_CATEGORY = 'settings/maas_category';
    public const XML_PATH_MAAS_PAYMENT_METHODS_EXPORT_STATUS = 'maas_orders/general/synchro_status_by_payment_method';
    public const XML_PATH_MAAS_MATCHING_BETWEEN_OCTOPIA_AND_MAGENTO_PAYMENT_METHODS = 'maas_orders/general/matching_between_octopia_and_magento_payment_methods';

    /*  System Config -> Performance shooting */
    public const XML_PATH_MAAS_ENTITY_IMPORT_PERF = 'maas_logs/advanced/entity_import_perf';
    public const XML_PATH_MAAS_ATTRIBUTE_CREATION_PERF = 'maas_logs/advanced/attribute_creation_perf';
    public const XML_PATH_MAAS_VARIATION_GROUP_CREATION_PERF = 'maas_logs/advanced/variation_creation_group_perf';
    public const XML_PATH_MAAS_IMAGE_IMPORT_PERF = 'maas_logs/advanced/image_import_perf';
    public const XML_PATH_MAAS_CATALOG_RULE_PREPARE_DATA_PERF = 'maas_logs/advanced/catalog_rule_prepare_data';
    public const XML_PATH_MAAS_CATALOG_RULE_ASSIGN_PRODUCT_TO_CATEGORY_PERF = 'maas_logs/advanced/assign_product_to_categories';
    public const XML_PATH_MAAS_INVENTORY_IMPORT_PERF = 'maas_logs/advanced/inventory_import_perf';
    public const XML_PATH_MAAS_DELIVERY_IMPORT_PERF = 'maas_logs/advanced/delivery_import_perf';
    public const XML_PATH_MAAS_TAX_IMPORT_PERF = 'maas_logs/advanced/tax_import_perf';
    public const XML_PATH_MAAS_PRICE_IMPORT_PERF = 'maas_logs/advanced/price_import_perf';
    public const XML_PATH_MAAS_OFFER_DELETE_IMPORT_PERF = 'maas_logs/advanced/offer_delete_import_perf';
    public const XML_PATH_MAAS_SELLER_IMPORT_PERF = 'maas_logs/advanced/seller_import_perf';
    public const XML_PATH_MAAS_IMAGE_OFFER_IMPORT_PERF = 'maas_logs/advanced/offer_image_import_perf';
    public const XML_PATH_MAAS_OFFER_IMPORT_PERF = 'maas_logs/advanced/offer_import_perf';
    public const XML_PATH_MAAS_UPDATE_OFFER_IMPORT_PERF = 'maas_logs/advanced/update_offer_import_perf';

    /* System Config -> Message queue connection mode */
    public const XML_PATH_MESSAGE_QUEUE_CONNECTION_TYPE = 'maas_general/general/mq_mode';
    
    /* System Config -> Variant Product Import */
    public const INCLUDE_VARIANT_PRODUCT_IMPORT = 'maas_products/general/catalog_variant_product_import';

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /** @var SerializerInterface */
    private $serializer;

    /** @var PaymentMethodListInterfaceProxy */
    private $paymentMethodList;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param SerializerInterface $serializer
     * @param PaymentMethodListInterfaceProxy $paymentMethodList
     */
    public function __construct(
        ScopeConfigInterface            $scopeConfig,
        SerializerInterface             $serializer,
        PaymentMethodListInterfaceProxy $paymentMethodList
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->serializer = $serializer;
        $this->paymentMethodList = $paymentMethodList;
    }

    /**
     * An alias for scope config with default scope type SCOPE_STORE
     *
     * @param string $key
     * @param string|null $scopeCode
     * @param string $scopeType
     *
     * @return string|null
     */
    public function getValue($key, $scopeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        return $this->scopeConfig->getValue($key, $scopeType, $scopeCode);
    }

    /**
     * @param string $path
     * @param string|null $scopeCode
     * @param string $scopeType
     *
     * @return bool
     */
    public function isSetFlag($path, $scopeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        return $this->scopeConfig->isSetFlag($path, $scopeType, $scopeCode);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isModuleEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::MODULE_ENABLED, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isDeveloperMode($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_DEVELOPER_MODE, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param string|null $scopeCode
     *
     * @return array
     */
    public function getPaymentMethodsExportStatus($scopeCode = null)
    {
        // default values
        $methods = [];
        foreach ($this->paymentMethodList->getList(0) as $paymentMethod) {
            $methods[$paymentMethod->getCode()] = ['processing'];
        }
        $value = $this->getValue(
            self::XML_PATH_MAAS_PAYMENT_METHODS_EXPORT_STATUS,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
        if ($value !== null) {
            $datas = $this->serializer->unserialize($value);
            foreach ($datas as $data) {
                $methods[$data['payment_code']] = isset($data['status']) ? explode(',', $data['status']) : [];
            }
        }
        return $methods;
    }

    /**
     * @param string|null $scopeCode
     *
     * @return array
     */
    public function getOctopiaPaymentCodeByMagentoPaymentCode($scopeCode = null)
    {
        // default values
        $methods = [];
        foreach ($this->paymentMethodList->getList(0) as $paymentMethod) {
            $methods[$paymentMethod->getCode()] = '';
        }
        $value = $this->getValue(
            self::XML_PATH_MAAS_MATCHING_BETWEEN_OCTOPIA_AND_MAGENTO_PAYMENT_METHODS,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
        if ($value !== null) {
            $datas = $this->serializer->unserialize($value);
            foreach ($datas as $data) {
                $methods[$data['payment_code']] = $data['octopia_payment_code'];
            }
        }
        return $methods;
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isEntityImportPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_ENTITY_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isAttributeCreationPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_ATTRIBUTE_CREATION_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isVariationGroupCreationPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_VARIATION_GROUP_CREATION_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isImagesImportPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_IMAGE_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isCatalogRulePrepareDataPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_CATALOG_RULE_PREPARE_DATA_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isCatalogRuleAssignProductsToCategoriesPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_CATALOG_RULE_ASSIGN_PRODUCT_TO_CATEGORY_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isInventoryPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_INVENTORY_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isTaxPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_TAX_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isDeliveryPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_DELIVERY_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null $scopeCode
     *
     * @return bool
     */
    public function isPricePerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_PRICE_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null $scopeCode
     *
     * @return bool
     */
    public function isDeleteOfferPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_OFFER_DELETE_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);

    }

    /**
     * @param null $scopeCode
     *
     * @return bool
     */
    public function isSellerPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_SELLER_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null $scopeCode
     *
     * @return bool
     */
    public function isImagesOfferImportPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_IMAGE_OFFER_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null $scopeCode
     *
     * @return bool
     */
    public function isOfferPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_OFFER_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null $scopeCode
     *
     * @return bool
     */
    public function isUpdateOfferPerfEnabled($scopeCode = null)
    {
        return $this->isSetFlag(self::XML_PATH_MAAS_UPDATE_OFFER_IMPORT_PERF, $scopeCode, ScopeInterface::SCOPE_STORE);
    }

    /**
     * An altered getValue() for exceptional cases where a configuration cannot start with self::PATH_PREFIX
     *
     * @param string $key
     * @param string|null $scopeCode
     * @param string $scopeType
     *
     * @return string|null
     */
    public function getValueWithoutPrefix($key, $scopeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        return $this->scopeConfig->getValue($key, $scopeType, $scopeCode);
    }

    /**
     * Function to retrieve the connexion method to use in a message queue
     *
     * @param null $scopeCode
     *
     * @return string
     */
    public function getMessageQueueConnectionMethod($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_MESSAGE_QUEUE_CONNECTION_TYPE, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the job timeout
     *
     * @param null $scopeCode
     *
     * @return string
     */
    public function getJobTimeout($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_JOB_TIMEOUT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * @param null $scopeCode
     * @return string|null
     */
    public function isVariantProductsImportIncluded($scopeCode = null)
    {
        return $this->getValue(self::INCLUDE_VARIANT_PRODUCT_IMPORT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }
}
