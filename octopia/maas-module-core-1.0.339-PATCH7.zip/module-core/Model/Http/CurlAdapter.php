<?php

namespace Maas\Core\Model\Http;

use Magento\Framework\HTTP\Adapter\Curl;
use Zend_Http_Client;
use Zend_Uri_Http;

/**
 * Class CurlAdapter
 *
 * @package Maas\Core\Model\Http
 */
class CurlAdapter extends Curl
{
    /**
     * @param string $method
     * @param string|Zend_Uri_Http $url
     * @param string $http_ver
     * @param array $headers
     * @param string $body
     *
     * @return string
     */
    public function write($method, $url, $http_ver = '1.1', $headers = [], $body = '')
    {
        $resource = $this->_getResource();
        if ($method === Zend_Http_Client::HEAD) {
            curl_setopt($resource, CURLOPT_NOBODY, true);
        } else {
            curl_setopt($resource, CURLOPT_NOBODY, false);
        }
        return parent::write($method, $url, $http_ver, $headers, $body);
    }
}