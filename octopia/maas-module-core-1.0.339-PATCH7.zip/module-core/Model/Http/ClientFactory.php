<?php

namespace Maas\Core\Model\Http;

use Maas\Core\Model\Http\CurlAdapterFactory;
use Magento\CatalogImportExport\Model\Import\Product;
use Magento\Framework\HTTP\ZendClientFactory;
use Magento\Framework\ObjectManagerInterface;

/**
 * Class ClientFactory
 *
 * @package Maas\Core\Model\Http
 */
class ClientFactory extends ZendClientFactory
{
    /**
     * Factory constructor
     *
     * @param ObjectManagerInterface $objectManager
     * @param string $instanceName
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        $instanceName = Client::class
    ) {
        parent::__construct($objectManager, $instanceName);
    }

    /**
     * Create class instance with specified parameters
     *
     * @param array $data
     *
     * @return Product
     */
    public function create(array $data = [])
    {
        return $this->_objectManager->create($this->_instanceName, $data);
    }
}