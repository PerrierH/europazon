<?php

namespace Maas\Core\Model\Http;

use Maas\Core\Model\Http\CurlAdapterFactory;
use Magento\Framework\HTTP\Adapter\Curl;
use Magento\Framework\HTTP\ZendClient;

/**
 * Class Client
 *
 * @package Maas\Core\Model\Http
 */
class Client extends ZendClient
{
    /**
     * @var CurlAdapterFactory
     */
    protected $curlAdapterFactory;

    /**
     * @param CurlAdapterFactory $curlAdapterFactory
     * @param null $uri
     * @param null $config
     */
    public function __construct(
        CurlAdapterFactory $curlAdapterFactory,
        $uri = null,
        $config = null
    ) {
        $this->curlAdapterFactory = $curlAdapterFactory;
        parent::__construct($uri, $config);
    }

    /**
     * Load the connection adapter
     *
     * While this method is not called more than one for a client, it is
     * seperated from ->request() to preserve logic and readability
     *
     * @param Zend_Http_Client_Adapter_Interface|string $adapter
     *
     * @return null
     * @throws Zend_Http_Client_Exception
     */
    public function setAdapter($adapter)
    {
        if ($adapter instanceof Curl && (!$adapter instanceof CurlAdapter)) {
            return parent::setAdapter($this->curlAdapterFactory->create());
        }
        return parent::setAdapter($adapter);
    }
}