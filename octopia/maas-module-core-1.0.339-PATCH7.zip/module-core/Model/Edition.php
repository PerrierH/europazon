<?php

namespace Maas\Core\Model;

use Maas\Core\Api\Data\EditionInterface;

/**
 * Class Edition
 */
class Edition implements EditionInterface
{
    const FIELD_NAME = 'entity_id';
    const EDITION_NAME = 'Community';

    /**
     * Get Magento edition
     *
     * @return string
     */
    public function getEdition()
    {
        return self::EDITION_NAME;
    }

    /**
     * @return string
     */
    public function getLinkField(): string
    {
        return self::FIELD_NAME;
    }

    /**
     * @return bool
     */
    public function isEnterprise(): bool
    {
        return false;
    }
}
