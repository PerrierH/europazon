<?php

namespace Maas\Core\Model\Service;

use Magento\Framework\App\ObjectManager;

/**
 *
 */
class Instantiate
{
    public function __construct()
    {
        $this->objectManager = ObjectManager::getInstance();
    }

    /**
     * @param mixed $object
     *
     * @return object
     */
    public function getInstanceIfArray($object)
    {
        if(is_array($object) && array_key_exists('instance', $object))
        {
            return $this->objectManager->get($object['instance']);
        }
        return $object;
    }
}