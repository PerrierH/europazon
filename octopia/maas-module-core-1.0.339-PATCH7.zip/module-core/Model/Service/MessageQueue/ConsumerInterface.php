<?php

namespace Maas\Core\Model\Service\MessageQueue;

/**
 * Interface ConsumerInterface
 *
 * Implement this for all MQ Consumers
 *
 * @package Maas\ImportExport\Model\Service\MessageQueue
 */
interface ConsumerInterface
{
    /**
     * @param string $message
     *
     * @return void
     */
    public function process($message);
}
