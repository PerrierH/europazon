<?php

namespace Maas\Core\Model\Service\MessageQueue;

use Magento\Framework\Communication\Config as CommunicationConfig;
use Magento\Framework\MessageQueue\Topology\Config as TopologyConfig;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\ObjectManagerInterface;
use Rcason\Mq\Model\Config\Config as RcMqConfig;

/**
 * Class ConfigOptions
 *
 * @package Maas\ImportExport\Model\Service\MessageQueue
 */
class Config extends AbstractModuleDependant
{
    /** @var string Module used in 2.2 */
    const RCASONMQ_MODULE = 'Rcason_Mq';

    /** @var string Publisher class used in 2.2 */
    const RCASONMQ_CONFIG = '\\Rcason\\Mq\\Model\\Config\\Config';

    /** @var string Standard module used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_MODULE1 = 'Magento_Amqp';

    /** @var string Standard nodule used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_MODULE2 = 'Magento_MysqlMq';

    /** @var string Standard config class used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_CONFIG1 = '\\Magento\\Framework\\Communication\\Config';

    /** @var string Standard config class used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_CONFIG2 = '\\Magento\\Framework\\MessageQueue\\Topology\\Config';

    /** @var string[] */
    protected $queues;

    /** @var string[] */
    protected $requestedQueues;

    /** @var string[]|array */
    protected $brokers;

    /** @var ObjectManagerInterface */
    protected $objectManager;

    /**
     * ConfigOptions constructor.
     *
     * @param ObjectManagerInterface $objectManager
     * @param ModuleListProxy $moduleList
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        ModuleListProxy $moduleList
    ) {
        parent::__construct($moduleList);
        $this->brokers = null;
        $this->objectManager = $objectManager;
    }

    /**
     * @param string $requestedQueueName
     *
     * @return bool
     */
    public function validateRequestedQueueName($requestedQueueName)
    {
        $this->initialize();
        return in_array($requestedQueueName, $this->requestedQueues);
    }

    protected function initialize()
    {
        if (!$this->initialized) {
            parent::initialize();
            if ($this->isModuleActive(self::RCASONMQ_MODULE)) {
                /** @var RcMqConfig $config */
                $config = $this->objectManager->create(self::RCASONMQ_CONFIG);
                $this->queues = $config->getQueueNames();
                $this->requestedQueues = $config->getQueueNames();
            } elseif ($this->areModulesActive([self::MAGENTO_MODULE1, self::MAGENTO_MODULE2])) {
                /** @var CommunicationConfig $config */
                $config = $this->objectManager->create(self::MAGENTO_CONFIG1);
                $topics = $config->getTopics();
                $this->requestedQueues = [];
                foreach ($topics as $topic) {
                    $this->requestedQueues[] = $topic['name'];
                }

                /** @var TopologyConfig $config */
                $config = $this->objectManager->create(self::MAGENTO_CONFIG2);
                $this->queues = [];
                foreach ($config->getQueues() as $queue) {
                    $this->queues[] = $queue->getName();
                }
            }

            if (is_null($this->queues)) {
                $this->throwNoModulesException();
            }

            $this->initialized = true;
        }
    }

    /**
     * @return string[]
     */
    public function getBrokerCodes()
    {
        $this->initialize();
        if (is_null($this->brokers)) {
            $this->brokers = [];
            foreach ($this->queues as $queue) {
                $broker = $this->extractBrokerFromQueue($queue);
                if($broker)
                {
                    $this->brokers[$broker] = true;
                }
            }
            $this->brokers = array_keys($this->brokers);
        }
        return $this->brokers;
    }

    /**
     * Extracts broker code from queue name.
     * This could have been done with regex, but code analysis tools detected the used expression as a security risk
     *
     * @param string $queueName
     *
     * @return bool|string
     */
    protected function extractBrokerFromQueue($queueName)
    {
        $quoteNameParts = array_slice(explode('.', $queueName), -2, 2);
        if(count($quoteNameParts) == 2 && $quoteNameParts[1] == 'queue')
        {
            return $quoteNameParts[0];
        }
        return false;
    }
}
