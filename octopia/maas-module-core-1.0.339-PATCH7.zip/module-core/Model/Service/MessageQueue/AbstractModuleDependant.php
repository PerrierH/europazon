<?php

namespace Maas\Core\Model\Service\MessageQueue;

use Maas\Core\Model\Service\AbstractModuleDependant as ParentAbstractModuleDependant;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class AbstractModuleDependant
 *
 * @package Maas\ImportExport\Model\Service\MessageQueue
 */
abstract class AbstractModuleDependant extends ParentAbstractModuleDependant
{
    /**
     * @throws LocalizedException
     */
    protected function throwNoModulesException()
    {
        throw new LocalizedException(__('No supported Message Queue modules detected.'));
    }
}
