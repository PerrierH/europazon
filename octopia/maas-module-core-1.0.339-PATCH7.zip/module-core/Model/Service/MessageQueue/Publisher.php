<?php

namespace Maas\Core\Model\Service\MessageQueue;

use Maas\ImportExport\Model\Config;
use Maas\Core\Model\Service\MessageQueue\Config as MqConfig;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\ObjectManagerInterface;

/**
 * Class Publisher
 *
 * Uses the ObjectManager to instantiate the appropriate publishers
 *
 * @package Maas\ImportExport\Model\Service\MessageQueue
 */
class Publisher extends AbstractModuleDependant
{
    /** @var string Module used in 2.2 */
    const RCASONMQ_MODULE = 'Rcason_Mq';

    /** @var string Publisher class used in 2.2 */
    const RCASONMQ_PUBLISHER = '\\Rcason\\Mq\\Model\\Publisher';

    /** @var string Standard module used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_MODULE1 = 'Magento_Amqp';

    /** @var string Standard nodule used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_MODULE2 = 'Magento_MysqlMq';

    /** @var string Standard publisher class used from 2.3 onwards, or in Commerce Edition */
    const MAGENTO_PUBLISHER = '\\Magento\\Framework\\MessageQueue\\PublisherInterface';

    /** @var mixed */
    protected $delegatedPublisher;

    /** @var string */
    protected $delegatedPublisherClass;

    /** @var string */
    protected $connectionMethod;

    /** @var MqConfig */
    protected $mqConfig;

    /** @var Config */
    protected $config;

    /** @var ObjectManagerInterface */
    protected $objectManager;

    /**
     * Publisher constructor.
     *
     * @param ObjectManagerInterface $objectManager
     * @param ModuleListProxy $moduleList
     * @param Config $config
     * @param MqConfig $mqConfig
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        ModuleListProxy $moduleList,
        Config $config,
        MqConfig $mqConfig
    ) {
        parent::__construct($moduleList);
        $this->objectManager = $objectManager;
        $this->mqConfig = $mqConfig;
        $this->config = $config;
    }

    /**
     * @param string $queue
     * @param mixed $messageData
     * @param null|string $forceMqMode
     *
     * @throws LocalizedException
     */
    public function publish($queue, $messageData, $forceMqMode = null)
    {
        $this->initialize();
        $configurationEndpointType = 'topic';
        if ($this->delegatedPublisherClass == self::RCASONMQ_PUBLISHER) {
            $configurationEndpointType = 'queue';
        }

        if ($this->delegatedPublisher) {
            $requestedQueueName = $queue . '.' . ($forceMqMode ?? $this->connectionMethod) . '.' . $configurationEndpointType;
            if ($this->mqConfig->validateRequestedQueueName($requestedQueueName)) {
                $this->delegatedPublisher->publish(
                    $requestedQueueName,
                    $messageData
                );
            } else {
                throw new LocalizedException(__("Invalid requested queue: %1", $requestedQueueName));
            }
        }
    }

    protected function initialize()
    {
        if (!$this->initialized) {
            parent::initialize();

            $this->delegatedPublisher = null;
            $this->connectionMethod = $this->config->getMessageQueueConnectionMethod();

            if ($this->isModuleActive(self::RCASONMQ_MODULE)) {
                $this->delegatedPublisher = $this->objectManager->create(self::RCASONMQ_PUBLISHER);
                $this->delegatedPublisherClass = self::RCASONMQ_PUBLISHER;
            } else {
                if ($this->areModulesActive([self::MAGENTO_MODULE1, self::MAGENTO_MODULE2])) {
                    $this->delegatedPublisher = $this->objectManager->create(self::MAGENTO_PUBLISHER);
                    $this->delegatedPublisherClass = self::MAGENTO_PUBLISHER;
                }
            }
            if (is_null($this->delegatedPublisher)) {
                $this->throwNoModulesException();
            }
        }
    }
}
