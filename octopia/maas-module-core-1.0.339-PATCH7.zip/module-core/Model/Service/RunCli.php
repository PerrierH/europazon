<?php

namespace Maas\Core\Model\Service;

use Maas\Core\Api\RunCli\MessageInterface;
use Maas\Core\Model\Service\MessageQueue\Publisher;

/**
 * Class RunCli
 *
 * @package Maas\Core\Model\Service
 */
class RunCli
{
    const QUEUE_NAME = 'maas_core.run_cli';

    /** @var Publisher */
    private $publisher;
    /** @var MessageInterface */
    private $message;

    /**
     * RunCli constructor.
     *
     * @param Publisher $publisher
     * @param MessageInterface $message
     */
    public function __construct(
        Publisher $publisher,
        MessageInterface $message
    ) {
        $this->publisher = $publisher;
        $this->message = $message;
    }

    /**
     * @param string $job
     * @param array $params
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function addToQueue(string $job, array $params = [])
    {
        $messageString = $job;
        foreach ($params as $key => $value) {
            if (!is_numeric($key)) {
                $messageString .= ' -' . $key;
            }
            $messageString .= ' ' . $value;
        }
        $this->message->setMessage($messageString);
        $this->publisher->publish(self::QUEUE_NAME, $this->message);
    }
}
