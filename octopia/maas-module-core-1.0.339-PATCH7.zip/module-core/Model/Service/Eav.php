<?php


namespace Maas\Core\Model\Service;

use Magento\Eav\Model\ResourceModel\Entity\Type;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Exception\LocalizedException;
use Zend_Validate_Exception;

/**
 * Class Eav
 *
 * @package Maas\Core\Model\Service
 * @codeCoverageIgnore Impacts the database
 */
class Eav
{
    /**
     * @var array
     */
    protected $defaultSetIds = [];

    /**
     * @var Type
     */
    protected $typeResource;

    /**
     * @var EavSetup
     */
    protected $eavSetup;

    /**
     * Eav constructor.
     *
     * @param EavSetup $eavSetup
     * @param Type $typeResource
     */
    public function __construct(
        EavSetup $eavSetup,
        Type $typeResource
    ) {
        $this->eavSetup = $eavSetup;
        $this->typeResource = $typeResource;
    }

    /**
     * @param string|int $entityTypeId
     * @param array $data
     *
     * @return $this
     * @throws LocalizedException
     * @throws Zend_Validate_Exception
     */
    public function addAttributesToDefaultSetAndGroup($entityTypeId, $data)
    {
        $defaultProperties = [
            'required' => false,
            'user_defined' => true
        ];
        $attributeSetId = $this->getDefaultAttributeSetId($entityTypeId);

        foreach ($data as $attributeData) {
            list($code, $label, $type, $properties) = $attributeData;

            $properties = array_merge($defaultProperties, $properties, [
                'type' => $type,
                'label' => $label,
                'attribute_set_id' => $attributeSetId,
                'group' => 'General'
            ]);
            $this->eavSetup->addAttribute($entityTypeId, $code, $properties);
        }
        return $this;
    }

    /**
     * @param string|int $entityTypeId
     *
     * @return int|null
     */
    private function getDefaultAttributeSetId($entityTypeId)
    {
        if (!isset($this->defaultSetIds[$entityTypeId])) {
            $defaultId = $this->eavSetup->getDefaultAttributeSetId($entityTypeId);
            if ($defaultId) {
                $this->defaultSetIds[$entityTypeId] = $defaultId;
            } else {
                $ids = $this->eavSetup->getAllAttributeSetIds();
                if ($ids) {
                    $this->defaultSetIds[$entityTypeId] = reset($ids);
                } else {
                    $this->defaultSetIds[$entityTypeId] = null;
                }
            }
        }
        return $this->defaultSetIds[$entityTypeId];
    }

    /**
     * @param string|int $entityTypeId
     * @param array $entityTypeData
     *
     * @return $this
     */
    public function updateEavEntitySetupCache($entityTypeId, $entityTypeData)
    {
        foreach ($entityTypeData as $key => $value) {
            $this->eavSetup->updateEntityType($entityTypeId, $key, $value);
        }
        return $this;
    }
}