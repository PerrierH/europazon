<?php

namespace Maas\Core\Model\Service\Cpu;

use Magento\Framework\Shell\Driver;

/**
 * Class Linux1
 *
 * @package Maas\Core\Model\Service\Cpu
 * @codeCoverageIgnore
 */
class Linux1 extends AbstractCpu
{
    /**
     * @var int
     */
    protected $cpuCount = null;

    /**
     * @var Driver
     */
    protected $driver;

    /**
     * Linux1 constructor.
     *
     * @param Driver $driver
     */
    public function __construct(Driver $driver)
    {
        $this->driver = $driver;
    }

    /**
     * @inheritDoc
     */
    public function isUsable()
    {
        if (PHP_OS_FAMILY == 'Linux' && is_file('/proc/cpuinfo') && is_readable('/proc/cpuinfo')) {
            $result = $this->driver->execute('which ps', []);
            if ($result && $result->getExitCode() == 0) {
                return strlen(trim($result->getOutput())) > 0;
            }
        }
        return false;
    }

    /**
     * @inheritDoc
     */
    protected function getOverallCpuLoad()
    {
        $percents = 0.0;
        $result = $this->driver->execute('ps -eo pcpu', []);
        if ($result && $result->getExitCode() == 0) {
            $output = explode(PHP_EOL, $result->getOutput());
            foreach ($output as $line) {
                $line = trim($line);
                if (is_numeric($line)) {
                    $percents += floatval($line);
                }
            }
        }
        return $percents;
    }

    /**
     * @inheritDoc
     */
    protected function getCpuCount()
    {
        if (is_null($this->cpuCount)) {
            $this->cpuCount = 0;
            $cpuinfoLines = file('/proc/cpuinfo');
            foreach ($cpuinfoLines as $line) {
                list($key) = explode(':', $line);
                if (trim($key) == 'processor') {
                    $this->cpuCount++;
                }
            }
            if ($this->cpuCount == 0) {
                // in case something goes wrong, avoid a division by 0
                $this->cpuCount = 1;
            }
        }
        return $this->cpuCount;
    }
}