<?php

namespace Maas\Core\Model\Service\Cpu;

/**
 * Class AbstractCpu
 *
 * @package Maas\Core\Model\Service\Cpu
 * @codeCoverageIgnore
 */
abstract class AbstractCpu
{
    /**
     * @return bool
     */
    abstract public function isUsable();

    /**
     * @return float
     */
    abstract protected function getOverallCpuLoad();

    /**
     * @return int
     */
    abstract protected function getCpuCount();

    /**
     * @return float
     */
    public function getCpuLoad()
    {
        return $this->getOverallCpuLoad()/$this->getCpuCount();
    }
}