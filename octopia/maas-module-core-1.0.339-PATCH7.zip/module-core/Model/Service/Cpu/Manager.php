<?php

namespace Maas\Core\Model\Service\Cpu;

use Magento\Framework\App\CacheInterface;

/**
 * Class Manager
 *
 * @package Maas\Core\Model\Service\Cpu
 * @codeCoverageIgnore
 */
class Manager
{
    const CPU_INSTANCE_CACHE_KEY = 'octopia_cpu_instance';

    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var object[]
     */
    protected $cpuVariantFactories;

    /**
     * @var AbstractCpu|null
     */
    protected $cpuVariantInstance = null;

    /**
     * Manager constructor.
     *
     * @param CacheInterface $cache
     * @param AbstractCpu[] $cpuVariants
     */
    public function __construct(
        CacheInterface $cache,
        DummyFactory $dummyFactory,
        $cpuVariantFactories = []
    ) {
        $this->cache = $cache;
        $this->dummyFactory = $dummyFactory;
        $this->cpuVariantFactories = $cpuVariantFactories;
        $this->cpuVariantInstance = null;
    }

    public function getCpuLoad()
    {
        return $this->getCpuInstance()->getCpuLoad();
    }

    protected function getCpuInstance()
    {
        if ($this->cpuVariantInstance) {
            return $this->cpuVariantInstance;
        }

        $cachedKey = $this->cache->load(self::CPU_INSTANCE_CACHE_KEY);
        if ($cachedKey && isset($this->cpuVariantFactories[$cachedKey])) {
            $this->cpuVariantInstance = $this->cpuVariantFactories[$cachedKey]->create();
        } else {
            foreach ($this->cpuVariantFactories as $variantKey => $variantFactory) {
                /** @var AbstractCpu $variant */
                $variant = $variantFactory->create();
                if ($variant->isUsable()) {
                    $this->cache->save($variantKey, self::CPU_INSTANCE_CACHE_KEY);
                    $this->cpuVariantInstance = $variant;
                    break;
                }
            }
        }
        if (is_null($this->cpuVariantInstance)) {
            $this->cpuVariantInstance = $this->dummyFactory->create();
        }
        return $this->cpuVariantInstance;
    }
}