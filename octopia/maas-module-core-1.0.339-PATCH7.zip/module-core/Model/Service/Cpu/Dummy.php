<?php

namespace Maas\Core\Model\Service\Cpu;

/**
 * Class Dummy
 *
 * @package Maas\Core\Model\Service\Cpu
 * @codeCoverageIgnore
 */
class Dummy extends AbstractCpu
{

    /**
     * @inheritDoc
     */
    public function isUsable()
    {
        return true;
    }

    /**
     * @inheritDoc
     */
    protected function getOverallCpuLoad()
    {
        return 0;
    }

    /**
     * @inheritDoc
     */
    protected function getCpuCount()
    {
        return 1;
    }
}