<?php

namespace Maas\Core\Model\Service\Cpu;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Shell\Driver;

/**
 * Class Linux1
 *
 * @package Maas\Core\Model\Service\Cpu
 * @codeCoverageIgnore
 */
class Windows1 extends AbstractCpu
{
    /**
     * @var Driver
     */
    protected $driver;
    /**
     * @var int
     */
    protected $coresCount = null;

    /**
     * Windows1 constructor.
     *
     * @param Driver $driver
     */
    public function __construct(
        Driver $driver
    ) {
        $this->driver = $driver;
    }

    /**
     * @inheritDoc
     */
    public function isUsable()
    {
        return (PHP_OS_FAMILY == 'Windows');
    }

    /**
     * @inheritDoc
     */
    protected function getOverallCpuLoad()
    {
        return $this->getAverageFromWmicCpuGetResult('LoadPercentage');
    }

    /**
     * @param string $param
     *
     * @return float|int
     */
    protected function getAverageFromWmicCpuGetResult($param)
    {
        $result = $this->execWmicCpuGet($param);
        return (count($result) > 0) ? (array_sum($result) / count($result)) : 0;
    }

    /**
     * @param string $param
     *
     * @return array
     * @throws LocalizedException
     */
    protected function execWmicCpuGet($param)
    {
        $result = $this->driver->execute('wmic cpu get ' . $param, []);
        if ($result && $result->getExitCode() == 0) {
            $lines = explode(PHP_EOL, $result->getOutput());
            $result = [];
            $functionNameFound = false;
            foreach ($lines as $line) {
                $line = trim($line);
                if (preg_match("/^$line$/", $param)) {
                    $functionNameFound = true;
                } elseif (is_numeric($line)) {
                    $result[] = floatval($line);
                }
            }
            return $functionNameFound ? $result : [];
        }
        return [];
    }

    /**
     * @inheritDoc
     */
    protected function getCpuCount()
    {
        // it is simpler to calculate the average elsewhere with getAverageFromWmicCpuGetResult()
        return 1;
    }

    /**
     * @param string $param
     *
     * @return bool
     */
    protected function isWmicCpuGetResultPresent($param)
    {
        return count($this->execWmicCpuGet($param)) > 0;
    }
}