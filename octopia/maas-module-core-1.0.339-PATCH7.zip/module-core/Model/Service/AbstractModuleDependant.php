<?php

namespace Maas\Core\Model\Service;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;

/**
 * Class AbstractModuleDependant
 *
 * @package Maas\ImportExport\Model\Service
 */
abstract class AbstractModuleDependant
{
    /** @var array */
    protected $modules;

    /** @var ModuleListProxy */
    protected $moduleList;

    /** @var bool */
    protected $initialized;

    /**
     * AbstractModuleDependant constructor.
     *
     * @param ModuleListProxy $moduleList
     */
    public function __construct(
        ModuleListProxy $moduleList
    ) {
        $this->initialized = false;
        $this->moduleList = $moduleList;
        $this->modules = null;
    }

    /**
     * @param string[] $moduleNames
     *
     * @return bool
     */
    protected function areModulesActive($moduleNames)
    {
        foreach ($moduleNames as $moduleName) {
            if (!$this->isModuleActive($moduleName)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param string $moduleName
     *
     * @return bool
     */
    protected function isModuleActive($moduleName)
    {
        $this->initialize();
        return isset($this->modules[$moduleName]);
    }

    protected function initialize()
    {
        if (!$this->initialized) {
            $this->modules = $this->moduleList->getAll();
            $this->initialized = true;
        }
    }
}
