<?php

namespace Maas\Core\Model\Service;

use Magento\Cron\Model\ResourceModel\Schedule\Collection;
use Magento\Cron\Model\ResourceModel\Schedule\CollectionFactory;
use Magento\Cron\Model\Schedule;

/**
 * Class CronScheduleDelete
 *
 * @codeCoverageIgnore
 * @package Maas\Core\Model\Service
 */
class CronScheduleDelete
{
    /**
     * @var CollectionFactory
     */
    protected $scheduleCollectionFactory;

    /**
     * @param CollectionFactory $scheduleCollectionFactory
     */
    public function __construct(
        CollectionFactory $scheduleCollectionFactory
    )
    {
        $this->scheduleCollectionFactory = $scheduleCollectionFactory;
    }

    /**
     * @param array $jobsCodes
     * @return $this
     */
    public function execute(array $jobsCodes)
    {
        $this->scheduleCollectionFactory->create()
            ->addFieldToFilter('job_code', ['in' => $jobsCodes])
            ->addFieldToFilter('status', Schedule::STATUS_PENDING)
            ->walk('delete');
        return $this;
    }
}