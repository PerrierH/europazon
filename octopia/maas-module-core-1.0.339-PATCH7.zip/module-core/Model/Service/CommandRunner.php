<?php


namespace Maas\Core\Model\Service;

use Magento\Framework\App\Filesystem\DirectoryList;
use Symfony\Component\Process\Process;
use Magento\Cron\Model\Schedule;


/**
 * Class CommandRunner
 *
 * @codeCoverageIgnore
 * @package Maas\Core\Model\Service
 */
abstract class CommandRunner
{
    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * Product constructor.
     *
     * @param DirectoryList $directoryList
     */
    public function __construct(
        DirectoryList $directoryList
    ) {
        $this->directoryList = $directoryList;
    }

    /**
     * @param $commandName
     * @param $schedule
     */
    public function executeCommand($commandName, Schedule $schedule)
    {
        $rootPath = $this->directoryList->getRoot();
        $proc = new Process(
            "php bin/magento {$commandName} -s {$schedule->getId()}",
            $rootPath,
            null,
            null,
            null
        );
        $proc->run();
    }


    /**
     * @param Schedule $schedule
     */
    public function execute(Schedule $schedule)
    {
        $this->executeCommand($this->getCommandName(), $schedule);
    }

    /**
     * @return mixed
     */
    abstract protected function getCommandName();
}
