<?php

namespace Maas\Core\Model\Service;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class ExtensionAttributeCrudManager
 *
 * @package Maas\Core\Model\Service
 *
 */
class ExtensionAttributeCrudManager
{
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var array
     */
    protected $cachedEntities = [];

    /**
     * ExtensionAttributeCrudManager constructor.
     *
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->cachedEntities = [];
    }

    /**
     * Load the requested extension attribute after model load
     *
     * @param AbstractModel $model
     * @param object $modelExtensionFactory Factories don't have a common ancestor class
     * @param string $extensionAttributeName
     * @param object $extensionAttributeRepository Repositories don't have a common ancestor class
     * @param object $extensionAttributeFactory Factories don't have a common ancestor class
     */
    public function loadAfter(
        AbstractModel $model,
        $modelExtensionFactory,
        $extensionAttributeName,
        $extensionAttributeRepository,
        $extensionAttributeFactory
    ) {
        $getterSetterSuffix = $this->getGetterSetterSuffix($extensionAttributeName);
        $getterName = 'get' . $getterSetterSuffix;
        $setterName = 'set' . $getterSetterSuffix;

        $modelExtension = $model->getExtensionAttributes();
        if (!$modelExtension) {
            $modelExtension = $modelExtensionFactory->create();
        }

        $extensionAttribute = $modelExtension->$getterName();
        if (!$extensionAttribute) {
            try {
                $extensionAttribute = $extensionAttributeRepository->get($model->getId());
            } catch (NoSuchEntityException $nsee) {
                $extensionAttribute = $extensionAttributeFactory->create();
                $extensionAttribute->setId($model->getId());
            }
            $modelExtension->$setterName($extensionAttribute);
        }
        $model->setExtensionAttributes($modelExtension);
    }

    /**
     * @param string $extensionAttributeName
     *
     * @return string
     */
    public function getGetterSetterSuffix($extensionAttributeName)
    {
        $extensionAttributeNameParts = explode('_', $extensionAttributeName);
        $getterSetterSuffix = '';
        foreach ($extensionAttributeNameParts as $extensionAttributeNamePart) {
            $getterSetterSuffix .= ucfirst($extensionAttributeNamePart ?? '');
        }
        return $getterSetterSuffix;
    }

    /**
     * Load the requested extension attributes after model collection load
     *
     * @param AbstractCollection $collection
     * @param string $idFieldName
     * @param object $modelExtensionFactory Factories don't have a common ancestor class
     * @param string $extensionAttributeName
     * @param object $extensionAttributeRepository Repositories don't have a common ancestor class
     * @param object $extensionAttributeFactory Factories don't have a common ancestor class
     */
    public function loadCollectionAfter(
        AbstractCollection $collection,
        $idFieldName,
        $modelExtensionFactory,
        $extensionAttributeName,
        $extensionAttributeRepository,
        $extensionAttributeFactory
    ) {
        $getterSetterSuffix = $this->getGetterSetterSuffix($extensionAttributeName);
        $getterName = 'get' . $getterSetterSuffix;
        $setterName = 'set' . $getterSetterSuffix;

        $ids = [];
        foreach ($collection as $item) {
            /** @var AbstractModel $id */
            if ($item->getId()) {
                $ids[] = $item->getId();
            }
        }
        if (!$ids) {
            return;
        }
        $extensionItems = [];
        if ($ids) {
            $searchCriteria = $this->searchCriteriaBuilder->addFilter($idFieldName, $ids, 'in')->create();
            $searchResult = $extensionAttributeRepository->getList($searchCriteria);
            $extensionItems = $searchResult->getItems();
        }
        $itemsById = [];
        foreach ($extensionItems as $item) {
            $itemsById[$item->getId()] = $item;
        }
        foreach ($collection as $item) {
            $itemExtensionAttributes = $item->getExtensionAttributes();
            if (!isset($itemExtensionAttributes)) {
                $itemExtensionAttributes = $modelExtensionFactory->create();
            }
            $extensionItem = $itemExtensionAttributes->$getterName();
            if (!$extensionItem) {
                if (isset($itemsById[$item->getId()])) {
                    $extensionItem = $itemsById[$item->getId()];
                } else {
                    $extensionItem = $extensionAttributeFactory->create();
                    $extensionItem->setId($item->getId());
                }
            }
            $itemExtensionAttributes->$setterName($extensionItem);
            $item->setExtensionAttributes($itemExtensionAttributes);
        }
    }

    /**
     * Store the requested extension attribute before model save
     *
     * @param AbstractModel $model
     * @param string $extensionAttributeName
     * @param object $extensionAttributeFactory Factories don't have a common ancestor class
     */
    public function saveBefore(AbstractModel $model, $extensionAttributeName, $extensionAttributeFactory)
    {
        $getterSetterSuffix = $this->getGetterSetterSuffix($extensionAttributeName);
        $getterName = 'get' . $getterSetterSuffix;
        $entityToCache = false;
        $modelExtension = $model->getExtensionAttributes();
        if ($modelExtension && $modelExtension->$getterName()) {
            $entityToCache = $modelExtension->$getterName();
        }
        if (!$entityToCache) {
            $entityToCache = $extensionAttributeFactory->create();
            $entityToCache->setId($model->getId());
        }
        $this->cachedEntities[get_class($model) . '|' . $extensionAttributeName] = $entityToCache;
    }

    /**
     * Save the stored requested extension attribute after model save
     *
     * @param AbstractModel $model
     * @param object $modelExtensionFactory Factories don't have a common ancestor class
     * @param string $extensionAttributeName
     * @param object $extensionAttributeRepository Repositories don't have a common ancestor class
     * @param object $extensionAttributeFactory Factories don't have a common ancestor class
     */
    public function saveAfter(
        AbstractModel $model,
        $modelExtensionFactory,
        $extensionAttributeName,
        $extensionAttributeRepository,
        $extensionAttributeFactory
    ) {
        $getterSetterSuffix = $this->getGetterSetterSuffix($extensionAttributeName);
        $setterName = 'set' . $getterSetterSuffix;

        $key = get_class($model) . '|' . $extensionAttributeName;
        if (isset($this->cachedEntities[$key])) {
            $entityToSave = $this->cachedEntities[$key];
            if (!$entityToSave->getId()) {
                $entityToSave->setId($model->getId());
            }
        } else {
            $entityToSave = $extensionAttributeFactory->create();
            $entityToSave->setId($model->getId());
        }
        $entityToSave = $extensionAttributeRepository->save($entityToSave);
        $modelExtension = $model->getExtensionAttributes();
        if (!$modelExtension) {
            $modelExtension = $modelExtensionFactory->create();
        }
        $modelExtension->$setterName($entityToSave);
        $model->setExtensionAttributes($modelExtension);
    }
}
