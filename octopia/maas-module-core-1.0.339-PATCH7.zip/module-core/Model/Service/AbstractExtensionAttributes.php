<?php

namespace Maas\Core\Model\Service;

/**
 * Class AbstractExtensionAttributes
 *
 * @package Maas\Core\Model\Service
 */
abstract class AbstractExtensionAttributes
{

    /**
     * None of the interfaces have common parent classes
     *
     * @param mixed $object
     * @param mixed $extensionFactory
     * @param mixed $extraInfoFactory
     *
     * @return mixed
     */
    protected function getObjectExtensionAttributes($object, $extensionFactory, $extraInfoFactory)
    {
        $ext = $object->getExtensionAttributes();
        if (!$ext) {
            $ext = $extensionFactory->create();
        }
        $extraInfo = $ext->getExtraInfo();
        if (!$extraInfo) {
            $extraInfo = $extraInfoFactory->create();
            $ext->setExtraInfo($extraInfo);
        }
        $object->setExtensionAttributes($ext);
        return $ext;
    }
}
