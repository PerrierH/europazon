<?php

namespace Maas\Core\Model\Import;

use Magento\Framework\ObjectManagerInterface;
use Magento\ImportExport\Model\Import\Config\ReaderFactory;
use Magento\ImportExport\Model\Import\ConfigFactory;

/**
 * Class ProductFactory
 *
 * @codeCoverageIgnore
 * @package Maas\Core\Model
 */
class ProductFactory extends \Magento\CatalogImportExport\Model\Import\ProductFactory
{
    /**
     * Factory constructor
     *
     * @param ObjectManagerInterface $objectManager
     * @param string $instanceName
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        ConfigFactory $configFactory,
        ReaderFactory $configReaderFactory,
        $instanceName = Product::class
    ) {
        parent::__construct($objectManager, $instanceName);
        $this->configFactory = $configFactory;
        $this->configReaderFactory = $configReaderFactory;
    }

    /**
     * Create class instance with specified parameters
     *
     * @param array $data
     *
     * @return \Magento\CatalogImportExport\Model\Import\Product
     */
    public function create(array $data = [])
    {
        return $this->_objectManager->create($this->_instanceName, array_merge([
            'importConfig' => $this->configFactory->create([
                'reader' => $this->configReaderFactory->create([
                    'fileName' => 'maas_import.xml'
                ])
            ])
        ], $data));
    }
}