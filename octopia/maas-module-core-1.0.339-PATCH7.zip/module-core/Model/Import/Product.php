<?php

namespace Maas\Core\Model\Import;

use Magento\CatalogImportExport\Model\Import\Product as MagentoProduct;
use Magento\ImportExport\Model\Import;

/**
 * Class Product
 *
 * @codeCoverageIgnore
 * @package Maas\Core\Model
 */
class Product extends MagentoProduct
{
    /**
     * @var bool
     */
    protected $keepCoreCategories = false;

    /**
     * Retrieve attribute by code
     *
     * @param string $attrCode
     *
     * @return mixed
     */
    public function retrieveAttributeByCode($attrCode)
    {
        /** @var string $attrCode */
        $attrCode = mb_strtolower($attrCode);

        if (!isset($this->_attributeCache[$attrCode])) {
            $attribute = $this->getResource()->getAttribute($attrCode);
            if ((strpos($attrCode, 'maas_') === 0) && ('datetime' == $attribute->getBackendType())) {
                $attribute->setIsUserDefined(0);
            }
            $this->_attributeCache[$attrCode] = $attribute;
        }

        return $this->_attributeCache[$attrCode];
    }

    /**
     * @param array $attributeIds
     *
     * @return $this
     */
    public function clearAttributeCaches($attributeIds)
    {
        foreach ($this->_productTypeModels as $model) {
            if (method_exists($model, 'reinitAttributes')) {
                $model->reinitAttributes($attributeIds);
            }
        }
        return $this;
    }

    /**
     * @param bool $keepCoreCategories
     *
     * @return $this
     */
    public function setKeepCoreCategories($keepCoreCategories)
    {
        $this->keepCoreCategories = $keepCoreCategories;
        return $this;
    }

    /**
     * Save product categories.
     *
     * @param array $categoriesData
     *
     * @return $this
     */
    protected function _saveProductCategories(array $categoriesData)
    {
        if (!$this->keepCoreCategories) {
            return parent::_saveProductCategories($categoriesData);
        }
        static $tableName = null;
        $linkField = $this->getProductEntityLinkField();
        if (!$tableName) {
            $tableName = $this->_resourceFactory->create()->getProductCategoryTable();
        }
        if ($categoriesData) {
            $categoriesIn = [];
            $delProductId = [];

            foreach ($categoriesData as $delSku => $categories) {
                $productId = $this->skuProcessor->getNewSku($delSku)[$linkField];
                $delProductId[] = $productId;

                foreach (array_keys($categories) as $categoryId) {
                    $categoriesIn[] = ['product_id' => $productId, 'category_id' => $categoryId, 'position' => 0];
                }
            }
            if (Import::BEHAVIOR_APPEND != $this->getBehavior()) {
                // only delete maas category IDs
                $deleteWhere = $this->getWhereForCategoryProductDeletion($delProductId);

                $this->_connection->delete(
                    $tableName,
                    $deleteWhere
                );
            }
            if ($categoriesIn) {
                $this->_connection->insertOnDuplicate($tableName, $categoriesIn, ['product_id', 'category_id']);
            }
        }
        return $this;
    }

    /**
     * To overload with a plugin, because of constructors
     *
     * @param int[] $delProductId
     *
     * @return string
     */
    public function getWhereForCategoryProductDeletion($delProductId)
    {
        return $this->_connection->quoteInto('product_id IN (?)', $delProductId);
    }

    /**
     * Get product entity link field
     *
     * @return string
     */
    private function getProductEntityLinkField()
    {
        if (!$this->productEntityLinkField) {
            $this->productEntityLinkField = $this->getMetadataPool()
                ->getMetadata(\Magento\Catalog\Api\Data\ProductInterface::class)
                ->getLinkField();
        }
        return $this->productEntityLinkField;
    }
}
