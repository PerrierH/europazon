<?php

namespace Maas\Core\Model\Import\Product\Type;

/**
 * Class Configurable
 *
 * @package Maas\Core\Model\Import\Product\Type
 */
class Configurable extends \Maas\ImportExport\Model\Import\Catalog\Product\Type\Configurable
{
    use TypeTrait;
}
