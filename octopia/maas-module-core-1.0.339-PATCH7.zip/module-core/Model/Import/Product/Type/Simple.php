<?php

namespace Maas\Core\Model\Import\Product\Type;

/**
 * Class Simple
 *
 * @package Maas\Core\Model\Import\Product\Type
 */
class Simple extends \Maas\ImportExport\Model\Import\Catalog\Product\Type\Simple
{
    use TypeTrait;
}
