<?php

namespace Maas\Core\Model\Import\Product\Type;

/**
 * Class Virtual
 *
 * @package Maas\Core\Model\Import\Product\Type
 */
class Virtual extends \Magento\CatalogImportExport\Model\Import\Product\Type\Virtual
{
    use TypeTrait;
}