<?php

namespace Maas\Core\Model\Import\Product\Type;

use Magento\Catalog\Model\ResourceModel\Attribute;
use Magento\ImportExport\Model\Import;

/**
 * Trait TypeTrait
 *
 * @package Maas\Core\Model\Import\Product\Type
 */
trait TypeTrait
{

    /**
     * @var null|Attribute[]
     */
    protected $_prdAttributesCache = null;


    public function reinitAttributes()
    {
        self::$commonAttributesCache = [];
        $this->_initAttributes();
    }

    /**
     * @param $ids
     *
     * @return Attribute[]
     */
    protected function _getPrdAttributesByIds($ids)
    {
        $this->_initPrdAttributesCache();
        return array_intersect_key($this->_prdAttributesCache, array_flip($ids));
    }

    /**
     * @return void
     */
    protected function _initPrdAttributesCache()
    {
        $this->_prdAttributesCache = [];
        foreach ($this->_prodAttrColFac->create() as $attribute) {
            $this->_prdAttributesCache[$attribute->getId()] = $attribute;
        }
    }
}