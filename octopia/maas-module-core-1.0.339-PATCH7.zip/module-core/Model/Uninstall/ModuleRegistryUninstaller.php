<?php

namespace Maas\Core\Model\Uninstall;

use Magento\Framework\App\DeploymentConfig;
use Magento\Framework\Config\ConfigOptionsListConstants;
use Magento\Framework\Config\File\ConfigFilePool;
use Magento\Framework\Module\ModuleList\Loader;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Used to uninstall registry from the database and deployment config
 */
class ModuleRegistryUninstaller
{
    /**
     * @var DeploymentConfig
     */
    private $deploymentConfig;

    /**
     * @var DeploymentConfig\Writer
     */
    private $writer;

    /**
     * @var Loader
     */
    private $loader;

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * ModuleRegistryUninstaller constructor.
     * @param DeploymentConfig $deploymentConfig
     * @param DeploymentConfig\Writer $writer
     * @param Loader $loader
     * @param ModuleDataSetupInterface $moduleDataSetup
     */
    public function __construct(
        DeploymentConfig $deploymentConfig,
        DeploymentConfig\Writer $writer,
        Loader $loader,
        ModuleDataSetupInterface $moduleDataSetup
    )
    {
        $this->deploymentConfig = $deploymentConfig;
        $this->writer = $writer;
        $this->loader = $loader;
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * Removes module from setup_module table
     *
     * @param OutputInterface $output
     * @param string[] $modules
     * @return void
     */
    public function removeModulesFromDb(OutputInterface $output, $modules)
    {
        $output->writeln(
            '<info>Removing ' . implode(', ', $modules) . ' from module registry in database</info>'
        );

        $connection = $this->moduleDataSetup->getConnection();
        $table = $this->moduleDataSetup->getTable('setup_module');
        foreach ($modules as $module) {
            $connection->delete($table, "`module` LIKE '" . $module . "'");
        }
    }

    /**
     * Removes module from deployment configuration
     *
     * @param OutputInterface $output
     * @param string[] $modules
     * @return void
     */
    public function removeModulesFromDeploymentConfig(OutputInterface $output, $modules)
    {
        $output->writeln(
            '<info>Removing ' . implode(', ', $modules) . ' from module list in deployment configuration</info>'
        );

        $configuredModules = $this->deploymentConfig->getConfigData(
            ConfigOptionsListConstants::KEY_MODULES
        );
        $existingModules = $this->loader->load($modules);
        $newModules = [];
        foreach (array_keys($existingModules) as $existingModule) {
            $newModules[$existingModule] = isset($configuredModules[$existingModule]) ? $configuredModules[$existingModule] : 0;
        }
        $this->writer->saveConfig(
            [
                ConfigFilePool::APP_CONFIG =>
                    [ConfigOptionsListConstants::KEY_MODULES => $newModules]
            ],
            true
        );
    }
}