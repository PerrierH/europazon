<?php

namespace Maas\Core\Model\Uninstall;

use Magento\Framework\Module\ResourceInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Setup\Model\ModuleContext;
use Symfony\Component\Console\Output\OutputInterface;
/**
 * Class to uninstall a module component
 * @codeCoverageIgnore
 */
class ModuleUninstaller
{
    /**
     * @var SchemaSetupInterface
     */
    private $setup;

    /**
     * @var UninstallCollector
     */
    private $uninstallCollector;

    /**
     * @var ResourceInterface
     */
    private $moduleResource;

    /**
     * ModuleUninstaller constructor.
     * @param SchemaSetupInterface $setup
     * @param UninstallCollector $uninstallCollector
     * @param ResourceInterface $moduleResource
     */
    public function __construct(
        SchemaSetupInterface $setup,
        UninstallCollector $uninstallCollector,
        ResourceInterface $moduleResource
    )
    {
        $this->setup = $setup;
        $this->uninstallCollector = $uninstallCollector;
        $this->moduleResource = $moduleResource;

    }

    /**
     * Invoke remove data routine in each specified module
     *
     * @param OutputInterface $output
     * @param array $modules
     * @return void
     */
    public function uninstallData(OutputInterface $output, array $modules)
    {
        $uninstalls = $this->uninstallCollector->collectUninstall($modules);
        foreach ($modules as $module) {
            if (isset($uninstalls[$module])) {
                $output->writeln("<info>Removing data of $module</info>");
                $uninstalls[$module]->uninstall(
                    $this->setup,
                    new ModuleContext($this->moduleResource->getDbVersion($module) ?: '')
                );
                $output->writeln("<info>$module Data succefully removed</info>");
            } else {
                $output->writeln("<info>No data to clear in $module</info>");
            }
        }
    }
}
