<?php
namespace Maas\Core\Model\Uninstall;

use Exception as ExceptionAlias;
use Magento\Framework\Indexer\ConfigInterface;
use Magento\Indexer\Model\IndexerFactory;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class Indexer
 * No need to test this class.
 * We only call a magento function already tested
 * class with no logic inside
 * @codeCoverageIgnore
 * @package Maas\Core\Model\Uninstall
 */
class Indexer
{
    /**
     * @var IndexerFactory
     */
    protected $indexerFactory;

    /**
     * @var ConfigInterface
     */
    protected $config;

    /**
     * Indexer constructor.
     * @param IndexerFactory $indexerFactory
     */
    public function __construct(
        IndexerFactory $indexerFactory,
        ConfigInterface $config

    ) {
        $this->indexerFactory = $indexerFactory;
        $this->config = $config;
    }

    /**
     * Regenerate full index
     *
     * @return void
     * @throws ExceptionAlias
     */
    public function execute(OutputInterface $output)
    {
        $output->writeln(
            '<info>Reindex all</info>'
        );
        $this->reindexAll();
    }

    /**
     * Regenerate all index
     *
     * @return void
     * @throws ExceptionAlias
     */
    private function reindexAll(){
        foreach (array_keys($this->config->getIndexers()) as $indexerId) {
            $indexer = $this->indexerFactory->create()->load($indexerId);
            $indexer->reindexAll();
        }
    }
}
