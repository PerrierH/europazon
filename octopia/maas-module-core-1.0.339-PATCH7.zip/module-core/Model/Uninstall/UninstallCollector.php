<?php

namespace Maas\Core\Model\Uninstall;

use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class for collecting all Uninstall interfaces in all Maas modules
 * @codeCoverageIgnore
 */
class UninstallCollector
{
    /**
     * @var ObjectManagerInterface
     */
    private $objectManager;

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;


    /**
     * Constructor
     *
     * @param ObjectManagerInterface $objectManager
     * @param ModuleDataSetupInterface $moduleDataSetup
     */

    public function __construct(
        ObjectManagerInterface $objectManager,
        ModuleDataSetupInterface $moduleDataSetup
    )
    {
        $this->objectManager = $objectManager;
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * Collect Uninstall classes from modules
     *
     * @param array $filterModules
     * @return UninstallInterface[]
     */
    public function collectUninstall($filterModules = [])
    {
        $uninstallList = [];
        $setup = $this->moduleDataSetup->getConnection();
        $result = $setup->select()->from($setup->getTableName('setup_module'), ['module']);
        if (isset($filterModules) && sizeof($filterModules) > 0) {
            $result->where('module in( ? )', $filterModules);
        }
        // go through modules
        foreach ($setup->fetchAll($result) as $row) {
            $uninstallClassName = str_replace('_', '\\', $row['module']) . '\Setup\Uninstall';
            if (class_exists($uninstallClassName)) {
                $uninstallClass = $this->objectManager->create($uninstallClassName);
                if (is_subclass_of($uninstallClass, \Magento\Framework\Setup\UninstallInterface::class)) {
                    $uninstallList[$row['module']] = $uninstallClass;
                }
            }
        }
        return $uninstallList;
    }

}