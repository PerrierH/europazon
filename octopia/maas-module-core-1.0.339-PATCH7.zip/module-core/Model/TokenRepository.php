<?php

namespace Maas\Core\Model;

use Exception;
use Maas\Core\Api\TokenRepositoryInterface;
use Maas\Core\Model\CoreFactory;
use Maas\Core\Api\Data\TokenInterface;
use Maas\Core\Model\ResourceModel\Token\CollectionFactory as TokenCollectionFactory;
use Maas\Core\Model\ResourceModel\Token\Collection;
use Maas\Core\Model\ResourceModel\TokenFactory;
use Maas\Core\Model\ResourceModel\Token;
use Maas\Core\Model\TokenFactory as ModelTokenFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Class TokenRepository
 * @codeCoverageIgnore
 * @package Maas\Core\Model
 * @codeCoverageIgnore
 */
class TokenRepository implements TokenRepositoryInterface
{
    /**
     * @var tokenFactory
     */
    protected $tokenFactory;

    /**
     * @var tokenCollectionFactory
     */
    protected $tokenCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var CoreFactory
     */
    protected $modelTokenFactory;

    /**
     * TokenRepository constructor.
     *
     * @param TokenFactory $tokenFactory
     * @param TokenCollectionFactory $tokenCollectionFactory
     * @param CollectionProcessorInterface $collectionProcessor
     * @param ModelTokenFactory $modelTokenFactory
     */
    public function __construct(
        TokenFactory $tokenFactory,
        TokenCollectionFactory $tokenCollectionFactory,
        CollectionProcessorInterface $collectionProcessor,
        ModelTokenFactory $modelTokenFactory
    ) {
        $this->tokenFactory = $tokenFactory;
        $this->tokenCollectionFactory = $tokenCollectionFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->modelTokenFactory = $modelTokenFactory;
    }

    /**
     * @param TokenInterface $token
     *
     * @return TokenInterface
     */
    public function save(TokenInterface $token)
    {
        $tokenResource = $this->tokenFactory->create();
        $tokenResource->save($token);
        return $token;
    }

    /**
     * @param int $id
     *
     * @return TokenInterface
     */
    public function get($id)
    {
        $tokenResource = $this->tokenFactory->create();
        $token = $this->modelTokenFactory->create();
        $tokenResource->load($token, $id);
        return $token;
    }

    /**
     * @param TokenInterface $token
     *
     * @throws Exception
     */
    public function delete(TokenInterface $token)
    {
        $tokenResource = $this->tokenFactory->create();
        $tokenResource->delete($token);
    }

    /**
     * @param int $id
     *
     * @throws Exception
     */
    public function deleteById($id)
    {
        $tokenResource = $this->tokenFactory->create();
        $token = $this->get($id);
        $tokenResource->delete($token);
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return TokenInterface[]
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->tokenCollectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $collection->load();
        return $collection->getItems();
    }

    /**
     * @return TokenInterface
     */
    public function getEnabledToken()
    {
        /** @var Collection $collection */
        $collection = $this->tokenCollectionFactory->create();
        $collection->load();
        return $collection->getFirstItem();
    }

    public function truncateTokenTable()
    {
        /** @var Token $tokenResource */
        $tokenResource = $this->tokenFactory->create();
        $tokenResource->truncateTableToken();
    }
}
