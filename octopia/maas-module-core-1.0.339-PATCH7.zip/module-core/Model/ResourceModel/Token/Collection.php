<?php

namespace Maas\Core\Model\ResourceModel\Token;

use Maas\Core\Model\Token as Model;
use Maas\Core\Model\ResourceModel\Token as ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\Core\Model\ResourceModel\Token
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}