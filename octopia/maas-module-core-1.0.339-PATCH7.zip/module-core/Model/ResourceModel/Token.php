<?php

namespace Maas\Core\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Token
 * @codeCoverageIgnore
 * @package Maas\Core\Model\ResourceModel
 * @codeCoverageIgnore
 */
class Token extends AbstractDb
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('maas_auth_token_info', 'token_id');
    }

    public function truncateTableToken()
    {
        /** @var \Magento\Framework\DB\Adapter\AdapterInterface $connection */
        $connection = $this->getConnection();
        $tableName = $this->getMainTable();
        $connection->truncateTable($tableName);
    }
}
