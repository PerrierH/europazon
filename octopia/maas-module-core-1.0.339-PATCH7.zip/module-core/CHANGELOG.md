#### 1.0.339  | Bug fixes (Aug 16th, 2022)
- Multiple bug fixes

#### 1.0.336-P3  | Bug fixes (Jul 30th, 2022)
- In the case of a text type attribute, the fields must be concatenated (DSI_5245-2322)
- Do not index categorizations without criteria (DSI_5245-2294)
- Move the Urls configuration from the "fixture" module to the "Core" module to be able to deactivate the "Fixture" module (DSI_5245-1959) (Not visible in the FO and BO, only in the code)
- The product is put out of stock if the offer is deactivated in the API feed (DSI_5245-1979)
- Fix to update seller information (DSI_5245-2312)
- Multi-select problem (DSI_5245-2311)
- Token expires on imports case 1,000,000 products (DSI_5245-2295)
- Do not import variant type products (DSI_5245-2364)

#### 1.0.338-EE-RC  | Enterprise adaptation and bug fixes (Jul 1st, 2022)
- Enterprise adaptation
- Error import json category ( DSI_5245-2385 )
- Compose errors (DSI_5245-2383)
- Out of stock products are always present on the site window ( DSI_5245-2372 )

#### 1.0.337-RC  | New features and bug fixes (Jun 22nd, 2022)
- Some product and offer increments are not correct in the report page (DSI_5245-1980)
- Fix to update seller information (DSI_5245-2312)
- Multi-select problem (DSI_5245-2311)
- Text type attribute, the fields must be concatenated (DSI_5245-2322)
- Categorization of variants (DSI_5245-2270)
- Categorization without criteria (DSI_5245-2294)
- Token expires during imports case 1000,000 products (DSI_5245-2295)

#### 1.0.336-p2  | Bug fixes (Jun 20th, 2022)
- The discounted amount is not transmitted in the order to RIC

#### 1.0.336-p1  | Bug fixes (Jun 16th, 2022)
- The execution of categorization rules based on a category Id was in error ("contains")

#### 1.0.337-RC  | New features and Performance and bug fixes (Jun 8th, 2022)
- Sending an attachment when opening a chat
- Sending an attachment when creating a new message in an existing discussion
- Viewing and downloading attachments sent by the seller or the telephone agent (DSI_5245-2035)
- Integration of variants (DSI_5245-1167)
- Integration of discounted prices in the Octopia API (sales channel business transaction) (DSI_5245-1949)
- [Major] Amount errors are observed when recording split orders in the Magento BO (SP 11.2) (DSI_5245-1995)
- The product is taken out of stock if the offer is deactivated in the API feed (DSI_5245-1979)
- In the catalog rules engine the attributes are sorted in alphabetical order (DSI_5245-2021)
- Move the Urls configuration from the "fixture" module to the "Core" module to be able to deactivate the "Fixture" module (DSI_5245-1959) (Not visible in the FO and BO, only in the code)

#### 1.0.336  | Bug fixes (May 24th, 2022)
- Dependency Injection
- Error in commercial categorization

#### 1.0.335  | Bug fixes (May 9th, 2022)
-  Correction of an anomaly concerning the transmission of the order to RIC (BusinessOrder to False)

#### 1.0.333  | Bug fixes (April 27th, 2022)
- Seller information is not imported correctly (blocks the best offer) (DSI_5245-2032)
- Some products have no seller even though the best offer job has passed (DSI_5245-2007)
- The canceled status for orders created an error in the order status update job (DSI_5245-2030)

#### 1.0.332  | Performance and several bug fixes (April 22th, 2022)
- If the taxes are 0 in the order, they must still be sent to RIC
- Adding and Updating Composer Files
- Remove cascading delete between maas_offer and maas_sales tables
- Error on order talk page when client session times out
- Increase the default values configured in the cron group maas_order
- Installation on a blank magento is in error
- Adapt the dataset to V3 APIs to cut old consumers (products)
- Price/stock update

#### 1.0.331  | Performance and several bug fixes (April 13th, 2022)
- Improve performance to import products and offers
- Import only offers and products updated recently
- The error when adding some products to cart has been fixed
- Sellers without legal terms are imported
- The messages written by and to the seller are now no longer displayed in discussions
- The seller's logo is no longer displayed in the seller's page if the seller does not have a logo
- Composer dependencies has been updated (webmozart )
- New tax classes other than 0 and 20% can be interpreted by the best offer job
- The basket is not kept if the payment in the PSP is in failure
- Several bug fixed

#### 1.0.330  | Performance and several bug fixes (November 11th, 2021)
- Performance Inprovement
- Add shipping country code as product attribute
- Children categories are automatically selected by selecting the parent category in the commercial categorization tool
- Improve speed page to edit Core and Octopia products in back office
- Integrate original price as product attribute for commercial use
- Categories and attributes are initialized once in Magento via json in the dataset tool
- Remove Octopia categories from the configuration
- Octopia attributes (select, multiselect) are automatically displayed in filters
- Add custom validations to discussion forms
- Use update files to update the module easily
- Several bug fixed

#### 1.0.329 | Performance and APIM connexion (September 2nd, 2021)
- Performance Inprovement
- Import Octopia categories via queue
- Import sellers via dataset
- Import Octopia products and offers via APIM
- Update default value for the configuration
- Several bug fixed
> Product and Offer API : Connected to userbox, prod environment and custom mock
> Order API : Connected to userbox and prod environment
> DEM API : Connected to userbox and prod environment

#### 1.0.328 | Shipping and orders (June 24th, 2021)
- Compatibility with Magento 2.4
- Define CRM contact reasons in Back office
- Connection to Octopia APIs to create, view and reply to messages from the customer area
- Notify the customer of new messages in customer area
- Generate a mocked up dataset from the Magento Back office to facilitate the integration
- Execute imports from the Magento back office
- Import seller information
- Adding cron groups to speed up the imports
- Several bug fixed
> Product and Offer API : Connected to Apiary beta version and custom mock
> Order API : Connected to the Octopia test and preprod environment
> DEM API : Connected to the Octopia test and preprod environment

#### 1.0.325 | Shipping and orders (March 15th, 2021)
- Choose the delivery method in the monoshipping checkout for each Octopia Product
- Choose the delivery method in the multishipping checkout for each Octopia Product
- Export and update status for Octopia orders
- Add estimated delivery dates on product page, checkout, customer zone and documents generated
- Add seller name in the checkout summary, customer zone and documents generated
- Only import new modifications on Octopia products
- Inprovement speed to add or update products
- Disable CRON in the configuration
- New control to add country code for phone numbers
- Adapat API controller to export and update orders
> Product and Offer API : Connected to Apiary beta version and custom mock
> Order API : Connected to the Octopia test environment

#### 1.0.320 | Import products and offers (February 3rd, 2021)
- Import products and offers manually or automatically
- Multi processing to import
- Show report page to control feeds
- Define the import method from the back office (RabbitMQ or PoolingSQL)
- Define the CRON frequency from the back office
- Download advanced logs to calculate the integration time step by step
- Several bug fixed> Product and Offer API : Connected to Apiary beta version and custom mock
> Categories API : Connected to Apiary beta version and custom mock

#### 1.0.318 | Discussions, catalog rules and PSP (November 25th, 2020)
- New form to open a new discussion for an order in the customer zone
- New form to show open discussions
- New form to show and send messages
- New catalog rules engine to add products in specific categories with attributes
- Moderate imported products via attributes
- Braintree compatibility to split orders
- Several bug fixed> DEM API Connected to Apiary beta version

#### 1.0.315 | Orders (Septembre 16th, 2020)
- Split orders by seller
- Marketplace filters in the back office
- Create new order status for maas orders
- Export orders automatically (CRON) and manually
- Import orders status and tracking number
> Order API Connected to Apiary beta version

#### 1.0.310 | Performance and APIM connexion (September 2nd, 2021)
- Performance Inprovement
- Import Octopia categories via queue
- Import sellers via dataset
- Import Octopia products and offers via APIM
- Update default value for the configuration
- Several bug fixed> Product and Offer API : Connected to userbox, prod environment and custom mock
> Order API : Connected to userbox and prod environment
> DEM API : Connected to userbox and prod environment

#### 1.0.303 | Shipping and orders (June 24th, 2021)
- Compatibility with Magento 2.4
- Define CRM contact reasons in Back office
- Connection to Octopia APIs to create, view and reply to messages from the customer area
- Notify the customer of new messages in customer area
- Generate a mocked up dataset from the Magento Back office to facilitate the integration
- Execute imports from the Magento back office
- Import seller information
- Adding cron groups to speed up the imports
- Several bug fixed> Product and Offer API : Connected to Apiary beta version and custom mock
> Order API : Connected to the Octopia test and preprod environment
> DEM API : Connected to the Octopia test and preprod environment

#### 1.0.302 | Shipping and orders (March 15th, 2021)
- Choose the delivery method in the monoshipping checkout for each Octopia Product
- Choose the delivery method in the multishipping checkout for each Octopia Product
- Export and update status for Octopia orders
- Add estimated delivery dates on product page, checkout, customer zone and documents generated
- Add seller name in the checkout summary, customer zone and documents generated
- Only import new modifications on Octopia products
- Inprovement speed to add or update products
- Disable CRON in the configuration
- New control to add country code for phone numbers
- Adapat API controller to export and update orders
> Product and Offer API : Connected to Apiary beta version and custom mock
> Order API : Connected to the Octopia test environment

#### 1.0.200 | Import products and offers (February 3rd, 2021)
- Import products and offers manually or automatically
- Multi processing to import
- Show report page to control feeds
- Define the import method from the back office (RabbitMQ or PoolingSQL)
- Define the CRON frequency from the back office
- Download advanced logs to calculate the integration time step by step
- Several bug fixed
> Product and Offer API : Connected to Apiary beta version and custom mock
> Categories API : Connected to Apiary beta version and custom mock

#### 1.0.110 | Discussions, catalog rules and PSP (November 25th, 2020)
- New form to open a new discussion for an order in the customer zone
- New form to show open discussions
- New form to show and send messages
- New catalog rules engine to add products in specific categories with attributes
- Moderate imported products via attributes
- Braintree compatibility to split orders
- Several bug fixed
> DEM API Connected to Apiary beta version

#### 1.0.33 | Orders (Septembre 16th, 2020)
- Split orders by seller
- Marketplace filters in the back office
- Create new order status for maas orders
- Export orders automatically (CRON) and manually
- Import orders status and tracking number
> Order API Connected to Apiary beta version
