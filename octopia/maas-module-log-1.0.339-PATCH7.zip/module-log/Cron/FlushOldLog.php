<?php
namespace Maas\Log\Cron;

use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Service\DeleteLogFile;

/**
 * Class FlushOldLog
 *
 * @package Maas\Log\Cron
 * @codeCoverageIgnore
 */
class FlushOldLog
{
    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;

    /** @var DeleteLogFile */
    private $deleteLogFile;

    /**
     * FlushOldLog constructor.
     *
     * @param ReportRepositoryInterface $reportRepository
     */
    public function __construct(
        ReportRepositoryInterface $reportRepository,
        DeleteLogFile $deleteLogFile
    ) {
        $this->reportRepository = $reportRepository;
        $this->deleteLogFile = $deleteLogFile;
    }

    /**
     * flushed expired logs
     */
    public function execute()
    {
        $this->reportRepository->flushOldLogs();
        $this->deleteLogFile->execute();
    }
}
