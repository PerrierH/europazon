<?php

namespace Maas\Log\Cron;

use Exception;
use Maas\Log\Model\Service\FrontResponseLogger as LoggerService;
use Magento\Cron\Model\Schedule;

/**
 * Class FrontResponseLogger
 * Gets the response time of the index page and log it in a daily csv file
 *
 * @codeCoverageIgnore
 * @package Maas\Log\Cron
 */
class FrontResponseLogger
{
    /** @var LoggerService */
    protected $loggerService;

    /**
     * Orders constructor.
     *
     * @param LoggerService $loggerService
     * @param Config $configModel
     */
    public function __construct(
        LoggerService $loggerService
    ) {
        $this->loggerService = $loggerService;
    }

    /**
     * @param Schedule $schedule
     *
     * @throws Exception
     */
    public function execute(Schedule $schedule)
    {
        $this->loggerService->execute();
        return $this;
    }
}
