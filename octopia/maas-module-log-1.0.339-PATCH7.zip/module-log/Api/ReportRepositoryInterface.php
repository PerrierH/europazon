<?php

namespace Maas\Log\Api;

use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\Data\ReportSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Interface ReportRepositoryInterface
 * @api
 * @package Maas\Log\Api
 */
interface ReportRepositoryInterface
{
    /**
     * @param ReportInterface $report
     *
     * @return ReportInterface
     */
    public function save(ReportInterface $report);

    /**
     * @param $id
     *
     * @return ReportInterface
     */
    public function get($id);

    /**
     * @param ReportInterface $report
     */
    public function delete(ReportInterface $report);

    public function generateLogReport(ReportInterface $report, string $module, string $action, string $operation): ReportInterface;

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return ReportSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @param ReportInterface $report
     * @param bool $error
     * @deprecated use \Maas\Log\Api\ReportRepositoryInterface::close()
     *
     * @return ReportInterface
     * @throws AlreadyExistsException
     */
    public function closeLogReport(ReportInterface $report, $error = false);
}