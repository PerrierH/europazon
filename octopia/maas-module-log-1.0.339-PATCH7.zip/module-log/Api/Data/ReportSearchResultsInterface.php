<?php

namespace Maas\Log\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface ReportSearchResultsInterface
 * @api
 * @package Maas\Log\Api\Data
 */
interface ReportSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get reports list.
     *
     * @return ReportInterface[]
     */
    public function getItems();

    /**
     * Set reports list.
     *
     * @param ReportInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}