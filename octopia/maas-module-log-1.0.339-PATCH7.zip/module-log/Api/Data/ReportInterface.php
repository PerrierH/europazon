<?php

namespace Maas\Log\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface ReportInterface
 * @api
 * @package Maas\Log\Api\Data
 */
interface ReportInterface extends ExtensibleDataInterface
{
    const ID = 'id';

    const MODULE = 'module';

    const ITEMS_COUNT = 'items_count';

    const SUCCESS_ITEMS_COUNT = 'success_items_count';

    const WARNING_ITEMS_COUNT = 'warning_items_count';

    const ERROR_ITEMS_COUNT = 'error_items_count';

    const DELTA_ITEMS_COUNT = 'delta_items_count';

    const DELTA_SUCCESS_ITEMS_COUNT = 'delta_success_items_count';

    const DELTA_WARNING_ITEMS_COUNT = 'delta_warning_items_count';

    const DELTA_ERROR_ITEMS_COUNT = 'delta_error_items_count';

    const OPERATION_TYPE = 'operation_type';

    const SCHEDULE_ID = 'schedule_id';

    const REPORT_DATA = 'data';

    const STATUS = 'status';

    const MESSAGE = 'message';

    const FILE = 'file';

    const STARTED_AT = 'started_at';

    const ENDED_AT = 'ended_at';

    const SYNC_DATE = 'sync_date';

    const IS_DELTA = 'is_delta';

    const ACTION = 'action';

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return string|null
     */
    public function getModule();

    /**
     * @param string $module
     *
     * @return $this
     */
    public function setModule($module);

    /**
     * @return int|null
     */
    public function getItemsCount();

    /**
     * @param int $count
     *
     * @return $this
     */
    public function setItemsCount($count);

    /**
     * @return int|null
     */
    public function getSuccessItemsCount();

    /**
     * @param int $count
     *
     * @return $this
     */
    public function setSuccessItemsCount($count);

    /**
     * @return int|null
     */
    public function getWarningItemsCount();

    /**
     * @param int $count
     *
     * @return $this
     */
    public function setWarningItemsCount($count);

    /**
     * @return int|null
     */
    public function getErrorItemsCount();

    /**
     * @param int $count
     *
     * @return $this
     */
    public function setErrorItemsCount($count);

    /**
     * @return string|null
     */
    public function getOperationType();

    /**
     * @param string $operationType
     *
     * @return $this
     */
    public function setOperationType($operationType);

    /**
     * @return string|null
     */
    public function getAction();

    /**
     * @param string $action
     *
     * @return $this
     */
    public function setAction($action);

    /**
     * @return int|null
     */
    public function getScheduleId();

    /**
     * @param int $scheduleId
     *
     * @return $this
     */
    public function setScheduleId($scheduleId);

    /**
     * @return string|null
     */
    public function getReportData();

    /**
     * @param string $data
     *
     * @return $this
     */
    public function setReportData($data);

    /**
     * @return string|null
     */
    public function getStatus();

    /**
     * @param string $status
     *
     * @return $this
     */
    public function setStatus($status);

    /**
     * @return string|null
     */
    public function getMessage();

    /**
     * @param string $message
     *
     * @return $this
     */
    public function setMessage($message);

    /**
     * @return string|null
     */
    public function getFile();

    /**
     * @return string|null
     */
    public function getStartedAt();

    /**
     * @param string $startedAt
     *
     * @return $this
     */
    public function setStartedAt($startedAt);

    /**
     * @return string|null
     */
    public function getEndedAt();

    /**
     * @param string $endedAt
     *
     * @return $this
     */
    public function setEndedAt($endedAt);

    /**
     * @return string|null
     */
    public function getSyncDate();

    /**
     * @param string $syncDate
     *
     * @return $this
     */
    public function setSyncDate($syncDate);

    /**
     * @return mixed
     */
    public function getIsDelta();

    /**
     * @param $delta
     * @return mixed
     */
    public function setIsDelta($delta);

    /**
     * @param int $deltaItemsCount
     *
     * @return $this
     */
    public function setDeltaItemsCount($deltaItemsCount);

    /**
     * @return int
     */
    public function getDeltaItemsCount();

    /**
     * @param int $deltaSuccessItemsCount
     *
     * @return $this
     */
    public function setDeltaSuccessItemsCount($deltaSuccessItemsCount);

    /**
     * @return int
     */
    public function getDeltaSuccessItemsCount();

    /**
     * @param int $deltaWarningItemsCount
     *
     * @return $this
     */
    public function setDeltaWarningItemsCount($deltaWarningItemsCount);

    /**
     * @return int
     */
    public function getDeltaWarningItemsCount();

    /**
     * @param int $deltaErrorItemsCount
     *
     * @return $this
     */
    public function setDeltaErrorItemsCount($deltaErrorItemsCount);

    /**
     * @return int
     */
    public function getDeltaErrorItemsCount();

    /**
     * @param string $message
     * @param int $level
     * @param boolean $echo
     */
    public function log($message, $echo = false, $level = 100);

    /**
     * Close the log
     * @param bool $error
     * @return $this
     */
    public function closeLog(bool $error = false);

    /**
     * Check if the job is over
     * @return bool
     */
    public function isJobOver(): bool;

    /**
     * Check if delta import enable
     * @return bool
     */
    public function isDeltaEnable(): bool;
}
