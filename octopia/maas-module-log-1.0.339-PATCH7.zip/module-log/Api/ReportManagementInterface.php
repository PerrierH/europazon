<?php

namespace Maas\Log\Api;

use Maas\Log\Api\Data\ReportInterface;

/**
 * Interface ReportManagementInterface
 * @api
 * @package Maas\Log\Api
 */
interface ReportManagementInterface
{
    /**
     * Close the report
     *
     * @param ReportInterface $report
     * @return ReportInterface
     */
    public function close(ReportInterface $report) : ReportInterface;

    /**
     * Abort the report
     *
     * @param ReportInterface $report
     * @return ReportInterface
     */
    public function abort(ReportInterface $report) : ReportInterface;

    /**
     * Get report by params
     *
     * @param string $module
     * @param string $action
     * @return ReportInterface
     */
    public function getStartedByModule(string $module, string $action);
}