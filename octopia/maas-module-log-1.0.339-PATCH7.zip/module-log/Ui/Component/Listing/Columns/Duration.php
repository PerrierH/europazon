<?php

namespace Maas\Log\Ui\Component\Listing\Columns;

use DateTime;
use Maas\Log\Model\ResourceModel\Report\Collection;
use Magento\Ui\Component\Listing\Columns\Column;

class Duration extends Column
{


    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if ($this->getData('name') == 'duration' && !empty($item['started_at']) && !empty($item['ended_at'])) {
                    $startDate = new DateTime($item['started_at']);
                    $endDate = new DateTime($item['ended_at']);
                    $dateDiff = $startDate->diff($endDate);
                    $item[$this->getData('name')] = $this->formatDateDiff($dateDiff);
                }
            }
        }
        return  parent::prepareDataSource($dataSource);
    }

    /**
     * Special formatting that includes days
     *
     * @param \DateInterval $dateDiff
     *
     * @return string
     */
    protected function formatDateDiff(\DateInterval $dateDiff)
    {
        return sprintf('%s:%s:%s',
            $dateDiff->d * 24 + $dateDiff->h,
            str_pad($dateDiff->i, 2, '0', STR_PAD_LEFT),
            str_pad($dateDiff->s, 2, '0', STR_PAD_LEFT)
        );
    }

    protected function applySorting()
    {
        $sorting = $this->getContext()->getRequestParam('sorting');
        $isSortable = $this->getData('config/sortable');
        if ($isSortable !== false
            && !empty($sorting['field'])
            && !empty($sorting['direction'])
            && $sorting['field'] === $this->getName()
        ) {
            $sort = $sorting['direction'];
            /** @var Collection $collection */
            $collection = $this->getContext()->getDataProvider()->getCollection();
            $collection->getSortingGridForTime($sort);
        }
    }
}
