<?php

namespace Maas\Log\Ui\Component\Listing\Columns;

use DateTime;
use Maas\Log\Model\ResourceModel\Report\Collection;
use Magento\Ui\Component\Listing\Columns\Column;

class Message extends Column
{
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (!empty($item['message'])) {
                    $item['message'] = __($item['message']);
                }
            }
        }
        return  parent::prepareDataSource($dataSource);
    }
}
