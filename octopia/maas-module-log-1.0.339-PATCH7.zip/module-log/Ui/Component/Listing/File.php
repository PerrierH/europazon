<?php

namespace Maas\Log\Ui\Component\Listing;

use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class File
 *
 * @package Maas\Log\Ui\Component\Listing
 */
class File extends Column
{
    /**
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as &$item) {
                if (isset($item[$fieldName])) {
                    $item[$fieldName] = [
                        'url' => $this->context->getUrl('maaslog/report/logFile', ['id' => $item['id']]),
                        'name' => basename($item[$fieldName]),
                    ];
                }
            }
        }
        return parent::prepareDataSource($dataSource);
    }
}