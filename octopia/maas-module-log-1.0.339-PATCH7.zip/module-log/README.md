# Maas Log
## Purpose

A module used to create logs files for a specific task. It also creates a report line in the DB that is available for consultation in a backoffice grid.  

## Techincal usage

1) Instanciate the class \Maas\Log\Model\Report
2) Use the ReportRepository method generateLogReport to link the report to a log file
3) Use the log method to add logs in the file
4) Use the ReportManagement method close to end
````bash
$report = $this->reportFactory->create()
$this->reportRepository->generateLogReport($report, 'Maas_Exemple', 'testAction');
$report->log('test log 1');
...
$report->log('test log 2');
...
$report->log('test log 3');
$this->reportManagement->close($report);
```` 

note : One log file will be created per action (import or export)

## Data storage

#### log files
Log files can be found at the following path :
````
var/log/Maas/{module_name}/{YYYY}/{MM}/{action}-{YYYYMMDDHHIISS}.log
ex : var/log/maas/Maas_Fixture/2020/08/testAction-20200812081010.log
````

#### Reports
Reports are stored in the DB table maas_report and link to the associated log file if any.

## Backoffice user access

The Reports and their associated log files can be displayed/downloaded in the back office : Content > Import / Export