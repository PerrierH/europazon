define([
    'underscore',
    'Magento_Ui/js/grid/columns/select'
], function (_, Element) {
    'use strict';

    return Element.extend({
        getStatusClass: function ($row) {
            return 'status-' + $row.status.toLowerCase().trim();
        }
    });
});
