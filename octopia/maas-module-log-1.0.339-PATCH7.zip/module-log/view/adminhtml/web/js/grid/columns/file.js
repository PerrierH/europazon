define([
    'underscore',
    'Magento_Ui/js/grid/columns/column'
], function (_, Element) {
    'use strict';

    return Element.extend({
        getFileName: function ($row) {
            if ($row.file !== null) {
                return $row.file.name;
            } else {
                return null;
            }
        },
        getUrl: function ($row) {
            if ($row.file !== null) {
                return $row.file.url;
            } else {
                return null;
            }
        }
    });
});
