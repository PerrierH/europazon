<?php

namespace Maas\Log\Test\Builder;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Model\Report;
use PHPUnit_Framework_MockObject_MockObject;

class ReportBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];
        return $this->createMock($this->getClassToInstantiate(ReportInterface::class, Report::class), $defaultData);
    }
}
