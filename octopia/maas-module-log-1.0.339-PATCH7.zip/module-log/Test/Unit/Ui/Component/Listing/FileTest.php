<?php

namespace Maas\Log\Test\Unit\Ui\Component\Listing;

use Maas\Log\Ui\Component\Listing\File;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\Context;
use PHPUnit\Framework\TestCase;

/**
 * Class FileTest
 *
 * @package Maas\Log\Test\Unit\Ui\Component\Listing
 */
class FileTest extends TestCase
{
    /**
     * @var File
     */
    private $file;

    public function setUp()
    {
        $contextMock = $this->getMockBuilder(Context::class)
            ->setMethods(['getUrl'])
            ->disableOriginalConstructor()
            ->getMock();
        $contextMock->method('getUrl')->willReturn('mockedurl');

        $uiComponentFactory = $this->getMockBuilder(UiComponentFactory::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->file = new File($contextMock, $uiComponentFactory);
        $this->file->setData('name', 'file');
    }

    /**
     * @dataProvider additionProvider
     */
    public function testPrepareDataSource($dataSource, $expected)
    {
        $this->assertEquals($this->file->prepareDataSource($dataSource), $expected);
    }

    /**
     * @return array
     */
    public function additionProvider()
    {
        return [
            // nominal case
            [
                [
                    'data' => [
                        'totalRecords' => 3,
                        'items' => [
                            [
                                'id' => 1,
                                'file' => '/log/Maas/maas_fixture/2020/08/test-20200806161206.log'
                            ],
                            [
                                'id' => 2,
                                'file' => '/log/Maas/maas_fixture/2020/08/test-20200806161342.log'
                            ],
                        ]
                    ]
                ],
                [
                    'data' => [
                        'totalRecords' => 3,
                        'items' => [
                            [
                                'id' => 1,
                                'file' => [
                                    'url' => 'mockedurl',
                                    'name' => 'test-20200806161206.log',
                                ]
                            ],
                            [
                                'id' => 2,
                                'file' => [
                                    'url' => 'mockedurl',
                                    'name' => 'test-20200806161342.log',
                                ]
                            ],
                        ]
                    ]
                ],
            ],
            // empty case
            [[], []]
        ];
    }
}