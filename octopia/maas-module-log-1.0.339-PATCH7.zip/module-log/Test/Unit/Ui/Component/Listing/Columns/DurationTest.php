<?php

namespace Maas\Log\Test\Unit\Ui\Component\Listing\Columns;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Log\Ui\Component\Listing\Columns\Duration;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\Context;
use PHPUnit\Framework\TestCase;
use ReflectionClass;
use Magento\Framework\View\Element\UiComponent\DataProvider\DataProviderInterface;
use Maas\Log\Model\ResourceModel\Report\Collection;

class DurationTest extends TestCase
{
    /**
     * @var Duration
     */
    private $stub;

    public function initTest($requestParam = [], $getData = 'duration')
    {
        $contextMock = AnyBuilder::createForClass(
            $this,
            Context::class,
            $requestParam
        )->build();

        $uiComponentFactory = AnyBuilder::createForClass($this, UiComponentFactory::class)->build();
        $this->stub = AnyBuilder::createForClass($this, Duration::class, [
            'getData' => [$this->any(), $getData],
            'getContext' => [$this->atMost(2), $contextMock]
        ])
            ->setConstructorArgs([$contextMock, $uiComponentFactory])
            ->build();
    }

    /**
     * @dataProvider getDataSource
     * TODO 1671 : re-activate test
    public function testFunctionPrepareDataSource($data, $expected)
    {
        $this->initTest();
        $data = $this->stub->prepareDataSource($data);
        $this->assertEquals($expected, $data);
    }
     */

    /**
     * @dataProvider getCondition
     */
    public function testFunctionApplySortingConditionFalse($isSortable, $sortingField, $direction)
    {
        $requestParams = [
            'getRequestParam' => [$this->once(), ['field'=>$sortingField, 'direction'=>$direction]],
            'getDataProvider' => [$this->never()]
        ];
        $this->initTest($requestParams, $isSortable);
        $this->invokeMethod($this->stub, 'applySorting');
    }

    public function testFunctionApplySortingConditionTrue()
    {
        $reportCollecion = AnyBuilder::createForClass($this, Collection::class, [
            'getSortingGridForTime' => [$this->once()]
        ])->build();
        $dataProvider = AnyBuilder::createForClass($this, DataProviderInterface::class, [
            'getCollection' => [$this->once(), $reportCollecion]
        ])->build();
        $requestParams = [
            'getRequestParam' => [$this->once(), ['field'=> 'sorting', 'direction'=>'asc']],
            'getDataProvider' => [$this->once(), $dataProvider]
        ];
        $this->initTest($requestParams, 'sorting');
        $this->invokeMethod($this->stub, 'applySorting');
    }

    protected function invokeMethod(&$object, $methodName, array $parameters = [])
    {
        $reflection = new ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }

    public function getDataSource()
    {
        yield from [
            "Expected empty array" => [[], []],
            "Expected a data source with duration time" => [
                [
                    'data' => [
                        'items' => [
                            [
                                'started_at' => '11/12/01',
                                'ended_at' => '11/12/01',
                            ]
                        ]
                    ]
                ],
                [
                    'data' => [
                        'items' => [
                            [
                                'started_at' => '11/12/01',
                                'ended_at' => '11/12/01',
                                'duration' => "00:00:00"
                            ]
                        ]
                    ]
                ]
            ],
            "Expected a data source with duration time over a day" => [
                [
                    'data' => [
                        'items' => [
                            [
                                'started_at' => '11/12/01',
                                'ended_at' => '13/12/01',
                            ]
                        ]
                    ]
                ],
                [
                    'data' => [
                        'items' => [
                            [
                                'started_at' => '11/12/01',
                                'ended_at' => '13/12/01',
                                'duration' => "48:00:00"
                            ]
                        ]
                    ]
                ]
            ],
        ];
    }

    public function getCondition()
    {
        yield from [
          "all condition false" => [false, false, false],
          "One condition false" => [true, false, true],
          "Two condition false" => [false, false, false],
        ];
    }
}
