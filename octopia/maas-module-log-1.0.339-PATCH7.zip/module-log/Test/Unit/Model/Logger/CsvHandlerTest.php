<?php

namespace Maas\Log\Test\Unit\Model\Logger;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Log\Model\Logger\CsvHandler;
use Magento\Framework\Filesystem\DriverInterface;
use PHPUnit\Framework\MockObject\MockObject;

class CsvHandlerTest extends AbstractTestCase
{
    /**
     * @var DriverInterface|MockObject
     */
    private $driverInterface;

    public function setUp()
    {
        $this->driverInterface = $this->createMock(DriverInterface::class);
    }

    /**
     * @dataProvider getCustomFilenameProvider
     *
     * @param $input
     * @param $expected
     * @param $assertType
     */
    public function testGetCustomFilename($input, $expected, $assertMethod)
    {
        /** @var CsvHandler $handler */
        $handler = $this->getMockBuilder(CsvHandler::class)
            ->setConstructorArgs([
                $this->driverInterface,
                $input['module'],
                $input['action'],
                $input['filename']
            ])
            ->setMethods()
            ->getMock();

        $this->$assertMethod(
            $expected,
            $handler->getCustomFilename()
        );
    }

    public function getCustomFilenameProvider()
    {
        yield 'auto generated log file name' => [
            'input' => ['module' => 'test_module', 'action' => 'action', 'filename' => null],
            'expected' => '/\/var\/log\/Maas_csv\/test_module\/[0-9]{4}\/[0-9]{2}\/action-[0-9]{20}\.csv/',
            'assertMethod' => 'assertRegExp',
        ];
        yield 'forced log file name' => [
            'input' => ['module' => null, 'action' => null, 'filename' => '/custom_file_name'],
            'expected' => '/custom_file_name',
            'assertMethod' => 'assertEquals',
        ];
        yield 'auto generated log name with forced file name' => [
            'input' => ['module' => 'test_module', 'action' => 'action', 'filename' => 'custom_file_name'],
            'expected' => '/\/var\/log\/Maas_csv\/test_module\/[0-9]{4}\/[0-9]{2}\/custom_file_name/',
            'assertMethod' => 'assertRegExp',
        ];
    }

    /**
     * @dataProvider getAsValidCsvRowProvider
     *
     * @param $elements
     * @param $separator
     * @param $withLineReturn
     * @param $expected
     */
    public function testGetAsValidCsvRow($elements, $separator, $withLineReturn, $expected)
    {
        $handler = $this->getMockBuilder(CsvHandler::class)
            ->disableOriginalConstructor()
            ->setMethods()
            ->getMock();

        $this->assertEquals(
            $this->invokeMethod($handler, 'getAsValidCsvRow', [$elements, $separator, $withLineReturn]),
            $expected
        );
    }

    public function getAsValidCsvRowProvider()
    {
        yield 'three cells with ; separator, sepcial chars and line return' => [
            'elements' => ['cell1', 'cell"2"', 'cell;3'],
            'separator' => ';',
            'withLineReturn' => true,
            'expected' => "\n" . 'cell1;"cell""2""";"cell;3"',
        ];
        yield 'two cells with , separator and no line return' => [
            'elements' => ['cell1', 'cell2'],
            'separator' => ',',
            'withLineReturn' => false,
            'expected' => 'cell1,cell2',
        ];
    }
}
