<?php

namespace Maas\Log\Test\Unit\Model\Logger;

use InvalidArgumentException;
use Maas\Log\Model\Logger\Handler;
use Magento\Framework\Filesystem\DriverInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class HandlerTest extends TestCase
{
    /**
     * @var DriverInterface|MockObject
     */
    private $driverInterface;

    public function setUp()
    {
        $this->driverInterface = $this->getMockBuilder(DriverInterface::class)
            ->disableOriginalConstructor()
            ->getMock();
    }

    /**
     * @dataProvider getCustomFilenameProvider
     *
     * @param $input
     * @param $expected
     * @param $assertType
     *
     * @throws \Exception
     */
    public function testGetCustomFilename($input, $expected, $assertMethod)
    {
        if ($assertMethod == 'expectException') {
            $this->expectException(InvalidArgumentException::class);
        }

        $handler = new Handler(
            $this->driverInterface,
            $input['module'],
            $input['action'],
            $input['filename']
        );

        if ($assertMethod != 'expectException') {
            $this->$assertMethod(
                $expected,
                $handler->getCustomFilename()
            );
        }
    }

    public function getCustomFilenameProvider()
    {
        yield 'auto generated log file name' => [
            ['module' => 'test_module', 'action' => 'action', 'filename' => null],
            '/\/var\/log\/Maas\/test_module\/[0-9]{4}\/[0-9]{2}\/action-[0-9]{14}\.log/',
            'assertRegExp',
        ];
        yield 'module missing exception' => [
            ['module' => null, 'action' => 'action', 'filename' => null],
            InvalidArgumentException::class,
            'expectException',
        ];
        yield 'action missing exception' => [
            ['module' => 'test_module', 'action' => null, 'filename' => null],
            InvalidArgumentException::class,
            'expectException',
        ];
        yield 'forced log file name' => [
            ['module' => null, 'action' => null, 'filename' => 'var/log/test/error.log'],
            'var/log/test/error.log',
            'assertEquals',
        ];
    }
}
