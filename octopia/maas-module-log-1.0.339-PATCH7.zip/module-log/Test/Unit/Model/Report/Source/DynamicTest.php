<?php


namespace Maas\Log\Test\Unit\Model\Report\Source;


use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Log\Model\Report\Source\Dynamic;
use Maas\Log\Model\ResourceModel\Report;
use PHPUnit\Framework\TestCase;

class DynamicTest extends TestCase
{
    public const VALUES = ['test category', 'test offer'];
    /**
     * @var Dynamic
     */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $reportResource;

    public function initTest()
    {
        $this->reportResource = AnyBuilder::createForClass($this, Report::class, [
            'getUniqueColumnValues' => [$this->once(), self::VALUES]
        ])->build();
        $this->stub = new Dynamic(
            $this->reportResource,
            '',
            false
        );
    }

    public function testToOptionArray()
    {
        $expectedOptions = [
            ['label' => '', 'value' => ''],
            ['label' => self::VALUES[0], 'value' => self::VALUES[0]],
            ['label' => self::VALUES[1], 'value' => self::VALUES[1]]
        ];
        $this->initTest();
        $options = $this->stub->toOptionArray();
        $this->assertEquals($options, $expectedOptions, 'Should return an array of array');
    }
}
