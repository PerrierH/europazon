<?php

namespace Maas\Log\Test\Unit\Model\Report\Source;

use Maas\Log\Model\Report;
use Maas\Log\Model\Report\Source\Status;
use PHPUnit\Framework\TestCase;

class StatusTest extends TestCase
{
    /**
     * @var Status
     */
    private $source;

    public function setUp()
    {
        $this->source = new Status();
    }

    /* TODO 1671 : re-activate test
    public function testToOptionArray()
    {
        $this->assertEquals(
            [
                ['label' => '', 'value' => ''],
                ['label' => __('Started'), 'value' => 'started'],
                ['label' => __('Success'), 'value' => 'success'],
                ['label' => __('Failed'), 'value' => 'failed'],
            ],
            $this->source->toOptionArray()
        );
    }
    */
}