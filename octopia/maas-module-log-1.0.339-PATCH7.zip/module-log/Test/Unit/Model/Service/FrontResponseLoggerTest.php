<?php


namespace Maas\Log\Test\Unit\Model\Service;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Log\Model\Config;
use Maas\Log\Model\Csv;
use Maas\Log\Model\CsvFactory;
use Maas\Log\Model\Service\FrontResponseLogger;
use Maas\Log\Model\Service\StoreFrontHttpCode;
use PHPUnit\Framework\TestCase;
use Psr\Log\LoggerInterface;

/**
 * Class FrontResponseLoggerTest
 *
 * @package Maas\Log\Test\Unit\Model\Service
 */
class FrontResponseLoggerTest extends TestCase
{
    /**
     * @var StoreFrontHttpCode
     */
    private $storeFrontHttpCode;

    /**
     * @var CsvFactory
     */
    private $csvLoggerFactory;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @dataProvider executeProvider
     *
     * @param $moduleEnabled bool
     * @param $loggerEnabled bool
     * @param $expectedMethod string
     */
    public function testExecute($moduleEnabled, $loggerEnabled, $expectedMethod)
    {

        $config = AnyBuilder::createForClass($this, Config::class, [
            'isModuleEnabled' => [$this->once(), $moduleEnabled, AnyBuilder::RETURN_VALUE],
            'isEnabledFrontResponseLogger' => [$this->any(), $loggerEnabled, AnyBuilder::RETURN_VALUE],
        ])
            ->build();

        $storeFrontHttpCode = AnyBuilder::createForClass($this, StoreFrontHttpCode::class, [
            'getMessage' => [$this->$expectedMethod(), 'log message', AnyBuilder::RETURN_VALUE],
            'getMessageArray' => [
                $this->$expectedMethod(),
                ['status' => 200, 'time' => 0.086],
                AnyBuilder::RETURN_VALUE
            ],
        ])
            ->build();


        $csvLogger = AnyBuilder::createForClass($this, Csv::class, [
            'initializeNewFile' => [$this->$expectedMethod(), null, AnyBuilder::RETURN_SELF],
            'newRow' => [$this->$expectedMethod(), null, AnyBuilder::RETURN_SELF],
            'finalizeRow' => [$this->$expectedMethod(), null, AnyBuilder::RETURN_SELF],
        ])
            ->build();

        $csvLoggerFactory = AnyBuilder::createForClass($this, CsvFactory::class, [
            'create' => [$this->$expectedMethod(), $csvLogger, AnyBuilder::RETURN_VALUE],
        ])
            ->build();
        $logger = AnyBuilder::createForClass($this, LoggerInterface::class, [
            'info' => [$this->$expectedMethod(), null, AnyBuilder::RETURN_SELF],
        ])
            ->build();

        $fontResponseLogger = $this->getMockBuilder(FrontResponseLogger::class)
            ->setConstructorArgs([
                'storeFrontHttpCode' => $storeFrontHttpCode,
                'csvLoggerFactory' => $csvLoggerFactory,
                'logger' => $logger,
                'configModel' => $config,
            ])
            ->setMethods()
            ->getMock();
        $fontResponseLogger->execute();
    }

    public function executeProvider()
    {
        yield 'module not enabled' => [
            'moduleEnabled' => false,
            'loggerEnabled' => true,
            'expectedMethod' => 'never',
        ];
        yield 'logger not enabled' => [
            'moduleEnabled' => true,
            'loggerEnabled' => false,
            'expectedMethod' => 'never',
        ];
        yield 'module and logger enabled' => [
            'moduleEnabled' => true,
            'loggerEnabled' => true,
            'expectedMethod' => 'once',
        ];
    }
}
