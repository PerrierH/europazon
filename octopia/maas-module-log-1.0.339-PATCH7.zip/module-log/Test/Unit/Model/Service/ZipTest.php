<?php


namespace Maas\Log\Test\Unit\Model\Service;

use Maas\Log\Model\Service\Zip;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Laminas\Filter\Compress\Zip as ZendZip;

/**
 * Class ZipTest
 *
 * @package Maas\Log\Test\Unit\Model\Service
 */
class ZipTest extends TestCase
{
    /**
     * @var ZendZip
     */
    private $zendZipMock;

    /**
     * @var ObjectManager
     */
    private $objectManager;

    /**
     * set up
     */
    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->zendZipMock = $this->createMock(ZendZip::class);
        $this->zendZipMock->expects($this->once())->method('setArchive');
        $this->zendZipMock->expects($this->once())->method('compress');
    }

    /**
     * test compress
     */
    public function testCompress()
    {
        $zip = $this->objectManager->getObject(Zip::class, ['zip' => $this->zendZipMock]);
        $zip->compress('a', 'b');
    }
}
