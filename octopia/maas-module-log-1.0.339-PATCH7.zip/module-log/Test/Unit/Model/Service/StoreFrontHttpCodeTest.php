<?php


namespace Maas\Log\Test\Unit\Model\Service;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Log\Model\Service\StoreFrontHttpCode;
use Magento\Framework\UrlInterface;
use PHPUnit\Framework\TestCase;

/**
 * Class StoreFrontHttpCodeTest
 *
 * @package Maas\Log\Test\Unit\Model\Service
 */
class StoreFrontHttpCodeTest extends TestCase
{
    /**
     * @var UrlInterface
     */
    private $url;

    public function setup()
    {
        $this->url = $this->createMock(UrlInterface::class);
    }

    /**
     * @dataProvider getMessageProvider
     *
     * @param $curlData
     * @param $date
     * @param $expected
     */
    public function testGetMessage($curlData, $date, $expected)
    {
        $httpCode = $this->getMockBuilder(StoreFrontHttpCode::class)
            ->setConstructorArgs(['url' => $this->url])
            ->setMethods(['getHttpStatusCode', 'getDate'])
            ->getMock();
        $httpCode->expects($this->once())->method('getHttpStatusCode')->willReturn($curlData);
        $httpCode->expects($this->once())->method('getDate')->willReturn($date);

        $this->assertEquals($expected, $httpCode->getMessage());
    }

    public function getMessageProvider()
    {
        yield 'nominal case' => [
            'curlData' => ['http_code' => 200, 'total_time' => 0.125],
            'date' => '2021-03-25 11:42:23',
            'expected' => "Call frontend with status 200 time in second 0.125 ; 2021-03-25 11:42:23",
        ];
    }

    /**
     * @dataProvider getMessageArrayProvider
     *
     * @param $curlData
     * @param $date
     * @param $expected
     */
    public function testGetMessageArray($curlData, $expected)
    {
        $httpCode = $this->getMockBuilder(StoreFrontHttpCode::class)
            ->setConstructorArgs(['url' => $this->url])
            ->setMethods(['getHttpStatusCode'])
            ->getMock();
        $httpCode->expects($this->once())->method('getHttpStatusCode')->willReturn($curlData);

        $this->assertEquals($expected, $httpCode->getMessageArray());
    }

    public function getMessageArrayProvider()
    {
        yield 'nominal case' => [
            'curlData' => ['http_code' => 200, 'total_time' => 0.125, 'dummy_info' => 'lorem ipsum'],
            'expected' => ['status' => 200, 'time' => 0.125],
        ];
    }

    /**
     * @return array
     */
    public function getMessageArray()
    {
        $curlDatas = $this->getHttpStatusCode();
        return [
            'status' => $curlDatas['http_code'],
            'time' => $curlDatas['total_time']
        ];
    }
}
