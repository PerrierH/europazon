<?php

namespace Maas\Log\Block\Adminhtml\Presentation;

use Maas\Core\Block\Adminhtml\Presentation\Buttons;

/**
 * Class Button
 * @codeCoverageIgnore
 * @package Maas\Log\Block\Adminhtml\Presentation
 */
class Button extends Buttons
{
    /**
     * Generate synchronize button html
     *
     * @return string
     */
    public function getButton()
    {
        $data = [
            'class' => self::CLASS_CSS,
            'href' => $this->getUrl('maaslog/report'),
            'title' => __('Reports')
        ];

        return $this->getButtonHtml($data);
    }
}
