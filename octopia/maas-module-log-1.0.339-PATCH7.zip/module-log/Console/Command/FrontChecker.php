<?php

namespace Maas\Log\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Maas\Log\Model\Service\StoreFrontHttpCode;

/**
 * Class FrontChecker
 *
 * @codeCoverageIgnore
 * @package Maas\Log\Console\Command
 */
class FrontChecker extends Command
{
    /**
     * @var StoreFrontHttpCode
     */
    private $storeFront;


    /**
     * FrontChecker constructor.
     *
     * @param StoreFrontHttpCode $logger
     * @param null $name
     */
    public function __construct(
        StoreFrontHttpCode $storeFront,
        $name = null
    ) {
        $this->storeFront = $storeFront;
        parent::__construct($name);
    }

    /**
     * @inheritDoc
     */
    protected function configure()
    {
        $this->setName('maas:front:checker');
        $this->setDescription('Check if the frontend store is still alive.');
        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return int|void|null
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $message = $this->storeFront->getMessage();
        $output->writeln("\n" . $message);
    }
}
