<?php


namespace Maas\Log\Console\Command;

use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Service\DeleteLogFile\Proxy as DeleteLogFile;
use Magento\Framework\App\Area;
use Magento\Framework\App\State as AppState;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class FlushLog
 *
 * @package Maas\Log\Console\Command
 * @codeCoverageIgnore
 *
 */
class FlushLog extends Command
{
    const DATE_TIME_FORMAT = 'Y-m-d H:i:s';

    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;

    /**
     * @var TimezoneInterface
     */
    protected $dateTime;

    /**
     * @var AppState
     */
    protected $appState;

    /** @var DeleteLogFile */
    private $deleteLogFile;

    /**
     * FlushLog constructor.
     *
     * @param ReportRepositoryInterface $reportRepository
     * @param TimezoneInterface $dateTime
     * @param AppState $appState
     * @param DeleteLogFile $deleteLogFile
     * @param null $name
     */
    public function __construct(
        ReportRepositoryInterface $reportRepository,
        TimezoneInterface $dateTime,
        AppState $appState,
        DeleteLogFile $deleteLogFile,
        $name = null
    ) {
        $this->reportRepository = $reportRepository;
        $this->dateTime = $dateTime;
        $this->appState = $appState;
        $this->deleteLogFile = $deleteLogFile;
        parent::__construct($name);
    }

    /**
     * Configures the current command.
     */
    protected function configure()
    {
        $this->setName('maas:log:flush')
            ->setDescription('Delete the old log (db entry and files) after a configurable delay');
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return $this
     * @throws LocalizedException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln($this->getTime() . ' Started flush log');

        $this->appState->setAreaCode(Area::AREA_GLOBAL);
        $total = $this->reportRepository->flushOldLogs();
        $output->writeln($this->getTime() . sprintf(' %s lines removed', $total));
        $total = $this->deleteLogFile->execute();
        $output->writeln($this->getTime() . sprintf(' %s Log files removed', $total));

        $output->writeln($this->getTime() . ' Finished flush log');

        return $this;
    }

    /**
     * @return string
     */
    protected function getTime()
    {
        $time = $this->dateTime->date()->format(self::DATE_TIME_FORMAT);
        return '[' . $time . ']';
    }
}
