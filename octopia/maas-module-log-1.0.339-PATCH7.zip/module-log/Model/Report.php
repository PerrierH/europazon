<?php

namespace Maas\Log\Model;

use Maas\ImportExport\Model\Config\Proxy as ConfigModel;
use Maas\ImportExport\Model\Import\Seller\Seller;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Model\LogFactory;
use Maas\Log\Model\Logger\HandlerFactory;
use Maas\Log\Model\Logger\Logger;
use Maas\Log\Model\Logger\LoggerFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Filesystem;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Maas\ImportExport\Model\Import\Catalog\Product;
use Maas\ImportExport\Model\Import\Offer\Offer;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\CouldNotSaveException;
use const PHP_EOL;

/**
 * Class Report
 *
 * @package Maas\Log\Model
 * @codeCoverageIgnore
 */
class Report extends AbstractModel implements ReportInterface
{
    const STATUS_STARTED = 'started';

    const STATUS_SUCCESS = 'success';

    const STATUS_FAILED = 'failed';

    const STATUS_ABORTED = 'aborted';

    const OPERATION_TYPE_IMPORT = 'Import';

    const OPERATION_TYPE_EXPORT = 'Export';

    /**
     * @var Log
     */
    protected $log;

    /**
     * @var LogFactory
     */
    protected $logFactory;

    /**
     * @var HandlerFactory
     */
    protected $handlerFactory;

    /**
     * @var LoggerFactory
     */
    protected $loggerFactory;

    /**
     * @var Filesystem
     */
    protected $filesystem;

    /** @var DateTime */
    private $date;

    /** @var bool */
    private $echo = true;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var FilterBuilder
     */
    private $filterBuilder;

    /**
     * @var ConfigModel
     */
    protected $configModel;

    /**
     * Report constructor.
     * @param Context $context
     * @param Registry $registry
     * @param \Maas\Log\Model\LogFactory $logFactory
     * @param LoggerFactory $loggerFactory
     * @param HandlerFactory $handlerFactory
     * @param Filesystem $filesystem
     * @param DateTime $date
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param ConfigModel $configModel
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context               $context,
        Registry              $registry,
        LogFactory            $logFactory,
        LoggerFactory         $loggerFactory,
        HandlerFactory        $handlerFactory,
        Filesystem            $filesystem,
        DateTime              $date,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder         $filterBuilder,
        ConfigModel           $configModel,
        AbstractResource      $resource = null,
        AbstractDb            $resourceCollection = null,
        array                 $data = []
    )
    {
        $this->logFactory = $logFactory;
        $this->loggerFactory = $loggerFactory;
        $this->handlerFactory = $handlerFactory;
        $this->filesystem = $filesystem;
        $this->date = $date;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->configModel = $configModel;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Report constructor.
     */
    public function _construct()
    {
        $this->_init('Maas\Log\Model\ResourceModel\Report');
    }


    /**
     * @param string $module
     *
     * @return this
     */
    public function setModule($module)
    {
        return $this->setData(self::MODULE, $module);
    }

    /**
     * @param int $id
     *
     * @return this
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @return int|null
     */
    public function getItemsCount()
    {
        return $this->getData(self::ITEMS_COUNT);
    }

    /**
     * @param int $count
     *
     * @return this
     */
    public function setItemsCount($count)
    {
        return $this->setData(self::ITEMS_COUNT, $count);
    }

    /**
     * @return int|null
     */
    public function getSuccessItemsCount()
    {
        return $this->getData(self::SUCCESS_ITEMS_COUNT);
    }

    /**
     * @param int $count
     *
     * @return this
     */
    public function setSuccessItemsCount($count)
    {
        return $this->setData(self::SUCCESS_ITEMS_COUNT, $count);
    }

    /**
     * @return int|null
     */
    public function getWarningItemsCount()
    {
        return $this->getData(self::WARNING_ITEMS_COUNT);
    }

    /**
     * @param int $count
     *
     * @return this
     */
    public function setWarningItemsCount($count)
    {
        return $this->setData(self::WARNING_ITEMS_COUNT, $count);
    }

    /**
     * @return int|null
     */
    public function getErrorItemsCount()
    {
        return $this->getData(self::ERROR_ITEMS_COUNT);
    }

    /**
     * @param int $count
     *
     * @return this
     */
    public function setErrorItemsCount($count)
    {
        return $this->setData(self::ERROR_ITEMS_COUNT, $count);
    }

    /**
     * @return string|null
     */
    public function getOperationType()
    {
        return $this->getData(self::OPERATION_TYPE);
    }

    /**
     * @param string $operationType
     *
     * @return this
     */
    public function setOperationType($operationType)
    {
        return $this->setData(self::OPERATION_TYPE, $operationType);
    }

    /**
     * @param string $action
     *
     * @return this
     */
    public function setAction($action)
    {
        return $this->setData(self::ACTION, $action);
    }

    /**
     * @return int|null
     */
    public function getScheduleId()
    {
        return $this->getData(self::SCHEDULE_ID);
    }

    /**
     * @param int $scheduleId
     *
     * @return this
     */
    public function setScheduleId($scheduleId)
    {
        return $this->setData(self::SCHEDULE_ID, $scheduleId);
    }

    /**
     * @return string|null
     */
    public function getReportData()
    {
        return $this->getData(self::REPORT_DATA);
    }

    /**
     * @param string $data
     *
     * @return this
     */
    public function setReportData($data)
    {
        return $this->setData(self::REPORT_DATA, $data);
    }

    /**
     * @return string|null
     */
    public function getMessage()
    {
        return $this->getData(self::MESSAGE);
    }

    /**
     * @param string $message
     *
     * @return this
     */
    public function setMessage($message)
    {
        return $this->setData(self::MESSAGE, $message);
    }

    /**
     * @return string|null
     */
    public function getStartedAt()
    {
        return $this->getData(self::STARTED_AT);
    }

    /**
     * @return string|null
     */
    public function getEndedAt()
    {
        return $this->getData(self::ENDED_AT);
    }

    /**
     * @return string|null
     */
    public function getSyncDate()
    {
        return $this->getData(self::SYNC_DATE);
    }

    /**
     * @param bool $echo
     */
    public function setEcho(bool $echo)
    {
        $this->echo = $echo;
    }

    /**
     * @param string $endedAt
     *
     * @return this
     */
    public function setEndedAt($endedAt)
    {
        return $this->setData(self::ENDED_AT, $endedAt);
    }

    /**
     * @param string $status
     *
     * @return this
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * @param string $message
     * @param boolean $echo
     * @param int $level
     */
    public function warning($message, $echo = false, $level = Logger::WARNING)
    {
        $this->log($message, $echo, $level);
    }

    /**
     * @param string $message
     * @param int $level
     * @param boolean $echo
     */
    public function error($message, $echo = false, $level = Logger::ERROR)
    {
        $this->log($message, $echo, $level);
    }

    /**
     * @param string $message
     * @param int $level
     * @param boolean $echo
     */
    public function success($message, $echo = false, $level = Logger::INFO)
    {
        $this->log($message, $echo, $level);
    }

    /**
     * @param string $message
     * @param boolean $echo
     * @param int $level
     */
    public function log($message, $echo = false, $level = Logger::DEBUG)
    {
        if ($this->getId() === ReportRepository::JOKER_REPORT_ID) {
            return;
        }
        if (!$this->log instanceof Log) {
            $this->initLog();
        }
        $this->log->log($message, $level);
        if ($echo && $this->echo) {
            print_r($message . PHP_EOL);
        }
    }

    /**
     * @return string|null
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * @return $this
     * @throws AlreadyExistsException
     */
    public function initLog()
    {
        /** the module name cannot be empty because it is used in the file path */
        if ($this->getModule() === null) {
            throw new \InvalidArgumentException(__('Module name can not be null'));
        }

        /** the action name cannot be empty because it is used in the file name */
        if ($this->getAction() === null) {
            throw new \InvalidArgumentException(__('Action name can not be null'));
        }

        $handerProperties = [
            'module' => $this->getModule(),
            'action' => $this->getAction(),
            'filename' => $this->getFile()
        ];

        $handler = $this->handlerFactory->create($handerProperties);

        $this->log = $this->logFactory->create([
            'logger' => $this->loggerFactory->create([
                'handlers' => [$handler],
            ]),
            'handler' => $handler,
        ]);

        $this->setFile($this->log->getFile());
        if (is_null($this->getStatus())) {
            $this->setStatus(self::STATUS_STARTED);
            $this->setStartedAt($this->date->gmtDate());
            $this->setSyncDate($this->date->gmtDate());
            $this->setIsDelta($this->isDeltaEnable());
            $this->log(sprintf('Starting process: %s', $this->getAction()), false);
        }

        return $this;
    }

    /**
     * @return string|null
     */
    public function getModule()
    {
        return $this->getData(self::MODULE);
    }

    /**
     * @return string|null
     */
    public function getAction()
    {
        return $this->getData(self::ACTION);
    }

    /**
     * @return string|null
     */
    public function getFile()
    {
        return $this->getData(self::FILE);
    }

    /**
     * @param int $file
     *
     * @return string
     */
    protected function setFile($file)
    {
        return $this->setData(self::FILE, $file);
    }

    /**
     * @return string|null
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * @param string $startedAt
     *
     * @return this
     */
    public function setStartedAt($startedAt)
    {
        return $this->setData(self::STARTED_AT, $startedAt);
    }

    /**
     * @return $this
     */
    public function setCurrentDateAsStartedAt()
    {
        $this->setStartedAt($this->date->gmtDate());
        return $this;
    }

    /**
     * @return $this
     */
    public function setCurrentDateAsEndedAt()
    {
        $this->setEndedAt($this->date->gmtDate());
        return $this;
    }

    /**
     * @param $syncDate
     * @return Report
     */
    public function setSyncDate($syncDate)
    {
        return $this->setData(self::SYNC_DATE, $syncDate);
    }

    /**
     * @param $delta
     * @return Report|mixed
     */
    public function setIsDelta($delta)
    {
        return $this->setData(self::IS_DELTA, $delta);
    }

    /**
     * @return array|mixed|null
     */
    public function getIsDelta()
    {
        return $this->getData(self::IS_DELTA);
    }

    /**
     * @return bool
     */
    public function removeLog()
    {
        $path = $this->filesystem
            ->getDirectoryRead(DirectoryList::VAR_DIR)
            ->getAbsolutePath($this->getFile());
        if (is_file($path)) {
            return unlink($path);
        }
        return false;
    }

    /**
     * @inheritDoc
     */
    public function setDeltaItemsCount($deltaItemsCount)
    {
        return $this->setData(self::DELTA_ITEMS_COUNT, $deltaItemsCount);
    }

    /**
     * @inheritDoc
     */
    public function getDeltaItemsCount()
    {
        return $this->getData(self::DELTA_ITEMS_COUNT);
    }

    /**
     * @inheritDoc
     */
    public function setDeltaSuccessItemsCount($deltaSuccessItemsCount)
    {
        return $this->setData(self::DELTA_SUCCESS_ITEMS_COUNT, $deltaSuccessItemsCount);
    }

    /**
     * @inheritDoc
     */
    public function getDeltaSuccessItemsCount()
    {
        return $this->getData(self::DELTA_SUCCESS_ITEMS_COUNT);
    }

    /**
     * @inheritDoc
     */
    public function setDeltaWarningItemsCount($deltaWarningItemsCount)
    {
        return $this->setData(self::DELTA_WARNING_ITEMS_COUNT, $deltaWarningItemsCount);
    }

    /**
     * @inheritDoc
     */
    public function getDeltaWarningItemsCount()
    {
        return $this->getData(self::DELTA_WARNING_ITEMS_COUNT);
    }

    /**
     * @inheritDoc
     */
    public function setDeltaErrorItemsCount($deltaErrorItemsCount)
    {
        return $this->setData(self::DELTA_ERROR_ITEMS_COUNT, $deltaErrorItemsCount);
    }

    /**
     * @inheritDoc
     */
    public function getDeltaErrorItemsCount()
    {
        return $this->getData(self::DELTA_ERROR_ITEMS_COUNT);
    }

    /**
     * @inheritDoc
     */
    public function closeLog(bool $error = false)
    {
        if ($this->getStatus() == self::STATUS_FAILED) {
            $error = true;
        } else {
            $error = $this->getItemsCount() > 0 &&
                ($this->getErrorItemsCount() > 0 || (($this->getWarningItemsCount() + $this->getSuccessItemsCount()) == 0));

        }
        $this->setEndedAt($this->date->gmtDate());
        $this->setStatus($error ? self::STATUS_FAILED : self::STATUS_SUCCESS);
        $this->log(__('Ending process: %1', $this->getAction()));
        return $this;
    }

    /**
     * Check if Import Job has finished all items
     */
    public function isJobOver(): bool
    {
        $isJobOver = $this->getItemsCount() <= (
            $this->getErrorItemsCount() +
            $this->getWarningItemsCount() +
            $this->getSuccessItemsCount()
        );
        if (!$isJobOver) {
            $isJobOver = $this->getResource()->isImportFinished($this->getId());
        }

        return $isJobOver;
    }

    /**
     * @return bool
     */
    public function isDeltaEnable(): bool
    {
        switch ($this->getAction()) {
            case Product::MAAS_LOG_ACTION:
                return $this->configModel->getCatalogProductImportDeltaEnabled();
            case Offer::MAAS_LOG_ACTION:
                return $this->configModel->getCatalogOfferImportDeltaEnabled();
            case Seller::MAAS_LOG_ACTION:
                return $this->configModel->getCatalogSellerImportDeltaEnabled();
            default:
                return 0;
        }
    }
}
