<?php

namespace Maas\Log\Model;

use Maas\Log\Model\Logger\CsvHandler;
use Maas\Log\Model\Logger\CsvHandlerFactory;

/**
 * Class Csv
 *
 * @package Maas\Log\Model
 * @@codeCoverageIgnore
 */
class Csv
{
    protected const SEPARATOR = ';';
    protected const DECIMAL_POINT = ',';

    /**
     * @var array
     */
    protected $headers = [];

    /**
     * @var array
     */
    protected $currentRow = [];

    /**
     * @var array
     */
    protected $currentMicrotimes = [];

    protected $filePath;

    /**
     * @var CsvHandlerFactory
     */
    protected $csvHandlerFactory;

    /**
     * @var CsvHandler
     */
    protected $handler;

    /**
     * Csv constructor.
     *
     * @param CsvHandlerFactory $csvHandlerFactory
     */
    public function __construct(
        CsvHandlerFactory $csvHandlerFactory
    ) {
        $this->csvHandlerFactory = $csvHandlerFactory;
    }

    /**
     * Initialize a new file.
     *
     * @param array $headers Headers to use
     * @param string $module Module
     * @param string $action Action
     * @param string $filename Custom filename if needed
     *
     * @return $this
     */
    public function initializeNewFile($headers, $module, $action, $filename = null)
    {
        $this->handler = $this->csvHandlerFactory->create([
            'module' => $module,
            'action' => $action,
            'filename' => $filename
        ]);
        $this->headers = $headers;
        return $this;
    }

    /**
     * Start a new row without saving it yet
     *
     * @param array $row Preexisting fields
     *
     * @return $this
     */
    public function newRow($row = [])
    {
        $this->currentRow = $this->combineWithHeaders($row);
        $this->currentMicrotimes = [];
        return $this;
    }

    /**
     * Filter the associative array to add as a row
     *
     * @param array $row Associative array
     *
     * @return array
     */
    protected function combineWithHeaders($row)
    {
        $combinedRow = [];
        foreach ($this->headers as $header) {
            if (isset($row[$header])) {
                $combinedRow[$header] = $row[$header];
            } else {
                $combinedRow[$header] = '';
            }
        }
        return $combinedRow;
    }

    /**
     * Start micro-timing
     *
     * @param string|string[] $fields Field(s) to which the timed microtime(s) will be saved
     *
     * @return $this
     */
    public function storeMicrotimeStart($fields)
    {
        if (!is_array($fields)) {
            $fields = [$fields];
        }
        $microtime = microtime(true);
        foreach ($fields as $field) {
            $this->currentMicrotimes[$field] = $microtime;
        }
        return $this;
    }

    /**
     * End micro-timing, add the result to the current row
     *
     * @param string|string[] $fields Field(s) to which the timed microtime(s) will be saved
     *
     * @return $this
     */
    public function storeMicrotimeFinish($fields)
    {
        $microtime = microtime(true);
        if (!is_array($fields)) {
            $fields = [$fields];
        }
        foreach ($fields as $field) {
            if (isset($this->currentMicrotimes[$field])) {
                $this->addToRow($field,
                    number_format($microtime - $this->currentMicrotimes[$field], 16, self::DECIMAL_POINT, ''));
            }
        }
        return $this;
    }

    /**
     * Add data to the current row
     *
     * @param string $key
     * @param string $value
     *
     * @return $this
     */
    public function addToRow($key, $value)
    {
        if (in_array($key, $this->headers)) {
            $this->currentRow[$key] = $value;
        }
        return $this;
    }

    /**
     * Save the current row
     *
     * @return $this
     */
    public function finalizeRow()
    {
        $this->saveRow();
        $this->currentRow = [];
        return $this;
    }

    /**
     * @return $this
     */
    protected function saveRow()
    {
        $this->handler->saveRow($this->headers, $this->combineWithHeaders($this->currentRow), self::SEPARATOR);
        $this->currentRow = [];
        return $this;
    }

    /**
     * Add an entire row at once without using other functions
     *
     * @param array $row
     *
     * @return $this
     */
    public function addRow($row)
    {
        $this->currentRow = $this->combineWithHeaders($row);
        $this->saveRow();
        return $this;
    }
}
