<?php


namespace Maas\Log\Model\Service;

use Maas\Log\Model\Config;
use Maas\Log\Model\Csv;
use Maas\Log\Model\CsvFactory;
use Maas\Log\Model\Service\StoreFrontHttpCode;
use Psr\Log\LoggerInterface;

/**
 * Class FrontResponseLogger
 * Gets the response time of the index page and log it in a daily csv file
 *
 * @package Maas\Log\Model\Service
 */
class FrontResponseLogger
{
    public const ACTION = 'Log front response time';
    public const MODULE = 'Maas_Log';
    public const HEADERS = ['Date', 'Response time', 'Status'];

    /**
     * @var StoreFrontHttpCode
     */
    private $storeFrontHttpCode;

    /**
     * @var CsvFactory
     */
    private $csvLoggerFactory;

    /**
     * @var Config
     */
    private $configModel;

    /**
     * @var Csv
     */
    private $csvLogger;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * FrontResponseLogger constructor.
     *
     * @param StoreFrontHttpCode $storeFrontHttpCode
     * @param CsvFactory $csvLoggerFactory
     * @param LoggerInterface $logger
     * @param Config $configModel
     */
    public function __construct(
        StoreFrontHttpCode $storeFrontHttpCode,
        CsvFactory $csvLoggerFactory,
        LoggerInterface $logger,
        Config $configModel
    ) {
        $this->storeFrontHttpCode = $storeFrontHttpCode;
        $this->csvLoggerFactory = $csvLoggerFactory;
        $this->logger = $logger;
        $this->configModel = $configModel;
    }

    /**
     * @return $this
     */
    public function execute()
    {
        if ($this->isEnabled()) {
            $this->logCsv();
            $this->log();
        }
        return $this;
    }

    /**
     * log with maas csv logger
     *
     * @return $this
     */
    private function logCsv()
    {
        $arrayLog = $this->storeFrontHttpCode->getMessageArray();
        $this->getCsvLogger()->newRow([
            'Date' => date('Y/m/d H:i:s'),
            'Response time' => $arrayLog['time'],
            'Status' => $arrayLog['status'],
        ]);
        $this->getCsvLogger()->finalizeRow();
        return $this;
    }

    /**
     * initialise csv log file
     */
    private function getCsvLogger()
    {
        /** @var Csv $csvLogger */
        if ($this->csvLogger === null) {
            $this->csvLogger = $this->csvLoggerFactory->create();
            $this->csvLogger->initializeNewFile(
                self::HEADERS,
                self::MODULE,
                self::ACTION,
                $this->getFileName()
            );
        }
        return $this->csvLogger;
    }

    /**
     * log with magento standard logger
     *
     * @return $this
     */
    private function log()
    {
        $this->logger->info($this->storeFrontHttpCode->getMessage());
        return $this;
    }

    /**
     * @return string
     */
    private function getFileName()
    {
        $date = date('Ymd');
        return 'front-response-' . $date . '.csv';
    }

    /**
     * @return bool
     */
    private function isEnabled()
    {
        return ($this->configModel->isModuleEnabled() && $this->configModel->isEnabledFrontResponseLogger());
    }
}
