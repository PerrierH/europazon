<?php

namespace Maas\Log\Model\Service;

use DateInterval;
use DateTime;
use Magento\Framework\Filesystem\Driver\File;
use Maas\Log\Model\Config;
use Magento\Framework\Filesystem\DirectoryList;

/**
 * Class DeleteLogFile
 *
 * @package Maas\Log\Model\Service
 * @codeCoverageIgnore
 */
class DeleteLogFile
{

    /** @var File */
    private $file;

    /** @var Config */
    private $config;

    /** @var DirectoryList */
    private $directoryList;

    /**
     * DeleteLogFile constructor.
     *
     * @param File $file
     * @param Config $config
     * @param DirectoryList $directoryList
     */
    public function __construct(
        File $file,
        Config $config,
        DirectoryList $directoryList
    )
    {
        $this->file = $file;
        $this->config = $config;
        $this->directoryList = $directoryList;
    }

    public function execute()
    {
        $removedFileCount = 0;

        $lifespan = $this->config->getLogLifespan();
        $minDate = new DateTime();
        $minDate->sub(new DateInterval('P' . $lifespan . 'D'));
        $minDate->setTime(0, 0, 0);
        $date = $minDate->getTimestamp();

        $path = $this->directoryList->getPath('var') . '/log/Maas_csv';

        $files = $this->file->readDirectoryRecursively($path);
        foreach ($files as $file) {
            if (is_file($file) && (filemtime($file) < $date)) {
                $this->file->deleteFile($file);
                $removedFileCount++;
            }
        }

        return $removedFileCount;
    }
}
