<?php


namespace Maas\Log\Model\Service;

use Magento\Framework\UrlInterface;

/**
 * Class StoreFrontHttpCode
 *
 * @package Maas\Log\Model\Service
 */
class StoreFrontHttpCode
{
    /**
     * @var UrlInterface
     */
    private $url;
    /**
     * @var array
     */
    private $httpStatusCode;

    /**
     * StoreFrontHttpCode constructor.
     *
     * @param UrlInterface $url
     */
    public function __construct(
        UrlInterface $url
    ) {
        $this->url = $url;
    }

    /**
     * @param $curlDatas
     *
     * @return string
     */
    public function getMessage()
    {
        $curlDatas = $this->getHttpStatusCode();
        $httpCode = $curlDatas['http_code'];
        $httpTimeResponse = $curlDatas['total_time'];
        return "Call frontend with status $httpCode time in second $httpTimeResponse ; {$this->getDate()}";
    }

    /**
     * @return array
     */
    public function getMessageArray()
    {
        $curlDatas = $this->getHttpStatusCode();
        return [
            'status' => $curlDatas['http_code'],
            'time' => $curlDatas['total_time']
        ];
    }

    /**
     * @return int
     * @codeCoverageIgnore
     */
    protected function getHttpStatusCode()
    {
        if ($this->httpStatusCode === null) {
            $this->httpStatusCode = $this->generateHttpStatusCode($this->getStoreUrl());
        }
        return $this->httpStatusCode;
    }

    /**
     * @param $storeUrl
     *
     * @return mixed
     * @codeCoverageIgnore
     */
    private function generateHttpStatusCode($storeUrl)
    {
        $curl = curl_init($storeUrl);
        $curlOptions = [
            CURLOPT_HEADER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_NOBODY => true,
            CURLOPT_HTTPHEADER => [
                'custom-header: testing_url',
            ]
        ];
        curl_setopt_array($curl, $curlOptions);
        curl_exec($curl);
        $urlStatusCode = curl_getinfo($curl);
        curl_close($curl);
        return $urlStatusCode;
    }

    /**
     * @return string
     * @codeCoverageIgnore
     */
    private function getStoreUrl()
    {
        $timeStamp = 'timestamp/' . time();
        return $this->url->getUrl('testing_url/url/testingfront') . $timeStamp;
    }

    /**
     * @return false|string
     * @codeCoverageIgnore
     */
    protected function getDate()
    {
        return date("Y-m-d H:i:s");
    }
}
