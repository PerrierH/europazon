<?php


namespace Maas\Log\Model\Service;

use Laminas\Filter\Compress\Zip as ZendZip;

/**
 * Class Zip
 *
 * @package Maas\Log\Model\Service
 */
class Zip
{
    /**
     * Zip constructor.
     *
     * @param ZendZip $zip
     */
    public function __construct(ZendZip $zip)
    {
        $this->zip = $zip;
    }

    /**
     * @param string $archive path of the target archive
     * @param string $content path to be compressed
     */
    public function compress($archive, $content)
    {
        $this->zip->setArchive($archive);
        $this->zip->compress($content);
    }
}
