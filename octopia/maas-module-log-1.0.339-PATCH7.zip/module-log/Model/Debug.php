<?php

namespace Maas\Log\Model;

use Psr\Log\LogLevel;

class Debug extends InitLog
{
    const FILENAME = 'var/log/Maas/debug.log';

    /**
     * @param $message
     */
    public function debug($message)
    {
        $this->log->log($message, LogLevel::DEBUG);
    }
}
