<?php

namespace Maas\Log\Model;

use Magento\Framework\Serialize\Serializer\Json;
use Maas\Log\Model\Logger\HandlerFactory;
use Maas\Log\Model\Logger\LoggerFactory;
use Maas\Log\Model\LogFactory;
use Maas\Log\Model\Log;

class InitLog
{
    const FILENAME = '';

    /** @var LoggerFactory */
    private $loggerFactory;

    /** @var HandlerFactory */
    private $handlerFactory;

    /** @var LogFactory */
    private $logFactory;

    /** @var Json */
    private $serializer;

    /**
     * @var Log
     */
    protected $log;

    /**
     * Log constructor.
     *
     * @param LoggerFactory $loggerFactory
     * @param HandlerFactory $handlerFactory
     * @param LogFactory $logFactory
     * @param Json $serializer
     */
    public function __construct(
        LoggerFactory $loggerFactory,
        HandlerFactory $handlerFactory,
        LogFactory $logFactory,
        Json $serializer
    )
    {
        $this->loggerFactory = $loggerFactory;
        $this->handlerFactory = $handlerFactory;
        $this->logFactory = $logFactory;
        $this->serializer = $serializer;
        $this->initLog();
    }

    /**
     * Init Log
     */
    public function initLog()
    {
        $handler = $this->handlerFactory->create([
            'module' => '',
            'action' => '',
            'filename' => static::FILENAME
        ]);

        $this->log = $this->logFactory->create([
            'logger' => $this->loggerFactory->create([
                'handlers' => [$handler],
            ]),
            'handler' => $handler,
        ]);
    }
}
