<?php

namespace Maas\Log\Model\Logger;

use Exception;
use InvalidArgumentException;
use Magento\Framework\Filesystem\DriverInterface;
use Magento\Framework\Logger\Handler\Base as BaseHandler;

/**
 * Class Handler
 *
 * @package Maas\Log\Model\Logger
 */
class Handler extends BaseHandler
{
    /**
     * @var string
     */
    protected $customFilename;

    /**
     * Handler constructor.
     *
     * @param DriverInterface $filesystem
     * @param string $module
     * @param string $action
     *
     * @throws Exception
     */
    public function __construct(
        DriverInterface $filesystem,
        $module = null,
        $action = null,
        $filename = null
    ) {
        $this->setCustomFileName($module, $action, $filename);
        $this->fileName = $this->customFilename;
        parent::__construct($filesystem, null);
    }

    /**
     * @param $module
     * @param $action
     * @param $filename
     *
     * @return $this
     */
    protected function setCustomFileName($module, $action, $filename)
    {
        if ($filename === null) {
            $this->customFilename = $this->createFileName($module, $action);
        } else {
            $this->customFilename = $filename;
        }
        return $this;
    }

    /**
     * @param string $module
     * @param string $action
     *
     * @return string
     */
    protected function createFileName($module, $action)
    {
        if ($module === null) {
            throw new InvalidArgumentException(__('Module name can not be null'));
        }

        if ($action === null) {
            throw new InvalidArgumentException(__('Action name can not be null'));
        }
        return $this->generateName($module, $action);
    }

    /**
     * @param string $module
     * @param string $action
     *
     * @return string
     */
    protected function generateName($module, $action)
    {
        $date = date('Y/m/%\s-YmdHis');
        return sprintf('/var/log/Maas/%s/' . $date . '.log', $module, str_replace(' ','_',$action));
    }

    /**
     * @return string
     */
    public function getCustomFilename()
    {
        return $this->customFilename;
    }
}
