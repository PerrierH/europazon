<?php

namespace Maas\Log\Model\Logger;

use Magento\Framework\Logger\Monolog;

/**
 * Class Logger
 *
 * @package Maas\Log\Model\Logger
 */
class Logger extends Monolog
{
}