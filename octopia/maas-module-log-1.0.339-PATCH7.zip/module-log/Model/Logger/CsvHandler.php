<?php

namespace Maas\Log\Model\Logger;


/**
 * Class CsvHandler
 *
 * @package Maas\Log\Model\Logger
 */
class CsvHandler extends Handler
{
    /**
     * @param $module
     * @param $action
     * @param $filename
     *
     * @return $this
     */
    protected function setCustomFileName($module, $action, $filename)
    {
        if ($filename === null) {
            $this->customFilename = $this->createFileName($module, $action);
        } else {
            if (substr($filename, 0, 1) == '/') {
                $this->customFilename = $filename;
            } else {
                $this->customFilename = dirname($this->createFileName($module, $action)) . '/' . $filename;
            }
        }
        return $this;
    }

    /**
     * Save CSV log, don't read headers if file already exists
     *
     * @param string[] $headers
     * @param string[] $row
     * @param string $separator
     *
     * @return $this
     * @codeCoverageIgnore
     */
    public function saveRow($headers, $row, $separator)
    {
        $csvOutputBuffer = '';
        if (!$this->fileAlreadyExists()) {
            $csvOutputBuffer .= $this->getAsValidCsvRow($headers, $separator, false);
        }
        $csvOutputBuffer .= $this->getAsValidCsvRow($row, $separator, true);
        $this->write(['formatted' => $csvOutputBuffer]);
        $this->rows = [];
        return $this;
    }

    /**
     * Returns an array as a writeable CSV row
     *
     * @param string[] $elements
     * @param string $separator
     * @param boolean $withLineReturn
     *
     * @return string
     */
    protected function getAsValidCsvRow($elements, $separator, $withLineReturn)
    {
        foreach($elements as $i => $element)
        {
            $element = str_replace('"', '""', $element);
            if(strpos($element, $separator) !== false || strpos($element, '"') !== false)
            {
                $element = '"'.$element.'"';
            }
            $elements[$i] = $element;
        }
        return ($withLineReturn ? "\n": '').implode($separator, $elements);
    }

    /**
     * @return bool
     * @codeCoverageIgnore
     */
    public function fileAlreadyExists()
    {
        return $this->filesystem->isExists($this->url) && $this->filesystem->isFile($this->url);
    }

    /**
     * Creates a file in a different directory and, considering the nature of logged data, microtime decimal part
     *
     * @param string $module
     * @param string $action
     *
     * @return string
     */
    protected function generateName($module, $action)
    {
        $date = date('Y/m/%\s-YmdHis');
        $microTime = microtime(true);
        $microTime = str_pad(round(($microTime - floor($microTime)) * 1000000), 6, '0', STR_PAD_LEFT);
        return sprintf('/var/log/Maas_csv/%s/' . $date . $microTime . '.csv', $module, $action);
    }
}
