<?php

namespace Maas\Log\Model;

use Psr\Log\LogLevel;

class Error extends InitLog
{
    const FILENAME = 'var/log/Maas/exception.log';

    /**
     * @param $message
     */
    public function error($message)
    {
        $this->log->log($message, LogLevel::ERROR);
    }
}
