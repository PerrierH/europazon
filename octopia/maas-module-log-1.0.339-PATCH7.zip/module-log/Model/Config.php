<?php

namespace Maas\Log\Model;

use Maas\Core\Model\Config as CoreConfig;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 *
 * @package Maas\Catalog\Model
 * @codeCoverageIgnore
 */
class Config extends CoreConfig
{
    public const XML_PATH_MAAS_LOGS_LIFESPAN = 'maas_logs/general/lifespan';
    public const XML_PATH_MAAS_FRONT_RESPONSE_LOGGER = 'maas_logs/general/front_response_logger';

    /**
     * Returns the lifespan of a report / log
     *
     * @return int
     */
    public function getLogLifespan()
    {
        return $this->getValue(self::XML_PATH_MAAS_LOGS_LIFESPAN, null, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Returns whether front response logger cron is enabled or not
     *
     * @param string $entityCode
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isEnabledFrontResponseLogger()
    {
        return (bool)$this->getValue(self::XML_PATH_MAAS_FRONT_RESPONSE_LOGGER, null, ScopeInterface::SCOPE_STORE);
    }
}
