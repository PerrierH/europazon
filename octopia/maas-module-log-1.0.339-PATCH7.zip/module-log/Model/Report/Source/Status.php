<?php

namespace Maas\Log\Model\Report\Source;

use Maas\Log\Model\Report;
use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 *
 * @package Maas\Log\Model\Report\Source
 */
class Status implements OptionSourceInterface
{
    const STATUS_LABEL = [
        Report::STATUS_STARTED => 'Started',
        Report::STATUS_SUCCESS => 'Success',
        Report::STATUS_FAILED => 'Failed',
        Report::STATUS_ABORTED => 'Aborted'
    ];

    /**
     * Get status options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        foreach (self::STATUS_LABEL as $k => $label) {
            $options[] = ['label' => __($label), 'value' => $k];
        }

        return $options;
    }
}
