<?php

namespace Maas\Log\Model\Report\Source;

use Maas\Log\Model\ResourceModel\Report;
use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class OperationType
 *
 * @package Maas\Log\Model\Report\Source
 */
class Dynamic implements OptionSourceInterface
{
    /**
     * @var Report
     */
    protected $reportResource;

    /**
     * @var mixed|string
     */
    protected $column;

    /**
     * @var boolean
     */
    protected $translate;

    /**
     * Dynamic constructor.
     *
     * @param Report $reportResource
     * @param string $column
     * @param false $translate
     */
    public function __construct(
        Report $reportResource,
        $column = '',
        $translate = false
    ) {
        $this->reportResource = $reportResource;
        $this->column = $column;
        $this->translate = $translate;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        foreach ($this->reportResource->getUniqueColumnValues($this->column) as $value) {
            $options[] = ['label' => $this->translate ? __($value) : $value, 'value' => $value];
        }
        return $options;
    }
}
