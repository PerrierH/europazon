<?php

namespace Maas\Log\Model;

use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\Data\ReportSearchResultsInterfaceFactory;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\ResourceModel\Report\Collection as ReportCollection;
use Maas\Log\Model\ResourceModel\Report as ReportResource;

/**
 * Class ReportManagement
 *
 * @package Maas\Log\Model
 */
class ReportManagement implements ReportManagementInterface
{
    private ReportRepositoryInterface $reportRepository;
    private ReportResource $reportResource;

    public function __construct(
        ReportRepositoryInterface $reportRepository,
        ReportResource $reportResource
    )
    {
        $this->reportRepository = $reportRepository;
        $this->reportResource = $reportResource;
    }

    public function close(ReportInterface $report) : ReportInterface
    {
        try {
            $report->closeLog();
            $this->reportRepository->save($report);
            $this->cleanQueueMessageByReportId($report->getId());
        } catch (\Exception $e) {
            $report->log($e->getMessage());
        }
        return $report;
    }

    public function abort(ReportInterface $report) : ReportInterface
    {
        try {
            $report->setStatus(Report::STATUS_ABORTED);
            $report->setCurrentDateAsEndedAt();
            $this->reportRepository->save($report);
            $this->cleanQueueMessageByReportId($report->getId());
        } catch (\Exception $e) {
            $report->log($e->getMessage());
        }
        return $report;
    }

    /**
     * @param string $module
     * @param string $action
     * @return false|ReportInterface|\Magento\Framework\DataObject
     */
    public function getStartedByModule(string $module, string $action)
    {
        if ($module && $action) {
            return false;
        }
        /** @var ReportCollection $collection */
        $collection = $this->reportCollectionFactory->create();
        /** @var AbstractDb $collection */
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', \Maas\Log\Model\Report::STATUS_STARTED)
            ->setPageSize(1);

        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }

        return false;
    }

    /**
     * Clean related message queue
     *
     * @param int $reportId
     */
    protected function cleanQueueMessageByReportId(int $reportId)
    {
        $this->reportResource->deleteQueueMessageByReportId($reportId);
    }
}
