<?php

namespace Maas\Log\Model;

use Maas\Log\Model\Logger\Handler;
use Psr\Log\LoggerInterface as PsrLoggerInterface;

/**
 * Class Log
 *
 * @package Maas\Log\Model
 * @codeCoverageIgnore
 */
class Log
{
    /** @var PsrLoggerInterface */
    protected $logger;

    /** @var Handler */
    protected $handler;

    /** @var string */
    protected $file;

    /**
     * Log constructor.
     *
     * @param PsrLoggerInterface $logger
     * @param Handler $handler
     */
    public function __construct(
        PsrLoggerInterface $logger,
        Handler $handler
    ) {
        $this->logger = $logger;
        $this->handler = $handler;
        $this->file = $this->handler->getCustomFilename();
    }

    /**
     * @param $message
     * @param int $level
     */
    public function log($message, $level = 100) 
    {
        $this->logger->log($level, $message);
    }

    /**
     * @return string|string[]
     */
    public function getFile()
    {
        return $this->file;
    }
}
