<?php

namespace Maas\Log\Model\ResourceModel\Report;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Zend_Db_Expr;

/**
 * Class Collection
 *
 * @package Maas\Log\Model\ResourceModel\Report
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    protected $_idFieldName = 'entity_id';
    protected $_eventPrefix = 'maas_report_collection';
    protected $_eventObject = 'report_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Maas\Log\Model\Report', 'Maas\Log\Model\ResourceModel\Report');
    }

    public function getSortingGridForTime($sort)
    {
        $this->addExpressionFieldToSelect(
            'diff',
            new Zend_Db_Expr('timediff(started_at, ended_at)'),
            ['started_at', 'ended_at']
        );
        $this->getSelect()->order(new Zend_Db_Expr("diff $sort"));
    }
}
