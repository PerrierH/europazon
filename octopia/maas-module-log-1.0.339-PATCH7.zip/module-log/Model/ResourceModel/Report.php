<?php

namespace Maas\Log\Model\ResourceModel;

use Maas\Log\Api\Data\ReportInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Zend_Db_Expr;
use Maas\Log\Model\Report as ReportModel;
use Exception;

/**
 * Class Report
 *
 * @package Maas\Log\Model\ResourceModel
 * @codeCoverageIgnore
 */
class Report extends AbstractDb
{
    /**
     * @var array
     */
    protected $_fieldsToReload = [];
    protected \Psr\Log\LoggerInterface $logger;

    /**
     * @param string $column
     *
     * @return string[]
     */
    public function getUniqueColumnValues($column)
    {
        $result = [];

        $connection = $this->getConnection();
        $fetched = $connection->fetchAll(
            $this->getConnection()
                ->select()->distinct(true)->from($this->_mainTable, [$column])
                ->order($column)
        );
        foreach ($fetched as $row) {
            $result[] = $row[$column];
        }

        return $result;
    }

    /**
     * @param $module
     * @param $action
     * @param $operationType
     * @param false $onlyStatusSuccess
     * @return bool
     * @throws LocalizedException
     */
    public function getFirstRunHasExecuted($module, $action, $operationType, $onlyStatusSuccess = false)
    {
        $status = ($onlyStatusSuccess) ? [ReportModel::STATUS_SUCCESS] : [ReportModel::STATUS_SUCCESS, ReportModel::STATUS_FAILED];
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($this->getMainTable(), ['sync_date'])
            ->where('status in (?)', $status)
            ->where('module = ?', $module)
            ->where('action = ?', $action)
            ->where('operation_type = ?', $operationType)
            ->where('sync_date is not null')
            ->order('id DESC')
            ->limit(1, 0);
        $result = $connection->fetchRow($select);
        return ($onlyStatusSuccess) ? $result : !empty($connection->fetchRow($select));
    }

    /**
     * @param string $module
     * @param string $action
     * @param string $operationType
     *
     * @return bool
     * @throws LocalizedException
     */
    public function getFirstRunIsExecuting($module, $action, $operationType)
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($this->getMainTable(), ['only_status' => new Zend_Db_Expr('group_concat(status)'), 'row_count' => new Zend_Db_Expr('count(*)')])
            ->where('status != ?', [ReportModel::STATUS_ABORTED])
            ->where('module = ?', $module)
            ->where('action = ?', $action)
            ->where('operation_type = ?', $operationType)
            ->limit(2, 0);
        $row = $connection->fetchRow($select);
        return $row['row_count'] == '1' && $row['only_status'] == ReportModel::STATUS_STARTED;
    }

    protected function _construct()
    {
        $this->_init('maas_report', 'id');
    }

    /**
     * @param AbstractModel $object
     *
     * @return $object
     */
    protected function prepareDataForUpdate($object)
    {
        $this->_fieldsToReload = [];
        foreach ([
                     ReportInterface::DELTA_ITEMS_COUNT => ReportInterface::ITEMS_COUNT,
                     ReportInterface::DELTA_SUCCESS_ITEMS_COUNT => ReportInterface::SUCCESS_ITEMS_COUNT,
                     ReportInterface::DELTA_WARNING_ITEMS_COUNT => ReportInterface::WARNING_ITEMS_COUNT,
                     ReportInterface::DELTA_ERROR_ITEMS_COUNT => ReportInterface::ERROR_ITEMS_COUNT
                 ] as $deltaField => $field) {
            $deltaValue = $object->getData($deltaField);
            if ($deltaValue > 0) {
                $object->unsetData($deltaField);
                $object->setData($field, new Zend_Db_Expr(sprintf('%s + %d', $field, $deltaValue)));
                $this->_fieldsToReload[] = $field;
            }
        }
        return parent::prepareDataForUpdate($object);
    }

    /**
     * @param AbstractModel $object
     *
     * @throws LocalizedException
     */
    protected function updateObject(AbstractModel $object)
    {
        parent::updateObject($object);
        if ($this->_fieldsToReload) {
            $connection = $this->getConnection();
            $select = $connection->select()
                ->from($this->getMainTable(), $this->_fieldsToReload)
                ->where('id = ?', $object->getId());
            $row = $connection->fetchRow($select);
            if ($row) {
                $object->setData(array_merge($object->getData(), $row));
            }
        }
        $this->_fieldsToReload = [];
    }

    /**
     * @param int $id
     * @return bool
     */
    public function isImportFinished($id): bool
    {
        try {
            if ($id) {
                $connection = $this->getConnection();
                $select = $connection->select()
                    ->from(
                        $connection->getTableName('maas_report'),
                        [
                            'items_count',
                            'success_items_count',
                            'warning_items_count',
                            'error_items_count'
                        ]
                    )
                    ->where('id = ?', $id);
                $row = $connection->fetchRow($select);
                return $row && $row['items_count'] <= ((int)$row['success_items_count'] +
                    $row['warning_items_count'] +
                    $row['error_items_count']);
            }
        } catch (Exception $e) {
            $this->getLogger()->debug($e->getMessage());
        }
        return false;
    }

    /**
     * @param int $reportId
     */
    public function deleteQueueMessageByReportId(int $reportId)
    {
        try {
            $this->getConnection()->delete($this->getTable('queue_message'), 'body like \'%"report_id":' . $reportId . '}\'');
        } catch (Exception $e) {
            $this->getLogger()->debug($e->getMessage());
        }
    }

    /**
     * Get logger
     *
     * @return \Psr\Log\LoggerInterface
     */
    private function getLogger()
    {
        if ($this->logger == null) {
            $this->logger = \Magento\Framework\App\ObjectManager::getInstance()
                ->get(\Psr\Log\LoggerInterface::class);
        }
        return $this->logger;
    }
}
