<?php

namespace Maas\Log\Model;

use DateTime;
use DateInterval;
use Exception;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\Data\ReportSearchResultsInterface;
use Maas\Log\Api\Data\ReportSearchResultsInterfaceFactory;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Config as LogConfig;
use Maas\Log\Model\ReportFactory as ModelReportFactory;
use Maas\Log\Model\ResourceModel\Report;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\Log\Model\ResourceModel\Report\Collection as ReportCollection;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class ReportRepository
 *
 * @package Maas\Log\Model
 * @codeCoverageIgnore
 */
class ReportRepository implements ReportRepositoryInterface
{
    const JOKER_REPORT_ID = -1;
    /**
     * @var ReportResource
     */
    protected $reportResource;

    /**
     * @var ModelReportFactory
     */
    protected $modelReportFactory;

    /**
     * @var ReportCollectionFactory
     */
    protected $reportCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @var LogConfig
     */
    protected $config;

    /**
     * @var ReportSearchResultsInterfaceFactory
     */
    private $searchResultFactory;
    /**
     * @var SortOrderBuilder
     */
    private $sortOrderBuilder;

    /**
     * ReportRepository constructor.
     *
     * @param ReportResource $reportResource
     * @param ReportFactory $modelReportFactory
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param CollectionProcessorInterface $collectionProcessor
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param Config $config
     * @param ReportSearchResultsInterfaceFactory $searchResultFactory
     * @param SortOrderBuilder $sortOrderBuilder
     */
    public function __construct(
        ReportResource $reportResource,
        ModelReportFactory $modelReportFactory,
        ReportCollectionFactory $reportCollectionFactory,
        CollectionProcessorInterface $collectionProcessor,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        LogConfig $config,
        ReportSearchResultsInterfaceFactory $searchResultFactory,
        SortOrderBuilder $sortOrderBuilder
    )
    {
        $this->reportResource = $reportResource;
        $this->modelReportFactory = $modelReportFactory;
        $this->reportCollectionFactory = $reportCollectionFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->config = $config;
        $this->searchResultFactory = $searchResultFactory;
        $this->sortOrderBuilder = $sortOrderBuilder;
    }

    /**
     * @param $id
     *
     * @return ReportInterface|void
     */
    public function get($id)
    {
        $report = $this->modelReportFactory->create();
        if ($id === self::JOKER_REPORT_ID) {
            $report->setId(self::JOKER_REPORT_ID);
            return $report;
        }
        $this->reportResource->load($report, $id);

        if (!$report->getId()) {
            throw new NoSuchEntityException(__('Report with id "%1" does not exist.', $id));
        }
        return $report;
    }

    /**
     * @param int $id
     *
     * @throws Exception
     */
    public function deleteById($id)
    {
        $report = $this->reportResource->load($id);
        $this->reportResource->delete($report);
    }

    /**
     * @return int|void
     * @throws Exception
     */
    public function flushOldLogs()
    {
        $lifespan = $this->config->getLogLifespan();

        $minDate = new DateTime();
        $minDate->sub(new DateInterval('P' . $lifespan . 'D'));
        $minDate->setTime(0, 0, 0);

        $this->searchCriteriaBuilder->addFilters(
            [
                $this->filterBuilder
                    ->setConditionType('lteq')
                    ->setField('ended_at')
                    ->setValue($minDate->format('Y-m-d H:i:s'))
                    ->create()
            ],
            [
                $this->filterBuilder
                    ->setConditionType('notnull')
                    ->setField('ended_at')
                    ->create(),
            ]
        );
        $searchCriteria = $this->searchCriteriaBuilder->create();

        $items = $this->getList($searchCriteria)->getItems();

        foreach ($items as $item) {
            /** @var ReportInterface $item */
            $item->removeLog();
            $this->delete($item);
        }

        return count($items);
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return ReportSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var ReportSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultFactory->create();

        /** @var ReportCollection $collection */
        $collection = $this->reportCollectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        $searchResults->setSearchCriteria($searchCriteria);
        return $searchResults;
    }

    /**
     * @param ReportInterface $report
     *
     * @throws Exception
     */
    public function delete(ReportInterface $report)
    {
        $this->reportResource->delete($report);
    }

    /**
     * @param ReportInterface $report
     * @param string $module
     * @param string $action
     * @param string $operation
     * @return ReportInterface
     */
    public function generateLogReport(ReportInterface $report, string $module, string $action, string $operation): ReportInterface
    {
        $report->setModule($module);
        $report->setAction($action);
        $report->setOperationType($operation);
        $report->initLog();
        return $this->save($report);
    }

    /**
     * @param ReportInterface $report
     *
     * @return ReportInterface
     * @throws AlreadyExistsException
     */
    public function save(ReportInterface $report)
    {
        $this->reportResource->save($report);
        return $report;
    }

    /**
     * @param ReportInterface $report
     * @param bool $error
     * @deprecated use close()
     *
     * @return ReportInterface
     * @throws AlreadyExistsException
     */
    public function closeLogReport(ReportInterface $report, $error = false)
    {
        return $this->close($report);
    }

    public function close(ReportInterface $report) : ReportInterface
    {
        try {
            $report->closeLog();
            $this->save($report);
        } catch (\Exception $e) {
            $report->log($e->getMessage());
        }
        return $report;
    }

    /**
     * @param string $module
     * @param string $action
     * @return ReportInterface
     */
    public function getStartedByModule(string $module, string $action)
    {
        if ($module && $action) {
            return false;
        }
        /** @var ReportCollection $collection */
        $collection = $this->reportCollectionFactory->create();
        /** @var AbstractDb $collection */
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', \Maas\Log\Model\Report::STATUS_STARTED)
            ->setPageSize(1);

        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }

        return false;
    }
}
