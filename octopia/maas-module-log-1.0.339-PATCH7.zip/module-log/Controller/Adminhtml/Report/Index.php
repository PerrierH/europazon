<?php

namespace Maas\Log\Controller\Adminhtml\Report;

use Magento\Customer\Controller\Adminhtml\Index as MagentoIndex;
use Magento\Framework\View\Result\Page;

/**
 * Class Index
 *
 * @package Maas\Log\Controller\Adminhtml\Report
 * @codeCoverageIgnore
 */
class Index extends MagentoIndex
{
    /**
     * @return Page
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $this->_setActiveMenu('Maas_Log::logreport');
        $resultPage->addBreadcrumb(__('Core'), __('Reports'));
        $resultPage->getConfig()->getTitle()->prepend(__('Reports'));

        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Maas_Log::importexport');
    }
}
