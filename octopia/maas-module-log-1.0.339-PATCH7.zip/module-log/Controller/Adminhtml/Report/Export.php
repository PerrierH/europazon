<?php


namespace Maas\Log\Controller\Adminhtml\Report;

use Maas\Log\Model\Service\Zip;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Filesystem;
use Magento\Store\Model\Store;

/**
 * Class Export
 *
 * @codeCoverageIgnore
 *
 * @package Maas\Log\Controller\Adminhtml\Report
 */
class Export extends Action
{
    const ARCHIVE_EXTENSION = '.zip';

    /**
     * @var Filesystem
     */
    private $filesystem;

    /**
     * @var Zip
     */
    private $zip;

    /**
     * @var ProductMetadataInterface
     */
    private $metadata;

    /**
     * @var Store
     */
    private $store;

    /**
     * Export constructor.
     *
     * @param Context $context
     * @param Filesystem $filesystem
     * @param Zip $zip
     * @param ProductMetadataInterface $metadata
     * @param Store $store
     */
    public function __construct(
        Context $context,
        FileSystem $filesystem,
        Zip $zip,
        ProductMetadataInterface $metadata,
        Store $store
    ) {
        parent::__construct($context);
        $this->filesystem = $filesystem;
        $this->zip = $zip;
        $this->metadata = $metadata;
        $this->store = $store;
    }

    /**
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        // remove old archives
        if (is_file($this->getZipPath())) {
            unlink($this->getZipPath());
        }

        // compress log folder
        $this->zip->compress($this->getZipPath(), $this->getLogPath());

        // set header for download
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename=' . basename($this->getZipName()));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Content-Length: ' . filesize($this->getZipPath()));
        readfile($this->getZipPath());
    }

    /**
     * @return string
     */
    private function getZipPath()
    {
        return $this->filesystem->getDirectoryRead(DirectoryList::VAR_DIR)
            ->getAbsolutePath('log.zip');
    }

    /**
     * @return string
     */
    private function getLogPath()
    {
        return $this->filesystem->getDirectoryRead(DirectoryList::VAR_DIR)
            ->getAbsolutePath('log/');
    }

    /**
     * @return string
     */
    private function getZipName()
    {
        $version = $this->metadata->getVersion();
        $domain = parse_url($this->store->getBaseUrl(), PHP_URL_HOST);
        $date = date('Ymd');
        $extension = self::ARCHIVE_EXTENSION;
        return $version . '-' . $domain . '-' . $date . $extension;
    }
}
