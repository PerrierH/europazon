<?php

namespace Maas\Log\Controller\Adminhtml\Report;

use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Message\ManagerInterface;

class UpdateStatus extends Action
{
    protected ManagerInterface $managerInterface;
    protected ReportRepositoryInterface $reportRepository;
    protected ReportManagementInterface $reportManagement;

    /**
     * ChangeStatus constructor.
     *
     * @param Context $context
     * @param ManagerInterface $managerInterface
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     */
    public function __construct(
        Context          $context,
        ManagerInterface $managerInterface,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement
    )
    {
        parent::__construct($context);
        $this->managerInterface = $managerInterface;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
    }

    /**
     * @return ResultInterface
     * @throws AlreadyExistsException
     */
    public function execute()
    {
        $reportId = $this->getRequest()->getParam('id');
        try {
            $report = $this->reportRepository->get($reportId);
            $this->reportManagement->abort($report);
            $this->managerInterface->addSuccessMessage(__("The report with the id %1 has been aborted.", $reportId));
        } catch (NoSuchEntityException $e) {
            $this->managerInterface->addErrorMessage(__("The report with the id %1 doesn't abort.", $reportId));
        }

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
