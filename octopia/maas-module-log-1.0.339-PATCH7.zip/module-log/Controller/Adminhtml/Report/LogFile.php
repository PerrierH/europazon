<?php

namespace Maas\Log\Controller\Adminhtml\Report;

use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\View\Result\Layout;

/**
 * Class LogFile
 *
 * @package Maas\Log\Controller\Adminhtml\Report
 * @codeCoverageIgnore
 */
class LogFile extends Action
{
    /**
     * @var Filesystem
     */
    protected $filesystem;

    /**
     * @var ManagerInterface
     */
    protected $managerInterface;

    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;

    /**
     * LogFile constructor.
     *
     * @param Context $context
     * @param Filesystem $filesystem
     * @param ManagerInterface $managerInterface
     * @param ReportRepositoryInterface $reportRepository
     */
    public function __construct(
        Context $context,
        Filesystem $filesystem,
        ManagerInterface $managerInterface,
        ReportRepositoryInterface $reportRepository
    ) {
        parent::__construct($context);
        $this->filesystem = $filesystem;
        $this->managerInterface = $managerInterface;
        $this->reportRepository = $reportRepository;
    }

    /**
     * @return ResponseInterface|ResultInterface|Layout
     */
    public function execute()
    {
        $reportId = $this->getRequest()->getParam('id');

        try {
            $report = $this->reportRepository->get($reportId);
        } catch (NoSuchEntityException $e) {
            /** manage cas where the report does not exist */
            $this->managerInterface->addErrorMessage(__('The report with the id "%1" doesn\'t exist.', $reportId));
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }

        /** manage cas where the file does not exist */
        if (!file_exists($this->getPath($report))) {
            $this->managerInterface->addErrorMessage(__('The file "%1" doesn\'t exist.',
                basename($this->getPath($report))));
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/text');
        header('Content-Disposition: attachment; filename=' . basename($this->getPath($report)));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Content-Length: ' . filesize($this->getPath($report)));
        readfile($this->getPath($report));
    }

    /**
     * @param ReportInterface $report
     *
     * @return string
     */
    protected function getPath(ReportInterface $report)
    {
        return $this->filesystem
            ->getDirectoryRead(DirectoryList::ROOT)
            ->getAbsolutePath($report->getFile());
    }
}