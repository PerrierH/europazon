<?php

namespace Maas\Log\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 *
 * @package Maas\Log\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    const  TABLE_MAAS_REPORT = 'maas_report';
    const  TABLE_MAAS_JOB = 'maas_job';

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connexion = $setup->getConnection();
        $connexion->dropTable($setup->getTable(self::TABLE_MAAS_REPORT));
        $connexion->dropTable($setup->getTable(self::TABLE_MAAS_JOB));
    }
}
