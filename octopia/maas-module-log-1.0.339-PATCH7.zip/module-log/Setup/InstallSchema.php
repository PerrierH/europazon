<?php

namespace Maas\Log\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Zend_Db_Expr;

/**
 * Class InstallSchema
 *
 * @package Maas\Log\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $this->createLogTable($installer);
        $this->createMaasJob($installer);

        $installer->endSetup();
    }

    /**
     * @param $installer
     */
    public function createLogTable($installer)
    {
        $tableName = 'maas_report';

        if (!$installer->getConnection()->isTableExists($installer->getTable($tableName))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable($tableName)
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Report Id'
            )->addColumn(
                'module',
                Table::TYPE_TEXT,
                25,
                [],
                'Maas Module'
            )->addColumn(
                'action',
                Table::TYPE_TEXT,
                50,
                [],
                'Action to execute'
            )->addColumn(
                'items_count',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Number of Items'
            )->addColumn(
                'success_items_count',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Number of Items in Success'
            )->addColumn(
                'warning_items_count',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'default' => 0],
                'Number of Items in Warning'
            )->addColumn(
                'error_items_count',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'default' => 0],
                'Number of Items in Error'
            )->addColumn(
                'operation_type',
                Table::TYPE_TEXT,
                50,
                [],
                'Type of Operation'
            )->addColumn(
                'schedule_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true],
                'Cron Schedule Id'
            )->addColumn(
                'data',
                Table::TYPE_TEXT,
                null,
                [],
                'Operation Data'
            )->addColumn(
                'status',
                Table::TYPE_TEXT,
                25,
                [],
                'Status'
            )->addColumn(
                'message',
                Table::TYPE_TEXT,
                null,
                [],
                'Message'
            )->addColumn(
                'file',
                Table::TYPE_TEXT,
                255,
                [],
                'Log File'
            )->addColumn(
                'created_at',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => false, 'default' => new Zend_Db_Expr('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],

                'Report Creation Date'
            )->addColumn(
                'updated_at',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => false, 'default' => new Zend_Db_Expr('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],

                'Report Update Date'
            )->addColumn(
                'started_at',
                Table::TYPE_DATETIME,
                null,
                [],
                'Operation start Date'
            )->addColumn(
                'ended_at',
                Table::TYPE_DATETIME,
                null,
                [],
                'Operation End Date'
            );

            $installer->getConnection()->createTable($table);
        }
    }

    /**
     * @param $installer
     */
    public function createMaasJob($installer)
    {
        if (!$installer->getConnection()->isTableExists($installer->getTable('maas_job'))) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('maas_job')
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id job'
            )->addColumn(
                'report_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Id job'
            )->addColumn(
                'name',
                Table::TYPE_TEXT,
                25,
                [],
                'job name'
            )->addColumn(
                'type',
                Table::TYPE_TEXT,
                25,
                [],
                'job type'
            )->addColumn(
                'status',
                Table::TYPE_TEXT,
                25,
                [],
                'job name'
            )->addColumn(
                'last_execution_date',
                Table::TYPE_DATETIME,
                null,
                [],
                'Last Import date'
            );

            $installer->getConnection()->createTable($table);
        }
    }
}
