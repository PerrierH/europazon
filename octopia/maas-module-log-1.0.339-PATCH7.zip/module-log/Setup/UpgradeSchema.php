<?php

namespace Maas\Log\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            //delete table maas_job
            $connection->dropTable($setup->getTable('maas_job'));
        }
        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            //add sync_date column in table maas_report
            if ($setup->tableExists('maas_report')) {
                $connection->addColumn(
                    $connection->getTableName('maas_report'),
                    'sync_date',
                    [
                        'type' => Table::TYPE_DATETIME,
                        'length' => 255,
                        'comment' => 'Operation Sync Date'
                    ]
                );
            }
        }
        if (version_compare($context->getVersion(), '1.0.3', '<') &&
            $setup->tableExists('maas_report')) {
            //add is_delta column in table maas_report
            $connection->addColumn(
                $connection->getTableName('maas_report'),
                'is_delta',
                [
                    'type' => Table::TYPE_BOOLEAN,
                    'default' => 0,
                    'nullable' => true,
                    'comment' => 'Is delta enable'
                ]
            );
        }
        $setup->endSetup();
    }
}
