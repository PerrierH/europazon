<?php

namespace Maas\Offer\Model\Offer\Config\Source;


use Maas\Offer\Model\OfferRepository;
use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Class Options
 * @package Maas\Offer\Model\Offer\Config\Source
 */
class Options extends AbstractSource
{
    protected $offerRepository;

    /**
     * @var SearchCriteriaInterface
     */
    private $searchCriteria;

    /**
     * Options constructor.
     * @param OfferRepository $offerRepository
     * @param SearchCriteriaInterface $searchCriteria
     */
    public function __construct(
        OfferRepository $offerRepository,
        SearchCriteriaInterface $searchCriteria
    )
    {
        $this->offerRepository = $offerRepository;
        $this->searchCriteria = $searchCriteria;
    }

    public function getAllOptions()
    {
        $offers = $this->offerRepository->getList($this->searchCriteria)->getItems();
        $options [] = ['value' => "", 'label' => ' '];
        foreach ($offers as $offer) {
            array_push($options,
                [
                    'label' => __($offer->getMaasEntityId()),
                    'value' => $offer->getEntityId()
                ]
            );
        }
        return $options;
    }
}
