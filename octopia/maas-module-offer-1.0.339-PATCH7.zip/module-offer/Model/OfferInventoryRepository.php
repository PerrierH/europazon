<?php

namespace Maas\Offer\Model;

use Exception;
use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Api\Data\OfferInventoryInterface;
use Maas\Offer\Api\Data\OfferInventorySearchResultsInterfaceFactory;
use Maas\Offer\Api\OfferInventoryRepositoryInterface;
use Maas\Offer\Model\ResourceModel\OfferInventory\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Class OfferInventoryRepository
 *
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferInventoryRepository extends AbstractRepository implements OfferInventoryRepositoryInterface
{
    /**
     * @param OfferInventoryInterface $offerInventory
     *
     * @return OfferInventoryInterface
     * @throws AlreadyExistsException
     */
    public function save(OfferInventoryInterface $offerInventory)
    {
        return $this->_save($offerInventory);
    }

    /**
     * @param OfferInventoryInterface $offerInventory
     *
     * @throws Exception
     */
    public function delete(OfferInventoryInterface $offerInventory)
    {
        $this->_delete($offerInventory);
    }
}
