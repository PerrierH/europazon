<?php

namespace Maas\Offer\Model;

use Maas\Offer\Api\Data\OfferTaxInterface;
use Maas\Offer\Model\ResourceModel\OfferTax as ResourceModel;
use Magento\Framework\Model\AbstractModel;

/**
 * Class OfferTax
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferTax extends AbstractModel implements OfferTaxInterface
{
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @return mixed
     */
    public function getPriceId()
    {
        return $this->_getData(self::PRICE_ID);
    }

    /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->_getData(self::CODE);
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->_getData(self::TYPE);
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->_getData(self::VALUE);
    }

    /**
     * @param $offerId
     * @return mixed
     */
    public function setPriceId($offerId)
    {
        return $this->setData(self::PRICE_ID, $offerId);
    }

    /**
     * @param $code
     * @return mixed
     */
    public function setCode($code)
    {
        return $this->setData(self::CODE, $code);
    }

    /**
     * @param $type
     * @return mixed
     */
    public function setType($type)
    {
        return $this->setData(self::TYPE, $type);
    }

    /**
     * @param $value
     * @return mixed
     */
    public function setValue($value)
    {
        return $this->setData(self::VALUE, $value);
    }
}
