<?php

namespace Maas\Offer\Model;

use Exception;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\Data\OfferSearchResultsInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Offer\Model\ResourceModel\Offer\CollectionFactory as OfferCollectionFactory;
use Maas\Offer\Model\ResourceModel\OfferFactory;
use Maas\Offer\Model\ResourceModel\Offer as OfferResource;
use Maas\Offer\Model\OfferFactory as ModelOfferFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Maas\Offer\Api\Data\OfferSearchResultsInterfaceFactory;

/**
 * Class OfferRepository
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 * @codeCoverageIgnore
 */
class OfferRepository implements OfferRepositoryInterface
{
    /*
     * @var OfferResource
     */
    protected $offerResource;

    /**
     * @var OfferCollectionFactory
     */
    protected $offerCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;
    /**
     * @var ModelOfferFactory
     */
    protected $modelOfferFactory;

    /**
     * @var OfferSearchResultsInterfaceFactory
     */
    protected $offerSearchResultsInterfaceFactory;

    /**
     * OfferRepository constructor.
     *
     * @param OfferResource $offerResource
     * @param OfferCollectionFactory $offerCollectionFactory
     * @param CollectionProcessorInterface $collectionProcessor
     * @param ModelOfferFactory $modelOfferFactory
     * @param OfferSearchResultsInterfaceFactory $offerSearchResultsInterfaceFactory
     */
    public function __construct(
        OfferResource $offerResource,
        OfferCollectionFactory $offerCollectionFactory,
        CollectionProcessorInterface $collectionProcessor,
        ModelOfferFactory $modelOfferFactory,
        OfferSearchResultsInterfaceFactory $offerSearchResultsInterfaceFactory
    ) {
        $this->offerResource = $offerResource;
        $this->offerCollectionFactory = $offerCollectionFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->modelOfferFactory = $modelOfferFactory;
        $this->offerSearchResultsInterfaceFactory = $offerSearchResultsInterfaceFactory;
    }

    /**
     * @param OfferInterface $offer
     *
     * @return OfferInterface
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function save(OfferInterface $offer)
    {
        $this->offerResource->save($offer);
        return $offer;
    }

    /**
     * @param int $id
     *
     * @return OfferInterface
     */
    public function get($id)
    {
        $offer = $this->modelOfferFactory->create();
        $this->offerResource->load($offer, $id);
        return $offer;
    }

    /**
     * @param OfferInterface $offer
     *
     * @throws Exception
     */
    public function delete(OfferInterface $offer)
    {
        $this->offerResource->delete($offer);
    }

    /**
     * @param int $id
     *
     * @throws Exception
     */
    public function deleteById($id)
    {
        $offer = $this->get($id);
        $this->offerResource->delete($offer);
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return OfferSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var OfferSearchResultsInterface $searchResults */
        $searchResults = $this->offerSearchResultsInterfaceFactory->create();

        /** @var \Maas\Offer\Model\ResourceModel\Offer\Collection $collection */
        $collection = $this->offerCollectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResults->setItems($collection->getItems());
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setTotalCount($collection->getSize());

        return $searchResults;
    }
}