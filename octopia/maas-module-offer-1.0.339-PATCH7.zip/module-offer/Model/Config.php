<?php


namespace Maas\Offer\Model;

use Maas\Core\Model\Config as CoreConfig;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class Config extends CoreConfig
{
    public const XML_PATH_IS_PRODUCT_ACTIVATION_ENABLED = 'maas_bestoffer/general/is_product_activation_enabled';
    public const XML_PATH_ACTIVATE_PRODUCTS_INCOMPLETE_SELLERS = 'maas_bestoffer/general/activate_products_incomplete_sellers';

    /** Default tax class for products */
    public const CONFIG_DEFAULT_PRODUCT_TAX_CLASS = 'tax/classes/default_product_tax_class';
    
    /* System Config -> Variant Product Import */
    public const INCLUDE_VARIANT_PRODUCT_IMPORT = 'maas_products/general/catalog_variant_product_import';
    /**
     * @param $scopeCode
     * @return string|null
     */
    public function getDefaultProductTaxClass($scopeCode = null)
    {
        return $this->getValue(self::CONFIG_DEFAULT_PRODUCT_TAX_CLASS);
    }

    /**
     * @param null $scopeCode
     *
     * @return string|null
     */
    public function isProductActivationEnabled($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IS_PRODUCT_ACTIVATION_ENABLED,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * @param null $scopeCode
     * @return string|null
     */
    public function getActivateProductsIncompleteSellers($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_ACTIVATE_PRODUCTS_INCOMPLETE_SELLERS,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * @param null $scopeCode
     * @return string|null
     */
    public function isVariantProductsUpdateIncluded($scopeCode = null)
    {
        return $this->getValue(self::INCLUDE_VARIANT_PRODUCT_IMPORT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }
}
