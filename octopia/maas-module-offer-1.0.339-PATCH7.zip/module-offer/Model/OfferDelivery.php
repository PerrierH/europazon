<?php

namespace Maas\Offer\Model;

use Maas\Offer\Api\Data\OfferDeliveryInterface;
use Magento\Framework\Model\AbstractModel;
use Maas\Offer\Model\ResourceModel\OfferDelivery as ResourceModel;

/**
 * Class OfferDelivery
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferDelivery extends AbstractModel implements OfferDeliveryInterface
{

    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @return int
     */
    public function getInventoryId()
    {
        return $this->_getData(self::INVENTORY_ID);
    }

    /**
     * @return string
     */
    public function getMode()
    {
        return $this->_getData(self::MODE);
    }

    /**
     * @return int
     */
    public function getMinDelay()
    {
        return $this->_getData(self::MIN_DELAY);
    }

    /**
     * @return int
     */
    public function getMaxDelay()
    {
        return $this->_getData(self::MAX_DELAY);
    }

    /**
     * @return float
     */
    public function getShippingCost()
    {
        return $this->_getData(self::SHIPPING_COST);
    }

    /**
     * @param int $inventoryId
     *
     * @return $this
     */
    public function setInventoryId($inventoryId)
    {
        return $this->setData(self::INVENTORY_ID, $inventoryId);
    }

    /**
     * @param string $mode
     *
     * @return $this
     */
    public function setMode($mode)
    {
        return $this->setData(self::MODE, $mode);
    }

    /**
     * @param int $minDelay
     *
     * @return $this
     */
    public function setMinDelay($minDelay)
    {
        return $this->setData(self::MIN_DELAY, $minDelay);
    }

    /**
     * @param int $maxDelay
     *
     * @return $this
     */
    public function setMaxDelay($maxDelay)
    {
        return $this->setData(self::MAX_DELAY, $maxDelay);
    }

    /**
     * @param float $shippingCost
     *
     * @return $this
     */
    public function setShippingCost($shippingCost)
    {
        return $this->setData(self::SHIPPING_COST, $shippingCost);
    }

    /**
     * @inheritDoc
     */
    public function getAdditionalShippingCost()
    {
        return $this->_getData(self::ADDITIONAL_SHIPPING_COST);
    }

    /**
     * @param float $additionalShippingCost
     *
     * @return $this
     */
    public function setAdditionalShippingCost($additionalShippingCost)
    {
        return $this->setData(self::ADDITIONAL_SHIPPING_COST, $additionalShippingCost);
    }
}
