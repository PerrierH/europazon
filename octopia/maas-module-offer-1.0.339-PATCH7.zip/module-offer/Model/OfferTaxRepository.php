<?php


namespace Maas\Offer\Model;


use Exception;
use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Api\Data\OfferTaxInterface;
use Maas\Offer\Api\Data\OfferTaxSearchResultsInterfaceFactory;
use Maas\Offer\Api\OfferTaxRepositoryInterface;
use Maas\Offer\Model\ResourceModel\OfferTax\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Class OfferTaxRepository
 *
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferTaxRepository extends AbstractRepository implements OfferTaxRepositoryInterface
{
    /**
     * @param OfferTaxInterface $offerTax
     *
     * @return OfferTaxInterface|void
     * @throws AlreadyExistsException
     */
    public function save(OfferTaxInterface $offerTax)
    {
        return $this->_save($offerTax);
    }

    /**
     * @param OfferTaxInterface $offerTax
     *
     * @throws Exception
     */
    public function delete(OfferTaxInterface $offerTax)
    {
        $this->_delete($offerTax);
    }
}
