<?php


namespace Maas\Offer\Model;


use Exception;
use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Api\Data\OfferDeliveryInterface;
use Maas\Offer\Api\Data\OfferDeliverySearchResultsInterfaceFactory;
use Maas\Offer\Api\OfferDeliveryRepositoryInterface;
use Maas\Offer\Model\ResourceModel\OfferDelivery\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Class OfferDeliveryRepository
 *
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferDeliveryRepository extends AbstractRepository implements OfferDeliveryRepositoryInterface
{
    /**
     * @param OfferDeliveryInterface $offerDelivery
     *
     * @return OfferDeliveryInterface|void
     * @throws AlreadyExistsException
     */
    public function save(OfferDeliveryInterface $offerDelivery)
    {
        return $this->_save($offerDelivery);
    }

    /**
     * @param OfferDeliveryInterface $offerDelivery
     *
     * @throws Exception
     */
    public function delete(OfferDeliveryInterface $offerDelivery)
    {
        $this->_delete($offerDelivery);
    }
}
