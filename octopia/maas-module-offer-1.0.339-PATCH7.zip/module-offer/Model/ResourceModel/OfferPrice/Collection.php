<?php

namespace Maas\Offer\Model\ResourceModel\OfferPrice;

use Maas\Offer\Model\OfferPrice as Model;
use Maas\Offer\Model\ResourceModel\OfferPrice as ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel\OfferPrice
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
