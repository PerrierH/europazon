<?php

namespace Maas\Offer\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class OfferDelivery
 *
 * @package Maas\Offer\Model\ResourceModel
 * @codeCoverageIgnore
 */
class OfferDelivery extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('maas_offer_delivery', 'entity_id');
    }
}
