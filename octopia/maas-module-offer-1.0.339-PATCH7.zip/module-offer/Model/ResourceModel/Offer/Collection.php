<?php

namespace Maas\Offer\Model\ResourceModel\Offer;

use Maas\Offer\Model\Offer as Model;
use Maas\Offer\Model\ResourceModel\Offer as ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel\Offer
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}