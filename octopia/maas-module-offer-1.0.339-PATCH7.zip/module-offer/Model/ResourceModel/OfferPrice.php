<?php

namespace Maas\Offer\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class OfferPrice
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel
 */
class OfferPrice extends AbstractDb
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('maas_offer_price', 'entity_id');
    }
}
