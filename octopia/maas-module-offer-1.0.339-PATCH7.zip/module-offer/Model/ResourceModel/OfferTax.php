<?php

namespace Maas\Offer\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class OfferTax
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel
 */
class OfferTax extends AbstractDb
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('maas_offer_tax', 'entity_id');
    }
}
