<?php

namespace Maas\Offer\Model\ResourceModel\OfferDelivery;

use Maas\Offer\Model\OfferDelivery as Model;
use Maas\Offer\Model\ResourceModel\OfferDelivery as ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel\OfferDelivery
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
