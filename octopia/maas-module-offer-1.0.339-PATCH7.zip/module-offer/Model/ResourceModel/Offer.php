<?php

namespace Maas\Offer\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Offer
 *
 * @package Maas\Offer\Model\ResourceModel
 * @codeCoverageIgnore
 */
class Offer extends AbstractDb
{
    /**
     * @var array
     */
    protected $preloadedStatuses = [];
    /**
     * @var array
     */
    protected $offersToPreload = [];

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('maas_offer', 'entity_id');
    }

    /**
     * @return $this
     */
    public function clearIdsToPreload()
    {
        $this->offersToPreload = [];
        $this->preloadedStatuses = [];
        return $this;
    }

    /**
     * @param string $maasEntityId
     *
     * @return $this
     */
    public function addEntityIdToPreload($maasEntityId)
    {
        $this->offersToPreload[] = $maasEntityId;
        $this->preloadedStatuses[$maasEntityId] = false;
        return $this;
    }

    /**
     * @return $this
     */
    public function preloadOffers()
    {
        $rows = $this->getOffersByMaasEntityId($this->offersToPreload);
        foreach ($rows as $entityId => $data) {
            $this->preloadedStatuses[$entityId] = $data;
        }
        return $this;
    }


    /**
     * @param $maasEntityId
     * @return array
     */
    public function offerExists($maasEntityId)
    {
        return $this->preloadedStatuses[$maasEntityId] ?? [];
    }
    /**
     * Get Offers ids by their maas entity id
     *
     * @param  array $offersList
     * @return array
     */
    public function getOffersByMaasEntityId(array $offersList)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable('maas_offer'),
            ['entity_id', 'sync_date', 'maas_entity_id', 'product_id', 'best_offer']
        )->where(
            'maas_entity_id IN (?)',
            $offersList
        );
        $rows = $this->getConnection()->fetchAll($select);
        $result = [];
        foreach ($rows as $row) {
            $result[$row['maas_entity_id']] = [
                'entity_id' => $row['entity_id'],
                'sync_date' => $row['sync_date'],
                'best_offer' => $row['best_offer'],
                'product_id' => $row['product_id'],
                'maas_entity_id' => $row['maas_entity_id'],
            ];
        }
        return $result;
    }

}