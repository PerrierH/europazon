<?php

namespace Maas\Offer\Model\ResourceModel;

use Maas\Log\Api\Data\ReportInterface;
use Zend_Db_Expr;
use Maas\Offer\Model\Config;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\App\ResourceConnection as Resource;
use Maas\Offer\Model\Service\BestOffer\TaxesInterface;
use Maas\Offer\Model\Service\BestOffer\DeliveriesInterface;
use Psr\Log\LogLevel;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class BestOffer
 * Allows retrieving data for best offer updates.
 *
 *
 * @package Maas\Offer\Model\ResourceModel
 */
class BestOffer
{
    /**
     * @var Config
     */
    protected $config;
    /**
     * @var DateTime
     */
    protected $dateTime;
    /**
     * @var TaxesInterface
     */
    protected $taxesInterface;
    /**
     * @var DeliveriesInterface
     */
    protected $deliveriesInterface;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * @param Config $config
     * @param DateTime $dateTime
     * @param Resource $resource
     * @param TaxesInterface $taxesInterface
     * @param DeliveriesInterface $deliveriesInterface
     * @param EditionInterface $edition
     */
    public function __construct(
        Config              $config,
        DateTime            $dateTime,
        Resource            $resource,
        TaxesInterface      $taxesInterface,
        DeliveriesInterface $deliveriesInterface,
        EditionInterface    $edition
    )
    {
        $this->resource = $resource;
        $this->config = $config;
        $this->dateTime = $dateTime;
        $this->taxesInterface = $taxesInterface;
        $this->deliveriesInterface = $deliveriesInterface;
        $this->edition = $edition;
    }

    /**
     * @param $offersRawData
     * @param $report
     * @return array
     */
    public function getOfferEntities($offersRawData, &$report)
    {
        $weeeData['entity_ids'] = [];
        $weeeData['rows'] = [];
        $offersData = [];

        /** init tax classes */
        $this->taxesInterface->init();
        $activateProduct = $this->config->isProductActivationEnabled();
        $isVariantsUpdateIncluded = $this->config->isVariantProductsUpdateIncluded();

        foreach ($offersRawData as &$offerData) {
            if ($offerData['rn'] == 1) {
                $this->deliveriesInterface->prepareDeliveriesData($offerData, $report);
                $taxes = $this->taxesInterface->prepareVatTaxData($offerData, $report);
                $this->taxesInterface->prepareWeeeTaxData($offerData, $weeeData, $taxes);
            } else {
                $report->setWarningItemsCount($report->getWarningItemsCount() + 1);
                $report->log(sprintf("product %s not updated with offer %s. offer best rank is no more valid",
                    $offerData['sku'], $offerData['maas_offer_id']), false, LogLevel::WARNING);
                $offerData = [];
            }

            if (!empty($offerData)) {
                $offersData[] = $offerData;
                
                if ($isVariantsUpdateIncluded) {
                    $this->pluginConfigurableUpdate($offersData, $report, $activateProduct);
                }
            }
        }
        unset($offersRawData);

        return ['offerData' => $offersData, 'weeeData' => $weeeData];
    }

    /**
     * @return array
     */
    public function collectOffersData(int $max = 0)
    {
        $linkField = $this->edition->getLinkField();
        $connection = $this->resource->getConnection();

        $select = $connection->select();
        $isVariantsUpdateIncluded = $this->config->isVariantProductsUpdateIncluded();

        $select->from(['maas_offer' => $this->resource->getTableName('maas_offer')], []);

        //Products conditions begin
        $productCond = 'maas_offer.product_id = catalog_product_entity.sku';
        $select->join(['catalog_product_entity' => $this->resource->getTableName('catalog_product_entity')], $productCond, []);
        //Products conditions end

        //Price conditions begin
        $priceCond = 'maas_offer.maas_entity_id = maas_offer_price.maas_entity_id AND maas_offer_price.price IS NOT NULL AND maas_offer_price.taxes IS NOT NULL';
        $select->join(['maas_offer_price' => $this->resource->getTableName('maas_offer_price')], $priceCond, []);
        //Price conditions end

        //Inventory conditions begin
        $inventoryCond = 'maas_offer.maas_entity_id = maas_offer_inventory.maas_entity_id AND maas_offer_inventory.stock IS NOT NULL AND maas_offer_inventory.deliveries IS NOT NULL';
        $select->join(['maas_offer_inventory' => $this->resource->getTableName('maas_offer_inventory')], $inventoryCond, []);
        $inventoryCond = 'maas_offer.product_id = inventory_reservation.sku';
        $select->joinLeft(['inventory_reservation' => $this->resource->getTableName('inventory_reservation')], $inventoryCond, []);
        //Inventory conditions end

        //Seller conditions begin ( We assume that all sellers are mapped to store_id 0)
        if ($this->config->getActivateProductsIncompleteSellers()) {
            $sellerLeftCond = "maas_offer.seller_id = maas_seller_entity.maas_entity_id";
            $select->joinLeft(['maas_seller_entity' => $this->resource->getTableName('maas_seller_entity')], $sellerLeftCond , []);
        }
        else {
            $sellerCond = "maas_offer.seller_id = maas_seller_entity.maas_entity_id AND maas_seller_entity.name IS NOT NULL AND maas_seller_entity.name <> ''";
            $select->join(['maas_seller_entity' => $this->resource->getTableName('maas_seller_entity')], $sellerCond , []);
        }
        $select->join(['eav_attr' => $this->resource->getTableName('eav_attribute')], "eav_attr.attribute_code = 'shipping_country'", []);
        $countryCond = "maas_seller_entity_varchar.entity_id = maas_seller_entity.entity_id AND (`maas_seller_entity_varchar`.`attribute_id` = eav_attr.attribute_id) AND (`maas_seller_entity_varchar`.`store_id` = 0)";
        $select->joinLeft(['maas_seller_entity_varchar', $this->resource->getTableName('maas_seller_entity_varchar')], $countryCond, []);
        //Seller conditions end

        //Product last update DateTime conditions begin ( We assume that all products are mapped to store_id 0)
        $select->join(['eav_attribute' => $this->resource->getTableName('eav_attribute')], "eav_attribute.attribute_code = 'maas_offer_updated_at'", []);
        $select->join(['eav_attribute_set', $this->resource->getTableName('eav_attribute_set')], 'eav_attribute_set.attribute_set_id = catalog_product_entity.attribute_set_id', []);
        $updatedCond = sprintf("catalog_product_entity_datetime.%s = catalog_product_entity.%s AND (`catalog_product_entity_datetime`.`attribute_id` = eav_attribute.attribute_id) AND (`catalog_product_entity_datetime`.`store_id` = 0)", $linkField, $linkField);
        $select->joinLeft(['catalog_product_entity_datetime', $this->resource->getTableName('catalog_product_entity_datetime')], $updatedCond, []);
        $select->where('catalog_product_entity_datetime.value < maas_offer.sync_date OR catalog_product_entity_datetime.value IS NULL');
        //Product last update DateTime conditions end

        if ($isVariantsUpdateIncluded) {
            //Associated configurable Products begin
            $select->joinLeft(['catalog_product_super_link' => $this->resource->getTableName('catalog_product_super_link')], 'catalog_product_super_link.product_id = catalog_product_entity.entity_id', []);
            $select->joinLeft(['catalog_product_entity2' => $this->resource->getTableName('catalog_product_entity')], sprintf('catalog_product_entity2.%s = catalog_product_super_link.parent_id', $linkField), []);
            //configurable Products end
        }
        $timeStamp = $this->dateTime->timestamp();
        $activateProduct = $this->config->isProductActivationEnabled();
        $columns = [
            //Product columns
            'sku' => "catalog_product_entity.sku",
            'attribute_set_code' => "eav_attribute_set.attribute_set_name",
            '_attribute_set' => "eav_attribute_set.attribute_set_name",
            'type_id' => "catalog_product_entity.type_id",
            'product_type' => "catalog_product_entity.type_id",

            'entity_id' => "catalog_product_entity.entity_id",
            'product_id' => sprintf("catalog_product_entity.%s", $linkField),

            'product_updated_at' => "catalog_product_entity_datetime.value",
            'status' => new Zend_Db_Expr($activateProduct ? Status::STATUS_ENABLED : "NULL"),
            'visibility' => new Zend_Db_Expr($activateProduct ? "'Catalog, Search'" : "NULL"),

            //Offer columns
            'rn' => new Zend_Db_Expr('row_number() over(partition by product_id order by `maas_offer`.`sync_date` DESC)'),
            'maas_offer_id' => "maas_offer.entity_id",
            'offer_product_id' => "maas_offer.product_id",
            'maas_offer_condition' => "maas_offer.condition",
            'maas_offer_sub_condition' => "IFNULL(maas_offer.sub_condition, '')",
            'maas_offer_condition_comment' => "IFNULL(maas_offer.comment, '')",
            'maas_offer_image' => "IFNULL(maas_offer.image, '')",
            'offer_best_offer' => "maas_offer.best_offer",
            'offer_seller_id' => "maas_offer.seller_id",
            'offer_quantity' => "maas_offer.quantity",
            'offer_sync_date' => "maas_offer.sync_date",
            'maas_warranty_duration' => "maas_offer.warranty_duration",
            'maas_offer_updated_at' => new Zend_Db_Expr($timeStamp),

            //Price columns
            'price' => "IF (maas_offer_price.original_price > maas_offer_price.price, maas_offer_price.original_price, maas_offer_price.price)",
            'special_price' => "maas_offer_price.price",
            //'special_from_date' => "maas_offer_price.start_date",
            //'special_to_date' => "maas_offer_price.end_date",

            'maas_currency' => "maas_offer_price.currency",
            //'maas_discount_id' => "IFNULL(maas_offer_price.discount_id, '')",
            'tax_class_id' => new Zend_Db_Expr('NULL'),
            'maas_origin_price' => "IF(maas_offer_price.original_price > 0, maas_offer_price.original_price, '')",
            'maas_original_taxes' => "maas_offer_price.taxes",

            //Inventory columns
            'qty' => new Zend_Db_Expr("(CASE WHEN maas_offer_inventory.stock - IFNULL(SUM(inventory_reservation.quantity), 0) > 0 THEN maas_offer_inventory.stock - IFNULL(SUM(inventory_reservation.quantity), 0) ELSE 0 END)"),
            'reserved_qty' => "IFNULL(SUM(inventory_reservation.quantity), 0)",
            'is_in_stock' =>new Zend_Db_Expr("(CASE WHEN maas_offer_inventory.stock - IFNULL(SUM(inventory_reservation.quantity), 0) > 0 THEN 1 ELSE 0 END)"),

            'maas_supply_mode' => "maas_offer_inventory.supply_mode",
            'maas_original_deliveries' => "maas_offer_inventory.deliveries",

            //Seller columns
            'maas_offer_seller_id' => "maas_seller_entity.entity_id",
            'maas_offer_seller_name' => "IFNULL(maas_seller_entity.name, '')",
            'maas_shipping_country' => "maas_seller_entity_varchar.value",
            'seller_maas_entity_id' => "maas_seller_entity.maas_entity_id",
            'maas_offer_seller_front_name' => "IFNULL(maas_seller_entity.name, '')"
        ];
        if ($isVariantsUpdateIncluded) {
            $columns = array_merge($columns, [
                'parent_product_id' => "IFNULL(catalog_product_super_link.parent_id, '')",
                'parent_sku' => "IFNULL(catalog_product_entity2.sku, '')",
                'visibility' => new Zend_Db_Expr($activateProduct ? "IF (IFNULL(catalog_product_super_link.parent_id, '') <> '', 'Not Visible Individually', 'Catalog, Search')" : "NULL"),
            ]);
        }
        $select->columns($columns);

        $select->where("maas_offer.best_offer = 1 AND IFNULL(maas_offer.maas_entity_id, '') <> ''");
        $select->group(new Zend_Db_Expr('sku, offer_sync_date'));

        //most recent offer
        $select->order(new Zend_Db_Expr("sku ASC, offer_sync_date DESC"));

        if ($max) {
            $select->limitPage(0, $max);
        }
        return $connection->fetchAll($select);
    }

    /**
     * @param array $offersData
     * @param ReportInterface $report
     * @param ?string $activateProduct
     */
    private function pluginConfigurableUpdate(array &$offersData, ReportInterface &$report, ?string $activateProduct)
    {
        $offerData = end($offersData);
        if (!empty($offerData['parent_product_id'])) {
            // Plug-in potential configurable
            if (!in_array($offerData['parent_sku'], array_column($offersData, 'sku'))) {
                $offersData[] = [
                    'sku' => $offerData['parent_sku'],
                    'attribute_set_code' => $offerData['attribute_set_code'],
                    '_attribute_set' => $offerData['_attribute_set'],
                    'product_type' => 'configurable',
                    'status' => $offerData['status'],
                    'visibility' => $activateProduct ? 'Catalog, Search' : null,
                    'is_in_stock' => '1',
                ];
                $report->setItemsCount($report->getItemsCount() + 1);
                $report->log(sprintf("configurable product %s was updated",
                    $offerData['parent_sku']), false, LogLevel::DEBUG);
            }
        }
    }
}
