<?php


namespace Maas\Offer\Model\ResourceModel;


use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class OfferInventory
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel
 */
class OfferInventory extends AbstractDb
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('maas_offer_inventory', 'entity_id');
    }
}
