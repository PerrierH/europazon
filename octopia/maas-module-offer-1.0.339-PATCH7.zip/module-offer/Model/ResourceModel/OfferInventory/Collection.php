<?php

namespace Maas\Offer\Model\ResourceModel\OfferInventory;

use Maas\Offer\Model\OfferInventory as Model;
use Maas\Offer\Model\ResourceModel\OfferInventory as ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @codeCoverageIgnore
 * @package Maas\Offer\Model\ResourceModel\OfferInventory
 */
class Collection extends AbstractCollection
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
