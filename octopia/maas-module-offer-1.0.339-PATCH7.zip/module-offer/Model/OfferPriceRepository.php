<?php


namespace Maas\Offer\Model;


use Exception;
use Maas\Core\Model\AbstractRepository;
use Maas\Offer\Api\Data\OfferPriceInterface;
use Maas\Offer\Api\Data\OfferPriceSearchResultsInterfaceFactory;
use Maas\Offer\Api\OfferPriceRepositoryInterface;
use Maas\Offer\Model\ResourceModel\OfferPrice\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Class OfferPriceRepository
 *
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferPriceRepository extends AbstractRepository implements OfferPriceRepositoryInterface
{
    /**
     * @param OfferPriceInterface $offerPrice
     *
     * @return OfferPriceInterface|void
     * @throws AlreadyExistsException
     */
    public function save(OfferPriceInterface $offerPrice)
    {
        return $this->_save($offerPrice);
    }

    /**
     * @param OfferPriceInterface $offerPrice
     *
     * @throws Exception
     */
    public function delete(OfferPriceInterface $offerPrice)
    {
        $this->_delete($offerPrice);
    }
}
