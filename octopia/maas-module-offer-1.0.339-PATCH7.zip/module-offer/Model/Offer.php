<?php

namespace Maas\Offer\Model;

use DateTime;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Model\ResourceModel\Offer as ResourceModel;
use Magento\Framework\Model\AbstractModel;

/**
 * Class Offer
 *
 * @package Maas\Offer\Model
 * @codeCoverageIgnore
 */
class Offer extends AbstractModel implements OfferInterface
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @return int|null
     */
    public function getMaasEntityId()
    {
        return $this->_getData(self::MAAS_ENTITY_ID);
    }

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setMaasEntityId($id)
    {
        return $this->setData(self::MAAS_ENTITY_ID, $id);
    }

    /**
     * @return int|null
     */
    public function getSellerId()
    {
        return $this->_getData(self::SELLER_ID);
    }

    /**
     * @param int $sellerId
     *
     * @return $this
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * @return int|mixed|null
     */
    public function getQuantity()
    {
        return $this->_getData(self::QUANTITY);
    }

    /**
     * @param int $quantity
     *
     * @return $this
     */
    public function setQuantity($quantity)
    {
        return $this->setData(self::QUANTITY, $quantity);
    }

    /**
     * @return mixed|string|null
     */
    public function getProductId()
    {
        return $this->_getData(self::PRODUCT_ID);
    }

    /**
     * @param string $productId
     *
     * @return $this
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * @return mixed|string|null
     */
    public function getCondition()
    {
        return $this->_getData(self::CONDITION);
    }

    /**
     * @param string $condition
     *
     * @return $this
     */
    public function setCondition($condition)
    {
        return $this->setData(self::CONDITION, $condition);
    }

    /**
     * @return mixed|string|null
     */
    public function getSubCondition()
    {
        return $this->_getData(self::SUB_CONDITION);
    }

    /**
     * @param string $subCondition
     *
     * @return $this
     */
    public function setSubCondition($subCondition)
    {
        return $this->setData(self::SUB_CONDITION, $subCondition);
    }

    /**
     * @return mixed|string|null
     */
    public function getComment()
    {
        return $this->_getData(self::COMMENT);
    }

    /**
     * @param string $comment
     *
     * @return $this
     */
    public function setComment($comment)
    {
        return $this->setData(self::COMMENT, $comment);
    }

    /**
     * @return mixed|string|null
     */
    public function getBestOffer()
    {
        return $this->_getData(self::BEST_OFFER);
    }

    /**
     * @param string $bestOfferRank
     *
     * @return $this
     */
    public function setBestOffer($bestOfferRank)
    {
        return $this->setData(self::BEST_OFFER, $bestOfferRank);
    }

    /**
     * @return mixed|string|null
     */
    public function getImage()
    {
        return $this->_getData(self::IMAGE);
    }

    /**
     * @param string $image
     *
     * @return $this
     */
    public function setImage($image)
    {
        return $this->setData(self::IMAGE, $image);
    }

    /**
     * @return DateTime|mixed|null
     */
    public function getSyncDate()
    {
        return $this->_getData(self::SYNC_DATE);
    }

    /**
     * @param DateTime $syncDate
     *
     * @return $this
     */
    public function setSyncDate($syncDate)
    {
        return $this->setData(self::SYNC_DATE, $syncDate);
    }

    /**
     * @return string|null
     */
    public function getWarrantyDuration()
    {
        return $this->_getData(self::WARRANTY_DURATION);
    }

    /**
     * @param $warrantyDuration
     *
     * @return $this
     */
    public function setWarrantyDuration($warrantyDuration)
    {
        return $this->setData(self::WARRANTY_DURATION, $warrantyDuration);
    }
}
