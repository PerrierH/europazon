<?php

namespace Maas\Offer\Model;

use Exception;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\Log\Model\Report;

/**
 * Class BestOffer
 *
 * @package Maas\ImportExport\Model\Import\Offer
 */
class BestOffer extends AbstractImportExportApi
{
    public const MAAS_LOG_ACTION = 'Update_Best_Offer';

    public const MAAS_LOG_MODULE = 'Maas_Offer';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_IMPORT;

    public const CSV_LOG_HEADERS = ['date', 'report_id', 'operation', 'count', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'import-update-bestoffer';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_offer_bestoffer_update_report_id';


    /**
     * @param array|null $args
     * @return Report
     * @throws Exception
     */
    public function startImportBestOffers(array $args = null)
    {
        return $this->startProcess($args);
    }

    public function endImportBestOffer()
    {
        $reportId = $this->loadReportIdFromCache();
        if (!$reportId) {
            return;
        }
        $report = $this->reportRepository->get($reportId);

        $result = [
            'itemsCount' => $report->getItemsCount(),
            'successItemsCount' => $report->getSuccessItemsCount(),
            'warningItemsCount' => $report->getWarningItemsCount()
        ];
        $this->endLog($result);
    }

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return '';
    }
}
