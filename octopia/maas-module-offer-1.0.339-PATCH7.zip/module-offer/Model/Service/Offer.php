<?php

namespace Maas\Offer\Model\Service;

use Maas\Offer\Api\OfferRepositoryInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class Offer
 *
 * @package Maas\Offer\Model\Service
 *
 * @codeCoverageIgnore
 */
class Offer
{


    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;
    /**
     * @var OfferRepositoryInterface
     */
    protected $offerRepository;

    /**
     * Offer constructor.
     *
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OfferRepositoryInterface $offerRepository
     */
    public function __construct(
        FilterBuilder $filterBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        OfferRepositoryInterface $offerRepository
    ){
        $this->filterBuilder = $filterBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->offerRepository = $offerRepository;
    }

    /**
     * @param $value
     *
     * @return \Maas\Offer\Api\Data\OfferInterface|null
     */
    public function getOfferById($value)
    {
        $filter = $this->filterBuilder
            ->setField('maas_entity_id')
            ->setConditionType('eq')
            ->setValue($value)
            ->create();
        $this->searchCriteriaBuilder->addFilters([$filter]);
        $searchCriteria = $this->searchCriteriaBuilder->create();
        $offerArray = $this->offerRepository->getList($searchCriteria)->getItems();
        if(count($offerArray) == 0){
            return null;
        }
        return array_pop($offerArray);
    }


}
