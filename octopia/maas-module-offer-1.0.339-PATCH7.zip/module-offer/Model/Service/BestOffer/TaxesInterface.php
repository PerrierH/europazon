<?php

namespace Maas\Offer\Model\Service\BestOffer;


interface TaxesInterface
{
    /**
     * @param $offerData
     * @param $report
     * @return mixed
     */
    public function prepareVatTaxData(&$offerData, &$report);

    /**
     * @param $offerData
     * @param $weeeData
     * @return mixed
     */
    public function prepareWeeeTaxData($offerData, &$weeeData, $taxes);
}
