<?php

namespace Maas\Offer\Model\Service\BestOffer\Taxes;

use Maas\Offer\Model\Service\BestOffer\TaxesInterface;
use Magento\Catalog\Model\Product;
use Maas\Catalog\Model\Config as CatalogConfig;
use Magento\Eav\Model\ResourceModel\Entity\Attribute;
use Magento\Tax\Model\ResourceModel\TaxClass\CollectionFactory as TaxCollection;
use Psr\Log\LogLevel;
use Zend_Db_Expr;

class Taxes implements TaxesInterface
{
    /**
     * @var array
     */
    protected $taxClasses;
    /**
     * @var array
     */
    protected $weeeTaxAttributes;
    /**
     * @var string|null
     */
    protected $country;
    /**
     * @var string|null
     */
    protected $region;
    /**
     * @var CatalogConfig
     */
    protected $catalogConfig;
    /**
     * @var Attribute
     */
    protected $eavAttribute;

    /**
     * @var TaxCollection
     */
    protected $taxClass;

    /**
     * @param Attribute $eavAttribute
     * @param TaxCollection $taxClass
     * @param CatalogConfig $catalogConfig
     */
    public function __construct(
        Attribute $eavAttribute,
        TaxCollection $taxClass,
        CatalogConfig $catalogConfig
    )
    {
        $this->taxClass = $taxClass;
        $this->eavAttribute = $eavAttribute;
        $this->catalogConfig = $catalogConfig;

    }

    public function init() {
        $this->taxClasses = $this->initMaasTaxClasses($this->taxClass);
        $this->weeeTaxAttributes = $this->getWeeeTaxAttributes();
        $this->country = $this->catalogConfig->getDefaultCountry();
        $this->region = $this->catalogConfig->getDefaultRegion();
    }

    /**
     * @param $offerData
     * @param $report
     * @return array|mixed
     */
    public function prepareVatTaxData(&$offerData, &$report)
    {
        $taxes = [];
        if ($offerData) {
            $str = '';
            $taxes = json_decode($offerData['maas_original_taxes'] ?? '', true);
            $j = 0;
            foreach ($taxes as $tax) {
                if (strtolower($tax['code']) == 'vat') {
                    if (strtolower($tax['type']) == 'rate') {
                        $taxValue = (int)($tax['value'] * 100);
                        $str = "Maas_Product_tax_vat_" . $taxValue;
                        $offerData['tax_class_id'] = array_search($str, $this->taxClasses) ?? null;
                    }
                    elseif (strtolower($tax['type']) == 'amount') {
                        $offerData['tax_class_id'] = null;
                    }
                    //if no tax_class_id
                    if (empty($offerData['tax_class_id'])) {
                        $report->setWarningItemsCount($report->getWarningItemsCount() + 1);
                        $report->log(sprintf("product %s not updated with offer %s. Tax class %s must be configured",
                            $offerData['sku'], $offerData['maas_offer_id'], $str), false, LogLevel::WARNING);

                        $offerData = [];
                    }
                    unset($taxes[$j]);
                    break;
                }
                $j++;
            }
        }

        return $taxes;
    }

    /**
     * @param $offerData
     * @param $weeeData
     * @param $taxes
     * @return mixed|void
     */
    public function prepareWeeeTaxData($offerData, &$weeeData, $taxes)
    {
        if ($offerData && count($taxes)) {
            foreach ($this->weeeTaxAttributes as $weeeTaxAttrId => $weeeTaxAttrCode) {
                foreach ($taxes as $tax) {
                    if ($weeeTaxAttrCode == "maas_" . strtolower($tax['code'])) {
                        $taxValue = null;
                        if (strtolower($tax['type']) == 'rate') {
                            $taxValue =  ($offerData['special_price'] ?? $offerData['price']) * $tax['value'];
                        } elseif (strtolower($tax['type']) == 'amount') {
                            $taxValue = $tax['value'];
                        }
                        if ($taxValue) {
                            $weeeData['rows'][] =
                                [
                                    'website_id' => new Zend_Db_Expr('0'),
                                    'entity_id' => new Zend_Db_Expr($offerData['entity_id']),
                                    'country' => new Zend_Db_Expr("'" . $this->country . "'"),
                                    'value' => new Zend_Db_Expr($taxValue),
                                    'state' => new Zend_Db_Expr($this->region),
                                    'attribute_id' => new Zend_Db_Expr($weeeTaxAttrId)
                                ];
                        }
                        break;
                    }
                }
            }
            $weeeData['entity_ids'][] = $offerData['entity_id'];
        }
    }

    /**
     * @param $taxClass
     * @return array
     */
    private function initMaasTaxClasses($taxClass)
    {
        $result = [];
        $collection = $taxClass->create()
            ->addFieldToSelect('class_id')
            ->addFieldToSelect('class_name')
            ->addFieldToFilter('class_name', ['like' => 'Maas%'])
            ->addFieldToFilter('class_type', 'PRODUCT');

        foreach ($collection->getData() as $item){
            $result[$item['class_id']] = $item['class_name'];
        }

        return $result;
    }

    /**
     * @return array
     */
    private function getWeeeTaxAttributes()
    {
        $result = [];
        foreach($this->catalogConfig->getTaxCategoriesCodes() as $weeeTaxAttributeCode){
            $weeeTaxAttributeId = $this->eavAttribute->getIdByCode(Product::ENTITY, $weeeTaxAttributeCode);
            if ($weeeTaxAttributeId) {
                $result[$weeeTaxAttributeId] = $weeeTaxAttributeCode;
            }
        }
        return $result;
    }
}
