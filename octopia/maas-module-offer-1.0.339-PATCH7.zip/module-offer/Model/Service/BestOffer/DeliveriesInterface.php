<?php

namespace Maas\Offer\Model\Service\BestOffer;


interface DeliveriesInterface
{
    /**
     * @param $offerData
     * @param $report
     * @return mixed
     */
    public function prepareDeliveriesData(&$offerData, &$report);
}
