<?php

namespace Maas\Offer\Model\Service\BestOffer;

use Maas\Core\Model\Import\ProductFactory;
use Maas\Log\Api\Data\ReportInterface;
use Magento\CatalogImportExport\Model\Import\Product;
use Magento\Framework\Exception\ValidatorException;
use Magento\ImportExport\Model\Import;
use Magento\ImportExport\Model\ResourceModel\Import\Data;
use Magento\Framework\App\ResourceConnection as Resource;
use Magento\Framework\Event\ManagerInterface as EventManager;


/**
 * Class ProductUpdate
 * @codeCoverageIgnore No need to test only calling standard functions
 * @package Maas\Offer\Model\Service\BestOffer
 */
class ProductUpdate
{
    const ENTITY = 'maas_bestoffer_update';
    /**
     * @var ProductFactory
     */
    private ProductFactory $importProductFactory;

    /**
     * @var Product|null
     */
    private ?Product $importProduct = null;

    /**
     * @var Data
     */
    private Data $productData;

    /**
     * @var Resource
     */
    private Resource $resource;

    /**
     * @var EventManager
     */
    private $eventManager;

    /**
     * @param ProductFactory $importProductFactory
     * @param Data $productData
     * @param Resource $resource
     * @param EventManager $eventManager
     */
    public function __construct(
        ProductFactory $importProductFactory,
        Data $productData,
        Resource $resource,
        EventManager $eventManager
    ) {
        $this->importProductFactory = $importProductFactory;
        $this->productData = $productData;
        $this->resource = $resource;
        $this->eventManager = $eventManager;
    }

    /**
     * @param array $data
     * @param ReportInterface $report
     * @throws ValidatorException
     */
    public function saveProductData(array $data, ReportInterface &$report)
    {
        $this->productData->cleanBunches();
        $this->productData->saveBunch(self::ENTITY, Import::BEHAVIOR_APPEND, $data['offerData']);
        if (!$this->importProduct) {
            $this->importProduct = $this->importProductFactory->create();
        }
        $this->importProduct->importData();
        $this->updateProductWeeeTaxes($data['weeeData']);

        $this->eventManager->dispatch('maas_products_attributes_update_after_save',
            ['ids' => array_column($data['offerData'], 'product_id')]);

        $this->logImportResult($report);
    }

    /**
     * @param $data
     */
    private function updateProductWeeeTaxes($data)
    {
        if (count($data['rows'])) {
            $connection = $this->resource->getConnection();
            //must delete all products related weeetaxes
            $connection->delete($connection->getTableName('weee_tax'), "website_id = '0' AND entity_id IN (". implode(',', $data['entity_ids']) . ")");
            $connection->insertMultiple($connection->getTableName('weee_tax'), $data['rows']);
        }
    }

    /**
     * @param ReportInterface $report
     */
    private function logImportResult(ReportInterface &$report)
    {
        $successItemCount = $this->importProduct->getUpdatedItemsCount();
        if ($successItemCount) {
            $report->setSuccessItemsCount($this->importProduct->getUpdatedItemsCount());
        }
        $errorItemCount = $this->importProduct->getErrorAggregator()->getErrorsCount();
        if ($errorItemCount) {
            $report->setErrorItemsCount($errorItemCount);
            $errorStrings = [];
            foreach ($this->importProduct->getErrorAggregator()->getAllErrors() as $error) {
                $errorStrings[] = sprintf("%s at %s : %s, %s",
                    $error->getErrorCode(), $error->getRowNumber(), $error->getErrorMessage(), $error->getColumnName()
                );
            }
            if (count($errorStrings)) {
                $report->log(sprintf("Magento product import finished with errors: \n - %s",
                    implode("\n - ", $errorStrings)));
            }
        }
    }
}
