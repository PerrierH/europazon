<?php

namespace Maas\Offer\Model\Service\BestOffer\Deliveries;

use Maas\Offer\Model\Service\BestOffer\DeliveriesInterface;
use Psr\Log\LogLevel;


class Deliveries implements DeliveriesInterface
{
    const MAAS_DELIVERY_MODES = ['EHD' => 'express', 'THD' => 'standard'];

    /**
     * @param $offerData
     * @param $report
     * @return void
     */
    public function prepareDeliveriesData(&$offerData, &$report)
    {
        if ($offerData) {
            $deliveries = json_decode($offerData['maas_original_deliveries'] ?? '', true);
            $initialCount = count($offerData);
            foreach ($deliveries as $delivery) {
                if (!empty($delivery['mode']) && array_key_exists($delivery['mode'],self::MAAS_DELIVERY_MODES)) {
                    
                    if (!empty($delivery['min_delay'])
                        && !empty($delivery['max_delay'])
                        && isset($delivery['shipping_cost'])
                        && $delivery['min_delay'] > 0
                        && $delivery['max_delay'] > 0
                        && $delivery['shipping_cost'] >= 0
                    ) {
                        $mode = self::MAAS_DELIVERY_MODES[$delivery['mode']];
                        
                        $offerData[sprintf('maas_delivery_%s_min', $mode)] = $delivery['min_delay'];
                        $offerData[sprintf('maas_delivery_%s_max', $mode)] = $delivery['max_delay'];
                        $offerData[sprintf('maas_delivery_%s_cost', $mode)] = $delivery['shipping_cost'];

                        if (isset($delivery['additional_shipping_cost'])) {
                            
                            if ($delivery['additional_shipping_cost'] >= 0) {
                                $offerData[sprintf('maas_delivery_%s_acost', $mode)] =
                                    $delivery['additional_shipping_cost'];
                            }
                            else {
                                unset(
                                    $offerData[sprintf('maas_delivery_%s_min', $mode)],
                                    $offerData[sprintf('maas_delivery_%s_max', $mode)],
                                    $offerData[sprintf('maas_delivery_%s_cost', $mode)]
                                );
                                
                                $report->setWarningItemsCount($report->getWarningItemsCount() + 1);
                                $report->log(
                                    sprintf("product %s not updated with offer %s. No valid delivery additional_cost value %s",
                                    $offerData['sku'], $offerData['maas_offer_id'], $delivery['additional_shipping_cost']),
                                    false, LogLevel::WARNING
                                );
                            }
                        }
                    }
                    else {
                        $report->setWarningItemsCount($report->getWarningItemsCount() + 1);
                        $report->log(
                            sprintf("product %s not updated with offer %s. No valid delivery data",
                            $offerData['sku'], $offerData['maas_offer_id']), false, LogLevel::WARNING
                        );
                    }
                }
                else {
                    $report->setWarningItemsCount($report->getWarningItemsCount() + 1);
                    $report->log(
                        sprintf("product %s not updated with offer %s. No valid delivery mode",
                        $offerData['sku'], $offerData['maas_offer_id']), false, LogLevel::WARNING
                    );
                }
            }

            //if no deliveries
            if (count($offerData) == $initialCount) {
                $offerData = [];
            }
        }
    }
}
