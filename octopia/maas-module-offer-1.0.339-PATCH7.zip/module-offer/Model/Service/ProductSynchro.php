<?php

namespace Maas\Offer\Model\Service;

use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;

/**
 * Class ProductSynchro
 *
 * @package Maas\Offer\Model\Service
 */
class ProductSynchro
{
    const STATUS_ACTIVE = 'active';

    private $productRepository;
    /**
     * @var OfferRepositoryInterface
     */
    private $offerRepository;


    /**
     * @param ProductRepositoryInterface $productRepository
     * @param OfferRepositoryInterface $offerRepository
     */
    public function __construct(
        ProductRepositoryInterface $productRepository,
        OfferRepositoryInterface $offerRepository
    ) {
        $this->productRepository = $productRepository;
        $this->offerRepository = $offerRepository;
    }

    /**
     * @param OfferInterface|false $offer
     *
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws StateException
     */
    public function shouldDeleteOffer($offer)
    {
        $product = $this->getProduct($offer);
        if (!empty($product)) {
            $this->setProductOutOfStock($product);
        }
        $this->offerRepository->delete($offer);
    }

    /**
     * @param OfferInterface $offer
     *
     * @return ProductInterface|null
     */
    private function getProduct(OfferInterface $offer)
    {
        try {
            return $this->productRepository->get($offer->getProductId());
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }

    /**
     * @param ProductInterface $product
     *
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws StateException
     */
    private function setProductOutOfStock(ProductInterface $product)
    {
        $attributes = $product->getExtensionAttributes();
        $stockItem = $attributes->getStockItem();
        $stockItem->setQty(0);
        $stockItem->setIsInStock(false);
        $attributes->setStockItem($stockItem);
        $product->setExtensionAttributes($attributes);
        $this->productRepository->save($product);
    }
}
