<?php

namespace Maas\Offer\Model;

use Maas\Offer\Api\Data\OfferPriceInterface;
use Maas\Offer\Model\ResourceModel\OfferPrice as ResourceModel;
use Magento\Framework\Model\AbstractModel;

/**
 * Class OfferPrice
 * @codeCoverageIgnore
 * @package Maas\Offer\Model
 */
class OfferPrice extends AbstractModel implements OfferPriceInterface
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @return string|null
     */
    public function getMaasEntityId()
    {
        return $this->_getData(self::MAAS_ENTITY_ID);
    }

    /**
     * @return float|null
     */
    public function getPrice()
    {
        return $this->_getData(self::PRICE);
    }

    /**
     * @return string|null
     */
    public function getCurrency()
    {
        return $this->_getData(self::CURRENCY);
    }

    /**
     * @return float|null
     */
    public function getOriginalPrice()
    {
        return $this->_getData(self::ORIGINAL_PRICE);
    }

    /**
     * @return string|null
     */
    public function getStartDate()
    {
        return $this->_getData(self::START_DATE);
    }

    /**
     * @return string|null
     */
    public function getEndDate()
    {
        return $this->_getData(self::END_DATE);
    }

    /**
     * @return string|null
     */
    public function getDiscountId()
    {
        return $this->_getData(self::DISCOUNT_ID);
    }

    /**
     * @return string|null
     */
    public function getSyncDate()
    {
        return $this->_getData(self::SYNC_DATE);
    }

    /**
     * @return string|null
     */
    public function getTaxes()
    {
        return $this->_getData(self::TAXES);
    }

    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setMaasEntityId($offerId)
    {
        return $this->setData(self::MAAS_ENTITY_ID, $offerId);
    }

    /**
     * @param float $price
     *
     * @return $this
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * @param string $currency
     *
     * @return $this
     */
    public function setCurrency($currency)
    {
        return $this->setData(self::CURRENCY, $currency);
    }

    /**
     * @param float $originalPrice
     *
     * @return $this
     */
    public function setOriginalPrice($originalPrice)
    {
        return $this->setData(self::ORIGINAL_PRICE, $originalPrice);
    }
    /**
     * @param string $startDate
     *
     * @return $this
     */
    public function setStartDate($startDate)
    {
        return $this->setData(self::START_DATE, $startDate);
    }

    /**
     * @param string $endDate
     *
     * @return $this
     */
    public function setEndDate($endDate)
    {
        return $this->setData(self::END_DATE, $endDate);
    }

    /**
     * @param string $discountId
     *
     * @return $this
     */
    public function setDiscountId($discountId)
    {
        return $this->setData(self::DISCOUNT_ID, $discountId);
    }

    /**
     * @param string $syncDate
     *
     * @return $this
     */
    public function setSyncDate($syncDate)
    {
        return $this->setData(self::SYNC_DATE, $syncDate);
    }

    /**
     * @param string $taxes
     *
     * @return $this
     */
    public function setTaxes($taxes)
    {
        return $this->setData(self::TAXES, $taxes);
    }
}
