<?php


namespace Maas\Offer\Model;


use DateTime;
use Maas\Offer\Api\Data\OfferInventoryInterface;
use Magento\Framework\Model\AbstractModel;
use Maas\Offer\Model\ResourceModel\OfferInventory as ResourceModel;

/**
 * Class OfferInventory
 * @codeCoverageIgnore 
 * @package Maas\Offer\Model
 */
class OfferInventory extends AbstractModel implements OfferInventoryInterface
{

    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }


    /**
     * @return string
     */
    public function getMaasEntityId()
    {
        return $this->_getData(self::MAAS_ENTITY_ID);
    }

    /**
     * @return string
     */
    public function getStock()
    {
        return $this->_getData(self::STOCK);
    }

    /**
     * @return string
     */
    public function getSupplyMode()
    {
        return $this->_getData(self::SUPPLY_MODE);
    }

    /**
     * @return DateTime
     */
    public function getSyncDate()
    {
        return $this->_getData(self::SYNC_DATE);
    }

    /**
     * @return string
     */
    public function getDeliveries()
    {
        return $this->_getData(self::DELIVERIES);
    }

    /**
     * @param string $maasEntityId
     *
     * @return $this
     */
    public function setMaasEntityId($maasEntityId)
    {
        return $this->setData(self::MAAS_ENTITY_ID, $maasEntityId);
    }

    /**
     * @param string $stock
     *
     * @return $this
     */
    public function setStock($stock)
    {
        return $this->setData(self::STOCK, $stock);
    }

    /**
     * @param string $supplyMode
     *
     * @return $this
     */
    public function setSupplyMode($supplyMode)
    {
        return $this->setData(self::SUPPLY_MODE, $supplyMode);
    }

    /**
     * @param DateTime $synDate
     *
     * @return $this
     */
    public function setSyncDate($synDate)
    {
        return $this->setData(self::SYNC_DATE, $synDate);
    }

    /**
     * @param string $deliveries
     *
     * @return $this
     */
    public function setDeliveries($deliveries)
    {
        return $this->setData(self::DELIVERIES, $deliveries);
    }
}
