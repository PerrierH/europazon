<?php

namespace Maas\Offer\Test\Builder;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Model\Offer;
use Maas\Sales\Model\Session;
use PHPUnit_Framework_MockObject_MockObject;

class OfferBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];
        return $this->createMock($this->getClassToInstantiate(OfferInterface::class, Offer::class), $defaultData);
    }
}