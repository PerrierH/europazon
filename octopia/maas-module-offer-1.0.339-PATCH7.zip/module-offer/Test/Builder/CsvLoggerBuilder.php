<?php

namespace Maas\Offer\Test\Builder;

use Maas\Core\Test\Builder\BuilderInterface;
use Maas\Core\Test\Builder\BuilderTrait;
use Maas\Log\Model\Csv;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class CsvLoggerBuilder
 *
 * @package Maas\Offer\Test\Builder
 */
class CsvLoggerBuilder implements BuilderInterface
{
    use BuilderTrait;

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function build()
    {
        $defaultData = [

        ];
        $this->setCreateAsFullMock(true);
        return $this->createMock($this->getClassToInstantiate(Csv::class, Csv::class), $defaultData);
    }
}
