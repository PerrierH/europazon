<?php

namespace Maas\Offer\Test\Implementation;

use Maas\Offer\Model\Service\BestOffer\Data\DTO;
use Maas\Offer\Model\Service\BestOffer\Transducer\AbstractDTOStep;

/**
 * Class DTOStepForTests
 *
 * @package Maas\Offer\Test\Implementation
 */
class DTOStepForTests extends AbstractDTOStep
{
    /**
     * @param bool $compareDates
     * @param string $productUpdatedAtAttribute
     * @param string $entityGetter
     * @param string $entityPropertyGetter
     */
    public function setProperties($compareDates, $productUpdatedAtAttribute, $entityGetter, $entityPropertyGetter)
    {
        $this->compareDates = $compareDates;
        $this->productUpdatedAtAttribute = $productUpdatedAtAttribute;
        $this->entityGetter = $entityGetter;
        $this->entityPropertyGetter = $entityPropertyGetter;
    }

    /**
     * @inheritDoc
     */
    protected function update(DTO $item)
    {
    }

    /**
     * @inheritDoc
     */
    protected function getLogPrefix()
    {
        return 'DTO Test Step';
    }
}
