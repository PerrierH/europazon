<?php

namespace Maas\Offer\Test\Unit\Plugin;

use Maas\Core\Test\Builder\AnyBuilder;
use PHPUnit\Framework\TestCase;
use Maas\Offer\Plugin\AllowTimestampsForOfferSyncDates;
use Magento\CatalogImportExport\Model\Import\Product\Validator;

class AllowTimestampsForOfferSyncDatesTest extends TestCase
{
    /**
     * @var AllowTimestampsForOfferSyncDates
     */
    private $stub;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $subject;

    public function setUp()
    {
        $this->subject = AnyBuilder::createForClass($this, Validator::class)->build();
        $this->stub = new AllowTimestampsForOfferSyncDates();
    }

    public function testInArrayAttribute()
    {
        $attrCode = 'maas_offer_updated_at';
        $rowData = ['maas_offer_updated_at' => 6];
        $closure = function () {
            return true;
        };
        $retunTrue = $this->stub->aroundIsAttributeValid(
            $this->subject,
            $closure,
            $attrCode,
            [],
            $rowData
        );
        $this->assertTrue($retunTrue, 'should return a boolean true');
    }

    /**
     * @dataProvider getConditions
     */
    public function testNotInArrayAttribute($attributeCode, $rowDataValue)
    {
        $rowData = [$attributeCode => $rowDataValue];
        $closure = function () {
            return false;
        };
        $retunFalse = $this->stub->aroundIsAttributeValid(
            $this->subject,
            $closure,
            $attributeCode,
            [],
            $rowData
        );
        $this->assertFalse($retunFalse, 'should return a boolean false from closure');
    }

    public function getConditions()
    {
        yield from [
            '$attribute code not in array' => ['notAttributeCode', 6],
            '$rowdata[$ttrCode] not numeric' => ['maas_offer_price_updated_at', 'NotNumeric']
        ];
    }
}
