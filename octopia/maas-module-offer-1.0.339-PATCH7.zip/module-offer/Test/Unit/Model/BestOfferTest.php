<?php

namespace Maas\Offer\Test\Unit\Model;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Console\Command\InputBuilder;
use Maas\Core\Test\Builder\Console\Command\OutputBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Report;
use Maas\Log\Test\Builder\ReportBuilder;
use Maas\Offer\Model\BestOffer;
use Maas\Offer\Test\Builder\CsvLoggerBuilder;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\ImportExport\Model\Import\ErrorProcessing\ProcessingError;
use ReflectionException;

/**
 * Class BestOfferTest
 *
 * @package Maas\Offer\Test\Unit\Model
 */
class BestOfferTest extends AbstractTestCase
{
    protected const REPORT_ID = 123;

    /* TODO 1671 : re-activate test
    public function testStartImportBestOffers()
    {
        $csvLogger = CsvLoggerBuilder::create($this, [])->build();

        $reportMock = ReportBuilder::create($this, [
            'getId' => [$this->any(), self::REPORT_ID]
        ])->build();

        $successfulStartModelMockArgs = ['test' => 1];
        $successfulStartModelMock = $this->getInstanceMock(BestOffer::class, [], [
            'checkIfCommandLaunched' => [
                1,
                false,
                self::RETURN_VALUE,
                [
                    BestOffer::MAAS_LOG_MODULE,
                    BestOffer::MAAS_LOG_ACTION,
                    Report::STATUS_STARTED
                ]
            ],
            'initLog' => [1, $reportMock, self::RETURN_REFERENCE, [$successfulStartModelMockArgs]],
            'getCsvLogger' => [1, $csvLogger]
        ]);
        $successfulStartModelMock->startImportBestOffers($successfulStartModelMockArgs);


        $failedStartModelMockArgs = ['test' => 1];
        $failedStartModelMock = $this->getInstanceMock(BestOffer::class, [], [
            'checkIfCommandLaunched' => [
                1,
                true,
                self::RETURN_VALUE,
                [
                    BestOffer::MAAS_LOG_MODULE,
                    BestOffer::MAAS_LOG_ACTION,
                    Report::STATUS_STARTED
                ]
            ],
            'initLog' => [0]
        ]);
        $this->expectException(AlreadyExistsException::class);
        $failedStartModelMock->startImportBestOffers($failedStartModelMockArgs);
    }
    */

    public function testRunAfterLastCommandError()
    {
        $this->_testRunAfterLastCommand(7, Report::STATUS_FAILED);
    }

    /**
     * @param int $warningCount
     * @param string $expectedState
     *
     * @throws ReflectionException
     */
    protected function _testRunAfterLastCommand($warningCount, $expectedState)
    {

        $csvLogger = CsvLoggerBuilder::create($this, [])->build();

        $input = InputBuilder::create($this)->build();
        $output = OutputBuilder::create($this)->build();

        $reportMock = ReportBuilder::create($this, [
            'getWarningItemsCount' => [2, $warningCount]
        ])
            ->setUseConcreteClass(true)
            ->build();

        $reportRepositoryMock = AnyBuilder::createForClass($this, ReportRepositoryInterface::class, [
            'get' => [1, $reportMock, self::RETURN_REFERENCE],
            'closeLogReport' => [1, null, self::RETURN_SELF, [$reportMock, $warningCount > 0]]
        ])->build();

        $instance = $this->getInstanceMock(BestOffer::class, [
            'reportRepository' => $reportRepositoryMock
        ], [
            'loadReportIdFromCache' => [
                1,
                self::REPORT_ID
            ],
            'getCsvLogger' => [
                1,
                $csvLogger
            ]
        ]);

        $this->setAttribute($instance, 'report', $reportMock);

        $this->invokeMethod($instance, 'endImportBestOffer', [$input, $output]);

    }

    public function testRunAfterLastCommandSuccess()
    {
        $this->_testRunAfterLastCommand(0, Report::STATUS_SUCCESS);
    }

    /**
     * @param int $warningCount
     * @param string $expectedState
     *
     * @throws ReflectionException
     */
    public function testEndImportBestOfferFailed()
    {
        $input = InputBuilder::create($this)->build();
        $output = OutputBuilder::create($this)->build();

        $reportRepositoryMock = AnyBuilder::createForClass($this, ReportRepositoryInterface::class, [
            'get' => [0],
        ])->build();

        $instance = $this->getInstanceMock(BestOffer::class, [
            'reportRepository' => $reportRepositoryMock
        ], [
            'loadReportIdFromCache' => [
                1,
                0
            ]
        ]);

        $this->invokeMethod($instance, 'endImportBestOffer', [$input, $output]);

    }
}
