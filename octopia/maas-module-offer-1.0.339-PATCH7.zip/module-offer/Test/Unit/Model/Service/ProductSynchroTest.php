<?php

namespace Maas\Offer\Test\Unit\Model\Service;

use Exception;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Inventory\StockItemBuilder;
use Maas\Core\Test\Builder\Product\ProductBuilder;
use Maas\Core\Test\Builder\Product\ProductExtensionBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Offer\Model\Service\ProductSynchro;
use Maas\Offer\Test\Builder\OfferBuilder;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class ProductSynchroTest
 *
 * @package Maas\Offer\Test\Unit\Model\Service
 */
class ProductSynchroTest extends AbstractTestCase
{
    const PRODUCT_ID = 123;
    const PRODUCT_ID_NOT_EXISTING = 456;
    const SELLER_ID = 456;

    protected $existingProduct;

    protected $productRepositoryMock;

    protected $offerWithProductMock;

    protected $offerWithoutProductMock;

    public function testGetProduct()
    {
        $this->initializeMocks(2, 0, 1, 1, 0, 0, false);

        $instance = $this->getObject(ProductSynchro::class, [
            'productRepository' => $this->productRepositoryMock
        ]);

        $this->assertSame($this->existingProduct,
            $this->invokeMethod($instance, 'getProduct', [$this->offerWithProductMock]));
        $this->assertNull($this->invokeMethod($instance, 'getProduct', [$this->offerWithoutProductMock]));
    }

    /**
     * @param int $productRepositoryGetCallCount
     * @param int $productRepositorySaveCallCount
     * @param int $offerWithProductGetProductidCallCount
     * @param int $offerWithoutProductGetProductidCallCount
     * @param int $productGetExtCallCount
     * @param int $productSetExtCallCount
     * @param boolean $stockItemIsSettingOutOfStock
     */
    protected function initializeMocks(
        $productRepositoryGetCallCount,
        $productRepositorySaveCallCount,
        $offerWithProductGetProductidCallCount,
        $offerWithoutProductGetProductidCallCount,
        $productGetExtCallCount,
        $productSetExtCallCount,
        $stockItemIsSettingOutOfStock
    ) {
        $existingProductStockItemMock = StockItemBuilder::create($this, $stockItemIsSettingOutOfStock ? [
            'setQty' => [1, null, self::RETURN_SELF, [0]],
            'setIsInStock' => [1, null, self::RETURN_SELF, [false]]
        ] : [])->build();

        $existingProductExtensionMock = ProductExtensionBuilder::create($this, $stockItemIsSettingOutOfStock ? [
            'getStockItem' => [1, $existingProductStockItemMock, self::RETURN_REFERENCE],
            'setStockItem' => [1, null, self::RETURN_SELF, [$existingProductStockItemMock]]
        ] : [])->build();

        $this->existingProduct = ProductBuilder::create($this, [
            'getExtensionAttributes' => [
                $productGetExtCallCount,
                $existingProductExtensionMock,
                self::RETURN_REFERENCE
            ],
            'setExtensionAttributes' => [
                $productSetExtCallCount,
                null,
                self::RETURN_SELF,
                [$existingProductExtensionMock]
            ]
        ])->build();
        $this->productRepositoryMock = AnyBuilder::createForClass($this, ProductRepositoryInterface::class, [
            'get' => [
                $productRepositoryGetCallCount,
                function ($productId) {
                    if ($productId == self::PRODUCT_ID) {
                        return $this->existingProduct;
                    } else {
                        throw new NoSuchEntityException(__('No such product'));
                    }
                },
                self::RETURN_CALLBACK
            ],
            'save' => [$productRepositorySaveCallCount ? 1 : 0, null, self::RETURN_SELF, [$this->existingProduct]]
        ])->build();
        $this->offerWithProductMock = OfferBuilder::create($this, [
            'getProductId' => [$offerWithProductGetProductidCallCount, self::PRODUCT_ID]
        ])->build();

        $this->offerWithoutProductMock = OfferBuilder::create($this, [
            'getProductId' => [$offerWithoutProductGetProductidCallCount, self::PRODUCT_ID_NOT_EXISTING]
        ])->build();
    }

    public function testShouldDeleteOffer()
    {
        $this->initializeMocks(2, 1, 1, 1, 1, 1, true);
        $offerDeleteCalls = 0;

        $offer1 = &$this->offerWithProductMock;
        $offer2 = &$this->offerWithoutProductMock;

        $offerRepositoryMock = AnyBuilder::createForClass($this, OfferRepositoryInterface::class, [
            'delete' => [
                2,
                function ($offer) use (&$offerDeleteCalls, $offer1, $offer2) {
                    if ($offerDeleteCalls) {
                        if ($offer !== $offer2) {
                            $this->throwException(new Exception('Wrong or unknown offer'));
                        }
                    } else {
                        if ($offer !== $offer1) {
                            $this->throwException(new Exception('Wrong or unknown offer'));
                        }
                    }
                    $offerDeleteCalls++;
                },
                self::RETURN_CALLBACK
            ]
        ])->build();

        $instance = $this->getObject(ProductSynchro::class, [
            'productRepository' => $this->productRepositoryMock,
            'offerRepository' => $offerRepositoryMock
        ]);

        $instance->shouldDeleteOffer($this->offerWithProductMock);
        $instance->shouldDeleteOffer($this->offerWithoutProductMock);
        $this->assertEquals(2, $offerDeleteCalls);
    }
}
