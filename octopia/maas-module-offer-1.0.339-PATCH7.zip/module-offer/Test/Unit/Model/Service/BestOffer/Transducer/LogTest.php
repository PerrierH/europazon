<?php


namespace Maas\Offer\Test\Unit\Model\Service\BestOffer\Transducer;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Offer\Model\BestOffer;
use Maas\Offer\Model\Service\BestOffer\Data\DTO;
use Magento\Framework\Stdlib\DateTime\DateTime as DateTime;
use Maas\Offer\Model\Service\BestOffer\Transducer\Log;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Log\Api\Data\ReportInterface;

use PHPUnit\Framework\TestCase;

class LogTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $datTime;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $bestOffer;
    /**
     * @var Log
     */
    private $stub;

    public function initTest($report = null)
    {
        $this->bestOffer = AnyBuilder::createForClass($this, BestOffer::class, [
            'loadReportFromCache' => [$this->once(), $report]
        ])->build();
        $this->datTime = AnyBuilder::createForClass($this, DateTime::class, [
            'date' => [$this->any(), '29/03/2021']
        ])->build();
        $this->stub = new Log(
            $this->bestOffer,
            $this->datTime
        );
    }

    public function testReportNotExist()
    {
        $this->initTest();
        $row = AnyBuilder::createForClass($this, DTO::class, [
            'getProductAttribute' => [$this->never()]
        ])->build();
        $dto = $this->stub->__invoke($row);
        $this->assertEquals($dto, $row, 'should return a DTO');
    }

    public function testReportExist()
    {
        $report = AnyBuilder::createForClass($this,ReportInterface::class, [
            'log' => [$this->once()]
        ])->build();
        $this->initTest($report);
        $offer = AnyBuilder::createForClass($this, OfferInterface::class, [
            'getMaasEntityId' => [$this->once(), '75']
        ])->build();
        $row = AnyBuilder::createForClass($this, DTO::class, [
            'getProductAttribute' => [$this->once(), 'testSku'],
            'getOffer' => [$this->once(), $offer],
        ])->build();
        $dto = $this->stub->__invoke($row);
        $this->assertEquals($dto, $row, 'should return a DTO');
    }
}
