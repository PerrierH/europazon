<?php

namespace Maas\Offer\Test\Unit\Model\Service\BestOffer\Transducer;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Offer\Model\Offer;
use Maas\Offer\Model\OfferInventory;
use Maas\Offer\Model\OfferPrice;
use Maas\Offer\Model\Service\BestOffer\Data\DTO;
use Maas\Offer\Test\Implementation\DTOStepForTests;
use Magento\Framework\DataObject;

/**
 * Class AbstractDTOStepTest
 *
 * @package Maas\Offer\Test\Unit\Model\Service\BestOffer\Transducer
 */
class AbstractDTOStepTest extends AbstractTestCase
{
    const OFFER_SYNC_DATE = '2021-01-31 23:59:59';
    const PRODUCT_MAAS_OFFER_UPDATED_AT = '2021-01-31 20:00:00';
    const OFFER_PRICE_SYNC_DATE = '2021-01-31 20:00:00';
    const PRODUCT_MAAS_OFFER_PRICE_UPDATED_AT = '2021-01-31 23:59:59';
    const OFFER_INVENTORY_SYNC_DATE = '2021-01-31 20:00:00';
    const PRODUCT_MAAS_OFFER_INVENTORY_UPDATED_AT = null;

    const ATTRIBUTE_CODE_OFFER_UPDATED_AT = 'maas_offer_updated_at';
    const ATTRIBUTE_CODE_OFFER_PRICE_UPDATED_AT = 'maas_offer_price_updated_at';
    const ATTRIBUTE_CODE_OFFER_INVENTORY_UPDATED_AT = 'maas_offer_inv_updated_at';


    public function testUpdateIsNeeded()
    {
        /** @var DTOStepForTests $instance */
        $instance = $this->getObject(DTOStepForTests::class);

        /** @var DTO $dto */
        $dto = $this->getObject(DTO::class, [
            'row' => [
                DTO::KEY_OFFER => $this->getObject(Offer::class, ['data' => ['sync_date' => self::OFFER_SYNC_DATE]]),
                DTO::KEY_PRICE => $this->getObject(OfferPrice::class,
                    ['data' => ['sync_date' => self::OFFER_PRICE_SYNC_DATE]]),
                DTO::KEY_INVENTORY => $this->getObject(OfferInventory::class,
                    ['data' => ['sync_date' => self::OFFER_INVENTORY_SYNC_DATE]]),
                DTO::KEY_PRODUCT_DATA => $this->getObject(DataObject::class, [
                    'data' => [
                        self::ATTRIBUTE_CODE_OFFER_UPDATED_AT => self::PRODUCT_MAAS_OFFER_UPDATED_AT,
                        self::ATTRIBUTE_CODE_OFFER_PRICE_UPDATED_AT => self::PRODUCT_MAAS_OFFER_PRICE_UPDATED_AT,
                        self::ATTRIBUTE_CODE_OFFER_INVENTORY_UPDATED_AT => self::PRODUCT_MAAS_OFFER_INVENTORY_UPDATED_AT
                    ]
                ])
            ]
        ]);

        // test without date check : returns true
        $this->assertTrue($this->invokeMethod($instance, 'updateIsNeeded', [$dto]));

        // test with date check : returns true if it's time to update due to the update being more recent
        $instance->setProperties(true, self::ATTRIBUTE_CODE_OFFER_UPDATED_AT, 'getOffer', 'getSyncDate');
        $this->assertTrue($this->invokeMethod($instance, 'updateIsNeeded', [$dto]));

        // test with date check : returns false if it's not time to update
        $instance->setProperties(true, self::ATTRIBUTE_CODE_OFFER_PRICE_UPDATED_AT, 'getOfferPrice', 'getSyncDate');
        $this->assertFalse($this->invokeMethod($instance, 'updateIsNeeded', [$dto]));

        // test with date check : returns true if it's time to update due to the absence of an update date
        $instance->setProperties(true, self::ATTRIBUTE_CODE_OFFER_INVENTORY_UPDATED_AT, 'getOfferInventory',
            'getSyncDate');
        $this->assertTrue($this->invokeMethod($instance, 'updateIsNeeded', [$dto]));
    }

    public function testInvokeUpdateNeeded()
    {
        /** @var DTOStepForTests $instance */
        $instance = $this->getObject(DTOStepForTests::class);
        /** @var DTO $dto */
        $dto = $this->getObject(DTO::class, [
            'row' => [
                DTO::KEY_OFFER => $this->getObject(Offer::class, ['data' => ['sync_date' => self::OFFER_SYNC_DATE]]),
                DTO::KEY_PRICE => $this->getObject(OfferPrice::class,
                    ['data' => ['sync_date' => self::OFFER_PRICE_SYNC_DATE]]),
                DTO::KEY_INVENTORY => $this->getObject(OfferInventory::class,
                    ['data' => ['sync_date' => self::OFFER_INVENTORY_SYNC_DATE]]),
                DTO::KEY_PRODUCT_DATA => $this->getObject(DataObject::class, [
                    'data' => [
                        self::ATTRIBUTE_CODE_OFFER_UPDATED_AT => self::PRODUCT_MAAS_OFFER_UPDATED_AT,
                        self::ATTRIBUTE_CODE_OFFER_PRICE_UPDATED_AT => self::PRODUCT_MAAS_OFFER_PRICE_UPDATED_AT,
                        self::ATTRIBUTE_CODE_OFFER_INVENTORY_UPDATED_AT => self::PRODUCT_MAAS_OFFER_INVENTORY_UPDATED_AT
                    ]
                ])
            ]
        ]);
        $instance->setProperties(true, self::ATTRIBUTE_CODE_OFFER_PRICE_UPDATED_AT, 'getOfferPrice', 'getSyncDate');
        $item = $this->invokeMethod($instance, '__invoke', [$dto]);
        $this->assertEquals($item, $dto, 'should return the dto class');
    }

    public function testInvokeUpdateNotNeeded()
    {
        /** @var DTOStepForTests $instance */
        $instance = $this->getObject(DTOStepForTests::class);
        $dto = $this->getObject(DTO::class);
        $item = $this->invokeMethod($instance, '__invoke', [$dto]);
        $this->assertEquals($item, $dto, 'should return the dto class');
    }
}
