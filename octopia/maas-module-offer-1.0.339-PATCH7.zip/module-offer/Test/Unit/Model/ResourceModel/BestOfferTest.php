<?php

namespace Maas\Offer\Test\Unit\Model\ResourceModel;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Offer\Api\Data\OfferDeliveryInterface;
use Maas\Offer\Api\Data\OfferDeliveryInterfaceFactory;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\Data\OfferInterfaceFactory;
use Maas\Offer\Api\Data\OfferInventoryInterface;
use Maas\Offer\Api\Data\OfferInventoryInterfaceFactory;
use Maas\Offer\Api\Data\OfferPriceInterface;
use Maas\Offer\Api\Data\OfferPriceInterfaceFactory;
use Maas\Offer\Model\Offer;
use Maas\Offer\Model\OfferDelivery;
use Maas\Offer\Model\OfferInventory;
use Maas\Offer\Model\OfferPrice;
use Maas\Offer\Model\ResourceModel\BestOffer;
use Maas\Offer\Model\Service\BestOffer\Data\DTO;
use Maas\Seller\Api\Data\SellerInterface;
use Maas\Seller\Api\Data\SellerInterfaceFactory;
use Maas\Seller\Model\Seller;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\DataObject;
use Magento\Framework\DataObjectFactory;

/**
 * Class BestOfferTest
 *
 * @package Maas\Offer\Test\Unit\Model\ResourceModel
 */
class BestOfferTest extends AbstractTestCase
{
    const TEST_PRODUCT_SKU1 = 'ABC';
    const TEST_PRODUCT_SKU2 = 'DEF';
    const TEST_PRODUCT_OFFER_MAAS_ID1 = 'ABC_offer';
    const TEST_PRODUCT_OFFER_MAAS_ID2 = 'DEF_offer';
    const TEST_PRODUCT_SELLER_MAAS_ID1 = 'ABCS';
    const TEST_PRODUCT_SELLER_MAAS_ID2 = 'DEFS';
    const TEST_PRODUCT_SELLER_NAME1 = 'ABC_seller';
    const TEST_PRODUCT_SELLER_NAME2 = 'DEF_seller';

    const TEST_STANDARD_DELIVERY_MODE = 'Standard';
    const TEST_STANDARD_DELIVERY_PRICE1 = '12.34';
    const TEST_STANDARD_DELIVERY_PRICE2 = '56.78';
    const TEST_EXPRESS_DELIVERY_MODE = 'Express';
    const TEST_EXPRESS_DELIVERY_PRICE1 = '123.45';
    const TEST_EXPRESS_DELIVERY_PRICE2 = '567.89';

    /**
     * Tests the following:
     *  - getOfferEntities
     *  - getSegmentedRow
     *  - createEntity
     */
    public function testEntitySplit()
    {
        $productsWithOffers = [
            $this->createProductData(
                self::TEST_PRODUCT_SKU1, self::TEST_PRODUCT_OFFER_MAAS_ID1,
                self::TEST_PRODUCT_OFFER_MAAS_ID1, self::TEST_PRODUCT_SELLER_NAME1,
                self::TEST_STANDARD_DELIVERY_PRICE1, self::TEST_EXPRESS_DELIVERY_PRICE1
            ),
            $this->createProductData(
                self::TEST_PRODUCT_SKU2, self::TEST_PRODUCT_OFFER_MAAS_ID2,
                self::TEST_PRODUCT_OFFER_MAAS_ID2, self::TEST_PRODUCT_SELLER_NAME2,
                self::TEST_STANDARD_DELIVERY_PRICE2, self::TEST_EXPRESS_DELIVERY_PRICE2
            )
        ];

        $args = ['test' => 1];

        $instance = $this->getInstanceMock(BestOffer::class, [
            'dataObjectFactory' => $this->createFactory(
                DataObjectFactory::class, DataObject::class, count($productsWithOffers)
            ),
            'offerFactory' => $this->createFactory(
                OfferInterfaceFactory::class, Offer::class, count($productsWithOffers)
            ),
            'offerPriceFactory' => $this->createFactory(
                OfferPriceInterfaceFactory::class, OfferPrice::class, count($productsWithOffers)
            ),
            'offerInventoryFactory' => $this->createFactory(
                OfferInventoryInterfaceFactory::class, OfferInventory::class, count($productsWithOffers)
            ),
            'offerDeliveryFactory' => $this->createFactory(
                OfferDeliveryInterfaceFactory::class, OfferDelivery::class, count($productsWithOffers) * 2
            ),
            'sellerFactory' => $this->createFactory(
                SellerInterfaceFactory::class, Seller::class, count($productsWithOffers)
            ),
            'dataObjectHelper' => $this->getObject(DataObjectHelper::class, [
                'joinProcessor' => AnyBuilder::createForClass($this, JoinProcessorInterface::class, [
                    'extractExtensionAttributes' => [
                        $this->any(),
                        function ($class, $data) {
                            return $data;
                        },
                        self::RETURN_CALLBACK
                    ]
                ])->build()
            ])
        ], [
            'getProductsWithOffers' => [1, $productsWithOffers, self::RETURN_VALUE, [false, false, $args]]
        ]);

        $rows = $instance->getOfferEntities($args);
        $this->assertEquals(count($productsWithOffers), count($rows));
        if (count($rows) == 2) {
            list($row1, $row2) = $rows;
            $this->executeResultAssertions($row1, self::TEST_PRODUCT_SKU1, self::TEST_PRODUCT_OFFER_MAAS_ID1,
                self::TEST_PRODUCT_OFFER_MAAS_ID1, self::TEST_PRODUCT_SELLER_NAME1,
                self::TEST_STANDARD_DELIVERY_PRICE1, self::TEST_EXPRESS_DELIVERY_PRICE1);
            $this->executeResultAssertions($row2, self::TEST_PRODUCT_SKU2, self::TEST_PRODUCT_OFFER_MAAS_ID2,
                self::TEST_PRODUCT_OFFER_MAAS_ID2, self::TEST_PRODUCT_SELLER_NAME2,
                self::TEST_STANDARD_DELIVERY_PRICE2, self::TEST_EXPRESS_DELIVERY_PRICE2);
        }
    }

    /**
     * @param string $sku
     * @param string $offerId
     * @param string $sellerId
     * @param string $sellerName
     * @param float $standardPrice
     * @param float $expressPrice
     *
     * @return DataObject
     */
    protected function createProductData($sku, $offerId, $sellerId, $sellerName, $standardPrice, $expressPrice)
    {
        return new DataObject([
            'type_id' => 'simple',
            'sku' => $sku,
            'offer_maas_entity_id' => $offerId,
            'offer_product_id' => $sku,
            'seller_maas_entity_id' => $sellerId,
            'seller_name' => $sellerName,
            'price_maas_entity_id' => $offerId,
            'inventory_maas_entity_id' => $offerId,
            'deliverystandard_mode' => self::TEST_STANDARD_DELIVERY_MODE,
            'deliverystandard_shipping_cost' => $standardPrice,
            'deliveryexpress_mode' => self::TEST_EXPRESS_DELIVERY_MODE,
            'deliveryexpress_shipping_cost' => $expressPrice
        ]);
    }

    /**
     * @param string $factoryClass
     * @param string $objectClass
     * @param int $createCallCount
     *
     * @return \PHPUnit_Framework_MockObject_MockObject
     */
    protected function createFactory($factoryClass, $objectClass, $createCallCount)
    {
        return AnyBuilder::createForClass($this, $factoryClass, [
            'create' => [
                $createCallCount,
                function ($args) use ($objectClass) {
                    $object = $this->getObject($objectClass);
                    if ($args && isset($args['data']) && method_exists($object, 'setData')) {
                        $object->setData($args['data']);
                    }
                    return $object;
                },
                self::RETURN_CALLBACK
            ]
        ])->build();
    }

    /**
     * @param array $row
     * @param string $sku
     * @param string $offerId
     * @param string $sellerId
     * @param string $sellerName
     * @param float $standardPrice
     * @param float $expressPrice
     */
    protected function executeResultAssertions(
        $row,
        $sku,
        $offerId,
        $sellerId,
        $sellerName,
        $standardPrice,
        $expressPrice
    ) {
        $this->executeSubResultAssertions($row, DTO::KEY_PRODUCT_DATA, DataObject::class, [
            'getTypeId' => 'simple',
            'getSku' => $sku
        ]);
        $this->executeSubResultAssertions($row, DTO::KEY_OFFER, OfferInterface::class, [
            'getProductId' => $sku,
            'getMaasEntityId' => $offerId
        ]);
        $this->executeSubResultAssertions($row, DTO::KEY_SELLER, SellerInterface::class, [
            'getMaasEntityId' => $sellerId,
            'getName' => $sellerName
        ]);
        $this->executeSubResultAssertions($row, DTO::KEY_PRICE, OfferPriceInterface::class, [
            'getMaasEntityId' => $offerId
        ]);
        $this->executeSubResultAssertions($row, DTO::KEY_INVENTORY, OfferInventoryInterface::class, [
            'getMaasEntityId' => $offerId
        ]);
    }

    /**
     * @param array $row
     * @param string $key
     * @param string $className
     * @param array $values
     */
    protected function executeSubResultAssertions($row, $key, $className, $values)
    {
        $this->assertArrayHasKey($key, $row);
        $this->assertInstanceOf($className, $row[$key]);
        foreach ($values as $getter => $expected) {
            $this->assertSame($expected, $row[$key]->$getter());
        }
    }
}
