<?php

namespace Maas\Offer\Test\Unit\Model\Offer\Config\Source;

use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\Data\OfferSearchResultsInterface;
use Maas\Offer\Model\Offer\Config\Source\Options;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Maas\Offer\Model\OfferRepository;
use Magento\Framework\Api\SearchCriteriaInterface;

class OptionsTest extends TestCase
{
    private $optionsValuesExpected = [
        [
            'label' => ' ',
            'value' => ''
        ],
        [
            'label' => 'MAASOFFERENTITYID0',
            'value' => '00010'
        ],
        [
            'label' => 'MAASOFFERENTITYID1',
            'value' => '00011'
        ],
        [
            'label' => 'MAASOFFERENTITYID2',
            'value' => '00012'
        ]
    ];
    /**
     * @var MockObject
     */
    private $offerRepository;
    /**
     * @var MockObject
     */
    private $searchCriteriaInterface;
    /**
     * @var Options
     */
    private $sut;

    public function testShouldReturnConfig()
    {
        $offers = [];
        $offerSearchResult = $this->creatMockOfferSearchResult();
        for ($nbOffer = 0; $nbOffer < 3; $nbOffer++) {
            $offer = $this->creatMockOffer();
            $offer->expects($this->once())->method('getMaasEntityId')->willReturn('MAASOFFERENTITYID' . $nbOffer);
            $offer->expects($this->once())->method('getEntityId')->willReturn('0001' . $nbOffer);
            $offers[] = $offer;
        }
        $this->offerRepository->expects($this->once())->method('getList')->willReturn($offerSearchResult);
        $offerSearchResult->expects($this->once())->method('getItems')->willReturn($offers);
        $options = $this->sut->getAllOptions();
        $this->assertEquals($this->optionsValuesExpected, $options, 'Les valeurs d\'options ne sont pas correct');
    }

    private function creatMockOfferSearchResult()
    {
        return $this->getMockBuilder(OfferSearchResultsInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    private function creatMockOffer()
    {
        return $this->getMockBuilder(OfferInterface::class)
            ->setMethods(['getEntityId'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * Set up
     */
    protected function setUp()
    {
        $this->offerRepository = $this->createMock(OfferRepository::class);
        $this->searchCriteriaInterface = $this->createMock(SearchCriteriaInterface::class);
        $this->sut = new Options(
            $this->offerRepository,
            $this->searchCriteriaInterface
        );
    }
}
