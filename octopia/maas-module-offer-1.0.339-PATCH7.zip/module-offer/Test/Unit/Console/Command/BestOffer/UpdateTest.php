<?php

namespace Maas\Offer\Test\Unit\Console\Command\BestOffer;

use Exception;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Console\Command\InputBuilder;
use Maas\Core\Test\Builder\Console\Command\OutputBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Core\Model\Config\Proxy;
use Maas\Log\Api\Data\ReportInterfaceFactory;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Test\Builder\ReportBuilder;
use Maas\Offer\Console\Command\BestOffer\Update;
use Maas\Offer\Model\BestOffer as BestOfferModel;
use Maas\Offer\Model\ResourceModel\BestOffer;
use Maas\Offer\Model\Service\BestOffer\ImportData\Proxy as ImportDataProxy;
use Maas\Offer\Model\Service\BestOffer\ProductUpdate\Proxy as ProductUpdateProxy;
use Maas\Offer\Test\Builder\CsvLoggerBuilder;
use Magento\ImportExport\Model\Import\ErrorProcessing\ProcessingError;
use ReflectionException;

/**
 * Class UpdateTest
 *
 * @package Maas\Offer\Test\Unit\Console\Command\BestOffer
 */
class UpdateTest extends AbstractTestCase
{

    const REPORT_ID_FROM_CACHE = 1234;
    const REPORT_ID_SINGLE_FROM = 12;
    const REPORT_ID_SINGLE_TO = 34;

    const EXISTING_SUCCESS_ITEMS = 4;
    const EXISTING_ERROR_ITEMS = 1;

    const SCHEDULE_ID = 12;

    public function testRunSingleCommandSuccess()
    {
        $this->_testRunSingleCommand(false);
    }

    /**
     * @param bool $throwException
     *
     * @throws ReflectionException
     */
    protected function _testRunSingleCommand($throwException)
    {
        $csvLogger = CsvLoggerBuilder::create($this, [])->build();

        $input = InputBuilder::create($this)->build();
        $output = OutputBuilder::create($this,
            ['writeln' => $throwException ? [$this->once(), null] : [$this->never()]]
        )->build();

        $data = [1, 2, 3, 4];
        $importResult = ['processed' => 4, 'errors' => []];

        $importModelMock = AnyBuilder::createForClass($this, BestOfferModel::class, [
            'loadReportIdFromCache' => [1, self::REPORT_ID_FROM_CACHE],
            'getCsvLogger' => [1, $csvLogger]
        ])->build();

        $reportMock = ReportBuilder::create($this)->build();
        $reportRepositoryMock = AnyBuilder::createForClass($this, ReportRepositoryInterface::class, [
            'get' => [1, $reportMock, self::RETURN_REFERENCE, [self::REPORT_ID_FROM_CACHE]],
            'save' => [1, null, self::RETURN_SELF, [$reportMock]]
        ])->build();

        $productUpdateMock = AnyBuilder::createForClass($this, ProductUpdateProxy::class, [
            'saveProductData' => $throwException ? [
                1,
                $importResult,
                self::RETURN_CALLBACK,
                function ($p_data) {
                    throw new Exception('Error!');
                }
            ] : [1, $importResult, self::RETURN_VALUE, [$data]]
        ])->build();

        $importData = AnyBuilder::createForClass($this, ImportDataProxy::class, [
            'getDataToImport' => [1, $data],
            // 'injectDataToImport' => [1, null, self::RETURN_SELF, [$data]]
        ])->build();

        //reportId 1234
        $instance = $this->getInstanceMock(Update::class, [
            'importModel' => $importModelMock,
            'reportRepository' => $reportRepositoryMock,
            'importData' => $importData,
            'productUpdate' => $productUpdateMock
        ], [
            'processImportResult' => $throwException ? [$this->never()] : [
                $this->once(),
                null,
                self::RETURN_SELF,
                [$importResult, $reportMock, $csvLogger]
            ],
            //'finalizeIfPossible' => [$this->once(), null, self::RETURN_SELF, [$reportMock]]
        ]);

        $this->invokeMethod($instance, 'runSingleCommand',
            [self::REPORT_ID_SINGLE_FROM . '-' . self::REPORT_ID_SINGLE_TO, $input, $output]);
    }

    public function testRunSingleCommandException()
    {
        $this->_testRunSingleCommand(true);
    }

    /* TODO 1671 : re-activate test
    public function testProcessImportResultSuccess()
    {
        $this->_testProcessImportResult([], -1);
    }
    */

    /**
     * @param ProcessingError[] $errors
     * @param int $firstErrorRowNumber
     *
     * @throws ReflectionException
     */
    protected function _testProcessImportResult($errors, $firstErrorRowNumber)
    {
        $csvLogger = CsvLoggerBuilder::create($this, [])->build();
        $data = [
            ['data' => 0],
            ['data' => 1],
            ['data' => 2],
            ['data' => 3],
            ['data' => 4],
            ['data' => 5],
            ['data' => 6],
            ['data' => 7],
            ['data' => 8],
            ['data' => 9]
        ];

        $processedRowCount = count($errors) ? $firstErrorRowNumber : count($data);
        $warningRowCount = count($data) - $processedRowCount;

        $report = ReportBuilder::create($this, [
            'getSuccessItemsCount' => [1, self::EXISTING_SUCCESS_ITEMS],
            'getWarningItemsCount' => [1, self::EXISTING_ERROR_ITEMS],
            'setSuccessItemsCount' => [1, null, self::RETURN_SELF, [self::EXISTING_SUCCESS_ITEMS + $processedRowCount]],
            'setWarningItemsCount' => [1, null, self::RETURN_SELF, [self::EXISTING_ERROR_ITEMS + $warningRowCount]],
        ])->build();
        $result = [
            'processed_count' => $processedRowCount,
            'errors' => $errors,
            'errors_count' => $warningRowCount,

            'bunch_clean_microtime' => 0.1,
            'bunch_save_microtime' => 0.1,
            'bunch_import_microtime' => 0.1,

            'bunch_clean_datetime' => 0.1,
            'bunch_save_datetime' => 0.1,
            'bunch_import_datetime' => 0.1,

            'bunch_count' => count($data)
        ];

        $object = $this->getInstance();
        $this->invokeMethod($object, 'processImportResult', [$result, $report, $csvLogger]);
    }

    /**
     * @param array $arguments
     *
     * @return Update
     */
    protected function getInstance($arguments = [])
    {
        return $this->getObject(Update::class, $arguments);
    }

    /* TODO 1671 : re-activate test
    public function testProcessImportResultError()
    {
        $error1test = AnyBuilder::createForClass($this, ProcessingError::class, [
            'getRowNumber' => [0, 3],
            //'getErrorMessage' => [1, 'Error #1']
        ])->build();
        $error2test = AnyBuilder::createForClass($this, ProcessingError::class, [
            'getRowNumber' => [0, 6],
            //'getErrorMessage' => [1, 'Error #2']
        ])->build();
        $this->_testProcessImportResult([$error1test, $error2test], 3);
    }
    */

    public function testFetchItems()
    {
        $csvLogger = CsvLoggerBuilder::create($this, [])->build();

        $offerIds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
        $expectedRanges = ['1-4', '5-8', '9-10'];

        $input = InputBuilder::create($this, [
            'getOption' => [
                2,
                function ($optionName) {
                    switch ($optionName) {
                        case 'scheduleId':
                            return self::SCHEDULE_ID;
                        case 'limit':
                            return 4;
                        default:
                            $this->throwException(new Exception('Unknown option'));
                    }
                    return null;
                },
                self::RETURN_CALLBACK
            ]
        ])->build();

        $bestOfferMock = AnyBuilder::createForClass($this, BestOffer::class, [
            'getOfferIds' => [1, $offerIds]
        ])->build();

        $reportMock = ReportBuilder::create($this, [
            'getId' => [1, self::REPORT_ID_FROM_CACHE],
            'setItemsCount' => [1, null, self::RETURN_SELF, [count($offerIds)]],
        ])->build();

        $importModelMock = AnyBuilder::createForClass($this, BestOfferModel::class, [
            'saveReportIdInCache' => [1, null, self::RETURN_SELF, [self::REPORT_ID_FROM_CACHE]],
            'startImportBestOffers' => [
                1,
                $reportMock,
                self::RETURN_REFERENCE,
                [
                    [
                        'scheduleId' => self::SCHEDULE_ID
                    ]
                ]
            ],
            'getCsvLogger' => [1, $csvLogger]
        ])->build();

        $reportRepositoryMock = AnyBuilder::createForClass($this, ReportRepositoryInterface::class, [
            'save' => [1, $reportMock, self::RETURN_REFERENCE, [$reportMock]]
        ])->build();

        $instance = $this->getInstance([
            'importModel' => $importModelMock,
            'bestOffer' => $bestOfferMock,
            'reportRepository' => $reportRepositoryMock
        ]);

        $result = $this->invokeMethod($instance, 'fetchItems', [$input]);
        $this->assertSame($expectedRanges, $result);
    }

}
