<?php

namespace Maas\Offer\Cron\BestOffer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Update
 *
 * @package Maas\Offer\Cron\BestOffer
 *
 * @codeCoverageIgnore Delegates all logic to \Maas\ImportExport\Model\Service\CommandRunner and parent class
 */
class Update extends CommandRunner
{
    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:update:bestoffer";
    }
}
