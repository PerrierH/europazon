<?php

namespace Maas\Offer\Plugin;

use Closure;
use Magento\CatalogImportExport\Model\Import\Product\Validator;

/**
 * Class AllowTimestampsForOfferSyncDates
 *
 * @package Maas\Offer\Plugin
 */
class AllowTimestampsForOfferSyncDates
{
    /**
     * @param Validator $subject
     * @param Closure $proceed
     * @param $attrCode
     * @param array $attrParams
     * @param array $rowData
     *
     * @return bool|mixed
     */
    public function aroundIsAttributeValid(
        Validator $subject,
        Closure $proceed,
        $attrCode,
        array $attrParams,
        array $rowData
    ) {
        if (in_array($attrCode, [
                'maas_offer_updated_at',
                'maas_offer_price_updated_at',
                'maas_offer_inv_updated_at'
            ]) && is_numeric($rowData[$attrCode])) {
            return true;
        } else {
            return $proceed($attrCode, $attrParams, $rowData);
        }
    }
}
