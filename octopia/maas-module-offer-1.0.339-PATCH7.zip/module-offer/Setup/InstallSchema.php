<?php

namespace Maas\Offer\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Zend_Db_Exception;

/**
 * Class InstallSchema
 *
 * @codeCoverageIgnore
 * @package Mass\Offer\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    const OFFER_TABLE_NAME = 'maas_offer';
    const OFFER_PRICE_TABLE_NAME = 'maas_offer_price';
    const SELLER_TABLE_NAME = 'maas_seller_entity';

    const MAAS_OFFER_INVENTORY = 'maas_offer_inventory';
    const MAAS_OFFER_DELIVERY = 'maas_offer_delivery';

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        $this->createOfferTable($setup, $connection);
        $this->createOfferPriceTable($setup, $connection);
        $this->createOfferInventoryTable($setup, $connection);
        $this->createOfferDeliveryTable($setup, $connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     */
    private function createOfferTable(SchemaSetupInterface $setup, $connection)
    {
        $offerTable = $connection->newTable(
            $setup->getTable(self::OFFER_TABLE_NAME)
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Entity Id'
        )->addColumn(
            'maas_entity_id',
            Table::TYPE_TEXT,
            64,
            ['nullable' => false],
            'Maas entity Id'
        )->addColumn(
            'product_id',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Product Id equal to product sku'
        )->addColumn(
            'condition',
            Table::TYPE_TEXT,
            20,
            ['nullable' => false],
            'Condition for the offer'
        )->addColumn(
            'sub_condition',
            Table::TYPE_TEXT,
            25,
            ['nullable' => false],
            'Sub condition offer'
        )->addColumn(
            'comment',
            Table::TYPE_TEXT,
            '64k',
            ['nullable' => false],
            'Comment offer'
        )->addColumn(
            'image',
            Table::TYPE_TEXT,
            '255',
            ['nullable' => false],
            'Large image for offer'
        )->addColumn(
            'best_offer',
            Table::TYPE_TEXT,
            '255',
            ['nullable' => false],
            'Best offer'
        )->addColumn(
            'seller_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'unsigned' => true],
            'Seller Id'
        )->addColumn(
            'quantity',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Maas quantity'
        )->addColumn(
            'sync_date',
            Table::TYPE_DATETIME,
            255,
            ['nullable' => false],
            'Date of synchronisation'
        )->addIndex(
            $connection->getIndexName(
                $setup->getTable(self::OFFER_TABLE_NAME),
                ['maas_entity_id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['maas_entity_id'],
            ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
        )->addForeignKey(
            $connection->getForeignKeyName(
                $setup->getTable(self::OFFER_TABLE_NAME),
                'seller_id',
                $connection->getTableName(self::SELLER_TABLE_NAME),
                'entity_id'
            ),
            'seller_id',
            $connection->getTableName(self::SELLER_TABLE_NAME),
            'entity_id',
            Table::ACTION_CASCADE
        );

        $connection->createTable($offerTable);
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     */
    private function createOfferPriceTable(SchemaSetupInterface $setup, $connection)
    {
        $offerPriceTable = $connection->newTable(
            $setup->getTable(self::OFFER_PRICE_TABLE_NAME)
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Entity Id'
        )->addColumn(
            'maas_entity_id',
            Table::TYPE_TEXT,
            64,
            ['nullable' => false],
            'Maas entity Id'
        )->addColumn(
            'price',
            Table::TYPE_DECIMAL,
            '10,2',
            ['nullable' => false],
            'Maas offer price'
        )->addColumn(
            'currency',
            Table::TYPE_TEXT,
            5,
            ['nullable' => false],
            'Maas offer currency'
        )->addColumn(
            'original_price',
            Table::TYPE_DECIMAL,
            '10,2',
            ['nullable' => false],
            'Maas offer original price'
        )->addColumn(
            'start_date',
            Table::TYPE_DATETIME,
            255,
            ['nullable' => false],
            'Maas offer start date of validity of the price'
        )->addColumn(
            'end_date',
            Table::TYPE_DATETIME,
            255,
            ['nullable' => false],
            'Maas offer end date of validity of the price'
        )->addColumn(
            'discount_id',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Maas offer discount id of the commercial operation'
        )->addColumn(
            'sync_date',
            Table::TYPE_DATETIME,
            255,
            ['nullable' => false],
            'Maas offer last date and time when offer was updated'
        )->addIndex(
            $connection->getIndexName(
                $setup->getTable(self::OFFER_PRICE_TABLE_NAME),
                ['maas_entity_id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['maas_entity_id'],
            ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
        )->addForeignKey(
            $connection->getForeignKeyName(
                $setup->getTable(self::OFFER_PRICE_TABLE_NAME),
                'maas_entity_id',
                $connection->getTableName(self::OFFER_TABLE_NAME),
                'maas_entity_id'
            ),
            'maas_entity_id',
            $connection->getTableName(self::OFFER_TABLE_NAME),
            'maas_entity_id',
            Table::ACTION_CASCADE
        );
        $connection->createTable($offerPriceTable);
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     *
     * @throws Zend_Db_Exception
     */
    private function createOfferInventoryTable(SchemaSetupInterface $setup, AdapterInterface $connection)
    {
        $offerInventoryTable = $connection->newTable(
            $setup->getTable(self::MAAS_OFFER_INVENTORY)
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Entity Id'
        )->addColumn(
            'maas_entity_id',
            Table::TYPE_TEXT,
            64,
            ['nullable' => false],
            'Maas entity Id'
        )->addColumn(
            'stock',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Maas inventory quantity'
        )->addColumn(
            'supply_mode',
            Table::TYPE_TEXT,
            '255',
            ['nullable' => false],
            'Maas inventory the fulfillment channel for the offer'
        )->addColumn(
            'sync_date',
            Table::TYPE_DATETIME,
            255,
            ['nullable' => false],
            'Maas inventory the cost of the shipping including all taxes'
        )->addIndex(
            $connection->getIndexName(
                $setup->getTable(self::MAAS_OFFER_INVENTORY),
                ['maas_entity_id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['maas_entity_id'],
            ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
        )->addForeignKey(
            $connection->getForeignKeyName(
                $setup->getTable(self::MAAS_OFFER_INVENTORY),
                'maas_entity_id',
                $connection->getTableName(self::OFFER_TABLE_NAME),
                'maas_entity_id'
            ),
            'maas_entity_id',
            $connection->getTableName(self::OFFER_TABLE_NAME),
            'maas_entity_id',
            Table::ACTION_CASCADE
        );
        $connection->createTable($offerInventoryTable);
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     *
     * @throws Zend_Db_Exception
     */
    private function createOfferDeliveryTable(SchemaSetupInterface $setup, AdapterInterface $connection)
    {
        $offerDeliveryTable = $connection->newTable(
            $setup->getTable(self::MAAS_OFFER_DELIVERY)
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Entity Id'
        )->addColumn(
            'inventory_id',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false, 'unsigned' => true],
            'Maas delivery reference maas_offer_inventory'
        )->addColumn(
            'mode',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Maas inventory delivery mode of your sales channel'
        )->addColumn(
            'min_delay',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Maas inventory minimum delivery delay'
        )->addColumn(
            'max_delay',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Maas inventory maximum delivery delay'
        )->addColumn(
            'shipping_cost',
            Table::TYPE_DECIMAL,
            '10,2',
            ['nullable' => false],
            'Maas inventory basic shipping cost'
        )->addColumn(
            'additional_shipping_cost',
            Table::TYPE_DECIMAL,
            '10,2',
            ['nullable' => true],
            'Maas inventory additional cost for 2+ products'
        )->addForeignKey(
            $connection->getForeignKeyName(
                $setup->getTable(self::MAAS_OFFER_DELIVERY),
                'inventory_id',
                self::MAAS_OFFER_INVENTORY,
                'entity_id'
            ),
            'inventory_id',
            self::MAAS_OFFER_INVENTORY,
            'entity_id'
        );
        $connection->createTable($offerDeliveryTable);
    }
}
