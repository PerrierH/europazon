<?php

namespace Maas\Offer\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    const OFFER_TABLE_NAME = 'maas_offer';
    const MAAS_OFFER_INVENTORY = 'maas_offer_inventory';
    const MAAS_OFFER_DELIVERY = 'maas_offer_delivery';
    const SELLER_TABLE_NAME = 'maas_seller_entity';
    const OFFER_TAX_TABLE_NAME = 'maas_offer_tax';
    const OFFER_PRICE_TABLE_NAME = 'maas_offer_price';

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            $connection->addIndex(
                $setup->getTable('maas_offer'),
                'unique_bestoffer_per_product',
                ['product_id', 'best_offer'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            );
        }
        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            $connection->addColumn(
                $setup->getTable('maas_offer'),
                'warranty_duration',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => 255,
                    'nullable' => true,
                    'comment' => 'Warranty duration'
                ]
            );
        }

        if (version_compare($context->getVersion(), '1.0.4', '<')) {
            $foreignKeyDeliveryTable = $connection->getForeignKeyName(
                $setup->getTable(self::MAAS_OFFER_DELIVERY),
                'inventory_id',
                self::MAAS_OFFER_INVENTORY,
                'entity_id'
            );
            $connection->dropForeignKey(
                self::MAAS_OFFER_DELIVERY,
                $foreignKeyDeliveryTable
            );
            $connection->addForeignKey(
                $foreignKeyDeliveryTable,
                self::MAAS_OFFER_DELIVERY,
                'inventory_id',
                self::MAAS_OFFER_INVENTORY,
                'entity_id',
                Table::ACTION_CASCADE
            );
        }

        if (version_compare($context->getVersion(), '1.0.5', '<')) {
            $connection->dropIndex(
                $setup->getTable('maas_offer'),
                'unique_bestoffer_per_product'
            );
        }

        if (version_compare($context->getVersion(), '1.0.6', '<')) {
            $this->createOfferTaxTable($setup, $connection);
        }

        if (version_compare($context->getVersion(), '1.0.7', '<')) {

            $connection->dropTable(
                $setup->getTable('maas_offer_tax')
            );

            $connection->dropTable(
                $setup->getTable('maas_offer_delivery')
            );

            $connection->addColumn(
                $setup->getTable('maas_offer_price'),
                'taxes',
                [
                    'type' => Table::TYPE_TEXT,
                    '64k',
                    'nullable' => true,
                    'comment' => 'Taxes'
                ]
            );

            $connection->addColumn(
                $setup->getTable('maas_offer_inventory'),
                'deliveries',
                [
                    'type' => Table::TYPE_TEXT,
                    '64k',
                    'nullable' => true,
                    'comment' => 'Deliveries'
                ]
            );
        }
        
        if (version_compare($context->getVersion(), '1.0.9', '<')) {
            $foreignKeyOffer = $connection->getForeignKeyName(
                $setup->getTable(self::OFFER_TABLE_NAME),
                'seller_id',
                self::SELLER_TABLE_NAME,
                'entity_id'
            );
            $connection->dropForeignKey(
                self::OFFER_TABLE_NAME,
                $foreignKeyOffer
            );
        }
        
        $setup->endSetup();
    }
    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     * @return void
     */
    private function createOfferTaxTable(SchemaSetupInterface $setup, $connection)
    {
        $offerTaxTable = $connection->newTable(
            $setup->getTable(self::OFFER_TAX_TABLE_NAME)
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'Entity Id'
        )->addColumn(
            'price_id',
            Table::TYPE_INTEGER,
            null,
            ['unsigned' => true, 'nullable' => false],
            'Maas tax reference maas_offer_price'
        )->addColumn(
            'code',
            Table::TYPE_TEXT,
            64,
            ['nullable' => false],
            'Maas offer tax code of the commercial operation'
        )->addColumn(
            'type',
            Table::TYPE_TEXT,
            64,
            ['nullable' => false],
            'Maas offer tax type of the commercial operation'
        )->addColumn(
            'value',
            Table::TYPE_DECIMAL,
            '10,2',
            ['nullable' => false],
            'Maas offer tax value of the commercial operation'
        )->addIndex(
            $connection->getIndexName(
                $setup->getTable(self::OFFER_TAX_TABLE_NAME),
                ['entity_id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['entity_id'],
            ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
        )->addForeignKey(
            $connection->getForeignKeyName(
                $setup->getTable(self::OFFER_TAX_TABLE_NAME),
                'price_id',
                $connection->getTableName(self::OFFER_PRICE_TABLE_NAME),
                'entity_id'
            ),
            'price_id',
            $connection->getTableName(self::OFFER_PRICE_TABLE_NAME),
            'entity_id',
            Table::ACTION_CASCADE
        );
        $connection->createTable($offerTaxTable);
    }
}
