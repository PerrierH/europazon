<?php

namespace Maas\Offer\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 *
 * @package Maas\Offer\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $connection = $setup->getConnection();
        $connection->query('SET FOREIGN_KEY_CHECKS=0;');
        /* Remove Maas_Offer tables */
        $connection->dropTable($setup->getTable('maas_offer'));
        $connection->dropTable($setup->getTable('maas_offer_inventory'));
        $connection->dropTable($setup->getTable('maas_offer_price'));
        $connection->query('SET FOREIGN_KEY_CHECKS=1;');

        $setup->endSetup();

    }
}
