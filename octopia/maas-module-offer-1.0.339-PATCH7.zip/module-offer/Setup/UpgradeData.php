<?php

namespace Maas\Offer\Setup;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Maas\Core\Api\Data\EditionInterface;

class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * @param EditionInterface $edition
     */
    public function __construct(EditionInterface $edition)
    {
        $this->edition = $edition;
    }
    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.10', '<')) {
            $connection = $setup->getConnection();

            $csi = $connection->getTableName('cataloginventory_stock_item');
            $cpe = $connection->getTableName('catalog_product_entity');
            $ir = $connection->getTableName('inventory_reservation');
            $eav = $connection->getTableName('eav_attribute');
            $cped = $connection->getTableName('catalog_product_entity_datetime');
            $mo = $connection->getTableName('maas_offer');
            $linkField = $this->edition->getLinkField();
            $connection->query(
                "UPDATE " . $csi . " AS csi
INNER JOIN (SELECT cpe.entity_id, CASE WHEN csi.qty - IFNULL(SUM(ir.quantity), 0) > 0 THEN csi.qty - IFNULL(SUM(ir.quantity), 0) ELSE 0 END as qty from " . $csi . " AS csi
INNER JOIN " . $cpe . " AS cpe ON cpe.entity_id = csi.product_id
INNER JOIN " . $ir . " AS ir ON ir.sku = cpe.sku
INNER JOIN " . $eav . " AS eav ON eav.attribute_code = 'maas_offer_updated_at'
INNER JOIN " . $cped ." AS cped ON cped.".$linkField." = cpe.".$linkField." AND eav.attribute_id = cped.attribute_id
INNER JOIN " . $mo . " AS mo on mo.product_id = cpe.sku
WHERE cped.value >= mo.sync_date
GROUP BY csi.product_id) AS tbl ON tbl.entity_id =  csi.product_id
SET csi.qty = tbl.qty"
            );
        }

        $setup->endSetup();
    }
}
