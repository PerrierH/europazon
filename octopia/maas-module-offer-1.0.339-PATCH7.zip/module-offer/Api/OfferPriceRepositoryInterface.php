<?php

namespace Maas\Offer\Api;

use Maas\Offer\Api\Data\OfferPriceInterface;
use Maas\Offer\Api\Data\OfferPriceSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface OfferPriceRepositoryInterface
 *
 * @package Maas\Offer\Api
 */
interface OfferPriceRepositoryInterface
{
    /**
     * @param OfferPriceInterface $offerPrice
     *
     * @return OfferPriceInterface
     */
    public function save(OfferPriceInterface $offerPrice);

    /**
     * @param int $id
     *
     * @return OfferPriceInterface
     */
    public function get($id);

    /**
     * @param OfferPriceInterface $offerPrice
     */
    public function delete(OfferPriceInterface $offerPrice);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return OfferPriceSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
