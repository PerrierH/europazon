<?php

namespace Maas\Offer\Api;

use Maas\Offer\Api\Data\OfferDeliveryInterface;
use Maas\Offer\Api\Data\OfferDeliverySearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface OfferDeliveryRepositoryInterface
 *
 * @package Maas\Offer\Api
 */
interface OfferDeliveryRepositoryInterface
{
    /**
     * @param OfferDeliveryInterface $offerIDelivery
     *
     * @return OfferDeliveryInterface
     */
    public function save(OfferDeliveryInterface $offerIDelivery);

    /**
     * @param int $id
     *
     * @return OfferDeliveryInterface
     */
    public function get($id);

    /**
     * @param OfferDeliveryInterface $offerIDelivery
     */
    public function delete(OfferDeliveryInterface $offerIDelivery);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return OfferDeliverySearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
