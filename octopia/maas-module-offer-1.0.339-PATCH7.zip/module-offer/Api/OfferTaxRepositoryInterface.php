<?php

namespace Maas\Offer\Api;

use Maas\Offer\Api\Data\OfferTaxInterface;
use Maas\Offer\Api\Data\OfferTaxSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface OfferTaxRepositoryInterface
 *
 * @package Maas\Offer\Api
 */
interface OfferTaxRepositoryInterface
{
    /**
     * @param OfferTaxInterface $offerTax
     *
     * @return OfferTaxInterface
     */
    public function save(OfferTaxInterface $offerTax);

    /**
     * @param int $id
     *
     * @return OfferTaxInterface
     */
    public function get($id);

    /**
     * @param OfferTaxInterface $offerTax
     */
    public function delete(OfferTaxInterface $offerTax);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return OfferTaxSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
