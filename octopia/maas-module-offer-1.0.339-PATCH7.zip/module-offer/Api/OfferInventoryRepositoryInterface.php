<?php

namespace Maas\Offer\Api;

use Maas\Offer\Api\Data\OfferInventoryInterface;
use Maas\Offer\Api\Data\OfferInventorySearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface OfferInventoryRepositoryInterface
 *
 * @package Maas\Offer\Api
 */
interface OfferInventoryRepositoryInterface
{
    /**
     * @param OfferInventoryInterface $offerInventory
     *
     * @return OfferInventoryInterface
     */
    public function save(OfferInventoryInterface $offerInventory);

    /**
     * @param int $id
     *
     * @return OfferInventoryInterface
     */
    public function get($id);

    /**
     * @param OfferInventoryInterface $offerInventory
     */
    public function delete(OfferInventoryInterface $offerInventory);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return OfferInventorySearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
