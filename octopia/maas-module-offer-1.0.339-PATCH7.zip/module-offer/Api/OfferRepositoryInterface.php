<?php

namespace Maas\Offer\Api;

use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\Data\OfferSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface OfferRepositoryInterface
 *
 * @package Maas\Offer\Api
 */
interface OfferRepositoryInterface
{
    /**
     * @param OfferInterface $offer
     *
     * @return OfferInterface
     */
    public function save(OfferInterface $offer);

    /**
     * @param int $id
     *
     * @return OfferInterface
     */
    public function get($id);

    /**
     * @param OfferInterface $offer
     */
    public function delete(OfferInterface $offer);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return OfferSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
