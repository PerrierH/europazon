<?php

namespace Maas\Offer\Api\Data;

/**
 * Interface OfferTaxInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferTaxInterface
{
    const PRICE_ID = 'price_id';
    const CODE = 'code';
    const TYPE = 'type';
    const VALUE = 'value';

    /**
     * @return mixed
     */
    public function getPriceId();

    /**
     * @return mixed
     */
    public function getCode();

    /**
     * @return mixed
     */
    public function getType();

    /**
     * @return mixed
     */
    public function getValue();

    /**
     * @param $offerId
     * @return mixed
     */
    public function setPriceId($offerId);

    /**
     * @param $code
     * @return mixed
     */
    public function setCode($code);

    /**
     * @param $type
     * @return mixed
     */
    public function setType($type);

    /**
     * @param $value
     * @return mixed
     */
    public function setValue($value);
}
