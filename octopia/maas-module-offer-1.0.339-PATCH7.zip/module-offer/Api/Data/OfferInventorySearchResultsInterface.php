<?php

namespace Maas\Offer\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface OfferInventorySearchResultsInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferInventorySearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get offerInventories list.
     *
     * @return OfferInventoryInterface[]
     */
    public function getItems();

    /**
     * Set offerInventories list.
     *
     * @param OfferInventoryInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
