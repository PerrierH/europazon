<?php

namespace Maas\Offer\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface OfferSearchResultsInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get offers list.
     *
     * @return OfferInterface[]
     */
    public function getItems();

    /**
     * Set offers list.
     *
     * @param OfferInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}