<?php

namespace Maas\Offer\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface OfferPriceSearchResultsInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferPriceSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get offers list.
     *
     * @return OfferPriceInterface[]
     */
    public function getItems();

    /**
     * Set offers list.
     *
     * @param OfferPriceInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
