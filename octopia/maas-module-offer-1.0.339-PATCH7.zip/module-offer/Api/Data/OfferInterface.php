<?php

namespace Maas\Offer\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;
use DateTime;

/**
 * Interface OfferInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferInterface extends ExtensibleDataInterface
{
    const MAAS_ENTITY_ID = 'maas_entity_id';

    const SELLER_ID = 'seller_id';

    const QUANTITY = 'quantity';

    const PRODUCT_ID = 'product_id';

    const CONDITION = 'condition';

    const SUB_CONDITION = 'sub_condition';

    const IMAGE = 'image';

    const BEST_OFFER = 'best_offer';

    const SYNC_DATE = 'sync_date';

    const COMMENT = 'comment';

    const WARRANTY_DURATION = 'warranty_duration';

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return int|null
     */
    public function getMaasEntityId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setMaasEntityId($id);

    /**
     * @return int|null
     */
    public function getSellerId();

    /**
     * @param int $sellerId
     *
     * @return $this
     */
    public function setSellerId($sellerId);

    /**
     * @return int|null
     */
    public function getQuantity();

    /**
     * @param int $quantity
     *
     * @return $this
     */
    public function setQuantity($quantity);

    /**
     * @return string|null
     */
    public function getProductId();

    /**
     * @param string $productId
     *
     * @return $this
     */
    public function setProductId($productId);

    /**
     * @return string|null
     */
    public function getCondition();

    /**
     * @param string $condition
     *
     * @return $this
     */
    public function setCondition($condition);

    /**
     * @return string|null
     */
    public function getSubCondition();

    /**
     * @param string $subCondition
     *
     * @return $this
     */
    public function setSubCondition($subCondition);

    /**
     * @return string|null
     */
    public function getComment();

    /**
     * @param string $comment
     *
     * @return $this
     */
    public function setComment($comment);

    /**
     * @return string|null
     */
    public function getImage();

    /**
     * @param string $image
     *
     * @return $this
     */
    public function setImage($image);

    /**
     * @return string|null
     */
    public function getBestOffer();

    /**
     * @param string $bestOfferRank
     *
     * @return $this
     */
    public function setBestOffer($bestOfferRank);

    /**
     * @return Datetime|null
     */
    public function getSyncDate();

    /**
     * @param DateTime $syncDate
     *
     * @return $this
     */
    public function setSyncDate($syncDate);

    /**
     * @return string|null
     */
    public function getWarrantyDuration();

    /**
     * @param $warrantyDuration
     *
     * @return $this
     */
    public function setWarrantyDuration($warrantyDuration);
}
