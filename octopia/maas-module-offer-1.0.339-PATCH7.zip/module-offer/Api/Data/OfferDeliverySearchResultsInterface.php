<?php

namespace Maas\Offer\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface OfferDeliverySearchResultsInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferDeliverySearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get offerDeliveries list.
     *
     * @return OfferDeliveryInterface[]
     */
    public function getItems();

    /**
     * Set offerDeliveries list.
     *
     * @param OfferDeliveryInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
