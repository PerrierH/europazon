<?php

namespace Maas\Offer\Api\Data;

/**
 * Interface OfferPriceInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferPriceInterface
{

    const MAAS_ENTITY_ID = 'maas_entity_id';
    const PRICE = 'price';
    const CURRENCY = 'currency';
    const ORIGINAL_PRICE = 'original_price';
    const START_DATE = 'start_date';
    const END_DATE = 'end_date';
    const DISCOUNT_ID = 'discount_id';
    const SYNC_DATE = 'sync_date';
    const TAXES = 'taxes';

    /**
     * @return string
     */
    public function getMaasEntityId();
    /**
     * @return float
     */
    public function getPrice();
    /**
     * @return string
     */
    public function getCurrency();
    /**
     * @return float
     */
    public function getOriginalPrice();
    /**
     * @return string
     */
    public function getStartDate();
    /**
     * @return string
     */
    public function getEndDate();
    /**
     * @return string
     */
    public function getDiscountId();
    /**
     * @return string
     */
    public function getSyncDate();
    /**
     * @return string
     */
    public function getTaxes();
    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setMaasEntityId($offerId);
    /**
     * @param float $price
     *
     * @return $this
     */
    public function setPrice($price);
    /**
     * @param string $currency
     *
     * @return $this
     */
    public function setCurrency($currency);
    /**
     * @param float $originalPrice
     *
     * @return $this
     */
    public function setOriginalPrice($originalPrice);
    /**
     * @param string $startDate
     *
     * @return $this
     */
    public function setStartDate($startDate);
    /**
     * @param string $endDate
     *
     * @return $this
     */
    public function setEndDate($endDate);
    /**
     * @param string $discountId
     *
     * @return $this
     */
    public function setDiscountId($discountId);
    /**
     * @param string $syncDate
     *
     * @return $this
     */
    public function setSyncDate($syncDate);
    /**
     * @param string $taxes
     *
     * @return $this
     */
    public function setTaxes($taxes);
}
