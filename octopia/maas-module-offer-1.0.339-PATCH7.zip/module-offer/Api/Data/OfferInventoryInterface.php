<?php

namespace Maas\Offer\Api\Data;

use DateTime;

interface OfferInventoryInterface
{
    const MAAS_ENTITY_ID = "maas_entity_id";
    const STOCK = "stock";
    const SUPPLY_MODE = "supply_mode";
    const SYNC_DATE = "sync_date";
    const DELIVERIES = "deliveries";

    /**
     * @return string
     */
    public function getMaasEntityId();

    /**
     * @return string
     */
    public function getStock();

    /**
     * @return string
     */
    public function getSupplyMode();

    /**
     * @return DateTime
     */
    public function getSyncDate();

    /**
     * @return string
     */
    public function getDeliveries();

    /**
     * @param string $maasEntityId
     *
     * @return $this
     */
    public function setMaasEntityId($maasEntityId);

    /**
     * @param string $stock
     *
     * @return $this
     */
    public function setStock($stock);

    /**
     * @param string $supplyMode
     *
     * @return $this
     */
    public function setSupplyMode($supplyMode);

    /**
     * @param DateTime $synDate
     *
     * @return $this
     */
    public function setSyncDate($synDate);

    /**
     * @param string $deliveries
     *
     * @return $this
     */
    public function setDeliveries($deliveries);
}
