<?php

namespace Maas\Offer\Api\Data;

interface OfferDeliveryInterface
{
    const INVENTORY_ID = "inventory_id";
    const MODE = "mode";
    const MIN_DELAY = "min_delay";
    const MAX_DELAY = "max_delay";
    const SHIPPING_COST = "shipping_cost";
    const ADDITIONAL_SHIPPING_COST = "additional_shipping_cost";

    /**
     * @return int
     */
    public function getInventoryId();
    /**
     * @return string
     */
    public function getMode();

    /**
     * @return int
     */
    public function getMinDelay();

    /**
     * @return int
     */
    public function getMaxDelay();

    /**
     * @return float
     */
    public function getShippingCost();

    /**
     * @return float
     */
    public function getAdditionalShippingCost();

    /**
     * @param int $inventoryId
     * @return $this
     */
    public function setInventoryId($inventoryId);
    /**
     * @param string $mode
     *
     * @return $this
     */
    public function setMode($mode);

    /**
     * @param int $minDelay
     *
     * @return $this
     */
    public function setMinDelay($minDelay);

    /**
     * @param int $maxDelay
     *
     * @return $this
     */
    public function setMaxDelay($maxDelay);

    /**
     * @param float $shippingCost
     *
     * @return $this
     */
    public function setShippingCost($shippingCost);

    /**
     * @param float $additionalShippingCost
     *
     * @return $this
     */
    public function setAdditionalShippingCost($additionalShippingCost);
}
