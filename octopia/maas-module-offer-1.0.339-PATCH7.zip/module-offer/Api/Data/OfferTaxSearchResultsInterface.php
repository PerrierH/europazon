<?php

namespace Maas\Offer\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface OfferTaxSearchResultsInterface
 *
 * @package Maas\Offer\Api\Data
 */
interface OfferTaxSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get offers list.
     *
     * @return OfferTaxInterface[]
     */
    public function getItems();

    /**
     * Set offers list.
     *
     * @param OfferTaxInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
