<?php

namespace Maas\Offer\Console\Command\BestOffer;

use Exception;
use Maas\Core\Console\Command\AbstractParallelEntityProcess;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;
use Maas\Core\Model\Parallelization\Parallelization;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Logger\Logger;
use Maas\Offer\Model\BestOffer as BestOfferModel;
use Maas\Offer\Model\ResourceModel\BestOffer;
use Maas\Offer\Model\Service\BestOffer\ProductUpdate as ProductUpdate;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime as DateTime;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Maas\Log\Model\Error as ErrorLogger;
use Magento\Framework\App\CacheInterface;


/**
 * Class Update
 *
 * @package Maas\Offer\Console\Command\BestOffer
 */
class Update extends AbstractParallelEntityProcess
{
    use Parallelization;

    protected $commandName = 'maas:update:bestoffer';
    protected $commandDescription = 'Update best offer.';
    protected OutputInterface $output;
    protected BestOffer $bestOffer;
    protected ProductUpdate $productUpdate;
    protected ErrorLogger $errorLogger;
    private BestOfferModel $importModel;
    private bool $isStopped = false;
    private array $remaining = [];

    /**
     * @param SerializerInterface $serializer
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param DateTime $dateTime
     * @param CacheInterface $cache
     * @param ConfigProxy $configModel
     * @param BestOfferModel $importModel
     * @param BestOffer $bestOffer
     * @param ProductUpdate $productUpdate
     * @param ErrorLogger $errorLogger
     */
    public function __construct(
        SerializerInterface $serializer,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        DateTime $dateTime,
        CacheInterface $cache,
        ConfigProxy $configModel,
        BestOfferModel $importModel,
        BestOffer $bestOffer,
        ProductUpdate $productUpdate,
        ErrorLogger $errorLogger
    ) {
        $this->importModel = $importModel;
        $this->bestOffer = $bestOffer;
        $this->productUpdate = $productUpdate;
        $this->errorLogger = $errorLogger;
        parent::__construct($serializer, $reportRepository, $reportManagement, $dateTime, $cache, $configModel);
    }

    /**
     * We don't need to test for this function
     * @codeCoverageIgnore
     * @return bool
     */
    protected function isModuleEnabled()
    {
        return $this->configModel->isModuleEnabled();
    }

    /**
     * @param int|null $scheduleId
     * @return ReportInterface
     * @throws Exception
     */
    protected function startReport(?int $scheduleId = null) : ReportInterface
    {
        return $this->importModel->startImportBestOffers($this->getArgsScheduleId($scheduleId));
    }

    /**
     * @inheirtDoc
     */
    protected function runSingleCommand($item, InputInterface $input, OutputInterface $output): void
    {
        $report = $this->getReport();
        $counter = count($item);
        try {
            if ($counter) {
                $data = $this->bestOffer->getOfferEntities($item, $report);
                $this->productUpdate->saveProductData($data, $report);
            } else {
                $this->stopReport($report);
            }
        } catch (Exception $e) {
            $errorMessage = __("Error occurred detail: %1. See logs file for more details.", $e->getMessage());
            $errorLogMessage = __('Trace: %1', $e->getTraceAsString());
            if ($report->getId()) {
                $report->log(__('%1 products not updated', $counter),false, Logger::ERROR);
                $report->log($errorMessage, false, Logger::ERROR);
                $report->setMessage($errorMessage);
                $report->setDeltaErrorItemsCount($counter);
                $this->stopReport($report);
            }
            $this->errorLogger->error($errorMessage);
            $this->errorLogger->error($errorLogMessage);
            $output->writeln('<error>' . $errorMessage->__toString() . '</error>');
        }
        if ($report->getId()) {
            $this->reportRepository->save($report);
        }
    }

    /**
     * @inheirtDoc
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $report = $this->initReport($input);
            $this->remaining = $this->bestOffer->collectOffersData($this->getMax());
            $process = $this->beforeNextProcess($report, '%1 products to update', $input, count($this->remaining));
            if ($process) {
                $execute = parent::execute($input, $output);
                $this->afterNextProcess('%1 Products are updated successfully', '%1 Products not updated error');
                return $execute;
            }
        } catch (\Magento\Framework\Exception\AlreadyExistsException $e) {
            //Nothing to do
            $output->writeln('<error>' . $e->getMessage() .'</error>');
        } catch (\Exception $e) {
            //IF there is an error
            $errorMessage = __("Error occurred detail: %1. See logs file for more details.", $e->getMessage());
            $errorLogMessage = __('Trace: %1', $e->getTraceAsString());
            $report = $this->getReport();
            if ($report->getId()) {
                $report->log("Error occurred.", false, Logger::ERROR);
                $report->log($errorMessage, false, Logger::ERROR);
                $report->setMessage($errorMessage, false, Logger::ERROR);
                $report->setErrorItemsCount($report->getItemsCount() - ($report->getSuccessItemsCount() + $report->getWarningItemsCount()));
                $this->stopReport($report);
            }
            $this->errorLogger->error($errorMessage);
            $this->errorLogger->error($errorLogMessage);
            $output->writeln('<error>' . $errorMessage->__toString() . '</error>');
        }
        return 0;
    }

    /**
     * @inheirtDoc
     */
    protected function fetchItems(InputInterface $input, OutputInterface $output): array
    {
        if ($this->getLimit() == 0) {
            return [$this->remaining];
        }
        return array_chunk($this->remaining, $this->getLimit());
    }

    /**
     * @inheirtDoc
     */
    protected function getLimit() : int
    {
        return $this->configModel->getBestOffersLimit();
    }

    /**
     * @inheirtDoc
     */
    protected function getMax() : int
    {
        return (int)$this->configModel->getBestOffersMax();
    }

    /**
     * @inheirtDoc
     */
    protected function getProcessesNumber() : int
    {
        return $this->configModel->getBestOffersProcessesNumber();
    }

    /**
     * @inheirtDoc
     */
    protected function getReportIdKey() : string
    {
        return BestOfferModel::CACHE_KEY_MAAS_REPORT_ID;
    }

    protected function getStartedImportReportObject() : ?ReportInterface
    {
        return $this->importModel->getStartedImportReportObject();
    }
}
