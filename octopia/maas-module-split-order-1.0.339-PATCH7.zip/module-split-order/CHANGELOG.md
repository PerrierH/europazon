
### [1.0.0] - 11/05/2022
#### Added
- Release module.
