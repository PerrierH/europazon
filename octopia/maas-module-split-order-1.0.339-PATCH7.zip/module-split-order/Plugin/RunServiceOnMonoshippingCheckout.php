<?php

namespace Maas\SplitOrder\Plugin;

use Closure;
use Exception;
use Maas\Sales\Model\Session;
use Maas\SplitOrder\Api\QuoteHandlerInterface;
use Maas\SplitOrder\Helper\Data;
use Maas\SplitOrder\Api\MainOrderIdInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Session\Generic;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote as QuoteEntity;
use Magento\Quote\Model\QuoteManagement;
use Psr\Log\LoggerInterface;

/**
 * Class RunServiceOnMonoshippingCheckout
 * Responsible to split order in mono shipping mode
 * @package Maas\SplitOrder\Plugin
 */
class RunServiceOnMonoshippingCheckout
{
    /**
     * @var CartRepositoryInterface
     */
    private $quoteRepository;

    /**
     * @var Session
     */
    private $maasSession;

    /**
     * @var ManagerInterface
     */
    private $eventManager;

    /**
     * @var Generic
     */
    private $session;

    /**
     * @var Data
     */
    private $helperData;

    /**
     * @var Multishipping
     */
    private $multishipping;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var MainOrderIdInterface
     */
    private $mainOrderId;

    /**
     * @var QuoteHandlerInterface
     */
    protected QuoteHandlerInterface $quoteHandler;

    /**
     * @param CartRepositoryInterface $quoteRepository
     * @param Session $maasSession
     * @param ManagerInterface $eventManager
     * @param Generic $session
     * @param Data $helperData
     * @param LoggerInterface $logger
     * @param MainOrderIdInterface $mainOrderId
     * @param QuoteHandlerInterface $quoteHandler
     * @param Multishipping|null $multishipping
     */
    public function __construct(
        CartRepositoryInterface $quoteRepository,
        Session $maasSession,
        ManagerInterface $eventManager,
        Generic $session,
        Data $helperData,
        LoggerInterface $logger,
        MainOrderIdInterface $mainOrderId,
        QuoteHandlerInterface $quoteHandler,
        Multishipping $multishipping = null
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->maasSession = $maasSession;
        $this->eventManager = $eventManager;
        $this->session = $session;
        $this->helperData = $helperData;
        $this->logger = $logger;
        $this->mainOrderId = $mainOrderId;
        $this->quoteHandler = $quoteHandler;
        $this->multishipping = $multishipping ?: ObjectManager::getInstance()
            ->get(Multishipping::class);
    }

    /**
     * @param QuoteManagement $subject
     * @param Closure $proceed
     * @param QuoteEntity $originalQuote
     * @param array $orderData
     * @return void
     * @throws LocalizedException
     * @throws InputException
     * @throws NoSuchEntityException
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundSubmit(QuoteManagement $subject, Closure $proceed, QuoteEntity $originalQuote, $orderData = [])
    {
        $this->maasSession->clearOrders();
        $shippingAddress= $originalQuote->getShippingAddress();
        $addresses = $this->quoteHandler->normalizeAddressesBySeller($shippingAddress);
        if (
            !$this->helperData->isActive() ||
            $originalQuote->getItemsCount() < 2 ||
            count($addresses) < 2
        ) {
            $monoOrder = $proceed($originalQuote, $orderData);
            $this->mainOrderId->saveUniqueOrderById($monoOrder->getId());
            return $monoOrder;
        }

        try {
            $this->multishipping->createOrders();
        }  catch (LocalizedException $e) {
            $this->session->setIsMultishipping(false);
            throw $e;
        } catch (Exception $e) {
            $this->logger->critical($e);
            $this->session->setIsMultishipping(false);
            throw new LocalizedException(__('Something went wrong with your request. Please try again later?'));
        }
        $this->eventManager->dispatch(
            'checkout_submit_all_after',
            ['orders' => $this->maasSession->getOrders(), 'quote' => $originalQuote]
        );
        return $this->maasSession->getFirstOrder();
    }
}
