<?php

namespace Maas\SplitOrder\Plugin;

use Closure;
use Maas\Sales\Model\Session;
use Maas\SplitOrder\Api\SplitHandlerInterface;
use Maas\SplitOrder\Helper\Data;
use Magento\Framework\Exception\LocalizedException;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;

/**
 * Class RunServiceOnMultishippingCheckout
 * Responsible to split order in multishipping shipping mode
 * @package Maas\SplitOrder\Plugin
 */
class RunServiceOnMultishippingCheckout
{
    /**
     * @var Data
     */
    private $helperData;

    /**
     * @var SplitHandlerInterface
     */
    private $splitHandler;

    /**
     * @var Session
     */
    private $maasSession;

    /**
     * RunServiceOnMultishippingCheckout constructor.
     *
     * @param Data $helperData
     * @param SplitHandlerInterface $splitHandler
     * @param Session $maasSession
     */
    public function __construct(
        Data $helperData,
        SplitHandlerInterface $splitHandler,
        Session $maasSession
    ) {
        $this->helperData = $helperData;
        $this->splitHandler = $splitHandler;
        $this->maasSession = $maasSession;
    }

    /**
     * @param Multishipping $subject
     * @param Closure $proceed
     * @return Multishipping
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundCreateOrders(Multishipping $subject, Closure $proceed)
    {
        $this->maasSession->clearOrders();
        if (!$this->helperData->isActive()) {
            return $proceed();
        }
        return $this->splitHandler->createMultiOrdersFromQuote($subject->getQuote(), $proceed, $subject->getCheckoutSession());
    }
}
