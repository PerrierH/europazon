<?php

namespace Maas\SplitOrder\Plugin;

use Maas\Sales\Model\Session as MaasSession;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Quote\Api\CartItemRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote\ItemFactory;
use Psr\Log\LoggerInterface;

/**
 * Class RestoreOriginalCart
 * Restore the original cart if we catch a payment failed.
 * @package  Maas\SplitOrder\Plugin
 */
class RestoreOriginalCart
{
    /**
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     * @var ItemFactory
     */
    private $quoteItemFactory;

    /**
     * @var CartItemRepositoryInterface
     */
    private $quoteItemRepository;

    /**
     * @var MaasSession
     */
    private $maasSession;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * RestoreOriginalCart constructor
     *
     * @param CartRepositoryInterface $quoteRepository
     * @param ItemFactory $quoteItemFactory
     * @param CartItemRepositoryInterface $quoteItemRepository
     * @param MaasSession $maasSession
     * @param LoggerInterface $logger
     */
    public function __construct(
        CartRepositoryInterface $quoteRepository,
        ItemFactory $quoteItemFactory,
        CartItemRepositoryInterface $quoteItemRepository,
        MaasSession $maasSession,
        LoggerInterface $logger
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->quoteItemFactory = $quoteItemFactory;
        $this->quoteItemRepository = $quoteItemRepository;
        $this->maasSession = $maasSession;
        $this->logger = $logger;
    }

    /**
     * @param CheckoutSession $subject
     * @return bool|void
     */
    public function beforeRestoreQuote(CheckoutSession $subject)
    {
        try {
            if ($this->maasSession->hasOriginalCartId()) {
                $quote = $this->quoteRepository->get($this->maasSession->getOriginalCartId());
                if ($quote && $quote->getId()) {
                    $quote->setIsActive(1)->setReservedOrderId(null);
                    $this->quoteRepository->save($quote);
                    $subject->replaceQuote($quote);
                    $subject->unsLastRealOrderId();
                    $this->maasSession->unsOriginalCartId();
                    return true;
                }
            }
        } catch (\Exception $e) {
            $this->logger->critical($e);
        }
    }
}
