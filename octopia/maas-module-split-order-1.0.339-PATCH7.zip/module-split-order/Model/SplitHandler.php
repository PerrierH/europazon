<?php

namespace Maas\SplitOrder\Model;

use Closure;
use Maas\Sales\Api\Data\SalesQuoteInfoInterfaceFactory;
use Maas\Sales\Api\SalesQuoteInfoRepositoryInterface;
use Maas\Sales\Model\Session;
use Maas\SplitOrder\Api\MainOrderIdInterface;
use Maas\SplitOrder\Api\QuoteHandlerInterface;
use Maas\SplitOrder\Api\ShippingHandlerInterface;
use Maas\SplitOrder\Api\SplitHandlerInterface;
use Maas\SplitOrder\Helper\Data;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Session\Generic;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\CartExtensionInterfaceFactory;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\AddressFactory;
use Magento\Quote\Model\QuoteFactory;
use Magento\Quote\Api\CartManagementInterface;
use Magento\SalesRule\Model\Coupon\Quote\UpdateCouponUsages;
use Magento\Tax\Model\Calculation;
use Magento\Tax\Model\Config as ConfigTax;
use Psr\Log\LoggerInterface;

/**
 * Class SplitHandler
 * Responsible to do split from given quote
 * @package Maas\SplitOrder\Model
 */
class SplitHandler implements SplitHandlerInterface
{
    /**
     * @var MainOrderId
     */
    private $mainOrderIdService;

    /**
     * @var ManagerInterface|null
     */
    protected $eventManager;

    /**
     * @var Session
     */
    private $maasSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @var Generic
     */
    private $session;

    /**
     * @var Data
     */
    private $helperData;

    /**
     * @var QuoteHandlerInterface
     */
    private $quoteHandler;

    /**
     * @var QuoteFactory
     */
    private $quoteFactory;

    /**
     * @var AddressRepositoryInterface
     */
    protected $addressRepository;

    /**
     * @var AddressFactory
     */
    private $addressFactory;

    /**
     * @var CartRepositoryInterface
     */
    private $quoteRepository;

    /**
     * @var AddressesRegistry
     */
    private $addressesRegistry;

    /**
     * @var ShippingHandlerInterface
     */
    private $shippingHandler;

    /**
     * @var MainOrderId
     */
    private $mainOrderId;

    /**
     * @var UpdateCouponUsages
     */
    private $updateCouponUsages;

    /**
     * @var ConfigTax
     */
    protected $config;

    /**
     * @var Calculation
     */
    private $taxCalculation;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var SalesQuoteInfoInterfaceFactory
     */
    private $salesQuoteInfoInterfaceFactory;

    /**
     * @var CartExtensionInterfaceFactory
     */
    private $salesQuoteExtensionFactory;

    /**
     * @param MainOrderIdInterface $mainOrderIdService
     * @param ManagerInterface $eventManager
     * @param Session $maasSession
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param Generic $session
     * @param Data $helperData
     * @param QuoteHandlerInterface $quoteHandler
     * @param QuoteFactory $quoteFactory
     * @param AddressRepositoryInterface $addressRepository
     * @param AddressFactory $addressFactory
     * @param CartRepositoryInterface $quoteRepository
     * @param AddressesRegistry $addressesRegistry
     * @param ShippingHandlerInterface $shippingHandler
     * @param MainOrderIdInterface $mainOrderId
     * @param UpdateCouponUsages $updateCouponUsages
     * @param ConfigTax $taxConfig
     * @param Calculation $taxCalculation
     * @param LoggerInterface $logger
     * @param SalesQuoteInfoInterfaceFactory $salesQuoteInfoInterfaceFactory
     * @param CartExtensionInterfaceFactory $salesQuoteExtensionFactory
     */
    public function __construct(
        MainOrderIdInterface $mainOrderIdService,
        ManagerInterface $eventManager,
        Session $maasSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        Generic $session,
        Data $helperData,
        QuoteHandlerInterface $quoteHandler,
        QuoteFactory $quoteFactory,
        AddressRepositoryInterface $addressRepository,
        AddressFactory $addressFactory,
        CartRepositoryInterface $quoteRepository,
        AddressesRegistry $addressesRegistry,
        ShippingHandlerInterface $shippingHandler,
        MainOrderIdInterface $mainOrderId,
        UpdateCouponUsages $updateCouponUsages,
        ConfigTax $taxConfig,
        Calculation $taxCalculation,
        LoggerInterface $logger,
        SalesQuoteInfoInterfaceFactory $salesQuoteInfoInterfaceFactory,
        CartExtensionInterfaceFactory $salesQuoteExtensionFactory
    ) {
        $this->mainOrderIdService = $mainOrderIdService;
        $this->eventManager = $eventManager;
        $this->maasSession = $maasSession;
        $this->checkoutSession = $checkoutSession;
        $this->session = $session;
        $this->helperData = $helperData;
        $this->quoteHandler = $quoteHandler;
        $this->quoteFactory = $quoteFactory;
        $this->addressRepository = $addressRepository;
        $this->addressFactory = $addressFactory;
        $this->quoteRepository = $quoteRepository;
        $this->addressesRegistry = $addressesRegistry;
        $this->shippingHandler = $shippingHandler;
        $this->mainOrderId = $mainOrderId;
        $this->updateCouponUsages = $updateCouponUsages;
        $this->config = $taxConfig;
        $this->taxCalculation = $taxCalculation;
        $this->logger = $logger;
        $this->salesQuoteInfoInterfaceFactory = $salesQuoteInfoInterfaceFactory;
        $this->salesQuoteExtensionFactory = $salesQuoteExtensionFactory;
    }

    /**
     * @inheirtDoc
     */
    public function createMultiOrdersFromQuote($originalQuote, Closure $proceed, $checkoutSession)
    {
        if (!$this->helperData->isActive()) {
            return $proceed();
        }
        $this->session->setIsMultishipping(true);
        $originalQuoteId = $originalQuote->getId();
        try {
            $this->updateCouponUsages($originalQuote);
            $newQuote = $this->duplicateOriginalQuote($originalQuote);
            $shippingAddresses = $originalQuote->getAllShippingAddresses();
            if ($originalQuote->hasVirtualItems()) {
                $shippingAddresses[] = $originalQuote->getBillingAddress();
            }
            //array to store the original addresses information
            $originalAddresses = [];

            //preparation of addresses
            foreach ($shippingAddresses as $shippingAddress) {
                if (!$this->addressesRegistry->isRegistredAddressId($shippingAddress->getId())) {
                    // Save new address book
                    if ($shippingAddress->getSaveInAddressBook()) {
                        $shippingAddressData = $shippingAddress->exportCustomerAddress();
                        $shippingAddressData->setCustomerId($originalQuote->getCustomerId());
                        $this->addressRepository->save($shippingAddressData);
                        $originalQuote->addCustomerAddress($shippingAddressData);
                        $shippingAddress->setCustomerAddressData($shippingAddressData);
                        $shippingAddress->setCustomerAddressId($shippingAddressData->getId());
                    }
                    $shippingTaxPercent = $this->getShippingTaxPercent($shippingAddress);
                    $addresses = $this->quoteHandler->normalizeAddressesBySeller($shippingAddress);
                    $addressData = $shippingAddress->getData();
                    unset($addressData['address_id']);
                    $addressData['quote_id'] = $newQuote->getId();
                    try {
                        if ($addressData['customer_address_id']) {
                            $address = $this->addressRepository->getById($addressData['customer_address_id']);
                        } else {
                            $address = $shippingAddress->getDataModel();
                        }
                        foreach ($addresses as $items) {
                            if (count($items)) {
                                //create the new address
                                $splitAddress = $this->addressFactory->create();
                                if (isset($address)) {
                                    $splitAddress->importCustomerAddressData($address);
                                } else {
                                    $splitAddress->setData($addressData);
                                }
                                $this->quoteHandler->populateAddress($splitAddress, $addressData, $shippingTaxPercent, $items, $newQuote);
                                $originalAddresses[$splitAddress->getId()] = $splitAddress->getData();
                                $this->addressesRegistry->registerAddressId($splitAddress->getId());
                            }
                        }
                        // phpcs:ignore Magento2.CodeAnalysis.EmptyBlock
                    } catch (\Exception $e) {
                        continue;
                    }
                }
            }
            //Recollect quote after adding addresses
            $newQuote->setTotalsCollectedFlag(false)->collectTotals();
            $newQuote = $this->shippingHandler->prepareShippingAssignment($newQuote);
            $this->quoteRepository->save($newQuote);
            $this->eventManager->dispatch('checkout_type_multishipping_set_shipping_items', ['quote' => $newQuote]);
            //Restore original address data
            foreach ($newQuote->getAllShippingAddresses() as &$address) {
                if (isset($originalAddresses[$address->getId()])) {
                    $addressData = $originalAddresses[$address->getId()];
                    $address->setBaseDiscountAmount($addressData['base_discount_amount']);
                    $address->setDiscountAmount($addressData['discount_amount']);
                    $address->setBaseDiscountTaxCompensationAmount($addressData['base_discount_tax_compensation_amount']);
                    $address->setDiscountTaxCompensationAmount($addressData['discount_tax_compensation_amount']);
                    $address->setBaseShippingAmount($addressData['base_shipping_amount']);
                    $address->setShippingAmount($addressData['shipping_amount']);
                    $address->setBaseShippingInclTax($addressData['base_shipping_incl_tax']);
                    $address->setShippingInclTax($addressData['shipping_incl_tax']);
                    $address->setBaseShippingTaxAmount($addressData['base_shipping_tax_amount']);
                    $address->setShippingTaxAmount($addressData['shipping_tax_amount']);
                    $address->setBaseShippingTaxAmount($addressData['base_shipping_tax_amount']);
                    $address->setShippingTaxAmount($addressData['shipping_tax_amount']);
                    $address->setBaseShippingDiscountTaxCompensationAmnt($addressData['base_shipping_discount_tax_compensation_amnt']);
                    $address->setShippingDiscountTaxCompensationAmount($addressData['shipping_discount_tax_compensation_amount']);
                    $address->setBaseShippingDiscountAmount($addressData['base_shipping_discount_amount']);
                    $address->setShippingDiscountAmount($addressData['shipping_discount_amount']);
                    $address->setGrandTotal($address->getSubtotalInclTax() + $address->getShippingInclTax() + $address->getDiscountAmount());
                }
            }
            //Replace with the new quote
            $checkoutSession->replaceQuote($newQuote);
            //Execute the original behavior
            $originalReturn = $proceed();

            //Success
            //Restore the information of the new quote
            $originalQuote = $this->quoteRepository->get($originalQuoteId);
            $newQuote->setIsMultiShipping($originalQuote->getIsMultiShipping());
            $newQuote->setIsActive(false);
            $this->quoteRepository->save($newQuote);
            $originalQuote->setIsActive(false);
            $this->quoteRepository->save($originalQuote);

            //get orders from session
            $orderIds = array_flip($this->session->getOrderIds());
            $firstOrderId = reset(  $orderIds);
            $this->maasSession->setOrders($this->session->getOrderIds());
            if ($orderIds) {
                $this->mainOrderId->setMainOrderByIds($orderIds);
            }
            $this->maasSession->setFirstOrderId($firstOrderId);
            $this->checkoutSession->setLastQuoteId($originalQuoteId);
            $this->session->setIsMultishipping(false);
            $this->eventManager->dispatch(
                'maas_multishipping_checkout_submit_all_after',
                ['orders' => $orderIds]
            );
            return $originalReturn;
        }
        catch (\Exception $e) {
            $originalQuote = $this->quoteRepository->get($originalQuoteId);
            $checkoutSession->replaceQuote($originalQuote);
            throw $e;
        }
    }

    /**
     * The duplication of the quote to keep the original one to restore in case of error
     * @param Quote $originalQuote
     * @return Quote
     * @throws LocalizedException
     */
    private function duplicateOriginalQuote(Quote $originalQuote)
    {
        /** @var Quote $quote */
        $this->maasSession->setOriginalCartId($originalQuote->getId());
        $newQuote = $this->quoteFactory->create();
        $originalQuoteData =  $originalQuote->getData();
        $items = $originalQuote->getAllItems();
        unset($originalQuoteData['entity_id']);
        unset($originalQuoteData['items']);
        $originalQuoteData['is_active'] = false;
        $originalQuoteData['items_count'] =  count($originalQuote->getAllVisibleItems());
        $newQuote->setData($originalQuoteData);
        foreach ($items as $quoteItem) {
            $quoteItem->setId(null);
            $quoteItem->setQtyToAdd(0);
            $newQuote->addItem($quoteItem);
        }
        $newQuote->setItemsCount(count($newQuote->getAllVisibleItems()));
        $newQuote->setItems($newQuote->getItems());
        $paymentMethod = $originalQuote->getPayment();
        $payment = $originalQuote->getPayment()->getMethod();
        $quotePayment = $newQuote->getPayment();
        $quotePayment->setMethod($payment);
        if ($paymentMethod) {
            $newQuote->setTotalsCollectedFlag(true);
            $quotePayment->setQuote($newQuote);
            $data = $paymentMethod->getData();
            $quotePayment->importData($data);
        }
        $billingAddressData = $originalQuote->getBillingAddress()->getData();
        unset($billingAddressData['id']);
        unset($billingAddressData['quote_id']);
        $newQuote->getBillingAddress()->setData($billingAddressData);

        $newQuote->setIsMultiShipping(true);
        $newQuote->setIsSuperMode(true);

        //Set the original quote id
        $newQuoteExtensionAttributes = $newQuote->getExtensionAttributes();
        $newQuoteExtensionAttributes = $newQuoteExtensionAttributes ? $newQuoteExtensionAttributes : $this->salesQuoteExtensionFactory->create();
        $quoteExtraInfo = $newQuoteExtensionAttributes->getExtraInfo();
        $quoteExtraInfo = $quoteExtraInfo ? $quoteExtraInfo : $this->salesQuoteInfoInterfaceFactory->create();
        $quoteExtraInfo->setOriginalQuoteId($originalQuote->getId());
        $newQuoteExtensionAttributes->setData('extra_info', $quoteExtraInfo);
        $newQuote->setExtensionAttributes($newQuoteExtensionAttributes);
        $this->quoteRepository->save($newQuote);

        return $newQuote;
    }

    /**
     * Get the percent of shipping tax
     *
     * @param Address $shippingAddress
     * @return float
     */
    private function getShippingTaxPercent(Address $shippingAddress): float
    {
        $shippingTaxClass = $this->config->getShippingTaxClass();
        $store  = $shippingAddress->getQuote()->getStore();
        $request = $this->taxCalculation->getRateRequest($shippingAddress, null, null, $store);
        return $this->taxCalculation->getRate($request->setProductClassId($shippingTaxClass));
    }

    /**
     * @param $quote
     * @throws NoSuchEntityException
     */
    private function updateCouponUsages($quote)
    {
        /* if coupon code has been canceled then need to notify the customer */
        if (!$quote->getCouponCode() && $quote->dataHasChangedFor('coupon_code')) {
            throw new NoSuchEntityException(__("The coupon code isn't valid. Verify the code and try again."));
        }

        $this->updateCouponUsages->execute($quote, true);
    }
}
