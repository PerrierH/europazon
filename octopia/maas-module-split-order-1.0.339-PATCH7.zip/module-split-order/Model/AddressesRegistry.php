<?php

namespace Maas\SplitOrder\Model;

/**
 * Class AddressesRegistry
 *
 * Used during the creation of multiple orders to retain the IDs of carts split from the initial cart.
 * These carts return "true" if "getIsActive" is called.
 *
 * @package Maas\Sales\Model
 */
class AddressesRegistry
{
    /**
     * @var array
     */
    protected $addressesIds = [];

    /**
     * @param int $addressId
     *
     * @return $this
     */
    public function registerAddressId($addressId)
    {
        $this->addressesIds[] = $addressId;
        return $this;
    }

    /**
     * @param int $addressId
     *
     * @return bool
     */
    public function isRegistredAddressId($addressId)
    {
        return in_array($addressId, $this->addressesIds);
    }
}
