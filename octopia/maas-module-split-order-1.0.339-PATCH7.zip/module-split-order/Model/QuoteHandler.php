<?php

namespace Maas\SplitOrder\Model;

use Exception;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Session\Generic;
use Magento\Quote\Api\CartManagementInterface;
use Magento\Customer\Api\Data\GroupInterface;
use Maas\SplitOrder\Api\QuoteHandlerInterface;
use Maas\SplitOrder\Helper\Data as HelperData;
use Maas\SplitOrder\Api\ExtensionAttributesInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Store\Api\Data\StoreInterface;
use Magento\Weee\Helper\Data;

/**
 * Class QuoteHandler
 * Responsible to build some methods from the quote.
 */
class QuoteHandler implements QuoteHandlerInterface
{
    /**
     * @var Session
     */
    private $checkoutSession;

    /**
     * @var Data
     */
    private $helperData;

    /**
     * @var Data
     */
    protected $weeeHelper;

    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributesService;

    /**
     * @var AddressItem
     */
    private $addressItemService;

    /**
     * @var Generic
     */
    private $session;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    private $orderFactory;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper|null
     */
    private $dataObjectHelper;

    /**
     * @var Address\ToOrder
     */
    private $quoteAddressToOrder;

    /**
     * @var Quote\Payment\ToOrderPayment
     */
    private $quotePaymentToOrderPayment;

    /**
     * @var Item\ToOrderItem
     */
    private $quoteItemToOrderItem;

    /**
     * @var Address\ToOrderAddress
     */
    private $quoteAddressToOrderAddress;

    /**
     * @var PriceCurrencyInterface
     */
    private $priceCurrency;

    /**
     * QuoteHandler constructor.
     * @param CheckoutSession $checkoutSession
     * @param HelperData $helperData
     * @param Data $weeeHelper
     * @param ExtensionAttributes $extensionAttributesService
     * @param AddressItem $addressItemService
     * @param Generic $session
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param Address\ToOrder $quoteAddressToOrder
     * @param Address\ToOrderAddress $quoteAddressToOrderAddress
     * @param Quote\Payment\ToOrderPayment $quotePaymentToOrderPayment
     * @param Item\ToOrderItem $quoteItemToOrderItem
     * @param PriceCurrencyInterface $priceCurrency
     * @param \Magento\Framework\Api\DataObjectHelper|null $dataObjectHelper
     */
    public function __construct(
        CheckoutSession $checkoutSession,
        HelperData $helperData,
        Data $weeeHelper,
        ExtensionAttributes $extensionAttributesService,
        AddressItem $addressItemService,
        Generic $session,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Quote\Model\Quote\Address\ToOrder $quoteAddressToOrder,
        \Magento\Quote\Model\Quote\Address\ToOrderAddress $quoteAddressToOrderAddress,
        \Magento\Quote\Model\Quote\Payment\ToOrderPayment $quotePaymentToOrderPayment,
        \Magento\Quote\Model\Quote\Item\ToOrderItem $quoteItemToOrderItem,
        PriceCurrencyInterface $priceCurrency,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper = null
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->helperData = $helperData;
        $this->weeeHelper = $weeeHelper;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->addressItemService = $addressItemService;
        $this->session = $session;
        $this->orderFactory = $orderFactory;
        $this->quoteAddressToOrder = $quoteAddressToOrder;
        $this->quoteAddressToOrderAddress = $quoteAddressToOrderAddress;
        $this->quotePaymentToOrderPayment = $quotePaymentToOrderPayment;
        $this->quoteItemToOrderItem = $quoteItemToOrderItem;
        $this->priceCurrency = $priceCurrency;
        $this->dataObjectHelper = $dataObjectHelper ?: ObjectManager::getInstance()
            ->get(\Magento\Framework\Api\DataObjectHelper::class);
    }

    /**
     * @inheritdoc
     */
    public function normalizeAddressesBySeller($shippingAddress)
    {
        $groups = [];
        foreach ($shippingAddress->getAllItems() as $item) {
            $this->getSplittedItems($item, $groups);
        }
        // If order have more than one different attribute values.
        if (count($groups) > 0) {
            return $groups;
        }
        return false;
    }

    /**
     * @param CartItemInterface|Quote\Address\Item $item
     * @param array $groups
     * @return void
     */
    private function getSplittedItems($item, array &$groups)
    {
        $criterion = 0;
        $extraInfo = null;
        if ($item instanceof Quote\Address\Item) {
            $extraInfo = $this->addressItemService->loadExtraInfo($item);
        } else {
            $itemExtension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
            if ($itemExtension) {
                $extraInfo = $itemExtension->getExtraInfo();
            }
        }
        if ($extraInfo && $extraInfo->getSellerId()) {
            $criterion = $extraInfo->getSellerId();
        }
        $groups[$criterion][] = $item;
    }

    /**
     * @inheritdoc
     */
    public function collectAddressesData($quote, $shippingCustomerAddressId = 0)
    {
        $billing = $quote->getBillingAddress()->getData();
        unset($billing['id']);
        unset($billing['quote_id']);

        $shipping = $quote->getShippingAddress()->getData();
        foreach ($quote->getAllShippingAddresses() as $address) {
            if ($shippingCustomerAddressId == $address->getCustomerAddressId()) {
                $shipping = $address->getData();
                break;
            }
        }
        unset($shipping['id']);
        unset($shipping['quote_id']);

        return [
            'payment' => $quote->getPayment()->getMethod(),
            'billing' => $billing,
            'shipping' => $shipping
        ];
    }

    /**
     * @inheritdoc
     */
    public function setCustomerData($quote, $split)
    {
        $split->setStoreId($quote->getStoreId());
        $split->setCustomer($quote->getCustomer());
        $split->setCustomerIsGuest($quote->getCustomerIsGuest());

        if ($quote->getCheckoutMethod() === CartManagementInterface::METHOD_GUEST) {
            $split->setCustomerId(null);
            $split->setCustomerEmail($quote->getBillingAddress()->getEmail());
            $split->setCustomerIsGuest(true);
            $split->setCustomerGroupId(GroupInterface::NOT_LOGGED_IN_ID);
        }
        return $this;
    }


    /**
     * @inheritdoc
     */
    public function populateAddress($address, $originalAddressData, $shippingTaxPercent, $items, $quote)
    {
        if (isset($originalAddressData['applied_rule_ids'])) {
            $address->setAppliedRuleId($originalAddressData['applied_rule_ids']);
        }
        if (isset($originalAddressData['address_sales_rule_id'])) {
            $address->setAddressSalesRuleId($originalAddressData['address_sales_rule_id']);
        }
        if (isset($originalAddressData['coupon_code'])) {
            $address->setCouponCode($originalAddressData['coupon_code']);
        }
        if (isset($originalAddressData['extension_attributes'])) {
            $address->setExtensionAttributes($originalAddressData['extension_attributes']);
        }
        if (isset($originalAddressData['shipping_method'])) {
            $address->setShippingMethod($originalAddressData['shipping_method']);
        }
        if (isset($originalAddressData['discount_description'])) {
            $address->setDiscountDescription($originalAddressData['discount_description']);
        }
        $discount = 0.0;
        $baseDiscount = 0.0;
        $discountTaxCompensationAmount = 0.0;
        $baseDiscountTaxCompensationAmount = 0.0;
        $shippingInclTax = 0.0;
        $baseShippingInclTax = 0.0;
        $shippingDiscount = 0.0;
        $baseShippingDiscount = 0.0;
        $shippingDiscountTaxCompensationAmount = 0.0;
        $baseShippingDiscountTaxCompensationAmount = 0.0;
        $weeeInclTax = 0.00;
        foreach ($items as $item) {
            // Add item by item.
            $baseDiscount += $item->getData('base_discount_amount');
            $discount += $item->getData('discount_amount');
            $baseDiscountTaxCompensationAmount += $item->getData('base_discount_tax_compensation_amount');
            $discountTaxCompensationAmount += $item->getData('discount_tax_compensation_amount');
            $extraInfo = null;
            if ($item instanceof Quote\Address\Item) {
                $extraInfo = $this->addressItemService->loadExtraInfo($item);
                $quoteItem = $item->getQuoteItem();
            } else {
                $quoteItem = $item;
                if ($quoteItem->getExtensionAttributes()) {
                    $extraInfo = $quoteItem->getExtensionAttributes()->getExtraInfo();
                }
            }
            $qty = ($item->getQty() - $item->getQtyToAdd());
            if ($extraInfo) {
                $shippingInclTax += $extraInfo->getShippingAmount() * $qty;
                $baseShippingInclTax += $extraInfo->getShippingAmount() * $qty;
                $shippingDiscount += $extraInfo->getDiscountedShippingAmount() * $qty;
                $baseShippingDiscount += $extraInfo->getDiscountedShippingAmount() * $qty;
            }
            if ($quoteItem) {
                $address->addItem($quoteItem, $qty);
            } else {
                $address->addItem($item);
            }
            //WeeeTaxes
            $weeeInclTax += $this->weeeHelper->getRowWeeeTaxInclTax($quoteItem);
        }
        $shipping = ($shippingInclTax / (100 + $shippingTaxPercent)) * 100;
        $baseShipping = ($baseShippingInclTax / (100 + $shippingTaxPercent)) * 100;
        $shippingTax = $shippingInclTax - $shipping;
        $baseShippingTax = $baseShippingInclTax - $baseShipping;
        if ($baseShippingDiscount) {
            $baseDiscount += $baseShippingDiscount;
            $baseShippingDiscountTaxCompensationAmount = round($shippingDiscount - ($shippingDiscount / (1 + ($shippingTaxPercent / 100))), 4);
        }
        if ($shippingDiscount) {
            $discount += $shippingDiscount;
            $shippingDiscountTaxCompensationAmount = round($shippingDiscount - ($shippingDiscount / (1 + ($shippingTaxPercent / 100))), 4);
        }
        $address->setBaseDiscountAmount(-$baseDiscount);
        $address->setDiscountAmount(-$discount);
        $address->setBaseDiscountTaxCompensationAmount(-$baseDiscountTaxCompensationAmount);
        $address->setDiscountTaxCompensationAmount(-$discountTaxCompensationAmount);
        $address->setBaseShippingAmount($baseShipping);
        $address->setShippingAmount($shipping);
        $address->setBaseShippingInclTax($baseShippingInclTax);
        $address->setShippingInclTax($shippingInclTax);
        $address->setBaseShippingTaxAmount($baseShippingTax);
        $address->setShippingTaxAmount($shippingTax);
        $address->setBaseShippingDiscountTaxCompensationAmnt($baseShippingDiscountTaxCompensationAmount);
        $address->setShippingDiscountTaxCompensationAmount($shippingDiscountTaxCompensationAmount);
        $address->setBaseShippingDiscountAmount($baseShippingDiscount);
        $address->setShippingDiscountAmount($shippingDiscount);
        $address->setWeeeInclTax($weeeInclTax);
        $address->setCollectShippingRates(true);
        $quote->addShippingAddress($address);
        $address->save();
    }

    /**
     * @inheritdoc
     */
    public function defineSessions($split, $order, $orderIds)
    {
        $this->checkoutSession->setLastQuoteId($split->getId());
        $this->checkoutSession->setLastSuccessQuoteId($split->getId());

        return $this;
    }
}
