<?php

namespace Maas\SplitOrder\Model;

use Maas\Sales\Api\Data\SalesOrderInfoInterfaceFactory;
use Maas\Sales\Api\SalesOrderInfoRepositoryInterface;
use Maas\SplitOrder\Api\MainOrderIdInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class MainOrderId
 * @package Maas\SplitOrder\Model
 */
class MainOrderId implements MainOrderIdInterface
{
    private SalesOrderInfoRepositoryInterface $salesOrderInfoRepository;
    private SalesOrderInfoInterfaceFactory $salesOrderInfoFactory;
    private OrderRepositoryInterface $orderRepository;
    private SearchCriteriaBuilder $searchCriteriaBuilder;
    protected ManagerInterface $eventManager;

    /**
     * MainOrderId constructor.
     *
     * @param SalesOrderInfoRepositoryInterface $salesOrderInfoRepository
     * @param SalesOrderInfoInterfaceFactory $salesOrderInfoFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param ManagerInterface $eventManager
     */
    public function __construct(
        SalesOrderInfoRepositoryInterface $salesOrderInfoRepository,
        SalesOrderInfoInterfaceFactory $salesOrderInfoFactory,
        OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        ManagerInterface $eventManager
    ) {
        $this->salesOrderInfoRepository = $salesOrderInfoRepository;
        $this->salesOrderInfoFactory = $salesOrderInfoFactory;
        $this->orderRepository = $orderRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->eventManager = $eventManager;
    }

    /**
     * @param OrderInterface $mainOrder
     * @param OrderInterface[] $orders
     *
     * @return $this
     */
    protected function setMainOrder(OrderInterface $mainOrder, array $orders): MainOrderId
    {
        $mainOrderId = $mainOrder->getId();
        $mainOrderIncrementId = $mainOrder->getIncrementId();
        foreach ($orders as $order) {
            try {
                $orderInfo = $this->salesOrderInfoRepository->get($order->getId());

            } catch (NoSuchEntityException $e) {
                $orderInfo = $this->salesOrderInfoFactory->create();
                $orderInfo->setId($order->getId());
            }
            $orderInfo->setMainOrderId($mainOrderId);
            $orderInfo->setMainOrderIncrementId($mainOrderIncrementId);
            $orderInfo = $this->salesOrderInfoRepository->save($orderInfo);
            $orderExtensionAttributes = $order->getExtensionAttributes();
            if ($orderExtensionAttributes) {
                $orderExtensionAttributes->setExtraInfo($orderInfo);
                $order->setExtensionAttributes($orderExtensionAttributes);
            }
            $this->eventManager->dispatch('maas_sales_order_child_order', [
                'child_order_id' => $order->getId(),
                'main_order_id' => $mainOrderId,
                'child_order_increment_id' => $order->getIncrementId(),
                'main_order_increment_id' => $mainOrderIncrementId,
            ]);
        }
        $this->eventManager->dispatch('maas_sales_order_main_order', [
            'main_order_id' => $mainOrderId,
            'main_order_increment_id' => $mainOrderIncrementId
        ]);
        return $this;
    }

    /**
     * @inerhitDoc
     */
    public function saveUniqueOrderById(int $mainOrderId): MainOrderIdInterface
    {
        $order = $this->orderRepository->get($mainOrderId);
        $this->setMainOrder($order, [$order]);
        return $this;
    }

    /**
     * @inerhitDoc
     */
    public function setMainOrderByIds(array $orderIds): MainOrderIdInterface
    {
        $orders = $this->orderRepository
            ->getList($this->searchCriteriaBuilder->addFilter('entity_id', $orderIds, 'in')->create())
            ->getItems();
        $this->setMainOrder(reset($orders), $orders);
        return $this;
    }
}
