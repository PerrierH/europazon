<?php

namespace Maas\SplitOrder\Model\Checkout\Type\Rewrite;

use Magento\Checkout\Exception;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\ObjectManager;
use Magento\Quote\Model\Quote\Address;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order;
use Magento\Quote\Model\Quote;

/**
 * Class RunServiceOnMultishippingCheckout
 * @package Maas\SplitOrder\Plugin
 */
class Multishipping extends \Magento\Multishipping\Model\Checkout\Type\Multishipping
{
    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper = null;

    /**
     * Prepare order based on quote address
     *
     * @param   Address $address
     * @return  Order
     * @throws  Exception
     */
    protected function _prepareOrder(Address $address)
    {
        $quote = $this->getQuote();
        $quote->unsReservedOrderId();
        $quote->reserveOrderId();
        $quote->collectTotals();

        $order = $this->_orderFactory->create();

        /** @var DataObjectHelper $dataObjectHelper */
        $dataObjectHelper = $this->dataObjectHelper ?: ObjectManager::getInstance()
            ->get(DataObjectHelper::class);
        $dataObjectHelper->mergeDataObjects(
            OrderInterface::class,
            $order,
            $this->quoteAddressToOrder->convert($address)
        );
        $order->setCouponCode($address->getCouponCode());

        $order->setQuote($quote);
        $order->setBillingAddress($this->quoteAddressToOrderAddress->convert($quote->getBillingAddress()));

        if ($address->getAddressType() == 'billing') {
            $order->setIsVirtual(1);
        } else {
            $order->setShippingAddress($this->quoteAddressToOrderAddress->convert($address));
            $order->setShippingMethod($address->getShippingMethod());
        }

        $order->setPayment($this->quotePaymentToOrderPayment->convert($quote->getPayment()));
        if ($this->priceCurrency->round($address->getGrandTotal()) == 0) {
            $order->getPayment()->setMethod('free');
        }
        $order->setShippingTaxAmount($address->getShippingInclTax() - $address->getShippingAmount());

        foreach ($address->getAllItems() as $item) {
            if ($item instanceof Quote\Address\Item) {
                $_quoteItem = $item->getQuoteItem();
            }else{
                $_quoteItem = $item;
            }
            if (!$_quoteItem) {
                throw new Exception(
                    __("The item isn't found, or it's already ordered.")
                );
            }
            $item->setProductType(
                $_quoteItem->getProductType()
            )->setProductOptions(
                $_quoteItem->getProduct()->getTypeInstance()->getOrderOptions($_quoteItem->getProduct())
            );
            $orderItem = $this->quoteItemToOrderItem->convert($item);
            if ($item->getParentItem()) {
                $orderItem->setParentItem($order->getItemByQuoteItemId($_quoteItem->getParentItem()->getId()));
            }
            $order->addItem($orderItem);
        }

        return $order;
    }
}
