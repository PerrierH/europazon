# Maas SplitOrder

## Purpose

This module manages the split of octopia marketplace orders by seller.

