<?php

namespace Maas\SplitOrder\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

/**
 * Class Data.
 * @package Maas\SplitOrder\Helper
 */
class Data extends AbstractHelper
{
    /**
     * Check if module is active.
     * @return bool
     */
    public function isActive()
    {
        return (bool) $this->scopeConfig->isSetFlag('maas_orders/split_order/active');
    }
}
