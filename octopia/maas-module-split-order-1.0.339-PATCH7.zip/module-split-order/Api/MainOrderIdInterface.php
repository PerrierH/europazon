<?php

namespace Maas\SplitOrder\Api;

interface MainOrderIdInterface
{

    /**
     * @param int $mainOrderId
     *
     * @return $this
     * @codeCoverageIgnore No logic in the method
     */
    public function saveUniqueOrderById(int $mainOrderId): MainOrderIdInterface;

    /**
     * @param int[] $orderIds
     *
     * @return $this
     * @codeCoverageIgnore No logic in the method
     */
    public function setMainOrderByIds(array $orderIds): MainOrderIdInterface;
}