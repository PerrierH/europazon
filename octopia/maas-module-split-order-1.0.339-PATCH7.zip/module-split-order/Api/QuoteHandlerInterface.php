<?php

namespace Maas\SplitOrder\Api;

use Magento\Framework\Model\AbstractExtensibleModel;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Sales\Api\Data\OrderInterface;

/**
 * Interface QuoteHandlerInterface
 * @api
 * @package Maas\SplitOrder\Api
 */
interface QuoteHandlerInterface
{
    /**
     * Separate all addresses items in quote into new adresses by seller.
     *
     * @param Address $shippingAddress
     * @return bool|array False if not split, or an array of split items
     */
    public function normalizeAddressesBySeller($shippingAddress);

    /**
     * Collect list of data addresses.
     *
     * @param Quote $quote
     * @param int $shippingCustomerAddressId
     * @return array
     */
    public function collectAddressesData($quote, $shippingCustomerAddressId);

    /**
     * @param Quote $quote
     * @param Quote $split
     * @return \Magestat\SplitOrder\Api\QuoteHandlerInterface
     */
    public function setCustomerData($quote, $split);

    /**
     * Populate address with new data.
     *
     * @param Address $address
     * @param array $originalAddressData
     * @param float $shippingTaxPercent
     * @param array $items
     * @param Quote $quote
     */
    public function populateAddress($address, $originalAddressData, $shippingTaxPercent, $items, $quote);

    /**
     * Define checkout sessions.
     *
     * @param Quote $split
     * @param AbstractExtensibleModel|OrderInterface|object|null $order
     * @param array $orderIds
     * @return \Magestat\SplitOrder\Api\QuoteHandlerInterface
     */
    public function defineSessions($split, $order, $orderIds);
}
