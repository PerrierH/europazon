<?php

namespace Maas\SplitOrder\Api;

use Closure;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote;

/**
 * Interface SplitHandlerInterface
 * @api
 * @package Maas\SplitOrder\Api
 */
interface SplitHandlerInterface
{
    /**
     * @param Quote $originalQuote
     * @param Closure $proceed
     * @param $checkoutSession
     * @return mixed
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function createMultiOrdersFromQuote($originalQuote, Closure $proceed, $checkoutSession);
}
