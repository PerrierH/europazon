<?php

namespace Maas\SplitOrder\Api;

use Magento\Quote\Model\Quote;

/**
 * Interface ShippingHandlerInterface
 * @api
 * @package Maas\SplitOrder\Api
 */
interface ShippingHandlerInterface
{
    /**
     * Prepare shipping assignment.
     *
     * @param Quote $quote
     * @return Quote
     */
    public function prepareShippingAssignment(Quote $quote);
}
