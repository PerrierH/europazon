<?php

namespace Maas\SplitOrder\Tests\Unit\Plugin;

use Maas\SplitOrder\Plugin\RestoreOriginalCart;
use Magento\Checkout\Model\Session;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Session\Storage;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Quote\Api\CartItemRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\ItemFactory;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManagerInterface;
use PHPUnit\Framework\TestCase;

/**
 * Class RestoreOriginalCartTest.
 *
 * @property ObjectManager $helper
 * @package Maas\SplitOrder\Tests\Unit\Plugin
 * @covers Maas\SplitOrder\Plugin\RestoreOriginalCart
 */
class RestoreOriginalCartTest extends TestCase
{
    /**
     * @var Quote
     */
    private $originalQuote;

    /**
     * {@inheritdoc}
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->helper = new ObjectManager($this);
        $this->originalQuote = $this->helper->getObject(
            Quote::class
        );
    }

    /**
     * @return void
     */
    public function testBeforeRestoreQuote(): void
    {
        $currentCartId = 100;
        $lastOrderId = 2000;
        $originalCartId = 100;
        $originalCartItems = [200, 201, 202];
        $storage = new Storage();

        $this->originalQuote->setId($originalCartId);
        $this->originalQuote->setIsActive(false);

        $quoteRepository = $this->getMockBuilder(CartRepositoryInterface::class)
            ->onlyMethods(['get', 'save'])
            ->getMockForAbstractClass();
        $quoteRepository->expects($this->once())->method('get')->with($originalCartId)->willReturn($this->originalQuote);

        $quoteItem = $this->createPartialMock(
            Quote\Item::class,
            ['load', 'save']
        );
        $quoteItem->expects($this->any())->method('save')->willReturnSelf();
        $quoteItem->expects($this->any())->method('load')->willReturnSelf();

        $quoteItemFactory = $this->createPartialMock(ItemFactory::class, ['create']);
        $quoteItemFactory->expects($this->any())->method('create')->willReturn($quoteItem);

        $quoteItemRepository = $this->createMock(CartItemRepositoryInterface::class);

        /** @var \Maas\Sales\Model\Session $maasSession */
        $maasSession = $this->helper->getObject(\Maas\Sales\Model\Session::class, ['storage' => $storage]);
        $maasSession->setOriginalCartId($originalCartId);

        /** @var RestoreOriginalCart $restoreOriginalCart */
        $restoreOriginalCart = $this->helper->getObject(RestoreOriginalCart::class,  [
            'quoteRepository' => $quoteRepository,
            'quoteItemFactory' => $quoteItemFactory,
            'quoteItemRepository' => $quoteItemRepository,
            'maasSession' => $maasSession
        ]);

        $store = $this->createMock(Store::class);
        $storeManager = $this->getMockForAbstractClass(StoreManagerInterface::class);
        $storeManager->expects($this->any())->method('getStore')->willReturn($store);
        $eventManager = $this->getMockForAbstractClass(ManagerInterface::class);

        /** @var Session $checkoutSession */
        $checkoutSession = $this->helper->getObject(
            Session::class,
            [
                'storage' => $storage,
                'storeManager' => $storeManager,
                'eventManager' => $eventManager
            ]
        );
        $checkoutSession->setQuoteId($currentCartId);
        $checkoutSession->setLastRealOrderId($lastOrderId);
        $result = $restoreOriginalCart->beforeRestoreQuote($checkoutSession);

        $this->assertNull($checkoutSession->getLastRealOrderId());
        $this->assertEquals($originalCartId, $checkoutSession->getQuoteId());
        $this->assertNull($maasSession->getOriginalCartId());
        $this->assertEquals(1, $this->originalQuote->getIsActive());
        $this->assertTrue($result);
    }
}
