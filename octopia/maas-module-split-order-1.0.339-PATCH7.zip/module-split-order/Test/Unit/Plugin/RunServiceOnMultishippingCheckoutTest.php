<?php

namespace Maas\SplitOrder\Test\Unit\Plugin;

use Maas\SplitOrder\Api\SplitHandlerInterface;
use Maas\SplitOrder\Helper\Data;
use Maas\SplitOrder\Plugin\RunServiceOnMultishippingCheckout;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use PHPUnit\Framework\TestCase;

/**
 * Class RunServiceOnMultishippingCheckoutTest.
 *
 * @package Maas\SplitOrder\Tests\Unit\Plugin
 * @covers \Maas\SplitOrder\Plugin\RunServiceOnMultishippingCheckout
 */
class RunServiceOnMultishippingCheckoutTest extends TestCase
{
    /**
     * @var Data|PHPUnit\Framework\MockObject\MockObject
     */
    private $helperData;

    /**
     * Mock splitHandler
     *
     * @var SplitHandlerInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $splitHandler;

    /**
     * Object Manager instance
     *
     * @var ObjectManagerInterface
     */
    private $objectManager;

    /**
     * Object to test
     *
     * @var RunServiceOnMultishippingCheckout
     */
    private $runServiceOnMultishippingCheckout;

    /**
     * Main set up method
     */
    public function setUp(): void
    {
        $this->objectManager = new ObjectManager($this);
        $this->helperData = $this->createMock(Data::class);
        $this->splitHandler = $this->createMock(SplitHandlerInterface::class);
        $maasSession = $this->createMock(\Maas\Sales\Model\Session::class);
        $maasSession->expects($this->once())->method('clearOrders');
        $this->runServiceOnMultishippingCheckout = $this->objectManager->getObject(
            RunServiceOnMultishippingCheckout::class,
            [
                'helperData' => $this->helperData,
                'splitHandler' => $this->splitHandler,
                'maasSession' => $maasSession,
            ]
        );
    }

    /**
     * @return array
     */
    public function dataAroundCreateOrders()
    {
        return [
            'Testcase module activated' => [
                'active' => true,
                'return' => TestCase::once()
            ],
            'Testcase moule not activated' => [
                'active' => false,
                'return' => TestCase::never()
            ]
        ];
    }

    /**
     * @dataProvider dataAroundCreateOrders
     * @return void
     */
    public function testAroundCreateOrders($active, $return)
    {
        $expectedResult = 'expectedResult';
        $this->helperData->expects($this->once())
            ->method('isActive')
            ->will($this->returnValue($active));
        $subject = $this->createMock(Multishipping::class);
        $proceed = function () use ($expectedResult) {
            return $expectedResult;
        };
        $this->splitHandler->expects($return)
            ->method('createMultiOrdersFromQuote')
            ->will($this->returnCallback($proceed));
        $result = $this->runServiceOnMultishippingCheckout->aroundCreateOrders($subject, $proceed);
        $this->assertEquals($expectedResult, $result);
    }
}
