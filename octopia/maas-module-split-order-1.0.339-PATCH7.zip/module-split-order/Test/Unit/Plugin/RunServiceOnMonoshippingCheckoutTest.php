<?php
namespace Maas\SplitOrder\Test\Unit\Plugin;

use Maas\Sales\Model\Session;
use Maas\SplitOrder\Helper\Data;
use Maas\SplitOrder\Api\MainOrderIdInterfaceInterface;
use Maas\SplitOrder\Plugin\RunServiceOnMonoshippingCheckout;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Session\Generic;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote as QuoteEntity;
use Magento\Quote\Model\QuoteManagement;
use Magento\Sales\Model\Order;
use PHPUnit\Framework\TestCase;

/**
 * Class RunServiceOnMonoshippingCheckoutTest.
 *
 * @package Maas\SplitOrder\Tests\Unit\Plugin
 * @covers \Maas\SplitOrder\Plugin\RunServiceOnMonoshippingCheckout
 */
class RunServiceOnMonoshippingCheckoutTest extends TestCase
{
    /**
     * Mock quoteRepository
     *
     * @var CartRepositoryInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $quoteRepository;

    /**
     * Mock maasSession
     *
     * @var Session|PHPUnit\Framework\MockObject\MockObject
     */
    private $maasSession;

    /**
     * Mock eventManager
     *
     * @var ManagerInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $eventManager;

    /**
     * Mock session
     *
     * @var Generic|PHPUnit\Framework\MockObject\MockObject
     */
    private $session;

    /**
     * Mock helperData
     *
     * @var Data|PHPUnit\Framework\MockObject\MockObject
     */
    private $helperData;

    /**
     * Mock logger
     *
     * @var \Psr\Log\LoggerInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $logger;

    /**
     * Mock multishipping
     *
     * @var Multishipping|PHPUnit\Framework\MockObject\MockObject
     */
    private $multishipping;

    /**
     * Object Manager instance
     *
     * @var ObjectManagerInterface
     */
    private $objectManager;

    /**
     * Object to test
     *
     * @var RunServiceOnMonoshippingCheckout
     */
    private $runServiceOnMonoshippingCheckout;

    /**
     * @var MainOrderIdInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $mainOrderId;

    /**
     * Main set up method
     */
    public function setUp() : void
    {
        $this->objectManager = new ObjectManager($this);
        $this->quoteRepository = $this->createMock(CartRepositoryInterface::class);
        $this->eventManager = $this->createMock(ManagerInterface::class);
        $this->session = $this->createMock(Generic::class);
        $this->helperData = $this->createMock(Data::class);
        $this->mainOrderId = $this->createMock(MainOrderIdInterface::class);
        $this->logger = $this->createMock(\Psr\Log\LoggerInterface::class);
        $this->multishipping = $this->createMock(Multishipping::class);
        $this->maasSession = $this->createMock(\Maas\Sales\Model\Session::class);
        $this->maasSession->expects($this->once())->method('clearOrders');
        $this->runServiceOnMonoshippingCheckout = $this->objectManager->getObject(
        RunServiceOnMonoshippingCheckout::class,
            [
                'quoteRepository' => $this->quoteRepository,
                'maasSession' => $this->maasSession,
                'eventManager' => $this->eventManager,
                'session' => $this->session,
                'helperData' => $this->helperData,
                'logger' => $this->logger,
                'mainOrderId' => $this->mainOrderId,
                'multishipping' => $this->multishipping,
            ]
        );
    }

    /**
     * @return void
     */
    public function testAroundSubmitModuleNotActive()
    {
        $orderId = 1;
        $subject = $this->createMock(QuoteManagement::class);
        $quoteEntity = $this->createMock(QuoteEntity::class);
        $orderData = [];
        $order = $this->createMock(Order::class);
        $order->expects($this->once())->method('getId')->willReturn($orderId);
        $this->mainOrderId->expects($this->once())->method('saveUniqueOrderById')->willReturnSelf();
        $proceed = function ($quoteEntity, $orderData) use ($order) {
            return $order;
        };
        $this->helperData->expects($this->once())
            ->method('isActive')
            ->will($this->returnValue(false));

        $result = $this->runServiceOnMonoshippingCheckout->aroundSubmit($subject, $proceed, $quoteEntity, $orderData);
        $this->assertEquals($order, $result);
    }

    /**
     * @return void
     */
    public function testAroundSubmitModuleActive()
    {
        $subject = $this->createMock(QuoteManagement::class);
        $quoteEntity = $this->createMock(QuoteEntity::class);
        $orderData = [];
        $this->multishipping->expects($this->once())->method('createOrders');
        $this->eventManager->expects($this->once())->method('dispatch');
        $firstOrder = $this->createMock(Order::class);
        $this->maasSession->expects($this->once())->method('getFirstOrder')->willReturn($firstOrder);
        $proceed = function () {};
        $this->helperData->expects($this->once())
            ->method('isActive')
            ->will($this->returnValue(true));
        $result = $this->runServiceOnMonoshippingCheckout->aroundSubmit($subject, $proceed, $quoteEntity, $orderData);
        $this->assertEquals($firstOrder, $result);
    }

    /**
     * @return void
     */
    public function testExceptionAroundSubmitModuleActive()
    {
        $subject = $this->createMock(QuoteManagement::class);
        $quoteEntity = $this->createMock(QuoteEntity::class);
        $orderData = [];
        $proceed = function () {};
        $this->helperData->expects($this->once())
            ->method('isActive')
            ->will($this->returnValue(true));

        /*$this->session->expects($this->once())
            ->method('setIsMultishipping')
            ->with(false)
            ->willReturnSelf();*/
        $exception = $this->createMock(\Exception::class, []);
        $this->multishipping->expects($this->once())->method('createOrders')->willThrowException($exception);
        $this->logger->expects($this->once())->method('critical')->with($this->identicalTo($exception));
        $this->expectException(LocalizedException::class);
        $this->expectExceptionMessageMatches('/Something went wrong with your request. Please try again later?/');
        $result = $this->runServiceOnMonoshippingCheckout->aroundSubmit($subject, $proceed, $quoteEntity, $orderData);
        $this->assertNull($result);
    }

    /**
     * @return void
     */
    public function testLocalizedExceptionAroundSubmitModuleActive()
    {
        $subject = $this->createMock(QuoteManagement::class);
        $quoteEntity = $this->createMock(QuoteEntity::class);
        $orderData = [];
        $proceed = function () {};
        $this->helperData->expects($this->once())
            ->method('isActive')
            ->will($this->returnValue(true));
        /*$this->session->expects($this->once())
            ->method('setIsMultishipping')
            ->with(false)
            ->willReturnSelf();*/
        $exception = $this->createMock(LocalizedException::class, []);
        $this->multishipping->expects($this->once())->method('createOrders')->willThrowException($exception);
        $this->expectException(LocalizedException::class);
        $result = $this->runServiceOnMonoshippingCheckout->aroundSubmit($subject, $proceed, $quoteEntity, $orderData);
        $this->assertNull($result);
    }
}
