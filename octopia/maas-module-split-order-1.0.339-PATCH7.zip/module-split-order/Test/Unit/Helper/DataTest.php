<?php

namespace Maas\SplitOrder\Test\Unit\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Framework\App\Helper\Context;
use Maas\SplitOrder\Helper\Data;

/**
 * @covers \Maas\SplitOrder\Helper\Data
 */
class DataTest extends TestCase
{
    /**
     * Class to test instance
     *
     * @var Data
     */
    private Data $data;

    /**
     * @var ScopeConfigInterface|MockObject
     */
    private $scopeConfigMock;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $contextMock = $this->getMockBuilder(Context::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->scopeConfigMock = $this->getMockBuilder(ScopeConfigInterface::class)
            ->disableOriginalConstructor()
            ->getMock();
        $contextMock
            ->expects($this->once())
            ->method('getScopeConfig')
            ->willReturn($this->scopeConfigMock);
        $this->data = new Data(
            $contextMock
        );
    }

    /**
     * @return void
     */
    public function testIsActive() : void
    {
        $this->scopeConfigMock
            ->expects($this->once())
            ->method('isSetFlag')
            ->with('maas_orders/split_order/active')
            ->willReturn(false);
        $this->assertEquals(
            false,
            $this->data->isActive()
        );
    }
}
