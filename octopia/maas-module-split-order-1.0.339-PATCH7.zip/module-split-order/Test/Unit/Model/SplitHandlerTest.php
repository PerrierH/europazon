<?php
namespace Maas\SplitOrder\Test\Unit\Model;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Payment;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;

/**
 * Class SplitHandlerTest.
 *
 * @property ObjectManager $helper
 * @package Maas\SplitOrder\Tests\Unit\Model
 * @covers \Maas\SplitOrder\Model\SplitHandler
 */
class SplitHandlerTest extends TestCase
{
    /**
     * Mock mainOrderIdService
     *
     * @var \Maas\SplitOrder\Model\MainOrderId|PHPUnit\Framework\MockObject\MockObject
     */
    private $mainOrderIdService;

    /**
     * Mock eventManager
     *
     * @var \Magento\Framework\Event\ManagerInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $eventManager;

    /**
     * Mock maasSession
     *
     * @var \Maas\Sales\Model\Session|PHPUnit\Framework\MockObject\MockObject
     */
    private $maasSession;

    /**
     * Mock checkoutSession
     *
     * @var \Magento\Checkout\Model\Session|PHPUnit\Framework\MockObject\MockObject
     */
    private $checkoutSession;

    /**
     * Mock session
     *
     * @var \Magento\Framework\Session\Generic|PHPUnit\Framework\MockObject\MockObject
     */
    private $session;

    /**
     * Mock helperData
     *
     * @var \Maas\SplitOrder\Helper\Data|PHPUnit\Framework\MockObject\MockObject
     */
    private $helperData;

    /**
     * Mock quoteHandler
     *
     * @var \Maas\SplitOrder\Api\QuoteHandlerInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $quoteHandler;

    /**
     * Mock quoteFactoryInstance
     *
     * @var \Magento\Quote\Model\Quote|PHPUnit\Framework\MockObject\MockObject
     */
    private $quoteFactoryInstance;

    /**
     * Mock quoteFactory
     *
     * @var \Magento\Quote\Model\QuoteFactory|PHPUnit\Framework\MockObject\MockObject
     */
    private $quoteFactory;

    /**
     * Mock addressRepository
     *
     * @var \Magento\Customer\Api\AddressRepositoryInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $addressRepository;

    /**
     * Mock addressFactoryInstance
     *
     * @var \Magento\Quote\Model\Quote\Address|PHPUnit\Framework\MockObject\MockObject
     */
    private $addressFactoryInstance;

    /**
     * Mock addressFactory
     *
     * @var \Magento\Quote\Model\Quote\AddressFactory|PHPUnit\Framework\MockObject\MockObject
     */
    private $addressFactory;

    /**
     * Mock quoteRepository
     *
     * @var \Magento\Quote\Api\CartRepositoryInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $quoteRepository;

    /**
     * Mock addressesRegistry
     *
     * @var \Maas\SplitOrder\Model\AddressesRegistry|PHPUnit\Framework\MockObject\MockObject
     */
    private $addressesRegistry;

    /**
     * Mock shippingHandler
     *
     * @var \Maas\SplitOrder\Api\ShippingHandlerInterface|PHPUnit\Framework\MockObject\MockObject
     */
    private $shippingHandler;

    /**
     * Mock mainOrderId
     *
     * @var \Maas\SplitOrder\Model\MainOrderId|PHPUnit\Framework\MockObject\MockObject
     */
    private $mainOrderId;

    /**
     * Object Manager instance
     *
     * @var \Magento\Framework\ObjectManagerInterface
     */
    private $objectManager;

    /**
     * Object to test
     *
     * @var \Maas\SplitOrder\Model\SplitHandler
     */
    private $splitHandler;

    /**
     * Main set up method
     */
    public function setUp() : void
    {
        $this->objectManager = new ObjectManager($this);
        $this->mainOrderIdService = $this->createMock(\Maas\SplitOrder\Model\MainOrderId::class);
        $this->eventManager = $this->createMock(\Magento\Framework\Event\ManagerInterface::class);
        $this->maasSession = $this->createMock(\Maas\Sales\Model\Session::class);
        $this->checkoutSession = $this->createMock(\Magento\Checkout\Model\Session::class);
        $this->session = $this->createMock(\Magento\Framework\Session\Generic::class);
        $this->helperData = $this->createMock(\Maas\SplitOrder\Helper\Data::class);
        $this->quoteHandler = $this->createMock(\Maas\SplitOrder\Api\QuoteHandlerInterface::class);
        $this->quoteFactoryInstance = $this->createMock(\Magento\Quote\Model\Quote::class);
        $this->quoteFactory = $this->createMock(\Magento\Quote\Model\QuoteFactory::class);
        $this->quoteFactory->method('create')->willReturn($this->quoteFactoryInstance);
        $this->addressRepository = $this->createMock(\Magento\Customer\Api\AddressRepositoryInterface::class);
        $this->addressFactoryInstance = $this->createMock(\Magento\Quote\Model\Quote\Address::class);
        $this->addressFactory = $this->createMock(\Magento\Quote\Model\Quote\AddressFactory::class);
        $this->addressFactory->method('create')->willReturn($this->addressFactoryInstance);
        $this->quoteRepository = $this->createMock(\Magento\Quote\Api\CartRepositoryInterface::class);
        $this->addressesRegistry = $this->createMock(\Maas\SplitOrder\Model\AddressesRegistry::class);
        $this->shippingHandler = $this->createMock(\Maas\SplitOrder\Api\ShippingHandlerInterface::class);
        $this->mainOrderId = $this->createMock(\Maas\SplitOrder\Model\MainOrderId::class);
        $this->splitHandler = $this->objectManager->getObject(
        \Maas\SplitOrder\Model\SplitHandler::class,
            [
                'mainOrderIdService' => $this->mainOrderIdService,
                'eventManager' => $this->eventManager,
                'maasSession' => $this->maasSession,
                'checkoutSession' => $this->checkoutSession,
                'session' => $this->session,
                'helperData' => $this->helperData,
                'quoteHandler' => $this->quoteHandler,
                'quoteFactory' => $this->quoteFactory,
                'addressRepository' => $this->addressRepository,
                'addressFactory' => $this->addressFactory,
                'quoteRepository' => $this->quoteRepository,
                'addressesRegistry' => $this->addressesRegistry,
                'shippingHandler' => $this->shippingHandler,
                'mainOrderId' => $this->mainOrderId,
            ]
        );
    }

    /**
     * @return array
     */
    public function dataProviderForTestCreateMultiOrdersFromQuote()
    {
        return [
            'Testcase 1' => [
                'active' => false,
                'prerequisites' => ['param' => 1],
                'expectedResult' => ['param' => 1]
            ],
            'Testcase 2' => [
                'active' => true,
                'prerequisites' => ['param' => 1],
                'expectedResult' => ['param' => 1]
            ]
        ];
    }

    /**
     * @dataProvider dataProviderForTestCreateMultiOrdersFromQuote
     */
    public function testCreateMultiOrdersFromQuote($active, array $prerequisites, array $expectedResult)
    {
        $expectedResult = 'expectedResult';
        $this->helperData->expects($this->once())
            ->method('isActive')
            ->will($this->returnValue($active));
        $originalQuote = $this->createMock(Quote::class);
        $proceed = function () use ($expectedResult) {
            return $expectedResult;
        };
        $checkoutSession = $this->createMock(Quote::class);

        if ($active) {
            $originalQuote->method('getAllItems')
                ->will($this->returnValue([]));

            $paymentProviderCode = 'checkmo';
            $paymentMock = $this->getPaymentMock($paymentProviderCode);
            $originalQuote->method('getPayment')
                ->willReturn($paymentMock);

        }

        $result = $this->splitHandler->createMultiOrdersFromQuote($originalQuote, $proceed, $checkoutSession);
        $this->assertEquals($expectedResult, $result);
    }


    /**
     * Return Payment Mock.
     *
     * @param string $paymentProviderCode
     * @return MockObject
     */
    private function getPaymentMock(string $paymentProviderCode): MockObject
    {
        $abstractMethod = $this->getMockBuilder(AbstractMethod::class)
            ->disableOriginalConstructor()
            ->setMethods(['isAvailable'])
            ->getMockForAbstractClass();
        $abstractMethod->method('isAvailable')->willReturn(true);

        $paymentMock = $this->getMockBuilder(Payment::class)
            ->disableOriginalConstructor()
            ->setMethods(['getMethodInstance', 'getMethod'])
            ->getMock();
        $paymentMock->method('getMethodInstance')->willReturn($abstractMethod);
        $paymentMock->method('getMethod')->willReturn($paymentProviderCode);

        return $paymentMock;
    }
}
