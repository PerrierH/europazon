<?php
namespace Maas\SplitOrder\Test\Unit\Model;

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Quote\Model\Quote\ShippingAssignment\ShippingAssignmentProcessor;
use Magento\Quote\Api\Data\CartExtensionFactory;
use Maas\SplitOrder\Model\ShippingHandler;
use Magento\Quote\Api\Data\CartExtension;

/**
 * @covers \Maas\SplitOrder\Model\ShippingHandler
 */
class ShippingHandlerTest extends TestCase
{
    /**
     * Mock ShippingAssignmentProcessor
     *
     * @var ShippingAssignmentProcessor|MockObject
     */
    private $shippingAssignmentProcessorMock;

    /**
     * Mock CartExtensionFactory
     *
     * @var CartExtensionFactory|MockObject
     */
    private $cartExtensionFactoryMock;

    /**
     * Class to test instance
     *
     * @var ShippingHandler
     */
    private $shippingHandler;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->shippingAssignmentProcessorMock = $this->getMockBuilder(ShippingAssignmentProcessor::class)
        	->disableOriginalConstructor()
        	->getMock();

        $cartExtensionInstanceMock = $this->getMockBuilder(CartExtension::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->cartExtensionFactoryMock = $this->getMockBuilder(CartExtensionFactory::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->cartExtensionFactoryMock
        	->expects($this->atMost(1))
        	->method('create')
        	->willReturn($cartExtensionInstanceMock);

        $this->shippingHandler = new ShippingHandler(
        	$this->shippingAssignmentProcessorMock,
        	$this->cartExtensionFactoryMock
        );
    }

    /**
     * @return void
     */
    public function testPrepareShippingAssignment() : void
    {
        $quoteMock;
        $this->shippingHandler->prepareShippingAssignment($quoteMock);
    }
}
