<?php
namespace Maas\SplitOrder\Test\Unit\Model;

use Maas\Sales\Api\Data\SalesQuoteAddressItemInfoInterface;
use Magento\Quote\Api\Data\AddressExtensionInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Item;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Magento\Checkout\Model\Session;
use Maas\SplitOrder\Helper\Data;
use Magento\Weee\Helper\Data as HelperData;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Sales\Model\Service\AddressItem;
use Magento\Framework\Session\Generic;
use Magento\Sales\Model\OrderFactory;
use Magento\Quote\Model\Quote\Address\ToOrder;
use Magento\Quote\Model\Quote\Address\ToOrderAddress;
use Magento\Quote\Model\Quote\Payment\ToOrderPayment;
use Magento\Quote\Model\Quote\Item\ToOrderItem;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Maas\SplitOrder\Model\QuoteHandler;
use Magento\Sales\Model\Order;

/**
 * @covers \Maas\SplitOrder\Model\QuoteHandler
 */
class QuoteHandlerTest extends TestCase
{
    /**
     * Mock Session
     *
     * @var Session|MockObject
     */
    private $checkoutSessionMock;

    /**
     * Mock Data
     *
     * @var Data|MockObject
     */
    private $helperDataMock;

    /**
     * Mock HelperData
     *
     * @var HelperData|MockObject
     */
    private $weeeHelperMock;

    /**
     * Mock ExtensionAttributes
     *
     * @var ExtensionAttributes|MockObject
     */
    private $extensionAttributesServiceMock;

    /**
     * Mock AddressItem
     *
     * @var AddressItem|MockObject
     */
    private $addressItemServiceMock;

    /**
     * Mock Generic
     *
     * @var Generic|MockObject
     */
    private $sessionMock;

    /**
     * Mock OrderFactory
     *
     * @var OrderFactory|MockObject
     */
    private $orderFactoryMock;

    /**
     * Mock ToOrder
     *
     * @var ToOrder|MockObject
     */
    private $quoteAddressToOrderMock;

    /**
     * Mock ToOrderAddress
     *
     * @var ToOrderAddress|MockObject
     */
    private $quoteAddressToOrderAddressMock;

    /**
     * Mock ToOrderPayment
     *
     * @var ToOrderPayment|MockObject
     */
    private $quotePaymentToOrderPaymentMock;

    /**
     * Mock ToOrderItem
     *
     * @var ToOrderItem|MockObject
     */
    private $quoteItemToOrderItemMock;

    /**
     * Mock PriceCurrencyInterface
     *
     * @var PriceCurrencyInterface|MockObject
     */
    private $priceCurrencyMock;

    /**
     * Class to test instance
     *
     * @var QuoteHandler
     */
    private $quoteHandler;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->checkoutSessionMock = $this->getMockBuilder(Session::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->helperDataMock = $this->getMockBuilder(Data::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->weeeHelperMock = $this->getMockBuilder(HelperData::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->extensionAttributesServiceMock = $this->getMockBuilder(ExtensionAttributes::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->addressItemServiceMock = $this->getMockBuilder(AddressItem::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->sessionMock = $this->getMockBuilder(Generic::class)
        	->disableOriginalConstructor()
        	->getMock();

        $orderInstanceMock = $this->getMockBuilder(Order::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->orderFactoryMock = $this->getMockBuilder(OrderFactory::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->orderFactoryMock
        	->expects($this->atMost(1))
        	->method('create')
        	->willReturn($orderInstanceMock);

        $this->quoteAddressToOrderMock = $this->getMockBuilder(ToOrder::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->quoteAddressToOrderAddressMock = $this->getMockBuilder(ToOrderAddress::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->quotePaymentToOrderPaymentMock = $this->getMockBuilder(ToOrderPayment::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->quoteItemToOrderItemMock = $this->getMockBuilder(ToOrderItem::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->priceCurrencyMock = $this->getMockBuilder(PriceCurrencyInterface::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->quoteHandler = new QuoteHandler(
        	$this->checkoutSessionMock,
        	$this->helperDataMock,
        	$this->weeeHelperMock,
        	$this->extensionAttributesServiceMock,
        	$this->addressItemServiceMock,
        	$this->sessionMock,
        	$this->orderFactoryMock,
        	$this->quoteAddressToOrderMock,
        	$this->quoteAddressToOrderAddressMock,
        	$this->quotePaymentToOrderPaymentMock,
        	$this->quoteItemToOrderItemMock,
        	$this->priceCurrencyMock
        );
    }

    /**
     * @param array $sellerIds
     * @return void
     * @dataProvider normalizeAddressesBySellerDataProvider
     */
    public function testNormalizeAddressesBySeller(array $sellerIds) : void
    {
        $shippingAddressMock = $this->getMockBuilder(Address::class)
            ->disableOriginalConstructor()
            ->getMock();
        $shippingAddressItems = [];
        $i = 0;
        foreach ($sellerIds as $sellerId) {
            $shippingAddressItems[] = $this->getShippingAddressItemMock($i, $sellerId, true);
            $i++;
        }
        $shippingAddressMock
            ->expects($this->once())
            ->method('getAllItems')
            ->willReturn($shippingAddressItems);
        $result = $this->quoteHandler->normalizeAddressesBySeller($shippingAddressMock);
        if (empty($sellerIds)) {
            $this->assertFalse($result);
        } else {
            foreach (array_unique($sellerIds) as $sellerId) {
                $this->assertArrayHasKey($sellerId, $result);
            }
            $this->assertCount(count(array_unique($sellerIds)), $result);
        }
    }

    /**
     * @return array
     */
    public function normalizeAddressesBySellerDataProvider(): array
    {
        return [
            [
                [15, 25, 22, 15]
            ],
            [
                [15]
            ],
            [
                [22, 22, 22]
            ],
            [
                []
            ],
        ];
    }

    /**
     * @param int $iterator
     * @param int $sellerId
     * @param bool $withoutData
     * @return Item|MockObject
     */
    private function getShippingAddressItemMock(int $iterator = 0, int $sellerId = 0, bool $withoutData = false)
    {
        $shippingAddressItemMock = $this->getMockBuilder(Item::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['getData'])
            ->addMethods(['getQuoteItem', 'geQty', 'getQtyToAdd'])
            ->getMock();
        if (!$withoutData)  {
            $itemData = [
                'qty' => 10,
                'qty_to_add' => 0,
                'base_discount_amount' => 10,
                'discount_amount' => 10,
                'base_discount_tax_compensation_amount' => 0,
                'discount_tax_compensation_amount' => 0
            ];
            $shippingAddressItemMock
                ->expects($this->any())
                ->method('geQty')
                ->willReturn($itemData['qty']);
            $shippingAddressItemMock
                ->expects($this->any())
                ->method('getQtyToAdd')
                ->willReturn($itemData['qty_to_add']);

            $shippingAddressItemMock
                ->expects($this->at($iterator))
                ->method('getData')
                ->willReturnCallback(function ($key) use ($itemData) { return $itemData[$key]; } );

            $quoteItemMock = $this->getMockBuilder(Quote\Item::class)
                ->disableOriginalConstructor()
                ->getMock();

            $shippingAddressItemMock
                ->expects($this->any())
                ->method('getQuoteItem')
                ->willReturn($quoteItemMock);
        }
        $salesQuoteAddressItemInfoMock = $this->getMockBuilder(SalesQuoteAddressItemInfoInterface::class)
            ->disableOriginalConstructor()
            ->addMethods(['getSellerId'])
            ->getMockForAbstractClass();

        $this->addressItemServiceMock
            ->expects($this->at($iterator))
            ->method('loadExtraInfo')
            ->willReturn($salesQuoteAddressItemInfoMock);

        $salesQuoteAddressItemInfoMock
            ->expects($this->any())
            ->method('getSellerId')
            ->willReturn($sellerId);
        return $shippingAddressItemMock;
    }

    /**
     * @return void
     */
    public function testPopulateAddress() : void
    {
        $addressMock = $this->getMockBuilder(Address::class)
            ->disableOriginalConstructor()
            ->onlyMethods(['setExtensionAttributes'])
            ->addMethods([
                'setAppliedRuleId',
                'setAddressSalesRuleId',
                'setCouponCode',
                'setShippingMethod',
                'setDiscountDescription'
            ])
            ->getMock();
        $originalAddressDataMock = [];

        $originalAddressDataMock['applied_rule_ids'] = 22;
        $addressMock
            ->expects($this->once())
            ->method('setAppliedRuleId')
            ->with(22);

        $originalAddressDataMock['address_sales_rule_id'] = 21;
        $addressMock
            ->expects($this->once())
            ->method('setAddressSalesRuleId')
            ->with(21);

        $originalAddressDataMock['coupon_code'] = 'code';
        $addressMock
            ->expects($this->once())
            ->method('setCouponCode')
            ->with('code');

        $addressExtensionMock = $this->getMockBuilder(AddressExtensionInterface::class)
            ->disableOriginalConstructor()
            ->getMock();

        $originalAddressDataMock['extension_attributes'] = $addressExtensionMock;
        $addressMock
            ->expects($this->once())
            ->method('setExtensionAttributes')
            ->with($addressExtensionMock);

        $originalAddressDataMock['shipping_method'] = 'shipping_method';
        $addressMock
            ->expects($this->once())
            ->method('setShippingMethod')
            ->with('shipping_method');

        $originalAddressDataMock['discount_description'] = 'discount_description';
        $addressMock
            ->expects($this->once())
            ->method('setDiscountDescription')
            ->with('discount_description');

        $shippingTaxPercentMock = 14.0;
        $itemsMock = [
            $this->getShippingAddressItemMock()
        ];
        $quoteMock = $this->getMockBuilder(Quote::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->quoteHandler->populateAddress(
            $addressMock,
            $originalAddressDataMock,
            $shippingTaxPercentMock,
            $itemsMock,
            $quoteMock
        );
    }
}
