<?php

namespace Maas\SplitOrder\Test\Unit\Model;

use PHPUnit\Framework\TestCase;
use Maas\SplitOrder\Model\AddressesRegistry;

/**
 * @covers \Maas\SplitOrder\Model\AddressesRegistry
 */
class AddressesRegistryTest extends TestCase
{
    /**
     * Class to test instance
     *
     * @var AddressesRegistry
     */
    private AddressesRegistry $addressesRegistry;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->addressesRegistry = new AddressesRegistry();
    }

    /**
     * @return void
     */
    public function testRegisterAndIsRegisteredAddressId() : void
    {
        $addressIdMock = 22;
        $this->addressesRegistry->registerAddressId($addressIdMock);
        $this->assertTrue($this->addressesRegistry->isRegisteredAddressId($addressIdMock));
        $this->assertFalse($this->addressesRegistry->isRegisteredAddressId(23));
    }
}
