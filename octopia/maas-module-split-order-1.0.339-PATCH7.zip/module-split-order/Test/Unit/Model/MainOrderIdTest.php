<?php
namespace Maas\SplitOrder\Test\Unit\Model;

use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderSearchResultInterface;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Maas\Sales\Api\SalesOrderInfoRepositoryInterface;
use Maas\Sales\Api\Data\SalesOrderInfoInterfaceFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Event\ManagerInterface;
use Maas\SplitOrder\Model\MainOrderId;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;

/**
 * @covers \Maas\SplitOrder\Model\MainOrderId
 */
class MainOrderIdTest extends TestCase
{
    /**
     * Mock SalesOrderInfoRepositoryInterface
     *
     * @var SalesOrderInfoRepositoryInterface|MockObject
     */
    private $salesOrderInfoRepositoryMock;

    /**
     * Mock SalesOrderInfoInterfaceFactory
     *
     * @var SalesOrderInfoInterfaceFactory|MockObject
     */
    private $salesOrderInfoFactoryMock;

    /**
     * Mock OrderRepositoryInterface
     *
     * @var OrderRepositoryInterface|MockObject
     */
    private $orderRepositoryMock;

    /**
     * Mock SearchCriteriaBuilder
     *
     * @var SearchCriteriaBuilder|MockObject
     */
    private $searchCriteriaBuilderMock;

    /**
     * Mock ManagerInterface
     *
     * @var ManagerInterface|MockObject
     */
    private $eventManagerMock;

    /**
     * Class to test instance
     *
     * @var MainOrderId
     */
    private MainOrderId $mainOrderId;

    /**
     * @return void
     */
    public function setUp() : void
    {
        $this->salesOrderInfoRepositoryMock = $this->getMockBuilder(SalesOrderInfoRepositoryInterface::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->salesOrderInfoFactoryMock = $this->getMockBuilder(SalesOrderInfoInterfaceFactory::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->orderRepositoryMock = $this->getMockBuilder(OrderRepositoryInterface::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->searchCriteriaBuilderMock = $this->getMockBuilder(SearchCriteriaBuilder::class)
        	->disableOriginalConstructor()
        	->getMock();
        $this->eventManagerMock = $this->getMockBuilder(ManagerInterface::class)
        	->disableOriginalConstructor()
        	->getMock();

        $this->mainOrderId = new MainOrderId(
        	$this->salesOrderInfoRepositoryMock,
        	$this->salesOrderInfoFactoryMock,
        	$this->orderRepositoryMock,
        	$this->searchCriteriaBuilderMock,
        	$this->eventManagerMock
        );
    }

    /**
     * @return void
     */
    public function testSaveUniqueOrderById() : void
    {
        $mainOrderIdMock = 20;
        $mainOrderIncrementIdMock = 'MIM20000';

        $this->orderRepositoryMock
            ->expects($this->atMost(2))
            ->method('get')
            ->with($mainOrderIdMock)
            ->willReturn($this->getOrderMock($mainOrderIdMock, $mainOrderIncrementIdMock));

        $orderIdsMock = [$mainOrderIncrementIdMock => $mainOrderIdMock];
        $this->setMainOrder($mainOrderIdMock, $mainOrderIncrementIdMock, $orderIdsMock);
        $this->mainOrderId->saveUniqueOrderById($mainOrderIdMock);
        $this->setMainOrder($mainOrderIdMock, $mainOrderIncrementIdMock, $orderIdsMock, true);
        $this->mainOrderId->saveUniqueOrderById($mainOrderIdMock);
    }

    /**
     * @return void
     */
    public function testSetMainOrderByIds() : void
    {
        $orderIdsMock = ["MIM20001" => 1, "MIM200002" => 2,  "MIM20003" => 3];

        $orderSearchResultMock = $this->getMockBuilder(OrderSearchResultInterface::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->searchCriteriaBuilderMock
            ->expects($this->atMost(2))
            ->method('addFilter')
            ->with('entity_id', $orderIdsMock, 'in')
            ->willReturnSelf();

        $searchCriteriaMock = $this->getMockBuilder(SearchCriteria::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->searchCriteriaBuilderMock
            ->expects($this->atMost(2))
            ->method('create')
            ->willReturn($searchCriteriaMock);

        $this->orderRepositoryMock
            ->expects($this->atMost(2))
            ->method('getList')
            ->with($searchCriteriaMock)
            ->willReturn($orderSearchResultMock);

        $orders = [];
        foreach ($orderIdsMock as $orderIncrementIdMock => $orderIdMock) {
            $orders[] = $this->getOrderMock($orderIdMock, $orderIncrementIdMock);
        }
        $orderSearchResultMock
            ->expects($this->atMost(2))
            ->method('getItems')
            ->willReturn($orders);
        $mainOrderIdMock = 1;
        $mainOrderIncrementIdMock = 'MIM20001';
        $this->setMainOrder($mainOrderIdMock, $mainOrderIncrementIdMock, $orderIdsMock);
        $this->mainOrderId->setMainOrderByIds($orderIdsMock);
        $this->setMainOrder($mainOrderIdMock, $mainOrderIncrementIdMock, $orderIdsMock, true);
        $this->mainOrderId->setMainOrderByIds($orderIdsMock);
    }

    /**
     * @param int $orderIdMock
     * @param string $orderIncrementIdMock
     * @return OrderInterface|MockObject
     */
    private function getOrderMock(int $orderIdMock, string $orderIncrementIdMock)
    {
        $orderMock = $this->getMockBuilder(OrderInterface::class)
            ->disableOriginalConstructor()
            ->addMethods(['getId'])
            ->getMockForAbstractClass();
        $orderMock
            ->expects($this->any())
            ->method('getId')
            ->willReturn($orderIdMock);
        $orderMock
            ->expects($this->any())
            ->method('getIncrementId')
            ->willReturn($orderIncrementIdMock);

        $orderExtensionMock = $this->getMockBuilder(OrderExtensionInterface::class)
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
        $orderMock
            ->expects($this->any())
            ->method('getExtensionAttributes')
            ->willReturn($orderExtensionMock);
        return $orderMock;
    }

    /**
     * @param int $mainOrderIdMock
     * @param string $mainOrderIncrementIdMock
     * @param array $orderIdsMock
     * @param bool $withException
     * @return void
     */
    private function setMainOrder(
        int $mainOrderIdMock,
        string $mainOrderIncrementIdMock,
        array $orderIdsMock,
        bool $withException = false
    ) {
        $i = $j = $k = 0;
        foreach ($orderIdsMock as $orderIncrementIdMock => $orderIdMock) {
            $l = 0;
            $salesOrderInfoMock = $this->getMockBuilder(SalesOrderInfoInterface::class)
                ->disableOriginalConstructor()
                ->getMock();
            if ($withException) {
                $this->salesOrderInfoRepositoryMock
                    ->expects($this->at($i))
                    ->method('get')
                    ->willThrowException(new NoSuchEntityException(__('error')));
                $i++;
                $this->salesOrderInfoFactoryMock
                    ->expects($this->at($k))
                    ->method('create')
                    ->willReturn($salesOrderInfoMock);
                $k++;
                $salesOrderInfoMock
                    ->expects($this->at($l))
                    ->method('setId')
                    ->with($orderIdMock);
                $l++;
            } else {
                $this->salesOrderInfoRepositoryMock
                    ->expects($this->at($i))
                    ->method('get')
                    ->with($orderIdMock)
                    ->willReturn($salesOrderInfoMock);
                $i++;
            }
            $salesOrderInfoMock
                ->expects($this->at($l))
                ->method('setMainOrderId')
                ->with($mainOrderIdMock);
            $l++;
            $salesOrderInfoMock
                ->expects($this->at($l))
                ->method('setMainOrderIncrementId')
                ->with($mainOrderIncrementIdMock);
            $l++;

            $this->salesOrderInfoRepositoryMock
                ->expects($this->at($i))
                ->method('save')
                ->with($salesOrderInfoMock)
                ->willReturn($salesOrderInfoMock);
            $i++;
            $this->eventManagerMock
                ->expects($this->at($j))
                ->method('dispatch')
                ->with(
                    'maas_sales_order_child_order',
                    [
                        'child_order_id' => $orderIdMock,
                        'main_order_id' => $mainOrderIdMock,
                        'child_order_increment_id' => $orderIncrementIdMock,
                        'main_order_increment_id' => $mainOrderIncrementIdMock,
                    ]
                );
            $j++;
        }
        $this->eventManagerMock
            ->expects($this->at($j))
            ->method('dispatch')
            ->with(
                'maas_sales_order_main_order',
                [
                    'main_order_id' => $mainOrderIdMock,
                    'main_order_increment_id' => $mainOrderIncrementIdMock,
                ]
            );
    }
}
