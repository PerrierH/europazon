<?php


namespace Maas\AttributeGroupSchema\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{

    /**
     * @inheritDoc
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $linkTable = $setup->getTable('eav_entity_attribute');
        $groupTable = $setup->getTable('eav_attribute_group');
        $conn = $setup->getConnection();
        $cols = $conn->describeTable($groupTable);
        if(isset($cols['attribute_group_id']) && $cols['attribute_group_id']['DATA_TYPE'] == 'int')
        {
            $setup->endSetup();
            return;
        }
        $foundFk = null;
        $fks = $conn->getForeignKeys($linkTable);
        foreach ($fks as $fk) {
            if($fk['COLUMN_NAME'] == 'attribute_group_id'
                && $fk['REF_COLUMN_NAME'] == 'attribute_group_id'
                && $fk['REF_TABLE_NAME'] == $groupTable)
            {
                $foundFk = $fk;
                break;
            }
        }
        if($foundFk)
        {
            $conn->dropForeignKey($linkTable, $foundFk['FK_NAME']);
        }
        $conn->changeColumn($linkTable, 'attribute_group_id', 'attribute_group_id', [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            'nullable' => false,
            'unsigned' => true
        ]);
        $conn->changeColumn($groupTable, 'attribute_group_id', 'attribute_group_id', [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            'nullable' => false,
            'unsigned' => true,
            'identity' => true
        ]);
        if($foundFk)
        {
            $conn->addForeignKey($foundFk['FK_NAME'], $foundFk['TABLE_NAME'], $foundFk['COLUMN_NAME'],
                $foundFk['REF_TABLE_NAME'], $foundFk['REF_COLUMN_NAME'], $foundFk['ON_DELETE']);
        }

        $setup->endSetup();
    }
}