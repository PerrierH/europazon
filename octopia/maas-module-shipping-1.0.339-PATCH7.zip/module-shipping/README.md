# Maas Shipping

## Purpose

A module used to create shipment using dynamically created carriers (called custom carriers).

## Custom carriers

#### Usage

In order to use a carrier use the method Maas/Shipping/Model/CarrierManager::initCarrier() with parameters :

- $code : the unique code of the carrier
- $title : the label visible in the frontend
- $trackingUrl : the base of the tracking url for a shipment (add the tracking number for the full url)
- $active : is the carrier usable in the frontend

It will return the carrier if it already exists, or create a custom carrier if not.

#### Data storage

Custom carriers are stored in two places :

- In the table maas_carrier used to generate configs (contains id, code, and title)
- In the table core_config_data where the actual configs are stored (contains tracking_url, model, active...)

#### Config retrieval

The configs of each custom carrier is visible in le BO strore/config/sales/shipping_method Those configs are create on
the fly using the method Maas/Shipping/Model/CarrierManager::getConfigStructure and dynamically injected in the magento
config.

#### Model

All custom carriers uses the same model Maas/Shipping/Model/Carrier/MarketplaceCarrier
