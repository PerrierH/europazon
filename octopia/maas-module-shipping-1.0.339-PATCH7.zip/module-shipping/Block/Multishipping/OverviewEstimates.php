<?php

namespace Maas\Shipping\Block\Multishipping;

use Exception;
use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Model\Service\ItemsType;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Checkout\Helper\Data;
use Magento\Checkout\Model\Session;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class OverviewEstimates
 *
 * @package Maas\Shipping\Block\Multishipping
 */
class OverviewEstimates extends Template
{
    /** @var Address */
    protected $address;

    /** @var ProductDelivery */
    protected $productDeliveryService;

    /** @var AddressItem */
    protected $addressItemService;

    /** @var TimezoneInterface */
    protected $localeDate;

    /** @var Session */
    protected $checkoutSession;

    /** @var ShippingAttributesManagement */
    protected $shippingAttributesManagement;

    protected $productsWithShippingMethods = [];

    protected $cachedProductMethods = [];

    protected $cachedCoreAmounts = [];

    protected $checkoutHelper;

    protected $shippingAmountsService;

    protected $extensionAttributesService;

    protected $storeManager;

    protected $itemsTypeService;

    /**
     * OverviewEstimates constructor.
     *
     * @param Template\Context $context
     * @param ProductDelivery $productDeliveryService
     * @param AddressItem $addressItemService
     * @param Session $checkoutSession
     * @param ShippingAttributesManagement $shippingAttributesManagement
     * @param Data $checkoutHelper
     * @param ShippingAmounts $shippingAmountsService
     * @param ExtensionAttributes $extensionAttributesService
     * @param array $data
     *
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @codeCoverageIgnore
     */
    public function __construct(
        Template\Context $context,
        ProductDelivery $productDeliveryService,
        AddressItem $addressItemService,
        Session $checkoutSession,
        ShippingAttributesManagement $shippingAttributesManagement,
        Data $checkoutHelper,
        ShippingAmounts $shippingAmountsService,
        ExtensionAttributes $extensionAttributesService,
        StoreManagerInterface $storeManager,
        ItemsType $itemsType,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->localeDate = $context->getLocaleDate();

        $this->productDeliveryService = $productDeliveryService;
        $this->addressItemService = $addressItemService;
        $this->checkoutSession = $checkoutSession;
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        $this->checkoutHelper = $checkoutHelper;
        $this->shippingAmountsService = $shippingAmountsService;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->storeManager = $storeManager;
        $this->itemsTypeService = $itemsType;

        $cart = $this->checkoutSession->getQuote();

        $productIds = [];
        foreach ($cart->getAllItems() as $item) {
            /** @var $item Item */
            $productIds[] = $item->getProduct()->getId();
        }
        $this->productsWithShippingMethods = $this->shippingAttributesManagement->getProductsWithDeliveryAttributes($productIds,
            true, $cart->getStoreId());
    }

    /**
     * @return Address
     * @codeCoverageIgnore simple getter
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param Address $address
     *
     * @return $this
     * @codeCoverageIgnore simple setter
     */
    public function setAddress($address)
    {
        $this->address = $address;
        return $this;
    }

    /**
     * @param Address\Item $item
     *
     * @return string
     * @throws Exception
     */
    public function getEstimateForItem(Address\Item $item)
    {
        $extraInfo = $this->addressItemService->loadExtraInfoById($item->getId());
        if ($extraInfo && $extraInfo->getDeliveryDelayMin() && $extraInfo->getDeliveryDelayMax()) {
            return $this->productDeliveryService->assembleDeliveryEstimatedDatesFromDelays(
                $extraInfo->getDeliveryDelayMin(), $extraInfo->getDeliveryDelayMax(),
                __("%5\$sDelivery between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                $this->localeDate
            );
        }
        return '';
    }

    /**
     * @param Address\Item $item
     *
     * @return string|bool
     */
    public function getMethodLabel(Address\Item $item)
    {
        $extraInfo = $this->addressItemService->loadExtraInfoById($item->getId());
        if (!$extraInfo) {
            return null;
        }
        $method = $this->getLoadedMethod($item, $extraInfo->getShippingMethod());
        return $method ? $method->getLabel() : false;
    }

    /**
     * @param Address\Item $item
     * @param string|$code
     *
     * @return false|ShippingMethodInterface
     *
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    protected function getLoadedMethod(Address\Item $item, $code)
    {
        if (!isset($this->cachedProductMethods[$item->getProductId()])) {
            $extraInfo = $this->addressItemService->loadExtraInfoById($item->getId());
            if ($extraInfo && $extraInfo->getShippingMethod() && isset($this->productsWithShippingMethods[$item->getProductId()])) {
                $quote = $this->checkoutSession->getQuote();
                $methods = $this->shippingAttributesManagement->getShippingMethodsFromEntity(
                    $this->productsWithShippingMethods[$item->getProductId()], $quote->getStoreId(),
                    $quote->getCurrency()
                );
                $methodsByCode = [];
                foreach ($methods as $method) {
                    $methodsByCode[$method->getCode()] = $method;
                }
                $this->cachedProductMethods[$item->getProductId()] = $methodsByCode;
            }
        }
        if (isset($this->cachedProductMethods[$item->getProductId()][$code])) {
            return $this->cachedProductMethods[$item->getProductId()][$code];
        }
        return false;
    }

    /**
     * @param Address\Item $item
     * @param bool $base
     *
     * @return string|bool
     */
    public function getFormattedShippingAmount(Address\Item $item, $base = false)
    {
        $amount = $this->getShippingAmount($item, $base);
        return ($amount !== false) ? $this->checkoutHelper->formatPrice($amount) : false;
    }

    /**
     * @param Address\Item $item
     * @param bool $base
     *
     * @return bool|float|int
     */
    public function getShippingAmount(Address\Item $item, $base = false)
    {
        $extraInfo = $this->addressItemService->loadExtraInfoById($item->getId());
        if (!$extraInfo) {
            return false;
        }
        $method = $this->getLoadedMethod($item, $extraInfo->getShippingMethod());
        if ($method) {
            return ($base ? $method->getBaseAmountForQuantity($item->getQty()) :
                $method->getCalculatedAmountForQuantity($item->getQty(), $item->getQuote()->getStore(),
                    $item->getQuote()->getCurrency()));
        }
        return false;
    }

    /**
     * @param Address\Item $item
     *
     * @return bool
     * @codeCoverageIgnore Delegates all logic
     */
    public function isAddressItemMarketplace($item)
    {
        return $this->itemsTypeService->isItemMarketplace($item);
    }

    /**
     * @param Address $address
     *
     * @return float
     */
    public function getShippingPriceForCoreItems($base = false)
    {
        if (!isset($this->cachedCoreAmounts[$this->address->getId()])) {
            $shippingAmount = $this->address->getShippingInclTax();
            $baseShippingAmount = $this->address->getBaseShippingInclTax();
            /** @var $item Address\Item */
            foreach ($this->address->getAllVisibleItems() as $item) {
                $extension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item->getQuote()->getItemById($item->getQuoteItemId()));
                if ($extension->getExtraInfo()->getOfferId()) {
                    $shippingAmount -= $this->getShippingAmount($item, false);
                    $baseShippingAmount -= $this->getShippingAmount($item, true);
                }
            }
            $this->cachedCoreAmounts[$this->address->getId()] = [$shippingAmount, $baseShippingAmount];
        }

        return $this->checkoutHelper->formatPrice(
            $base ? $this->cachedCoreAmounts[$this->address->getId()][1] : $this->cachedCoreAmounts[$this->address->getId()][0]
        );
    }
}
