<?php

namespace Maas\Shipping\Block\Multishipping;

use Exception;
use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Sales\Model\Service\AddressItem as AddressItemService;
use Maas\Shipping\Model\Service\ItemsType;
use Maas\Shipping\Model\Service\Multishipping\Shipping as ShippingService;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Quote\Api\Data\CurrencyInterface;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\Item\AbstractItem;

/**
 * Class MarketplaceMethods
 *
 * @package Maas\Shipping\Block\Multishipping
 * @codeCoverageIgnore delegates to other classes
 */
class MarketplaceMethods extends Template
{
    /** @var Address */
    protected $address;

    /** @var ShippingAttributesManagement */
    protected $shippingAttributesManagement;

    /** @var PriceCurrencyInterface */
    protected $priceCurrency;

    /** @var ProductInterface[]|null */
    protected $loadedProducts = null;

    /** @var CurrencyInterface */
    protected $currency = null;

    /** @var null|int */
    protected $quoteId = null;

    /** @var null|string|int */
    protected $scope = null;

    /** @var AddressItemService */
    protected $addressItemService;

    /** @var ShippingService */
    protected $shippingService;

    /** @var ProductDelivery */
    protected $productDelivery;

    /** @var TimezoneInterface */
    protected $localeDate;

    /** @var ItemsType */
    protected $itemsTypeService;

    /**
     * MarketplaceMethods constructor.
     *
     * @param Context $context
     * @param ShippingAttributesManagement $shippingAttributesManagement
     * @param PriceCurrencyInterface $priceCurrency
     * @param AddressItemService $addressItemService
     * @param ShippingService $shippingService
     * @param ProductDelivery $productDelivery
     *
     * @param array $data
     */
    public function __construct(
        Context $context,
        ShippingAttributesManagement $shippingAttributesManagement,
        PriceCurrencyInterface $priceCurrency,
        AddressItemService $addressItemService,
        ShippingService $shippingService,
        ProductDelivery $productDelivery,
        TimezoneInterface $localeDate,
        ItemsType $itemsTypeService,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        $this->priceCurrency = $priceCurrency;
        $this->addressItemService = $addressItemService;
        $this->shippingService = $shippingService;
        $this->productDelivery = $productDelivery;
        $this->localeDate = $localeDate;
        $this->itemsTypeService = $itemsTypeService;
    }

    /**
     * @param AddressItem $item
     *
     * @return ShippingMethodInterface[]
     */
    public function getShippingMethods(AddressItem $item)
    {
        $this->loadDataFromCart();
        if (isset($this->loadedProducts[$item->getProductId()])) {
            if ($item->getHasChildren()) {
                foreach ($item->getChildren() as $child) {
                    return $this->shippingAttributesManagement->getShippingMethodsFromQuote($child);
                }
            } else {
                return $this->shippingAttributesManagement->getShippingMethodsFromQuote($item);
            }
        }
        return [];
    }

    protected function loadDataFromCart()
    {
        if (is_null($this->loadedProducts)) {
            $quote = $this->getAddress()->getQuote();
            $this->scope = $quote->getStoreId();

            if ($quote) {
                $productIds = [];
                foreach ($quote->getAllItems() as $item) {
                    $productIds[] = $item->getProductId();
                }
            }
            $this->loadedProducts = $this->shippingAttributesManagement->getProductsWithDeliveryAttributes(
                $productIds, true, $this->scope
            );
            $this->currency = $quote->getCurrency();
        }
    }

    /**
     * @return Address
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param Address $address
     *
     * @return $this
     */
    public function setAddress($address)
    {
        $this->address = $address;
        if ($this->address->getQuoteId() != $this->quoteId) {
            $this->loadedProducts = null;
            $this->currency = null;
            $this->scope = null;
        }
        $this->quoteId = $this->address->getQuoteId();
        return $this;
    }

    /**
     * @param AbstractItem $item
     * @param string $code
     * @param bool $isFirst
     *
     * @return bool
     */
    public function isMethodSelected($item, $code, $isFirst)
    {
        if ($item instanceof Item) {
            // quote item - the first method is used
            return $isFirst;
        } else {
            // quote address item - the selected method is used
            /** @var AddressItem $item */
            $addressItemInfo = $this->addressItemService->loadExtraInfoById($item->getId());
            if ($addressItemInfo) {
                return $addressItemInfo->getShippingMethod() == $code;
            }
            return $isFirst;
        }
    }

    /**
     * @param Address $address
     *
     * @return bool
     */
    public function isAddressWithMarketplaceProducts(Address $address)
    {
        return $this->itemsTypeService->isItemsMarketplace($address->getAllItems());
    }

    /**
     * @param ShippingMethodInterface $method
     *
     * @return string
     * @throws Exception
     */
    public function getEstimation(
        ShippingMethodInterface $method
    ) {
        return $this->productDelivery->assembleDeliveryEstimatedDatesFromDelays(
            $method->getMinDelay(), $method->getMaxDelay(),
            __("Delivered between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
            $this->localeDate
        );
    }

    /**
     * @param AddressItem $item
     *
     * @return bool
     */
    public function isAddressItemMarketplace($item)
    {
        return $this->itemsTypeService->isItemMarketplace($item);
    }

    /**
     * @param AddressItem $item
     * @param ShippingMethodInterface $method
     *
     * @return string
     */
    public function getMethodItemFormattedPrice($item, $method)
    {
        return $this->formatPrice(
            $method->getCalculatedAmountForQuantity($item->getQty(), $this->scope, $this->currency)
        );
    }

    /**
     * @param float $amount
     *
     * @return string
     */
    public function formatPrice($amount)
    {
        return $this->priceCurrency->format($amount);
    }
}
