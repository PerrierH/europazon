<?php

namespace Maas\Shipping\Api;

use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Magento\Quote\Api\Data\CartInterface;

/**
 * Interface ShippingMethodManagementInterface
 *
 * @package Maas\Shipping\Api
 */
interface ShippingMethodManagementInterface
{
    /**
     * @param $cart CartInterface
     *
     * @return AvailableShippingMethodsInterface
     */
    public function getCartAvailableShippingMethods($cart);

    /**
     * @return AvailableShippingMethodsInterface
     */
    public function getCurrentCartAvailableShippingMethods();
}
