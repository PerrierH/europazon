<?php

namespace Maas\Shipping\Api;

use Maas\Shipping\Api\Data\SalesShipmentInfoInterface;
use Maas\Shipping\Api\Data\SalesShipmentInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SalesShipmentInfoRepositoryInterface
 *
 * @package Maas\Shipping\Api
 */
interface SalesShipmentInfoRepositoryInterface
{

    /**
     * @param SalesShipmentInfoInterface $salesOrderInfo
     *
     * @return SalesShipmentInfoInterface
     */
    public function save(SalesShipmentInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     *
     * @return SalesShipmentInfoInterface
     */
    public function get($id);

    /**
     * @param SalesShipmentInfoInterface $salesOrderInfo
     */
    public function delete(SalesShipmentInfoInterface $salesOrderInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SalesShipmentInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
