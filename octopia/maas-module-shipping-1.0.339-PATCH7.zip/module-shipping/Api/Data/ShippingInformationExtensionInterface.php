<?php

namespace Maas\Shipping\Api\Data;

/**
 * Interface ShippingInformationExtensionInterface
 *
 * @package Maas\Shipping\Api\Data
 */
interface ShippingInformationExtensionInterface
{
    /**
     * @return int
     */
    public function getQuoteItemId();

    /**
     * @param int $quoteItemId
     *
     * @return $this
     */
    public function setQuoteItemId($quoteItemId);

    /**
     * @return string
     */
    public function getShippingMethod();

    /**
     * @param string $shippingMethod
     *
     * @return $this
     */
    public function setShippingMethod($shippingMethod);
}
