<?php

namespace Maas\Shipping\Api\Data;

/**
 * Interface SelectedShippingMethodInterface
 *
 * @package Maas\Shipping\Api\Data
 */
interface SelectedShippingMethodInterface
{
    /**
     * @return int
     */
    public function getItemId();

    /**
     * @param int $itemId
     *
     * @return $this
     */
    public function setItemId($itemId);

    /**
     * @return string
     */
    public function getCode();

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setCode($code);
}
