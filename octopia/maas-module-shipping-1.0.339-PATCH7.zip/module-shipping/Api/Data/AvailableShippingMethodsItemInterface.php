<?php

namespace Maas\Shipping\Api\Data;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Quote\Model\Cart\Data\CartItem;

/**
 * Interface AvailableShippingMethodsItemInterface
 *
 * @package Maas\Shipping\Api\Data
 */
interface AvailableShippingMethodsItemInterface
{
    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return float
     */
    public function getQty();

    /**
     * @param float $qty
     *
     * @return $this
     */
    public function setQty($qty);

    /**
     * @return int
     */
    public function getOfferId();

    /**
     * @param int $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId);

    /**
     * @return int
     */
    public function getSellerId();

    /**
     * @param int $sellerId
     *
     * @return $this
     */
    public function setSellerId($sellerId);

    /**
     * @return int
     */
    public function getProductId();

    /**
     * @param int $productId
     *
     * @return $this
     */
    public function setProductId($productId);

    /**
     * @return string
     */
    public function getProductSku();

    /**
     * @param int $productSku
     *
     * @return $this
     */
    public function setProductSku($productSku);

    /**
     * @return string
     */
    public function getProductName();

    /**
     * @param string $productName
     *
     * @return $this
     */
    public function setProductName($productName);

    /**
     * @return ShippingMethodInterface[]
     */
    public function getShippingMethods();

    /**
     * @param ShippingMethodInterface[] $shippingMethods
     *
     * @return $this
     */
    public function setShippingMethods($shippingMethods);

    /**
     * @return array
     */
    public function getOptionList();

    /**
     * @param array
     *
     * @return $this
     */
    public function setOptionList($optionList);
}
