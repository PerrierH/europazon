<?php

namespace Maas\Shipping\Api\Data;

/**
 * Interface SalesShipmentInfoInterface
 *
 * @package Maas\Shipping\Api\Data
 */
interface SalesShipmentInfoInterface
{
    const SHIPMENT_ID = 'shipment_id';
    const TRACKING_URL = 'tracking_url';

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return string
     */
    public function getTrackingUrl();

    /**
     * @param string $trackingUrl
     *
     * @return $this
     */
    public function setTrackingUrl($trackingUrl);
}
