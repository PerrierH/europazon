<?php

namespace Maas\Shipping\Api\Data;

/**
 * Interface AvailableShippingMethodsInterface
 *
 * @package Maas\Shipping\Api\Data
 */
interface AvailableShippingMethodsInterface
{
    /**
     * @return bool
     */
    public function getHasMarketplaceProducts();

    /**
     * @return bool
     */
    public function getHasCoreProducts();

    /**
     * @return AvailableShippingMethodsItemInterface[]
     */
    public function getItems();

    /**
     * @param bool $hasMarketplaceProducts
     *
     * @return $this
     */
    public function setHasMarketplaceProducts($hasMarketplaceProducts);

    /**
     * @param bool $hasCoreProducts
     *
     * @return $this
     */
    public function setHasCoreProducts($hasCoreProducts);

    /**
     * @param AvailableShippingMethodsItemInterface[] $items
     *
     * @return $this
     */
    public function setItems($items);
}
