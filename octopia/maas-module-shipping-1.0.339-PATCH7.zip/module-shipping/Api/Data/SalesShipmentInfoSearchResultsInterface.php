<?php

namespace Maas\Shipping\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SalesShipmentInfoSearchResultsInterface
 *
 * @package Maas\Shipping\Api\Data
 */
interface SalesShipmentInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get Shipment Info list.
     *
     * @return SalesShipmentInfoInterface[]
     */
    public function getItems();

    /**
     * Set Shipment Info list.
     *
     * @param SalesShipmentInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
