<?php

namespace Maas\Shipping\Plugin;

use Exception;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Quote\Api\Data\ShippingAssignmentInterface as ShippingAssignment;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Quote\Model\Quote\AddressFactory;
use Magento\Quote\Model\QuoteFactory;
use Magento\SalesRule\Model\Quote\Address\Total\ShippingDiscount;
use Magento\SalesRule\Model\Validator;

/**
 * Class DiscountedShippingAmountStore
 * @package Maas\Shipping\Plugin\Multishipping
 */
class DiscountedShippingAmountStore
{
    /**
     * @var Validator
     */
    private $calculator;

    /**
     * @var AddressFactory
     */
    private $addressFactory;

    /**
     * @var QuoteFactory
     */
    private $quoteFactory;

    /**
     * @var AddressItem
     */
    private $addressItemService;

    /**
     * @var SalesQuoteItemInfoRepositoryInterface
     */
    private $salesQuoteItemInfoRepository;

    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributesService;

    /**
     * @param Validator $calculator
     * @param AddressFactory $addressFactory
     * @param QuoteFactory $quoteFactory
     * @param AddressItem $addressItemService
     * @param SalesQuoteItemInfoRepositoryInterface $salesQuoteItemInfoRepository
     */
    public function __construct(
        Validator $calculator,
        AddressFactory $addressFactory,
        QuoteFactory $quoteFactory,
        AddressItem $addressItemService,
        ExtensionAttributes $extensionAttributesService,
        SalesQuoteItemInfoRepositoryInterface $salesQuoteItemInfoRepository
    ) {
        $this->calculator = $calculator;
        $this->addressFactory = $addressFactory;
        $this->quoteFactory = $quoteFactory;
        $this->addressItemService = $addressItemService;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->salesQuoteItemInfoRepository = $salesQuoteItemInfoRepository;
    }

    /**
     * @param ShippingDiscount $subject
     * @param ShippingDiscount $result
     * @param Quote $quote
     * @param ShippingAssignment $shippingAssignment
     * @param Total $total
     * @return ShippingDiscount
     * @throws Exception
     */
    public function afterCollect(ShippingDiscount $subject, ShippingDiscount $result, Quote $quote, ShippingAssignment $shippingAssignment, Total $total)
    {
        $address = $shippingAssignment->getShipping()->getAddress();
        $items = $shippingAssignment->getItems();
        if (!count($items)) {
            return $result;
        }
        if ($total->getShippingAmountForDiscount() !== null && $address->getShippingAmountForDiscount()) {
            $shippingAmount = $address->getShippingAmountForDiscount();
            $shippingDiscountAmount = $address->getShippingDiscountAmount();
            $totalDiscountShippingAmount = 0.00;
            foreach ($items as $item) {
                $extraInfo = null;
                if (!$item->getFreeShipping()) {
                    if ($item instanceof Quote\Address\Item) {
                        $extraInfo = $this->addressItemService->loadExtraInfo($item);
                    }
                    if ($item instanceof Quote\Item) {
                        $extension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
                        if ($extension) {
                            $extraInfo = $extension->getExtraInfo();
                        }
                    }
                    if  ($extraInfo) {
                        $itemShippingAmount = $extraInfo->getShippingAmount();
                        $discountedShippingAmount = 0.00;
                        $extraInfo->setDiscountedShippingAmount($discountedShippingAmount);
                        if ($shippingDiscountAmount && $shippingAmount > 0) {
                            $itemShippingAmount = $itemShippingAmount * $item->getQty();
                            $discountShippingAmount = round(($itemShippingAmount * $shippingDiscountAmount) / $shippingAmount, 4);
                            $discountShippingAmountRemainder = $shippingDiscountAmount - $totalDiscountShippingAmount;
                            $totalDiscountShippingAmount += min($discountShippingAmountRemainder, $discountShippingAmount);
                            $discountedShippingAmount = min($discountShippingAmountRemainder, $discountShippingAmount) / $item->getQty();
                            $extraInfo->setDiscountedShippingAmount($discountedShippingAmount);
                        }
                        if ($item instanceof Quote\Address\Item) {
                            $this->addressItemService->saveExtraInfo($extraInfo);
                            $quoteItem = $item->getQuoteItem();
                            if ($quoteItem) {
                                $extension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($quoteItem);
                                if ($extraInfo = $extension->getExtraInfo()) {
                                    $extraInfo->setDiscountedShippingAmount($discountedShippingAmount);
                                    try {
                                        $this->salesQuoteItemInfoRepository->save($extraInfo);
                                    } catch (\Exception $e) {

                                    }
                                }
                            }
                        } else {
                            $this->salesQuoteItemInfoRepository->save($extraInfo);
                        }
                    }
                }
            }
        }
        return $result;
    }
}
