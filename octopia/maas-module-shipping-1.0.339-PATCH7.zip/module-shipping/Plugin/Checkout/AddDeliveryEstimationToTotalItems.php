<?php

namespace Maas\Shipping\Plugin\Checkout;

use Maas\Shipping\Model\Service\DeliveryEstimationOnTotalItems;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\CartTotalRepositoryInterface;
use Magento\Quote\Api\Data\TotalsInterface;

/**
 * Class AddSellersToTotalItems
 *
 * @package Maas\Shipping\Plugin\Checkout
 * @codeCoverageIgnore Delegates all logic
 */
class AddDeliveryEstimationToTotalItems
{
    /** @var CartRepositoryInterface */
    protected $cartRepository;

    /** @var DeliveryEstimationOnTotalItems */
    protected $deliveryEstimationOnTotalItems;

    /**
     * AddDeliveryEstimationToTotalItems constructor.
     *
     * @param CartRepositoryInterface $cartRepository
     * @param DeliveryEstimationOnTotalItems $deliveryEstimationOnTotalItems
     */
    public function __construct(
        CartRepositoryInterface $cartRepository,
        DeliveryEstimationOnTotalItems $deliveryEstimationOnTotalItems
    ) {
        $this->cartRepository = $cartRepository;
        $this->deliveryEstimationOnTotalItems = $deliveryEstimationOnTotalItems;
    }

    /**
     * @param CartTotalRepositoryInterface $subject
     * @param TotalsInterface $result
     * @param int $cartId
     *
     * @return TotalsInterface
     */
    public function afterGet(CartTotalRepositoryInterface $subject, $result, $cartId)
    {
        $this->deliveryEstimationOnTotalItems->executeWithQuoteItems($this->cartRepository->get($cartId),
            $result->getItems());
        return $result;
    }
}
