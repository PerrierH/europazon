<?php

namespace Maas\Shipping\Plugin\Checkout;

use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Checkout\Api\PaymentInformationManagementInterface;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\PaymentInterface;

/**
 * Class ApplyOnPaymentSave
 *
 * @package Maas\Shipping\Plugin\Checkout
 * @codeCoverageIgnore Delegates all logic
 */
class ApplyOnPaymentSave
{
    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /**
     * ApplyOnPaymentSave constructor.
     *
     * @param ShippingAmounts $shippingAmountsService
     */
    public function __construct(
        ShippingAmounts $shippingAmountsService
    ) {
        $this->shippingAmountsService = $shippingAmountsService;
    }

    /**
     * @param PaymentInformationManagementInterface $subject
     * @param int $cartId
     * @param PaymentInterface $paymentMethod
     * @param AddressInterface|null $billingAddress
     *
     * @return array
     */
    public function beforeSavePaymentInformationAndPlaceOrder(
        PaymentInformationManagementInterface $subject,
        $cartId,
        PaymentInterface $paymentMethod,
        AddressInterface $billingAddress = null
    ) {
        $this->shippingAmountsService->setEnabled(true);
        return [$cartId, $paymentMethod, $billingAddress];
    }

    /**
     * @param PaymentInformationManagementInterface $subject
     * @param int $cartId
     * @param PaymentInterface $paymentMethod
     * @param AddressInterface|null $billingAddress
     *
     * @return array
     */
    public function beforeSavePaymentInformation(
        PaymentInformationManagementInterface $subject,
        $cartId,
        PaymentInterface $paymentMethod,
        AddressInterface $billingAddress = null
    ) {
        $this->shippingAmountsService->setEnabled(true);
        return [$cartId, $paymentMethod, $billingAddress];
    }
}
