<?php

namespace Maas\Shipping\Plugin\Checkout;

use Maas\Shipping\Model\Service\Multishipping\ShippingPost;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Multishipping\Model\Checkout\Type\Multishipping;
use Laminas\Stdlib\ParametersInterface;

/**
 * Class ApplyOnMultishippingCheckout
 *
 * @package Maas\Shipping\Plugin\Checkout
 * @codeCoverageIgnore Delegates all logic
 */
class ApplyOnMultishippingCheckout
{
    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /** @var ShippingPost */
    protected $shippingPostHelper;

    /**
     * ApplyOnMultishippingCheckout constructor.
     *
     * @param ShippingAmounts $shippingAmountsService
     * @param ShippingPost $shippingPostHelper
     */
    public function __construct(
        ShippingAmounts $shippingAmountsService,
        ShippingPost $shippingPostHelper
    ) {
        $this->shippingAmountsService = $shippingAmountsService;
        $this->shippingPostHelper = $shippingPostHelper;
    }

    /**
     * @param Multishipping $subject
     *
     * @return array
     */
    public function beforeCreateOrders(Multishipping $subject)
    {
        $this->shippingAmountsService->setEnabled(true);
        return [];
    }

    /**
     * @param Multishipping $subject
     * @param ParametersInterface $methods
     *
     * @return mixed
     */
    public function beforeSetShippingMethods(Multishipping $subject, $methods)
    {
        return [$this->shippingPostHelper->validateAndAddMarketplaceMethods()];
    }

    /**
     * @param Multishipping $subject
     * @param Multishipping $result
     * @param ParametersInterface $methods
     *
     * @return mixed
     */
    public function afterSetShippingMethods(Multishipping $subject, $result, $methods)
    {
        $this->shippingPostHelper->applyMarketplaceMethods();
        return $result;
    }
}
