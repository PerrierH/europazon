<?php

namespace Maas\Shipping\Plugin\Checkout\Cart;

use Maas\Catalog\Model\ShippingAttributesManagement;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Checkout\Model\DefaultConfigProvider;
use Magento\Checkout\Model\Session;

/**
 * Class LoadShippingMethodsForCartItems
 *
 * @package Maas\Shipping\Plugin\Checkout\Cart
 */
class LoadShippingMethodsForCartItems
{
    /**
     * @var ShippingAttributesManagement
     */
    protected $shippingAttributesManagement;

    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * LoadShippingMethodsForCartItems constructor.
     *
     * @param ShippingAttributesManagement $shippingAttributesManagement
     * @param Session $checkoutSession
     */
    public function __construct(
        ShippingAttributesManagement $shippingAttributesManagement,
        Session $checkoutSession
    ) {
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * @param DefaultConfigProvider $subject
     * @param array $result
     *
     * @return array
     */
    public function afterGetConfig(DefaultConfigProvider $subject, $result)
    {
        if (isset($result['quoteItemData'])) {
            $quote = $this->checkoutSession->getQuote();
            $scope = $quote->getStoreId();
            $currency = $quote->getCurrency();

            $productIds = [];
            foreach ($result['quoteItemData'] as $itemData) {
                $productIds[] = $itemData['product_id'];
            }
            /** @var Collection $products */
            $products = $this->shippingAttributesManagement->getProductsWithDeliveryAttributes(
                $productIds, false, $scope
            );
            foreach ($result['quoteItemData'] as $itemIndex => $itemData) {
                if (isset($itemData['has_children'])) {
                    foreach ($quote->getAllItems() as $item) {
                        if ($item->getParentItemId() == $itemData['item_id']) {
                            $product = $item->getProduct();
                            break;
                        }
                    }
                } else {
                    $product = $products->getItemById($itemData['product_id']);
                }
                if ($product) {
                    // non-array objects can be removed, since they are rendered as empty objects once serialized
                    if (!(isset($itemData['extension_attributes']) && is_array($itemData['extension_attributes']))) {
                        $itemData['extension_attributes'] = [];
                    }
                    $methods = array_values($this->shippingAttributesManagement->getShippingMethodsFromEntity(
                        $product, $scope, $currency, true, $itemData['qty']
                    ));
                    $itemData['extension_attributes']['maas_available_shipping_methods'] = $methods;
                    $result['quoteItemData'][$itemIndex] = $itemData;
                }
            }
        }
        return $result;
    }
}
