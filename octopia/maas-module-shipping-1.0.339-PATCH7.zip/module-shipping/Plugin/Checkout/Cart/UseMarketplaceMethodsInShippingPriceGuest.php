<?php

namespace Maas\Shipping\Plugin\Checkout\Cart;

use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\Cart\AddSelectedMethods;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Api\Data\TotalSegmentExtensionInterfaceFactory;

/**
 * Class UseMarketplaceMethodsInShippingPriceGuest
 *
 * @package Maas\Shipping\Plugin\Checkout\Cart
 * @codeCoverageIgnore Delegates to parent and standard classes
 */
class UseMarketplaceMethodsInShippingPriceGuest extends UseMarketplaceMethodsInShippingPrice
{
    /**
     * @var QuoteIdMaskFactory
     */
    protected $quoteIdMaskFactory;

    /**
     * @var array
     */
    protected $cache = [];

    /**
     * UseMarketplaceMethodsInShippingPriceGuest constructor.
     *
     * @param ShippingAmounts $shippingAmounts
     * @param CartRepositoryInterface $cartRepository
     * @param AddSelectedMethods $addSelectedMethodsService
     * @param TotalSegmentExtensionInterfaceFactory $totalSegmentExtensionFactory
     * @param ShippingMethodManagement $shippingMethodManagement
     * @param Config $config
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     */
    public function __construct(
        ShippingAmounts $shippingAmounts,
        CartRepositoryInterface $cartRepository,
        AddSelectedMethods $addSelectedMethodsService,
        TotalSegmentExtensionInterfaceFactory $totalSegmentExtensionFactory,
        ShippingMethodManagement $shippingMethodManagement,
        Config $config,
        QuoteIdMaskFactory $quoteIdMaskFactory
    ) {
        parent::__construct($shippingAmounts, $cartRepository, $addSelectedMethodsService,
            $totalSegmentExtensionFactory, $shippingMethodManagement, $config);
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
    }

    /**
     * @param int|string $cartId
     *
     * @return int
     */
    protected function getCartId($cartId)
    {
        if(!isset($this->cache[$cartId]))
        {
            /** @var $quoteIdMask \Magento\Quote\Model\QuoteIdMask */
            $quoteIdMask = $this->quoteIdMaskFactory->create()->load($cartId, 'masked_id');
            $this->cache[$cartId] = $quoteIdMask->getQuoteId();
        }
        return $this->cache[$cartId];
    }
}