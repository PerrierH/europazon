<?php

namespace Maas\Shipping\Plugin\Checkout\Cart;

use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\Cart\AddSelectedMethods;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Checkout\Api\Data\TotalsInformationInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\TotalSegmentExtensionInterface;
use Magento\Quote\Api\Data\TotalSegmentExtensionInterfaceFactory;
use Magento\Quote\Api\Data\TotalsInterface;
use Magento\Quote\Model\Quote;

/**
 * Class UseMarketplaceMethodsInShippingPrice
 *
 * @package Maas\Shipping\Plugin\Checkout\Cart
 */
class UseMarketplaceMethodsInShippingPrice
{
    /**
     * @var ShippingAmounts
     */
    protected $shippingAmounts;

    /**
     * @var CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * @var AddSelectedMethods
     */
    protected $addSelectedMethodsService;

    /**
     * @var TotalSegmentExtensionInterfaceFactory
     */
    protected $totalSegmentExtensionFactory;

    /**
     * @var Config
     */
    protected $config;

    /**
     * UseMarketplaceMethodsInShippingPrice constructor.
     *
     * @param ShippingAmounts $shippingAmounts
     * @param CartRepositoryInterface $cartRepository
     * @param AddSelectedMethods $addSelectedMethodsService
     * @param TotalSegmentExtensionInterfaceFactory $totalSegmentExtensionFactory
     * @param ShippingMethodManagement $shippingMethodManagement
     * @param Config $config
     */
    public function __construct(
        ShippingAmounts $shippingAmounts,
        CartRepositoryInterface $cartRepository,
        AddSelectedMethods $addSelectedMethodsService,
        TotalSegmentExtensionInterfaceFactory $totalSegmentExtensionFactory,
        ShippingMethodManagement $shippingMethodManagement,
        Config $config
    ) {
        $this->shippingAmounts = $shippingAmounts;
        $this->cartRepository = $cartRepository;

        $this->addSelectedMethodsService = $addSelectedMethodsService;
        $this->totalSegmentExtensionFactory = $totalSegmentExtensionFactory;

        $this->shippingMethodManagement = $shippingMethodManagement;
        $this->config = $config;
    }

    /**
     * @param $subject
     * @param int $cartId
     * @param TotalsInformationInterface $addressInformation
     *
     * @return array
     */
    public function beforeCalculate(
        $subject,
        $cartId,
        TotalsInformationInterface $addressInformation
    ) {
        $ext = $addressInformation->getExtensionAttributes();
        if ($ext && $ext->getMaasSelectedShippingMethods()) {

            $cart = $this->cartRepository->get($this->getCartId($cartId));

            /** @var AvailableShippingMethodsInterface $methodsObject */
            $methodsObject = $this->shippingMethodManagement->getCartAvailableShippingMethods($cart);
            if ($methodsObject->getHasMarketplaceProducts() && (!$methodsObject->getHasCoreProducts())) {
                $addressInformation->setShippingCarrierCode($this->config->getMarketplaceShippingCarrier());
                $addressInformation->setShippingMethodCode($this->config->getMarketplaceShippingMethod());
            }

            $this->addSelectedMethodsService->setMethodsToQuoteItems($cart, $ext->getMaasSelectedShippingMethods());
            $this->shippingAmounts->setCartMode(true)->setEnabled(true);
        }
        return [$cartId, $addressInformation];
    }

    /**
     * @param $subject
     * @param TotalsInterface $result
     */
    public function afterCalculate(
        $subject,
        $result,
        $cartId,
        TotalsInformationInterface $addressInformation
    ) {
        $segments = $result->getTotalSegments();
        foreach ($segments as $segment) {
            if ($segment->getCode() == 'shipping') {
                $label = $this->getShippingMethodLabel(
                    $this->getCartId($cartId), $addressInformation->getShippingCarrierCode(), $addressInformation->getShippingMethodCode()
                );
                if ($label) {
                    /** @var TotalSegmentExtensionInterface $ext */
                    $ext = $segment->getExtensionAttributes();
                    if (!$ext) {
                        $ext = $this->totalSegmentExtensionFactory->create();
                    }
                    $ext->setMaasShippingLabelInTotal($label);
                    $segment->setExtensionAttributes($ext);
                }
            }
        }
        return $result;
    }

    /**
     * @param int $cartId
     * @param string $carrierCode
     * @param string $methodCode
     *
     * @return string|bool
     */
    protected function getShippingMethodLabel($cartId, $carrierCode, $methodCode)
    {
        $cart = $this->cartRepository->get($cartId);
        /** @var Quote $cart */
        if ($cart instanceof Quote) {
            $rates = $cart->getShippingAddress()->getAllShippingRates();
            foreach ($rates as $rate) {
                /** @var $rate Quote\Address\Rate */
                if ($rate->getCarrier() == $carrierCode && $rate->getMethod() == $methodCode) {
                    return $rate->getCarrierTitle() . ' - ' . $rate->getMethodTitle();
                }
            }
        }
        return false;
    }

    /**
     * @param int|string $cartId
     *
     * @return int
     */
    protected function getCartId($cartId)
    {
        return $cartId;
    }
}
