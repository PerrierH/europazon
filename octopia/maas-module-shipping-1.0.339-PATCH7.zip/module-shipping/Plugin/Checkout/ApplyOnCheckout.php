<?php

namespace Maas\Shipping\Plugin\Checkout;

use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Quote\Api\CartManagementInterface;
use Magento\Quote\Api\Data\PaymentInterface;

/**
 * Class ApplyOnCheckout
 *
 * @package Maas\Shipping\Plugin\Checkout
 * @codeCoverageIgnore Delegates all logic
 */
class ApplyOnCheckout
{
    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /**
     * ApplyOnCheckout constructor.
     *
     * @param ShippingAmounts $shippingAmountsService
     */
    public function __construct(
        ShippingAmounts $shippingAmountsService
    ) {
        $this->shippingAmountsService = $shippingAmountsService;
    }

    /**
     * @param CartManagementInterface $subject
     * @param int $cartId
     * @param PaymentInterface|null $paymentMethod
     *
     * @return array
     */
    public function beforePlaceOrder(
        CartManagementInterface $subject,
        $cartId,
        PaymentInterface $paymentMethod = null
    ) {
        $this->shippingAmountsService->setEnabled(true);
        return [$cartId, $paymentMethod];
    }
}
