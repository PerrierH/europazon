<?php

namespace Maas\Shipping\Plugin\Checkout;

use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Checkout\Api\GuestPaymentInformationManagementInterface;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\PaymentInterface;

/**
 * Class ApplyOnGuestPaymentSave
 *
 * @package Maas\Shipping\Plugin\Checkout
 * @codeCoverageIgnore Delegates all logic
 */
class ApplyOnGuestPaymentSave
{
    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /**
     * ApplyOnPaymentSave constructor.
     *
     * @param ShippingAmounts $shippingAmountsService
     */
    public function __construct(
        ShippingAmounts $shippingAmountsService
    ) {
        $this->shippingAmountsService = $shippingAmountsService;
    }

    /**
     * @param GuestPaymentInformationManagementInterface $subject
     * @param int $cartId
     * @param string $email
     * @param PaymentInterface $paymentMethod
     * @param AddressInterface|null $billingAddress
     *
     * @return array
     */
    public function beforeSavePaymentInformationAndPlaceOrder(
        GuestPaymentInformationManagementInterface $subject,
        $cartId,
        $email,
        PaymentInterface $paymentMethod,
        AddressInterface $billingAddress = null
    ) {
        $this->shippingAmountsService->setEnabled(true);
        return [$cartId, $email, $paymentMethod, $billingAddress];
    }

    /**
     * @param GuestPaymentInformationManagementInterface $subject
     * @param int $cartId
     * @param string $email
     * @param PaymentInterface $paymentMethod
     * @param AddressInterface|null $billingAddress
     *
     * @return array
     */
    public function beforeSavePaymentInformation(
        GuestPaymentInformationManagementInterface $subject,
        $cartId,
        $email,
        PaymentInterface $paymentMethod,
        AddressInterface $billingAddress = null
    ) {
        $this->shippingAmountsService->setEnabled(true);
        return [$cartId, $email, $paymentMethod, $billingAddress];
    }
}
