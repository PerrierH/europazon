<?php

namespace Maas\Shipping\Plugin\Checkout;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Api\ShippingAttributesManagementInterface;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\ShippingInformationExtensionInterface;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Maas\Shipping\Model\Service\ValidateMarketplaceShipping;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Checkout\Api\Data\ShippingInformationInterface;
use Magento\Checkout\Api\ShippingInformationManagementInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Quote\Api\CartItemRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Quote\Model\Quote\Item;

/**
 * Class SaveMarketplaceShipmentMethods
 *
 * @package Maas\Shipping\Plugin\Checkout
 */
class SaveMarketplaceShipmentMethods
{
    /** @var CartRepositoryInterface */
    protected $cartRepository;

    /** @var CartItemRepositoryInterface */
    protected $cartItemRepository;

    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var ShippingAttributesManagement */
    protected $shippingMethodManagement;

    /** @var SalesQuoteItemInfoRepositoryInterface */
    protected $salesQuoteItemInfoRepository;

    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /** @var ShippingAttributesManagementInterface */
    protected $shippingAttributesManagement;

    /** @var ValidateMarketplaceShipping */
    protected $validateMarketplaceShipping;

    protected ManagerInterface $eventManager;

    /**
     * SaveMarketplaceShipmentMethods constructor.
     *
     * @param CartRepositoryInterface $cartRepository
     * @param CartItemRepositoryInterface $cartItemRepository
     * @param ExtensionAttributes $extensionAttributesService
     * @param ShippingAttributesManagement $shippingMethodManagement
     * @param SalesQuoteItemInfoRepositoryInterface $salesQuoteItemInfoRepository
     * @param ShippingAmounts $shippingAmountsService
     * @param ShippingAttributesManagementInterface $shippingAttributesManagement
     * @param ValidateMarketplaceShipping $validateMarketplaceShipping
     */
    public function __construct(
        CartRepositoryInterface $cartRepository,
        CartItemRepositoryInterface $cartItemRepository,
        ExtensionAttributes $extensionAttributesService,
        ShippingAttributesManagement $shippingMethodManagement,
        SalesQuoteItemInfoRepositoryInterface $salesQuoteItemInfoRepository,
        ShippingAmounts $shippingAmountsService,
        ShippingAttributesManagementInterface $shippingAttributesManagement,
        ValidateMarketplaceShipping $validateMarketplaceShipping,
        ManagerInterface $eventManager
    ) {
        $this->cartRepository = $cartRepository;
        $this->cartItemRepository = $cartItemRepository;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->shippingMethodManagement = $shippingMethodManagement;
        $this->salesQuoteItemInfoRepository = $salesQuoteItemInfoRepository;
        $this->shippingAmountsService = $shippingAmountsService;
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        $this->validateMarketplaceShipping = $validateMarketplaceShipping;
        $this->eventManager = $eventManager;
    }

    /**
     * @param ShippingInformationManagementInterface $subject
     * @param int $cartId
     * @param ShippingInformationInterface $addressInformation
     *
     * @return array
     */
    public function beforeSaveAddressInformation(
        ShippingInformationManagementInterface $subject,
                                               $cartId,
        ShippingInformationInterface $addressInformation
    ) {
        $this->shippingAmountsService->setEnabled(true);
        $msmethods = $addressInformation->getExtensionAttributes()->getMarketplaceShippingMethods();
        if ($msmethods) {
            $cart = $this->cartRepository->get($cartId);

            $this->validateMarketplaceShipping->validateOnShippingSelection($cart, $addressInformation);

            $products = $this->getProductsWithDeliveryModes($cart);
            $this->applyMarketplaceShipmentMethods($cart, $products, $msmethods);
        }
        return [$cartId, $addressInformation];
    }

    /**
     * @param CartInterface $cart
     *
     * @return ProductInterface[]
     */
    protected function getProductsWithDeliveryModes($cart)
    {
        $ids = [];
        foreach ($cart->getItems() as $item) {
            if ($item instanceof Item) {
                // getProductId is not present in the interface and SKUs are not reliable enough
                $ids[] = $item->getProductId();
            }
        }
        return $this->shippingAttributesManagement->getProductsWithDeliveryAttributes($ids, true, $cart->getStoreId());
    }

    /**
     * @param CartInterface $cart
     * @param ProductInterface[] $products
     * @param ShippingInformationExtensionInterface[] $msmethods
     */
    protected function applyMarketplaceShipmentMethods($cart, $products, $msmethods)
    {
        $items = $cart->getItems();
        /** @var CartItemInterface $item */

        foreach ($items as $item) {
            // the interface does not offer a getter for product ID, and the SKU is not reliable enoughDeliveryEstimationOnTotalItems
            if ($item instanceof Item) {
                /** @var ShippingInformationExtensionInterface $msmethod */
                foreach ($msmethods as $msmethod) {
                    if ($item->getItemId() == $msmethod->getQuoteItemId() && isset($products[$item->getProductId()])) {
                        $this->copyDataToExtensionAttribute($item, $msmethod);
                    }
                }
            }
        }
    }

    /**
     * @param CartItemInterface $item
     * @param ShippingInformationExtensionInterface $msmethod
     */
    protected function copyDataToExtensionAttribute($item, $msmethod)
    {
        $extensionAttribute = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
        $extraInfo = $extensionAttribute->getExtraInfo();
        $shippingMethode = $this->shippingMethodManagement->getShippingMethodsFromQuote($item);
        $methodObject = $this->getMethodByCode($msmethod->getShippingMethod(), $shippingMethode);
        if ($methodObject) {
            $baseAmount = $methodObject->getBaseAmount();
            $extraInfo->setOriginalShippingAmount($baseAmount);
            $extraInfo->setDiscountedShippingAmount(0);
            if ($item->getFreeShipping()) {
                $extraInfo->setDiscountedShippingAmount($baseAmount);
                $methodObject->setBaseAmount(0);
            }
            $this->eventManager->dispatch(
                'maas_shipping_set_marketplace_method',
                ['item' => $item, 'method' => $methodObject]
            );
            $extraInfo->setShippingAmount($methodObject->getBaseAmount());
            $extraInfo->setShippingMethod($methodObject->getCode());
            $extraInfo->setDeliveryDelayMin($methodObject->getMinDelay());
            $extraInfo->setDeliveryDelayMax($methodObject->getMaxDelay());
            $this->salesQuoteItemInfoRepository->save($extraInfo);
        }
    }

    /**
     * @param string $code
     * @param ShippingMethodInterface[] $methodObjects
     *
     * @return ShippingMethodInterface|null
     */
    protected function getMethodByCode($code, $methodObjects)
    {
        foreach ($methodObjects as $methodObject) {
            if ($methodObject->getCode() == $code) {
                return $methodObject;
            }
        }
        return null;
    }
}
