<?php

namespace Maas\Shipping\Plugin\Amount;

use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Quote\Model\Quote\Address\Rate;

/**
 * Class AddShippingAmountToRates
 *
 * @package Maas\Shipping\Plugin\Amount
 * @codeCoverageIgnore Delegates all logic to other classes
 */
class AddShippingAmountToRates
{
    /** @var ShippingAmounts */
    protected $shippingAmounts;

    /**
     * AddShippingAmountToRates constructor.
     *
     * @param ShippingAmounts $shippingAmounts
     */
    public function __construct(ShippingAmounts $shippingAmounts)
    {
        $this->shippingAmounts = $shippingAmounts;
    }

    /**
     * @param Rate $subject
     * @param Rate $result
     * @return mixed
     */
    public function afterImportShippingRate(
        Rate $subject,
        $result
    ) {
        if ($result->getCode() == 'maas_marketplace') {
            $result = $this->shippingAmounts->process($result);
        }
        return $result;
    }
}
