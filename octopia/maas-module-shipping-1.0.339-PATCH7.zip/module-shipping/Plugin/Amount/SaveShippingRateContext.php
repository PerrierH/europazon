<?php

namespace Maas\Shipping\Plugin\Amount;

use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item\AbstractItem;

/**
 * Class SaveShippingRateContext
 *
 * @package Maas\Shipping\Plugin\Amount
 * @codeCoverageIgnore Delegates all logic to other classes
 */
class SaveShippingRateContext
{
    /** @var ShippingAmounts */
    protected $shippingAmounts;

    /**
     * SaveShippingRateContext constructor.
     *
     * @param ShippingAmounts $shippingAmounts
     */
    public function __construct(ShippingAmounts $shippingAmounts)
    {
        $this->shippingAmounts = $shippingAmounts;
    }

    /**
     * @param Address $subject
     * @param AbstractItem|null $item
     *
     * @return AbstractItem[]|null[]
     */
    public function beforeRequestShippingRates(
        Address $subject,
        AbstractItem $item = null
    ) {
        if ($subject->getShippingMethod() == 'maas_marketplace') {
            $subject->setBaseShippingAmount(0);
            $subject->setShippingAmount(0);
        }
        $this->shippingAmounts->setContext($subject, $item);
        return [$item];
    }

    /**
     * @param Address $subject
     * @param $result
     *
     * @return mixed
     */
    public function afterRequestShippingRates(
        Address $subject,
        $result
    ) {
        $this->shippingAmounts->unsetContext();
        if ($subject->getShippingMethod() == 'maas_marketplace') {
            $subject->setBaseShippingAmount($subject->getBaseShippingInclTax() - $subject->getBaseShippingTaxAmount());
            $subject->setShippingAmount($subject->getShippingInclTax() - $subject->getShippingTaxAmount());
        }
        return $result;
    }
}
