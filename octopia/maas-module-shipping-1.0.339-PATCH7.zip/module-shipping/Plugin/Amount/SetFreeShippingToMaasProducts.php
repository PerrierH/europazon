<?php

namespace Maas\Shipping\Plugin\Amount;

use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\Shipping\Model\Shipping;

/**
 * Class SetFreeShippingToMaasProducts
 *
 * @package Maas\Shipping\Plugin\Amount
 */
class SetFreeShippingToMaasProducts
{
    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var SalesQuoteItemInfoRepositoryInterface */
    protected $quoteItemInfoRepository;

    /** @var SearchCriteriaBuilder */
    protected $searchCriteriaBuilder;

    /**
     * @var \Maas\Sales\Model\Service\AddressItem
     */
    protected $addressItemService;

    /** @var array */
    protected $quoteItemExtraInfoCache = [];

    /**
     * SetFreeShippingToMaasProducts constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     * @param SalesQuoteItemInfoRepositoryInterface $quoteItemInfoRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @codeCoverageIgnore
     */
    public function __construct(
        ExtensionAttributes $extensionAttributesService,
        SalesQuoteItemInfoRepositoryInterface $quoteItemInfoRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        \Maas\Sales\Model\Service\AddressItem $addressItemService
    ) {
        $this->extensionAttributesService = $extensionAttributesService;
        $this->quoteItemInfoRepository = $quoteItemInfoRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->addressItemService = $addressItemService;
    }

    /**
     * @param Shipping $subject
     * @param string $carrierCode
     * @param RateRequest $request
     *
     * @return array
     */
    public function beforeCollectCarrierRates(Shipping $subject, $carrierCode, $request)
    {
        $this->quoteItemExtraInfoCache = null;
        $items = $request->getAllItems();
        foreach ($items as $item) {
            $extraInfo = $this->getExtraInfo($item);
            if ($extraInfo && $extraInfo->getOfferId()) {
                $item->setFreeShipping(true);
                $item->setWeight(0);
                $item->setRowWeight(0);
            }
        }
        return [$carrierCode, $request];
    }

    /**
     * @param AbstractItem $item
     *
     * @return SalesQuoteItemInfoInterface|mixed|null
     */
    protected function getExtraInfo($item)
    {
        if ($item instanceof Item) {
            return $this->getExtraInfoFromQuoteItem($item);
        } else {
            if ($item instanceof AddressItem) {
                return $this->getExtraInfoFromQuoteAddressItem($item);
            }
        }
        return null;
    }

    /**
     * @param Item $item
     *
     * @return SalesQuoteItemInfoInterface|null
     */
    protected function getExtraInfoFromQuoteItem($item)
    {
        if ($item->getExtensionAttributes()) {
            return $item->getExtensionAttributes()->getExtraInfo();
        } else {
            return $this->extensionAttributesService->getQuoteItemExtensionAttributes($item)->getExtraInfo();
        }
    }

    /**
     * @param AddressItem $item
     *
     * @return SalesQuoteItemInfoInterface|null
     */
    protected function getExtraInfoFromQuoteAddressItem($item)
    {
        $this->preloadQuoteItemExtensions($item->getQuote());
        return $this->quoteItemExtraInfoCache[$item->getQuoteItemId()] ?? null;
    }

    /**
     * @param Quote $quote
     */
    protected function preloadQuoteItemExtensions($quote)
    {
        if (is_null($this->quoteItemExtraInfoCache)) {
            $this->quoteItemExtraInfoCache = [];
            $quoteItemIdsToQuery = [];
            foreach ($quote->getAllItems() as $quoteItem) {
                /** @var $quoteItem Item */
                if ($quoteItem->getExtensionAttributes() && $quoteItem->getExtensionAttributes()->getExtraInfo()) {
                    $this->quoteItemExtraInfoCache[$quoteItem->getId()] = $quoteItem->getExtensionAttributes()->getExtraInfo();
                } else {
                    $quoteItemIdsToQuery[] = $quoteItem->getId();
                }
            }
            if ($quoteItemIdsToQuery) {
                foreach ($this->quoteItemInfoRepository->getList(
                    $this->searchCriteriaBuilder->addFilter(
                        'quote_item_id', $quoteItemIdsToQuery, 'in'
                    )->create()
                )->getItems() as $quoteItemInfo) {
                    $this->quoteItemExtraInfoCache[$quoteItemInfo->getId()] = $quoteItemInfo;
                }
            }
        }
    }

    /**
     * @param Shipping $subject
     * @param RateRequest $request
     *
     * @return RateRequest[]
     */
    public function beforeCollectRates(Shipping $subject, RateRequest $request)
    {
        $filteredItems = [];
        $packageQty = 0;
        foreach ($request->getAllItems() as $item) {
            /** @var Item $quoteItem */
            $quoteItem = $item instanceof AddressItem ? $item->getQuote()->getItemById($item->getQuoteItemId()) : $item;
            if (!$this->extensionAttributesService->getQuoteItemExtensionAttributes($quoteItem)->getExtraInfo()->getOfferId()) {
                $filteredItems[] = $item;
                $packageQty += $item->getQty();
            }
        }
        $request->setAllItems($filteredItems);
        $request->setPackageQty($packageQty);

        return [$request];
    }
}
