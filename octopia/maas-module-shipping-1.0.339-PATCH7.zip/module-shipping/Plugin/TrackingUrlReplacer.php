<?php

namespace Maas\Shipping\Plugin;

use Maas\Shipping\Model\Service\ExtensionAttributes;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Shipment;
use Magento\Sales\Model\Order\Shipment\Track;
use Magento\Shipping\Helper\Data;

/**
 * Class TrackingUrlReplacer
 *
 * @package Maas\Shipping\Plugin
 */
class TrackingUrlReplacer
{
    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /**
     * TrackingUrlReplacer constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     */
    public function __construct(
        ExtensionAttributes $extensionAttributesService
    ) {
        $this->extensionAttributesService = $extensionAttributesService;
    }

    /**
     * @param Data $subject
     * @param string $result
     * @param DataObject $model
     *
     * @return mixed|string
     */
    public function afterGetTrackingPopupUrlBySalesModel(Data $subject, $result, $model)
    {
        if ($model instanceof Order && $model->getShippingMethod() == 'maas_marketplace') {
            $result = $this->getUrlForOrder($model, $result);
        } else {
            if ($model instanceof Shipment) {
                $result = $this->getUrlFromShipment($model);
            } else {
                if ($model instanceof Track) {
                    $result = $this->getUrlFromTrack($model);
                }
            }
        }
        return $result;
    }

    /**
     * @param Order $model
     * @param string $originalResult
     *
     * @return string
     */
    protected function getUrlForOrder(Order $model, $originalResult)
    {
        $shipments = $model->getShipmentsCollection();

        if ($shipments->count() == 1) {
            return $this->getUrlFromShipment($shipments->getFirstItem());
        }
        return $originalResult;
    }

    /**
     * @param Shipment $shipment
     *
     * @return string
     */
    protected function getUrlFromShipment(Shipment $shipment)
    {
        return $this->extensionAttributesService->getShipmentExtensionAttributes($shipment)->getExtraInfo()->getTrackingUrl();
    }

    /**
     * @param Track $track
     *
     * @return string
     * @throws LocalizedException
     */
    protected function getUrlFromTrack(Track $track)
    {
        return $this->getUrlFromShipment($track->getShipment());
    }
}