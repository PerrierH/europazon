<?php

namespace Maas\Shipping\Plugin\Multishipping;

use Maas\Checkout\Block\Checkout\Shipping;
use Maas\Shipping\Model\Service\ItemsType;
use Magento\Quote\Model\Quote\Address;

/**
 * Class DontDisplayNoMethodsMessageForMarketplace
 *
 * @package Maas\Shipping\Plugin\Multishipping
 * @codeCoverageIgnore Delegation only
 */
class DontDisplayNoMethodsMessageForMarketplace
{
    /** @var ItemsType */
    protected $itemsTypeService;

    /**
     * DontDisplayNoMethodsMessageForMarketplace constructor.
     *
     * @param ItemsType $itemsTypeService
     */
    public function __construct(
        ItemsType $itemsTypeService
    ) {
        $this->itemsTypeService = $itemsTypeService;
    }

    /**
     * @param Shipping $subject
     * @param bool $result
     * @param Address $address
     *
     * @return bool
     */
    public function afterGetDisplayNoMethodsMessage(Shipping $subject, $result, Address $address)
    {
        return $this->itemsTypeService->isItemsCore($address->getAllItems());
    }
}
