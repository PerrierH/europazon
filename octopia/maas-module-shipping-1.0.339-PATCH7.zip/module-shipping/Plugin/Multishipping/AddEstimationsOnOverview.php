<?php

namespace Maas\Shipping\Plugin\Multishipping;

use Maas\Checkout\Block\Checkout\Overview;
use Maas\Shipping\Block\Multishipping\OverviewEstimates;
use Magento\Quote\Model\Quote\Address;

/**
 * Class AddEstimationsOnOverview
 *
 * @package Maas\Shipping\Plugin\Multishipping
 */
class AddEstimationsOnOverview
{
    /**
     * @param Overview $subject
     * @param string $result
     * @param Address $address
     *
     * @return string
     */
    public function afterRenderAddressAdditionalInfo(Overview $subject, $result, Address $address)
    {
        $child = $subject->getChildBlock('maas_marketplace_overview_estimates');
        if ($child) {
            /** @var $child OverviewEstimates */
            $child->setAddress($address);
            return $result . $child->toHtml();
        }
        return $result;
    }
}
