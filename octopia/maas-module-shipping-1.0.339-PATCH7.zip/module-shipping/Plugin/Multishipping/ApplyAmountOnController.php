<?php

namespace Maas\Shipping\Plugin\Multishipping;

use Maas\Sales\Model\Service\AddressItem;
use Maas\Shipping\Model\Service\Multishipping\ShippingRate;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Checkout\Model\Session;
use Magento\Multishipping\Controller\Checkout;
use Magento\Quote\Api\CartRepositoryInterface;

/**
 * Class ApplyAmountOnController
 *
 * @package Maas\Shipping\Plugin\Multishipping
 * @codeCoverageIgnore Delegates all logic to other classes
 */
class ApplyAmountOnController
{

    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /** @var Session */
    protected $checkoutSession;

    /** @var AddressItem */
    protected $addressItemService;

    /**
     * @var CartRepositoryInterface
     */
    protected $cartRepository;

    /**
     * ApplyAmountOnController constructor.
     *
     * @param ShippingAmounts $shippingAmountsService
     * @param Session $checkoutSession
     * @param AddressItem $addressItemService
     */
    public function __construct(
        ShippingAmounts $shippingAmountsService,
        Session $checkoutSession,
        AddressItem $addressItemService,
        CartRepositoryInterface $cartRepository,
        ShippingRate $shippingRate
    ) {
        $this->shippingAmountsService = $shippingAmountsService;
        $this->checkoutSession = $checkoutSession;
        $this->addressItemService = $addressItemService;
        $this->cartRepository = $cartRepository;
        $shippingRate->updateShippingRates(true);
    }

    /**
     * @param Checkout $subject
     *
     * @return array
     */
    public function beforeExecute(Checkout $subject)
    {
        $this->shippingAmountsService->setEnabled(true);
        return [];
    }
}
