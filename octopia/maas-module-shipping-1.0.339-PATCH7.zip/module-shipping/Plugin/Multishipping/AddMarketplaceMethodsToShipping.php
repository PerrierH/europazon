<?php

namespace Maas\Shipping\Plugin\Multishipping;

use Magento\Framework\DataObject;
use Magento\Multishipping\Block\Checkout\Shipping;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Rate;

/**
 * Class AddMarketplaceMethodsToShipping
 *
 * @package Maas\Shipping\Plugin\Multishipping
 * @codeCoverageIgnore delegates all logic to other classes
 */
class AddMarketplaceMethodsToShipping
{
    /**
     * @var \Maas\Shipping\Model\Service\Multishipping\Shipping
     */
    protected $shipping;

    /**
     * MarketplaceMethods constructor.
     *
     * @param \Maas\Shipping\Model\Service\Multishipping\Shipping $shipping
     */
    public function __construct(
        \Maas\Shipping\Model\Service\Multishipping\Shipping $shipping
    ) {
        $this->shipping = $shipping;
    }

    /**
     * @param Shipping $shipping
     * @param Rate[] $rates
     * @param Address $address
     *
     * @return array|mixed
     */
    public function afterGetShippingRates(
        Shipping $shipping,
        $rates,
        $address
    ) {
        return $this->shipping->getFilteredRatesForAddress($address, $rates);
    }

    /**
     * @param Shipping $shipping
     * @param string $result
     * @param DataObject $addressEntity
     *
     * @return string
     */
    public function afterGetItemsBoxTextAfter(
        Shipping $shipping,
        $result,
        DataObject $addressEntity
    ) {
        $childBlock = $shipping->getChildBlock('maas_marketplace_shipping_methods');
        if ($childBlock) {
            $childBlock->setAddress($addressEntity);
            return $result . $childBlock->toHtml();
        } else {
            return $result;
        }

    }
}
