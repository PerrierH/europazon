<?php


namespace Maas\Shipping\Test\Unit\Plugin;


use Maas\Shipping\Model\ShipmentManager;
use Maas\Shipping\Plugin\TrackingUrlGenerator;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Model\AbstractModel;
use Magento\Sales\Model\Order\Shipment\Track;
use Magento\Shipping\Helper\Data;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class TrackingUrlGeneratorTest extends TestCase
{
    /**
     * @var TrackingUrlGenerator
     */
    private $plugin;

    /**
     * @var MockObject
     */
    private $dataMock;

    /**
     * @var MockObject
     */
    private $trackMock;

    /**
     * @var MockObject
     */
    private $abstractModelMock;

    /**
     * @var Callable
     */
    private $proceedMock = false;

    /**
     * @var MockObject
     */
    private $isProceedMockCalled = false;

    /**
     * @var ObjectManager
     */
    private $objectManager;

    /**
     * @inheritDoc
     */
    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->dataMock = $this->createMock(Data::class);

        $this->proceedMock = function () {
            $this->isProceedMockCalled = true;
            return 'standard/url';
        };

        $this->trackMock = $this->createMock(Track::class);
        $this->abstractModelMock = $this->createMock(AbstractModel::class);

        $shipmentManagerMock = $this->createMock(ShipmentManager::class);
        $shipmentManagerMock->expects($this->atMost(2))->method('getTrackingUrl')
            ->willReturnOnConsecutiveCalls(
                null,
                'maas/url'
            );

        $this->plugin = $this->objectManager->getObject(
            TrackingUrlGenerator::class,
            ['shipmentManager' => $shipmentManagerMock]
        );
    }

    public function testAroundGetTrackingPopupUrlBySalesModelStandard()
    {
        $this->isProceedMockCalled = false;
        $this->assertEquals(
            'standard/url',
            $this->plugin->aroundGetTrackingPopupUrlBySalesModel(
                $this->dataMock, $this->proceedMock, $this->abstractModelMock
            )
        );
        $this->assertTrue($this->isProceedMockCalled);
    }

    public function testAroundGetTrackingPopupUrlBySalesModelMaas()
    {
        $this->isProceedMockCalled = false;
        $this->assertEquals(
            'standard/url',
            $this->plugin->aroundGetTrackingPopupUrlBySalesModel($this->dataMock, $this->proceedMock, $this->trackMock)
        );
        $this->assertTrue($this->isProceedMockCalled);

        $this->isProceedMockCalled = false;
        $this->assertEquals(
            'maas/url',
            $this->plugin->aroundGetTrackingPopupUrlBySalesModel($this->dataMock, $this->proceedMock, $this->trackMock)
        );
        $this->assertFalse($this->isProceedMockCalled);
    }

}
