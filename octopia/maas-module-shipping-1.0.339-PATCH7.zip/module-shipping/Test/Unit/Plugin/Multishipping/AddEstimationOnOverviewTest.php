<?php


namespace Maas\Shipping\Test\Unit\Plugin\Multishipping;

use Maas\Checkout\Block\Checkout\Overview;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Shipping\Block\Multishipping\OverviewEstimates;
use Maas\Shipping\Plugin\Multishipping\AddEstimationsOnOverview;
use Magento\Quote\Model\Quote\Address;

/**
 * Class AddEstimationOnOverviewTest
 *
 * @package Maas\Shipping\Test\Unit\Plugin\Multishipping
 */
class AddEstimationOnOverviewTest extends AbstractTestCase
{
    const RESULT = '<span>TEST</span>';
    const CHILDHTML = '<span>Child HTML</span>';

    public function testAddChildHtml()
    {
        $addressMock = $this->getInstanceMock(Address::class, [], []);
        $childBlockMock = $this->getInstanceMock(OverviewEstimates::class, null, [
            'setAddress' => [1, null, self::RETURN_VALUE, [$addressMock]],
            'toHtml' => [1, self::CHILDHTML],
        ], false);
        $overviewMock = $this->getInstanceMock(Overview::class, [], [
            'getChildBlock' => [1, $childBlockMock, self::RETURN_REFERENCE]
        ]);

        $this->assertEquals(self::RESULT . self::CHILDHTML,
            $this->getObject(AddEstimationsOnOverview::class, [])->afterRenderAddressAdditionalInfo($overviewMock,
                self::RESULT, $addressMock));
    }

    public function testAddChildHtmlWithoutChild()
    {
        $overviewMock = $this->getInstanceMock(Overview::class, [], [
            'getChildBlock' => [1, null]
        ]);
        $addressMock = $this->getInstanceMock(Address::class, [], []);

        $this->assertEquals(self::RESULT,
            $this->getObject(AddEstimationsOnOverview::class, [])->afterRenderAddressAdditionalInfo($overviewMock,
                self::RESULT, $addressMock));
    }
}