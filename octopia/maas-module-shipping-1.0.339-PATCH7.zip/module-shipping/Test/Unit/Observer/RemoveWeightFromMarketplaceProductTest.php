<?php

namespace Maas\Shipping\Test\Unit\Observer;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Shipping\Observer\RemoveWeightFromMarketplaceProduct;
use Magento\Catalog\Model\Product;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Quote\Model\Quote\Item;

class RemoveWeightFromMarketplaceProductTest extends AbstractTestCase
{

    protected $instance;

    /**
     * @dataProvider getCases
     */
    public function testExecute($offerId, $setWeightCalls, $setRowWeightCalls, $isWeightZero, $isRowWeightZero)
    {
        $weight = 10;
        $rowWeight = 50;

        $quoteItem = $this->getInstanceMock(Item::class, [], [
            'setWeight' => [
                $setWeightCalls,
                function ($amount) use (&$weight) {
                    $weight = $amount;
                },
                self::RETURN_CALLBACK
            ],
            'setRowWeight' => [
                $setRowWeightCalls,
                function ($amount) use (&$rowWeight) {
                    $rowWeight = $amount;
                },
                self::RETURN_CALLBACK
            ],
        ]);

        $productMock = $this->getInstanceMock(Product::class, [], [
            'getMaasOfferId' => [1, $offerId]
        ]);

        $eventMock = $this->getInstanceMock(Event::class, [], [
            'getQuoteItem' => [1, $quoteItem],
            'getProduct' => [1, $productMock]
        ]);

        $observerMock = $this->getInstanceMock(Observer::class, [], [
            'getEvent' => [2, $eventMock]
        ]);

        $this->instance->execute($observerMock);

        $this->assertEquals($isWeightZero ? 0 : 10, $weight);
        $this->assertEquals($isRowWeightZero ? 0 : 50, $rowWeight);
    }

    public function getCases()
    {
        return [
            'marketplace product loses weight' => [
                'offerId' => 123,
                'setWeightCalls' => 1,
                'setRowWeightCalls' => 1,
                'isWeightZero' => true,
                '$isRowWeightZero' => true
            ],
            'core product keeps weight' => [
                'offerId' => null,
                'setWeightCalls' => 0,
                'setRowWeightCalls' => 0,
                'isWeightZero' => false,
                '$isRowWeightZero' => false
            ],
        ];
    }

    protected function setUp()
    {
        $this->instance = $this->getObject(RemoveWeightFromMarketplaceProduct::class);
    }
}