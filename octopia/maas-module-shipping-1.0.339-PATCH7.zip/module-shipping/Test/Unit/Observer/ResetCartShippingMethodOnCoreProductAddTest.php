<?php

namespace Maas\Shipping\Test\Unit\Observer;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Shipping\Observer\ResetCartShippingMethodOnCoreProductAdd;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item;

class ResetCartShippingMethodOnCoreProductAddTest extends AbstractTestCase
{
    /**
     * @dataProvider getCases
     */
    public function testExecute($unsetSuccessful, $saveCalls)
    {
        $addressMock = $this->getInstanceMock(Address::class, [], []);

        $quoteMock = $this->getInstanceMock(Quote::class, [], [
            'getShippingAddress' => [1, $addressMock, self::RETURN_REFERENCE]
        ]);

        $quoteItemMock = $this->getInstanceMock(Item::class, [], [
            'getQuote' => [1, $quoteMock, self::RETURN_REFERENCE]
        ]);

        $eventMock = $this->getInstanceMock(Event::class, [], [
            'getData' => [1, $quoteItemMock, self::RETURN_REFERENCE, ['quote_item']]
        ]);

        $observerMock = $this->getInstanceMock(Observer::class, [], [
            'getEvent' => [1, $eventMock]
        ]);

        $shippingMethodServiceMock = $this->getInstanceMock(\Maas\Shipping\Model\Service\ShippingMethod::class, [], [
            'unsetFromCartAndAddress' => [1, $unsetSuccessful, self::RETURN_VALUE, [$quoteMock, $addressMock]]
        ]);

        $addressResourceMock = $this->getInstanceMock(\Magento\Quote\Model\ResourceModel\Quote\Address::class, [], [
            'save' => [$saveCalls, null, self::RETURN_SELF, [$addressMock]]
        ]);

        $cartRepositoryMock = $this->getInstanceMock(\Magento\Quote\Api\CartRepositoryInterface::class, [], [
            'save' => [$saveCalls, null, self::RETURN_SELF, [$quoteMock]]
        ], false);

        $instance = $this->getObject(ResetCartShippingMethodOnCoreProductAdd::class, [
            'addressResource' => $addressResourceMock,
            'cartRepository' => $cartRepositoryMock,
            'shippingMethodService' => $shippingMethodServiceMock
        ]);
        $instance->execute($observerMock);
    }

    public function getCases()
    {
        return [
            'unset successful' => [
                'unsetSuccessful' => true,
                'saveCalls' => 1
            ],
            'unset unsuccessful' => [
                'unsetSuccessful' => false,
                'saveCalls' => 0
            ]
        ];
    }
}