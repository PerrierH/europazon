<?php

namespace Maas\Shipping\Test\Unit\Observer\Checkout;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesOrderInfoInterface;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ShippingMethod;
use Maas\Shipping\Observer\Checkout\UpdateShippingMethodOnQuoteSubmit;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderInterface;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class UpdateShippingMethodOnQuoteSubmitTest
 *
 * @package Maas\Sales\Test\Unit\Observer
 */
class UpdateShippingMethodOnQuoteSubmitTest extends AbstractTestCase
{

    /**
     * @var object
     */
    private $shippingMethod;
    /**
     * @var object
     */
    private $config;
    /**
     * @var UpdateShippingMethodOnQuoteSubmit
     */
    private $sut;

    public function testHandleUpdateOnExecute()
    {
        $orderMock = $this->buildOrder($this->buildSalesOrderInfoInterface(5));
        //Arrange prepare data
        $observer = $this->buildObserver(
            [
                ['order', null, $orderMock],
            ]
        );

        $this->shippingMethod->expects($this->once())->method('setOnOrder')->with($orderMock);
        //Act call function
        $this->sut->execute($observer);
    }

    /**
     * @param null $salesOrderInfoInterface
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    private function buildOrder($salesOrderInfoInterface = null)
    {
        $orderExtensionAttribute = AnyBuilder::createForClass($this, OrderExtensionInterface::class, [
            'getExtraInfo' => [$this->any(), $salesOrderInfoInterface]
        ])->build();
        return AnyBuilder::createForClass($this, OrderInterface::class, [
            'getExtensionAttributes' => [$this->any(), $orderExtensionAttribute]
        ])->build();
    }

    /**
     * @param null $sellerId
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    private function buildSalesOrderInfoInterface($sellerId = null)
    {
        return AnyBuilder::createForClass($this, SalesOrderInfoInterface::class, [
            'getSellerId' => [$this->any(), $sellerId]
        ])->build();
    }

    /**
     * @param array $eventDataReturnMap
     *
     * @return Observer|PHPUnit_Framework_MockObject_MockObject
     */
    private function buildObserver(array $eventDataReturnMap)
    {
        /** @var Observer|PHPUnit_Framework_MockObject_MockObject $observerMock */
        $observerMock = $this->createMock(Observer::class);
        /** @var Event|PHPUnit_Framework_MockObject_MockObject $eventMock */
        $eventMock = $this->getMockBuilder(Event::class)->disableOriginalConstructor()
            ->setMethods(['getData'])
            ->getMock();
        $observerMock->expects($this->once())->method('getEvent')->willReturn($eventMock);
        $eventMock->expects($this->any())->method('getData')
            ->willReturnMap(
                $eventDataReturnMap
            );
        return $observerMock;
    }

    /**
     * @dataProvider getDataProviderOrder
     *
     * @param $order
     *
     * @throws AlreadyExistsException
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function testDoNotCallUpdateOnExecuteWhen($order)
    {
        //Arrange prepare data
        $observer = $this->buildObserver(
            [
                ['order', null, $order],
            ]
        );
        // Assert
        $this->shippingMethod->expects($this->never())->method('setOnOrder');
        //Act call function
        $this->sut->execute($observer);
    }

    public function getDataProviderOrder()
    {
        yield from [
            "order is null" => [null],
            "ExtraInfo is null" => [$this->buildOrder()],
            "ExtraInfo get sellerId is null" => [$this->buildOrder($this->buildSalesOrderInfoInterface())],
        ];
    }

    /**
     * Set Up
     *RegisterOfferAndSellerDuringOrderProcessTest
     *
     * @return void
     */
    protected function setUp()
    {
        $this->shippingMethod = $this->createMock(ShippingMethod::class);
        $this->config = AnyBuilder::createForClass($this, Config::class, [
            'getMarketplaceShippingCarrier' => [$this->any(), 'maas'],
            'getMarketplaceShippingMethod' => [$this->any(), 'marketplace'],
            'getMarketplaceShippingMethodLabel' => [$this->any(), 'MaaS - Marketplace'],
        ])->build();
        $this->sut = new UpdateShippingMethodOnQuoteSubmit(
            $this->shippingMethod,
            $this->config
        );
    }
}
