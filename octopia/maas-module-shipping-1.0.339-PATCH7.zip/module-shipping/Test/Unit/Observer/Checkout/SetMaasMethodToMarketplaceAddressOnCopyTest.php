<?php

namespace Maas\Shipping\Test\Unit\Observer\Checkout;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Shipping\Model\Service\ItemsType;
use Maas\Shipping\Model\Service\ShippingMethod;
use Maas\Shipping\Observer\Checkout\SetMaasMethodToMarketplaceAddressOnCopy;
use Magento\Framework\DataObject;
use Magento\Framework\Event;
use Magento\Framework\Event\Observer;
use Magento\Quote\Model\Quote;

class SetMaasMethodToMarketplaceAddressOnCopyTest extends AbstractTestCase
{

    /**
     * @dataProvider getCases
     */
    public function testExecute($itemsType, $doCallSet)
    {
        $targetCartMock = $this->getInstanceMock(Quote::class, [], [
            'getStoreId' => [$doCallSet ? 1 : 0, 1],
            'getItems' => [1, []]
        ]);

        $quoteAddressDataMock = new DataObject();

        $eventMock = $this->getInstanceMock(Event::class, [], [
            'getData' => [
                2,
                function ($key) use (&$targetCartMock, &$quoteAddressDataMock) {
                    switch ($key) {
                        case 'target_cart':
                            return $targetCartMock;
                        case 'address_data':
                            return $quoteAddressDataMock;
                    }
                },
                self::RETURN_CALLBACK
            ]
        ]);

        $observerMock = $this->getInstanceMock(Observer::class, [], [
            'getEvent' => [2, $eventMock]
        ]);

        $itemsTypeServiceMock = $this->getInstanceMock(ItemsType::class, [], [
            'getItemsType' => [1, $itemsType]
        ]);

        $shippingMethodServiceMock = $this->getInstanceMock(ShippingMethod::class, [], [
            'setOnAddressDataObject' => [$doCallSet ? 1 : 0, null, self::RETURN_SELF]
        ]);

        $instance = $this->getObject(SetMaasMethodToMarketplaceAddressOnCopy::class, [
            'shippingMethodService' => $shippingMethodServiceMock,
            'itemsType' => $itemsTypeServiceMock
        ]);

        $instance->execute($observerMock);

    }


    public function getCases()
    {
        return [
            'core' => [ItemsType::CORE, false],
            'marketplace' => [ItemsType::MARKETPLACE, true]
        ];
    }
}