<?php

namespace Maas\Shipping\Test\Unit\Block\Multishipping;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Shipping\Block\Multishipping\OverviewEstimates;
use Maas\Shipping\Model\Service\ExtensionAttributes;
use Magento\Catalog\Model\Product;
use Magento\Checkout\Model\Session;
use Magento\Framework\DataObject;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address\Item;
use Magento\Store\Model\Store;

class OverviewEstimatesTest extends AbstractTestCase
{
    public function getEstimateForItemSamples()
    {
        return [
            'no extra info' => [
                'extraInfoExists' => false,
                'deliveryDelayMin' => null,
                'deliveryDelayMinCalls' => 0,
                'deliveryDelayMax' => null,
                'deliveryDelayMaxCalls' => 0,
                'assembleCalls' => 0,
                'expected' => ''
            ],
            'no delays on extra info' => [
                'extraInfoExists' => true,
                'deliveryDelayMin' => null,
                'deliveryDelayMinCalls' => 1,
                'deliveryDelayMax' => null,
                'deliveryDelayMaxCalls' => 0,
                'assembleCalls' => 0,
                'expected' => ''
            ],
            'missing max delay on extra info' => [
                'extraInfoExists' => true,
                'deliveryDelayMin' => 1,
                'deliveryDelayMinCalls' => 1,
                'deliveryDelayMax' => null,
                'deliveryDelayMaxCalls' => 1,
                'assembleCalls' => 0,
                'expected' => ''
            ],
            'extra info with delays' => [
                'extraInfoExists' => true,
                'deliveryDelayMin' => 2,
                'deliveryDelayMinCalls' => 2,
                'deliveryDelayMax' => 5,
                'deliveryDelayMaxCalls' => 2,
                'assembleCalls' => 1,
                'expected' => '2-5'
            ],
        ];
    }

    /**
     * @dataProvider getEstimateForItemSamples
     */
    public function testGetEstimateForItem(
        $extraInfoExists,
        $deliveryDelayMin,
        $deliveryDelayMinCalls,
        $deliveryDelayMax,
        $deliveryDelayMaxCalls,
        $assembleCalls,
        $expected
    ) {
        $productDeliveryServiceMock = $this->getInstanceMock(ProductDelivery::class, [], [
            'assembleDeliveryEstimatedDatesFromDelays' => [
                $assembleCalls,
                function ($delayMin, $delayMax, $template, $localeDate) {
                    return "$delayMin-$delayMax";
                },
                self::RETURN_CALLBACK
            ]
        ]);

        $extraInfoMock = $extraInfoExists ?
            $this->getInstanceMock(CartItemExtension::class, [], [
                'getDeliveryDelayMin' => [$deliveryDelayMinCalls, $deliveryDelayMin],
                'getDeliveryDelayMax' => [$deliveryDelayMaxCalls, $deliveryDelayMax],
            ], false) : false;

        $addressItemServiceMock = $this->getInstanceMock(AddressItem::class, [], [
            'loadExtraInfoById' => [1, $extraInfoMock]
        ]);

        $addressItemMock = $this->getInstanceMock(Item::class, [], [
            'getId' => [1, 1]
        ]);

        $instance = $this->getInstance([
            'addressItemService' => $addressItemServiceMock,
            'productDeliveryService' => $productDeliveryServiceMock
        ]);

        $this->assertEquals($expected, $instance->getEstimateForItem($addressItemMock));
    }

    public function getMethodLabelSamples()
    {
        return [
            'no extra info' => [
                'extraInfoExists' => false,
                'productId' => 2,
                'productIdCalls' => 0,
                'productsWithShippingMethods' => [],
                'loadExtraInfoCalls' => 1,
                'shippingMethodCalls' => null,
                'shippingMethod' => null,
                'shippingMethodsFromEntity' => null,
                'shippingMethodsFromEntityCalls' => 0,
                'cachedMethods' => null,
                'expected' => null
            ],
            'invalid shipping method' => [
                'extraInfoExists' => true,
                'productId' => 2,
                'productIdCalls' => $this->any(),
                'productsWithShippingMethods' => [],
                'loadExtraInfoCalls' => $this->any(),
                'shippingMethodCalls' => $this->any(),
                'shippingMethod' => 'fake',
                'shippingMethodsFromEntity' => null,
                'shippingMethodsFromEntityCalls' => 0,
                'cachedMethods' => [
                    2 => $this->getShippingMethodObjects([
                        'standard' => "Standard",
                        'express' => 'Express'
                    ])
                ],
                'expected' => false
            ],
            'valid shipping method' => [
                'extraInfoExists' => true,
                'productId' => 2,
                'productIdCalls' => $this->any(),
                'productsWithShippingMethods' => [],
                'loadExtraInfoCalls' => $this->any(),
                'shippingMethodCalls' => $this->any(),
                'shippingMethod' => 'standard',
                'shippingMethodsFromEntity' => null,
                'shippingMethodsFromEntityCalls' => 0,
                'cachedMethods' => [
                    2 => $this->getShippingMethodObjects([
                        'standard' => "Standard",
                        'express' => 'Express'
                    ])
                ],
                'expected' => 'Standard'
            ],
            'no cache shipping method' => [
                'extraInfoExists' => true,
                'productId' => 2,
                'productIdCalls' => $this->any(),
                'productsWithShippingMethods' => [2 => $this->getInstanceMock(Product::class, [], [])],
                'loadExtraInfoCalls' => $this->any(),
                'shippingMethodCalls' => $this->any(),
                'shippingMethod' => 'standard',
                'shippingMethodsFromEntity' => $this->getShippingMethodObjects([
                    'standard' => "Standard",
                    'express' => 'Express'
                ], false),
                'shippingMethodsFromEntityCalls' => 1,
                'cachedMethods' => [],
                'expected' => 'Standard'
            ],
        ];
    }

    protected function getShippingMethodObjects($array, $assoc = true)
    {
        $result = [];
        foreach ($array as $code => $label) {
            $price = 0;
            if (is_array($label))
            {
                list($label, $price) = $label;
            }
            $object = $this->getInstanceMock(ShippingMethodInterface::class, [], [
                'getCode' => [$this->any(), $code],
                'getLabel' => [$this->any(), $label],
                'getBaseAmountForQuantity' => [$this->any(), function($qty) use($price) {
                    return round($price) * $qty;
                }, self::RETURN_CALLBACK],
                'getCalculatedAmountForQuantity' => [$this->any(), function($qty, $store, $currency) use($price) {
                    return $price * $qty;
                }, self::RETURN_CALLBACK]
            ], false);
            if ($assoc) {
                $result[$code] = $object;
            } else {
                $result[] = $object;
            }
        }
        return $result;
    }

    /**
     * @dataProvider getMethodLabelSamples
     */
    public function testGetMethodLabel(
        $extraInfoExists,
        $productId,
        $productIdCalls,
        $productsWithShippingMethods,
        $loadExtraInfoCalls,
        $shippingMethodCalls,
        $shippingMethod,
        $shippingMethodsFromEntity,
        $shippingMethodsFromEntityCalls,
        $cachedMethods,
        $expected
    ) {

        $extraInfoMock = $extraInfoExists ?
            $this->getInstanceMock(CartItemExtension::class, [], [
                'getShippingMethod' => [$shippingMethodCalls, $shippingMethod],
            ], false) : false;

        $addressItemServiceMock = $this->getInstanceMock(AddressItem::class, [], [
            'loadExtraInfoById' => [$loadExtraInfoCalls, $extraInfoMock]
        ]);

        $addressItemMock = $this->getInstanceMock(Item::class, [], [
            'getId' => [$this->any(), 1],
            'getProductId' => [$productIdCalls, $productId]
        ]);

        $shippingAttributesManagementMock = $this->getInstanceMock(ShippingAttributesManagement::class,
            [], [
                'getShippingMethodsFromEntity' => [$shippingMethodsFromEntityCalls, $shippingMethodsFromEntity],
                'getProductsWithDeliveryAttributes' => [1, $productsWithShippingMethods]
            ]);

        $customCartMock = $this->getInstanceMock(Quote::class, [], [
            'getStoreId' => [$this->any(), 1], 'getCurrency' => [$this->any(), false],
            'getAllItems' => [1, []],
        ]);

        $instance = $this->getInstance([
            'addressItemService' => $addressItemServiceMock,
            'shippingAttributesManagement' => $shippingAttributesManagementMock
        ], $customCartMock);

        $this->setAttribute($instance, 'cachedProductMethods', $cachedMethods);

        $this->assertEquals($expected, $instance->getMethodLabel($addressItemMock));
    }

    public function getFormattedShippingAmountSamples()
    {

        return [
            'no extra info' => [
                'extraInfoExists' => false,
                'productId' => 2,
                'productIdCalls' => 0,
                'loadExtraInfoCalls' => 1,
                'shippingMethodCalls' => 0,
                'shippingMethod' => null,
                'formatCalled' => false,
                'getStoreCalls' => 0,
                'getCurrencyCalls' => 0,
                'cachedMethods' => [],
                'expectedAmount' => false,
                'expected' => false
            ],
            'no amount' => [
                'extraInfoExists' => true,
                'productId' => 2,
                'productIdCalls' => $this->any(),
                'loadExtraInfoCalls' => $this->any(),
                'shippingMethodCalls' => $this->any(),
                'shippingMethod' => 'standard',
                'formatCalled' => false,
                'getStoreCalls' => 0,
                'getCurrencyCalls' => 0,
                'cachedMethods' => [],
                'expectedAmount' => false,
                'expected' => false
            ],
            'amount present' => [
                'extraInfoExists' => true,
                'productId' => 2,
                'productIdCalls' => $this->any(),
                'loadExtraInfoCalls' => $this->any(),
                'shippingMethodCalls' => $this->any(),
                'shippingMethod' => 'standard',
                'formatCalled' => true,
                'getStoreCalls' => 1,
                'getCurrencyCalls' => 1,
                'cachedMethods' => [
                    2 => $this->getShippingMethodObjects([
                        'standard' => ["Standard", 12.34],
                        'express' => ['Express', 56.78]
                    ])
                ],
                'expectedAmount' => 12.34,
                'expected' => 'f12.3400'
            ],
        ];
    }

    /**
     * @dataProvider getFormattedShippingAmountSamples
     */
    public function testGetFormattedShippingAmount($extraInfoExists, $productId, $productIdCalls, $loadExtraInfoCalls, $shippingMethodCalls, $shippingMethod, $formatCalled, $getStoreCalls, $getCurrencyCalls, $cachedMethods, $expectedAmount, $expected)
    {
        $quoteMock = $this->getInstanceMock(Quote::class, [], [
            'getStore' => [$getStoreCalls, $this->getInstanceMock(Store::class, [], [])],
            'getCurrency' => [$getCurrencyCalls, $this->getInstanceMock(\Magento\Quote\Api\Data\CurrencyInterface::class, [], [], false)],
        ]);

        $addressItemMock = $this->getInstanceMock(Item::class, [], [
            'getId' => [$this->any(), 1],
            'getProductId' => [$productIdCalls, $productId],
            'getQuote' => [$getStoreCalls+$getCurrencyCalls, $quoteMock],
            'getQty' => [$this->any(), 1]
        ]);

        $extraInfoMock = $extraInfoExists ?
            $this->getInstanceMock(CartItemExtension::class, [], [
                'getShippingMethod' => [$shippingMethodCalls, $shippingMethod],
            ], false) : false;

        $addressItemServiceMock = $this->getInstanceMock(AddressItem::class, [], [
            'loadExtraInfoById' => [$loadExtraInfoCalls, $extraInfoMock]
        ]);

        $checkoutHelperMock = $this->getInstanceMock(\Magento\Checkout\Helper\Data::class, [], [
            'formatPrice' => [$formatCalled ? 1 : 0, function($amount){
                return $amount === false ? $amount : 'f'.number_format($amount, 4 ,'.', '');
            }, self::RETURN_CALLBACK]
        ]);

        $instance = $this->getInstance([
            'addressItemService' => $addressItemServiceMock,
            'checkoutHelper' => $checkoutHelperMock
        ]);
        $this->setAttribute($instance, 'cachedProductMethods', $cachedMethods);

        $this->assertEquals($expected, $instance->getFormattedShippingAmount($addressItemMock));
    }

    public function testGetShippingPriceForCoreItems()
    {
        $extraInfoQuoteItem1 = $this->getInstanceMock(SalesQuoteItemInfo::class, [], [
            'getOfferId' => [1, 31]
        ]);

        $extensionAttributeQuoteItem1 = $this->getInstanceMock(CartItemExtension::class, [], [
            'getExtraInfo' => [1, $extraInfoQuoteItem1]
        ]);

        $extraInfoQuoteItem2 = $this->getInstanceMock(SalesQuoteItemInfo::class, [], [
            'getOfferId' => [1, 32]
        ]);

        $extensionAttributeQuoteItem2 = $this->getInstanceMock(CartItemExtension::class, [], [
            'getExtraInfo' => [1, $extraInfoQuoteItem2]
        ]);

        $quoteItem1Mock = $this->getInstanceMock(Quote\Item::class, [], [
            'getId' => [$this->any(), 1],
            'getExtensionAttributes' => [$this->any(), $extensionAttributeQuoteItem1],
            'getProduct' => [$this->any(), $this->getInstanceMock(Product::class, [], ['getId' => [$this->any(), 1]])]
        ]);

        $quoteItem2Mock = $this->getInstanceMock(Quote\Item::class, [], [
            'getId' => [$this->any(), 2],
            'getExtensionAttributes' => [$this->any(), $extensionAttributeQuoteItem2],
            'getProduct' => [$this->any(), $this->getInstanceMock(Product::class, [], ['getId' => [$this->any(), 2]])]
        ]);

        $quote = $this->getInstanceMock(Quote::class, [], [
            'getItemById' => [2, function($id) use(&$quoteItem1Mock, &$quoteItem2Mock){
                switch($id)
                {
                    case 1:
                        return $quoteItem1Mock;
                    case 2:
                        return $quoteItem2Mock;
                    default:
                        return null;
                }
            }, self::RETURN_CALLBACK],

        ]);

        $extensionAttributesServiceMock = $this->getInstanceMock(\Maas\Sales\Model\Service\ExtensionAttributes::class, [], [
            'getQuoteItemExtensionAttributes' => [2, function($item){
                return $item->getExtensionAttributes();
            }, self::RETURN_CALLBACK]
        ]);

        $addressItem1Mock = $this->getInstanceMock(Item::class, [], [
            'getQuote' => [1, $quote],
            'getQuoteItemId' => [$this->any(), 1]
        ]);

        $addressItem2Mock = $this->getInstanceMock(Item::class, [], [
            'getQuote' => [1, $quote],
            'getQuoteItemId' => [$this->any(), 2]
        ]);

        $address = $this->getInstanceMock(Quote\Address::class, [], [
            'getId' => [$this->any(), 1],
            'getShippingInclTax' => [1, 12.34], 'getBaseShippingInclTax' => [1, 12],
            'getAllVisibleItems' => [1, [11 => $addressItem1Mock, 12 => $addressItem2Mock]]
        ]);

        $checkoutHelperMock = $this->getInstanceMock(\Magento\Checkout\Helper\Data::class, [], [
            'formatPrice' => [2, function($amount){
                return $amount === false ? $amount : 'f'.number_format($amount, 4 ,'.', '');
            }, self::RETURN_CALLBACK]
        ]);

        $cartMock = $this->getInstanceMock(Quote::class, [], [
                'getAllItems' => [1, [$quoteItem1Mock, $quoteItem2Mock]],
                'getStoreId' => [$this->any(), 1],
            ]);

        $instance = $this->getInstance([
            'checkoutHelper' => $checkoutHelperMock,
            'extensionAttributesService' => $extensionAttributesServiceMock
        ], $cartMock, [
            'getShippingAmount' => [$this->any(), function($item, $isBase){
                switch($item->getQuoteItemId())
                {
                    case 1:
                        return $isBase ? 1 : 1.23;
                    case 2:
                        return $isBase ? 2 : 2.45;
                    default:
                        return 0;
                }
            }, self::RETURN_CALLBACK]
        ]);
        $instance->setAddress($address);
        $this->assertEquals('f8.6600', $instance->getShippingPriceForCoreItems());
        $this->assertEquals('f9.0000', $instance->getShippingPriceForCoreItems(true));
    }

    protected function getInstance($additionalParams, $customCartMock = null, $stubs = null)
    {
        $cartMock = $customCartMock ?? $this->getInstanceMock(Quote::class, [], [
                'getAllItems' => [1, []],
                'getStoreId' => [$this->any(), 1],
            ]);

        $checkoutSessionMock = $this->getInstanceMock(Session::class, [], [
            'getQuote' => [$this->any(), $cartMock, self::RETURN_REFERENCE],
        ]);

        $params = array_merge([
            'checkoutSession' => $checkoutSessionMock
        ], $additionalParams);

        return is_null($stubs) ? $this->getObject(OverviewEstimates::class, $params) :
            $this->getInstanceMock(OverviewEstimates::class, $params, $stubs);
    }
}