<?php

namespace Maas\Shipping\Test\Unit\Model;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Api\ShippingAttributesManagementInterface;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Builder\Cart\CartItemBuilder;
use Maas\Core\Test\Builder\Product\ProductBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterfaceFactory;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterfaceFactory;
use Maas\Shipping\Model\AvailableShippingMethodsItem;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Checkout\Model\Session;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Quote\Api\Data\CartItemExtensionInterface;

/**
 * Class UpdateShippingMethodOnQuoteSubmitTest
 *
 * @package Maas\Sales\Test\Unit\Model
 */
class ShippingMethodManagementTest extends AbstractTestCase
{
    const KEY_HAS_CORE = 'has_core_products';
    const KEY_HAS_MKP = 'has_marketplace_products';
    const KEY_ITEMS = 'items';

    protected $instance;

    protected $methodsData = [self::KEY_HAS_CORE => null, self::KEY_HAS_MKP => null, self::KEY_ITEMS => null];

    protected $methodsObject;

    public function testGetCartAvailableShippingMethodsMarketplace()
    {
        $cartItems = [
            $this->getQuoteItemMock(1, 1, 2, 3, 4),
            $this->getQuoteItemMock(5, 1, 6, 7, 8),
            $this->getQuoteItemMock(9, 2, 10, 11, 12),
            $this->getQuoteItemMock(13, 5, 14, 15, 16)
        ];

        $cart = CartBuilder::create($this, [
            'getitemsCollection' => [1, $cartItems],
            'getStoreId' => [$this->any(), 1],
            'getCurrency' => [$this->any(), 'EUR'],
        ])->build();

        $products = [
            2 => $this->getProductMock(2, 'first-product', 'First Product', ['standard', 'express']),
            6 => $this->getProductMock(6, 'second-product', 'Second Product', ['standard']),
            10 => $this->getProductMock(10, 'third-product', 'Third Product', ['express']),
            14 => $this->getProductMock(14, 'last-product', 'Last Product', ['standard', 'express'])
        ];

        $this->setUpWithArguments($products, [2, 6, 10, 14], 4);

        $this->instance->getCartAvailableShippingMethods($cart);

        $this->assertFalse($this->methodsData[self::KEY_HAS_CORE]);
        $this->assertTrue($this->methodsData[self::KEY_HAS_MKP]);
        $this->assertForItems([
                2 => [[2, 'standard'], [2, 'express']],
                6 => [[6, 'standard']],
                10 => [[10, 'express']],
                14 => [[14, 'standard'], [14, 'express']]
            ]
        );
    }

    protected function getQuoteItemMock($itemId, $qty, $productId, $offerId, $sellerId)
    {
        $extraInfo = AnyBuilder::createForClass($this, SalesQuoteItemInfo::class, [
            'getOfferId' => [$this->any(), $offerId],
            'getSellerId' => [$this->any(), $sellerId]
        ])->build();

        $extensionAttributes = AnyBuilder::createForClass($this, CartItemExtensionInterface::class, [
            'getExtraInfo' => [1, $extraInfo]
        ])->build();

        return CartItemBuilder::create($this, [
            'getExtensionAttributes' => [1, $extensionAttributes],
            'getProductId' => [$offerId ? 1 : 0, $productId],
            'getId' => [$offerId ? 1 : 0, $itemId],
            'getQty' => [$offerId ? 1 : 0, $qty],
        ])->build();


    }

    protected function getProductMock($productId, $sku, $name, $methods)
    {
        return ProductBuilder::create($this, [
            'getSku' => [$this->any(), $sku],
            'getName' => [$this->any(), $name],
            'getId' => [$this->any(), $productId],
            'getMethodCodes' => [$this->any(), $methods],
        ])->build();
    }

    protected function setUpWithArguments($products, $expectedProductIds, $getShippingMethodsFromEntityCallNumber)
    {
        $this->methodsObject = AnyBuilder::createForClass($this, AvailableShippingMethodsInterface::class, [
            'getHasMarketplaceProducts' => [$this->any(), $this->methodsData[self::KEY_HAS_MKP]],
            'getHasCoreProducts' => [$this->any(), $this->methodsData[self::KEY_HAS_CORE]],
            'getItems' => [$this->any(), $this->methodsData[self::KEY_ITEMS]],
            'setHasMarketplaceProducts' => [
                $this->any(),
                function ($param) {
                    $this->methodsData[self::KEY_HAS_MKP] = $param;
                    return $this->methodsObject;
                },
                self::RETURN_CALLBACK
            ],
            'setHasCoreProducts' => [
                $this->any(),
                function ($param) {
                    $this->methodsData[self::KEY_HAS_CORE] = $param;
                    return $this->methodsObject;
                },
                self::RETURN_CALLBACK
            ],
            'setItems' => [
                $this->any(),
                function ($param) {
                    $this->methodsData[self::KEY_ITEMS] = $param;
                    return $this->methodsObject;
                },
                self::RETURN_CALLBACK
            ]
        ])->build();

        $extensionAttributesService = AnyBuilder::createForClass($this, ExtensionAttributes::class, [
            'getQuoteItemExtensionAttributes' => [
                $this->any(),
                function ($item) {
                    if (method_exists($item, 'getExtensionAttributes')) {
                        return $item->getExtensionAttributes();
                    } else {
                        return null;
                    }
                },
                self::RETURN_CALLBACK
            ]
        ])->build();
        $salesQuoteItemInfo = $this->getInstanceMock(SalesQuoteItemInfoInterface::class, [], []);
        $productRepository = $this->getInstanceMock(ProductRepositoryInterface::class, [], []);
        $searchCriteriaBuilder = $this->getInstanceMock(SearchCriteriaBuilder::class, [], []);
        $shippingAttributesManagement = $this->getInstanceMock(ShippingAttributesManagementInterface::class, [], [
            'getFastestShippingMethodFromEntity' => [0],
            'getProductsWithDeliveryAttributes' => [1, $products, self::RETURN_VALUE, [$expectedProductIds, true]],
            'getShippingMethodsFromEntity' => [
                $getShippingMethodsFromEntityCallNumber,
                function ($product, $storeId, $currency, $asArrays) {
                    $shippingMethodMocks = [];
                    foreach ($product->getMethodCodes() as $code) {
                        $productId = $product->getId();
                        if (!isset($shippingMethodMocks[$productId])) {
                            $shippingMethodMocks[$productId] = [];
                        }
                        $shippingMethodMocks[$productId][] = AnyBuilder::createForClass(
                            $this, ShippingMethodInterface::class, [
                            'getProductId' => [$this->any(), $productId],
                            'getCode' => [$this->any(), $code]
                        ])->build();
                    }
                    return $shippingMethodMocks;
                },
                self::RETURN_CALLBACK
            ]
        ]);
        $checkoutSession = AnyBuilder::createForClass($this, Session::class, [])->setCreateAsFullMock(false)->build();
        $availableShippingMethodsFactory = $this->getInstanceMock(AvailableShippingMethodsInterfaceFactory::class, [], [
            'create' => [1, $this->methodsObject]
        ]);
        $availableShippingMethodsItemFactory = $this->getInstanceMock(AvailableShippingMethodsItemInterfaceFactory::class,
            [], [
                'create' => [$this->any(), $this->getObject(AvailableShippingMethodsItem::class)]
            ]);

        $this->instance = $this->getObject(
            ShippingMethodManagement::class, [
                'extensionAttributesService' => $extensionAttributesService,
                'salesQuoteItemInfo' => $salesQuoteItemInfo,
                'productRepository' => $productRepository,
                'searchCriteriaBuilder' => $searchCriteriaBuilder,
                'shippingAttributesManagement' => $shippingAttributesManagement,
                'checkoutSession' => $checkoutSession,
                'availableShippingMethodsFactory' => $availableShippingMethodsFactory,
                'availableShippingMethodsItemFactory' => $availableShippingMethodsItemFactory
            ]
        );
    }

    protected function assertForItems($expected)
    {
        $actualItems = $this->methodsData[self::KEY_ITEMS];
        $this->assertNotNull($actualItems);
        $this->assertEquals(count($expected), count($actualItems));

        foreach ($actualItems as $actualItem) {
            $productId = $actualItem->getProductId();

            /** @var $actualItem AvailableShippingMethodsItem */
            $methods = $actualItem->getShippingMethods();
            $this->assertArrayHasKey($productId, $expected);
            foreach ($methods as $methodItems) {
                /** @var ShippingMethodInterface $methodItem */
                foreach ($methodItems as $methodItem) {
                    $found = false;
                    foreach ($expected[$productId] as $expectedMethodId => $expectedMethod) {
                        if ($expectedMethod[0] == $productId && $expectedMethod[1] == $methodItem->getCode()) {
                            $found = true;
                        }
                    }
                    $this->assertTrue($found);
                }
            }
        }
    }

    public function testGetCartAvailableShippingMethodsCore()
    {
        $cartItems = [
            $this->getQuoteItemMock(1, 1, 2, null, null),
            $this->getQuoteItemMock(5, 1, 6, null, null),
            $this->getQuoteItemMock(9, 2, 10, null, null),
            $this->getQuoteItemMock(13, 5, 14, null, null)
        ];

        $cart = CartBuilder::create($this, [
            'getitemsCollection' => [1, $cartItems],
            'getStoreId' => [$this->any(), 1],
            'getCurrency' => [$this->any(), 'EUR'],
        ])->build();

        $products = [
            2 => $this->getProductMock(2, 'first-product', 'First Product', []),
            6 => $this->getProductMock(6, 'second-product', 'Second Product', []),
            10 => $this->getProductMock(10, 'third-product', 'Third Product', []),
            14 => $this->getProductMock(14, 'last-product', 'Last Product', [])
        ];

        $this->setUpWithArguments($products, [], 0);

        $this->instance->getCartAvailableShippingMethods($cart);

        $this->assertTrue($this->methodsData[self::KEY_HAS_CORE]);
        $this->assertFalse($this->methodsData[self::KEY_HAS_MKP]);
        $this->assertForItems([]);
    }

    public function testGetCartAvailableShippingMethodsMixed()
    {
        $cartItems = [
            $this->getQuoteItemMock(1, 1, 2, 3, 4),
            $this->getQuoteItemMock(5, 1, 6, null, null),
            $this->getQuoteItemMock(9, 2, 10, 11, 12),
            $this->getQuoteItemMock(13, 5, 14, null, null)
        ];

        $cart = CartBuilder::create($this, [
            'getitemsCollection' => [1, $cartItems],
            'getStoreId' => [$this->any(), 1],
            'getCurrency' => [$this->any(), 'EUR'],
        ])->build();

        $products = [
            2 => $this->getProductMock(2, 'first-product', 'First Product', ['standard', 'express']),
            6 => $this->getProductMock(6, 'second-product', 'Second Product', []),
            10 => $this->getProductMock(10, 'third-product', 'Third Product', ['express']),
            14 => $this->getProductMock(14, 'last-product', 'Last Product', [])
        ];

        $this->setUpWithArguments($products, [2, 10], 2);

        $this->instance->getCartAvailableShippingMethods($cart);

        $this->assertTrue($this->methodsData[self::KEY_HAS_CORE]);
        $this->assertTrue($this->methodsData[self::KEY_HAS_MKP]);
        $this->assertForItems([
            2 => [[2, 'standard'], [2, 'express']],
            10 => [[10, 'express']]
        ]);
    }
}
