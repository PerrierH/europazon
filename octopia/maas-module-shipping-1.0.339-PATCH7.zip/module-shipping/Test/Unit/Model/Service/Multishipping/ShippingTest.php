<?php

namespace Maas\Shipping\Test\Unit\Model\Service\Multishipping;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ItemsType;
use Maas\Shipping\Model\Service\Multishipping\Shipping;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Rate;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ShippingTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service\Multishipping
 */
class ShippingTest extends AbstractTestCase
{
    const DEFAULT_SHIPPING_CODE = 'maas_marketplace';

    public function testGetFilteredRatesForAddressWithCore()
    {
        $result = $this->getFilteredRatesForAddress(true);

        $reference = $this->getInitialRates();
        unset($reference['maas']);

        $this->assertEquals($reference, $result);
    }

    /**
     * @param bool $withCore
     *
     * @return mixed
     */
    protected function getFilteredRatesForAddress($withCore)
    {
        $instance = $this->getObject(Shipping::class, [
            'shippingConfig' => AnyBuilder::createForClass($this, Config::class, [
                'getMarketplaceShippingCode' => [$this->any(), self::DEFAULT_SHIPPING_CODE]
            ])->build(),
            'itemsTypeService' => AnyBuilder::createForClass($this, ItemsType::class, [
                'isItemsCore' => [$this->any(), $withCore]
            ])->build(),
        ]);

        $addressMock = AnyBuilder::createForClass($this, Address::class, [
            'getAllItems' => [1, []]
        ])->build();

        return $instance->getFilteredRatesForAddress($addressMock, $this->getInitialRates());

    }

    /***
     * @return array[]
     */
    protected function getInitialRates()
    {
        return [
            'flatrate' => ['fixed' => $this->getRateMock('flatrate_fixed')],
            'tablerate' => ['bestway' => $this->getRateMock('tablerate_bestway')],
            'maas' => ['marketplace' => $this->getRateMock(self::DEFAULT_SHIPPING_CODE)],
        ];
    }

    /**
     * @param $code
     *
     * @return Rate|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getRateMock($code)
    {
        return AnyBuilder::createForClass($this, Rate::class, [
            'getCode' => [$this->any(), $code]
        ])->build();
    }

    public function testGetFilteredRatesForAddressWithoutCore()
    {
        $result = $this->getFilteredRatesForAddress(false);
        $this->assertEquals([], $result);
    }
}
