<?php

namespace Maas\Shipping\Test\Unit\Model\Service\Multishipping;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartAddressBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Builder\Product\ProductBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesQuoteAddressItemInfo;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ItemsType;
use Maas\Shipping\Model\Service\Multishipping\ShippingPost;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\InputException;
use Magento\Quote\Model\Cart\Currency;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ShippingPostTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service\Multishipping
 */
class ShippingPostTest extends AbstractTestCase
{
    const MAAS_MARKETPLACE_METHOD = 'maas_marketplace';

    protected $isMarketplace = [];

    protected $addressItemExtraInfo = [];

    public function testValidateAndAddMarketplaceMethodsNoParams()
    {
        $instance = $this->getInstance([], [
            1 => [[11, 101, 1001, true], [12, 102, 1002, true], [13, 103, 1003, true]],
            2 => [[21, 201, 2001, true], [22, 202, 2002, true], [23, 203, 2003, true]],
            3 => [[31, 301, 3001, true], [32, 302, 3002, true], [33, 303, 3003, true]],
        ]);
        $this->expectException(InputException::class);
        $instance->validateAndAddMarketplaceMethods();
    }

    /**
     * @param $params
     * @param $itemsByAddress
     *
     * @return ShippingPost
     */
    protected function getInstance($params, $itemsByAddress)
    {
        $this->isMarketplace = [];
        $this->addressItemExtraInfo = [];

        $productsWithDeliveryAttributes = [];
        foreach ($itemsByAddress as $itemsForAddress) {
            foreach ($itemsForAddress as $itemData) {
                $productsWithDeliveryAttributes[$itemData[2]] = ProductBuilder::create($this, [
                    'getId' => [$this->any(), $itemData[2]]
                ])->build();
            }
        }

        return $this->getObject(ShippingPost::class, [
            'shippingConfig' => AnyBuilder::createForClass($this, Config::class, [
                'getMarketplaceShippingCode' => [$this->any(), self::MAAS_MARKETPLACE_METHOD]
            ])->build(),
            'request' => AnyBuilder::createForClass($this, RequestInterface::class, [
                'getParams' => [$this->any(), $params]
            ])->build(),
            'session' => AnyBuilder::createForClass($this, Session::class, [
                'getQuote' => [$this->any(), $this->getCartMock($itemsByAddress)]
            ])->build(),
            'itemsTypeService' => AnyBuilder::createForClass($this, ItemsType::class, [
                'isItemMarketplace' => [
                    $this->any(),
                    function ($item) {
                        $id = $item->getId();
                        return $this->isMarketplace[$id] ?? false;
                    },
                    self::RETURN_CALLBACK
                ],
                'getItemsType' => [
                    $this->any(),
                    function ($items) {
                        $hasCore = false;
                        $hasMarketplace = false;

                        foreach ($items as $item) {
                            if ($this->isMarketplace[$item->getId()] ?? false) {
                                $hasMarketplace = true;
                            } else {
                                $hasCore = true;
                            }
                        }
                        return $hasMarketplace ? ($hasCore ? ItemsType::MIXED : ItemsType::MARKETPLACE) : ($hasCore ? ItemsType::CORE : ItemsType::EMPTY);
                    },
                    self::RETURN_CALLBACK
                ],
            ])->build(),
            'shippingAttributesManagement' => AnyBuilder::createForClass($this, ShippingAttributesManagement::class, [

                'getProductsWithDeliveryAttributes' => [$this->any(), $productsWithDeliveryAttributes],
                'getShippingMethodsFromEntity' => [
                    $this->any(),
                    function ($productMock) {
                        return [
                            AnyBuilder::createForClass($this, ShippingMethodInterface::class, [
                                'getCode' => [$this->any(), 'standard'],
                                'getProductId' => [$this->any(), $productMock->getId()]
                            ])->build(),
                            AnyBuilder::createForClass($this, ShippingMethodInterface::class, [
                                'getCode' => [$this->any(), 'express'],
                                'getProductId' => [$this->any(), $productMock->getId()]
                            ])->build(),
                        ];
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build(),
            'addressItemService' => AnyBuilder::createForClass($this, AddressItem::class, [
                'loadExtraInfo' => [
                    $this->any(),
                    function ($addressItem) {
                        /** @var SalesQuoteAddressItemInfo $object */
                        $object = $this->getObject(SalesQuoteAddressItemInfo::class);
                        $object->setId($addressItem->getId());
                        return $object;
                    },
                    self::RETURN_CALLBACK
                ],
                'saveExtraInfo' => [
                    $this->any(),
                    function ($extraInfo) {
                        $this->addressItemExtraInfo[$extraInfo->getId()] = $extraInfo;
                    },
                    self::RETURN_CALLBACK
                ],
            ])->build()
        ]);
    }

    /**
     * @param array $itemsByAddress
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function getCartMock($itemsByAddress)
    {
        $allItems = [];
        $addressMocks = [];
        foreach ($itemsByAddress as $addressId => $addressItemsData) {
            $addressItems = [];
            foreach ($addressItemsData as $addressItemData) {
                $addressItem = $this->getCartAddressItemMock($addressItemData);
                $allItems[] = $addressItem;

            }
            $addressMocks[] = $this->getCartAddressMock($addressId, $addressItemsData);
        }

        $currency = $this->getObject(Currency::class);

        return CartBuilder::create($this, [
            'getAllShippingAddresses' => [$this->any(), $addressMocks],
            'getAllItems' => [$this->any(), $allItems],
            'getStoreId' => [$this->any(), 1],
            'getCurrency' => [$this->any(), $currency]
        ])->setUseConcreteClass(true)->build();
    }

    /**
     * @param array $data
     *
     * @return Item
     */
    protected function getCartAddressItemMock($data)
    {
        list($id, $quoteItemId, $productId, $isMarketplace) = $data;
        $this->isMarketplace[$id] = $isMarketplace;

        // using real items to store data
        /** @var Item $addressItem */
        $addressItem = $this->getObject(Item::class);
        $addressItem->setId($id);
        $addressItem->setQuoteItemId($quoteItemId);
        $addressItem->setProductId($productId);

        return $addressItem;
    }

    /**
     * @param int $id
     * @param array $itemsData
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function getCartAddressMock($id, $itemsData)
    {
        $items = [];
        foreach ($itemsData as $itemData) {
            $items[] = $this->getCartAddressItemMock($itemData);
        }

        return CartAddressBuilder::create($this, [
            'getId' => [$this->any(), $id],
            'getAllItems' => [$this->any(), $items],
        ])->setUseConcreteClass(true)->build();
    }

    public function testValidateAndAddMarketplaceMethodsIncomplete()
    {
        $instance = $this->getInstance([
            'shipping_method' => [

            ],
            'mp_shipping_method' => [
                12 => 'standard',
                13 => 'standard',
                21 => 'standard',
                23 => 'standard',
                31 => 'standard',
                32 => 'standard'
            ]
        ], [
            1 => [[11, 101, 1001, true], [12, 102, 1002, true], [13, 103, 1003, true]],
            2 => [[21, 201, 2001, true], [22, 202, 2002, true], [23, 203, 2003, true]],
            3 => [[31, 301, 3001, true], [32, 302, 3002, true], [33, 303, 3003, true]],
        ]);
        $this->expectException(InputException::class);
        $instance->validateAndAddMarketplaceMethods();
    }

    public function testValidateAndAddMarketplaceMethodsIncorrect()
    {
        $instance = $this->getInstance([
            'shipping_method' => [

            ],
            'mp_shipping_method' => [
                11 => 'standard',
                12 => 'completely-invented-method',
                13 => 'standard',
                21 => 'standard',
                22 => 'standard',
                23 => 'standard',
                31 => 'standard',
                32 => 'standard',
                33 => 'standard'
            ]
        ], [
            1 => [[11, 101, 1001, true], [12, 102, 1002, true], [13, 103, 1003, true]],
            2 => [[21, 201, 2001, true], [22, 202, 2002, true], [23, 203, 2003, true]],
            3 => [[31, 301, 3001, true], [32, 302, 3002, true], [33, 303, 3003, true]],
        ]);
        $this->expectException(InputException::class);
        $instance->validateAndAddMarketplaceMethods();
    }

    public function testValidateAndAddMarketplaceMethodsAndApply()
    {
        $instance = $this->getInstance([
            'shipping_method' => [

            ],
            'mp_shipping_method' => [
                11 => 'standard',
                12 => 'express',
                13 => 'standard',
                21 => 'express',
                22 => 'standard',
                23 => 'standard',
                31 => 'standard',
                32 => 'standard',
                33 => 'express'
            ]
        ], [
            1 => [[11, 101, 1001, true], [12, 102, 1002, true], [13, 103, 1003, true]],
            2 => [[21, 201, 2001, true], [22, 202, 2002, true], [23, 203, 2003, true]],
            3 => [[31, 301, 3001, true], [32, 302, 3002, true], [33, 303, 3003, true]],
        ]);
        $instance->validateAndAddMarketplaceMethods();
        $instance->applyMarketplaceMethods();

        $this->assertEquals('standard', $this->addressItemExtraInfo[11]->getShippingMethod());
        $this->assertEquals('express', $this->addressItemExtraInfo[12]->getShippingMethod());
        $this->assertEquals('standard', $this->addressItemExtraInfo[13]->getShippingMethod());
        $this->assertEquals('express', $this->addressItemExtraInfo[21]->getShippingMethod());
        $this->assertEquals('standard', $this->addressItemExtraInfo[22]->getShippingMethod());
        $this->assertEquals('standard', $this->addressItemExtraInfo[23]->getShippingMethod());
        $this->assertEquals('standard', $this->addressItemExtraInfo[31]->getShippingMethod());
        $this->assertEquals('standard', $this->addressItemExtraInfo[32]->getShippingMethod());
        $this->assertEquals('express', $this->addressItemExtraInfo[33]->getShippingMethod());
    }

    /**
     * @param int $id
     *
     * @return Address|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getShippingAddressMock($id)
    {
        return AnyBuilder::createForClass($this, Address::class, [
            'getId' => [$this->any(), $id],
            'getAllItems' => [$this->any(), []]
        ])->build();
    }
}
