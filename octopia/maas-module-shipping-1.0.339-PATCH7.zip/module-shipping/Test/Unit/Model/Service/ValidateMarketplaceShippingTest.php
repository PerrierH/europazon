<?php

namespace Maas\Shipping\Test\Unit\Model\Service;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Builder\Cart\CartItemBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterface;
use Maas\Shipping\Api\Data\ShippingInformationExtensionInterface;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ValidateMarketplaceShipping;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Checkout\Api\Data\ShippingInformationInterface;
use Magento\Framework\Exception\InputException;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Api\Data\CartItemInterface;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ShippingDataCopierTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service
 */
class ValidateMarketplaceShippingTest extends AbstractTestCase
{
    public function testValidateForMixed()
    {
        $instance = $this->getInstance(true, true, [
            1 => ['sku' => 'product1', 'methods' => ['standard', 'express']],
            2 => ['sku' => 'product2', 'methods' => ['standard']],
            3 => ['sku' => 'product3', 'methods' => ['express']],
            4 => ['sku' => 'product4', 'methods' => []]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    11 => ['product_id' => 1, 'sku' => 'product1', 'offer_id' => 21],
                    12 => ['product_id' => 2, 'sku' => 'product2', 'offer_id' => 22],
                    13 => ['product_id' => 3, 'sku' => 'product3', 'offer_id' => 23],
                    14 => ['product_id' => 4, 'sku' => 'product4', 'offer_id' => null],
                ])
            ],
        ])->build();

        $shipping = $this->getShippingInformationMock('flatrate_flatrate', [
            11 => 'standard',
            12 => 'standard',
            13 => 'express'
        ]);

        // no exceptions
        $instance->validateOnShippingSelection($cart, $shipping);
    }

    /**
     * @param bool $hasMarketplace
     * @param bool $hasCore
     * @param array $methodsItemsData
     *
     * @return ValidateMarketplaceShipping
     */
    protected function getInstance($hasMarketplace, $hasCore, $methodsItemsData)
    {
        $itemMocks = [];
        foreach ($methodsItemsData as $productId => $methodsItemData) {
            $methods = [];
            foreach ($methodsItemData['methods'] as $methodCode) {
                $method = AnyBuilder::createForClass($this, ShippingMethodInterface::class, [
                    'getCode' => [$this->any(), $methodCode]
                ])->build();
                $methods[] = $method;
            }
            $itemMocks[] = AnyBuilder::createForClass($this, AvailableShippingMethodsItemInterface::class, [
                'getProductId' => [$this->any(), $productId],
                'getProductSku' => [$this->any(), $methodsItemData['sku']],
                'getShippingMethods' => [$this->any(), $methods]
            ])->build();
        }

        return $this->getObject(ValidateMarketplaceShipping::class, [
            'shippingMethodManagement' => AnyBuilder::createForClass($this, ShippingMethodManagement::class, [
                'getCurrentCartAvailableShippingMethods' => [
                    $this->any(),
                    AnyBuilder::createForClass($this, AvailableShippingMethodsInterface::class, [
                        'getHasMarketplaceProducts' => [$this->any(), $hasMarketplace],
                        'getHasCoreProducts' => [$this->any(), $hasCore],
                        'getItems' => [$this->any(), $itemMocks]
                    ])->build()
                ]
            ])->build(),
            'config' => AnyBuilder::createForClass($this, Config::class, [
                'getMarketplaceShippingCode' => [$this->any(), 'maas_marketplace']
            ])->build(),
            'extensionAttributesService' => AnyBuilder::createForClass($this, ExtensionAttributes::class, [
                'getQuoteItemExtensionAttributes' => [
                    $this->any(),
                    function ($item) {
                        return $item->getExtensionAttributes();
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build(),
        ]);
    }

    /**
     * @param array $cartItemsData
     *
     * @return CartItemInterface[]
     */
    protected function getCartItems($cartItemsData)
    {
        $items = [];
        foreach ($cartItemsData as $itemId => $cartItemData) {
            $extraInfo = AnyBuilder::createForClass($this, SalesQuoteItemInfo::class, [
                'getOfferId' => [$this->any(), $cartItemData['offer_id']]
            ])->build();

            $extensionAttribute = AnyBuilder::createForClass($this, CartItemExtension::class, [
                'getExtraInfo' => [$this->any(), $extraInfo]
            ])->build();

            $items[] = CartItemBuilder::create($this, [
                'getId' => [$this->any(), $itemId],
                'getItemId' => [$this->any(), $itemId],
                'getProductId' => [$this->any(), $cartItemData['product_id']],
                'getSku' => [$this->any(), $cartItemData['sku']],
                'getExtensionAttributes' => [$this->any(), $extensionAttribute]
            ])->setUseConcreteClass(true)->build();
        }
        return $items;
    }

    /**
     * @param string $standardMethod
     * @param array $methodsPerQuoteItemId
     *
     * @return ShippingInformationInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getShippingInformationMock($standardMethod, $methodsPerQuoteItemId)
    {
        $selectedMethods = [];
        foreach ($methodsPerQuoteItemId as $itemId => $code) {
            $selectedMethods[$itemId] = AnyBuilder::createForClass($this, ShippingInformationExtensionInterface::class,
                [
                    'getQuoteItemId' => [$this->any(), $itemId],
                    'getShippingMethod' => [$this->any(), $code]
                ])->build();
        }

        $extensionAttributes = AnyBuilder::createForClass($this, ShippingInformationExtensionInterface::class, [
            'getMarketplaceShippingMethods' => [$this->any(), $selectedMethods]
        ])->build();

        list($carrier, $method) = explode('_', $standardMethod);
        return AnyBuilder::createForClass($this, ShippingInformationInterface::class, [
            'getExtensionAttributes' => [$this->any(), $extensionAttributes],
            'getShippingCarrierCode' => [$this->any(), $carrier],
            'getShippingMethodCode' => [$this->any(), $method]
        ])->build();
    }

    public function testValidateForCore()
    {
        $instance = $this->getInstance(false, true, [
            4 => ['sku' => 'product4', 'methods' => []],
            5 => ['sku' => 'product5', 'methods' => []]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    14 => ['product_id' => 4, 'sku' => 'product4', 'offer_id' => null],
                    15 => ['product_id' => 5, 'sku' => 'product5', 'offer_id' => null],
                ])
            ],
        ])->build();

        $shipping = $this->getShippingInformationMock('flatrate_flatrate', []);

        // no exceptions
        $instance->validateOnShippingSelection($cart, $shipping);
    }

    public function testValidateForCoreWrongStandardMethod()
    {
        $instance = $this->getInstance(false, true, [
            4 => ['sku' => 'product4', 'methods' => []],
            5 => ['sku' => 'product5', 'methods' => []]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    14 => ['product_id' => 4, 'sku' => 'product4', 'offer_id' => null],
                    15 => ['product_id' => 5, 'sku' => 'product5', 'offer_id' => null],
                ])
            ],
        ])->build();

        $shipping = $this->getShippingInformationMock('maas_marketplace', []);

        $this->expectException(InputException::class);
        $instance->validateOnShippingSelection($cart, $shipping);
    }

    public function testValidateForMarketplace()
    {
        $instance = $this->getInstance(true, false, [
            1 => ['sku' => 'product1', 'methods' => ['standard', 'express']],
            2 => ['sku' => 'product2', 'methods' => ['standard']],
            3 => ['sku' => 'product3', 'methods' => ['express']]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    11 => ['product_id' => 1, 'sku' => 'product1', 'offer_id' => 21],
                    12 => ['product_id' => 2, 'sku' => 'product2', 'offer_id' => 22],
                    13 => ['product_id' => 3, 'sku' => 'product3', 'offer_id' => 23]
                ])
            ],
        ])->build();

        $shipping = $this->getShippingInformationMock('maas_marketplace', [
            11 => 'standard',
            12 => 'standard',
            13 => 'express'
        ]);

        // no exceptions
        $instance->validateOnShippingSelection($cart, $shipping);
    }

    public function testValidateForMarketplaceWrongStandardMethod()
    {
        $instance = $this->getInstance(true, false, [
            1 => ['sku' => 'product1', 'methods' => ['standard', 'express']],
            2 => ['sku' => 'product2', 'methods' => ['standard']],
            3 => ['sku' => 'product3', 'methods' => ['express']]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    11 => ['product_id' => 1, 'sku' => 'product1', 'offer_id' => 21],
                    12 => ['product_id' => 2, 'sku' => 'product2', 'offer_id' => 22],
                    13 => ['product_id' => 3, 'sku' => 'product3', 'offer_id' => 23]
                ])
            ],
        ])->build();

        $shipping = $this->getShippingInformationMock('flatrate_flatrate', [
            11 => 'standard',
            12 => 'standard',
            13 => 'express'
        ]);

        $this->expectException(InputException::class);
        $instance->validateOnShippingSelection($cart, $shipping);
    }

    public function testValidateForMarketplaceMissingMethods()
    {
        $instance = $this->getInstance(true, false, [
            1 => ['sku' => 'product1', 'methods' => ['standard', 'express']],
            2 => ['sku' => 'product2', 'methods' => ['standard']],
            3 => ['sku' => 'product3', 'methods' => ['express']]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    11 => ['product_id' => 1, 'sku' => 'product1', 'offer_id' => 21],
                    12 => ['product_id' => 2, 'sku' => 'product2', 'offer_id' => 22],
                    13 => ['product_id' => 3, 'sku' => 'product3', 'offer_id' => 23]
                ])
            ],
        ])->build();

        $shipping = $this->getShippingInformationMock('maas_marketplace', [
            11 => 'standard',
            12 => 'standard'
        ]);

        $this->expectException(InputException::class);
        $instance->validateOnShippingSelection($cart, $shipping);
    }

    public function testValidateForMarketplaceWrongMarketplaceMethod()
    {
        $instance = $this->getInstance(true, false, [
            1 => ['sku' => 'product1', 'methods' => ['standard', 'express']],
            2 => ['sku' => 'product2', 'methods' => ['standard']],
            3 => ['sku' => 'product3', 'methods' => ['express']]
        ]);

        $cart = CartBuilder::create($this, [
            'getItems' => [
                $this->any(),
                $this->getCartItems([
                    11 => ['product_id' => 1, 'sku' => 'product1', 'offer_id' => 21],
                    12 => ['product_id' => 2, 'sku' => 'product2', 'offer_id' => 22],
                    13 => ['product_id' => 3, 'sku' => 'product3', 'offer_id' => 23]
                ])
            ],
        ])->build();

        // express in unusable with 12
        $shipping = $this->getShippingInformationMock('maas_marketplace', [
            11 => 'standard',
            12 => 'express',
            13 => 'express'
        ]);

        $this->expectException(InputException::class);
        $instance->validateOnShippingSelection($cart, $shipping);
    }
}
