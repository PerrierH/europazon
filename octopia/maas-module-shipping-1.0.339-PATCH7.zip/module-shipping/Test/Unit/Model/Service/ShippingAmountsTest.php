<?php

namespace Maas\Shipping\Test\Unit\Model\Service;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartAddressBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesQuoteAddressItemInfo;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\SalesQuoteItemInfoRepository;
use Maas\Sales\Model\Service\AddressItem as AddressItemService;
use Maas\Shipping\Model\ResourceModel\Quote;
use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchResults;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Quote\Model\Quote\Address\Rate;
use Magento\Quote\Model\Quote\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ShippingAmountsTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service
 */
class ShippingAmountsTest extends AbstractTestCase
{
    /** @var ShippingAmounts */
    protected $instance;

    protected $quoteHasAddressItems = false;

    protected $quoteAddressItemsExtraInfos = [];
    protected $quoteItemsExtraInfos = [];

    public function setUp()
    {
        $this->quoteAddressItemsExtraInfos = [];
        $this->quoteItemsExtraInfos = [];

        $this->instance = $this->getObject(ShippingAmounts::class, [
            'quoteResourceModel' => AnyBuilder::createForClass($this, Quote::class, [
                'getHasAddressItems' => [$this->any(), $this->quoteHasAddressItems]
            ])->build(),
            'searchCriteriaBuilder' => AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
                'addFilter' => [$this->any(), null, self::RETURN_SELF],
                'create' => [$this->any(), AnyBuilder::createForClass($this, SearchCriteria::class)->build()]
            ])->build(),
            'itemInfoRepository' => AnyBuilder::createForClass($this, SalesQuoteItemInfoRepository::class, [
                'getList' => [
                    $this->any(),
                    AnyBuilder::createForClass($this, SearchResults::class, [
                        'getItems' => [
                            $this->any(),
                            function () {
                                return $this->getQuoteItemExtraInfos();
                            },
                            self::RETURN_CALLBACK
                        ]
                    ])->build()
                ]
            ])->build(),
            'addressItemService' => AnyBuilder::createForClass($this, AddressItemService::class, [
                'loadExtraInfoById' => [
                    $this->any(),
                    function ($id) {
                        return $this->quoteAddressItemsExtraInfos[$id] ?? null;
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build()
        ]);
    }

    /**
     * @return array
     */
    protected function getQuoteItemExtraInfos()
    {
        return $this->quoteItemsExtraInfos;
    }

    public function testProcessDisabled()
    {
        // $quoteItemId, $offerId, $shippingAmount, $qty, $quoteAddressItemId
        $quoteAddress = $this->getQuoteAddressMock(1, false, [
            [11, 21, 1.00, 1, 31]
        ]);

        $rate = $this->getObject(Rate::class);
        $rate->setMethodTitle('Standard')->setPrice(1.00);

        $this->instance->setEnabled(false);
        $this->instance->setContext($quoteAddress);
        $this->instance->process($rate);

        $this->assertEquals('Standard', $rate->getMethodTitle());
        $this->assertEquals(1.00, $rate->getPrice());
    }

    /**
     * @param int $quoteId
     * @param bool $useAddressItems
     * @param array $itemsData
     *
     * @return AddressInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getQuoteAddressMock($quoteId, $useAddressItems, $itemsData)
    {
        $this->quoteHasAddressItems = $useAddressItems;
        $addressItems = [];
        $quoteItems = [];
        foreach ($itemsData as $itemData) {
            $addressItems[$itemData[4]] = $this->getQuoteAddressItemMock($itemData[0], $itemData[1], $itemData[2],
                $itemData[3], $itemData[4]);
        }
        foreach ($itemsData as $itemData) {
            $quoteItems[$itemData[0]] = $this->getQuoteItemMock($itemData[0], $itemData[1], $itemData[2], $itemData[3]);
        }

        $quoteAddress = CartAddressBuilder::create($this, [
            'getQuoteId' => [$this->any(), $quoteId],
            'getQuote' => [
                $this->any(),
                CartBuilder::create($this, [
                    'getAllItems' => [$this->any(), $this->quoteHasAddressItems ? $addressItems : $quoteItems]
                ])->build()
            ],
            'getAllItems' => [$this->any(), $this->quoteHasAddressItems ? $addressItems : $quoteItems],
            'getItemById' => [
                $this->any(),
                function ($quoteItemId) use ($quoteItems) {
                    return $quoteItems[$quoteItemId] ?? null;
                }
            ]
        ])->build();
        return $quoteAddress;
    }

    /**
     * @param int $quoteItemId
     * @param int $offerId
     * @param float $shippingAmount
     * @param float $qty
     * @param int $quoteAddressItemId
     *
     * @return AddressItem|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getQuoteAddressItemMock($quoteItemId, $offerId, $shippingAmount, $qty, $quoteAddressItemId)
    {
        $this->quoteAddressItemsExtraInfos[$quoteAddressItemId] = AnyBuilder::createForClass($this,
            SalesQuoteAddressItemInfo::class, [
                'getShippingAmount' => [$this->any(), $shippingAmount]
            ])->build();

        return AnyBuilder::createForClass($this, AddressItem::class, [
            'getId' => [$this->any(), $quoteAddressItemId],
            'getQuoteItemId' => [$this->any(), $quoteItemId],
            'getQty' => [$this->any(), $qty],
            'getQuote' => [
                $this->any(),
                CartBuilder::create($this, [
                    'getItemById' => [
                        $this->any(),
                        $this->getQuoteItemMock($quoteItemId, $offerId, $shippingAmount, $qty),
                        self::RETURN_VALUE,
                        [$quoteItemId]
                    ]
                ])->build()
            ]
        ])->build();
    }

    /**
     * @param int $quoteItemId
     * @param int $offerId
     * @param float $shippingAmount
     * @param float $qty
     *
     * @return Item|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getQuoteItemMock($quoteItemId, $offerId, $shippingAmount, $qty)
    {
        $extraInfo = AnyBuilder::createForClass($this, SalesQuoteItemInfo::class, [
            'getId' => [$this->any(), $quoteItemId],
            'getOfferId' => [$this->any(), $offerId],
            'getShippingAmount' => [$this->any(), $shippingAmount]
        ])->build();

        $this->quoteItemsExtraInfos[$quoteItemId] = $extraInfo;

        return AnyBuilder::createForClass($this, Item::class, [
            'getId' => [$this->any(), $quoteItemId],
            'getItemId' => [$this->any(), $quoteItemId],
            'getQty' => [$this->any(), $qty],
            'getExtensionAttributes' => [
                $this->any(),
                AnyBuilder::createForClass($this, CartItemExtension::class, [
                    'getExtraInfo' => [
                        $this->any(),
                        $extraInfo
                    ]
                ])->build()
            ]
        ])->build();
    }

    public function testProcessQuoteItems()
    {
        // $quoteItemId, $offerId, $shippingAmount, $qty, $quoteAddressItemId
        $quoteAddress = $this->getQuoteAddressMock(1, false, [
            [11, 21, 1.00, 1, 31],
            [12, 22, 1.50, 2, 32]
        ]);

        $rate = $this->getObject(Rate::class);
        $rate->setMethodTitle('Standard')->setPrice(1.00);

        $this->instance->setEnabled(true);
        $this->instance->setContext($quoteAddress);
        $this->instance->process($rate);

        $this->assertEquals('Standard' . ' / ' . __('Marketplace'), $rate->getMethodTitle());
        $this->assertEquals(5.00, $rate->getPrice());
    }

    public function testProcessAddressQuoteItems()
    {
        // $quoteItemId, $offerId, $shippingAmount, $qty, $quoteAddressItemId
        $quoteAddress = $this->getQuoteAddressMock(1, true, [
            [11, 21, 1.00, 1, 31],
            [12, 22, 1.50, 2, 32]
        ]);

        $rate = $this->getObject(Rate::class);
        $rate->setMethodTitle('Standard')->setPrice(1.00);

        $this->instance->setEnabled(true);
        $this->instance->setContext($quoteAddress);
        $this->instance->process($rate);

        $this->assertEquals('Standard' . ' / ' . __('Marketplace'), $rate->getMethodTitle());
        $this->assertEquals(5.00, $rate->getPrice());
    }

    public function testProcessQuoteItemsNoDefaultFees()
    {
        // $quoteItemId, $offerId, $shippingAmount, $qty, $quoteAddressItemId
        $quoteAddress = $this->getQuoteAddressMock(1, false, [
            [11, 21, 1.00, 1, 31],
            [12, 22, 1.50, 2, 32]
        ]);

        $rate = $this->getObject(Rate::class);
        $rate->setMethodTitle('Standard')->setPrice(0.0000);

        $this->instance->setEnabled(true);
        $this->instance->setContext($quoteAddress);
        $this->instance->process($rate);

        $this->assertEquals('' . __('Marketplace'), $rate->getMethodTitle());
        $this->assertEquals(4.00, $rate->getPrice());
    }
}
