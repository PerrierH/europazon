<?php

namespace Maas\Shipping\Test\Unit\Model\Service;

use DateInterval;
use DateTime;
use Exception;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartAddressBuilder;
use Maas\Core\Test\Builder\Cart\CartItemBuilder;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Maas\Core\Test\Builder\Order\OrderItemBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesOrderItemInfo;
use Maas\Sales\Model\SalesQuoteAddressItemInfo;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Model\Service\ShippingDataCopier;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Model\Quote\Address\Item;
use Magento\Sales\Api\Data\OrderItemExtension;

/**
 * Class ShippingDataCopierTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service
 */
class ShippingDataCopierTest extends AbstractTestCase
{
    /** @var ShippingDataCopier */
    protected $instance;

    protected $addressExtraInfo = [];

    public function setUp()
    {
        $this->addressExtraInfo = [];
        $this->instance = $this->getObject(ShippingDataCopier::class, [
            'extensionAttributesService' => AnyBuilder::createForClass($this, ExtensionAttributes::class, [
                'getOrderItemExtensionAttributes' => [
                    $this->any(),
                    function ($item) {
                        return $item->getExtensionAttributes();
                    },
                    self::RETURN_CALLBACK
                ],
                'getQuoteItemExtensionAttributes' => [
                    $this->any(),
                    function ($item) {
                        return $item->getExtensionAttributes();
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build(),
            'addressItemService' => AnyBuilder::createForClass($this, AddressItem::class, [
                'loadExtraInfoById' => [
                    $this->any(),
                    function ($id) {
                        return $this->getAddressItemExtraInfo($id);
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build(),
        ]);
    }

    /**
     * @param $id
     *
     * @return mixed|null
     */
    protected function getAddressItemExtraInfo($id)
    {
        return $this->addressExtraInfo[$id] ?? null;
    }

    public function testExecuteForSingleShipping()
    {
        $cartItemExtraInfoMock = AnyBuilder::createForClass($this, SalesQuoteItemInfo::class, [
            'getShippingMethod' => [$this->any(), 'standard'],
            'getShippingAmount' => [$this->any(), 1.23],
            'getDeliveryDelayMin' => [$this->any(), 1],
            'getDeliveryDelayMax' => [$this->any(), 2],
        ])->build();
        $cartItemExtensionMock = AnyBuilder::createForClass($this, CartItemExtension::class, [
            'getExtraInfo' => [$this->any(), $cartItemExtraInfoMock, self::RETURN_REFERENCE]
        ])->build();
        $cartItemMock = CartItemBuilder::create($this, [
            'getExtensionAttributes' => [$this->any(), $cartItemExtensionMock, self::RETURN_REFERENCE]
        ])->setUseConcreteClass(true)->build();

        $orderShippingMethod = null;
        $orderShippingAmount = null;
        $orderDeliveryDateMin = null;
        $orderDeliveryDateMax = null;

        $orderItemExtraInfoMock = AnyBuilder::createForClass($this, SalesOrderItemInfo::class, [
            'setShippingMethod' => [],
            'setShippingAmount' => [],
            'setDeliveryDateMin' => [],
            'setDeliveryDateMax' => []
        ])->build();
        $orderItemExtraInfoMock->expects($this->any())->method('setShippingMethod')->willReturnCallback(function ($value
        ) use ($orderItemExtraInfoMock, &$orderShippingMethod) {
            $orderShippingMethod = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtraInfoMock->expects($this->any())->method('setShippingAmount')->willReturnCallback(function ($value
        ) use ($orderItemExtraInfoMock, &$orderShippingAmount) {
            $orderShippingAmount = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtraInfoMock->expects($this->any())->method('setDeliveryDateMin')->willReturnCallback(function (
            $value
        ) use ($orderItemExtraInfoMock, &$orderDeliveryDateMin) {
            $orderDeliveryDateMin = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtraInfoMock->expects($this->any())->method('setDeliveryDateMax')->willReturnCallback(function (
            $value
        ) use ($orderItemExtraInfoMock, &$orderDeliveryDateMax) {
            $orderDeliveryDateMax = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtensionMock = AnyBuilder::createForClass($this, OrderItemExtension::class, [
            'getExtraInfo' => [$this->any(), $orderItemExtraInfoMock, self::RETURN_REFERENCE]
        ])->build();
        $orderItemMock = OrderItemBuilder::create($this, [
            'getExtensionAttributes' => [$this->any(), $orderItemExtensionMock, self::RETURN_REFERENCE]
        ])->setUseConcreteClass(true)->build();

        $this->instance->executeForSingleShipping($cartItemMock, $orderItemMock);

        $this->assertEquals('standard', $orderShippingMethod);
        $this->assertEquals(1.23, $orderShippingAmount);
        $this->assertEquals($this->getMysqlDateWithAddedDays(1), $orderDeliveryDateMin);
        $this->assertEquals($this->getMysqlDateWithAddedDays(2), $orderDeliveryDateMax);

    }

    /**
     * @param int $days
     *
     * @return string
     * @throws Exception
     */
    protected function getMysqlDateWithAddedDays($days)
    {
        $d = new DateTime();
        $d->add(new DateInterval('P' . $days . 'D'));

        return $d->format('Y-m-d H:i:s');
    }

    public function testExecuteForMultishipping()
    {
        $this->addressExtraInfo[1] = AnyBuilder::createForClass($this, SalesQuoteAddressItemInfo::class, [
            'getShippingMethod' => [$this->any(), 'standard'],
            'getShippingAmount' => [$this->any(), 1.23],
            'getDeliveryDelayMin' => [$this->any(), 1],
            'getDeliveryDelayMax' => [$this->any(), 2],
        ])->build();

        $addressItemMock = AnyBuilder::createForClass($this, Item::class, [
            'getId' => [$this->any(), 1]
        ])->setUseConcreteClass(true)->build();

        $orderShippingMethod = null;
        $orderShippingAmount = null;
        $orderDeliveryDateMin = null;
        $orderDeliveryDateMax = null;

        $orderItemExtraInfoMock = AnyBuilder::createForClass($this, SalesOrderItemInfo::class, [
            'setShippingMethod' => [],
            'setShippingAmount' => [],
            'setDeliveryDateMin' => [],
            'setDeliveryDateMax' => []
        ])->build();
        $orderItemExtraInfoMock->expects($this->any())->method('setShippingMethod')->willReturnCallback(function ($value
        ) use ($orderItemExtraInfoMock, &$orderShippingMethod) {
            $orderShippingMethod = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtraInfoMock->expects($this->any())->method('setShippingAmount')->willReturnCallback(function ($value
        ) use ($orderItemExtraInfoMock, &$orderShippingAmount) {
            $orderShippingAmount = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtraInfoMock->expects($this->any())->method('setDeliveryDateMin')->willReturnCallback(function (
            $value
        ) use ($orderItemExtraInfoMock, &$orderDeliveryDateMin) {
            $orderDeliveryDateMin = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtraInfoMock->expects($this->any())->method('setDeliveryDateMax')->willReturnCallback(function (
            $value
        ) use ($orderItemExtraInfoMock, &$orderDeliveryDateMax) {
            $orderDeliveryDateMax = $value;
            return $orderItemExtraInfoMock;
        });
        $orderItemExtensionMock = AnyBuilder::createForClass($this, OrderItemExtension::class, [
            'getExtraInfo' => [$this->any(), $orderItemExtraInfoMock, self::RETURN_REFERENCE]
        ])->build();
        $orderItemMock = OrderItemBuilder::create($this, [
            'getExtensionAttributes' => [$this->any(), $orderItemExtensionMock, self::RETURN_REFERENCE]
        ])->setUseConcreteClass(true)->build();

        $addressMock = CartAddressBuilder::create($this, [
            'getItemByQuoteItemId' => [$this->any(), $addressItemMock]
        ])->setUseConcreteClass(true)->build();

        $orderMock = OrderBuilder::create($this, [
            'getItems' => [$this->any(), [$orderItemMock]]
        ])->setUseConcreteClass(true)->build();

        $this->instance->executeForMultishipping($orderMock, $addressMock);

        $this->assertEquals('standard', $orderShippingMethod);
        $this->assertEquals(1.23, $orderShippingAmount);
        $this->assertEquals($this->getMysqlDateWithAddedDays(1), $orderDeliveryDateMin);
        $this->assertEquals($this->getMysqlDateWithAddedDays(2), $orderDeliveryDateMax);
    }
}
