<?php

namespace Maas\Shipping\Test\Unit\Model\Service;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Model\Service\ItemsType;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Quote\Model\Quote\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class ItemsTypeTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service
 */
class ItemsTypeTest extends AbstractTestCase
{
    /**
     * @var ItemsType
     */
    protected $instance;

    public function setUp()
    {
        $this->instance = $this->getObject(ItemsType::class, [
            'extensionAttributes' => AnyBuilder::createForClass($this,
                ExtensionAttributes::class, [
                    'getQuoteItemExtensionAttributes' => [
                        $this->any(),
                        function ($item) {
                            return $item->getExtensionAttributes();
                        },
                        self::RETURN_CALLBACK
                    ]
                ])->build()
        ]);
    }

    public function testGetItemsTypeEmpty()
    {
        $this->assertEquals(ItemsType::EMPTY, $this->instance->getItemsType([]));
    }

    public function testGetItemsTypeCore()
    {
        $items = [
            $this->getQuoteItemMock(1, null, null),
            $this->getQuoteItemMock(2, null, null),
            $this->getQuoteItemMock(3, null, null)
        ];
        $this->assertEquals(ItemsType::CORE, $this->instance->getItemsType($items));
    }

    /**
     * @param int $quoteItemId
     * @param int $offerId
     * @param int|null $parentId
     *
     * @return Item|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getQuoteItemMock($quoteItemId, $offerId, $parentId)
    {
        return AnyBuilder::createForClass($this, Item::class, [
            'getQuoteItemId' => [$this->any(), $quoteItemId],
            'getParentItemId' => [$this->any(), $parentId],
            'getExtensionAttributes' => [
                $this->any(),
                AnyBuilder::createForClass($this, CartItemExtension::class, [
                    'getExtraInfo' => [
                        $this->any(),
                        AnyBuilder::createForClass($this, SalesQuoteItemInfo::class, [
                            'getOfferId' => [$this->any(), $offerId]
                        ])->build()
                    ]
                ])->build()
            ]
        ])->build();
    }

    public function testGetItemsTypeMarketplace()
    {
        $items = [
            $this->getQuoteItemMock(1, 1, null),
            $this->getQuoteItemMock(2, 2, null),
            $this->getQuoteItemMock(3, 3, null)
        ];
        $this->assertEquals(ItemsType::MARKETPLACE, $this->instance->getItemsType($items));
    }

    public function testGetItemsTypeMixed()
    {
        $items = [
            $this->getQuoteItemMock(1, 1, null),
            $this->getQuoteItemMock(2, 2, null),
            $this->getQuoteItemMock(3, null, null)
        ];
        $this->assertEquals(ItemsType::MIXED, $this->instance->getItemsType($items));
    }

    public function testGetAddressItemsTypeMixed()
    {
        $items = [
            $this->getQuoteAddressItemMock(1, 1, null),
            $this->getQuoteAddressItemMock(2, 2, null),
            $this->getQuoteAddressItemMock(3, null, null)
        ];
        $this->assertEquals(ItemsType::MIXED, $this->instance->getItemsType($items));
    }

    /**
     * @param int $quoteItemId
     * @param int $offerId
     * @param int $parentId
     *
     * @return AddressItem|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getQuoteAddressItemMock($quoteItemId, $offerId, $parentId)
    {
        return AnyBuilder::createForClass($this, AddressItem::class, [
            'getQuoteItemId' => [$this->any(), $quoteItemId],
            'getQuote' => [
                $this->any(),
                CartBuilder::create($this, [
                    'getItemById' => [
                        $this->any(),
                        $this->getQuoteItemMock($quoteItemId, $offerId, $parentId),
                        self::RETURN_VALUE,
                        [$quoteItemId]
                    ]
                ])->build()
            ]
        ])->build();
    }
}
