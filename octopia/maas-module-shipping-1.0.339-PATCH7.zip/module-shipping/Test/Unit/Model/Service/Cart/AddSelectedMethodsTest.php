<?php

namespace Maas\Shipping\Test\Unit\Model\Service\Cart;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterface;
use Maas\Shipping\Api\Data\SelectedShippingMethodInterface;
use Maas\Shipping\Api\ShippingMethodManagementInterface;
use Maas\Shipping\Model\Service\Cart\AddSelectedMethods;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Model\Quote\Item;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class AddSelectedMethodsTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service\Cart
 */
class AddSelectedMethodsTest extends AbstractTestCase
{
    public function testSetMethodsOnCore()
    {
        $cartMock = CartBuilder::create($this, [
            'getItems' => [0]
        ])->build();
        $instance = $this->getObject(AddSelectedMethods::class, [
            'shippingMethodManagement' => AnyBuilder::createForClass($this, ShippingMethodManagement::class, [
                'getCurrentCartAvailableShippingMethods' => [
                    1,
                    AnyBuilder::createForClass($this, ShippingMethodManagementInterface::class, [
                        'getHasMarketplaceProducts' => [1, false]
                    ])->build()
                ],
            ])->build(),
            'extensionAttributesService' => AnyBuilder::createForClass($this, ExtensionAttributes::class, [])->build()
        ]);
        $instance->setMethodsToQuoteItems($cartMock, []);
    }

    public function testSetMethodsToQuoteItems()
    {
        $item1 = $this->getCartItemMock(1, 11);
        $item2 = $this->getCartItemMock(2, 12);
        $item3 = $this->getCartItemMock(3, 13);

        $cartItems = [$item1, $item2, $item3];
        $cartMock = CartBuilder::create($this, [
            'getItems' => [1, $cartItems]
        ])->build();

        $selectedShippingMethodMocks = [
            $this->getSelectedShippingMethodMock(1, 'standard'),
            $this->getSelectedShippingMethodMock(2, 'express'),
            $this->getSelectedShippingMethodMock(3, 'standard')
        ];

        $shippingMethodsObject = AnyBuilder::createForClass($this, AvailableShippingMethodsInterface::class, [
            'getHasMarketplaceProducts' => [1, true],
            'getItems' => [
                1,
                [
                    AnyBuilder::createForClass($this, AvailableShippingMethodsItemInterface::class, [
                        'getId' => [$this->any(), 1],
                        'getShippingMethods' => [
                            1,
                            [
                                AnyBuilder::createForClass($this, ShippingMethodInterface::class,
                                    [
                                        'getCode' => [$this->any(), 'standard'],
                                        'getBaseAmount' => [$this->any(), 1.00],
                                        'getMinDelay' => [$this->any(), 2],
                                        'getMaxDelay' => [$this->any(), 5]
                                    ])->build(),
                                AnyBuilder::createForClass($this, ShippingMethodInterface::class,
                                    [
                                        'getCode' => [$this->any(), 'express'],
                                        'getBaseAmount' => [$this->any(), 2.00],
                                        'getMinDelay' => [$this->any(), 1],
                                        'getMaxDelay' => [$this->any(), 3]
                                    ])->build()
                            ]
                        ],
                        'getOfferId' => [$this->any(), 11]
                    ])->build(),

                    AnyBuilder::createForClass($this, AvailableShippingMethodsItemInterface::class, [
                        'getId' => [$this->any(), 2],
                        'getShippingMethods' => [
                            1,
                            [
                                AnyBuilder::createForClass($this, ShippingMethodInterface::class,
                                    [
                                        'getCode' => [$this->any(), 'standard'],
                                        'getBaseAmount' => [$this->any(), 0.75],
                                        'getMinDelay' => [$this->any(), 2],
                                        'getMaxDelay' => [$this->any(), 4]
                                    ])->build(),
                                AnyBuilder::createForClass($this, ShippingMethodInterface::class,
                                    [
                                        'getCode' => [$this->any(), 'express'],
                                        'getBaseAmount' => [$this->any(), 1.49],
                                        'getMinDelay' => [$this->any(), 1],
                                        'getMaxDelay' => [$this->any(), 2]
                                    ])->build()
                            ]
                        ],
                        'getOfferId' => [$this->any(), 12]
                    ])->build(),

                    AnyBuilder::createForClass($this, AvailableShippingMethodsItemInterface::class, [
                        'getId' => [$this->any(), 3],
                        'getShippingMethods' => [
                            1,
                            [
                                AnyBuilder::createForClass($this, ShippingMethodInterface::class,
                                    [
                                        'getCode' => [$this->any(), 'standard'],
                                        'getBaseAmount' => [$this->any(), 2.01],
                                        'getMinDelay' => [$this->any(), 5],
                                        'getMaxDelay' => [$this->any(), 15]
                                    ])->build(),
                                AnyBuilder::createForClass($this, ShippingMethodInterface::class,
                                    [
                                        'getCode' => [$this->any(), 'express'],
                                        'getBaseAmount' => [$this->any(), 4.50],
                                        'getMinDelay' => [$this->any(), 1],
                                        'getMaxDelay' => [$this->any(), 3]
                                    ])->build()
                            ]
                        ],
                        'getOfferId' => [$this->any(), 13]
                    ])->build()
                ]
            ]
        ])->build();

        $instance = $this->getObject(AddSelectedMethods::class, [
            'shippingMethodManagement' => AnyBuilder::createForClass($this, ShippingMethodManagement::class, [
                'getCurrentCartAvailableShippingMethods' => [1, $shippingMethodsObject, self::RETURN_REFERENCE],
                'getCartAvailableShippingMethods' => [1, $shippingMethodsObject, self::RETURN_REFERENCE, [$cartMock]]
            ])->build(),
            'extensionAttributesService' => AnyBuilder::createForClass($this, ExtensionAttributes::class, [
                'getQuoteItemExtensionAttributes' => [
                    count($cartItems),
                    function ($item) {
                        return $item->getExtensionAttributes();
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build()
        ]);
        $instance->setMethodsToQuoteItems($cartMock, $selectedShippingMethodMocks);

        $extraInfo = $item1->getExtensionAttributes()->getExtraInfo();
        $this->assertEquals(11, $extraInfo->getOfferId());
        $this->assertEquals('standard', $extraInfo->getShippingMethod());
        $this->assertEquals(1.00, $extraInfo->getShippingAmount());
        $this->assertEquals(2, $extraInfo->getDeliveryDelayMin());
        $this->assertEquals(5, $extraInfo->getDeliveryDelayMax());

        $extraInfo = $item2->getExtensionAttributes()->getExtraInfo();
        $this->assertEquals(12, $extraInfo->getOfferId());
        $this->assertEquals('express', $extraInfo->getShippingMethod());
        $this->assertEquals(1.49, $extraInfo->getShippingAmount());
        $this->assertEquals(1, $extraInfo->getDeliveryDelayMin());
        $this->assertEquals(2, $extraInfo->getDeliveryDelayMax());

        $extraInfo = $item3->getExtensionAttributes()->getExtraInfo();
        $this->assertEquals(13, $extraInfo->getOfferId());
        $this->assertEquals('standard', $extraInfo->getShippingMethod());
        $this->assertEquals(2.01, $extraInfo->getShippingAmount());
        $this->assertEquals(5, $extraInfo->getDeliveryDelayMin());
        $this->assertEquals(15, $extraInfo->getDeliveryDelayMax());
    }

    /**
     * Due to needing to get/set individual data, real objects are used to encapsulate it
     *
     * @param int $itemId
     * @param int $offerId
     *
     * @return Item
     */
    protected function getCartItemMock($itemId, $offerId)
    {
        /** @var SalesQuoteItemInfo $extraInfo */
        $extraInfo = $this->getObject(SalesQuoteItemInfo::class);
        $extraInfo->setOfferId($offerId);

        /** @var CartItemExtension $extensionAttributesMock */
        $extensionAttributes = $this->getObject(CartItemExtension::class);
        $extensionAttributes->setExtraInfo($extraInfo);

        /** @var Item $item */
        $item = $this->getObject(Item::class);
        $item->setData([
            'item_id' => $itemId,
            'extension_attributes' => $extensionAttributes
        ]);
        return $item;
    }

    /**
     * @param $itemId
     * @param $code
     *
     * @return SelectedShippingMethodInterface|PHPUnit_Framework_MockObject_MockObject
     */
    protected function getSelectedShippingMethodMock($itemId, $code)
    {
        return AnyBuilder::createForClass($this, SelectedShippingMethodInterface::class, [
            'getItemId' => [$this->any(), $itemId],
            'getCode' => [$this->any(), $code]
        ])->build();
    }
}
