<?php

namespace Maas\Shipping\Test\Unit\Model\Service;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Cart\CartBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Model\SalesQuoteItemInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\ShippingMethodManagementInterface;
use Maas\Shipping\Model\Service\DeliveryEstimationOnTotalItems;
use Magento\Quote\Api\Data\CartItemExtension;
use Magento\Quote\Api\Data\CartItemExtensionInterface;
use Magento\Quote\Api\Data\TotalsItemExtension;
use Magento\Quote\Model\Cart\Totals\Item as TotalsItem;
use Magento\Quote\Model\Quote\Item;

/**
 * Class DeliveryEstimationOnTotalItemsTest
 *
 * @package Maas\Shipping\Test\Unit\Model\Service
 */
class DeliveryEstimationOnTotalItemsTest extends AbstractTestCase
{
    public function testExecuteWithQuoteItems()
    {
        $cartItems = [
            1 => $this->getCartItem(1, 'standard', 2, 5),
            2 => $this->getCartItem(2, 'express', 1, 2),
            3 => $this->getCartItem(3, 'standard', 4, 6),
            4 => $this->getCartItem(4, null, null, null)
        ];

        $cart = CartBuilder::create($this, [
            'getItems' => [$this->any(), $cartItems]
        ])->build();

        $totalIitem1 = $this->getTotalItem(1);
        $totalIitem2 = $this->getTotalItem(2);
        $totalIitem3 = $this->getTotalItem(3);
        $totalIitem4 = $this->getTotalItem(4);

        $totalItems = [
            $totalIitem1,
            $totalIitem2,
            $totalIitem3,
            $totalIitem4
        ];

        $methods = $this->getShippingMethods([
            1 => ['standard' => 'Standard', 'express' => 'Express'],
            2 => ['standard' => 'Standard', 'express' => 'Express'],
            3 => ['standard' => 'Standard', 'express' => 'Express'],
            4 => [],
        ]);

        $instance = $this->getObject(DeliveryEstimationOnTotalItems::class, [
            'extensionAttributesService' => AnyBuilder::createForClass($this, ExtensionAttributes::class, [
                'getQuoteItemExtensionAttributes' => [
                    $this->any(),
                    function ($quoteItem) {
                        return $quoteItem->getExtensionAttributes();
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build(),
            'productDeliveryService' => AnyBuilder::createForClass($this, ProductDelivery::class, [
                'assembleDeliveryEstimatedDatesFromDelays' => [
                    $this->any(),
                    function ($minDelay, $maxDelay, $string, $locale) {
                        // exact strings are handled by an external class from Maas_Catalog
                        return 'assembled;' . $minDelay . ';' . $maxDelay;
                    },
                    self::RETURN_CALLBACK
                ]
            ])->build(),
            'shippingMethodManagement' => AnyBuilder::createForClass($this, ShippingMethodManagementInterface::class, [
                'getCurrentCartAvailableShippingMethods' => [
                    $this->any(),
                    AnyBuilder::createForClass($this, AvailableShippingMethodsInterface::class, [
                        'getItems' => [$this->any(), $methods]
                    ])->build()
                ]
            ])->build()
        ]);

        $instance->executeWithQuoteItems($cart, $totalItems);

        $extensionAttributes = $totalIitem1->getExtensionAttributes();
        $this->assertEquals('Standard', $extensionAttributes->getMaasShippingLabel());
        $this->assertEquals('assembled;2;5', $extensionAttributes->getMaasShippingEstimation());

        $extensionAttributes = $totalIitem2->getExtensionAttributes();
        $this->assertEquals('Express', $extensionAttributes->getMaasShippingLabel());
        $this->assertEquals('assembled;1;2', $extensionAttributes->getMaasShippingEstimation());

        $extensionAttributes = $totalIitem3->getExtensionAttributes();
        $this->assertEquals('Standard', $extensionAttributes->getMaasShippingLabel());
        $this->assertEquals('assembled;4;6', $extensionAttributes->getMaasShippingEstimation());

        $extensionAttributes = $totalIitem4->getExtensionAttributes();
        $this->assertNull($extensionAttributes->getMaasShippingLabel());
        $this->assertNull($extensionAttributes->getMaasShippingEstimation());

    }

    /**
     * @param int $id
     * @param int $minDelay
     * @param int $maxDelay
     *
     * @return Item
     */
    protected function getCartItem($id, $method, $minDelay, $maxDelay)
    {
        /** @var Item $item */
        $item = $this->getObject(Item::class);

        /** @var CartItemExtensionInterface $extensionAttribute */
        $extensionAttribute = $this->getObject(CartItemExtension::class);

        /** @var SalesQuoteItemInfoInterface $extraInfo */
        $extraInfo = $this->getObject(SalesQuoteItemInfo::class);

        $extraInfo->setShippingMethod($method);
        $extraInfo->setDeliveryDelayMin($minDelay);
        $extraInfo->setDeliveryDelayMax($maxDelay);
        $extraInfo->setId($id);

        $extensionAttribute->setExtraInfo($extraInfo);
        $item->setExtensionAttributes($extensionAttribute);
        $item->setItemId($id);

        return $item;
    }

    /**
     * @param int $id
     *
     * @return TotalsItem
     */
    protected function getTotalItem($id)
    {
        /** @var TotalsItem $totalsItem */
        $totalsItem = $this->getObject(TotalsItem::class);

        /** @var TotalsItemExtension $extensionAttribute */
        $extensionAttribute = $this->getObject(TotalsItemExtension::class);

        $totalsItem->setItemId($id);
        $totalsItem->setExtensionAttributes($extensionAttribute);

        return $totalsItem;
    }

    /**
     * @param $shippingMethodsData
     *
     * @return array
     */
    protected function getShippingMethods($shippingMethodsData)
    {
        $methods = [];
        foreach ($shippingMethodsData as $id => $itemShippingMethodsData) {
            $shippingMethods = [];

            foreach ($itemShippingMethodsData as $code => $label) {
                $shippingMethods[] = AnyBuilder::createForClass($this, ShippingMethodInterface::class, [
                    'getCode' => [$this->any(), $code],
                    'getLabel' => [$this->any(), $label],
                ])->build();
            }

            $methods[] = AnyBuilder::createForClass($this, AvailableShippingMethodsInterface::class, [
                'getId' => [$this->any(), $id],
                'getShippingMethods' => [$this->any(), $shippingMethods]
            ])->build();
        }
        return $methods;
    }
}
