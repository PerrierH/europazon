<?php

namespace Maas\Shipping\Model\Service\Cart;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\SelectedShippingMethodInterface;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Api\Data\CartInterface;

/**
 * Class AddSelectedMethods
 *
 * @package Maas\Shipping\Model\Service\Cart
 */
class AddSelectedMethods
{
    /**
     * @var ShippingMethodManagement
     */
    protected $shippingMethodManagement;

    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /**
     * @var null|array
     */
    protected $methodsByQuoteItemId = null;

    /**
     * @var null|array
     */
    protected $offerIds = null;

    protected ManagerInterface $eventManager;

    /**
     * AddSelectedMethods constructor.
     *
     * @param ShippingMethodManagement $shippingMethodManagement
     * @param ExtensionAttributes $extensionAttributesService
     * @param ManagerInterface $eventManager
     */
    public function __construct(
        ShippingMethodManagement $shippingMethodManagement,
        ExtensionAttributes $extensionAttributesService,
        ManagerInterface $eventManager
    ) {
        $this->shippingMethodManagement = $shippingMethodManagement;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->eventManager = $eventManager;
    }

    /**
     * @param CartInterface $cart
     * @param SelectedShippingMethodInterface[] $selectedShippingMethods
     * @throws LocalizedException
     */
    public function setMethodsToQuoteItems($cart, $selectedShippingMethods)
    {
        $availableMethodsObject = $this->shippingMethodManagement->getCurrentCartAvailableShippingMethods();
        if (!$availableMethodsObject->getHasMarketplaceProducts()) {
            return;
        }
        foreach ($cart->getItems() as $item) {
            foreach ($selectedShippingMethods as $selectedShippingMethod) {
                if ($selectedShippingMethod->getItemId() == $item->getItemId()) {
                    $extension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
                    if ($extension->getExtraInfo()->getOfferId()) {
                        $methodObject = $this->getShipmentMethodForQuoteItemId($cart, $item->getItemId(),
                            $selectedShippingMethod->getCode());
                        $extraInfo = $extension->getExtraInfo();
                        $baseAmount = $methodObject->getBaseAmount();
                        $extraInfo->setOriginalShippingAmount($baseAmount);
                        $extraInfo->setDiscountedShippingAmount($baseAmount);
                        if ($item->getFreeShipping()) {
                            $extraInfo->setDiscountedShippingAmount(0);
                            $methodObject->setBaseAmount(0);
                        }
                        $extraInfo->setOfferId($this->offerIds[$item->getItemId()]);
                        $this->eventManager->dispatch(
                            'maas_shipping_set_marketplace_method',
                            ['item' => $item, 'method' => $methodObject]
                        );
                        $extraInfo->setShippingAmount($methodObject->getBaseAmount());
                        $extraInfo->setShippingMethod($methodObject->getCode());
                        $extraInfo->setDeliveryDelayMin($methodObject->getMinDelay());
                        $extraInfo->setDeliveryDelayMax($methodObject->getMaxDelay());
                        $extension->setExtraInfo($extraInfo);
                        $item->setExtensionAttributes($extension);
                    }
                }
            }
        }
    }

    /**
     * @param CartInterface $cart
     * @param int $itemId
     * @param string $code
     * @return ShippingMethodInterface
     * @throws LocalizedException
     */
    protected function getShipmentMethodForQuoteItemId($cart, $itemId, $code)
    {
        if (is_null($this->methodsByQuoteItemId)) {
            $this->methodsByQuoteItemId = [];
            $this->offerIds = [];
            $availableMethodsObject = $this->shippingMethodManagement->getCartAvailableShippingMethods($cart);
            foreach ($availableMethodsObject->getItems() as $item) {
                $methods = [];
                foreach ($item->getShippingMethods() as $method) {
                    $methods[$method->getCode()] = $method;
                }
                $this->methodsByQuoteItemId[$item->getId()] = $methods;
                $this->offerIds[$item->getId()] = $item->getOfferId();
            }
        }
        if (isset($this->methodsByQuoteItemId[$itemId]) && isset($this->methodsByQuoteItemId[$itemId][$code])) {
            return $this->methodsByQuoteItemId[$itemId][$code];
        } else {
            throw new LocalizedException(__('Invalid shipping method selected'));
        }
    }
}
