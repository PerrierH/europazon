<?php

namespace Maas\Shipping\Model\Service\Multishipping;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class Overview
 *
 * @package Maas\Shipping\Model\Service\Multishipping
 *
 * @codeCoverageIgnore no logic in this class
 */
class Overview
{
    /**
     * Overview constructor.
     *
     * @param ShippingRate $shippingRate
     *
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function __construct(
        ShippingRate $shippingRate
    ) {
        $shippingRate->updateShippingRates(true);
    }
}


