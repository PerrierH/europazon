<?php

namespace Maas\Shipping\Model\Service\Multishipping;

use Maas\Shipping\Model\Service\ShippingAmounts;
use Magento\Checkout\Model\Session;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Rate;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Quote\Model\Quote\TotalsCollector;

/**
 * Class ShippingRate
 *
 * @package Maas\Shipping\Model\Service\Multishipping
 * @codeCoverageIgnore delegates all logic to other classes
 */
class ShippingRate
{
    /** @var Session */
    protected $session;

    /** @var ShippingAmounts */
    protected $shippingAmountsService;

    /** @var CartRepositoryInterface */
    protected $cartRepository;

    /**
     * @var TotalsCollector
     */
    private $totalsCollector;

    /**
     * ShippingRate constructor.
     *
     * @param Session $session
     * @param ShippingAmounts $shippingAmountsService
     * @param CartRepositoryInterface $cartRepository
     */
    public function __construct(
        Session $session,
        ShippingAmounts $shippingAmountsService,
        CartRepositoryInterface $cartRepository,
        TotalsCollector $totalsCollector
    ) {
        $this->session = $session;
        $this->shippingAmountsService = $shippingAmountsService;
        $this->cartRepository = $cartRepository;
        $this->totalsCollector = $totalsCollector;
    }


    /**
     * @param bool $enable
     *
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function updateShippingRates($enable)
    {
        $quote = $this->session->getQuote();
        $this->shippingAmountsService->setEnabled($enable);
        $this->shippingAmountsService->reset();
        foreach ($quote->getAllShippingAddresses() as $address) {
            /** @var $address Address */
           $this->totalsCollector->collectAddressTotals($quote, $address);
           $totals = $address->getTotals();
            if (isset($totals['shipping']) && !empty($totals['shipping'])) {
                /** @var Total $total */
                $total = $totals['shipping'];
                $shippingMethod = $total->getAddress()->getShippingMethod();
                if (isset($shippingMethod) && !empty($shippingMethod)) {
                    /** @var Rate $shippingRate */
                    $shippingRate = $total->getAddress()->getShippingRateByCode($shippingMethod);
                    $shippingRate->setPrice($total->getAddress()->getBaseShippingAmount());
                }
            }
            $address->setCollectShippingRates(true)->collectShippingRates();
        }
        $this->cartRepository->save($quote);
    }
}
