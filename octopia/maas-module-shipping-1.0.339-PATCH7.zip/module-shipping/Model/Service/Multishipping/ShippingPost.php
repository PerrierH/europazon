<?php

namespace Maas\Shipping\Model\Service\Multishipping;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ItemsType;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Item;

/**
 * Class ShippingPost
 *
 * @package Maas\Shipping\Model\Service\Multishipping
 */
class ShippingPost
{
    /** @var RequestInterface */
    protected $request;

    /** @var Config */
    protected $shippingConfig;

    /** @var ShippingAttributesManagement */
    protected $shippingAttributesManagement;

    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var AddressItem */
    protected $addressItemService;

    /** @var Session */
    protected $session;

    /** @var ShippingRate */
    protected $shippingRate;

    /** @var ItemsType */
    protected $itemsTypeService;

    /** @var null|ProductInterface */
    protected $loadedProducts = null;

    /**
     * @var SalesQuoteItemInfoRepositoryInterface
     */
    private $salesQuoteItemInfoRepository;

    protected ManagerInterface $eventManager;

    /**
     * ShippingPost constructor.
     *
     * @param RequestInterface $request
     * @param Config $shippingConfig
     * @param ShippingAttributesManagement $shippingAttributesManagement
     * @param ExtensionAttributes $extensionAttributesService
     * @param AddressItem $addressItemService
     * @param SalesQuoteItemInfoRepositoryInterface $salesQuoteItemInfoRepository
     * @param Session $session
     * @param ShippingRate $shippingRate
     * @param ItemsType $itemsTypeService
     * @param ManagerInterface $eventManager
     */
    public function __construct(
        RequestInterface $request,
        Config $shippingConfig,
        ShippingAttributesManagement $shippingAttributesManagement,
        ExtensionAttributes $extensionAttributesService,
        AddressItem $addressItemService,
        SalesQuoteItemInfoRepositoryInterface $salesQuoteItemInfoRepository,
        Session $session,
        ShippingRate $shippingRate,
        ItemsType $itemsTypeService,
        ManagerInterface $eventManager
    ) {
        $this->request = $request;
        $this->shippingConfig = $shippingConfig;
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->salesQuoteItemInfoRepository = $salesQuoteItemInfoRepository;
        $this->addressItemService = $addressItemService;
        $this->session = $session;
        $this->shippingRate = $shippingRate;
        $this->itemsTypeService = $itemsTypeService;
        $this->eventManager = $eventManager;
    }

    /**
     * @return array
     *
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function validateAndAddMarketplaceMethods()
    {
        $this->loadProducts();
        $quote = $this->session->getQuote();
        $params = $this->request->getParams();
        $errors = [];
        foreach ($quote->getAllShippingAddresses() as $shippingAddress) {
            $this->validateAndAddStandardShippingForAddress($shippingAddress, $params, $errors);
        }
        if ($errors) {
            throw new InputException(__('The following method(s) cannot be used: %1', implode(", ", $errors)));
        }
        $this->validateMarketplaceShippingMethods($quote, $params);
        $this->request->setParams($params);
        return $params['shipping_method'] ?? [];
    }

    protected function loadProducts()
    {
        if (is_null($this->loadedProducts)) {
            $quote = $this->session->getQuote();
            $productIds = [];

            foreach ($quote->getAllItems() as $item) {
                $productIds[] = $item->getProductId();
            }
            $this->loadedProducts = $this->shippingAttributesManagement->getProductsWithDeliveryAttributes(
                $productIds, true, $quote->getStoreId()
            );
        }
    }

    /**
     * @param Address $shippingAddress
     * @param string[] $params
     * @param string[] $errors
     */
    protected function validateAndAddStandardShippingForAddress($shippingAddress, &$params, &$errors)
    {
        $maasMethod = $this->shippingConfig->getMarketplaceShippingCode();
        if ($this->itemsTypeService->getItemsType($shippingAddress->getAllItems()) == ItemsType::MARKETPLACE) {
            if (!isset($params['shipping_method'])) {
                $params['shipping_method'] = [];
            }
            if (isset($params['shipping_method'][$shippingAddress->getId()])
                && $params['shipping_method'][$shippingAddress->getId()] != $maasMethod) {
                $errors[] = $params['shipping_method'][$shippingAddress->getId()];
            } else {
                $params['shipping_method'][$shippingAddress->getId()] = $maasMethod;
            }
        }
    }

    /**
     * @param Quote $quote
     * @param string[] $params
     *
     * @throws InputException
     */
    protected function validateMarketplaceShippingMethods(Quote $quote, $params)
    {
        foreach ($quote->getAllShippingAddresses() as $address) {
            /** @var Address $address */
            foreach ($address->getAllItems() as $addressItem) {
                $this->validateMarketplaceShippingMethodsOnAddressItem($addressItem, $params);
            }
        }
    }

    /**
     * @param $addressItem
     * @param $params
     * @return void
     * @throws InputException
     */
    protected function validateMarketplaceShippingMethodsOnAddressItem($addressItem, $params)
    {
        // making sure only marketplace items are affected
        if ($this->itemsTypeService->isItemMarketplace($addressItem)) {
            if (!isset($params['mp_shipping_method'][$addressItem->getId()])) {
                throw new InputException(__('Set shipping methods for all addresses. Verify the shipping methods and try again.'));
            }
            $code = $params['mp_shipping_method'][$addressItem->getId()];
            $item = $addressItem->getQuoteItem();
            if ($item->getHasChildren()) {
                foreach ($item->getChildren() as $child) {
                    $this->copyDataToExtensionAttribute($child, $code);
                }
            } else {
                $this->copyDataToExtensionAttribute($item, $code);
            }
        }
    }

    public function applyMarketplaceMethods()
    {
        $this->loadProducts();

        $quote = $this->session->getQuote();
        $params = $this->request->getParams();

        foreach ($quote->getAllShippingAddresses() as $address) {
            $this->applyMarketplaceMethodsToAddress($address, $params);
        }
        $this->shippingRate->updateShippingRates(true);
    }

    /**
     * @param $item
     * @param $code
     * @return void
     * @throws InputException
     */
    protected function copyDataToExtensionAttribute($item, $code)
    {
        $extensionAttribute = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
        $extraInfo = $extensionAttribute->getExtraInfo();
        $shippingMethode = $this->shippingAttributesManagement->getShippingMethodsFromQuote($item);
        $methodObject = $this->getMethodByCode($code, $shippingMethode);
        if ($methodObject) {
            $this->setMarketPlaceShippingMethod($methodObject, $extraInfo, $item);
            $this->salesQuoteItemInfoRepository->save($extraInfo);
        } else {
            throw new InputException(__('Invalid shipping method selected'));
        }
    }

    /**
     * @param $code
     * @param $methodObjects
     * @return mixed|null
     */
    protected function getMethodByCode($code, $methodObjects)
    {
        foreach ($methodObjects as $methodObject) {
            if ($methodObject->getCode() == $code) {
                return $methodObject;
            }
        }
        return null;
    }

    /**
     * @param Address $address
     * @param string[] $params
     */
    protected function applyMarketplaceMethodsToAddress(Address $address, $params)
    {
        foreach ($address->getAllVisibleItems() as $addressItem) {
            /** @var Item $addressItem */
            if ($this->itemsTypeService->isItemMarketplace($addressItem)) {
                $methodObject = $this->getShippingMethodForAddressItem(
                    $addressItem, $params['mp_shipping_method'][$addressItem->getId()]
                );
                if ($methodObject) {
                    $this->saveShippingDataOnAddressItem($addressItem, $methodObject);
                }
            }
        }
    }

    /**
     * @param Item $addressItem
     * @param string $code
     *
     * @return ShippingMethodInterface|null
     */
    protected function getShippingMethodForAddressItem(Item $addressItem, $code)
    {
        $methodObjects = $this->shippingAttributesManagement->getShippingMethodsFromEntity($this->loadedProducts[$addressItem->getProductId()]);
        foreach ($methodObjects as $methodObject) {
            if ($methodObject->getCode() == $code) {
                return $methodObject;
            }
        }
        return null;
    }

    /**
     * @param Item $addressItem
     * @param ShippingMethodInterface $methodObject
     */
    protected function saveShippingDataOnAddressItem(Item $addressItem, ShippingMethodInterface $methodObject)
    {
        $initMethodObject = clone $methodObject;//prevent of altered $methodObject by event
        $extraInfo = $this->addressItemService->loadExtraInfo($addressItem);
        $this->setMarketPlaceShippingMethod($methodObject, $extraInfo, $addressItem);
        $this->addressItemService->saveExtraInfo($extraInfo);

        $quoteItem = $addressItem->getQuoteItem();
        $extension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($quoteItem);
        if ($extraInfo = $extension->getExtraInfo()) {
            $this->setMarketPlaceShippingMethod($initMethodObject, $extraInfo, $quoteItem);
            try {
                $this->salesQuoteItemInfoRepository->save($extraInfo);
            } catch (\Exception $e) {

            }
        }
    }

    /**
     * @param ShippingMethodInterface $methodObject
     * @param $extraInfo
     * @param $item
     * @return void
     */
    protected function setMarketPlaceShippingMethod(ShippingMethodInterface $methodObject, $extraInfo, $item): void
    {
        $baseAmount = $methodObject->getBaseAmount();
        $extraInfo->setOriginalShippingAmount($baseAmount);
        $extraInfo->setDiscountedShippingAmount(0);
        if ($item->getFreeShipping()) {
            $extraInfo->setDiscountedShippingAmount($baseAmount);
            $methodObject->setBaseAmount(0);
        }
        $this->eventManager->dispatch(
            'maas_shipping_set_marketplace_method',
            ['item' => $item, 'method' => $methodObject]
        );
        $extraInfo->setShippingAmount($methodObject->getBaseAmount());
        $extraInfo->setShippingMethod($methodObject->getCode());
        $extraInfo->setDeliveryDelayMin($methodObject->getMinDelay());
        $extraInfo->setDeliveryDelayMax($methodObject->getMaxDelay());
    }
}
