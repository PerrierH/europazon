<?php

namespace Maas\Shipping\Model\Service\Multishipping;

use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ItemsType;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Rate;

/**
 * Class Shipping
 * Filters out available shipping methods for marketplace-only quotes
 *
 * @package Maas\Shipping\Model\Service\Multishipping
 */
class Shipping
{

    /**
     * @var Config
     */
    protected $shippingConfig;

    /**
     * @var ItemsType
     */
    protected $itemsTypeService;

    /**
     * Shipping constructor.
     *
     * @param Config $shippingConfig
     * @param ShippingRate $shippingRate
     * @param ItemsType $itemsTypeService
     *
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function __construct(
        Config $shippingConfig,
        ShippingRate $shippingRate,
        ItemsType $itemsTypeService
    ) {
        $this->shippingConfig = $shippingConfig;
        $this->itemsTypeService = $itemsTypeService;
        $shippingRate->updateShippingRates(false);
    }

    /**
     * @param Address $address
     * @param Rate[] $rates
     *
     * @return mixed
     */
    public function getFilteredRatesForAddress(Address $address, $rates)
    {
        $hasCore = $this->itemsTypeService->isItemsCore($address->getAllItems());
        $filtered = [];
        foreach ($rates as $groupKey => $rateGroup) {
            $filteredGroup = [];
            foreach ($rateGroup as $rateKey => $rate) {
                if ((!$this->isRateDefault($rate)) && ($hasCore)) {
                    $filteredGroup[$rateKey] = $rate;
                }
            }
            if ($filteredGroup) {
                $filtered[$groupKey] = $filteredGroup;
            }
        }
        return $filtered;
    }

    /**
     * @param Rate $rate
     *
     * @return bool
     */
    protected function isRateDefault($rate)
    {

        return ($rate->getCode() == $this->shippingConfig->getMarketplaceShippingCode());
    }
}
