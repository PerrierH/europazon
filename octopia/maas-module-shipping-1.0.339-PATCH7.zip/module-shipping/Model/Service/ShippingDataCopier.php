<?php

namespace Maas\Shipping\Model\Service;

use DateInterval;
use DateTime;
use Maas\Sales\Model\Service\AddressItem;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Item as OrderItem;
use Psr\Log\LoggerInterface;

/**
 * Class ShippingDataCopier
 *
 * @package Maas\Shipping\Model\Service
 */
class ShippingDataCopier
{
    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /**
     * @var AddressItem
     */
    protected $addressItemService;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * ShippingDataCopier constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     * @param AddressItem $addressItemService
     * @param LoggerInterface $logger
     */
    public function __construct(
        ExtensionAttributes $extensionAttributesService,
        AddressItem $addressItemService,
        LoggerInterface $logger
    ) {
        $this->extensionAttributesService = $extensionAttributesService;
        $this->addressItemService = $addressItemService;
        $this->logger = $logger;
    }

    /**
     * @param Item $quoteItem
     * @param OrderItem $orderItem
     */
    public function executeForSingleShipping(Item $quoteItem, OrderItem $orderItem)
    {
        $orderItemExtension = $this->extensionAttributesService->getOrderItemExtensionAttributes($orderItem);
        $extraInfo = $orderItemExtension->getExtraInfo();
        $cartItemExtension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($quoteItem);
        $cartItemExtraInfo = $cartItemExtension->getExtraInfo();
        $this->copyData($extraInfo, $cartItemExtraInfo);
    }

    /**
     * @param Order $order
     * @param Address $address
     */
    public function executeForMultishipping(Order $order, Address $address)
    {
        foreach ($order->getItems() as $orderItem) {
            $addressItem = $address->getItemByQuoteItemId($orderItem->getQuoteItemId());
            $addressItemExtraInfo = $this->addressItemService->loadExtraInfoById($addressItem->getId());
            if ($addressItemExtraInfo) {
                $orderItemExtraInfo = $this->extensionAttributesService->getOrderItemExtensionAttributes($orderItem)->getExtraInfo();
                $this->copyData($orderItemExtraInfo, $addressItemExtraInfo);
            }
        }
    }

    /**
     * Copy data
     * @param $extraInfo
     * @param $cartItemExtraInfo
     * @return void
     */
    protected function copyData($extraInfo, $cartItemExtraInfo)
    {
        if ($cartItemExtraInfo->getDeliveryDelayMin() && $cartItemExtraInfo->getDeliveryDelayMax()) {
            $extraInfo->setShippingMethod($cartItemExtraInfo->getShippingMethod())
                ->setShippingAmount($cartItemExtraInfo->getShippingAmount())
                ->setOriginalShippingAmount($cartItemExtraInfo->getOriginalShippingAmount())
                ->setDiscountedShippingAmount($cartItemExtraInfo->getDiscountedShippingAmount())
                ->setDeliveryDateMin($this->getMysqlDateWithAddedDays($cartItemExtraInfo->getDeliveryDelayMin()))
                ->setDeliveryDateMax($this->getMysqlDateWithAddedDays($cartItemExtraInfo->getDeliveryDelayMax()));
        }
    }

    /**
     * Generate datetime with interval
     * @param int $days
     * @return string
     */
    protected function getMysqlDateWithAddedDays($days)
    {
        $d = new DateTime();
        try {
            $d->add(new DateInterval('P' . $days . 'D'));
        } catch (\Exception $e) {
            $this->logger->critical($e);
        }
        return $d->format('Y-m-d H:i:s');
    }
}
