<?php

namespace Maas\Shipping\Model\Service;

use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Checkout\Api\Data\ShippingInformationInterface;
use Magento\Framework\Exception\InputException;
use Magento\Quote\Api\Data\CartInterface;

/**
 * Class ValidateMarketplaceShipping
 * @package Maas\Shipping\Model\Service
 */
class ValidateMarketplaceShipping
{
    /** @var ShippingMethodManagement */
    protected $shippingMethodManagement;

    /** @var Config */
    protected $config;

    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /**
     * ValidateMarketplaceShipping constructor.
     *
     * @param ShippingMethodManagement $shippingMethodManagement
     * @param Config $config
     * @param ExtensionAttributes $extensionAttributesService
     */
    public function __construct(
        ShippingMethodManagement $shippingMethodManagement,
        Config $config,
        ExtensionAttributes $extensionAttributesService
    ) {
        $this->shippingMethodManagement = $shippingMethodManagement;
        $this->config = $config;
        $this->extensionAttributesService = $extensionAttributesService;
    }

    /**
     * @param CartInterface $cart
     * @param ShippingInformationInterface $shippingInformation
     *
     * @throws InputException
     */
    public function validateOnShippingSelection(CartInterface $cart, ShippingInformationInterface $shippingInformation)
    {
        $methods = $this->shippingMethodManagement->getCurrentCartAvailableShippingMethods();
        if ($methods->getHasMarketplaceProducts()) {
            if ($methods->getHasCoreProducts()) {
                $this->validateForMixed($cart, $shippingInformation, $methods);
            } else {
                $this->validateForMarketplaceOnly($cart, $shippingInformation, $methods);
            }
        } else {
            if ($methods->getHasCoreProducts()) {
                $this->validateForCoreOnly($shippingInformation);
            }
        }
    }

    /**
     * @param CartInterface $cart
     * @param ShippingInformationInterface $shippingInformation
     * @param AvailableShippingMethodsInterface $availableShippingMethods
     *
     * @throws InputException
     */
    protected function validateForMixed(
        CartInterface $cart,
        ShippingInformationInterface $shippingInformation,
        AvailableShippingMethodsInterface $availableShippingMethods
    ) {
        $this->validateStandardShippingMethod($shippingInformation, false);
        $checkedMarketplaceQuoteItemIds = $this->validateSelectedCodes($shippingInformation, $availableShippingMethods);
        $this->validateAllProductsHaveMethods($cart, $checkedMarketplaceQuoteItemIds);
    }

    /**
     * @param ShippingInformationInterface $shippingInformation
     * @param bool $onlyMarketplace
     *
     * @throws InputException
     */
    protected function validateStandardShippingMethod(
        ShippingInformationInterface $shippingInformation,
        $onlyMarketplace = false
    ) {
        $setCode = $shippingInformation->getShippingCarrierCode() . '_' . $shippingInformation->getShippingMethodCode();
        if (($setCode == $this->config->getMarketplaceShippingCode()) != $onlyMarketplace) {
            throw new InputException(
                __('The following method(s) cannot be used: %1', $setCode)
            );
        }
    }

    /**
     * @param ShippingInformationInterface $shippingInformation
     * @param AvailableShippingMethodsInterface $availableShippingMethods
     * @return array
     * @throws InputException
     */
    protected function validateSelectedCodes(
        ShippingInformationInterface $shippingInformation,
        AvailableShippingMethodsInterface $availableShippingMethods
    ) {
        $availableMethodCodes = $this->getAvailableMethodsPerQuoteItem($availableShippingMethods);
        $selectedMethods = $shippingInformation->getExtensionAttributes()->getMarketplaceShippingMethods();
        $checkedMarketplaceQuoteItemIds = [];
        if (!count($availableMethodCodes)) {
            throw new InputException(
                __('There is no delivery method available for your products')
            );
        }
        foreach ($selectedMethods as $selectedMethod) {
            if (isset($availableMethodCodes[$selectedMethod->getQuoteItemId()])
               && !in_array($selectedMethod->getShippingMethod(),
                    $availableMethodCodes[$selectedMethod->getQuoteItemId()]['methods'])) {
                throw new InputException(
                    __('The method %1 cannot be used with product %2',
                        $selectedMethod->getShippingMethod(),
                        $availableMethodCodes[$selectedMethod->getQuoteItemId()]['sku'])
                );
            }
            $checkedMarketplaceQuoteItemIds[$selectedMethod->getQuoteItemId()] = true;
        }
        return $checkedMarketplaceQuoteItemIds;
    }

    /**
     * Get available methods per quote item
     *
     * @param AvailableShippingMethodsInterface $availableShippingMethods
     * @return array
     */
    protected function getAvailableMethodsPerQuoteItem(AvailableShippingMethodsInterface $availableShippingMethods)
    {
        $methodsByQuoteItemId = [];
        foreach ($availableShippingMethods->getItems() as $item) {
            $methodCodes = [];
            $methods = $item->getShippingMethods();
            foreach ($methods as $method) {
                $methodCodes[] = $method->getCode();
            }
            $methodsByQuoteItemId[$item->getId()] = ['methods' => $methodCodes, 'sku' => $item->getProductSku()];
        }
        return $methodsByQuoteItemId;
    }

    /**
     * @param CartInterface $cart
     * @param int[] $checkedMarketplaceQuoteItemIds
     *
     * @throws InputException
     */
    protected function validateAllProductsHaveMethods(CartInterface $cart, $checkedMarketplaceQuoteItemIds)
    {
        $notCheckedSkus = [];
        foreach ($cart->getItems() as $item) {
            if (isset($checkedMarketplaceQuoteItemIds[$item->getItemId()])) {
                unset($checkedMarketplaceQuoteItemIds[$item->getItemId()]);
            } else {
                $ext = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
                // Only check marketplace products
                if ($ext->getExtraInfo()->getOfferId()) {
                    $notCheckedSkus[] = $item->getSku();
                }
            }
        }
        if ($checkedMarketplaceQuoteItemIds || $notCheckedSkus) {
            throw new InputException(
                __('Shipping method not set for items: %1', implode(', ', array_unique($notCheckedSkus)))
            );
        }
    }

    /**
     * @param CartInterface $cart
     * @param ShippingInformationInterface $shippingInformation
     * @param AvailableShippingMethodsInterface $availableShippingMethods
     *
     * @throws InputException
     */
    protected function validateForMarketplaceOnly(
        CartInterface $cart,
        ShippingInformationInterface $shippingInformation,
        AvailableShippingMethodsInterface $availableShippingMethods
    ) {
        $this->validateStandardShippingMethod($shippingInformation, true);
        $checkedMarketplaceQuoteItemIds = $this->validateSelectedCodes($shippingInformation, $availableShippingMethods);
        $this->validateAllProductsHaveMethods($cart, $checkedMarketplaceQuoteItemIds);
    }

    /**
     * @param ShippingInformationInterface $shippingInformation
     *
     * @throws InputException
     */
    protected function validateForCoreOnly( ShippingInformationInterface $shippingInformation)
    {
        $this->validateStandardShippingMethod($shippingInformation, false);
        $methods = $shippingInformation->getExtensionAttributes()->getMarketplaceShippingMethods();
        $availablesMethods = [];
        foreach ($methods as $method) {
            $availablesMethods[] = $method->getShippingMethod();
        }
        if ($availablesMethods) {
            throw new InputException(
                __('The following method(s) cannot be used: %1', implode(', ', array_unique($availablesMethods)))
            );
        }
    }
}
