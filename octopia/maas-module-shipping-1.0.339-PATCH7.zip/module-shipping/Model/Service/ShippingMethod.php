<?php


namespace Maas\Shipping\Model\Service;

use Maas\Shipping\Model\Config;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderExtensionFactory;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order\ShippingAssignmentBuilder;
use Magento\Sales\Model\OrderRepository;

/**
 * Class ShippingMethod
 *
 * @package Maas\Shipping\Model\Service
 * @codeCoverageIgnore There is no logic in this class, only delegations to other classes
 */
class ShippingMethod
{
    /**
     * @var OrderRepository
     */
    private $orderRepository;
    /**
     * @var OrderExtensionFactory
     */
    private $orderExtensionFactory;
    /**
     * @var ShippingAssignmentBuilder
     */
    private $shippingAssignmentBuilder;

    /**
     * @var Config
     */
    private $config;


    /**
     * ShippingMethod constructor.
     *
     * @param OrderRepository $orderRepository
     * @param OrderExtensionFactory $orderExtensionFactory
     * @param ShippingAssignmentBuilder $shippingAssignmentBuilder
     * @param Config $config
     */
    public function __construct(
        OrderRepository $orderRepository,
        OrderExtensionFactory $orderExtensionFactory,
        ShippingAssignmentBuilder $shippingAssignmentBuilder,
        Config $config
    ) {
        $this->orderRepository = $orderRepository;
        $this->orderExtensionFactory = $orderExtensionFactory;
        $this->shippingAssignmentBuilder = $shippingAssignmentBuilder;
        $this->config = $config;
    }

    /**
     * @param OrderInterface $order
     *
     * @throws AlreadyExistsException
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function setOnOrder(OrderInterface $order)
    {
        $extensionAttributes = $order->getExtensionAttributes();
        if(!$extensionAttributes)
        {
            $extensionAttributes = $this->orderExtensionFactory->create();
        }
        $this->shippingAssignmentBuilder->setOrderId($order->getEntityId());
        $extensionAttributes->setShippingAssignments($this->shippingAssignmentBuilder->create());
        $shippingAssignments = $extensionAttributes->getShippingAssignments();
        $shipping = array_shift($shippingAssignments)->getShipping();
        $shipping->setMethod($this->config->getMarketplaceShippingCode());
        $order->setExtensionAttributes($extensionAttributes);
        $order->setShippingDescription($this->config->getMarketplaceShippingMethodLabel($order->getStoreId()));
        $this->orderRepository->save($order);
    }

    /**
     * @param DataObject $quoteAddressData
     * @param int|null $storeId
     */
    public function setOnAddressDataObject(DataObject $quoteAddressData, $storeId)
    {
        $quoteAddressData->setData('shipping_method', $this->config->getMarketplaceShippingCode());
        $quoteAddressData->setData('shipping_description', $this->config->getMarketplaceShippingMethodLabel($storeId));
    }

    /**
     * @param CartInterface $cart
     * @param AddressInterface $address
     *
     * @return bool
     */
    public function unsetFromCartAndAddress(CartInterface $cart, AddressInterface $address)
    {
        if ($address && $address->getShippingMethod()
            && $address->getShippingMethod() == $this->config->getMarketplaceShippingCode()) {
            $address->setShippingMethod(null)
                ->setShippingAmount(null);

            $shippingAssignments = $cart->getExtensionAttributes()->getShippingAssignments();
            if ($shippingAssignments) {
                $shippingAssignments[0]->getShipping()->setMethod(null);
            }
            $cart->getExtensionAttributes()->setShippingAssignments($shippingAssignments);
            return true;
        }
        return false;
    }
}
