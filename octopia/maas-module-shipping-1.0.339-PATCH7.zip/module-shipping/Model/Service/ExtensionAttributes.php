<?php

namespace Maas\Shipping\Model\Service;

use Maas\Core\Model\Service\AbstractExtensionAttributes;
use Maas\Shipping\Api\Data\SalesShipmentInfoInterfaceFactory;
use Magento\Sales\Api\Data\ShipmentExtensionInterface;
use Magento\Sales\Api\Data\ShipmentExtensionInterfaceFactory;
use Magento\Sales\Api\Data\ShipmentInterface;

/**
 * Class ExtensionAttributes
 *
 * @package Maas\Shipping\Model\Service
 * @codeCoverageIgnore delegates all logic to parent
 */
class ExtensionAttributes extends AbstractExtensionAttributes
{
    /**
     * @var ShipmentExtensionInterfaceFactory
     */
    protected $shipmentExtensionFactory;

    /**
     * @var SalesShipmentInfoInterfaceFactory
     */
    protected $shipmentInfoFactory;

    /**
     * ExtensionAttributes constructor.
     *
     * @param ShipmentExtensionInterfaceFactory $shipmentFactory
     * @param SalesShipmentInfoInterfaceFactory $shipmentInfoFactory
     */
    public function __construct(
        ShipmentExtensionInterfaceFactory $shipmentFactory,
        SalesShipmentInfoInterfaceFactory $shipmentInfoFactory
    ) {
        $this->shipmentExtensionFactory = $shipmentFactory;
        $this->shipmentInfoFactory = $shipmentInfoFactory;
    }

    /**
     * @param ShipmentInterface $shipment
     *
     * @return ShipmentExtensionInterface
     */
    public function getShipmentExtensionAttributes(ShipmentInterface $shipment)
    {
        return $this->getObjectExtensionAttributes($shipment, $this->shipmentExtensionFactory,
            $this->shipmentInfoFactory);
    }
}
