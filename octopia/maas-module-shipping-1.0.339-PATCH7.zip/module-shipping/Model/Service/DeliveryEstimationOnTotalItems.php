<?php

namespace Maas\Shipping\Model\Service;

use Exception;
use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\ShippingMethodManagementInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\TotalsItemInterface;

/**
 * Class DeliveryEstimationOnTotalItems
 *
 * @package Maas\Shipping\Model\Service
 */
class DeliveryEstimationOnTotalItems
{
    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var TimezoneInterface */
    protected $localeDate;

    /** @var ProductDelivery */
    protected $productDeliveryService;

    /** @var ShippingMethodManagementInterface */
    protected $shippingMethodManagement;

    protected $cartAvailableShippingMethods = null;

    /**
     * DeliveryEstimationOnTotalItems constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     * @param TimezoneInterface $localeDate
     * @param ProductDelivery $productDeliveryService
     * @param ShippingMethodManagementInterface $shippingMethodManagement
     */
    public function __construct(
        ExtensionAttributes $extensionAttributesService,
        TimezoneInterface $localeDate,
        ProductDelivery $productDeliveryService,
        ShippingMethodManagementInterface $shippingMethodManagement
    ) {
        $this->extensionAttributesService = $extensionAttributesService;
        $this->localeDate = $localeDate;
        $this->productDeliveryService = $productDeliveryService;
        $this->shippingMethodManagement = $shippingMethodManagement;
    }

    /**
     * @param CartInterface $cart
     * @param TotalsItemInterface[] $totalItems
     *
     * @throws Exception
     */
    public function executeWithQuoteItems($cart, $totalItems)
    {
        $shipmentData = [];
        foreach ($cart->getItems() as $item) {
            $extension = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item);
            $minDelay = $extension->getExtraInfo()->getDeliveryDelayMin();
            $maxDelay = $extension->getExtraInfo()->getDeliveryDelayMax();

            if (isset($minDelay) && isset($maxDelay)) {
                $shipmentData[$item->getItemId()] = [
                    'label' => $this->getItemIdShippingMethodName($item->getItemId(),
                        $extension->getExtraInfo()->getShippingMethod()),
                    'estimation' => $this->productDeliveryService->assembleDeliveryEstimatedDatesFromDelays(
                        $minDelay, $maxDelay,
                        __("Delivered between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                        $this->localeDate
                    )
                ];
            }
        }

        foreach ($totalItems as $totalItem) {
            if (isset($shipmentData[$totalItem->getItemId()])) {
                /** @var TotalsItemInterface $totalItem */
                $totalItem->getExtensionAttributes()->setMaasShippingLabel($shipmentData[$totalItem->getItemId()]['label']);
                $totalItem->getExtensionAttributes()->setMaasShippingEstimation($shipmentData[$totalItem->getItemId()]['estimation']);
            }
        }
    }

    /**
     * @param int $itemId
     * @param ShippingMethodInterface $shippingMethod
     *
     * @return false|string
     */
    protected function getItemIdShippingMethodName($itemId, $shippingMethod)
    {
        if (!$shippingMethod) {
            return false;
        }
        if (is_null($this->cartAvailableShippingMethods)) {
            $this->cartAvailableShippingMethods = $this->shippingMethodManagement->getCurrentCartAvailableShippingMethods();
        }
        foreach ($this->cartAvailableShippingMethods->getItems() as $methodsItem) {
            if ($methodsItem->getId() == $itemId) {
                foreach ($methodsItem->getShippingMethods() as $method) {
                    if ($method->getCode() == $shippingMethod) {
                        return $method->getLabel();
                    }
                }
            }
        }
        return false;
    }
}
