<?php

namespace Maas\Shipping\Model\Service;

use Maas\Sales\Api\SalesQuoteItemInfoRepositoryInterface;
use Maas\Sales\Model\SalesQuoteAddressItemInfo;
use Maas\Sales\Model\Service\AddressItem as AddressItemService;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Model\ResourceModel\Quote;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Address\Item as AddressItem;
use Magento\Quote\Model\Quote\Address\Rate;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\Item\AbstractItem;

/**
 * Class ShippingAmounts
 *
 * @package Maas\Shipping\Model\Service
 */
class ShippingAmounts
{
    /** @var bool */
    protected $enabled = false;

    /** @var bool */
    protected $contextSet = false;

    /** @var Address */
    protected $quoteAddress;

    /** @var array */
    protected $managedItems = [];

    /** @var bool */
    protected $calculated = false;

    /** @var float */
    protected $amount = 0.0;

    /** @var SalesQuoteItemInfoRepositoryInterface */
    protected $itemInfoRepository;

    /** @var SearchCriteriaBuilder */
    protected $searchCriteriaBuilder;

    /** @var AddressItemService */
    protected $addressItemService;

    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var Quote */
    protected $quoteResourceModel;

    /** @var int */
    protected $quoteId = null;

    /** @var bool */
    protected $cartMode = false;

    /**
     * ShippingAmounts constructor.
     *
     * @param SalesQuoteItemInfoRepositoryInterface $itemInfoRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param AddressItemService $addressItemService
     * @param ExtensionAttributes $extensionAttributesService
     * @param Quote $quoteResourceModel
     */
    public function __construct(
        SalesQuoteItemInfoRepositoryInterface $itemInfoRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        AddressItemService $addressItemService,
        ExtensionAttributes $extensionAttributesService,
        Quote $quoteResourceModel
    ) {
        $this->itemInfoRepository = $itemInfoRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->addressItemService = $addressItemService;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->quoteResourceModel = $quoteResourceModel;
    }

    /**
     * @param Address $quoteAddress
     * @param AbstractItem|null $quoteItem
     */
    public function setContext($quoteAddress, $quoteItem = null)
    {
        if (!$this->enabled) {
            return;
        }
        if ($this->quoteId != $quoteAddress->getQuoteId()) {
            $this->quoteId = $quoteAddress->getQuoteId();
        }

        $this->contextSet = true;
        $this->quoteAddress = $quoteAddress;
        $this->managedItems = [];

        $this->calculated = false;
        $this->amount = 0.0;

        if ($quoteItem) {
            $this->initOneItem($quoteItem);
        } else {
            $this->initAllItems();
        }
        $this->calculate();
    }

    /**
     * @param AbstractItem $quoteItem
     */
    protected function initOneItem($quoteItem)
    {
        if ($quoteItem instanceof Item) {
            $this->managedItems[] = [
                'quote_item' => $quoteItem,
                'address_item' => null
            ];
        } else {
            if ($quoteItem instanceof AddressItem) {
                $realQuoteItem = $quoteItem->getQuote()->getItemById($quoteItem->getQuoteItemId());
                $this->managedItems[] = [
                    'quote_item' => $realQuoteItem,
                    'address_item' => $this->cartMode ? null : $quoteItem
                ];
            }
        }
    }

    protected function initAllItems()
    {
        $items = $this->quoteResourceModel->getHasAddressItems($this->quoteAddress->getQuoteId()) ?
            $this->quoteAddress->getAllItems() : $this->quoteAddress->getQuote()->getAllItems();

        if ($items) {
            if (reset($items) instanceof Item) {
                $this->initQuoteItems($items);
            } else {
                if (reset($items) instanceof AddressItem) {
                    $this->initAddressItems($items);
                }
            }
        }
    }

    /**
     * @param Item[] $items
     */
    protected function initQuoteItems($items)
    {
        foreach ($items as $item) {
            /** @var Item $item */
            $this->managedItems[] = [
                'quote_item' => $item,
                'address_item' => null
            ];
        }
    }

    /**
     * @param AddressItem[] $items
     */
    protected function initAddressItems($items)
    {
        foreach ($items as $item) {
            /** @var AddressItem $item */
            $quoteItem = $item->getQuote()->getItemById($item->getQuoteItemId());
            $this->managedItems[] = [
                'quote_item' => $quoteItem,
                'address_item' => $item
            ];
        }
    }

    protected function calculate()
    {
        $extensions = $this->getQuoteItemExtensions();

        $this->amount = 0.0;

        foreach ($this->managedItems as $managedItem) {
            $this->amount += $this->calculateFeesForOneItem($managedItem, $extensions);
        }

        $this->calculated = true;
    }

    /**
     * @return array
     */
    protected function getQuoteItemExtensions()
    {
        if ($this->cartMode) {
            $extensions = [];
            foreach ($this->managedItems as $managedItem) {
                $extensions[$managedItem['quote_item']->getItemId()] = $this->extensionAttributesService->getQuoteItemExtensionAttributes($managedItem['quote_item'])->getExtraInfo();
            }
            return $extensions;
        } else {
            $quoteItemIds = [];
            foreach ($this->managedItems as $managedItem) {
                $quoteItemIds[] = $managedItem['quote_item']->getItemId();
            }
            $searchCriteria = $this->searchCriteriaBuilder->addFilter('quote_item_id', $quoteItemIds, 'in')->create();
            $resultItems = [];
            foreach ($this->itemInfoRepository->getList($searchCriteria)->getItems() as $item) {
                $resultItems[$item->getId()] = $item;
            }
            return $resultItems;
        }
    }

    /**
     * @param array $managedItem
     * @param array $extensions
     *
     * @return float
     */
    protected function calculateFeesForOneItem($managedItem, $extensions)
    {
        $id = $managedItem['quote_item']->getItemId();
        if ($managedItem['address_item']) {
            $qty = $managedItem['address_item']->getQty();
            /** @var SalesQuoteAddressItemInfo $extension */
            $extension = $this->addressItemService->loadExtraInfoById($managedItem['address_item']->getId());
            $itemFees = ($extension && isset($extensions[$id]) && $extensions[$id]->getOfferId())
                ? $qty * $extension->getShippingAmount() : 0.0;
        } else {
            $qty = $managedItem['quote_item']->getQty();
            $itemFees = (isset($extensions[$id]) && $extensions[$id]->getOfferId())
                ? $qty * $extensions[$id]->getShippingAmount() : 0.0;
        }

        return $itemFees;
    }

    /**
     * @codeCoverageIgnore setter
     */
    public function unsetContext()
    {
        $this->contextSet = false;
        $this->quoteAddress = null;
    }

    /**
     * @param Rate $rate
     * @return Rate
     */
    public function process($rate)
    {
        if (!$this->enabled) {
            return $rate;
        }
        if (!$this->calculated) {
            $this->calculate();
        }
        if ($this->amount >= 0.0001) {
            $this->updateLabels($rate);
            $rate->setPrice($this->amount + $rate->getPrice());
        }
        return $rate;
    }

    /**
     * @param Rate $rate
     *
     * @return $this
     */
    protected function updateLabels($rate)
    {
        if ($this->contextSet && $this->amount >= 0.0001) {
            if ($rate->getPrice()) {
                $rate->setMethodTitle($rate->getMethodTitle() . ' / ' . __('Marketplace'));
            } else {
                $rate->setMethodTitle(__('Marketplace'));
            }
        }

        return $this;
    }

    /**
     * Call this from other classes to enable/disable adding amounts to currently used shipping methods
     *
     * @param bool $enabled
     *
     * @return $this
     * @codeCoverageIgnore setter
     */
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
        return $this;
    }

    /**
     * @param bool $cartMode
     *
     * @return $this
     * @codeCoverageIgnore setter
     */
    public function setCartMode($cartMode)
    {
        $this->cartMode = $cartMode;
        return $this;
    }

    /**
     * @return $this
     *
     * @codeCoverageIgnore setter
     */
    public function reset()
    {
        $this->calculated = false;
        return $this;
    }
}
