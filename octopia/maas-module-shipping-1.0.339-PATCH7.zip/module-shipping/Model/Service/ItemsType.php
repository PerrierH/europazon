<?php

namespace Maas\Shipping\Model\Service;

use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\Quote\Item\AbstractItem;

/**
 * Class ItemsType
 *
 * @package Maas\Shipping\Model\Service
 */
class ItemsType
{
    /** @var int */
    const EMPTY = 0;

    /** @var int */
    const CORE = 1;

    /** @var int */
    const MARKETPLACE = 2;

    /** @var int */
    const MIXED = 3;

    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributes;

    /**
     * ItemsType constructor.
     *
     * @param ExtensionAttributes $extensionAttributes
     */
    public function __construct(
        ExtensionAttributes $extensionAttributes
    ) {
        $this->extensionAttributes = $extensionAttributes;
    }

    /**
     * @param AbstractItem[] $items
     *
     * @return bool
     */
    public function isItemsCore($items)
    {
        return in_array($this->getItemsType($items), [self::CORE, self::MIXED]);
    }

    /**
     * @param AbstractItem[] $items
     *
     * @return int
     */
    public function getItemsType($items)
    {
        $hasCore = false;
        $hasMarketplace = false;
        foreach ($items as $item) {
            $quoteItem = $this->getNonChildQuoteItem($item);
            if ($quoteItem) {
                $extraInfo = $this->extensionAttributes->getQuoteItemExtensionAttributes($quoteItem)->getExtraInfo();
                if ($extraInfo->getOfferId()) {
                    $hasMarketplace = true;
                } else {
                    $hasCore = true;
                }
            }
        }
        if($hasMarketplace)
        {
            return $hasCore ? self::MIXED : self::MARKETPLACE;
        }
        else
        {
            return $hasCore ? self::CORE : self::EMPTY;
        }
    }

    /**
     * @param AbstractItem $item
     *
     * @return Item|null
     */
    protected function getNonChildQuoteItem(AbstractItem $item)
    {
        $quoteItem = null;
        if ($item instanceof Item) {
            $quoteItem = $item;
        } else {
            if ($item instanceof \Magento\Quote\Model\Quote\Address\Item) {
                $quoteItem = $item->getQuote()->getItemById($item->getQuoteItemId());
            }
        }
        return ($quoteItem && !$quoteItem->getParentItemId()) ? $quoteItem : null;
    }

    /**
     * @param AbstractItem[] $items
     *
     * @return bool
     */
    public function isItemsMarketplace($items)
    {
        return in_array($this->getItemsType($items), [self::MARKETPLACE, self::MIXED]);
    }

    /**
     * @param AbstractItem $item
     *
     * @return bool
     */
    public function isItemMarketplace($item)
    {
        return $this->isItemsMarketplace([$item]);
    }
}
