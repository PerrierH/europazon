<?php

namespace Maas\Shipping\Model\Checkout;

use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Model\Carrier\MarketplaceCarrier;
use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\ShippingMethodManagement;
use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Checkout\Model\Session as CheckoutSession;

/**
 * Class ConfigProviderMaasShippingMethods
 *
 * @package Maas\Shipping\Model\Checkout
 * @codeCoverageIgnore delegates to other classes, contains no logic
 */
class ConfigProviderMaasShippingMethods implements ConfigProviderInterface
{
    /** @var CheckoutSession */
    protected $checkoutSession;

    /** @var ShippingMethodManagement */
    protected $shippingMethodManagement;

    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var Config */
    protected $config;

    /**
     * ConfigProviderMaasShippingMethods constructor.
     *
     * @param CheckoutSession $checkoutSession
     * @param ShippingMethodManagement $shippingMethodManagement
     * @param ExtensionAttributes $extensionAttributesService
     * @param Config $config
     */
    public function __construct(
        CheckoutSession $checkoutSession,
        ShippingMethodManagement $shippingMethodManagement,
        ExtensionAttributes $extensionAttributesService,
        Config $config
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->shippingMethodManagement = $shippingMethodManagement;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->config = $config;
    }

    /**
     * @inheritDoc
     */
    public function getConfig()
    {
        /** @var AvailableShippingMethodsInterface $methodsObject */
        $methodsObject = $this->shippingMethodManagement->getCurrentCartAvailableShippingMethods();
        $methodsAsArray = [
            'items' => [],
            'data' => [
                'hasMarketplace' => $methodsObject->getHasMarketplaceProducts(),
                'hasCore' => $methodsObject->getHasCoreProducts(),
                'marketplaceShippingMethod' => [
                    'carrier' => MarketplaceCarrier::CARRIER_CODE,
                    'method' => 'marketplace',
                    'carrier_label' => $this->config->getMarketplaceShippingStandardCarrierLabel(),
                    'method_label' => $this->config->getMarketplaceShippingStandardMethodLabel(),
                ]
            ]
        ];
        foreach ($methodsObject->getItems() as $methodsObjectItem) {
            $shippingMethods = [];
            foreach ($methodsObjectItem->getShippingMethods() as $method) {
                $shippingMethods[] = [
                    'amount' => $method->getAmount(),
                    'base_amount' => $method->getBaseAmount(),
                    'code' => $method->getCode(),
                    'estimation' => $method->getEstimation(),
                    'label' => $method->getLabel(),
                    'min_delay' => $method->getMinDelay(),
                    'max_delay' => $method->getMaxDelay(),
                    'product_id' => $method->getProductId()
                ];
            }
            $methodsAsArray['items'][$methodsObjectItem->getId()] = [
                'itemId' => $methodsObjectItem->getId(),
                'name' => $methodsObjectItem->getProductName(),
                'sku' => $methodsObjectItem->getProductSku(),
                'offerId' => $methodsObjectItem->getOfferId(),
                'sellerId' => $methodsObjectItem->getSellerId(),
                'qty' => $methodsObjectItem->getQty(),
                'shippingMethods' => $shippingMethods,
                'options' => $methodsObjectItem->getOptionList()
            ];
        }

        return [
            'maasMarketplaceShipment' => $methodsAsArray
        ];
    }
}
