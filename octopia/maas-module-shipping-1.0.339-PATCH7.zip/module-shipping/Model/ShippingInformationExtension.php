<?php


namespace Maas\Shipping\Model;

use Maas\Shipping\Api\Data\ShippingInformationExtensionInterface;

/**
 * Class ShippingInformationExtension
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore getters and setters
 */
class ShippingInformationExtension implements ShippingInformationExtensionInterface
{
    /** @var string */
    protected $shippingMethod;

    /** @var int */
    protected $quoteItemId;


    /**
     * @inheritDoc
     */
    public function getShippingMethod()
    {
        return $this->shippingMethod;
    }

    /**
     * @inheritDoc
     */
    public function setShippingMethod($shippingMethod)
    {
        $this->shippingMethod = $shippingMethod;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getQuoteItemId()
    {
        return $this->quoteItemId;
    }

    /**
     * @inheritDoc
     */
    public function setQuoteItemId($quoteItemId)
    {
        $this->quoteItemId = $quoteItemId;
        return $this;
    }
}
