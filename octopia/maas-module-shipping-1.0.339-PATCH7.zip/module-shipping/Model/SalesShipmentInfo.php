<?php

namespace Maas\Shipping\Model;

use Maas\Shipping\Api\Data\SalesShipmentInfoInterface;
use Maas\Shipping\Model\ResourceModel\SalesShipmentInfo as SalesShipmentInfoResource;
use Magento\Framework\Model\AbstractModel;

/**
 * Class SalesShipmentInfo
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore delegates all to parent
 */
class SalesShipmentInfo extends AbstractModel implements SalesShipmentInfoInterface
{
    /**
     * @inheritDoc
     */
    public function getTrackingUrl()
    {
        return $this->getData(self::TRACKING_URL);
    }

    /**
     * @inheritDoc
     */
    public function setTrackingUrl($trackingUrl)
    {
        return $this->setData(self::TRACKING_URL, $trackingUrl);
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(SalesShipmentInfoResource::class);
    }
}
