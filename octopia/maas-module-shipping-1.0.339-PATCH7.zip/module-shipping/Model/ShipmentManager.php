<?php


namespace Maas\Shipping\Model;

use Exception;
use Maas\Shipping\Model\Carrier\MarketplaceCarrier;
use Maas\Shipping\Model\Service\ExtensionAttributes;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderItemRepositoryInterface;
use Magento\Sales\Model\Convert\Order as OrderConverter;
use Magento\Sales\Model\Order\Item;
use Magento\Sales\Model\Order\Shipment;
use Magento\Sales\Model\Order\Shipment\OrderRegistrarInterface;
use Magento\Sales\Model\Order\Shipment\Track;
use Magento\Sales\Model\Order\Shipment\TrackFactory;
use Magento\Sales\Model\Order\ShipmentRepository;
use Magento\Sales\Model\OrderRepository;
use Psr\Log\LoggerInterface;
use Psr\Log\LogLevel;

/**
 * Class ShipmentManager
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore delegates all logic
 */
class ShipmentManager
{
    const KEY_RESPONSE_MUST_EXIST = [
        'number',
        'trackingUrl',
        'carrierName'
    ];
    /**
     * @var OrderConverter
     */
    private $orderConverter;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var ShipmentRepository
     */
    private $shipmentRepository;

    /**
     * @var TrackFactory
     */
    private $trackFactory;

    /**
     * @var ExtensionAttributes
     */
    private $extensionAttributesService;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var OrderRegistrarInterface
     */
    private $orderItemRepository;

    /**
     * ShipmentManager constructor.
     *
     * @param OrderConverter $orderConverter
     * @param OrderRepository $orderRepository
     * @param ShipmentRepository $shipmentRepository
     * @param TrackFactory $trackFactory
     * @param ExtensionAttributes $extensionAttributesService
     * @param LoggerInterface $logger
     * @param OrderItemRepositoryInterface $orderItemRepository
     */
    public function __construct(
        OrderConverter               $orderConverter,
        OrderRepository              $orderRepository,
        ShipmentRepository           $shipmentRepository,
        TrackFactory                 $trackFactory,
        ExtensionAttributes          $extensionAttributesService,
        LoggerInterface              $logger,
        OrderItemRepositoryInterface $orderItemRepository
    )
    {
        $this->orderConverter = $orderConverter;
        $this->orderRepository = $orderRepository;
        $this->shipmentRepository = $shipmentRepository;
        $this->trackFactory = $trackFactory;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->logger = $logger;
        $this->orderItemRepository = $orderItemRepository;
    }

    /**
     * @param Item $orderItem
     * @param $statusInfo
     * @return bool|Shipment|void
     * @throws AlreadyExistsException
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function setShipment(Item $orderItem, $statusInfo)
    {
        $this->checkKeyExistInStatusInfo($statusInfo);
        if (isset($statusInfo['carrierName']) && !empty($statusInfo['carrierName'])) {
            $parcelNumber = '';
            if (array_key_exists('number', $statusInfo)) {
                $parcelNumber = $statusInfo['number'];
            } elseif (array_key_exists('parcelNumber', $statusInfo)) {
                //TODO remove parcelNumber if not provided by api
                $parcelNumber = $statusInfo['parcelNumber'];
            }

            return $this->createShipment(
                $orderItem,
                MarketplaceCarrier::CARRIER_CODE,
                $statusInfo['carrierName'],
                (array_key_exists('trackingUrl', $statusInfo) ? $statusInfo['trackingUrl'] : ''),
                $parcelNumber
            );
        }
    }

    /**
     * @param $statusInfo
     *
     * @throws Exception
     */
    protected function checkKeyExistInStatusInfo($statusInfo)
    {
        $diff = array_diff(self::KEY_RESPONSE_MUST_EXIST, array_keys($statusInfo));
        if ($diff != []) {
            $missingKeys = implode(', ', $diff);
            $this->logger->log(LogLevel::EMERGENCY,
                "$missingKeys is missing in json response from api call order status");
        }
    }

    /**
     * @param Item $orderItem
     * @param $code
     * @param $title
     * @param $trackingUrl
     * @param $trackingNumber
     *
     * @return bool|Shipment
     * @throws AlreadyExistsException
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function createShipment(Item $orderItem, $code, $title, $trackingUrl, $trackingNumber)
    {
        $order = $orderItem->getOrder();

        // Check if order has already shipping or can be shipped
        if (!$order->canShip()) {
            return false;
        }

        // Initializing Object for the order shipment
        $shipment = $this->orderConverter->toShipment($order);

        // Check if the order item has Quantity to ship or is virtual
        if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
            return false;
        }
        $qtyShipped = $orderItem->getQtyToShip();

        // Create Shipment Item with Quantity
        $shipmentItem = $this->orderConverter->itemToShipmentItem($orderItem)->setQty($qtyShipped);

        // Add Shipment Item to Shipment
        $shipment->addItem($shipmentItem);

        // Register Shipment
        $shipment->register();

        // add tracking informations
        if ($trackingNumber) {
            $track = $this->trackFactory->create();
            $track->addData([
                'carrier_code' => $code,
                'title' => $title,
                'number' => $trackingNumber,
            ]);
            $shipment->addTrack($track);
        }

        $extension = $this->extensionAttributesService->getShipmentExtensionAttributes($shipment);
        $extraInfo = $extension->getExtraInfo();
        $extraInfo->setTrackingUrl($trackingUrl);
        $extension->setExtraInfo($extraInfo);
        $shipment->setExtensionAttributes($extension);

        // Save created Shipment and Order
        $shipment = $this->shipmentRepository->save($shipment);
        $orderItem = $shipmentItem->getOrderItem();
        $orderItem = $this->orderItemRepository->save($orderItem);
        $order = $orderItem->getOrder();
        $this->updateOrderItem($order, $orderItem);
        $this->orderRepository->save($order);
        return $shipment;
    }

    /**
     * @param Track $track
     *
     * @return string
     *
     * @throws LocalizedException
     */
    public function getTrackingUrl(Track $track)
    {
        return $this->extensionAttributesService->getShipmentExtensionAttributes($track->getShipment())
                ->getExtraInfo()->getTrackingUrl() . $track->getTrackNumber();
    }

    /**
     * @param OrderInterface $order
     * @param Item $orderItem
     */
    protected function updateOrderItem(OrderInterface $order, Item $orderItem)
    {
        $orderItems = $order->getItems();
        $orderItems[$orderItem->getItemId()] = $orderItem;
        $order->setItems($orderItems);
    }
}
