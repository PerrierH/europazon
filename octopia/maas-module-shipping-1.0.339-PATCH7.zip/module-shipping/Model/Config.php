<?php


namespace Maas\Shipping\Model;

use Maas\Core\Model\Config as CoreConfig;
use Maas\Shipping\Model\Carrier\MarketplaceCarrier;

/**
 * Class Config
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore Delegates all calls to parent
 */
class Config extends CoreConfig
{
    public const XML_PATH_CARRIER_MAAS_CARRIER_LABEL = 'carriers/' . MarketplaceCarrier::CARRIER_CODE . '/title';
    public const XML_PATH_CARRIER_MAAS_METHOD_LABEL = 'carriers/' . MarketplaceCarrier::CARRIER_CODE . '/name';

    /**
     * @return string|null
     */
    public function getMarketplaceShippingCode()
    {
        return $this->getMarketplaceShippingCarrier() . '_' . $this->getMarketplaceShippingMethod();
    }

    /**
     * @return string|null
     */
    public function getMarketplaceShippingCarrier()
    {
        return MarketplaceCarrier::CARRIER_CODE;
    }

    /**
     * @return string|null
     */
    public function getMarketplaceShippingMethod()
    {
        return MarketplaceCarrier::METHOD_CODE;
    }

    /**
     * @param int|string|null $scopeCode
     *
     * @return string|null
     */
    public function getMarketplaceShippingMethodLabel($scopeCode = null)
    {
        return $this->getMarketplaceShippingStandardCarrierLabel($scopeCode) . ' - ' . $this->getMarketplaceShippingStandardMethodLabel($scopeCode);
    }

    /**
     * @param int|string|null $scopeCode
     *
     * @return string|null
     */
    public function getMarketplaceShippingStandardCarrierLabel($scopeCode = null)
    {
        return $this->getValueWithoutPrefix(self::XML_PATH_CARRIER_MAAS_CARRIER_LABEL, $scopeCode);
    }

    /**
     * @param int|string|null $scopeCode
     *
     * @return string|null
     */
    public function getMarketplaceShippingStandardMethodLabel($scopeCode = null)
    {
        return $this->getValueWithoutPrefix(self::XML_PATH_CARRIER_MAAS_METHOD_LABEL, $scopeCode);
    }
}
