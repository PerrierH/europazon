<?php

namespace Maas\Shipping\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Shipping\Api\Data\SalesShipmentInfoInterface;
use Maas\Shipping\Api\Data\SalesShipmentInfoSearchResultsInterfaceFactory;
use Maas\Shipping\Api\SalesShipmentInfoRepositoryInterface;
use Maas\Shipping\Model\ResourceModel\SalesShipmentInfo;
use Maas\Shipping\Model\ResourceModel\SalesShipmentInfo\CollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class SalesShipmentInfoRepository
 *
 * @package Maas\Sales\Model
 * @codeCoverageIgnore delegates all to parent
 */
class SalesShipmentInfoRepository extends AbstractRepository implements SalesShipmentInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SalesShipmentInfoInterface $salesQuoteAddressItemInfo)
    {
        return $this->_save($salesQuoteAddressItemInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(SalesShipmentInfoInterface $salesQuoteAddressItemInfo)
    {
        $this->_delete($salesQuoteAddressItemInfo);
    }
}
