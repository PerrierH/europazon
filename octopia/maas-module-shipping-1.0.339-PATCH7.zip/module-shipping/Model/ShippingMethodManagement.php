<?php

namespace Maas\Shipping\Model;

use Maas\Catalog\Api\ShippingAttributesManagementInterface;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterface;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsInterfaceFactory;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterfaceFactory;
use Maas\Shipping\Api\ShippingMethodManagementInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Helper\Product\ConfigurationPool;
use Magento\Checkout\Model\Session;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class ShippingMethodManagement
 *
 * @package Maas\Shipping\Model
 */
class ShippingMethodManagement implements ShippingMethodManagementInterface
{
    /** @var ExtensionAttributes */
    protected $extensionAttributesService;

    /** @var SalesQuoteItemInfoInterface */
    protected $salesQuoteItemInfo;

    /** @var ProductRepositoryInterface */
    protected $productRepository;

    /** @var SearchCriteriaBuilder */
    protected $searchCriteriaBuilder;

    /** @var ShippingAttributesManagementInterface */
    protected $shippingAttributesManagement;

    /** @var Session */
    protected $checkoutSession;

    /** @var AvailableShippingMethodsInterfaceFactory */
    protected $availableShippingMethodsFactory;

    /** @var AvailableShippingMethodsItemInterfaceFactory */
    protected $availableShippingMethodsItemFactory;

    /** @var ConfigurationPool */
    protected $configurationPool;

    /**
     * ShippingMethodManagement constructor.
     *
     * @param ExtensionAttributes $extensionAttributesService
     * @param SalesQuoteItemInfoInterface $salesQuoteItemInfo
     * @param ProductRepositoryInterface $productRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param ShippingAttributesManagementInterface $shippingAttributesManagement
     * @param Session $checkoutSession
     * @param AvailableShippingMethodsInterfaceFactory $availableShippingMethodsFactory
     * @param AvailableShippingMethodsItemInterfaceFactory $availableShippingMethodsItemFactory
     * @param ConfigurationPool $configurationPool
     */
    public function __construct(
        ExtensionAttributes $extensionAttributesService,
        SalesQuoteItemInfoInterface $salesQuoteItemInfo,
        ProductRepositoryInterface $productRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        ShippingAttributesManagementInterface $shippingAttributesManagement,
        Session $checkoutSession,
        AvailableShippingMethodsInterfaceFactory $availableShippingMethodsFactory,
        AvailableShippingMethodsItemInterfaceFactory $availableShippingMethodsItemFactory,
        ConfigurationPool $configurationPool
    ) {
        $this->extensionAttributesService = $extensionAttributesService;
        $this->salesQuoteItemInfo = $salesQuoteItemInfo;
        $this->productRepository = $productRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        $this->checkoutSession = $checkoutSession;
        $this->availableShippingMethodsFactory = $availableShippingMethodsFactory;
        $this->availableShippingMethodsItemFactory = $availableShippingMethodsItemFactory;
        $this->configurationPool = $configurationPool;
    }

    /**
     * @inheritDoc
     * @codeCoverageIgnore delegates to another method a standard class
     */
    public function getCurrentCartAvailableShippingMethods()
    {
        return $this->getCartAvailableShippingMethods(
            $this->checkoutSession->getQuote()
        );
    }

    /**
     * @inheritDoc
     */
    public function getCartAvailableShippingMethods($cart)
    {
        /** @var AvailableShippingMethodsInterface $methodsObject */
        $methodsObject = $this->availableShippingMethodsFactory->create();
        $hasMarketplace = false;
        $hasCore = false;

        $methodsItems = [];
        foreach ($cart->getAllVisibleItems() as $item) {
            $extraInfo = $this->extensionAttributesService->getQuoteItemExtensionAttributes($item)->getExtraInfo();
            if ($extraInfo->getOfferId()) {
                $hasMarketplace = true;
                /** @var AvailableShippingMethodsItemInterface $methodsItem */
                $methodsItem = $this->availableShippingMethodsItemFactory->create();
                $productId = $item->getProductId();
                $methodsItem->setId($item->getId())
                    ->setProductName($item->getName())
                    ->setQty($item->getQty())
                    ->setOfferId($extraInfo->getOfferId())
                    ->setSellerId($extraInfo->getSellerId())
                    ->setProductId($productId)
                    ->setProductSku($item->getProductSku())
                    ->setOptionList($this->getOptionList($item))
                    ->setShippingMethods($this->shippingAttributesManagement->getShippingMethodsFromQuote($item));
                $methodsItems[] = $methodsItem;
            } else {
                $hasCore = true;
            }
        }

        $methodsObject->setHasCoreProducts($hasCore)
            ->setHasMarketplaceProducts($hasMarketplace)
            ->setItems($methodsItems);

        return $methodsObject;
    }


    /**
     * Get list of all options for product
     *
     * @return array
     * @codeCoverageIgnore
     */
    protected function getOptionList($item)
    {
        return $this->configurationPool->getByProductType($item->getProductType())->getOptions($item);
    }
}
