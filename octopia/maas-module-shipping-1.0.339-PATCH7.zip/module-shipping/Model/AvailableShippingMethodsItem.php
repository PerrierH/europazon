<?php


namespace Maas\Shipping\Model;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterface;
use Magento\Quote\Api\Data\CartItemInterface;

/**
 * Class AvailableShippingMethodsItem
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore getters and setters
 */
class AvailableShippingMethodsItem implements AvailableShippingMethodsItemInterface
{
    /** @var int */
    protected $id;

    /** @var float */
    protected $qty;

    /** @var int */
    protected $offerId;

    /** @var int */
    protected $sellerId;

    /** @var int */
    protected $productId;

    /** @var string */
    protected $productSku;

    /** @var string */
    protected $productName;

    /** @var ShippingMethodInterface[] */
    protected $shippingMethods;

    protected array $optionList;

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @inheritDoc
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getQty()
    {
        return $this->qty;
    }

    /**
     * @inheritDoc
     */
    public function setQty($qty)
    {
        $this->qty = $qty;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getOfferId()
    {
        return $this->offerId;
    }

    /**
     * @inheritDoc
     */
    public function setOfferId($offerId)
    {
        $this->offerId = $offerId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @inheritDoc
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getProductId()
    {
        return $this->productId;
    }

    /**
     * @inheritDoc
     */
    public function setProductId($productId)
    {
        $this->productId = $productId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getProductSku()
    {
        return $this->productSku;
    }

    /**
     * @inheritDoc
     */
    public function setProductSku($productSku)
    {
        $this->productSku = $productSku;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getProductName()
    {
        return $this->productName;
    }

    /**
     * @inheritDoc
     */
    public function setProductName($productName)
    {
        $this->productName = $productName;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getShippingMethods()
    {
        return $this->shippingMethods;
    }

    /**
     * @inheritDoc
     */
    public function setShippingMethods($shippingMethods)
    {
        $this->shippingMethods = $shippingMethods;
        return $this;
    }

    /**
     * @return array
     */
    public function getOptionList()
    {
        return $this->optionList;
    }

    /**
     * @param array $optionList
     *
     * @return $this
     */
    public function setOptionList($optionList)
    {
        $this->optionList = $optionList;
        return $this;
    }
}
