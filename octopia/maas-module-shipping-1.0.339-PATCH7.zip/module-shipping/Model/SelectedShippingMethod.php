<?php


namespace Maas\Shipping\Model;


use Maas\Shipping\Api\Data\SelectedShippingMethodInterface;

/**
 * Class SelectedShippingMethod
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore getters and setters
 */
class SelectedShippingMethod implements SelectedShippingMethodInterface
{
    /**
     * @var int|null
     */
    protected $itemId = null;

    /**
     * @var string|null
     */
    protected $code = null;

    /**
     * @inheritDoc
     */
    public function getItemId()
    {
        return $this->itemId;
    }

    /**
     * @inheritDoc
     */
    public function setItemId($itemId)
    {
        $this->itemId = $itemId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @inheritDoc
     */
    public function setCode($code)
    {
        $this->code = $code;
        return $this;
    }
}
