<?php

namespace Maas\Shipping\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class SalesShipmentInfo
 *
 * @package Maas\Shipping\Model\ResourceModel
 * @codeCoverageIgnore delegates to standard
 */
class SalesShipmentInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_sales_shipment_info', 'shipment_id');
        $this->_isPkAutoIncrement = false;
    }
}
