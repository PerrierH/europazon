<?php

namespace Maas\Shipping\Model\ResourceModel\SalesShipmentInfo;

use Maas\Shipping\Model\ResourceModel\SalesShipmentInfo as SalesShipmentInfoResource;
use Maas\Shipping\Model\SalesShipmentInfo as SalesShipmentInfoModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Shipping\Model\ResourceModel\SalesShipmentInfo
 * @codeCoverageIgnore delegates to standard
 */
class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(SalesShipmentInfoModel::class, SalesShipmentInfoResource::class);
    }
}
