<?php

namespace Maas\Shipping\Model\ResourceModel;

use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Model\ResourceModel\Quote\Address\Item as AddressItemResource;
use Magento\Quote\Model\ResourceModel\Quote\Item as ItemResource;

/**
 * Class Quote
 *
 * @package Maas\Shipping\Model\ResourceModel
 * @codeCoverageIgnore delegates all logic to the database
 */
class Quote
{
    /** @var ItemResource */
    protected $itemResource;

    /** @var AddressItemResource */
    protected $addressItemResource;

    /**
     * Quote constructor.
     *
     * @param ItemResource $itemResource
     * @param AddressItemResource $addressItemResource
     */
    public function __construct(
        ItemResource $itemResource,
        AddressItemResource $addressItemResource
    ) {
        $this->itemResource = $itemResource;
        $this->addressItemResource = $addressItemResource;
    }

    /**
     * Does at least one quote item address exist?
     * Detecting this with standard methods is either impossible or in some cases leads
     * to item duplication
     *
     * @param int $quoteId
     *
     * @return bool
     * @throws LocalizedException
     */
    public function getHasAddressItems($quoteId)
    {
        $connection = $this->itemResource->getConnection();
        $select = $connection->select()
            ->from(['qi' => $this->itemResource->getMainTable()], ['qi.item_id', 'qi.qty'])
            ->join(['qai' => $this->addressItemResource->getMainTable()],
                'qi.item_id = qai.quote_item_id',
                ['*'])
            ->where('quote_id = ?', $quoteId)
            ->limit(1);

        return $connection->fetchRow($select) ? true : false;
    }
}
