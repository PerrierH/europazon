<?php


namespace Maas\Shipping\Model;

use Maas\Shipping\Api\Data\AvailableShippingMethodsInterface;
use Maas\Shipping\Api\Data\AvailableShippingMethodsItemInterface;

/**
 * Class AvailableShippingMethods
 *
 * @package Maas\Shipping\Model
 * @codeCoverageIgnore getters and setters
 */
class AvailableShippingMethods implements AvailableShippingMethodsInterface
{
    /** @var bool */
    protected $hasMarketplaceProducts;

    /** @var bool */
    protected $hasCoreProducts;

    /** @var AvailableShippingMethodsItemInterface[] */
    protected $items;

    /**
     * @inheritDoc
     */
    public function getHasMarketplaceProducts()
    {
        return $this->hasMarketplaceProducts;
    }

    /**
     * @inheritDoc
     */
    public function setHasMarketplaceProducts($hasMarketplaceProducts)
    {
        $this->hasMarketplaceProducts = $hasMarketplaceProducts;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getHasCoreProducts()
    {
        return $this->hasCoreProducts;
    }

    /**
     * @inheritDoc
     */
    public function setHasCoreProducts($hasCoreProducts)
    {
        $this->hasCoreProducts = $hasCoreProducts;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getItems()
    {
        return $this->items;
    }

    /**
     * @inheritDoc
     */
    public function setItems($items)
    {
        $this->items = $items;
        return $this;
    }
}
