<?php


namespace Maas\Shipping\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 *
 * @codeCoverageIgnore
 * @package Maas\Sales\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        $this->createTableSalesShipmentInfo($setup, $connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param AdapterInterface $connection
     */
    protected function createTableSalesShipmentInfo($setup, $connection)
    {
        if (!$setup->tableExists('maas_sales_shipment_info')) {
            $table = $connection->newTable(
                $setup->getTable('maas_sales_shipment_info')
            )
                ->addColumn(
                    'shipment_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Shipment Id'
                )
                ->addColumn(
                    'tracking_url',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true
                    ],
                    'Tracking URL'
                )
                ->setComment('maas_sales_shipment_info Table');
            $connection->createTable($table);
            $connection->addForeignKey(
                $connection->getForeignKeyName(
                    $setup->getTable(
                        'maas_sales_shipment_info'
                    ),
                    'shipment_id',
                    'sales_shipment',
                    'entity_id'
                ),
                $setup->getTable('maas_sales_shipment_info'),
                'shipment_id',
                $setup->getTable('sales_shipment'),
                'entity_id'
            );
        }
    }
}
