define([
    'ko',
    'Maas_Shipping/js/model/marketplace-shipment-data',
    'Maas_Shipping/js/model/marketplace-shipment-selected',
    'uiClass'
], function (ko, marketplaceShipmentData, marketplaceShipmentSelected, uiClass) {
    'use strict';

    var radioStatesObject = ko.observable();

    var mixin = {
        defaults: {
            shippingMethodListTemplate: 'Maas_Shipping/shipping-address/shipping-method-list-with-children',
            marketplaceShippingMethodListTemplate: 'Maas_Shipping/shipping-address/marketplace-shipping-method-list',
            marketplaceShippingMethodItemTemplate: 'Maas_Shipping/shipping-address/marketplace-shipping-method-item'
        },
        radioStates: radioStatesObject,
        hasMarketplace: marketplaceShipmentData.data.hasMarketplace,
        hasCore: marketplaceShipmentData.data.hasCore,
        maasMarketplaceShipment: marketplaceShipmentSelected.initSelected(marketplaceShipmentData.items, radioStatesObject),
        selectMarketplaceShippingMethod: function (shippingMethod) {
            marketplaceShipmentSelected.setMarketplaceShippingMethodFromObject(shippingMethod, radioStatesObject);
            return true;
        },
        rates: function() {
            const parentRates = this._super();
            if(!(parentRates instanceof uiClass))
            {
                let maasMethod = null;
                for (let i = 0; i < parentRates.length; i++) {
                    if (parentRates[i].carrier_code === marketplaceShipmentData.data.marketplaceShippingMethod.carrier
                        && parentRates[i].method_code === marketplaceShipmentData.data.marketplaceShippingMethod.method) {
                        maasMethod = parentRates[i];
                        marketplaceShipmentData.marketplaceShippingMethod(maasMethod);
                    }
                }
                if (maasMethod && (marketplaceShipmentData.data.hasMarketplace && (!marketplaceShipmentData.data.hasCore))) {
                    this.selectShippingMethod(maasMethod);
                }
            }
            return parentRates;
        },
        filteredRates: function() {
            const rates = this.rates();
            if(rates instanceof uiClass)
            {
                return rates;
            }
            const filtered = []
            for (let i = 0; i < rates.length; i++) {
                if (rates[i].carrier_code !== marketplaceShipmentData.data.marketplaceShippingMethod.carrier
                    && rates[i].method_code !== marketplaceShipmentData.data.marketplaceShippingMethod.method) {
                    filtered.push(rates[i]);
                }
            }
            return filtered;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
