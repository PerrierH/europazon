define([
    'ko',
    'Magento_Checkout/js/model/quote',
    'Magento_Catalog/js/price-utils',
    'Magento_Checkout/js/action/select-shipping-method',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/totals',
    'Maas_Shipping/js/model/marketplace-shipment-data',
    'Maas_Shipping/js/model/cart/marketplace-shipment-selected',
    'Magento_Checkout/js/model/shipping-service',
    'Magento_Checkout/js/model/cart/estimate-service'
], function (ko, quote, priceUtils, selectShippingMethodAction, checkoutData, totalsService, marketplaceShipmentData, selectedMethodsModel, shippingService) {
    'use strict';

    const mixin = {
        defaults: {
            template: 'Maas_Shipping/cart/shipping-rates'
        },

        items: ko.observable([]),
        /**
         * @override
         */
        initObservable: function () {

            this._super();
            const marketplaceItems = [];

            quote.getItems().forEach(function (item) {
                const copyItem = Object.assign({}, item);
                if (copyItem.hasOwnProperty('extension_attributes')
                    && copyItem.extension_attributes.hasOwnProperty('maas_available_shipping_methods')
                    && Object.keys(copyItem.extension_attributes.maas_available_shipping_methods).length > 0
                ) {
                    selectedMethodsModel.setMethod(copyItem.item_id, copyItem.extension_attributes.maas_available_shipping_methods[0].code);
                    marketplaceItems.push(copyItem)
                }
            });
            this.items(marketplaceItems);
            totalsService.isLoading.subscribe(function (newValue) {
                this.isLoading(newValue);
            }.bind(this));
            quote.totals.subscribe(function (newValue) {
                this.updateShippingTotalName(newValue);
            }.bind(this));

            this.initShippingMethod();
            shippingService.getShippingRates().subscribe(function (newValue) {
                if (newValue.length > 0 && !quote.shippingMethod()) {
                    quote.shippingMethod(newValue[0]);
                }
            });
            this.triggerUpdateShippingMethod();
            return this;
        },

        updateShippingTotalName: function (totals) {
            let totalName = null;
            for (let i = 0; i < totals.total_segments.length; i++) {
                if (totals.total_segments[i].code === "shipping"
                    && totals.total_segments[i].hasOwnProperty('extension_attributes')
                    && totals.total_segments[i].extension_attributes.hasOwnProperty('maas_shipping_label_in_total')) {
                    totalName = totals.total_segments[i].extension_attributes.maas_shipping_label_in_total;
                }
            }
            if (totalName) {
                selectedMethodsModel.shippingTotalLabelOverride(totalName);
            }
        },

        showMagentoShipping: function () {
            return marketplaceShipmentData.data.hasCore;
        },
        formatPrice: function (amount) {
            return priceUtils.formatPrice(amount, quote.getPriceFormat());
        },
        initShippingMethod: function () {
            const items = quote.getItems();
            let storedMethods = checkoutData.getSelectedMarketplaceMethods();
            if (!storedMethods) {
                storedMethods = {};
            }
            for (let i = 0; i < items.length; i++) {
                const itemId = items[i].item_id;
                const code = this.getItemShippingMethod(items[i].item_id);
                if (code !== false) {
                    selectedMethodsModel.setMethod(itemId, code);
                    storedMethods[itemId] = code;
                }
            }
            checkoutData.setSelectedMarketplaceMethods(storedMethods);
        },
        reloadShippingMethod: function (itemId, code) {
            selectedMethodsModel.setMethod(itemId, code);
            let storedMethods = checkoutData.getSelectedMarketplaceMethods();
            if (!storedMethods) {
                storedMethods = {};
            }
            storedMethods[itemId] = code;
            checkoutData.setSelectedMarketplaceMethods(storedMethods);
            this.triggerUpdateShippingMethod();
            return true;
        },
        triggerUpdateShippingMethod() {
            if (marketplaceShipmentData.data.hasMarketplace && !marketplaceShipmentData.data.hasCore) {
                quote.shippingMethod(marketplaceShipmentData.getMaasMarketplaceShippingMethodObject());
            }
            quote.shippingMethod.valueHasMutated();
        },
        getItemShippingMethod(itemId) {
            const methodsFromStorage = checkoutData.getSelectedMarketplaceMethods();
            if (methodsFromStorage && methodsFromStorage.hasOwnProperty(itemId)) {
                selectedMethodsModel.setMethod(itemId, methodsFromStorage[itemId]);
                return methodsFromStorage[itemId];
            }
            return selectedMethodsModel.getMethod(itemId);
        },
        initialize: function () {
            this._super();
        },
        shippingAvailable: function() {
            return shippingService.getShippingRates().length > 0 || shippingService.maasMethodExists();
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
