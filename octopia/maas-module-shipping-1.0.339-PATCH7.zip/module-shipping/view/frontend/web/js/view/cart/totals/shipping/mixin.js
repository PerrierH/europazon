define([
    'ko',
    'Maas_Shipping/js/model/marketplace-shipment-data',
    'Maas_Shipping/js/model/cart/marketplace-shipment-selected',
    'Magento_Checkout/js/model/quote'
], function (ko, marketplaceShipmentData, marketplaceShipmentSelected, quote) {
    'use strict';

    const mixin = {
        getShippingMethodTitle: function () {
            const override = marketplaceShipmentSelected.shippingTotalLabelOverride();
            if (typeof override !== 'undefined' && override !== false) {
                return `(${override})`;
            } else {
                return this._super();
            }
        },
        isCalculated: function () {
            const method = quote.shippingMethod();
            if((!!method)
                && method.carrier === marketplaceShipmentData.data.marketplaceShippingMethod.carrier
                && method.method === marketplaceShipmentData.data.marketplaceShippingMethod.method)
            {
                return true;
            }
            else
            {
                return this._super();
            }
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
