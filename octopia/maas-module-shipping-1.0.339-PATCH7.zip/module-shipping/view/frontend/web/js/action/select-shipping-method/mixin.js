define([
    'Magento_Checkout/js/model/quote',
    'Maas_Shipping/js/model/marketplace-shipment-data'
], function(quote, marketplaceShipmentData)
{
    return function(originalAction) {
        return function (shippingMethod)
        {
            if(!!shippingMethod)
            {
                originalAction(shippingMethod);
            }
            else
            {
                const existingMethod = quote.shippingMethod();
                if (!!existingMethod)
                {
                    const marketplaceMethod = marketplaceShipmentData.getMaasMarketplaceShippingMethodObject()
                    if(existingMethod.carrier_code !== marketplaceMethod.carrier_code
                        || existingMethod.method_code !== marketplaceMethod.method_code)
                    {
                        originalAction(shippingMethod);
                    }
                }
            }
        }
    }
});
