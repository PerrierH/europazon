define([
    'Magento_Checkout/js/action/set-shipping-information',
    'Magento_Checkout/js/model/step-navigator'
], function (
    setShippingInformationAction,
    stepNavigator
) {
    'use strict';

    return function (cancelCoupon) {
        cancelCoupon.registerSuccessCallback(function () {
            setShippingInformationAction().done(
                function () {
                    let i = 1;
                    do {
                        stepNavigator.next();
                        i++;
                    } while (i <= 2);
                }
            );
        });
        return cancelCoupon;
    };
});
