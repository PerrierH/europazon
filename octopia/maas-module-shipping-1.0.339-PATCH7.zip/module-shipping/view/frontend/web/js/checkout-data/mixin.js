define([
    'Magento_Customer/js/customer-data',
    'jquery/jquery-storageapi'
], function (storage) {
    'use strict';

    var cacheKey = 'checkout-data';

    var saveData = function (data) {
        storage.set(cacheKey, data);
    };

    var getData = function () {
        return storage.get(cacheKey)();
    };

    return function (target) {
        target.getSelectedMarketplaceMethods = function () {
            var data = getData();
            if (data.hasOwnProperty('selectedMarketplaceMethods')) {
                return data.selectedMarketplaceMethods;
            } else {
                return {};
            }
        };
        target.setSelectedMarketplaceMethods = function (data) {
            var obj = getData();

            obj.selectedMarketplaceMethods = data;
            saveData(obj);
        };

        return target;
    };
});
