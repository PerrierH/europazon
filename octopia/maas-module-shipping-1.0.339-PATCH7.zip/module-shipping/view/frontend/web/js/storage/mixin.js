define([
    'Maas_Shipping/js/model/cart/marketplace-shipment-selected'
], function (selectedMethodsModel) {
    'use strict';

    return function (target) {
        target.originalPost = target.post;
        target.post = function (url, data, global, contentType) {
            if (url.match(/\/[^\/]*carts[^\/]*\/[^\/]+\/totals-information$/)) {
                const parsed = JSON.parse(data);
                if (parsed.hasOwnProperty('addressInformation')) {
                    if (!parsed.hasOwnProperty('extension_attributes')) {
                        parsed.addressInformation.extension_attributes = {
                            maas_selected_shipping_methods:
                                selectedMethodsModel.getMethodsToSubmit()
                        };
                        if ((!parsed.addressInformation.address.hasOwnProperty('countryId'))
                            || (parsed.addressInformation.address.countryId))
                        {
                            // a country ID is required
                            parsed.addressInformation.address.countryId = window.checkoutConfig.defaultCountryId;
                        }
                    }
                    data = JSON.stringify(parsed);
                }
            }
            return this.originalPost(url, data, global, contentType);
        };
        return target;
    };
});
