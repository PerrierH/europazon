define([
    'Magento_Checkout/js/model/shipping-service'
], function (shippingService) {
    'use strict';

    return function (target) {
        shippingService.enableFilter();
        return target;
    };
});
