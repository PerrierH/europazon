define([
    'Maas_Shipping/js/model/marketplace-shipment-data',
    'Maas_Shipping/js/model/marketplace-shipment-selected'
], function (marketplaceShipmentData, maasMarketplaceShipmentSelected) {
    'use strict';

    return function (originalFunction) {
        return function (payload) {
            if (!marketplaceShipmentData.data.hasCore) {
                payload.addressInformation.shipping_carrier_code = marketplaceShipmentData.data.marketplaceShippingMethod.carrier;
                payload.addressInformation.shipping_method_code = marketplaceShipmentData.data.marketplaceShippingMethod.method;
            }
            const result = originalFunction(payload);
            if (result.hasOwnProperty('addressInformation') &&
                result.addressInformation.hasOwnProperty('extension_attributes')
            ) {
                result.addressInformation.extension_attributes.marketplace_shipping_methods = maasMarketplaceShipmentSelected.getMarketplaceShippingMethodsToSubmit()
            }
            return result;
        };
    };
});
