/**
 * @api
 */
define([
    'ko',
    'Magento_Checkout/js/checkout-data'
], function (ko, checkoutData) {
    const selectedMethodsClass = function () {
        // empty constructor
    };
    selectedMethodsClass.prototype = {
        selectedData: ko.observable({}),
        initSelected: function (dataArray, radioStates) {
            const storedMethods = checkoutData.getSelectedMarketplaceMethods();
            for (let i = 0; i < dataArray().length; i++) {
                const itemData = dataArray()[i]();
                if (itemData.shippingMethods().length > 0) {
                    if (storedMethods.hasOwnProperty(itemData.itemId)) {
                        this.selectedData()[itemData.itemId] = storedMethods[itemData.itemId];
                    } else {
                        const shippingMethodData = itemData.shippingMethods()[0]();
                        this.selectedData()[itemData.itemId] = shippingMethodData.code;
                    }
                }
            }
            radioStates(this.selectedData());
            return dataArray;
        },
        setMarketplaceShippingMethodFromObject: function (object, radioStates) {
            if (object.hasOwnProperty('itemId') && object.hasOwnProperty('code')) {
                this.setMarketplaceShippingMethod(object.itemId, object.code, radioStates);
            }
            return false;
        },
        setMarketplaceShippingMethod: function (itemId, methodCode, radioStates) {
            this.selectedData()[itemId] = methodCode;
            const rs = radioStates();
            rs[itemId] = methodCode;
            radioStates(rs);
            return false;
        },
        getMarketplaceShippingMethodsToSubmit: function () {
            const result = [];
            for (const i in this.selectedData()) {
                result.push({
                    quote_item_id: i,
                    shipping_method: this.selectedData()[i]
                });
            }
            return result;
        }
    };
    return new selectedMethodsClass();
});
