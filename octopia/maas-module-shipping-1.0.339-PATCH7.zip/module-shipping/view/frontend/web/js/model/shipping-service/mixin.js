define(['ko'], function (ko) {
    'use strict';

    return function (target) {
        target.superSetShippingRates = target.setShippingRates;
        target.maasMethodExists = ko.observable(false);

        // not needed on checkout, only on cart
        target.filterEnabled = false;
        target.setShippingRates = function (ratesData) {
            if (this.filterEnabled) {
                const filteredRates = [];
                this.maasMethodExists(false);
                for (let i = 0; i < ratesData.length; i++) {
                    if (!(ratesData[i].carrier_code === "maas" && ratesData[i].method_code === "marketplace")) {
                        filteredRates.push(ratesData[i]);
                    }
                    else {
                        this.maasMethodExists(true);
                    }
                }
                this.superSetShippingRates(filteredRates);
            } else {
                this.superSetShippingRates(ratesData);
            }
        };

        target.enableFilter = function () {
            this.filterEnabled = true;
        };
        return target;
    };
});
