/**
 * @api
 */
define([
    'ko'
], function (ko) {
    return {
        shippingTotalLabelOverride: ko.observable(),
        methods: {},
        setMethod: function (itemId, code) {
            this.methods[itemId] = code;
        },
        getMethod(itemId) {
            return this.methods.hasOwnProperty(itemId) ? this.methods[itemId] : false;
        },
        getMethodsToSubmit() {
            const methodsToSubmit = [];
            for (const i in this.methods) {
                methodsToSubmit.push({
                    item_id: i, code: this.methods[i]
                });
            }
            return methodsToSubmit;
        }
    };
});
