define([
    'ko',
    'Magento_Checkout/js/model/totals',
    'Maas_Shipping/js/model/marketplace-shipment-data'
], function (ko, totals, marketplaceShipmentData) {
    'use strict';

    var mixin = {
        defaults: {
            template: 'Maas_Shipping/shipping-information-with-marketplace'
        },
        getMarketplaceShippingDescriptions: function () {
            var totalItems = totals.getItems()();
            var descriptions = [];
            for (var i = 0; i < totalItems.length; i++) {
                if (totalItems[i].extension_attributes) {
                    descriptions.push({
                        product_name: totalItems[i].name,
                        shipping_label: totalItems[i].extension_attributes.maas_shipping_label,
                        shipping_estimate: totalItems[i].extension_attributes.maas_shipping_estimation
                    });
                }
            }
            return descriptions;
        },
        isDefaultMethodShown: function () {
            return marketplaceShipmentData.data.hasCore;
        },
        getDivClassWithSuffix: function (existingClasses, index) {
            if (index() === 0 && (!this.isDefaultMethodShown())) {
                return existingClasses + '-first';
            }
            return existingClasses;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
