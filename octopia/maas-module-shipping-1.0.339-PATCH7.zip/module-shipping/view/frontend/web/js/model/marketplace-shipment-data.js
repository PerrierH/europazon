/**
 * @api
 */
define([
    'ko',
    'underscore',
    'Magento_Checkout/js/model/quote',
    'Magento_Catalog/js/price-utils',
    'domReady!'
], function (ko, _, quote, priceUtils) {
    var marketplaceShipments = {
        data: window.checkoutConfig.maasMarketplaceShipment.data,
        items: ko.observableArray([]),
        marketplaceShippingMethod: ko.observable(null),
        getMaasMarketplaceShippingMethodObject: function () {
            const data = window.checkoutConfig.maasMarketplaceShipment.data;
            const marketplaceShippingMethodData = window.checkoutConfig.maasMarketplaceShipment.data.marketplaceShippingMethod;
            return {
                carrier_code: marketplaceShippingMethodData.carrier,
                method_code: marketplaceShippingMethodData.method,
                carrier_title: marketplaceShippingMethodData.carrier_label,
                method_title: marketplaceShippingMethodData.method_label,
                amount: 0, base_amount: 0, available: data.hasMarketplace && (!data.hasCore),
                error_message: '', price_excl_tax: 0, price_incl_tax: 0
            };
        }
    };

    for (const i in window.checkoutConfig.maasMarketplaceShipment.items) {
        const itemData = window.checkoutConfig.maasMarketplaceShipment.items[i];
        const methods = [];
        for (let j = 0; j < itemData.shippingMethods.length; j++) {
            const methodData = itemData.shippingMethods[j];
            methods.push(ko.observable({
                formattedPrice: priceUtils.formatPrice(itemData.qty * methodData.amount, quote.getPriceFormat()),
                amount: methodData.amount,
                row_amount: itemData.qty * methodData.amount,
                baseAmount: methodData.base_amount,
                code: methodData.code,
                label: methodData.label,
                maxDelay: methodData.max_delay,
                minDelay: methodData.min_delay,
                productId: methodData.product_id,
                estimation: methodData.estimation,
                itemId: itemData.itemId
            }));
        }
        const item = ko.observable({
            itemId: itemData.itemId,
            name: itemData.name,
            offerId: itemData.offerId,
            productId: itemData.productId,
            qty: itemData.qty,
            sellerId: itemData.sellerId,
            shippingMethods: ko.observableArray(methods),
            options: itemData.options
        });
        marketplaceShipments.items.push(item);
    }
    return marketplaceShipments;
});
