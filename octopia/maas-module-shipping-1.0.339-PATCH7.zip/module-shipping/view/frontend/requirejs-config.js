var config = {
    config: {
        mixins: {
            'mage/storage': {
                'Maas_Shipping/js/storage/mixin': true
            },
            'Magento_Checkout/js/view/shipping': {
                'Maas_Shipping/js/view/shipping/mixin': true
            },
            'Magento_Checkout/js/model/shipping-save-processor/payload-extender': {
                'Maas_Shipping/js/model/shipping-save-processor/payload-extender/mixin': true
            },
            'Magento_Checkout/js/model/shipping-service': {
                'Maas_Shipping/js/model/shipping-service/mixin': true
            },
            'Magento_Checkout/js/view/shipping-information': {
                'Maas_Shipping/js/model/shipping-information/mixin': true
            },
            'Magento_Checkout/js/model/cart/estimate-service': {
                'Maas_Shipping/js/model/cart/estimate-service/mixin': true
            },
            'Magento_Checkout/js/view/cart/shipping-rates': {
                'Maas_Shipping/js/view/cart/shipping-rates/mixin': true
            },
            'Magento_Tax/js/view/checkout/cart/totals/shipping': {
                'Maas_Shipping/js/view/cart/totals/shipping/mixin': true
            },
            'Magento_Checkout/js/checkout-data': {
                'Maas_Shipping/js/checkout-data/mixin': true
            },
            'Magento_Checkout/js/action/select-shipping-method': {
                'Maas_Shipping/js/action/select-shipping-method/mixin': true
            },
            'Magento_SalesRule/js/action/set-coupon-code': {
                'Maas_Shipping/js/action/set-coupon-code/mixin': true
            },
            'Magento_SalesRule/js/action/cancel-coupon': {
                'Maas_Shipping/js/action/cancel-coupon/mixin': true
            },
        }
    }
};
