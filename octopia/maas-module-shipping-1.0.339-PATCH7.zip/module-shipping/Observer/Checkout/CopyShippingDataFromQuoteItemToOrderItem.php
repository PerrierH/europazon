<?php

namespace Maas\Shipping\Observer\Checkout;

use Maas\Shipping\Model\Service\ShippingDataCopier;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote\Item as QuoteItem;
use Magento\Sales\Model\Order\Item as OrderItem;

/**
 * Class CopyShippingDataFromQuoteItemToOrderItem
 * @package Maas\Shipping\Observer
 */
class CopyShippingDataFromQuoteItemToOrderItem implements ObserverInterface
{
    /**
     * @var ShippingDataCopier
     */
    protected $shippingDataCopier;

    /**
     * CopyShippingDataFromQuoteItemToOrderItem constructor.
     *
     * @param ShippingDataCopier $shippingDataCopier
     */
    public function __construct(ShippingDataCopier $shippingDataCopier)
    {
        $this->shippingDataCopier = $shippingDataCopier;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var QuoteItem $quoteItem */
        $quoteItem = $observer->getEvent()->getData('quote_item');
        if (!$quoteItem->getQuote()->getIsMultiShipping()) {
            /** @var OrderItem $orderItem */
            $orderItem = $observer->getEvent()->getData('order_item');
            $this->shippingDataCopier->executeForSingleShipping($quoteItem, $orderItem);
        }
    }
}
