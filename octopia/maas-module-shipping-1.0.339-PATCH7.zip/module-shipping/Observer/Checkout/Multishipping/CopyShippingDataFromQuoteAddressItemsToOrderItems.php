<?php

namespace Maas\Shipping\Observer\Checkout\Multishipping;

use Maas\Shipping\Model\Service\ShippingDataCopier;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class CopyShippingDataFromQuoteAddressItemsToOrderItems
 * @package Maas\Shipping\Observer\Multishipping
 */
class CopyShippingDataFromQuoteAddressItemsToOrderItems implements ObserverInterface
{
    /**
     * @var ShippingDataCopier
     */
    protected $shippingDataCopier;

    /**
     * CopyShippingDataFromQuoteAddressItemsToOrderItems constructor.
     *
     * @param ShippingDataCopier $shippingDataCopier
     */
    public function __construct(ShippingDataCopier $shippingDataCopier)
    {
        $this->shippingDataCopier = $shippingDataCopier;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $this->shippingDataCopier->executeForMultishipping(
            $observer->getEvent()->getData('order'), $observer->getEvent()->getData('address')
        );
    }
}
