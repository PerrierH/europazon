<?php

namespace Maas\Shipping\Observer\Checkout;

use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ItemsType;
use Maas\Shipping\Model\Service\ShippingMethod;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote;

/**
 * Class SetMaasMethodToMarketplaceAddressOnCopy
 *
 * @package Maas\Shipping\Observer\Checkout
 */
class SetMaasMethodToMarketplaceAddressOnCopy implements ObserverInterface
{

    /**
     * @var ShippingMethod
     */
    protected $shippingMethodService;

    /**
     * @var ItemsType
     */
    protected $itemsType;

    /**
     * SetMaasMethodToMarketplaceAddressOnCopy constructor.
     *
     * @param ShippingMethod $shippingMethodService
     * @param ItemsType $itemsType
     * @codeCoverageIgnore
     */
    public function __construct(
        ShippingMethod $shippingMethodService,
        ItemsType $itemsType
    ) {
        $this->shippingMethodService = $shippingMethodService;
        $this->itemsType = $itemsType;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Quote $targetCart */
        $targetCart = $observer->getEvent()->getData('target_cart');
        $quoteAddressData = $observer->getEvent()->getData('address_data');
        if ($this->itemsType->getItemsType($targetCart->getItems()) == ItemsType::MARKETPLACE) {
            $this->shippingMethodService->setOnAddressDataObject($quoteAddressData, $targetCart->getStoreId());
        }
    }
}
