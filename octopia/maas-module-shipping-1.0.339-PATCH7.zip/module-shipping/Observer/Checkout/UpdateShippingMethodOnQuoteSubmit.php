<?php


namespace Maas\Shipping\Observer\Checkout;

use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ShippingMethod;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderInterface;

/**
 * Class UpdateShippingMethodOnQuoteSubmit
 *
 * @package Maas\Shipping\Observer
 * @codeCoverageIgnore delegates to other classes
 */
class UpdateShippingMethodOnQuoteSubmit implements ObserverInterface
{
    /**
     * @var ShippingMethod
     */
    private $shippingMethod;

    /**
     * UpdateShippingMethod constructor.
     *
     * @param ShippingMethod $shippingMethod
     * @param Config $config
     */
    public function __construct(
        ShippingMethod $shippingMethod
    ) {
        $this->shippingMethod = $shippingMethod;
    }

    /**
     * @param Observer $observer
     *
     * @throws AlreadyExistsException
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function execute(Observer $observer)
    {
        $event = $observer->getEvent();
        /** @var OrderInterface $order */
        $order = $event->getData('order');
        if ($order) {
            $extraInfo = $order->getExtensionAttributes()->getExtraInfo();
            if ($extraInfo && !empty($extraInfo->getSellerId())) {
                $this->shippingMethod->setOnOrder($order);
            }
        }
    }
}
