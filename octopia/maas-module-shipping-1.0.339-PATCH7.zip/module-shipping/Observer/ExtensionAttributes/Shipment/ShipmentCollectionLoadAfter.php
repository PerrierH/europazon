<?php

namespace Maas\Shipping\Observer\ExtensionAttributes\Shipment;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Shipping\Api\Data\SalesShipmentInfoInterfaceFactory;
use Maas\Shipping\Api\SalesShipmentInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\ShipmentExtensionInterfaceFactory;

/**
 * Class OrderCollectionLoadAfter
 *
 * @package Maas\Sales\Observer\ExtensionAttributes\Order
 * @codeCoverageIgnore
 */
class ShipmentCollectionLoadAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var ShipmentExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesShipmentInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesShipmentInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * OrderCollectionLoadAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param ShipmentExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesShipmentInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesShipmentInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        ShipmentExtensionInterfaceFactory $modelExtensionFactory,
        SalesShipmentInfoRepositoryInterface $extensionAttributeRepository,
        SalesShipmentInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $collection = $observer->getEvent()->getData('order_shipment_collection');

        $this->extensionAttributeCrudManager->loadCollectionAfter(
            $collection, 'shipment_id', $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
