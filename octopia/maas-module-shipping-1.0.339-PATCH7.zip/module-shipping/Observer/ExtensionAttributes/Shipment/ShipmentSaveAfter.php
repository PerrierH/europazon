<?php

namespace Maas\Shipping\Observer\ExtensionAttributes\Shipment;

use Maas\Core\Model\Service\ExtensionAttributeCrudManager;
use Maas\Shipping\Api\Data\SalesShipmentInfoInterfaceFactory;
use Maas\Shipping\Api\SalesShipmentInfoRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\ShipmentExtensionInterfaceFactory;

/**
 * Class ShipmentSaveAfter
 *
 * @package Maas\Shipping\Observer\ExtensionAttributes\Shipment
 * @codeCoverageIgnore
 */
class ShipmentSaveAfter implements ObserverInterface
{
    /**
     * @var ExtensionAttributeCrudManager
     */
    private $extensionAttributeCrudManager;

    /**
     * @var ShipmentExtensionInterfaceFactory
     */
    private $modelExtensionFactory;

    /**
     * @var SalesShipmentInfoRepositoryInterface
     */
    private $extensionAttributeRepository;

    /**
     * @var SalesShipmentInfoInterfaceFactory
     */
    private $extensionAttributeFactory;

    /**
     * OrderSaveAfter constructor.
     *
     * @param ExtensionAttributeCrudManager $extensionAttributeCrudManager
     * @param ShipmentExtensionInterfaceFactory $modelExtensionFactory
     * @param SalesShipmentInfoRepositoryInterface $extensionAttributeRepository
     * @param SalesShipmentInfoInterfaceFactory $extensionAttributeFactory
     */
    public function __construct(
        ExtensionAttributeCrudManager $extensionAttributeCrudManager,
        ShipmentExtensionInterfaceFactory $modelExtensionFactory,
        SalesShipmentInfoRepositoryInterface $extensionAttributeRepository,
        SalesShipmentInfoInterfaceFactory $extensionAttributeFactory
    ) {
        $this->extensionAttributeCrudManager = $extensionAttributeCrudManager;
        $this->modelExtensionFactory = $modelExtensionFactory;
        $this->extensionAttributeRepository = $extensionAttributeRepository;
        $this->extensionAttributeFactory = $extensionAttributeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getData('shipment');

        $this->extensionAttributeCrudManager->saveAfter(
            $order, $this->modelExtensionFactory, 'extra_info',
            $this->extensionAttributeRepository, $this->extensionAttributeFactory
        );
    }
}
