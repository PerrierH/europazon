<?php

namespace Maas\Shipping\Observer;

use Maas\Shipping\Model\Config;
use Maas\Shipping\Model\Service\ShippingMethod;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\ResourceModel\Quote\Address;

/**
 * Class ResetCartShippingMethodOnCoreProductAdd
 *
 * @package Maas\Shipping\Observer
 */
class ResetCartShippingMethodOnCoreProductAdd implements ObserverInterface
{
    /** @var Address */
    protected $addressResource;

    /** @var CartRepositoryInterface */
    protected $cartRepository;

    /** @var ShippingMethod */
    protected $shippingMethodService;

    /**
     * ResetCartShippingMethodOnCoreProductAdd constructor.
     *
     * @param Address $addressResource
     * @param CartRepositoryInterface $cartRepository
     * @param ShippingMethod $shippingMethodService
     * @codeCoverageIgnore
     */
    public function __construct(
        Address $addressResource,
        CartRepositoryInterface $cartRepository,
        ShippingMethod $shippingMethodService
    ) {
        $this->addressResource = $addressResource;
        $this->cartRepository = $cartRepository;
        $this->shippingMethodService = $shippingMethodService;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Item $item */
        $item = $observer->getEvent()->getData('quote_item');

        $quote = $item->getQuote();
        $address = $quote->getShippingAddress();
        if ($this->shippingMethodService->unsetFromCartAndAddress($quote, $address)) {
            $this->addressResource->save($address);
            $this->cartRepository->save($quote);
        }
    }
}
