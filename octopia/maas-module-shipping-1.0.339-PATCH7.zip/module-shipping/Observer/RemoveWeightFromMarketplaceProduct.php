<?php

namespace Maas\Shipping\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote\Item;

/**
 * Class RemoveWeightFromMarketplaceProduct
 *
 * @package Maas\Shipping\Observer
 */
class RemoveWeightFromMarketplaceProduct implements ObserverInterface
{

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Item $qItem */
        $qItem = $observer->getEvent()->getQuoteItem();
        $product = $observer->getEvent()->getProduct();
        if ($product->getMaasOfferId()) {
            $qItem->setWeight(0);
            $qItem->setRowWeight(0);
        }
    }
}
