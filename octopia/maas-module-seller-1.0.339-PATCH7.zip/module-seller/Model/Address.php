<?php

namespace Maas\Seller\Model;

use Maas\Seller\Api\Data\AddressInterface;
use Maas\Seller\Model\ResourceModel\Address as AddressResource;
use Magento\Framework\Model\AbstractExtensibleModel;

/**
 * Class Address
 *
 * @package Maas\Seller\Model
 */
class Address extends AbstractExtensibleModel implements AddressInterface
{
    use AddressTrait;

    const ENTITY = 'maas_seller_address';
    CONST ADDRESS_TYPE_HEADOFFICE = 'headOffice';
    CONST ADDRESS_TYPE_CUSTOMERSERVICE = 'customerService';
    CONST ADDRESS_TYPE_RETURN = 'return';

    /**
     * @var string
     */
    protected $_eventPrefix = 'maas_seller_address';

    /**
     * @var string
     */
    protected $_eventObject = 'address';

    protected function _construct()
    {
        $this->_init(AddressResource::class);
    }

    /**
     * @inheritDoc
     */
    public function getSellerId()
    {
        return $this->getData(self::SELLER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * @inheritDoc
     */
    public function getAppartment()
    {
        return $this->getData(self::APPARTMENT);
    }

    /**
     * @inheritDoc
     */
    public function setAppartment($appartment)
    {
        return $this->setData(self::APPARTMENT, $appartment);
    }
}