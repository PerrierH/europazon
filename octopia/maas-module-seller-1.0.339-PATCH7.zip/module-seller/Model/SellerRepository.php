<?php

namespace Maas\Seller\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Seller\Api\Data\SellerInterface;
use Maas\Seller\Api\Data\SellerSearchResultsInterfaceFactory;
use Maas\Seller\Api\SellerRepositoryInterface;
use Maas\Seller\Model\ResourceModel\Seller as SellerResource;
use Maas\Seller\Model\ResourceModel\Seller\CollectionFactory as SellerCollectionFactory;
use Maas\Seller\Model\SellerFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class SellerRepository
 *
 * @package Maas\Seller\Model
 * @codeCoverageIgnore Delegates to parent
 */
class SellerRepository extends AbstractRepository implements SellerRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(SellerInterface $seller)
    {
        return $this->_save($seller);
    }

    /**
     * @inheritDoc
     */
    public function delete(SellerInterface $seller)
    {
        $this->_delete($seller);
    }
}
