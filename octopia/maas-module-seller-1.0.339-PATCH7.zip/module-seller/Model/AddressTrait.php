<?php

namespace Maas\Seller\Model;

/**
 * Class AddressRepository
 *
 * @package Maas\Seller\Model
 */
trait AddressTrait
{

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->getData(self::TYPE);
    }

    /**
     * @inheritDoc
     */
    public function setType($type)
    {
        return $this->setData(self::TYPE, $type);
    }

    /**
     * @inheritDoc
     */
    public function getAddress1()
    {
        return $this->getData(self::ADDRESS1);
    }

    /**
     * @inheritDoc
     */
    public function setAddress1($address1)
    {
        return $this->setData(self::ADDRESS1, $address1);
    }

    /**
     * @inheritDoc
     */
    public function getAddress2()
    {
        return $this->getData(self::ADDRESS2);
    }

    /**
     * @inheritDoc
     */
    public function setAddress2($address2)
    {
        return $this->setData(self::ADDRESS2, $address2);
    }


    /**
     * @inheritDoc
     */
    public function getBuilding()
    {
        return $this->getData(self::BUILDING);
    }

    /**
     * @inheritDoc
     */
    public function setBuilding($building)
    {
        return $this->setData(self::BUILDING, $building);
    }

    /**
     * @inheritDoc
     */
    public function getZipCode()
    {
        return $this->getData(self::ZIPCODE);
    }

    /**
     * @inheritDoc
     */
    public function setZipCode($zipCode)
    {
        return $this->setData(self::ZIPCODE, $zipCode);
    }

    /**
     * @inheritDoc
     */
    public function getCity()
    {
        return $this->getData(self::CITY);
    }

    /**
     * @inheritDoc
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * @inheritDoc
     */
    public function getCounty()
    {
        return $this->getData(self::COUNTY);
    }

    /**
     * @inheritDoc
     */
    public function setCounty($county)
    {
        return $this->setData(self::COUNTY, $county);
    }

    /**
     * @inheritDoc
     */
    public function getCountry()
    {
        return $this->getData(self::COUNTRY);
    }

    /**
     * @inheritDoc
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }

    /**
     * @inheritDoc
     */
    public function getInstructions()
    {
        return $this->getData(self::INSTRUCTIONS);
    }

    /**
     * @inheritDoc
     */
    public function setInstructions($instructions)
    {
        return $this->setData(self::INSTRUCTIONS, $instructions);
    }
}