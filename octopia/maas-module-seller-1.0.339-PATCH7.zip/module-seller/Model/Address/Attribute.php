<?php

namespace Maas\Seller\Model\Address;

use Maas\Seller\Api\Data\AddressAttributeInterface;
use Maas\Seller\Model\ResourceModel\Address\Attribute as AttributeResource;
use Magento\Eav\Model\Attribute as EavAttribute;

/**
 * Class Attribute
 *
 * @package Maas\Seller\Model\Address
 * @codeCoverageIgnore No logic, delegates to standard
 */
class Attribute extends EavAttribute implements AddressAttributeInterface
{
    /**
     * Name of the module
     */
    const MODULE_NAME = 'Maas_Seller';

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'maas_seller_address_attribute';

    /**
     * Prefix of model events object
     *
     * @var string
     */
    protected $_eventObject = 'attribute';


    /**
     * Init resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(AttributeResource::class);
    }
}

