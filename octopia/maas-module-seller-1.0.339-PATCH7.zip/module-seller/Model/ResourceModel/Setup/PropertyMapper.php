<?php

namespace Maas\Seller\Model\ResourceModel\Setup;

use Magento\Eav\Model\Entity\Setup\PropertyMapperAbstract;

/**
 * Class PropertyMapper
 *
 * @package Maas\Seller\Model\ResourceModel\Setup
 * @codeCoverageIgnore No logic, delegates to standard
 */
class PropertyMapper extends PropertyMapperAbstract
{
    /**
     * @inheritDoc
     */
    public function map(array $input, $entityTypeId)
    {
        return [
            'is_imported' => $this->_getValue($input, 'imported', 1),
        ];
    }
}
