<?php

namespace Maas\Seller\Model\ResourceModel;

use Maas\Seller\Model\Seller as SellerModel;
use Magento\Eav\Model\Entity\AbstractEntity;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Seller
 *
 * @package Maas\Seller\Model\ResourceModel
 * @codeCoverageIgnore
 */
class Seller extends AbstractEntity
{
    /**
     * @var string
     */
    protected $logoRenditionsTable = 'maas_seller_logo_rendition';

    /**
     * @var string[]|null
     */
    protected $customAttributeCodes = null;

    /**
     * @param SellerModel $object
     * @param array $renditionsData
     *
     * @return $this
     */
    public function saveLogoRenditions($object, $renditionsData)
    {
        $objectId = $object->getId();
        if (!($objectId && $renditionsData)) {
            return $this;
        }
        $connection = $this->getConnection();
        $table = $this->getTable($this->logoRenditionsTable);

        $connection->delete($table, $connection->quoteInto('seller_id = ?', $objectId));

        $rowsToInsert = [];
        foreach ($renditionsData as $renditionData) {
            $renditionData['seller_id'] = $objectId;
            $rowsToInsert[] = $renditionData;
        }
        $connection->insertMultiple($table, $rowsToInsert);
        return $this;
    }

    /**
     * @param SellerModel $object
     *
     * @return array
     */
    public function loadLogoRenditions($object)
    {
        $objectId = $object->getId();
        if ($objectId) {
            $connection = $this->getConnection();
            $table = $this->getTable($this->logoRenditionsTable);

            $select = $connection->select();
            $select->from($table)
                ->where('seller_id = ?', $objectId);

            $rawRows = $connection->fetchAll($select);
            $rows = [];
            foreach ($rawRows as $rawRow) {
                unset($rawRow['seller_id']);
                $rows[] = $rawRow;
            }
            return $rows;
        }
        return [];
    }


    /**
     * @param SellerModel[] $objects
     *
     * @return array
     */
    public function loadLogoRenditionsForObjects($objects)
    {
        $renditionsById = [];
        $indexedObjects = [];
        foreach ($objects as $object) {
            if ($object->getId()) {
                $indexedObjects[$object->getId()] = $object;
                $renditionsById[$object->getId()] = [];
            }
        }
        if (!$indexedObjects) {
            return [];
        }

        $connection = $this->getConnection();
        $table = $this->getTable($this->logoRenditionsTable);

        $select = $connection->select();
        $select->from($table)
            ->where('seller_id in (?)', array_keys($indexedObjects));

        $rawRows = $connection->fetchAll($select);
        foreach ($rawRows as $rawRow) {
            $sellerId = $rawRow['seller_id'];
            unset($rawRow['seller_id']);
            $renditionsById[$sellerId][] = $rawRow;
        }
        return $renditionsById;
    }

    /**
     * Get Sellers
     *
     * @return array
     */
    public function getSellers()
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable('maas_seller_entity'),
            ['entity_id', 'maas_entity_id']
        );
        $rows = $this->getConnection()->fetchAll($select);
        $result = [];
        foreach ($rows as $row) {
            $result['maas_' . $row['maas_entity_id']] = [
                'entity_id' => $row['entity_id']
            ];
        }
        return $result;
    }

    protected function _construct()
    {
        $this->setType(SellerModel::ENTITY);
    }

    /**
     * @param DataObject $object
     *
     * @return Seller
     * @throws LocalizedException
     */
    protected function _beforeSave(DataObject $object)
    {
        /** @var $object SellerModel */
        if (!$object->getData('attribute_set_id')) {
            $object->setData('attribute_set_id', $this->getEntityType()->getDefaultAttributeSetId());
        }
        $object->setCustomAttributeCodes($this->getCustomAttributeCodes());

        return parent::_beforeSave($object);
    }

    /**
     * @return string[]
     */
    public function getCustomAttributeCodes()
    {
        if (is_null($this->customAttributeCodes)) {
            $this->loadAllAttributes();
            $attributes = $this->getAttributesByCode();
            $this->customAttributeCodes = [];
            foreach ($attributes as $attribute) {
                if ($attribute->getBackendType() != 'static') {
                    $this->customAttributeCodes[] = $attribute->getAttributeCode();
                }
            }
        }
        return $this->customAttributeCodes;
    }

    /**
     * @param DataObject $object
     *
     * @return $this
     */
    protected function _afterLoad(DataObject $object)
    {
        parent::_afterLoad($object);
        $object->setCustomAttributeCodes($this->getCustomAttributeCodes());
        return $this;
    }
}
