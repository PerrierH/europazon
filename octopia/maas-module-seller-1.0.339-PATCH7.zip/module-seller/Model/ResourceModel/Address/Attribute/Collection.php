<?php

namespace Maas\Seller\Model\ResourceModel\Address\Attribute;

use Magento\Eav\Model\ResourceModel\Attribute\Collection as AttributeCollection;

/**
 * Class Collection
 *
 * @package Maas\Seller\Model\ResourceModel\Address\Attribute
 * @codeCoverageIgnore Delegates to standard
 */
class Collection extends AttributeCollection
{
    /**
     * Default attribute entity type code
     *
     * @var string
     */
    protected $_entityTypeCode = 'maas_seller_address';

    /**
     * @inheritDoc
     */
    protected function _getEntityTypeCode()
    {
        return $this->_entityTypeCode;
    }

    /**
     * @inheritDoc
     */
    protected function _getEavWebsiteTable()
    {
        return $this->getTable('maas_seller_address_eav_attribute_website');
    }
}