<?php

namespace Maas\Seller\Model\ResourceModel\Seller;

use Magento\Eav\Model\ResourceModel\Attribute as EavAttributeResource;

/**
 * Class Attribute
 *
 * @package Maas\Seller\Model\ResourceModel\Seller
 * @codeCoverageIgnore Delegates to standard
 */
class Attribute extends EavAttributeResource
{
    /**
     * @return string|null
     */
    protected function _getEavWebsiteTable()
    {
        return $this->getTable('maas_seller_eav_attribute_website');
    }

    /**
     * @return string|null
     */
    protected function _getFormAttributeTable()
    {
        return $this->getTable('maas_seller_form_attribute');
    }
}

