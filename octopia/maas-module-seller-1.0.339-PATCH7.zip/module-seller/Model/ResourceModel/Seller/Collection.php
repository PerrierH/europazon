<?php

namespace Maas\Seller\Model\ResourceModel\Seller;

use Maas\Seller\Model\ResourceModel\Seller;
use Magento\Eav\Model\Entity\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Seller\Model\ResourceModel\Seller
 * @codeCoverageIgnore No logic/delegates to standard
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';

    /**
     * @var string
     */
    protected $_eventPrefix = 'maas_seller_collection';

    /**
     * @var string
     */
    protected $_eventObject = 'seller_collection';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Maas\Seller\Model\Seller::class, Seller::class);
    }

    /**
     * After load method
     *
     * @return $this
     * @codeCoverageIgnore
     */
    protected function _afterLoad()
    {
        // EAV collections do not seem to dispatch this
        $this->_eventManager->dispatch($this->_eventPrefix.'_load_after', [
            $this->_eventObject => $this
        ]);
        return parent::_afterLoad();
    }
}

