<?php

namespace Maas\Seller\Model\ResourceModel;

use Maas\Seller\Model\Address as AddressModel;
use Magento\Eav\Model\Entity\AbstractEntity;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Address
 *
 * @package Maas\Seller\Model\ResourceModel
 * @codeCoverageIgnore
 */
class Address extends AbstractEntity
{
    /**
     * @var string[]|null
     */
    protected $customAttributeCodes = null;

    protected function _construct()
    {
        $this->setType(AddressModel::ENTITY);
    }

    /**
     * @param DataObject $object
     *
     * @return Address
     * @throws LocalizedException
     */
    protected function _beforeSave(DataObject $object)
    {
        /** @var $object AddressModel */
        if (!$object->getData('attribute_set_id')) {
            $object->setData('attribute_set_id', $this->getEntityType()->getDefaultAttributeSetId());
        }
        $object->setCustomAttributeCodes($this->getCustomAttributeCodes());
        return parent::_beforeSave($object);
    }

    /**
     * @param DataObject $object
     *
     * @return $this
     */
    protected function _afterLoad(DataObject $object)
    {
        parent::_afterLoad($object);
        $object->setCustomAttributeCodes($this->getCustomAttributeCodes());
        return $this;
    }

    /**
     * @return string[]
     */
    public function getCustomAttributeCodes()
    {
        if (is_null($this->customAttributeCodes)) {
            $this->loadAllAttributes();
            $attributes = $this->getAttributesByCode();
            $this->customAttributeCodes = [];
            foreach ($attributes as $attribute) {
                if ($attribute->getBackendType() != 'static') {
                    $this->customAttributeCodes[] = $attribute->getAttributeCode();
                }
            }
        }
        return $this->customAttributeCodes;
    }
}
