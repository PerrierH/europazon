<?php

namespace Maas\Seller\Model\Seller;

use Maas\Seller\Api\Data\SellerShopLogoRenditionInterface;
use Magento\Framework\DataObject;

/**
 * Class ShopLogoRendition
 *
 * @package Maas\Seller\Model\Seller
 * @codeCoverageIgnore No logic
 */
class ShopLogoRendition extends DataObject implements SellerShopLogoRenditionInterface
{
    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * @inheritDoc
     */
    public function getPath()
    {
        return $this->getData(self::PATH);
    }

    /**
     * @inheritDoc
     */
    public function setPath($path)
    {
        return $this->setData(self::PATH, $path);
    }

    /**
     * @inheritDoc
     */
    public function getWidth()
    {
        return $this->getData(self::WIDTH);
    }

    /**
     * @inheritDoc
     */
    public function setWidth($width)
    {
        return $this->setData(self::WIDTH, $width);
    }

    /**
     * @inheritDoc
     */
    public function getHeight()
    {
        return $this->getData(self::HEIGHT);
    }

    /**
     * @inheritDoc
     */
    public function setHeight($height)
    {
        return $this->setData(self::HEIGHT, $height);
    }
}