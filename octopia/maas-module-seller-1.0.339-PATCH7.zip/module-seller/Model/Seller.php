<?php

namespace Maas\Seller\Model;

use Maas\Seller\Api\Data\SellerInterface;
use Maas\Seller\Model\ResourceModel\Seller as SellerResource;
use Maas\Seller\Model\Seller\ShopLogoRendition;
use Magento\Framework\Model\AbstractExtensibleModel;

/**
 * Class Seller
 *
 * @package Maas\Seller\Model
 * @codeCoverageIgnore No logic
 */
class Seller extends AbstractExtensibleModel implements SellerInterface
{
    const ENTITY = 'maas_seller';

    /**
     * @var string
     */
    protected $_eventPrefix = 'maas_seller';

    /**
     * @var string
     */
    protected $_eventObject = 'seller';

    /**
     * @var string[]
     */
    protected $customAttributeCodes = [];

    /**
     * @var ShopLogoRendition[]
     */
    protected $shopLogoRenditions = [];

    /**
     * @var Address[]
     */
    protected $addresses = [];

        /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->_getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * @inheritDoc
     */
    public function getMaasEntityId()
    {
        return $this->_getData(self::MAAS_ENTITY_ID);
    }

    /**
     * @inheritDoc
     */
    public function setMaasEntityId($id)
    {
        return $this->setData(self::MAAS_ENTITY_ID, $id);
    }

    /**
     * @inheritDoc
     */
    public function getSyncDate()
    {
        return $this->_getData(self::SYNC_DATE);
    }

    /**
     * @inheritDoc
     */
    public function setSyncDate($syncDate)
    {
        return $this->setData(self::SYNC_DATE, $syncDate);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedAt()
    {
        return $this->_getData(self::CREATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedAt()
    {
        return $this->_getData(self::UPDATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * @param array|string[] $attributeCodes
     *
     * @return $this
     */
    public function setCustomAttributeCodes(array $attributeCodes)
    {
        $this->customAttributeCodes = $attributeCodes;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getShopLogoRenditions()
    {
        return $this->shopLogoRenditions;
    }

    /**
     * @inheritDoc
     */
    public function setShopLogoRenditions($renditions)
    {
        $this->shopLogoRenditions = $renditions;
        $this->setDataChanges(true);
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getShopLogo()
    {
        return $this->_getData(self::SHOP_LOGO);
    }

    /**
     * @inheritDoc
     */
    public function setShopLogo($shopLogo)
    {
        return $this->setData(self::SHOP_LOGO, $shopLogo);
    }

    /**
     * @inheritDoc
     */
    public function getShopLogoPosition()
    {
        return $this->_getData(self::SHOP_LOGO_POSITION);
    }

    /**
     * @inheritDoc
     */
    public function setShopLogoPosition($shopLogoPosition)
    {
        return $this->setData(self::SHOP_LOGO_POSITION, $shopLogoPosition);
    }

    protected function _construct()
    {
        $this->_init(SellerResource::class);
    }

    /**
     * @return array|string[]
     */
    protected function getCustomAttributesCodes()
    {
        return $this->customAttributeCodes;
    }

    /**
     * @inheritDoc
     */
    public function getAddresses()
    {
        return $this->addresses;
    }

    /**
     * @inheritDoc
     */
    public function setAddresses($addresses)
    {
        $this->addresses = $addresses;
        return $this;
    }

    /**
     * @param string $type
     * @return Address|null
     */
    public function getAddressByType(string $type = Address::ADDRESS_TYPE_HEADOFFICE){
        foreach ($this->addresses as $address){
            if($address->getType() == $type){
                return $address;
            }
        }
        return null;
    }
}
