<?php

namespace Maas\Seller\Model;

use Maas\Core\Model\AbstractRepository;
use Maas\Seller\Api\Data\AddressInterface;
use Maas\Seller\Api\Data\AddressSearchResultsInterfaceFactory;
use Maas\Seller\Api\AddressRepositoryInterface;
use Maas\Seller\Model\ResourceModel\Address as AddressResource;
use Maas\Seller\Model\ResourceModel\Address\CollectionFactory as AddressCollectionFactory;
use Maas\Seller\Model\AddressFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

/**
 * Class AddressRepository
 *
 * @package Maas\Seller\Model
 * @codeCoverageIgnore Delegates to parent
 */
class AddressRepository extends AbstractRepository implements AddressRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(AddressInterface $address)
    {
        return $this->_save($address);
    }

    /**
     * @inheritDoc
     */
    public function delete(AddressInterface $address)
    {
        $this->_delete($address);
    }
}
