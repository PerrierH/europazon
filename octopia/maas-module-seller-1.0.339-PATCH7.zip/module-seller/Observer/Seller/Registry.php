<?php
namespace Maas\Seller\Observer\Seller;

use Maas\Seller\Model\Address;
use Maas\Seller\Model\Seller\ShopLogoRendition;

/**
 * Class Registry
 *
 * @package Maas\Seller\Observer\Seller
 * @codeCoverageIgnore No logic
 */
class Registry
{
    /**
     * @var ShopLogoRendition[]
     */
    protected $renditions;

    /**
     * @var Address[]
     */
    protected $addresses;

    /**
     * @var bool
     */
    protected $isSellerNew;

    /**
     * @param ShopLogoRendition[] $renditions
     *
     * @return $this
     */
    public function setRenditions($renditions)
    {
        $this->renditions = $renditions;
        return $this;
    }

    /**
     * @return ShopLogoRendition[]
     */
    public function getRenditions()
    {
        $currentRenditions = $this->renditions;
        $this->renditions = null;
        return $currentRenditions;
    }

    /**
     * @param Address[] $addresses
     *
     * @return $this
     */
    public function setAddresses($addresses)
    {
        $this->addresses = $addresses;
        return $this;
    }

    /**
     * @return Address[]
     */
    public function getAddresses()
    {
        $currentAddresses = $this->addresses;
        $this->addresses = null;
        return $currentAddresses;
    }

    /**
     * @param bool $isSellerNew
     *
     * @return $this
     */
    public function setIsSellerNew($isSellerNew)
    {
        $this->isSellerNew = $isSellerNew;
        return $this;
    }

    /**
     * @return bool
     */
    public function getIsSellerNew()
    {
        return $this->isSellerNew;
    }
}
