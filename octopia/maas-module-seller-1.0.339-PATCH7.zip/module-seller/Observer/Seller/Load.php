<?php

namespace Maas\Seller\Observer\Seller;

use Maas\Seller\Model\ResourceModel\Seller as SellerResource;
use Maas\Seller\Model\Seller;
use Maas\Seller\Model\Seller\ShopLogoRenditionFactory;
use Maas\Seller\Model\AddressRepository;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class Load
 *
 * @package Maas\Seller\Plugin\LogoRendition
 * @codeCoverageIgnore Database use, no logic
 */
class Load implements ObserverInterface
{
    /**
     * @var SellerResource
     */
    protected $sellerResource;

    /**
     * @var ShopLogoRenditionFactory
     */
    protected $renditionFactory;

    /** @var AddressRepository */
    protected $addressRepository;

    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * Load constructor.
     * @param SellerResource $sellerResource
     * @param ShopLogoRenditionFactory $renditionFactory
     * @param AddressRepository $addressRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     */
    public function __construct(
        SellerResource $sellerResource,
        ShopLogoRenditionFactory $renditionFactory,
        AddressRepository $addressRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder
    ) {
        $this->sellerResource = $sellerResource;
        $this->renditionFactory = $renditionFactory;
        $this->addressRepository = $addressRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Seller $seller */
        $seller = $observer->getEvent()->getData('seller');
        //LogoRenditions
        $data = $this->sellerResource->loadLogoRenditions($seller);
        $renditions = [];
        foreach ($data as $renditionData) {
            $rendition = $this->renditionFactory->create();
            $rendition->setData($renditionData);
            $renditions[] = $rendition;
        }
        $seller->setShopLogoRenditions($renditions);
        //Addresses
        $filter = $this->filterBuilder
            ->setField('seller_id')
            ->setConditionType('eq')
            ->setValue($seller->getId())
            ->create();
        $this->searchCriteriaBuilder->addFilters([$filter]);
        $searchCriteria = $this->searchCriteriaBuilder->create();
        $addresses = $this->addressRepository->getList($searchCriteria)->getItems();
        $seller->setAddresses($addresses);
    }
}