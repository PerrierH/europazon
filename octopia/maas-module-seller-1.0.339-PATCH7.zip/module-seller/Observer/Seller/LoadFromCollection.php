<?php

namespace Maas\Seller\Observer\Seller;

use Maas\Seller\Model\AddressRepository;
use Maas\Seller\Model\ResourceModel\Seller as SellerResource;
use Maas\Seller\Model\Seller\ShopLogoRenditionFactory;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;

/**
 * Class LoadFromCollection
 *
 * @package Maas\Seller\Observer\Seller
 * @codeCoverageIgnore Database use, no logic
 */
class LoadFromCollection implements ObserverInterface
{
    /**
     * @var SellerResource
     */
    protected $sellerResource;

    /**
     * @var ShopLogoRenditionFactory
     */
    protected $renditionFactory;


    /** @var AddressRepository */
    protected $addressRepository;

    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * LoadFromCollection constructor.
     * @param SellerResource $sellerResource
     * @param ShopLogoRenditionFactory $renditionFactory
     * @param AddressRepository $addressRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     */
    public function __construct(
        SellerResource $sellerResource,
        ShopLogoRenditionFactory $renditionFactory,
        AddressRepository $addressRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder
    )
    {
        $this->sellerResource = $sellerResource;
        $this->renditionFactory = $renditionFactory;
        $this->addressRepository = $addressRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var SellerResource\Collection $sellerCollection */
        $sellerCollection = $observer->getEvent()->getData('seller_collection');
        $renditionsForObjects = $this->sellerResource->loadLogoRenditionsForObjects($sellerCollection->getItems());
        foreach ($renditionsForObjects as $objectId => $renditionsData) {
            $renditions = [];
            foreach ($renditionsData as $renditionData) {
                $renditionData['seller_id'] = $objectId;
                $renditions[] = $this->renditionFactory->create()->setData($renditionData);
            }
            $sellerCollection->getItemById($objectId)->setShopLogoRenditions($renditions);
        }
        //Addresses
        foreach ($sellerCollection->getItems() as $seller) {
            $filter = $this->filterBuilder
                ->setField('seller_id')
                ->setConditionType('eq')
                ->setValue($seller->getId())
                ->create();
            $this->searchCriteriaBuilder->addFilters([$filter]);
            $searchCriteria = $this->searchCriteriaBuilder->create();
            $addresses = $this->addressRepository->getList($searchCriteria)->getItems();
            $seller->setAddresses($addresses);
        }
    }
}