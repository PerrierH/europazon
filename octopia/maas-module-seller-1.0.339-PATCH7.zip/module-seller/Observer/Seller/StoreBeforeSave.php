<?php
namespace Maas\Seller\Observer\Seller;

use Maas\Seller\Model\Seller;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class StoreBeforeSave
 *
 * @package Maas\Seller\Observer\Seller
 * @codeCoverageIgnore No logic
 */
class StoreBeforeSave implements ObserverInterface
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * StoreBeforeSave constructor.
     *
     * @param Registry $registry
     */
    public function __construct(Registry $registry)
    {
        $this->registry = $registry;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Seller $seller */
        $seller = $observer->getEvent()->getData('seller');
        $renditions = $seller->getShopLogoRenditions();
        $addresses = $seller->getAddresses();
        $this->registry->setRenditions(is_array($renditions) ? $renditions : [])
            ->setAddresses(is_array($addresses) ? $addresses : [])
            ->setIsSellerNew(!$seller->getId());
    }
}