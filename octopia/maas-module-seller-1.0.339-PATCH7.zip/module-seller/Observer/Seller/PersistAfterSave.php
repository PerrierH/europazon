<?php
namespace Maas\Seller\Observer\Seller;

use Maas\Seller\Model\Address;
use Maas\Seller\Model\Seller;
use Maas\Seller\Model\ResourceModel\Seller as SellerResource;
use Maas\Seller\Model\ResourceModel\Address as AddressResource;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Maas\Seller\Model\ResourceModel\Address\Collection as AddressCollection;
use Maas\Seller\Model\ResourceModel\Address\CollectionFactory as AddressCollectionFactory;

/**
 * Class PersistAfterSave
 *
 * @package Maas\Seller\Observer\Seller
 * @codeCoverageIgnore Database use, no logic
 */
class PersistAfterSave implements ObserverInterface
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var SellerResource
     */
    protected $sellerResource;

    /**
     * @var AddressResource
     */
    protected $addressResource;

    /**
     * @var AddressCollectionFactory
     */
    protected $addressCollectionFactory;

    /**
     * PersistAfterSave constructor.
     *
     * @param Registry $registry
     * @param SellerResource $sellerResource
     * @param AddressResource $addressResource
     * @param AddressCollectionFactory $addressCollectionFactory
     */
    public function __construct(
        Registry $registry,
        SellerResource $sellerResource,
        AddressResource $addressResource,
        AddressCollectionFactory $addressCollectionFactory
    )
    {
        $this->registry = $registry;
        $this->sellerResource = $sellerResource;
        $this->addressResource = $addressResource;
        $this->addressCollectionFactory = $addressCollectionFactory;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Seller $seller */
        $seller = $observer->getEvent()->getData('seller');
        $renditionsData = [];
        $renditions = $this->registry->getRenditions();
        foreach($renditions as $rendition)
        {
            $rendition->setSellerId($seller->getId());
            $renditionData = $rendition->getData();
            $renditionsData[] = $renditionData;
        }
        $this->sellerResource->saveLogoRenditions($seller, $renditionsData);
        $seller->setShopLogoRenditions($renditions);

        $addresses = $this->registry->getAddresses();
        $existingAddresses = $this->getExistingAddresses($seller);
        $addresses = $this->combineAddressesData($existingAddresses, $addresses);

        foreach($addresses as $address)
        {
            $address->setSellerId($seller->getId());
            $this->addressResource->save($address);
        }
        $seller->setAddresses($addresses);
    }

    /**
     * @param Seller $seller
     *
     * @return Address[]
     */
    private function getExistingAddresses($seller)
    {
        if(!$this->registry->getIsSellerNew())
        {
            /** @var AddressCollection $addressCollection */
            $addressCollection = $this->addressCollectionFactory->create();
            $addressCollection->addFieldToFilter('seller_id', $seller->getId());
            return $addressCollection->getItems();
        }
        return [];
    }

    /**
     * @param Address[] $existingData
     * @param Address[] $newData
     *
     * @return Address[]
     */
    private function combineAddressesData($existingData, $newData)
    {
        $combined = [];

        foreach ($existingData as $existingAddress)
        {
            if($existingAddress->getType())
            {
                $combined[$existingAddress->getType()] = $existingAddress;
            }
        }
        foreach ($newData as $newAddress)
        {
            $type = $newAddress->getType();
            if($type)
            {
                if(isset($combined[$type]))
                {
                    $combined[$type]->addData($newAddress->getData());
                }
                else
                {
                    $combined[$type] = $newAddress;
                }
            }
        }
        return $combined;
    }
}