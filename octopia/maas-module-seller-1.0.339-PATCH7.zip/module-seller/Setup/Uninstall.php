<?php

namespace Maas\Seller\Setup;

use Maas\Core\Setup\Eav\Data;
use Maas\Core\Setup\Eav\Schema;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;
use Maas\Seller\Setup\InstallSchema as SellerInstall;

/**
 * Class Uninstall
 *
 * @package Maas\Seller\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    /**
     * @var Schema
     */
    protected $eavSchema;

    /**
     * @var Data
     */
    protected $eavData;

    /**
     * Uninstall constructor.
     *
     * @param Schema $eavSchema
     * @param Data $eavData
     */
    public function __construct(
        Schema $eavSchema,
        Data $eavData
    ) {
        $this->eavSchema = $eavSchema;
        $this->eavData = $eavData;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->eavData->deleteData('maas_seller');

        /* Drop EAV Entity maas_seller */
        $this->eavSchema->deleteTables($setup, 'maas_seller', ['datetime', 'varchar', 'int', 'decimal', 'text'],
            'maas_seller_eav_attribute', 'maas_seller_eav_attribute_website');

        $this->eavData->deleteData('maas_seller_address');

        /* Drop EAV Entity maas_seller_address */
        $this->eavSchema->deleteTables($setup, 'maas_seller_address', ['datetime', 'varchar', 'int', 'decimal', 'text'],
            'maas_seller_address_eav_attribute', 'maas_seller_address_eav_attribute_website');

        $this->dropTableLogoRendition($setup);

        $setup->endSetup();

    }

    /**
     * @param SchemaSetupInterface $uninstaller
     */
    private function dropTableLogoRendition(SchemaSetupInterface $uninstaller)
    {
        $uninstaller->getConnection()->dropTable(SellerInstall::LOGO_RENDITION_TABLE);
    }
}
