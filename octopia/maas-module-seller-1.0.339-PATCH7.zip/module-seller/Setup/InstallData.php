<?php

namespace Maas\Seller\Setup;

use Maas\Core\Model\Service\Eav;
use Maas\Core\Setup\Eav\Data;
use Maas\Seller\Model\Seller\Attribute as SellerAttribute;
use Maas\Seller\Model\Address\Attribute as AddressAttribute;
use Maas\Seller\Model\ResourceModel\Seller;
use Maas\Seller\Model\ResourceModel\Address;
use Maas\Seller\Model\ResourceModel\Seller\Attribute\Collection as SellerCollection;
use Maas\Seller\Model\ResourceModel\Address\Attribute\Collection as AddressCollection;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Sales\Model\Order\StatusFactory;

/**
 * Class InstallData
 *
 * @package Maas\Seller\Setup
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    /**
     * @var Data
     */
    protected $eavData;

    /**
     * @var Eav
     */
    protected $eavService;

    /**
     * InstallData constructor.
     *
     * @param Data $eavData
     * @param Eav $eavService
     */
    public function __construct(
        Data $eavData,
        Eav $eavService
    ) {
        $this->eavData = $eavData;
        $this->eavService = $eavService;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $this->installSellerData($setup, $context);
        $this->installSellerAddressData($setup, $context);
        $setup->endSetup();
    }

    protected function installSellerData(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $entityTypeData = $this->eavData->createEntityType('maas_seller', [
            'entity_model' => Seller::class,
            'attribute_model' => SellerAttribute::class,
            'additional_attribute_table' => 'maas_seller_eav_attribute',
            'entity_attribute_collection' => SellerCollection::class
        ]);
        $this->eavService->updateEavEntitySetupCache('maas_seller', $entityTypeData);
        $this->eavService->addAttributesToDefaultSetAndGroup('maas_seller', [
            ['name', 'Name', 'static', ['required' => true]],
            ['maas_entity_id', 'MaaS Entity ID', 'static', ['required' => true]],
            ['shop_logo', 'Shop Logo', 'static', ['required' => false]],
            ['shop_logo_position', 'Shop Logo Position', 'static', ['required' => false]],
            ['sync_date', 'SyncDate', 'static', ['required' => false]],
            ['is_complete', 'Is Complete Entity', 'static', ['required' => false, 'default' => '0']],

            ['url', 'Store URL', 'varchar', []],
            ['company_registration_number', 'Company Registration Number', 'varchar', []],
            ['email', 'Email', 'varchar', []],
            ['sales_advices_email', 'Sales Advice Email', 'varchar', []],
            ['notifications_email', 'Notifications Email', 'varchar', []],
            ['state', 'State', 'varchar', []],
            ['substate', 'Sub-State', 'varchar', []],
            ['mobile', 'Mobile Number', 'varchar', []],
            ['shipping_country', 'Shipping Country', 'varchar', []],
            ['legal_company_name', 'Legal Company Name', 'varchar', []],
            ['legal_status', 'Legal Status', 'varchar', []],
            ['company_capital', 'Company Capital', 'varchar', []],
            ['intracom_vat', 'Intracom VAT', 'varchar', []],
            ['is_fulfillment', 'Is Fulfillment', 'int', []],
            ['legal_terms', 'Legal Terms', 'text', []]
        ]);
    }

    protected function installSellerAddressData(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $entityTypeData = $this->eavData->createEntityType('maas_seller_address', [
            'entity_model' => Address::class,
            'attribute_model' => AddressAttribute::class,
            'additional_attribute_table' => 'maas_seller_address_eav_attribute',
            'entity_attribute_collection' => AddressCollection::class
        ]);
        $this->eavService->updateEavEntitySetupCache('maas_seller_address', $entityTypeData);
        $this->eavService->addAttributesToDefaultSetAndGroup('maas_seller_address', [
            ['seller_id', 'Seller ID', 'static', ['required' => true]],
            ['type', 'Type', 'static', ['required' => true]],
            ['address1', 'Address 1', 'static', ['required' => true]],
            ['address2', 'Address 2', 'static', ['required' => true]],
            ['appartment', 'Appartment number', 'static', ['required' => true]],
            ['building', 'Building number', 'static', ['required' => true]],
            ['zipcode', 'ZIP code', 'static', ['required' => true]],
            ['city', 'City', 'static', ['required' => true]],
            ['county', 'County', 'static', ['required' => true]],
            ['country', 'Country', 'static', ['required' => true]],
            ['instructions', 'Instructions', 'static', ['required' => true]],
            ['sync_date', 'SyncDate', 'static', ['required' => false]]
        ]);
    }
}
