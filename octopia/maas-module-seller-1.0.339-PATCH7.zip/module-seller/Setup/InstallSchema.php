<?php

namespace Maas\Seller\Setup;

use Maas\Core\Setup\Eav\Schema;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Zend_Db_Exception;

/**
 * Class InstallSchema
 *
 * @package Maas\Seller\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    const LOGO_RENDITION_TABLE = 'maas_seller_logo_rendition';

    /**
     * @var Schema
     */
    protected $eavSchema;

    /**
     * InstallSchema constructor.
     *
     * @param Schema $eavSchema
     */
    public function __construct(
        Schema $eavSchema
    ) {
        $this->eavSchema = $eavSchema;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $this->installSellerTables($setup, $context);
        $this->installSellerAddressTables($setup, $context);

        $installer->endSetup();
    }


    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws Zend_Db_Exception
     */
    private function installSellerTables(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->installEntityTables($setup, $context, 'maas_seller', [
            ['name', Table::TYPE_TEXT, 255, ['nullable' => false], 'Name of the Seller'],
            ['maas_entity_id', Table::TYPE_TEXT, 25, ['nullable' => false], 'Maas Entity Id'],
            ['shop_logo', Table::TYPE_TEXT, 255, ['nullable' => true], 'Shop Logo'],
            ['shop_logo_position', Table::TYPE_INTEGER, null, ['nullable' => true], 'Shop Logo Position'],
            ['sync_date', Table::TYPE_DATETIME, 255, ['nullable' => true], 'Date of synchronisation'],
            ['is_complete', Table::TYPE_BOOLEAN, 255, ['nullable' => false, 'default' => 0], 'Is complete']
        ], [
            ['', ['maas_entity_id'], []]
        ], []);
    }


    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws Zend_Db_Exception
     */
    private function installSellerAddressTables(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->installEntityTables($setup, $context, 'maas_seller_address', [
            ['seller_id', Table::TYPE_INTEGER, null, ['nullable' => false, 'unsigned' => true], 'Seller Magento internal ID'],
            ['type', Table::TYPE_TEXT, 16, ['nullable' => false], 'Address type'],
            ['address1', Table::TYPE_TEXT, 255, ['nullable' => true], 'Address Line 1'],
            ['address2', Table::TYPE_TEXT, 255, ['nullable' => false], 'Address Line 2'],
            ['appartment', Table::TYPE_TEXT, 32, ['nullable' => true], 'Appartment number'],
            ['building', Table::TYPE_TEXT, 32, ['nullable' => true], 'Building number'],
            ['zipcode', Table::TYPE_TEXT, 32, ['nullable' => false], 'ZIP Code'],
            ['city', Table::TYPE_TEXT, 255, ['nullable' => false], 'City'],
            ['county', Table::TYPE_TEXT, 255, ['nullable' => false], 'County'],
            ['country', Table::TYPE_TEXT, 255, ['nullable' => false], 'Country'],
            ['instructions', Table::TYPE_TEXT, 255, ['nullable' => false], 'Country'],
            ['sync_date', Table::TYPE_DATETIME, 255, ['nullable' => true], 'Date of synchronisation'],
        ], [
            ['', ['seller_id'], []], [AdapterInterface::INDEX_TYPE_UNIQUE, ['seller_id', 'type'], []]
        ], [
            ['seller_id', 'maas_seller_entity', 'entity_id', Table::ACTION_CASCADE]
        ]);
    }
    
    private function installEntityTables(SchemaSetupInterface $setup, ModuleContextInterface $context, $entityCode, $staticColumns, $staticIndexes, $staticForeignKeys)
    {
        $propertiesTableName = $entityCode.'_eav_attribute';
        $propertiesTableCols = [
            ['is_imported', Table::TYPE_BOOLEAN, null, ['default' => true, 'nullable' => false], 'Is imported']
        ];
        $propertiesIndexes = [
            ['', ['is_imported'], []]
        ];

        $propertiesScopeTableName = $entityCode.'_eav_attribute_website';
        $propertiesScopeTableCols = [];
        $propertiesScopeTableIndexes = [];
        $entityNameInComment = 'Seller';

        $this->eavSchema->createEntityTable($setup, $entityCode, $staticColumns, $staticIndexes, $staticForeignKeys,
            $entityNameInComment);

        $this->eavSchema->createPropertiesTable($setup, $propertiesTableName, $propertiesTableCols, $propertiesIndexes,
            $entityNameInComment);

        $this->eavSchema->createPropertiesScopeTable($setup, $propertiesScopeTableName, $propertiesScopeTableCols,
            $propertiesScopeTableIndexes, $entityNameInComment);


        $attributeTypes = [
            'datetime' => [Table::TYPE_DATETIME, null, []],
            'varchar' => [Table::TYPE_TEXT, 255, []],
            'int' => [Table::TYPE_INTEGER, null, []],
            'decimal' => [Table::TYPE_DECIMAL, '12,4', []],
            'text' => [Table::TYPE_TEXT, '64k', []]
        ];

        $this->eavSchema->createAttributeTables($setup, $entityCode, $attributeTypes, $entityNameInComment);
        $this->eavSchema->createFormTable($setup, $entityCode, $entityNameInComment);

        $this->createSellerLogoRenditionTable($setup);
    }

    /**
     * @param SchemaSetupInterface $setup
     *
     * @throws Zend_Db_Exception
     */
    private function createSellerLogoRenditionTable(SchemaSetupInterface $setup)
    {
        $connection = $setup->getConnection();

        $offerTable = $connection->newTable(
            $setup->getTable(self::LOGO_RENDITION_TABLE)
        )->addColumn(
            'seller_id',
            Table::TYPE_INTEGER,
            null,
            ['unsigned' => true, 'nullable' => false],
            'Seller Id'
        )->addColumn(
            'name',
            Table::TYPE_TEXT,
            64,
            ['nullable' => false],
            'Rendition name'
        )->addColumn(
            'path',
            Table::TYPE_TEXT,
            2048,
            ['nullable' => false],
            'Rendition Image Path'
        )->addColumn(
            'width',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Width'
        )->addColumn(
            'height',
            Table::TYPE_INTEGER,
            null,
            ['nullable' => false],
            'Height'
        )->addIndex(
            $connection->getIndexName(
                $setup->getTable(self::LOGO_RENDITION_TABLE),
                ['seller_id', 'name'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['seller_id', 'name'],
            ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
        )->addForeignKey(
            $connection->getForeignKeyName(
                $setup->getTable(self::LOGO_RENDITION_TABLE),
                'seller_id',
                $connection->getTableName('maas_seller_entity'),
                'entity_id'
            ),
            'seller_id',
            $connection->getTableName('maas_seller_entity'),
            'entity_id',
            Table::ACTION_CASCADE
        )->setComment('Seller Entity Logo Renditions Table');

        $connection->createTable($offerTable);
    }
}
