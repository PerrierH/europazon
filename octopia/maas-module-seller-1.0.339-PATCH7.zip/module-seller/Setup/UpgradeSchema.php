<?php

namespace Maas\Seller\Setup;

use Maas\Sales\Setup\AbstractInstaller;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;


class UpgradeSchema extends AbstractInstaller implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $setup->getConnection()->dropIndex(
                $setup->getTable('maas_seller_entity'),
                $setup->getConnection()->getIndexName(
                    $setup->getTable('maas_seller_entity'),
                    'maas_entity_id',
                    AdapterInterface::INDEX_TYPE_INDEX
                )
            );
            $setup->getConnection()->addIndex(
                $setup->getTable('maas_seller_entity'),
                $setup->getConnection()->getIndexName(
                    $setup->getTable('maas_seller_entity'),
                    'maas_entity_id',
                    AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['maas_entity_id'],
                AdapterInterface::INDEX_TYPE_UNIQUE
            );
        }

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            $setup->getConnection()->dropColumn(
                $setup->getTable('maas_seller_entity'), 'is_complete');
        }

        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            //clean table
            $setup->getConnection()->query(sprintf("DELETE FROM %s", $setup->getTable('maas_seller_address_entity')));

            // change length column
            $setup->getConnection()->changeColumn(
                $setup->getTable('maas_seller_address_entity'),
                'type',
                'type',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => false,
                    'length' => 128,
                    'comment' => 'Address type',
                ]
            );
        }

        $setup->endSetup();
    }

}
