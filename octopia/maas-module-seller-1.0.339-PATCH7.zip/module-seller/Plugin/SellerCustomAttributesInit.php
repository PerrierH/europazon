<?php

namespace Maas\Seller\Plugin;

use Maas\Seller\Model\Seller as SellerModel;
use Maas\Seller\Model\ResourceModel\Seller as SellerResource;

/**
 * Class SellerCustomAttributesInit
 *
 * Plugin used to avoid overriding a constructor
 *
 * @package Maas\Seller\Plugin
 * @codeCoverageIgnore Delegates all logic to ResourceModel
 */
class SellerCustomAttributesInit
{
    /**
     * @var SellerResource 
     */
    protected $sellerResource;

    /**
     * SellerCustomAttributesInit constructor.
     *
     * @param SellerResource $sellerResource
     */
    public function __construct(
        SellerResource $sellerResource
    )
    {
        $this->sellerResource = $sellerResource;
    }

    /**
     * @param SellerModel $subject
     *
     * @return array
     */
    public function beforeGetCustomAttributes(SellerModel $subject)
    {
        $subject->setCustomAttributeCodes($this->sellerResource->getCustomAttributeCodes());
        return [];
    }

    /**
     * @param SellerModel $subject
     * @param string $attributeCode
     *
     * @return array
     */
    public function beforeGetCustomAttribute(SellerModel $subject, $attributeCode)
    {
        $subject->setCustomAttributeCodes($this->sellerResource->getCustomAttributeCodes());
        return [$attributeCode];
    }

    /**
     * @param SellerModel $subject
     * @param array $attributes
     *
     * @return array
     */
    public function beforeSetCustomAttributes(SellerModel $subject, $attributes)
    {
        $subject->setCustomAttributeCodes($this->sellerResource->getCustomAttributeCodes());
        return [$attributes];
    }

    /**
     * @param SellerModel $subject
     * @param string $attributeCode
     * @param mixed $attributeValue
     *
     * @return array
     */
    public function beforeSetCustomAttribute(SellerModel $subject, $attributeCode, $attributeValue)
    {
        $subject->setCustomAttributeCodes($this->sellerResource->getCustomAttributeCodes());
        return [$attributeCode, $attributeValue];
    }
}