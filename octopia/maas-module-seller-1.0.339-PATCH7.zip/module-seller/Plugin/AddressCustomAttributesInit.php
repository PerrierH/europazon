<?php

namespace Maas\Seller\Plugin;

use Maas\Seller\Model\Address as AddressModel;
use Maas\Seller\Model\ResourceModel\Address as AddressResource;

/**
 * Class AddressCustomAttributesInit
 *
 * Plugin used to avoid overriding a constructor
 *
 * @package Maas\Seller\Plugin
 * @codeCoverageIgnore Delegates all logic to ResourceModel
 */
class AddressCustomAttributesInit
{
    /**
     * @var AddressResource 
     */
    protected $addressResource;

    /**
     * SellerCustomAttributesInit constructor.
     *
     * @param AddressResource $addressResource
     */
    public function __construct(
        AddressResource $addressResource
    )
    {
        $this->addressResource = $addressResource;
    }

    /**
     * @param AddressModel $subject
     *
     * @return array
     */
    public function beforeGetCustomAttributes(AddressModel $subject)
    {
        $subject->setCustomAttributeCodes($this->addressResource->getCustomAttributeCodes());
        return [];
    }

    /**
     * @param AddressModel $subject
     * @param string $attributeCode
     *
     * @return array
     */
    public function beforeGetCustomAttribute(AddressModel $subject, $attributeCode)
    {
        $subject->setCustomAttributeCodes($this->addressResource->getCustomAttributeCodes());
        return [$attributeCode];
    }

    /**
     * @param AddressModel $subject
     * @param array $attributes
     *
     * @return array
     */
    public function beforeSetCustomAttributes(AddressModel $subject, $attributes)
    {
        $subject->setCustomAttributeCodes($this->addressResource->getCustomAttributeCodes());
        return [$attributes];
    }

    /**
     * @param AddressModel $subject
     * @param string $attributeCode
     * @param mixed $attributeValue
     *
     * @return array
     */
    public function beforeSetCustomAttribute(AddressModel $subject, $attributeCode, $attributeValue)
    {
        $subject->setCustomAttributeCodes($this->addressResource->getCustomAttributeCodes());
        return [$attributeCode, $attributeValue];
    }
}