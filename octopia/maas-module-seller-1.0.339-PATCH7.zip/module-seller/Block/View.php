<?php

namespace Maas\Seller\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\ProductRepository;
use Maas\Seller\Model\SellerRepository;
use Maas\Seller\Model\Seller;
use Maas\Seller\Model\AddressRepository;
use Maas\Seller\Model\Address;
use Magento\Framework\UrlInterface;


/**
 * Class View
 * @package Maas\Seller\Block
 * @codeCoverageIgnore
 */
class View extends Template
{
    /** @var ProductRepository */
    public $productRepository;

    /** @var SellerRepository */
    public $sellerRepository;

    /** @var AddressRepository */
    public $addressRepository;

    /** @var Seller */
    public $seller;

    /**
     * View constructor.
     * @param Context $context
     * @param ProductRepository $productRepository
     * @param SellerRepository $sellerRepository
     * @param AddressRepository $addressRepository
     */
    public function __construct(
        Context $context,
        ProductRepository $productRepository,
        SellerRepository $sellerRepository,
        AddressRepository $addressRepository
    )
    {
        $this->productRepository = $productRepository;
        $this->sellerRepository = $sellerRepository;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $breadcrumbs = $this->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home', array(
            'label' => __('Home'),
            'title' => __('Home Page'),
            'link' => $this->getBaseUrl()
        ));

        if (array_key_exists('product', $this->getRequest()->getParams())) {
            $productId = $this->getRequest()->getParam('product');
            $product = $this->productRepository->getById($productId);
            $breadcrumbs->addCrumb('product', array(
                'label' => $product->getName(),
                'title' => $product->getName(),
                'link' => $product->getProductUrl()
            ));
        }

        $breadcrumbs->addCrumb('seller', array(
            'label' => __('Seller'),
            'title' => __('Seller')
        ));

        $this->pageConfig->getTitle()->set(__('Seller') . ' ' . $this->getSeller()->getName());

        return parent::_prepareLayout();
    }

    /**
     * @return Seller
     */
    public function getSeller()
    {
        if ($this->seller === null) {
            $this->seller = $this->sellerRepository->get($this->getRequest()->getParam('id'));
        }
        return $this->seller;
    }

    /**
     * @return string
     */
    public function getSellerLocation()
    {
        /** @var Address $address */
        $address = $this->seller->getAddressByType(Address::ADDRESS_TYPE_HEADOFFICE);
        if ($address) {
            return $address->getCity() . ', ' . $address->getCountry();
        }

        return '';
    }

    /**
     * @param string $type
     * @return string
     */
    public function getSingleLineAddress($type){
        $address = $this->seller->getAddressByType(Address::ADDRESS_TYPE_HEADOFFICE);

        $str = '';
        if ($address) {
            $str .= $address->getAddress1() . ' ';
            $str .= $address->getAddress2() . ' ';
            $str .= $address->getZipCode() . ' ';
            $str .= $address->getCity() . ', ';
            $str .= $address->getCountry();
        }
        return $str;
    }

    /**
     * @return string
     */
    public function getShopLogoUrl(){
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]) . 'maas_seller' . $this->seller->getShopLogo();
    }

    /**
     * @return false|string
     */
    public function hasShopLogo()
    {
        return ($this->seller->getShopLogo() && file_exists(UrlInterface::URL_TYPE_MEDIA . '/' . 'maas_seller' . $this->seller->getShopLogo()));
    }
}
