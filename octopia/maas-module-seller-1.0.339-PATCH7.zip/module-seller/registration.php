<?php

use Magento\Framework\Component\ComponentRegistrar;

/**
 * @codeCoverageIgnore
 */
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Maas_Seller', __DIR__);
