<?php

namespace Maas\Seller\Api;

/**
 * Interface AddressAttributeRepositoryInterface
 *
 * @package Maas\Seller\Api
 */
interface AddressAttributeRepositoryInterface extends \Magento\Framework\Api\MetadataServiceInterface
{
    /**
     * Retrieve all attributes for entity type
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     *
     * @return \Maas\Seller\Api\Data\AddressAttributeSearchResultsInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Retrieve specific attribute
     *
     * @param string $attributeCode
     *
     * @return \Maas\Seller\Api\Data\AddressAttributeInterface
     */
    public function get($attributeCode);
}
