<?php

namespace Maas\Seller\Api;

use Maas\Seller\Api\Data\AddressInterface;
use Maas\Seller\Api\Data\AddressSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface AddressRepositoryInterface
 *
 * @package Maas\Seller\Api
 */
interface AddressRepositoryInterface
{
    /**
     * @param AddressInterface $seller
     *
     * @return AddressInterface
     */
    public function save(AddressInterface $seller);

    /**
     * @param int $id
     *
     * @return AddressInterface
     */
    public function get($id);

    /**
     * @param AddressInterface $seller
     */
    public function delete(AddressInterface $seller);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return AddressSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}