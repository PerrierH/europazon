<?php

namespace Maas\Seller\Api;

use Maas\Seller\Api\Data\SellerInterface;
use Maas\Seller\Api\Data\SellerSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface SellerRepositoryInterface
 *
 * @package Maas\Seller\Api
 */
interface SellerRepositoryInterface
{
    /**
     * @param SellerInterface $seller
     *
     * @return SellerInterface
     */
    public function save(SellerInterface $seller);

    /**
     * @param int $id
     *
     * @return SellerInterface
     */
    public function get($id);

    /**
     * @param SellerInterface $seller
     */
    public function delete(SellerInterface $seller);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return SellerSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}