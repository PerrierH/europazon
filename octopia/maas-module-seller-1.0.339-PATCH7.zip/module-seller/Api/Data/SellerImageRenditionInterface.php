<?php

namespace Maas\Seller\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface SellerImageRenditionInterface extends ExtensibleDataInterface
{

}