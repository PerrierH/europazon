<?php

namespace Maas\Seller\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface SellerImageInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface SellerImageInterface extends ExtensibleDataInterface
{
    const POSITION = 'position';

    const URL = 'url';

    const RENDITIONS = 'renditions';

    /**
     * @return int
     */
    public function getPosition();

    /**
     * @param int $position
     *
     * @return $this
     */
    public function setPosition($position);

    /**
     * @return string
     */
    public function getUrl();

    /**
     * @param string $url
     *
     * @return $this
     */
    public function setUrl($url);


    /**
     * @return SellerImageRenditionInterface[]
     */
    public function getRenditions();

    /**
     * @param SellerImageRenditionInterface[] $renditions
     *
     * @return mixed
     */
    public function setRenditions($renditions);
}