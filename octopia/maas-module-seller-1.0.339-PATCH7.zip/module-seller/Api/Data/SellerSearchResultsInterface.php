<?php

namespace Maas\Seller\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface SellerSearchResultsInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface SellerSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get sellers list.
     *
     * @return SellerInterface[]
     */
    public function getItems();

    /**
     * Set sellers list.
     *
     * @param SellerInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}