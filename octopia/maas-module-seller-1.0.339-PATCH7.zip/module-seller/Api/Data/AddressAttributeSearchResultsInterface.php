<?php

namespace Maas\Seller\Api\Data;

/**
 * Interface AddressAttributeSearchResultsInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface AddressAttributeSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{
    /**
     * Get attributes list.
     *
     * @return \Maas\Seller\Api\Data\AddressAttributeInterface[]
     */
    public function getItems();

    /**
     * Set attributes list.
     *
     * @param \Maas\Seller\Api\Data\AddressAttributeInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
