<?php

namespace Maas\Seller\Api\Data;

interface SellerShopLogoRenditionInterface
{
    const NAME = 'name';
    const PATH = 'path';
    const WIDTH = 'width';
    const HEIGHT = 'height';

    /**
     * @return int
     */
    public function getName();

    /**
     * @param int $name
     *
     * @return $this
     */
    public function setName($name);

    /**
     * @return string
     */
    public function getPath();

    /**
     * @param string $path
     *
     * @return $this
     */
    public function setPath($path);

    /**
     * @return int
     */
    public function getWidth();

    /**
     * @param int $width
     *
     * @return $this
     */
    public function setWidth($width);

    /**
     * @return int
     */
    public function getHeight();

    /**
     * @param int $height
     *
     * @return $this
     */
    public function setHeight($height);
}