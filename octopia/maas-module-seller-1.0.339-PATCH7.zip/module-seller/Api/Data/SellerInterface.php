<?php

namespace Maas\Seller\Api\Data;

use DateTime;
use Magento\Framework\Api\CustomAttributesDataInterface;

/**
 * Interface SellerInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface SellerInterface extends CustomAttributesDataInterface
{

    const NAME = 'name';
    const MAAS_ENTITY_ID = 'maas_entity_id';
    const SYNC_DATE = 'sync_date';
    const SHOP_LOGO = 'shop_logo';
    const SHOP_LOGO_POSITION = 'shop_logo_position';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const ADDRESSES = 'addresses';

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @return int|null
     */
    public function getMaasEntityId();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setMaasEntityId($id);

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setName($name);

    /**
     * @return Datetime|null
     */
    public function getSyncDate();

    /**
     * @param DateTime $syncDate
     *
     * @return $this
     */
    public function setSyncDate($syncDate);

    /**
     * @return string
     */
    public function getCreatedAt();

    /**
     * @param string $createdAt
     *
     * @return $this
     */
    public function setCreatedAt($createdAt);

    /**
     * @return string
     */
    public function getUpdatedAt();

    /**
     * @param string $updatedAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt);

    /**
     * @return string
     */
    public function getShopLogo();

    /**
     * @param string $shopLogo
     *
     * @return $this
     */
    public function setShopLogo($shopLogo);

    /**
     * @return int
     */
    public function getShopLogoPosition();

    /**
     * @param int $shopLogoPosition
     *
     * @return $this
     */
    public function setShopLogoPosition($shopLogoPosition);

    /**
     * @return SellerShopLogoRenditionInterface[]
     */
    public function getShopLogoRenditions();

    /**
     * @param SellerShopLogoRenditionInterface[] $renditions
     *
     * @return $this
     */
    public function setShopLogoRenditions($renditions);

    /**
     * @return AddressInterface[]
     */
    public function getAddresses();

    /**
     * @param AddressInterface[] $addresses
     *
     * @return $this
     */
    public function setAddresses($addresses);
}
