<?php

namespace Maas\Seller\Api\Data;

/**
 * Interface SellerAttributeSearchResultsInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface SellerAttributeSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{
    /**
     * Get attributes list.
     *
     * @return \Maas\Seller\Api\Data\SellerAttributeInterface[]
     */
    public function getItems();

    /**
     * Set attributes list.
     *
     * @param \Maas\Seller\Api\Data\SellerAttributeInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
