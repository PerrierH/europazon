<?php

namespace Maas\Seller\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface AddressSearchResultsInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface AddressSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get addresses list.
     *
     * @return AddressInterface[]
     */
    public function getItems();

    /**
     * Set addresses list.
     *
     * @param AddressInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}