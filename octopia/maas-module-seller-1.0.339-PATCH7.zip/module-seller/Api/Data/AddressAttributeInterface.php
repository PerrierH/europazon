<?php

namespace Maas\Seller\Api\Data;

/**
 * Interface AddressAttributeInterface
 *
 * @package Maas\Seller\Api\Data
 */
interface AddressAttributeInterface extends  \Magento\Eav\Api\Data\AttributeInterface
{
    const ENTITY_TYPE_CODE = 'maas_seller_address';
}
