<?php

namespace Maas\ImportExport\Console\Command\Export;

use Exception;
use Maas\Core\Model\Config\Proxy as ConfigProxy;
use Maas\ImportExport\Console\Command\AbstractOrderCommand;
use Maas\ImportExport\Model\Export\Order\Proxy as ExportOrder;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\App\State;

/**
 * Class Status
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command
 */
class Order extends AbstractOrderCommand
{
    /** @var ExportOrder */
    private $exportOrder;

    /**
     * Order constructor.
     *
     * @param ExportOrder $exportOrder
     * @param ConfigProxy $configModel
     */
    public function __construct(
        ExportOrder $exportOrder,
        ConfigProxy $configModel,
        State $state
    ) {
        parent::__construct($configModel,$state);
        $this->exportOrder = $exportOrder;
    }

    protected function configureCodeAndDescription()
    {
        $this->setName('maas:export:order');
        $this->setDescription('Export orders to Maas.');
    }

    protected function doExecute($args, $output)
    {
        try {
            $this->exportOrder->execute($args);
        } catch (AlreadyExistsException $alreadyExists) {
            $output->writeln('<error>' . $alreadyExists->getMessage() . '</error>');
        } catch (Exception $ex) {
            $output->writeln('<error>' . $ex->getMessage() . '</error>');
        }
    }
}
