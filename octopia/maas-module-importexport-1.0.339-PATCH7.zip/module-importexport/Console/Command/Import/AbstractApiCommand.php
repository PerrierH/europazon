<?php

namespace Maas\ImportExport\Console\Command\Import;

use Exception;
use Maas\Core\Console\Command\AbstractParallelEntityProcess;
use Maas\Core\Model\Parallelization\Parallelization;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\AbstractImportV3Adapter;
use Maas\ImportExport\Model\Config\Proxy as Config;
use Maas\ImportExport\Model\Service\MessageQueue\AbstractImportPublisher;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Logger\Logger;
use Maas\Log\Model\Report;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Shell;
use Magento\Framework\Stdlib\DateTime\DateTime as DateTime;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\App\CacheInterface;
use Symfony\Component\Console\Input\ArrayInput;
use Magento\Framework\Module\Dir;
use Maas\ImportExport\Model\Import\Catalog\Product;

/**
 * Command to back up code base and user data
 *
 * @package Maas\ImportExport\Console\Command\Import
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @codeCoverageIgnore
 * @codeCoverageIgnore
 *
 */
abstract class AbstractApiCommand extends AbstractParallelEntityProcess
{
    use Parallelization;

    const SEGMENT_SIZE = 1;
    const BATCH_SIZE = 1;
    /**
     * @var AbstractImportExportApi
     */
    protected $importModel;
    /**
     * @var AbstractImportPublisher
     */
    protected $importPublisher;
    /**
     * @var ErrorLogger
     */
    protected $errorLogger;
    /**
     * @var string
     */
    protected $newCsvModelIdColName = 'id';
    /**
     * @var string
     */
    protected $newCsvModelIdName = 'id';
    /**
     * @var string
     */
    protected $newCsvOperationLabel = 'Adding to publisher';
    /**
     * @var string
     */
    protected $configLimitMethod = 'getLimit';

    /**
     * @var AbstractApiCommand[]
     */
    protected $dependencies = [];
    /**
     * @var Report
     */
    private $report;

    /**
     * @var Dir
     */
    private $moduleDirectory;

    /**
     * @var int
     */
    private $limit;

    /**
     * @var int
     */
    private $remaining;

    /**
     * Shell command line wrapper for executing command in background
     */
    protected Shell $shellBackground;

    /**
     * AbstractApiCommand constructor.
     * @param Config $configModel
     * @param SerializerInterface $serializer
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param DateTime $dateTime
     * @param CacheInterface $cache
     * @param Shell $shellBackground
     * @param ErrorLogger $errorLogger
     * @param AbstractImportExportApi $importModel
     * @param AbstractImportPublisher $importPublisher
     * @param Dir $moduleDirectory
     * @param array $dependencies
     */
    public function __construct(
        Config $configModel,
        SerializerInterface $serializer,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        DateTime $dateTime,
        CacheInterface $cache,
        Shell $shellBackground,
        ErrorLogger $errorLogger,
        AbstractImportExportApi $importModel,
        AbstractImportPublisher $importPublisher,
        Dir $moduleDirectory,
        array $dependencies = []
    )
    {
        $this->importModel = $importModel;
        $this->importPublisher = $importPublisher;
        $this->errorLogger = $errorLogger;
        $this->moduleDirectory = $moduleDirectory;
        $this->dependencies = $dependencies;
        $this->shellBackground = $shellBackground;
        parent::__construct($serializer, $reportRepository, $reportManagement, $dateTime, $cache, $configModel);
    }

    /**
     * We don't need to test for this function
     * @codeCoverageIgnore
     * @return bool
     */
    protected function isModuleEnabled()
    {
        return $this->configModel->isModuleEnabled();
    }

    /**
     * @return string
     */
    private function getBackgroundConsumerCommand()
    {
        return sprintf('php bin/magento %s >/dev/null &', $this->consumerCommand);
    }

    /**
     * Run the consumer after every batch
     * @param InputInterface $input
     * @param OutputInterface $output
     * @param array $items
     * @throws LocalizedException
     */
    protected function runAfterBatch(
        InputInterface $input,
        OutputInterface $output,
        array $items
    ): void {
        $this->shellBackground->execute($this->getBackgroundConsumerCommand());
    }

    /**
     * @param $entityType
     */
    protected function resetPaginationCursor($entityType)
    {
        $this->cache->remove(sprintf(AbstractImportV3Adapter::CACHE_KEY_CURSOR, $entityType));
    }

    /**
     * @param ?int $scheduleId
     *
     * @return Report
     * @throws Exception
     */
    protected function startReport(?int $scheduleId = null) : ReportInterface
    {
        return $this->importModel->startProcess($this->getArgsScheduleId($scheduleId));
    }

    /**
     * @param $item
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function runSingleCommand($item, InputInterface $input, OutputInterface $output): void
    {
        $report = $this->getReport();
        $limit = $this->getLimit();
        try {
            if ($this->remaining <= 0) {
                throw new LocalizedException(__('There are no items to process'));
            }
            $limit = min($this->remaining, $this->getLimit());
            $args = ['limit' => $limit, 'page' => $item];
            $models = $this->importModel->getApiResponse($args);
            foreach ($models['items'] as $model) {
                if ($model !== null) {
                    $this->importPublisher->publish($model);
                }
            }
            if (count($models['items']) != $limit) {
                throw new LocalizedException(__('The number of elements retrieved is not correct'));
            }
            $this->importPublisher->publishRemaining();
        } catch (Exception $e) {
            $errorMessage = __("Error occurred detail: %1. See logs file for more details.", $e->getMessage());
            $errorLogMessage = __('Trace: %1', $e->getTraceAsString());
            if ($report->getId()) {
                $report->log(__('%1 %2(s) not imported error in page %3', $limit, $this->entityType, $item),false, Logger::ERROR);
                $report->log($errorMessage, false, Logger::ERROR);
                $report->setMessage($errorMessage);
                $report->setDeltaErrorItemsCount($limit);
                $this->reportRepository->save($report);
                if ($report->isJobOver()) {
                    $this->stopReport($report);
                    $this->remaining = 0;
                }
            }
            $this->errorLogger->error($errorMessage);
            $this->errorLogger->error($errorLogMessage);
            $output->writeln('<error>' . $errorMessage->__toString() . '</error>');
        }
        if ($report->getId()) {
            $this->reportRepository->save($report);
        }
        $this->remaining -= $limit;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return array
     * @throws Exception
     */
    protected function fetchItems(InputInterface $input, OutputInterface $output): array
    {
        $this->resetPaginationCursor($this->entityType);
        $report = $this->getReport();
        $this->remaining = $this->fetchTotalItemsCount();
        $report->setItemsCount($this->remaining);
        $report->log(__('%1 %2(s) to import', $this->remaining, $this->entityType));
        $this->reportRepository->save($report);
        if (!$this->remaining) {
            $this->stopReport($report);
            return [];
        }
        $this->importPublisher->setEntityType($this->entityType)->setReportId($report->getId());
        $pages = ceil($this->remaining / $this->getLimit());
        return range(1, $pages);
    }

    /**
     * @return int
     */
    protected function getLimit() : int
    {
        return $this->configModel->{$this->configLimitMethod}();
    }

    /**
     * @return int
     */
    protected function getProcessesNumber() : int
    {
        //There is no parallelization for the import because of th cursor pattern
        return 1;
    }

    /**
     * @param $output
     * @return void
     * @throws Exception
     */
    protected function importCategoryJson($output)
    {
        $directory = $this->moduleDirectory->getDir('Maas_DataSet') . '/data/categories';
        $arguments = new ArrayInput(['dir-path' => $directory]);
        $this->getApplication()->find('maas:dataset:import:categories')->run($arguments, $output);
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int
     * @throws LocalizedException
     * @throws Exception
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        if ($this->importModel->getMode()) {
            foreach ($this->dependencies as $dependency) {
                $state = $dependency->importModel->getFirstRunState();
                if ($state != AbstractImportExportApi::FIRST_RUN_STATE_RUN) {
                    $message = $this->importModel->getFirstRunErrorMessage($state, $input->getOption('scheduleId'));
                    $output->writeln('<info>' . $message . '</info>');
                    if ($state == AbstractImportExportApi::FIRST_RUN_STATE_NOT_RUN) {
                        if ((function_exists('str_contains') &&
                                str_contains($message, Product::DEPENDENCY_CATEGORY_MESSAGE_ERROR)) ||
                            (function_exists('strpos') &&
                                strpos($message, Product::DEPENDENCY_CATEGORY_MESSAGE_ERROR) !== false)
                        ) {
                            $this->importCategoryJson($output);
                            return 0;
                        }
                        return $dependency->execute($input, $output);
                    }
                    return 0;
                }
            }
            try {
                $this->initReport($input);
                //Return without stop
                return parent::execute($input, $output);
            } catch (\Magento\Framework\Exception\AlreadyExistsException $e) {
                //Nothing to do
                $output->writeln('<error>' . $e->getMessage() .'</error>');
            } catch (\Exception $e) {
                //IF there is an error
                $errorMessage = __("Error occurred detail: %1. See logs file for more details.", $e->getMessage());
                $errorLogMessage = __('Trace: %1', $e->getTraceAsString());
                $report = $this->getReport();
                if ($report->getId()) {
                    $report->log("Error occurred.", false, Logger::ERROR);
                    $report->log($errorMessage, false, Logger::ERROR);
                    $report->setMessage($errorMessage, false, Logger::ERROR);
                    $report->setStatus(Report::STATUS_FAILED);
                    $report->setErrorItemsCount($report->getItemsCount() - ($report->getSuccessItemsCount() + $report->getWarningItemsCount()));
                    $this->stopReport($report);
                }
                $this->errorLogger->error($errorMessage);
                $this->errorLogger->error($errorLogMessage);
                $output->writeln('<error>' . $errorMessage->__toString() . '</error>');
            }
            return 0;
        } else {
            $output->writeln('<info>API disabled.</info>');
        }
        return 0;
    }

    protected function getReportIdKey() : string
    {
        return $this->importModel->getReportIdKey();
    }

    protected function getStartedImportReportObject() : ?ReportInterface
    {
        return $this->importModel->getStartedImportReportObject();
    }

    /**
     * @return int
     */
    protected function fetchTotalItemsCount()
    {
        return $this->importModel->getTotalItemsCount();
    }
}
