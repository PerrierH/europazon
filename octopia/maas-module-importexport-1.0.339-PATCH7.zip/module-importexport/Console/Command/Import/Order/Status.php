<?php

namespace Maas\ImportExport\Console\Command\Import\Order;

use Maas\Core\Model\Config\Proxy as ConfigProxy;
use Maas\ImportExport\Console\Command\AbstractOrderCommand;
use Maas\ImportExport\Model\Import\Order\Status\Proxy as ImportOrderStatus;
use Magento\Framework\App\State;

/**
 * Class Status
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command
 */
class Status extends AbstractOrderCommand
{
    const ORDERID = 'orderId';

    /** @var ImportOrderStatus */
    private $importOrderStatus;

    /**
     * Status constructor.
     *
     * @param ImportOrderStatus $importOrderStatus
     * @param ConfigProxy $configModel
     */
    public function __construct(
        ImportOrderStatus $importOrderStatus,
        ConfigProxy       $configModel,
        State             $state
    )
    {
        parent::__construct($configModel, $state);
        $this->importOrderStatus = $importOrderStatus;
    }

    protected function configureCodeAndDescription()
    {
        $this->setName('maas:import:orderstatus');
        $this->setDescription('Import orders status from Maas.');
    }

    protected function doExecute($args, $output)
    {
        $this->importOrderStatus->execute($args);
    }
}
