<?php

namespace Maas\ImportExport\Console\Command\Import\Price;

use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Import\Price
 */
class Consumer extends AbstractConsumerCommand
{
    protected $commandName = 'maas:import:offer:price:consumer';
    protected $commandDescription = 'Consumes offers price messages already in queue';
    protected $referenceWorkerProcess = 'import_offer_price';
    protected $logAction = 'Import_Offers_Price';
    protected $logModuleName = 'Maas_ImportExport';

    /**
     * @return int
     */
    protected function getConsumerProcessNumber()
    {
        return $this->configModel->getOffersConsumerProcessNumber();
    }

    /**
     * @return int
     */
    protected function getEntitiesNumberPerMessage()
    {
        return $this->configModel->getOffersNumberPerMessage();
    }

    /**
     * @return int
     */
    protected function getEntitiesPageLimit()
    {
        return $this->configModel->getOffersLimit();
    }
}
