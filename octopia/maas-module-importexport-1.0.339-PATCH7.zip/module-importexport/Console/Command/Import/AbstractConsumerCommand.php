<?php

namespace Maas\ImportExport\Console\Command\Import;

use Maas\Core\Model\Parallelization\ProcessManager;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;
use Maas\Core\Model\Service\MessageQueue\Publisher;
use Maas\Log\Model\Report;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Process\Process;
use Symfony\Component\Console\Input\InputOption;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Framework\Data\Collection\AbstractDb;

/**
 * Class AbstractConsumerCommand
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command
 */
abstract class AbstractConsumerCommand extends Command
{
    protected $commandName = '';
    protected $commandDescription = '';
    protected $referenceWorkerProcess = '';
    protected $logAction = '';
    protected $logModuleName = '';

    /**
     * @var array
     */
    protected $modules;
    /**
     * @var ProcessManager
     */
    protected $processManager;

    /**
     * @var ConfigProxy
     */
    protected $configModel;

    /**
     * @var ReportCollectionFactory
     */
    private $reportCollectionFactory;

    /**
     * AbstractConsumerCommand constructor.
     * @param ModuleListProxy $moduleList
     * @param ConfigProxy $configModel
     * @param ProcessManager $processManager
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param null $name
     */
    public function __construct(
        ModuleListProxy $moduleList,
        ConfigProxy $configModel,
        ProcessManager $processManager,
        ReportCollectionFactory $reportCollectionFactory,
        $name = null
    ) {
        $this->configModel = $configModel;
        $this->processManager = $processManager;
        $this->modules = $moduleList->getAll();
        $this->reportCollectionFactory = $reportCollectionFactory;
        parent::__construct($name);
    }

    /**
     * @inheritDoc
     */
    protected function configure()
    {
        $this->setName($this->commandName)
            ->setDescription($this->commandDescription)
            ->addOption(
                'scheduleId',
                's',
                InputOption::VALUE_OPTIONAL,
                'The schedule id from cron',
                null
            );
        parent::configure();
    }


    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return int|void|null
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {

        if ($this->configModel->isModuleEnabled()) {
            $itemsCount = $this->getItemsCount($this->logModuleName, $this->logAction);
            if ($itemsCount) {
                $processes = [];
                $connectionMethod = $this->configModel->getMessageQueueConnectionMethod();
                $entNumPerMess = $this->getEntitiesNumberPerMessage();
                $consumerProcesses = $this->getConsumerProcessNumber();
                $maxMessages = $this->calculateMaxMessages($itemsCount, $consumerProcesses, $entNumPerMess);
                $messagesCount = ceil($itemsCount / $entNumPerMess);
                $cmd = 'queue:consumers:start';
                $mqSuffix = 'consumer';
                $limitOption = 'max-messages';

                if ($this->isModuleActive(Publisher::RCASONMQ_MODULE)) {
                    $cmd = 'ce_mq:consumers:start';
                    $mqSuffix = 'queue';
                    $limitOption = 'limit';
                    $consumerProcesses = $connectionMethod == 'db' ? 1 : $consumerProcesses;
                }
                //Added case if message count is less than consumerProcesses
                $consumerProcesses = min($consumerProcesses, (int)$messagesCount);
                $format = 'php bin/magento %s maas_importexport.' . $this->referenceWorkerProcess . '.%s.%s --%s=%d >/dev/null &';
                $consumedMessages = 0;
                /** Processus to execute queue consumers start command */
                for ($i = 1; $i <= $consumerProcesses; $i++) {
                    if ($i == $consumerProcesses) {
                        $maxMessages = $messagesCount - $consumedMessages;
                    }
                    if ($maxMessages > 0) {
                        $command = sprintf(
                            $format,
                            $cmd,
                            $connectionMethod,
                            $mqSuffix,
                            $limitOption,
                            $maxMessages
                        );
                        $consumedMessages += $maxMessages;
                        $processes[] = $this->newProcess($command);
                    }
                }
                $pollingInterval = 1000; // microseconds
                /** Run all processes */
                $this->processManager->runParallel($output, $processes, sizeof($processes), $pollingInterval);
            }
        }
    }

    /**
     * @param $module
     * @param $action
     *
     * @return int
     */
    protected function getItemsCount($module, $action)
    {
        $collection = $this->reportCollectionFactory->create();
        $itemsCount = 0;
        /** @var AbstractDb $collection */
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', Report::STATUS_STARTED)
            ->setPageSize(1);

        if ($collection->getSize()) {
            /** @var Report $report */
            $passedItemsCount = $collection->getFirstItem()->getSuccessItemsCount();
            $passedItemsCount += $collection->getFirstItem()->getWarningItemsCount();
            $passedItemsCount += $collection->getFirstItem()->getErrorItemsCount();
            $itemsCount = $collection->getFirstItem()->getItemsCount() - $passedItemsCount;
        }
        return $itemsCount;
    }

    /**
     * @return int
     */
    abstract protected function getEntitiesNumberPerMessage();

    /**
     * @return int
     */
    abstract protected function getConsumerProcessNumber();

    /**
     * @param int $count
     * @param int $numberProcess
     * @param int $entNumPerMess
     * @return false|float
     */
    private function calculateMaxMessages(int $count, int $numberProcess, int $entNumPerMess)
    {
        return ceil($count / ($numberProcess * $entNumPerMess));
    }

    /**
     * @param string $moduleName
     *
     * @return bool
     */
    private function isModuleActive($moduleName)
    {
        return isset($this->modules[$moduleName]);
    }

    /**
     * @param string $input
     *
     * @return Process
     */
    protected function newProcess(string $input)
    {
        return new Process($input);
    }

    /**
     * @return int
     */
    abstract protected function getEntitiesPageLimit();
}
