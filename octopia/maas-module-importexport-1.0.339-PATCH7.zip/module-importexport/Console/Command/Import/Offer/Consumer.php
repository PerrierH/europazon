<?php

namespace Maas\ImportExport\Console\Command\Import\Offer;

use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Import\Offer
 */
class Consumer extends AbstractConsumerCommand
{
    protected $commandName = 'maas:import:offer:consumer';
    protected $commandDescription = 'Consumes offers messages already in queue';
    protected $referenceWorkerProcess = 'import_offer';
    protected $logAction = 'Import_Offers';
    protected $logModuleName = 'Maas_ImportExport';

    /**
     * @return int
     */
    protected function getConsumerProcessNumber()
    {
        return $this->configModel->getOffersConsumerProcessNumber();
    }

    /**
     * @return int
     */
    protected function getEntitiesNumberPerMessage()
    {
        return $this->configModel->getOffersNumberPerMessage();
    }

    /**
     * @return int
     */
    protected function getEntitiesPageLimit()
    {
        return $this->configModel->getOffersLimit();
    }
}
