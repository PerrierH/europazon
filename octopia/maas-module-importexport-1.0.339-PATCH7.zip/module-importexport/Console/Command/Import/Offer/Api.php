<?php

namespace Maas\ImportExport\Console\Command\Import\Offer;

use Maas\ImportExport\Console\Command\Import\AbstractApiCommand;

/**
 * Command to backup code base and user data
 *
 * @package Maas\ImportExport\Console\Command\Import\Offer
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @codeCoverageIgnore
 */
class Api extends AbstractApiCommand
{
    const SEGMENT_SIZE = 1;
    const BATCH_SIZE = 1;
    protected $commandName = 'maas:import:offer';
    protected $consumerCommand = 'maas:import:offer:consumer';
    protected $commandDescription = 'Adds offers messages';
    protected $entityType = 'offer';

    /**
     * @var string
     */
    protected $newCsvModelIdColName = 'sku';

    /**
     * @var string
     */
    protected $newCsvModelIdName = 'productId';

    /**
     * @var string
     */
    protected $newCsvOperationLabel = 'Adding offer to publisher';

    /**
     * @var string
     */
    protected $configLimitMethod = 'getOffersLimit';

    /**
     * @var string
     */
    protected $configMaximumMethod = 'getMaximumOffersToImport';

    /**
     * @return int
     */
    protected function fetchTotalItemsCount()
    {
        $maxOffersToImport = $this->configModel->getMaximumOffersToImport();
        return $maxOffersToImport ?? parent::fetchTotalItemsCount();
    }

    /**
     * @return int
     */
    protected function getLimit() : int
    {
        $limit = $this->configModel->{$this->configLimitMethod}();
        $maximum = $this->configModel->{$this->configMaximumMethod}();
        return ($maximum && $maximum < $limit) ? $maximum : $limit;
    }
}
