<?php

namespace Maas\ImportExport\Console\Command\Import\Inventory;

use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Import\Inventory
 */
class Consumer extends AbstractConsumerCommand
{
    protected $commandName = 'maas:import:offer:inventory:consumer';
    protected $commandDescription = 'Consumes offers inventory messages already in queue';
    protected $referenceWorkerProcess = 'import_offer_inventory';
    protected $logAction = 'Import_Inventories';
    protected $logModuleName = 'Maas_ImportExport';

    /**
     * @return int
     */
    protected function getConsumerProcessNumber()
    {
        return $this->configModel->getOffersConsumerProcessNumber();
    }

    /**
     * @return int
     */
    protected function getEntitiesNumberPerMessage()
    {
        return $this->configModel->getOffersNumberPerMessage();
    }

    /**
     * @return int
     */
    protected function getEntitiesPageLimit()
    {
        return $this->configModel->getOffersLimit();
    }
}
