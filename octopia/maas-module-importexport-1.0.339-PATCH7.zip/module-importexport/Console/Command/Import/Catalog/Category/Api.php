<?php

namespace Maas\ImportExport\Console\Command\Import\Catalog\Category;

use Maas\ImportExport\Console\Command\Import\AbstractApiCommand;

/**
 * Command to backup code base and user data
 *
 * @package Maas\ImportExport\Console\Command\Import\Catalog\Api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @codeCoverageIgnore
 */
class Api extends AbstractApiCommand
{
    const SEGMENT_SIZE = 1;
    const BATCH_SIZE = 1;
    protected $commandName = 'maas:import:category';
    protected $consumerCommand = 'maas:import:category:consumer';
    protected $commandDescription = 'Adds categories messages';
    protected $entityType = 'catalog_category';

    /**
     * @var string
     */
    protected $newCsvModelIdColName = 'id';

    /**
     * @var string
     */
    protected $newCsvModelIdName = 'categoryId';

    /**
     * @var string
     */
    protected $newCsvOperationLabel = 'Adding category to publisher';

    /**
     * @var string
     */
    protected $configLimitMethod = 'getCategoriesLimit';

}
