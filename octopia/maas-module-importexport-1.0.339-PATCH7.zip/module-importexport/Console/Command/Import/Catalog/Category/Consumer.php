<?php

namespace Maas\ImportExport\Console\Command\Import\Catalog\Category;

use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Import\Catalog\Category
 */
class Consumer extends AbstractConsumerCommand
{
    protected $commandName = 'maas:import:category:consumer';
    protected $commandDescription = 'Consumes categories messages already in queue';
    protected $referenceWorkerProcess = 'import_catalog_category';
    protected $logAction = 'Import_Categories';
    protected $logModuleName = 'Maas_ImportExport';

    /**
     * @return int
     */
    protected function getConsumerProcessNumber()
    {
        return $this->configModel->getCategoriesConsumerProcessNumber();
    }

    /**
     * @return int
     */
    protected function getEntitiesNumberPerMessage()
    {
        return $this->configModel->getCategoriesNumberPerMessage();
    }

    /**
     * @return int
     */
    protected function getEntitiesPageLimit()
    {
        return $this->configModel->getCategoriesLimit();
    }
}
