<?php

namespace Maas\ImportExport\Console\Command\Import\Catalog\Product;

use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Import\Catalog
 */
class Consumer extends AbstractConsumerCommand
{
    protected $commandName = 'maas:import:product:consumer';
    protected $commandDescription = 'Consumes products messages already in queue';
    protected $referenceWorkerProcess = 'import_catalog_product';
    protected $logAction = 'Import_Products';
    protected $logModuleName = 'Maas_ImportExport';

    /**
     * @return int
     */
    protected function getConsumerProcessNumber()
    {
        return $this->configModel->getProductsConsumerProcessNumber();
    }

    /**
     * @return int
     */
    protected function getEntitiesNumberPerMessage()
    {
        return $this->configModel->getProductsNumberPerMessage();
    }

    /**
     * @return int
     */
    protected function getEntitiesPageLimit()
    {
        return $this->configModel->getProductsLimit();
    }
}
