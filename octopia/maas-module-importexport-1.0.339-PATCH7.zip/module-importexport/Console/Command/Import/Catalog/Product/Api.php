<?php

namespace Maas\ImportExport\Console\Command\Import\Catalog\Product;

use Maas\ImportExport\Console\Command\Import\AbstractApiCommand;

/**
 * Command to backup code base and user data
 *
 * @package Maas\ImportExport\Console\Command\Import\Catalog
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @codeCoverageIgnore
 */
class Api extends AbstractApiCommand
{
    const SEGMENT_SIZE = 1;
    const BATCH_SIZE = 1;
    protected $commandName = 'maas:import:product';
    protected $consumerCommand = 'maas:import:product:consumer';
    protected $commandDescription = 'Adds products messages';
    protected $entityType = 'catalog_product';

    /**
     * @var string
     */
    protected $newCsvModelIdColName = 'sku';

    /**
     * @var string
     */
    protected $newCsvModelIdName = 'productId';

    /**
     * @var string
     */
    protected $newCsvOperationLabel = 'Adding product to publisher';

    /**
     * @var string
     */
    protected $configLimitMethod = 'getProductsLimit';

    /**
     * @var string
     */
    protected $configMaximumMethod = 'getMaximumProductsToImport';

    /**
     * @return int
     */
    protected function fetchTotalItemsCount()
    {
        $maxProductsToImport = $this->configModel->getMaximumProductsToImport();
        return $maxProductsToImport ?? parent::fetchTotalItemsCount();
    }

    /**
     * @return int
     */
    protected function getLimit() : int
    {
        $limit = $this->configModel->{$this->configLimitMethod}();
        $maximum = $this->configModel->{$this->configMaximumMethod}();
        return ($maximum && $maximum < $limit) ? $maximum : $limit;
    }
}
