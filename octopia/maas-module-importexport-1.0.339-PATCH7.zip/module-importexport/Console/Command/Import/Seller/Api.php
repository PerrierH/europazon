<?php

namespace Maas\ImportExport\Console\Command\Import\Seller;

use Maas\ImportExport\Console\Command\Import\AbstractApiCommand;

/**
 * Command to backup code base and user data
 *
 * @package Maas\ImportExport\Console\Command\Import\Seller
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @codeCoverageIgnore
 */
class Api extends AbstractApiCommand
{
    const SEGMENT_SIZE = 1;
    const BATCH_SIZE = 1;
    protected $commandName = 'maas:import:seller';
    protected $consumerCommand = 'maas:import:seller:consumer';
    protected $commandDescription = 'Adds sellers messages';
    protected $entityType = 'seller';

    /**
     * @var string
     */
    protected $newCsvModelIdColName = 'seller_id';

    /**
     * @var string
     */
    protected $newCsvModelIdName = 'sellerId';

    /**
     * @var string
     */
    protected $newCsvOperationLabel = 'Adding seller to publisher';

    /**
     * @var string
     */
    protected $configLimitMethod = 'getSellersLimit';

    /**
     * @return int
     */
    protected function fetchTotalItemsCount()
    {
        return $this->importModel->getTotalItemsCount();
    }
}
