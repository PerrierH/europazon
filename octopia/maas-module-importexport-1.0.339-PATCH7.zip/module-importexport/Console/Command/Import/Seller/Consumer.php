<?php

namespace Maas\ImportExport\Console\Command\Import\Seller;

use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;

/**
 * Class Consumer
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command\Import\Seller
 */
class Consumer extends AbstractConsumerCommand
{
    protected $commandName = 'maas:import:seller:consumer';
    protected $commandDescription = 'Consumes sellers messages already in queue';
    protected $referenceWorkerProcess = 'import_seller';
    protected $logAction = 'Import_Sellers';
    protected $logModuleName = 'Maas_ImportExport';

    /**
     * @return int
     */
    protected function getConsumerProcessNumber()
    {
        return $this->configModel->getSellersConsumerProcessNumber();
    }

    /**
     * @return int
     */
    protected function getEntitiesNumberPerMessage()
    {
        return $this->configModel->getSellersNumberPerMessage();
    }

    /**
     * @return int
     */
    protected function getEntitiesPageLimit()
    {
        return $this->configModel->getSellersLimit();
    }
}
