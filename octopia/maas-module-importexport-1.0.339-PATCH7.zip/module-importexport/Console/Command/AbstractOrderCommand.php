<?php

namespace Maas\ImportExport\Console\Command;

use Maas\Core\Model\Config\Proxy as ConfigProxy;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputInterface;
use Magento\Framework\App\Area;
use Magento\Framework\App\State;

/**
 * Class AbstractOrderCommand
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Console\Command
 */
abstract class AbstractOrderCommand extends Command
{
    const ORDERID = 'orderId';

    /**
     * @var ConfigProxy
     */
    protected $configModel;

    /** @var State * */
    protected $state;

    /**
     * @param ConfigProxy $configModel
     */
    public function __construct(
        ConfigProxy $configModel,
        State $state
    ) {
        parent::__construct();
        $this->state = $state;
        $this->configModel = $configModel;
    }

    /**
     * @inheritDoc
     */
    protected function configure()
    {
        $this->configureCodeAndDescription();
        $this->addOption(
            self::ORDERID,
            null,
            InputOption::VALUE_OPTIONAL,
            'Order Id'
        );

        parent::configure();
    }

    abstract protected function configureCodeAndDescription();

    /**
     * Execute the command
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return null|int
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->state->setAreaCode(Area::AREA_ADMINHTML);
        if ($this->configModel->isModuleEnabled()) {
            $args = null;
            if ($orderId = $input->getOption(self::ORDERID)) {
                $args['orderId'] = $orderId;
                $output->writeln('<info>Provided Order Id is `' . $orderId . '`</info>');
            }

            $this->doExecute($args, $output);
        } else {
            $output->writeln('<info>You cannot execute this command because Maas module is disabled </info>');
        }
    }

    /**
     * @param array $args
     * @param OutputInterface $output
     */
    abstract protected function doExecute($args, $output);
}