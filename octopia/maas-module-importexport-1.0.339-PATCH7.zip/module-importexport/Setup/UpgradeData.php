<?php

namespace Maas\ImportExport\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Config\Model\ResourceModel\Config;
use Magento\Framework\App\Cache\Manager;


class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var Manager
     */
    private $cacheManager;

    /**
     * @param Config $config
     * @param Manager $cacheManager
     */
    public function __construct(Config $config, Manager $cacheManager)
    {
        $this->config = $config;
        $this->cacheManager = $cacheManager;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $this->upgradeApiConfigVersion();
            $this->configCacheClean();
        }

        $setup->endSetup();
    }


    private function upgradeApiConfigVersion()
    {
        $this->config->saveConfig('maas_api/production/api_version','V3');
        $this->config->saveConfig('maas_api/preprod/api_version','V3');
        $this->config->saveConfig('maas_api/recette/api_version','V3');
        $this->config->saveConfig('maas_api/userbox/api_version','V3');
        $this->config->saveConfig('maas_api/mock/api_version','V3');
    }


    private function configCacheClean()
    {
        $this->cacheManager->clean(['config']);
    }
}
