<?php

namespace Maas\ImportExport\Setup\Patch\Data;

use Maas\AttributeSet\Api\Data\AttributeSetInfoInterface;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Eav\Model\Entity\Attribute\Set;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;

/**
 * Interface PopulateAttributeSetWithMaasCategory
 * @package Maas\ImportExport\Setup\Patch\Data
 */
class PopulateAttributeSetWithMaasCategory implements DataPatchInterface, PatchRevertableInterface
{
    private ModuleDataSetupInterface $moduleDataSetup;
    protected CategoryCollectionFactory $categoryCollectionFactory;
    protected CollectionFactory $attributeSetCollectionFactory;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param CollectionFactory $attributeSetCollectionFactory
     */
    public function __construct(
        ModuleDataSetupInterface  $moduleDataSetup,
        CategoryCollectionFactory $categoryCollectionFactory,
        CollectionFactory         $attributeSetCollectionFactory
    )
    {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->attributeSetCollectionFactory = $attributeSetCollectionFactory;
    }

    /**
     * @inheritdoc
     */
    public function apply()
    {
        $this->moduleDataSetup->startSetup();
        if ($this->moduleDataSetup->getConnection()->isTableExists(
            $this->moduleDataSetup->getTable(AttributeSetInfoInterface::MAIN_TABLE)
        )) {
            $categories = $this->loadMaasCategories();
            $data = [];
            foreach ($categories as $category) {
                /** @var Collection $attributeSetCollection */
                $attributeSetCollection = $this->attributeSetCollectionFactory->create();
                $attributeSetCollection->addFieldToFilter(
                    'attribute_set_name', ['like' => 'Maas ' . '% ' . $category->getId()]
                );
                $attributeSets = $attributeSetCollection->getItems();
                /** @var Set $attributeSet */
                foreach ($attributeSets as $attributeSet) {
                    $data[] = [
                        AttributeSetInfoInterface::ATTRIBUTE_SET_ID => $attributeSet->getId(),
                        AttributeSetInfoInterface::MAAS_CATEGORY_ID => $category->getMaasCategoryId()
                    ];
                }
            }
            if (count($data)) {
                $this->moduleDataSetup->getConnection()->insertOnDuplicate(
                    $this->moduleDataSetup->getTable(AttributeSetInfoInterface::MAIN_TABLE),
                    $data,
                    [AttributeSetInfoInterface::ATTRIBUTE_SET_ID, AttributeSetInfoInterface::MAAS_CATEGORY_ID]
                );
            }
        }
        $this->moduleDataSetup->endSetup();
    }

    /**
     * @return void
     */
    private function loadMaasCategories()
    {
        $categoryCollection = $this->categoryCollectionFactory->create();
        $categoryCollection->addAttributeToSelect('maas_category_id');
        $categoryCollection->addAttributeToSelect('maas_level3_category');
        $categoryCollection->addAttributeToFilter('maas_is_maas_category', ['eq' => 1]);
        return $categoryCollection;
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [];
    }

    public function revert()
    {
        $this->moduleDataSetup->getConnection()->startSetup();
        if ($this->moduleDataSetup->getConnection()->isTableExists(
            $this->moduleDataSetup->getTable(AttributeSetInfoInterface::MAIN_TABLE)
        )) {
            $this->moduleDataSetup->getConnection()->delete(
                $this->moduleDataSetup->getTable(AttributeSetInfoInterface::MAIN_TABLE)
            );
        }
        $this->moduleDataSetup->getConnection()->endSetup();
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }
}
