<?php

namespace Maas\ImportExport\Api\Data\Common;

interface ImageInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const TITLE = 'title';
    const URL = 'url';
    const SIZE = 'size';
    const WIDTH = 'width';
    const HEIGHT = 'height';
    const UPDATE_AT = 'updateAt';

    /**
     * @return string
     */
    public function getTitle();

    /**
     * @param string $title
     * @return $this
     */
    public function setTitle($title);

    /**
     * @return string
     */
    public function getUrl();

    /**
     * @param string $url
     * @return $this
     */
    public function setUrl($url);

    /**
     * @return int
     */
    public function getSize();

    /**
     * @param int $size
     * @return $this
     */
    public function setSize($size);

    /**
     * @return int
     */
    public function getWidth();

    /**
     * @param int $width
     * @return $this
     */
    public function setWidth($width);

    /**
     * @return int
     */
    public function getHeight();

    /**
     * @param int $height
     * @return $this
     */
    public function setHeight($height);

    /**
     * @return string
     */
    public function getUpdatedAt();

    /**
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt);
}
