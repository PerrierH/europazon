<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface CategoryInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getCategoryId();

    /**
     * @param string $categoryId
     * @return $this
     */
    public function setCategoryId($categoryId);

    /**
     * @return string
     */
    public function getLabel();

    /**
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * @return string
     */
    public function getLevel();

    /**
     * @param string $level
     * @return $this
     */
    public function setLevel($level);

    /**
     * @return string
     */
    public function getParentCategoryId();

    /**
     * @param string $parentCategoryId
     * @return $this
     */
    public function setParentCategoryId($parentCategoryId);

    /**
     * @return string
     */
    public function getUpdatedAt();

    /**
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\Category\AttributeInterface[]
     */
    public function getAttributes();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\Category\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes($attributes);
}
