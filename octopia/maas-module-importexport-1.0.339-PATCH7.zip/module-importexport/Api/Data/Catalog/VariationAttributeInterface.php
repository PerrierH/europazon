<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface VariationAttributeInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getLabel();

    /**
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * @return string[]
     */
    public function getValues();

    /**
     * @param string[] $values
     * @return $this
     */
    public function setValues($values);

    /**
     * @return string
     */
    public function getCode();

    /**
     * @param string $code
     * @return $this
     */
    public function setCode($code);
}
