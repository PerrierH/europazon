<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface BrandInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getCode();

    /**
     * @param string $code
     * @return $this
     */
    public function setCode($code);

    /**
     * @return string
     */
    public function getLabel();

    /**
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\BrandImagesInterface
     */
    public function getImage();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\BrandImagesInterface $images
     * @return $this
     */
    public function setImage(\Maas\ImportExport\Api\Data\Catalog\BrandImagesInterface $images);
}
