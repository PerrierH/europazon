<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface AttributeInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getCode();

    /**
     * @param string $code
     * @return $this
     */
    public function setCode($code);

    /**
     * @return string
     */
    public function getLabel();

    /**
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * @return string[]|string|null
     */
    public function getValue();

    /**
     * @param string[]|string|null $value
     * @return $this
     */
    public function setValue($value);

    /**
     * @return string
     */
    public function getValueType();

    /**
     * @param string $valueType
     * @return $this
     */
    public function setValueType($valueType);

    /**
     * @return string
     */
    public function getUnit();

    /**
     * @param string $unit
     * @return $this
     */
    public function setUnit($unit);

    /**
     * @return int
     */
    public function getPosition();

    /**
     * @param int $position
     * @return $this
     */
    public function setPosition($position);
}
