<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface AttributesGroupInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getCode();

    /**
     * @param string $code
     * @return $this
     */
    public function setCode($code);

    /**
     * @return string
     */
    public function getLabel();

    /**
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * @return int
     */
    public function getPosition();

    /**
     * @param int $position
     * @return $this
     */
    public function setPosition($position);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\AttributeInterface[]
     */
    public function getAttributes();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\AttributeInterface[] $attributes
     * @return $this
     */
    public function setAttributes($attributes);
}
