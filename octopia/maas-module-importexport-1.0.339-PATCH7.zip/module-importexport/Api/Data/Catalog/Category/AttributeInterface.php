<?php

namespace Maas\ImportExport\Api\Data\Catalog\Category;
use Magento\Framework\Serialize\Serializer\Json;

interface AttributeInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getCode();

    /**
     * @param string $code
     * @return $this
     */
    public function setCode($code);

    /**
     * @return string
     */
    public function getLabel();

    /**
     * @param string $label
     * @return $this
     */
    public function setLabel($label);

    /**
     * @return string
     */
    public function getProperties();

    /**
     * @param array $properties
     * @return $this
     */
    public function setProperties($properties);

    /**
     * @return string[]
     */
    public function getOptions();

    /**
     * @param string[] $options
     * @return $this
     */
    public function setOptions($options);

    /**
     * @return string
     */
    public function getRequired();

    /**
     * @param string $required
     * @return $this
     */
    public function setRequired($required);
}
