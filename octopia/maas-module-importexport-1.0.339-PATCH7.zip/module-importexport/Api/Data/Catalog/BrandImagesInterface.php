<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface BrandImagesInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Common\ImageInterface
     */
    public function getSmall();

    /**
     * @param \Maas\ImportExport\Api\Data\Common\ImageInterface $small
     *
     * @return $this
     */
    public function setSmall(\Maas\ImportExport\Api\Data\Common\ImageInterface $small);

    /**
     * @return \Maas\ImportExport\Api\Data\Common\ImageInterface
     */
    public function getMedium();

    /**
     * @param \Maas\ImportExport\Api\Data\Common\ImageInterface $medium
     * @return $this
     */
    public function setMedium(\Maas\ImportExport\Api\Data\Common\ImageInterface $medium);

    /**
     * @return \Maas\ImportExport\Api\Data\Common\ImageInterface
     */
    public function getLarge();

    /**
     * @param \Maas\ImportExport\Api\Data\Common\ImageInterface $large
     * @return $this
     */
    public function setLarge(\Maas\ImportExport\Api\Data\Common\ImageInterface $large);
}
