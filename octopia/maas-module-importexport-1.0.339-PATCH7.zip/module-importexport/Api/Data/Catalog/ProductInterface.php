<?php

namespace Maas\ImportExport\Api\Data\Catalog;

use Magento\Eav\Api\Data\AttributeSetInterface;

interface ProductInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return string
     */
    public function getProductId();

    /**
     * @param string $productId
     * @return $this
     */
    public function setProductId($productId);

    /**
     * @return string
     */
    public function getGtin();

    /**
     * @param string $gtin
     * @return $this
     */
    public function setGtin($gtin);

    /**
     * @return string
     */
    public function getTitle();

    /**
     * @param string $title
     * @return $this
     */
    public function setTitle($title);

    /**
     * @return string
     */
    public function getDescription();

    /**
     * @param string $description
     * @return $this
     */
    public function setDescription($description);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\BrandInterface
     */
    public function getBrand();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\BrandInterface $brand
     * @return $this
     */
    public function setBrand(\Maas\ImportExport\Api\Data\Catalog\BrandInterface $brand);

    /**
     * @return string
     */
    public function getCategoryId();

    /**
     * @param string $categoryId
     * @return $this
     */
    public function setCategoryId($categoryId);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\ProductImagesInterface
     */
    public function getImages();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\ProductImagesInterface $images
     * @return $this
     */
    public function setImages(\Maas\ImportExport\Api\Data\Catalog\ProductImagesInterface $images);

    /**
     * @return int
     */
    public function getWeight();

    /**
     * @param int $weight
     * @return $this
     */
    public function setWeight($weight);

    /**
     * @return string
     */
    public function getVariationGroupId();

    /**
     * @param string $variationGroupId
     * @return $this
     */
    public function setVariationGroupId($variationGroupId);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\VariationAttributeInterface[]
     */
    public function getVariationAttributes();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\VariationAttributeInterface[] $variationAttributes
     * @return $this
     */
    public function setVariationAttributes($variationAttributes);

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\AttributesGroupInterface[]
     */
    public function getAttributesGroup();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\AttributesGroupInterface[] $attributesGroup
     * @return $this
     */
    public function setAttributesGroup($attributesGroup);

    /**
     * @return string
     */
    public function getUpdatedAt();

    /**
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt);

    /**
     * @return string
     */
    public function getCreatedAt();

    /**
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt);

    /**
     * @return string
     */
    public function getStatus();

    /**
     * @param string $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * @return string
     */
    public function getThirdLevelCategoryLabel();

    /**
     * @param string $thirdLevelLabel
     * @return $this
     */
    public function setThirdLevelCategoryLabel($thirdLevelLabel);

    /**
     * @return int
     */
    public function getAttributeSetId(): ?int;

    /**
     * @param int $attributeSetId
     * @return $this
     */
    public function setAttributeSetId(?int $attributeSetId);
}
