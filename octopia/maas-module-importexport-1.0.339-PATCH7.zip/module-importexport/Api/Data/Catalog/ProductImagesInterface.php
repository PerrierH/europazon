<?php

namespace Maas\ImportExport\Api\Data\Catalog;

interface ProductImagesInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Common\ImageInterface[]
     */
    public function getSmall();

    /**
     * @param \Maas\ImportExport\Api\Data\Common\ImageInterface[] $small
     *
     * @return $this
     */
    public function setSmall($small);

    /**
     * @return \Maas\ImportExport\Api\Data\Common\ImageInterface[]
     */
    public function getMedium();

    /**
     * @param \Maas\ImportExport\Api\Data\Common\ImageInterface[] $medium
     * @return $this
     */
    public function setMedium($medium);

    /**
     * @return \Maas\ImportExport\Api\Data\Common\ImageInterface[]
     */
    public function getLarge();

    /**
     * @param \Maas\ImportExport\Api\Data\Common\ImageInterface[] $large
     * @return $this
     */
    public function setLarge($large);
}
