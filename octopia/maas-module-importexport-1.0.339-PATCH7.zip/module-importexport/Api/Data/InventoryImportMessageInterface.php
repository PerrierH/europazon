<?php

namespace Maas\ImportExport\Api\Data;

/**
 * Interface InventoryImportMessageInterface
 *
 * @package Maas\ImportExport\Api\Data
 */
interface InventoryImportMessageInterface extends AbstractImportMessageInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface[]
     */
    public function getEntities();

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
