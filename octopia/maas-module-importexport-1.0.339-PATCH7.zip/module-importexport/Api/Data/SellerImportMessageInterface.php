<?php

namespace Maas\ImportExport\Api\Data;

/**
 * Interface SellerImportMessageInterface
 *
 * @package Maas\ImportExport\Api\Data
 */
interface SellerImportMessageInterface extends AbstractImportMessageInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Seller\SellerInterface[]
     */
    public function getEntities();

    /**
     * @param \Maas\ImportExport\Api\Data\Seller\SellerInterface[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
