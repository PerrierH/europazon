<?php

namespace Maas\ImportExport\Api\Data;

/**
 * Interface OfferPriceImportMessageInterface
 *
 * @package Maas\ImportExport\Api\Data
 */
interface OfferPriceImportMessageInterface extends AbstractImportMessageInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Offer\Price\PriceInterface[]
     */
    public function getEntities();

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\Price\PriceInterface[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
