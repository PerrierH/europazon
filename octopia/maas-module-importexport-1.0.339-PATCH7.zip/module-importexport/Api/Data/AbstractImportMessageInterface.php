<?php

namespace Maas\ImportExport\Api\Data;


/**
 * Interface ImportMessageWrapper
 * @package Maas\ImportExport\Api\Data
 */
interface AbstractImportMessageInterface
{
    /**
     * @return int
     */
    public function getReportId();

    /**
     * @param int $reportId
     * @return $this
     */
    public function setReportId($reportId);

    /**
     * @return string[]
     */
    public function getEntities();

    /**
     * @param string[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
