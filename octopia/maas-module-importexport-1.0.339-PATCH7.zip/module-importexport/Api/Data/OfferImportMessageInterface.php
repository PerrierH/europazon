<?php

namespace Maas\ImportExport\Api\Data;

/**
 * Interface OfferImportMessage
 *
 * @package Maas\ImportExport\Api\Data
 */
interface OfferImportMessageInterface extends AbstractImportMessageInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Offer\OfferInterface[]
     */
    public function getEntities();

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\OfferInterface[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
