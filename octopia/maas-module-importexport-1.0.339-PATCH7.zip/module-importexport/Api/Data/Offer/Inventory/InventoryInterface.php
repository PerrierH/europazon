<?php

namespace Maas\ImportExport\Api\Data\Offer\Inventory;

use Magento\Framework\Api\ExtensibleDataInterface;

interface InventoryInterface extends ExtensibleDataInterface
{
    const OFFER_ID = "offerId";
    const STOCK = "stock";
    const SUPPLY_MODE = "supplyMode";
    const DELIVERIES = "deliveries";
    const UPDATED_AT = "updatedAt";

    /**
     * @return string
     */
    public function getOfferId();
    /**
     * @return string
     */
    public function getStock();
    /**
     * @return string
     */
    public function getSupplyMode();
    /**
     * @return Maas\ImportExport\Api\Data\Offer\Inventory\DeliveryInterface[]
     */
    public function getDeliveries();
    /**
     * @return string
     */
    public function getUpdatedAt();
    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId);
    /**
     * @param string $stock
     *
     * @return $this
     */
    public function setStock($stock);
    /**
     * @param string $supplyMode
     *
     * @return $this
     */
    public function setSupplyMode($supplyMode);
    /**
     * @param Maas\ImportExport\Api\Data\Offer\Inventory\DeliveryInterface[] $deliveries
     *
     * @return $this
     */
    public function setDeliveries($deliveries);
    /**
     * @param string $updatedAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt);
}
