<?php

namespace Maas\ImportExport\Api\Data\Offer\Inventory;

interface DeliveryInterface
{
    const MODE = 'mode';
    const MIN_DELAY = 'minDelay';
    const MAX_DELAY = 'maxDelay';
    const SHIPPING_COST = 'shippingCost';
    const ADDITIONAL_SHIPPING_COST = 'additionalShippingCost';

    /**
     * @return string
     */
    public function getMode();

    /**
     * @return string
     */
    public function getMinDelay();

    /**
     * @return string
     */
    public function getMaxDelay();

    /**
     * @return string
     */
    public function getShippingCost();

    /**
     * @return string
     */
    public function getAdditionalShippingCost();

    /**
     * @param string $mode
     * @return $this
     */
    public function setMode($mode);

    /**
     * @param string $minDelay
     * @return $this
     */
    public function setMinDelay($minDelay);

    /**
     * @param string $maxDelay
     * @return $this
     */
    public function setMaxDelay($maxDelay);

    /**
     * @param string $shippingCost
     * @return $this
     */
    public function setShippingCost($shippingCost);

    /**
     * @param string $additionalShippingCost
     * @return $this
     */
    public function setAdditionalShippingCost($additionalShippingCost);
}
