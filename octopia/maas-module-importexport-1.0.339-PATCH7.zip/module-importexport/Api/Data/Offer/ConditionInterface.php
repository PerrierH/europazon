<?php
namespace Maas\ImportExport\Api\Data\Offer;

interface ConditionInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const CONDITION = 'condition';
    const SUB_CONDITION = 'subCondition';
    const COMMENT = 'comment';

    /**
     * @return string
     */
    public function getCondition();

    /**
     * @return string
     */
    public function getSubCondition();

    /**
     * @return string
     */
    public function getComment();

    /**
     * @param string $condition
     *
     * @return $this
     */
    public function setCondition($condition);

    /**
     * @param string $subCondition
     *
     * @return $this
     */
    public function setSubCondition($subCondition);

    /**
     * @param string $comment
     *
     * @return $this
     */
    public function setComment($comment);
}
