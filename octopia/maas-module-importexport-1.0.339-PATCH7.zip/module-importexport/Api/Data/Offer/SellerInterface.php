<?php
namespace Maas\ImportExport\Api\Data\Offer;

interface SellerInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const NAME = 'name';

    /**
     * @return int
     */
    public function getId();

    /**
     * @return string
     */
    public function getName();

    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id);

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setName($name);
}
