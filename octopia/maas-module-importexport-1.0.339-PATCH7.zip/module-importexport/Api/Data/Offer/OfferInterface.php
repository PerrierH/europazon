<?php
namespace Maas\ImportExport\Api\Data\Offer;

interface OfferInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const OFFER_ID = 'offerId';
    const PRODUCT_ID = 'productId';
    const CONDITION = 'condition';
    const SELLER = 'seller';
    const IMAGES = 'images';
    const BEST_OFFER_RANK = 'bestOfferRank';
    const UPDATE_AT = 'updatedAt';
    const CREATE_AT = 'createdAt';
    const STATUS = 'status';
    const PRICE = 'price';
    const INVENTORY = 'inventory';
    const WARRANTY_DURATION = 'warranty_duration';

    /**
     * @return string
     */
    public function getOfferId();

    /**
     * @return string
     */
    public function getProductId();

    /**
     * @return \Maas\ImportExport\Api\Data\Offer\ConditionInterface
     */
    public function getCondition();

    /**
     * @return \Maas\ImportExport\Api\Data\Offer\Price\PriceInterface
     */
    public function getPrice();

    /**
     * @return \Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface
     */
    public function getInventory();

    /**
     * @return \Maas\ImportExport\Api\Data\Offer\SellerInterface
     */
    public function getSeller();

    /**
     * @return \Maas\ImportExport\Api\Data\Offer\OfferImagesInterface
     */
    public function getImages();

    /**
     * @return string
     */
    public function getBestOfferRank();

    /**
     * @return string
     */
    public function getUpdatedAt();

    /**
     * @return string
     */
    public function getCreatedAt();

    /**
     * @return string
     */
    public function getStatus();

    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId);

    /**
     * @param string $productId
     *
     * @return $this
     */
    public function setProductId($productId);

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\ConditionInterface $condition
     *
     * @return $this
     */
    public function setCondition($condition);

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\Price\PriceInterface $price
     *
     * @return $this
     */
    public function setPrice($price);

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface $inventory
     *
     * @return $this
     */
    public function setInventory($inventory);

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\SellerInterface $seller
     *
     * @return $this
     */
    public function setSeller($seller);

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\OfferImagesInterface $images
     *
     * @return $this
     */
    public function setImages(OfferImagesInterface $images);

    /**
     * @param string $bestOfferRank
     *
     * @return $this
     */
    public function setBestOfferRank($bestOfferRank);

    /**
     * @param string $updatedAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt);

    /**
     * @param $createAt
     *
     * @return $this
     */
    public function setCreatedAt($createAt);

    /**
     * @param string $status
     *
     * @return $this
     */
    public function setStatus($status);

    /**
     * @return string|null
     */
    public function getWarrantyDuration();

    /**
     * @param $warrantyDuration
     *
     * @return $this
     */
    public function setWarrantyDuration($warrantyDuration);
}
