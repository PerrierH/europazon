<?php
namespace Maas\ImportExport\Api\Data\Offer\Price;

use Magento\Framework\Api\ExtensibleDataInterface;

interface PriceInterface extends ExtensibleDataInterface
{
    const OFFER_ID = 'offerId';
    const PRICE = 'price';
    const CURRENCY = 'currency';
    const TAXES = 'taxes';
    const ORIGINAL_PRICE = 'originalPrice';
    const START_DATE = 'startDate';
    const END_DATE = 'endDate';
    const DISCOUNT_ID = 'discountId';
    const CREATED_AT = 'createdAt';
    const UPDATED_AT = 'updatedAt';

    /**
     * @return string
     */
    public function getOfferId();

    /**
     * @return float
     */
    public function getPrice();

    /**
     * @return string
     */
    public function getCurrency();
    /**
     * @return Maas\ImportExport\Api\Data\Offer\Price\TaxInterface[]
     */
    public function getTaxes();
    /**
     * @return float
     */
    public function getOriginalPrice();
    /**
     * @return string
     */
    public function getStartDate();
    /**
     * @return string
     */
    public function getEndDate();
    /**
     * @return string
     */
    public function getDiscountId();
    /**
     * @return string
     */
    public function getCreatedAt();
    /**
     * @return string
     */
    public function getUpdatedAt();
    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId);
    /**
     * @param float $price
     *
     * @return $this
     */
    public function setPrice($price);
    /**
     * @param string $currency
     *
     * @return $this
     */
    public function setCurrency($currency);
    /**
     * @param Maas\ImportExport\Api\Data\Offer\Price\TaxInterface[] $taxes
     *
     * @return $this
     */
    public function setTaxes($taxes);
    /**
     * @param float $originalPrice
     *
     * @return $this
     */
    public function setOriginalPrice($originalPrice);
    /**
     * @param string $startDate
     *
     * @return $this
     */
    public function setStartDate($startDate);
    /**
     * @param string $endDate
     *
     * @return $this
     */
    public function setEndDate($endDate);
    /**
     * @param string $discountId
     *
     * @return $this
     */
    public function setDiscountId($discountId);
    /**
     * @param string $createAt
     *
     * @return $this
     */
    public function setCreatedAt($createdAt);
    /**
     * @param string $updateAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt);
}
