<?php
namespace Maas\ImportExport\Api\Data\Offer\Price;

interface TaxInterface
{
    const CODE = 'code';
    const TYPE = 'type';
    const VALUE = 'value';
    /**
     * @return string
     */
    public function getCode();
    /**
     * @return string
     */
    public function getType();
    /**
     * @return float
     */
    public function getValue();
    /**
     * @param string $code
     *
     * @return $this
     */
    public function setCode($code);
    /**
     * @param string $type
     *
     * @return $this
     */
    public function setType($type);
    /**
     * @param float $value
     *
     * @return $this
     */
    public function setValue($value);
}
