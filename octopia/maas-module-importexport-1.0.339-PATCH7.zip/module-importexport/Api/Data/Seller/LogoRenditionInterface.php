<?php

namespace Maas\ImportExport\Api\Data\Seller;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface LogoRenditionInterface
 *
 * @package Maas\ImportExport\Api\Data\Seller
 */
interface LogoRenditionInterface extends ExtensibleDataInterface
{
    const NAME = 'name';
    const URL = 'url';
    const WIDTH = 'width';
    const HEIGHT = 'height';

    /**
     * @return string
     */
    public function getName();

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setName($name);

    /**
     * @return string
     */
    public function getUrl();

    /**
     * @param string $url
     *
     * @return $this
     */
    public function setUrl($url);

    /**
     * @return int
     */
    public function getWidth();

    /**
     * @param int $width
     *
     * @return $this
     */
    public function setWidth($width);

    /**
     * @return int
     */
    public function getHeight();

    /**
     * @param int $height
     *
     * @return $this
     */
    public function setHeight($height);
}