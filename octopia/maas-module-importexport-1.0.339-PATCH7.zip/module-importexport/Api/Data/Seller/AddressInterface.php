<?php

namespace Maas\ImportExport\Api\Data\Seller;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface AddressInterface
 *
 * @package Maas\ImportExport\Api\Data\Seller
 */
interface AddressInterface extends ExtensibleDataInterface
{
    const TYPE = 'type';
    const ADDRESS1 = 'address1';
    const ADDRESS2 = 'address2';
    const APPARTMENTNUMBER = 'appartmentNumber';
    const BUILDING = 'building';
    const ZIPCODE = 'zipCode';
    const CITY = 'city';
    const COUNTY = 'county';
    const COUNTRY = 'country';
    const INSTRUCTIONS = 'instructions';

    /**
     * @return string
     */
    public function getType();

    /**
     * @param string $type
     *
     * @return $this
     */
    public function setType($type);

    /**
     * @return string
     */
    public function getAddress1();

    /**
     * @param string $address1
     *
     * @return $this
     */
    public function setAddress1($address1);

    /**
     * @return string
     */
    public function getAddress2();

    /**
     * @param string $address2
     *
     * @return $this
     */
    public function setAddress2($address2);

    /**
     * @return string
     */
    public function getAppartmentNumber();

    /**
     * @param string $appartmentNumber
     *
     * @return $this
     */
    public function setAppartmentNumber($appartmentNumber);

    /**
     * @return string
     */
    public function getBuilding();

    /**
     * @param string $building
     *
     * @return $this
     */
    public function setBuilding($building);

    /**
     * @return string
     */
    public function getZipCode();

    /**
     * @param string $zipCode
     *
     * @return $this
     */
    public function setZipCode($zipCode);

    /**
     * @return string
     */
    public function getCity();

    /**
     * @param string $city
     *
     * @return $this
     */
    public function setCity($city);

    /**
     * @return string
     */
    public function getCounty();

    /**
     * @param string $county
     *
     * @return $this
     */
    public function setCounty($county);

    /**
     * @return string
     */
    public function getCountry();

    /**
     * @param string $country
     *
     * @return $this
     */
    public function setCountry($country);

    /**
     * @return string
     */
    public function getInstructions();

    /**
     * @param string $instructions
     *
     * @return $this
     */
    public function setInstructions($instructions);
}