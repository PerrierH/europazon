<?php

namespace Maas\ImportExport\Api\Data\Seller;

use Magento\Framework\Api\ExtensibleDataInterface;

interface LogoInterface extends ExtensibleDataInterface
{
    const POSITION = 'position';
    const URL = 'url';
    const RENDITIONS = 'renditions';

    /**
     * @return int
     */
    public function getPosition();

    /**
     * @param int $position
     *
     * @return $this
     */
    public function setPosition($position);

    /**
     * @return string
     */
    public function getUrl();

    /**
     * @param string $url
     *
     * @return $this
     */
    public function setUrl($url);

    /**
     * @return \Maas\ImportExport\Api\Data\Seller\LogoRenditionInterface[]
     */
    public function getRenditions();

    /**
     * @param \Maas\ImportExport\Api\Data\Seller\LogoRenditionInterface[] $renditions
     *
     * @return $this
     */
    public function setRenditions($renditions);
}