<?php

namespace Maas\ImportExport\Api\Data\Seller;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface SellerInterface
 *
 * @package Maas\ImportExport\Api\Data\Seller
 */
interface SellerInterface extends ExtensibleDataInterface
{
    const SELLER_ID = 'sellerId';
    const CREATION_DATE = 'creationDate';
    const LAST_UPDATE_DATE = 'lastUpdateDate';
    const SHOP_NAME = 'shopName';
    const SHOP_URL = 'shopUrl';
    const SHOP_LOGO = 'shopLogo';
    const COMPANY_REGISTRATION_NUMBER = 'companyRegistrationNumber';
    const DELIVERY_MODES = 'deliveryModes';
    const SUBSCRIPTION = 'subscription';
    const EMAIL = 'email';
    const SALES_ADVICES_EMAIL = 'salesAdvicesEmail';
    const NOTIFICATIONS_EMAIL = 'notificationsEmail';
    const STATE = 'state';
    const SUB_STATE = 'subState';
    const MOBILE_NUMBER = 'mobileNumber';
    const SHIPPING_COUNTRY = 'shippingCountry';
    const LEGAL_COMPANY_NAME = 'legalCompanyName';
    const LEGAL_STATUS = 'legalStatus';
    const COMPANY_CAPITAL = 'companyCapital';
    const INTRACOM_VAT = 'intracomVat';
    const IS_FULFILLMENT = 'isFulfillment';

    const ADDRESS = 'address';
    const LEGAL_TERMS = 'legal_terms';

    /**
     * @return string
     */
    public function getSellerId();

    /**
     * @param string $sellerId
     *
     * @return $this
     */
    public function setSellerId($sellerId);

    /**
     * @return string
     */
    public function getCreationDate();

    /**
     * @param string $creationDate
     *
     * @return $this
     */
    public function setCreationDate($creationDate);

    /**
     * @return string
     */
    public function getLastUpdateDate();

    /**
     * @param string $lastUpdateDate
     *
     * @return $this
     */
    public function setLastUpdateDate($lastUpdateDate);

    /**
     * @return string
     */
    public function getShopName();

    /**
     * @param string $shopName
     *
     * @return $this
     */
    public function setShopName($shopName);

    /**
     * @return string
     */
    public function getShopUrl();

    /**
     * @param string $shopUrl
     *
     * @return $this
     */
    public function setShopUrl($shopUrl);

    /**
     * @return \Maas\ImportExport\Api\Data\Seller\LogoInterface
     */
    public function getShopLogo();

    /**
     * @param \Maas\ImportExport\Api\Data\Seller\LogoInterface $shopLogo
     *
     * @return $this
     */
    public function setShopLogo($shopLogo);

    /**
     * @return string
     */
    public function getCompanyRegistrationNumber();

    /**
     * @param string $companyRegistrationNumber
     *
     * @return $this
     */
    public function setCompanyRegistrationNumber($companyRegistrationNumber);

    /**
     * @return string
     */
    public function getDeliveryModes();

    /**
     * @param string $deliveryModes
     *
     * @return $this
     */
    public function setDeliveryModes($deliveryModes);

    /**
     * @return string
     */
    public function getSubscription();

    /**
     * @param string $subscription
     *
     * @return $this
     */
    public function setSubscription($subscription);

    /**
     * @return string
     */
    public function getEmail();

    /**
     * @param string $email
     *
     * @return $this
     */
    public function setEmail($email);

    /**
     * @return string
     */
    public function getSalesAdvicesEmail();

    /**
     * @param string $salesAdvicesEmail
     *
     * @return $this
     */
    public function setSalesAdvicesEmail($salesAdvicesEmail);

    /**
     * @return string
     */
    public function getNotificationsEmail();

    /**
     * @param string $notificationsEmail
     *
     * @return $this
     */
    public function setNotificationsEmail($notificationsEmail);

    /**
     * @return string
     */
    public function getState();

    /**
     * @param string $state
     *
     * @return $this
     */
    public function setState($state);

    /**
     * @return string
     */
    public function getSubState();

    /**
     * @param string $subState
     *
     * @return $this
     */
    public function setSubState($subState);

    /**
     * @return string
     */
    public function getMobileNumber();

    /**
     * @param string $mobileNumber
     *
     * @return $this
     */
    public function setMobileNumber($mobileNumber);

    /**
     * @return \Maas\ImportExport\Api\Data\Seller\AddressInterface[]
     */
    public function getAddress();

    /**
     * @param \Maas\ImportExport\Api\Data\Seller\AddressInterface[] $address
     *
     * @return $this
     */
    public function setAddress($address);

    /**
     * @return string
     */
    public function getShippingCountry();

    /**
     * @param string $shippingCountry
     *
     * @return $this
     */
    public function setShippingCountry($shippingCountry);

    /**
     * @return string
     */
    public function getLegalCompanyName();

    /**
     * @param string $legalCompanyName
     *
     * @return $this
     */
    public function setLegalCompanyName($legalCompanyName);

    /**
     * @return string
     */
    public function getLegalStatus();

    /**
     * @param string $legalStatus
     *
     * @return $this
     */
    public function setLegalStatus($legalStatus);

    /**
     * @return string
     */
    public function getCompanyCapital();

    /**
     * @param string $companyCapital
     *
     * @return $this
     */
    public function setCompanyCapital($companyCapital);

    /**
     * @return string
     */
    public function getIntracomVat();

    /**
     * @param string $intracomVat
     *
     * @return $this
     */
    public function setIntracomVat($intracomVat);

    /**
     * @return bool
     */
    public function getIsFulfillment();

    /**
     * @param bool $isFulfillment
     *
     * @return $this
     */
    public function setIsFulfillment($isFulfillment);

    /**
     * @return \Maas\ImportExport\Api\Data\Seller\LegalTermsInterface[]
     */
    public function getLegalTerms();

    /**
     * @param \Maas\ImportExport\Api\Data\Seller\LegalTermsInterface[] $legalTerms
     *
     * @return $this
     */
    public function setLegalTerms($legalTerms);
}