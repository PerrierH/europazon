<?php

namespace Maas\ImportExport\Api\Data\Seller;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface LegalTermsInterface
 *
 * @package Maas\ImportExport\Api\Data\Seller
 */
interface LegalTermsInterface extends ExtensibleDataInterface
{
    const DESCRIPTION = 'description';
    const LANGUAGECODE = 'languageCode';

    /**
     * @return string
     */
    public function getDescription();

    /**
     * @param string $description
     *
     * @return $this
     */
    public function setDescription($description);

    /**
     * @return string
     */
    public function getLanguageCode();

    /**
     * @param string $languageCode
     *
     * @return $this
     */
    public function setLanguageCode($languageCode);
}