<?php

namespace Maas\ImportExport\Api\Data;

/**
 * Interface CategoryImportMessage
 *
 * @package Maas\ImportExport\Api\Data
 */
interface CategoryImportMessageInterface extends AbstractImportMessageInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\CategoryInterface[]
     */
    public function getEntities();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\CategoryInterface[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
