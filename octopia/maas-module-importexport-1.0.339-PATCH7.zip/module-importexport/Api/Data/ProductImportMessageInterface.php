<?php

namespace Maas\ImportExport\Api\Data;

/**
 * Interface ProductImportMessage
 *
 * @package Maas\ImportExport\Api\Data
 */
interface ProductImportMessageInterface extends AbstractImportMessageInterface
{
    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\ProductInterface[]
     */
    public function getEntities();

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\ProductInterface[] $entities
     * @return $this
     */
    public function setEntities($entities);
}
