<?php

namespace Maas\ImportExport\Test\Unit\Console\Command\Import;

use Exception;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Console\Command\Import\Offer\Api;
use Maas\ImportExport\Model\Config\Proxy;
use Maas\ImportExport\Model\Import\Offer\Offer as ImportOffer;
use Maas\ImportExport\Model\Import\Offer\Publisher;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportRepositoryInterface as ReportRepository;
use Maas\Log\Model\Csv;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Report;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;
use ReflectionClass;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;


class AbstractApiCommandTest extends TestCase
{

    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $importModel;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $serializer;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $importPublisher;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $reportRepository;
    /**
     * @var AbstractModelCommand|__anonymous@1810
     */
    private $consoleAbstractApiCommand;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $dateTime;

    /**
     * @dataProvider countItem
     *
     * @param $count
     * @param $expected
     */
    public function testGetItemName($count, $expected)
    {
        $this->initTest();
        $itemName = $this->invokeMethod($this->consoleAbstractApiCommand, 'getItemName', [$count]);
        $this->assertEquals($expected, $itemName, "Should return page or pages");
    }

    public function initTest($csv = null, $isEnable = false)
    {
        $report = AnyBuilder::createForClass($this, ReportInterface::class, [
            'log' => [$this->atMost(1), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $newReport = AnyBuilder::createForClass($this, Report::class, [
            "getId" => [$this->any(), 3, AnyBuilder::RETURN_VALUE],
            'log' => [$this->any(), true],
            'getErrorItemsCount' => [$this->any(), 4]
        ])->build();
        $this->configModel = AnyBuilder::createForClass($this, Proxy::class, [
            'isModuleEnabled' => [$this->any(), $isEnable, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->importModel = AnyBuilder::createForClass($this, ImportOffer::class, [
            'loadReportIdFromCache' => [$this->any(), 2, AnyBuilder::RETURN_VALUE],
            'loadReportFromCache' => [$this->any(), $newReport, AnyBuilder::RETURN_VALUE],
            'getCsvLogger' => [$this->any(), $csv, AnyBuilder::RETURN_VALUE],
            'getApiResponse' => [
                $this->any(),
                ['items' => ['item' => ['productId' => 'Maas']], 'totalItemCount' => 10],
                AnyBuilder::RETURN_VALUE
            ],
            'saveReportIdInCache' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'startProcess' => [$this->any(), $newReport, AnyBuilder::RETURN_VALUE],
        ])->build();
        $this->serializer = AnyBuilder::createForClass($this, SerializerInterface::class)->build();
        $this->importPublisher = AnyBuilder::createForClass($this, Publisher::class, [
            'setEntityType' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'setReportId' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'publish' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'publishRemaining' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $this->reportRepository = AnyBuilder::createForClass($this, ReportRepository::class, [
            'get' => [$this->any(), $report, AnyBuilder::RETURN_VALUE],
            'save' => [$this->any(), null, AnyBuilder::RETURN_SELF],
        ])->build();
        $this->dateTime = AnyBuilder::createForClass($this, DateTime::class, [
            'date' => [$this->any(), date('Y-m-d H:i:s'), AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->errorLogger = AnyBuilder::createForClass($this, ErrorLogger::class, [])->build();

        $this->consoleAbstractApiCommand = $this->getMockBuilder(Api::class)
            ->setConstructorArgs([
                $this->configModel,
                $this->importModel,
                $this->serializer,
                $this->importPublisher,
                $this->reportRepository,
                $this->dateTime,
                $this->errorLogger
            ])
            ->setMethods()
            ->getMock();
    }

    protected function invokeMethod(&$object, $methodName, array $parameters = [])
    {
        $reflection = new ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }

    public function countItem()
    {
        yield from [
            "Count egale 1" => [1, 'page'],
            "Count superior to 1" => [5, 'pages'],
        ];
    }

    public function testGetBashSize()
    {
        $this->initTest();
        $bashSize = $this->invokeMethod($this->consoleAbstractApiCommand, 'getBatchSize', []);
        $this->assertEquals(1, $bashSize, "Should return value from cont BATCH_SIZE");
    }

    public function testGetSegmentSize()
    {
        $this->initTest();
        $segmentSize = $this->invokeMethod($this->consoleAbstractApiCommand, 'getSegmentSize', []);
        $this->assertEquals(1, $segmentSize, "Should return value from cont SEGMENT_SIZE");
    }

    public function testRunSingleCommandException()
    {
        $csv = AnyBuilder::createForClass($this, Csv::class, [
            'storeMicrotimeStart' => [$this->once(), Exception::class, AnyBuilder::RETURN_VALUE]
        ])->build();
        $csv->expects($this->once())->method('storeMicrotimeStart')->willThrowException(new Exception('test'));

        $this->initTest($csv);
        $this->invokeMethod(
            $this->consoleAbstractApiCommand,
            'runSingleCommand',
            [
                'test',
                $this->getMockInputInterface(),
                $this->getMockOutPutInterface($this->once())
            ]
        );
    }

    /**
     * @param int $value
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    private function getMockInputInterface($value = 5)
    {
        return AnyBuilder::createForClass($this, InputInterface::class, [
            'getOption' => [$this->any(), $value, AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    private function getMockOutPutInterface($nbtimesCall)
    {
        return AnyBuilder::createForClass($this, OutputInterface::class, [
            "writeln" => [$nbtimesCall, "test", AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    public function testRunSingleCommand()
    {

        $csv = AnyBuilder::createForClass($this, Csv::class, [
            'newRow' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'storeMicrotimeStart' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'storeMicrotimeFinish' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'finalizeRow' => [$this->any(), null, AnyBuilder::RETURN_SELF],
        ])->build();

        $this->initTest($csv);
        $this->invokeMethod(
            $this->consoleAbstractApiCommand,
            'runSingleCommand',
            [
                'test',
                $this->getMockInputInterface(),
                $this->getMockOutPutInterface($this->never())
            ]
        );
    }

    public function testFetchItems()
    {
        $this->initTest();
        $value = $this->invokeMethod(
            $this->consoleAbstractApiCommand,
            'fetchItems',
            [
                $this->getMockInputInterface()
            ]
        );
        $this->assertEquals([1.0, 2.0], $value, 'should return an array');
    }

    public function testExecuteModuleNotActive()
    {
        $this->initTest();
        $notEnable = $this->invokeMethod(
            $this->consoleAbstractApiCommand,
            'execute',
            [
                $this->getMockInputInterface(),
                $this->getMockOutPutInterface($this->once())
            ]
        );
        $this->assertEquals(0, $notEnable, "should return 0");
    }
}
