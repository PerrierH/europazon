<?php

namespace Maas\ImportExport\Test\Unit\Console\Command\Import;

use Maas\Core\Model\Parallelization\ProcessManager;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Console\Command\Import\AbstractConsumerCommand;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;
use Maas\ImportExport\Model\Import\Catalog\Product as ImportProduct;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportRepositoryInterface as ReportRepository;
use Maas\Log\Model\Report;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;
use ReflectionClass;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Process\Process;

class AbstractConsumerCommandTest extends TestCase
{

    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $processManager;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $configModel;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $importModel;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $moduleList;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $reportRepository;
    /**
     * @var Product
     */
    private $consoleImportCommand;

    private $messageModuleNotActive = "<info>You cannot execute this command because Maas module is disabled </info>";

    /**
     * @dataProvider listModule
     */
    public function testIsModuleActive($module, $expected)
    {
        $this->initTest($module, $this->never());
        $isModuleActive = $this->invokeMethod($this->consoleImportCommand, 'isModuleActive', ['maas']);
        $this->assertEquals($isModuleActive, $expected, "should return a boolean");
    }

    public function initTest($moduleName = '', $numberOfSave = null, $isModuleEnable = false)
    {
        $this->processManager = AnyBuilder::createForClass($this, ProcessManager::class, [
            'runParallel' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $this->configModel = AnyBuilder::createForClass($this, ConfigProxy::class, [
            "isModuleEnabled" => [$this->any(), $isModuleEnable, AnyBuilder::RETURN_VALUE],
            "getMessageQueueConnectionMethod" => [$this->any(), 'mysql', AnyBuilder::RETURN_VALUE],
        ])->build();
        $this->importModel = AnyBuilder::createForClass($this, ImportProduct::class, [
            'loadReportIdFromCache' => [$this->any(), 2, AnyBuilder::RETURN_VALUE],
            'getApiResponse' => [$this->any(), ['totalItemCount' => 50], AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->moduleList = AnyBuilder::createForClass($this, ModuleListProxy::class, [
            "getAll" => [$this->any(), $moduleName, AnyBuilder::RETURN_VALUE]
        ])->build();
        $report = AnyBuilder::createForClass($this, ReportInterface::class)->build();
        $this->reportRepository = AnyBuilder::createForClass($this, ReportRepository::class, [
            "get" => [$this->any(), $report, AnyBuilder::RETURN_VALUE],
            "save" => [$numberOfSave, null, AnyBuilder::RETURN_SELF],
            "closeLogReport" => [$this->any(), null, AnyBuilder::RETURN_SELF],
        ])->build();

        $this->consoleImportCommand = AnyBuilder::createForClass(
            $this,
            AbstractConsumerCommand::class,
            [
                'getConfLimit' => [$this->any(), 2, AnyBuilder::RETURN_VALUE],
                'getParallelProcessNumber' => [$this->any(), 10, AnyBuilder::RETURN_VALUE],
                'getConsumerProcessNumber' => [$this->any(), 10, AnyBuilder::RETURN_VALUE],
                'newProcess' => [
                    $this->any(),
                    AnyBuilder::createForClass($this, Process::class)->build(),
                    AnyBuilder::RETURN_VALUE
                ],
                'setName' => [$this->any(), 'test', AnyBuilder::RETURN_VALUE],
                'callParentConstruct' => [$this->any(), null, AnyBuilder::RETURN_SELF],
                // created for unit test pruposes only on Magent 2.2.11
            ]
        )
            ->setCreateAsFullMock(true)
            ->setConstructorArgs([
                'moduleList' => $this->moduleList,
                'configModel' => $this->configModel,
                'processManager' => $this->processManager,
                'importModel' => $this->importModel,
                'reportRepository' => $this->reportRepository,
            ])
            ->build();
    }

    protected function invokeMethod(&$object, $methodName, array $parameters = [])
    {
        $reflection = new ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }

    public function listModule()
    {
        yield from [
            "The module exist" => [['maas' => true], true],
            "The module does not exist" => [['magento' => true], false],
        ];
    }

    /**
     * @dataProvider listValue
     */
    public function testCalculateMaxMessage($params, $expected)
    {
        $this->initTest('', $this->never());
        $ceilValue = $this->invokeMethod($this->consoleImportCommand, 'calculateMaxMessages', $params);
        $this->assertEquals($ceilValue, $expected, "should return an integer");
    }

    public function listValue()
    {
        yield from [
            "Divide inferior to 1" => [[5, 50], 1],
            "Divide is an integer" => [[20, 10], 2],
        ];
    }

    /**
     * @dataProvider listStatus
     */
    public function testUpdateReportStatus($error)
    {
        $this->initTest('', $this->any());
        $this->invokeMethod($this->consoleImportCommand, 'updateReportStatus', [
            $this->getMockReportModel(),
            $error
        ]);
    }

    private function getMockReportModel()
    {
        return AnyBuilder::createForClass($this, Report::class)->build();
    }

    public function listStatus()
    {
        yield from [
            "Import succeed" => [true],
            "Import failed" => [false],
        ];
    }

    public function testGetCountItem()
    {
        $this->initTest('', $this->never());
        $nbItems = $this->invokeMethod($this->consoleImportCommand, 'getCountItems');
        $this->assertEquals(50, $nbItems, "should return 50");
    }

    public function testExecuteCommandModuleIsDisable()
    {
        $this->initTest('', $this->never(), false);
        $this->invokeMethod($this->consoleImportCommand, 'execute', [
            $this->getMockInputInterface(),
            $this->getMockOutPutInterface($this->once())
        ]);
    }

    private function getMockInputInterface()
    {
        return AnyBuilder::createForClass($this, InputInterface::class)->build();
    }

    private function getMockOutPutInterface($nbTimes)
    {
        return AnyBuilder::createForClass($this, OutputInterface::class, [
            "writeln" => [$nbTimes, $this->messageModuleNotActive, AnyBuilder::RETURN_VALUE]
        ])->build();
    }

    public function testExecuteCommandModuleEnable()
    {
        $this->initTest('', $this->any(), true);
        $this->invokeMethod($this->consoleImportCommand, 'execute', [
            $this->getMockInputInterface(),
            $this->getMockOutPutInterface($this->any())
        ]);
    }

    public function testExecuteCommandModuleEnableIn22MagentoVersion()
    {
        $this->initTest(['Rcason_Mq' => true], $this->any(), true);
        $this->invokeMethod($this->consoleImportCommand, 'execute', [
            $this->getMockInputInterface(),
            $this->getMockOutPutInterface($this->any())
        ]);
    }
}
