<?php

namespace Maas\ImportExport\Test\Unit\Model\Service;

use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Catalog\Setup\CategorySetup;
use Magento\Eav\Api\Data\AttributeSetInterfaceFactory;
use Magento\Eav\Api\Data\AttributeSetSearchResultsInterface;
use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Maas\ImportExport\Model\Service\CreateProductAttribute;
use Maas\ImportExport\Model\Service\CreateAttributeSet;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Eav\Model\AttributeSetManagement;
use PHPUnit\Framework\TestCase;

class CreateAttributeSetTest extends TestCase
{
    /**
     * @var AttributeSetInterfaceFactory
     */
    private $attributeSetFactory;
    /**
     * @var AttributeSetRepositoryInterface
     */
    private $attributeSetRepository;
    /**
     * @var CreateProductAttribute
     */
    private $createProductAttribute;
    /**
     * @var AttributeSetManagement
     */
    private $attributeSetManagement;
    /**
     * @var CreateAttributeSet
     */
    private $stub;

    public function initTest($createProductAttribute, $nb)
    {
        $confAttributeSet = [
            'setAttributeSetName' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'setEntityTypeId' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ];
        $attributeSetInterface = $this->createMockAttributeSet($confAttributeSet);
        $attributeSetInterfaceCreated = $this->createMockAttributeSet();
        $this->attributeSetFactory = AnyBuilder::createForClass($this, AttributeSetInterfaceFactory::class, [
            'create' => [$nb, $attributeSetInterface]
        ])
            ->build();
        $this->attributeSetRepository = AnyBuilder::createForClass($this, AttributeSetRepositoryInterface::class)
            ->build();
        $this->attributeSetManagement = AnyBuilder::createForClass($this, AttributeSetManagement::class, [
            'create' => [$this->any(), $attributeSetInterfaceCreated]
        ])->build();
        $this->stub = new CreateAttributeSet(
            $this->attributeSetFactory,
            $this->attributeSetRepository,
            $createProductAttribute,
            $this->attributeSetManagement
        );
    }

    /**
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function testAttributeWithNameAlreadyExist()
    {
        $attributeSetInterface = $this->createMockAttributeSet();
        $createProductAttribute = AnyBuilder::createForClass($this, CreateProductAttribute::class, [
            'getAttributeEavAttributGroupMaas' => [
                $this->any(),
                [$attributeSetInterface],
            ]
        ])->build();
        $this->initTest($createProductAttribute, $this->never());
        $attributeSet = $this->stub->createAttributeSetByName('Test');
        $this->assertEquals($attributeSetInterface, $attributeSet, 'Should return an attributeSet');
    }

    /**
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function testAttributeNameNotExist()
    {
        $attributeSetInterface = [];
        $confAttributeSetMaas = [
            'getId' => [$this->any(), 9]
        ];
        $attributeMaasSetInterface = $this->createMockAttributeSet($confAttributeSetMaas);
        $createProductAttribute = AnyBuilder::createForClass($this, CreateProductAttribute::class, [
            'getAttributeEavAttributGroupMaas' => [
                $this->any(),
                [$attributeSetInterface, [$attributeMaasSetInterface]],
                AnyBuilder::RETURN_CONSECUTIVE
            ]
        ])->build();
        $this->initTest($createProductAttribute,$this->once());
        $attributeSet = $this->stub->createAttributeSetByName('Test2');
         $this->assertEquals($this->createMockAttributeSet(), $attributeSet, 'Should return an attributeSet');
    }

    public function createMockAttributeSet($conf = [])
    {
        return AnyBuilder::createForClass(
            $this,
            AttributeSetInterface::class,
            $conf
        )->build();
    }
}
