<?php

namespace Maas\ImportExport\Test\Unit\Model\Service;

use Maas\ImportExport\Model\Service\ProductImage;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;
use Magento\Framework\Filesystem\Io\File;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Catalog\Api\Data\ProductInterface;
use StdClass;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface;
use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Magento\Catalog\Model\Product\Gallery\Processor;
use Maas\Catalog\Model\Service\MediaProcessor;
use Magento\Catalog\Model\Product;

use const DIRECTORY_SEPARATOR;

/**
 * Class ProductImageTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Service
 */
class ProductImageTest extends TestCase
{

    const DUMMY_PATH = '/dummy/path';

    /** @var ProductImage */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $fileMock = AnyBuilder::createForClass(
            $this,
            File::class,
            [
                'checkAndCreateFolder' => [$this->any(), true],
                'read' => [$this->any(), true]
            ]
        )->build();

        $directoryListMock = AnyBuilder::createForClass(
            $this,
            DirectoryList::class,
            [
                'getPath' => [$this->any(), self::DUMMY_PATH]
            ]
        )->build();

        $processor = AnyBuilder::createForClass(
            $this,
            Processor::class,
            [
                'addImage' => [$this->any(), true],
                'updateImage' => [$this->any(), true]
            ]
        )->build();

        $mediaProcessor = AnyBuilder::createForClass(
            $this,
            MediaProcessor::class,
            [
                'updateMassInfo' => [$this->any(), true]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            ProductImage::class,
            [
                'file' => $fileMock,
                'directoryList' => $directoryListMock,
                'processor' => $processor,
                'mediaProcessor' => $mediaProcessor
            ]
        );
    }

    /**
     * @dataProvider getFileNameProvider
     */
    public function testGetNewFileName(string $fileName, $expectedFileName, $dir)
    {
        $newFileName = $this->instance->getNewFileName($fileName, $dir);
        $expectedFileName = self::DUMMY_PATH . DIRECTORY_SEPARATOR . $dir . DIRECTORY_SEPARATOR . $expectedFileName;
        $this->assertEquals($expectedFileName, $newFileName);
    }

    public function getFileNameProvider()
    {
        yield from [
            'Clean filename' => ['http://www.test.com/some_file_name.jpg', 'some_file_name.jpg', 'tmp'],
            'Unclean filename' => ['http://www.test.com/some%file?name.jpg', 'some_file_name.jpg', 'tmp'],
        ];
    }

    /**
     * @param $medias
     * @param $expected
     *
     * @dataProvider mediaProvider
     */
    public function testGetMediaGalleryImageAsArray($medias, $expected)
    {
        $product = AnyBuilder::createForClass(
            $this,
            ProductInterface::class,
            [
                'getMediaGalleryEntries' => [$this->any(), $medias]
            ]
        )->build();

        $this->assertEquals($expected, $this->instance->getMediaGalleryImageAsArray($product));

    }

    public function mediaProvider()
    {

        $medias = [];
        $imgUrl = 'http://test.image.com/image.jpg';

        $mediaMaasInfo = AnyBuilder::createForClass(
            $this,
            StdClass::class,
            [
                'getImageUrl' => [$this->any(), $imgUrl]
            ]
        )->build();

        $mediaExtensionAttribute = AnyBuilder::createForClass(
            $this,
            StdClass::class,
            [
                'getMaasInfo' => [$this->any(), $mediaMaasInfo]
            ]
        )->build();

        $medias[] = AnyBuilder::createForClass(
            $this,
            ProductAttributeMediaGalleryEntryInterface::class,
            [
                'getExtensionAttributes' => [$this->any(), $mediaExtensionAttribute]
            ]
        )->build();

        yield from [
            'No media' => [null, []],
            'Medias' => [$medias, [$imgUrl => $medias[0]]]
        ];
    }

    public function testAddToMediaGallery()
    {
        $product = AnyBuilder::createForClass(
            $this,
            Product::class,
            []
        )->build();

        $image = AnyBuilder::createForClass(
            $this,
            ImageInterface::class,
            [
                'getUrl' => [$this->any(), 'http://test.image.com/image.jpg'],
                'getTitle' => [$this->any(), 'Test title']
            ]
        )->build();

        $this->assertTrue($this->instance->addToMediaGallery($product, $image));
    }
}
