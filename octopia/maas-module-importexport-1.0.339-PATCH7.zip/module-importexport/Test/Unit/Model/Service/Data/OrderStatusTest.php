<?php
// TODO Must implement Test on Fulfillment order workflow

namespace Maas\ImportExport\Test\Unit\Model\Service\Data;

use Maas\Sales\Exception\UnknownStatus;
use Maas\Sales\Model\Service\Data\OrderStatus;
use PHPUnit\Framework\TestCase;

class OrderStatusTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $orderStatus;

    /**
     * set up
     */
    public function setUp()
    {
        $this->orderStatus = $this->getMockBuilder(OrderStatus::class)
            ->setMethods()
            ->getMock();
    }

    /**
     * @dataProvider getStatusWorkflowProvider
     *
     * @param string $initialStatus
     * @param string $targetStatus
     * @param string[] $expected
     */
    public function testGetStatusWorkflow($initialStatus, $targetStatus, $expected)
    {
        $statusListe = $this->orderStatus->getStatusWorkflow($initialStatus, $targetStatus);

        $this->assertEquals($expected, $statusListe);
    }

    public function getStatusWorkflowProvider()
    {
        yield from [
            'nominal cas exported => delivered' => [
                'initial_status' => OrderStatus::STATUS_EXPORTED,
                'target_status' => OrderStatus::STATUS_DELIVERED,
                'expected' => [
                    OrderStatus::STATUS_PROCESSING,
                    OrderStatus::STATUS_ACCEPTED,
                    OrderStatus::STATUS_SHIPPED,
                    OrderStatus::STATUS_DELIVERED,
                ],
            ],
            'nominal cas exported => Rejected' => [
                'initial_status' => OrderStatus::STATUS_EXPORTED,
                'target_status' => OrderStatus::STATUS_REJECTED,
                'expected' => [
                    OrderStatus::STATUS_PROCESSING,
                    OrderStatus::STATUS_REJECTED,
                ],
            ],
            'nominal cas exported => canceled' => [
                'initial_status' => OrderStatus::STATUS_EXPORTED,
                'target_status' => OrderStatus::STATUS_CANCELED,
                'expected' => [
                    OrderStatus::STATUS_CANCELED
                ],
            ],
            'cas where the status does not change' => [
                'initial_status' => OrderStatus::STATUS_ACCEPTED,
                'target_status' => OrderStatus::STATUS_ACCEPTED,
                'expected' => [],
            ],
        ];
    }

    /**
     * @dataProvider getStatusWorkflowProviderWithInvalidStatus
     *
     * @param string $initialStatus
     * @param string $targetStatus
     */
    public function testGetStatusWorkflowWithInvalidStatus($initialStatus, $targetStatus)
    {
        $this->expectException(UnknownStatus::class);
        $this->orderStatus->getStatusWorkflow($initialStatus, $targetStatus);
    }

    public function getStatusWorkflowProviderWithInvalidStatus()
    {
        yield from [
            'invalide initial status' => [
                'initial_status' => 'invalide',
                'target_status' => OrderStatus::STATUS_ACCEPTED,
            ],
            'invalide target status' => [
                'initial_status' => OrderStatus::STATUS_ACCEPTED,
                'target_status' => 'invalide',
            ],
            'invalide workflow' => [
                'initial_status' => OrderStatus::STATUS_ACCEPTED,
                'target_status' => OrderStatus::STATUS_REJECTED,
            ],
        ];
    }
}
