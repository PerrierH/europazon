<?php


namespace Maas\ImportExport\Test\Unit\Model\Service;

use Magento\Eav\Model\AttributeManagement;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Catalog\Model\Product\Attribute\Repository;
use Magento\Eav\Api\Data\AttributeInterface;
use Magento\Framework\Api\AbstractSimpleObject;
use Magento\Framework\Api\Filter;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\Search\FilterGroup;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Catalog\Api\AttributeSetRepositoryInterface;
use Magento\Catalog\Api\ProductAttributeGroupRepositoryInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use Magento\Eav\Api\Data\AttributeOptionInterfaceFactory;
use Maas\ImportExport\Model\Service\CreateProductAttribute;
use Magento\Catalog\Api\Data\ProductAttributeSearchResultsInterface;
use Magento\Eav\Api\Data\AttributeSetSearchResultsInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Magento\Eav\Api\Data\AttributeGroupSearchResultsInterface;
use Magento\Eav\Api\Data\AttributeGroupInterface;
use function Amp\Iterator\fromIterable;

class CreateAttributeTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $filterBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $filterGroupBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $searchCriteriaBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeSetRepositoryInterface;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productAttributeGroupRepositoryInterface;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeOptionInterfaceFactory;

    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $attributeManagement;


    public function initTest(
        $nbtimes,
        $nbTimesFilter,
        $nbSetFilter,
        $nbTimesFilterGroups,
        $productAttributeSearchResultsInterface,
        $isOptionExist = true
    ) {
        $filter = AnyBuilder::createForClass($this, Filter::class)
            ->build();
        $filterGroup = AnyBuilder::createForClass($this, FilterGroup::class)
            ->build();
        $attributeOptionInterface = AnyBuilder::createForClass($this, AttributeOptionInterface::class, [
            'setLabel' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'setValue' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $searchCriteria = AnyBuilder::createForClass($this, SearchCriteria::class)
            ->build();
        $attributeSetInterface = AnyBuilder::createForClass($this, AttributeSetInterface::class, [
            'getId' => [$this->any(), 5, AnyBuilder::RETURN_VALUE]
        ])->build();
        $attributeSetSearchResultsInterface = AnyBuilder::createForClass(
            $this,
            AttributeSetSearchResultsInterface::class,
            [
                'getItems' => [$this->any(), [$attributeSetInterface], AnyBuilder::RETURN_VALUE]
            ]
        )->build();
        $attributeGroupInterface = AnyBuilder::createForClass($this, AttributeGroupInterface::class, [
            'getId' => [$this->any(), 3, AnyBuilder::RETURN_VALUE]
        ])->build();
        $attributeGroupSearchResultsInterface = AnyBuilder::createForClass(
            $this,
            AttributeGroupSearchResultsInterface::class,
            [
                'getItems' => [$this->any(), [$attributeGroupInterface], AnyBuilder::RETURN_VALUE]
            ]
        )->build();
        $attribute = AnyBuilder::createForClass($this, Attribute::class)
            ->build();
        $this->attributeFactory = AnyBuilder::createForClass($this, AttributeFactory::class, [
            'create' => [$nbtimes, $attribute, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->attributeRepository = AnyBuilder::createForClass($this, Repository::class, [
            'getList' => [$this->once(), $productAttributeSearchResultsInterface, AnyBuilder::RETURN_VALUE],
            'save' => [$this->any(), null, AnyBuilder::RETURN_SELF],
        ])->build();
        $this->filterBuilder = AnyBuilder::createForClass($this, FilterBuilder::class, [
            'setField' => [$nbTimesFilter, null, AnyBuilder::RETURN_SELF],
            'setValue' => [$nbTimesFilter, null, AnyBuilder::RETURN_SELF],
            'setConditionType' => [$nbTimesFilter, null, AnyBuilder::RETURN_SELF],
            'create' => [$nbTimesFilter, $filter, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->filterGroupBuilder = AnyBuilder::createForClass($this, FilterGroupBuilder::class, [
            'setFilters' => [$nbSetFilter, null, AnyBuilder::RETURN_SELF],
            'create' => [$nbSetFilter, $filterGroup, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->searchCriteriaBuilder = AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'setFilterGroups' => [$nbTimesFilterGroups, null, AnyBuilder::RETURN_SELF],
            'create' => [$nbTimesFilterGroups, $searchCriteria, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->attributeSetRepositoryInterface = AnyBuilder::createForClass(
            $this,
            AttributeSetRepositoryInterface::class,
            [
                'getList' => [$this->any(), $attributeSetSearchResultsInterface, AnyBuilder::RETURN_VALUE]
            ]
        )->build();
        $this->productAttributeGroupRepositoryInterface = AnyBuilder::createForClass(
            $this,
            ProductAttributeGroupRepositoryInterface::class,
            [
                'getList' => [$this->any(), $attributeGroupSearchResultsInterface, AnyBuilder::RETURN_VALUE]
            ]
        )->build();
        $this->attributeOptionInterfaceFactory = AnyBuilder::createForClass(
            $this,
            AttributeOptionInterfaceFactory::class,
            [
                'create' => [
                    $isOptionExist ? $this->never() : $this->once(),
                    $attributeOptionInterface,
                    AnyBuilder::RETURN_VALUE
                ]
            ]
        )->build();

        $this->attributeManagement = AnyBuilder::createForClass(
            $this,
            AttributeManagement::class,
            [
                'assign' => [$this->any(), '5', AnyBuilder::RETURN_VALUE]
            ]
        )->build();

        $this->stub = new CreateProductAttribute(
            $this->attributeFactory,
            $this->attributeRepository,
            $this->filterBuilder,
            $this->filterGroupBuilder,
            $this->searchCriteriaBuilder,
            $this->attributeSetRepositoryInterface,
            $this->productAttributeGroupRepositoryInterface,
            $this->attributeOptionInterfaceFactory,
            $this->attributeManagement
        );
    }

    public function testAttributeItemEmptyAndNoOptions()
    {
        $productAttributeSearchResultsInterface = AnyBuilder::createForClass(
            $this,
            ProductAttributeSearchResultsInterface::class,
            ['getItems' => [$this->once(), [], AnyBuilder::RETURN_VALUE]]
        )->build();
        $this->initTest(
            $this->once(),
            $this->exactly(20),
            $this->exactly(8),
            $this->exactly(6),
            $productAttributeSearchResultsInterface
        );
        $this->stub->createProductAttributeByCode('tire_type', 'Tire type');
    }

    /**
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    public function testAttributeItemNotEmptyAndNoOptionsAndSameLabel()
    {
        $productAttributeInterface = AnyBuilder::createForClass($this, ProductAttributeInterface::class, [
            'getDefaultFrontendLabel' => [$this->any(), 'Tire type', AnyBuilder::RETURN_VALUE],
            'setDefaultFrontendLabel' => [$this->never()]
        ])->build();
        $productAttributeSearchResultsInterface = AnyBuilder::createForClass(
            $this,
            ProductAttributeSearchResultsInterface::class,
            ['getItems' => [$this->any(), [$productAttributeInterface], AnyBuilder::RETURN_VALUE]]
        )->build();
        $this->initTest(
            $this->never(),
            $this->exactly(20),
            $this->exactly(8),
            $this->exactly(6),
            $productAttributeSearchResultsInterface
        );
        $this->stub->createProductAttributeByCode('tire_type', 'Tire type');
    }

    /**
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    public function testAttributeItemNotEmptyAndNoOptions()
    {
        $productAttributeInterface = AnyBuilder::createForClass($this, ProductAttributeInterface::class, [
            'setDefaultFrontendLabel' => [$this->once()]
        ])->build();
        $productAttributeSearchResultsInterface = AnyBuilder::createForClass(
            $this,
            ProductAttributeSearchResultsInterface::class,
            ['getItems' => [$this->any(), [$productAttributeInterface], AnyBuilder::RETURN_VALUE]]
        )->build();
        $this->initTest(
            $this->never(),
            $this->exactly(20),
            $this->exactly(8),
            $this->exactly(6),
            $productAttributeSearchResultsInterface
        );
        $this->stub->createProductAttributeByCode('tire_type', 'Tire type');
    }

    /**
     * @dataProvider  getAttributeOptionInteface
     */
    public function testAttributeItemNotEmptyWithOptions($otpionLabel, $isOption)
    {
        $attributeOptionInterface = AnyBuilder::createForClass($this, AttributeOptionInterface::class, [
            'getLabel' => [$this->any(), '', AnyBuilder::RETURN_VALUE]
        ])->build();
        $attributeOptionInterface1 = AnyBuilder::createForClass($this, AttributeOptionInterface::class, [
            'getLabel' => [
                $this->any(),
                $otpionLabel,
                AnyBuilder::RETURN_VALUE
            ]
        ])->build();

        $productAttributeInterface = AnyBuilder::createForClass($this, ProductAttributeInterface::class, [
            'getOptions' => [
                $this->any(),
                [
                    $attributeOptionInterface,
                    $attributeOptionInterface1
                ],
                AnyBuilder::RETURN_VALUE
            ]
        ])->build();
        $productAttributeSearchResultsInterface = AnyBuilder::createForClass(
            $this,
            ProductAttributeSearchResultsInterface::class,
            ['getItems' => [$this->any(), [$productAttributeInterface], AnyBuilder::RETURN_VALUE]]
        )->build();
        $this->initTest(
            $this->never(),
            $this->exactly(20),
            $this->exactly(8),
            $this->exactly(6),
            $productAttributeSearchResultsInterface,
            $isOption
        );
        $this->stub->createProductAttributeByCode(
            'produit_largeur',
            'Largeur',
            null,
            0,
            [
                'frontend_input' => 'select',
                'backend_type' => 'int'
            ],
            [
                'value' => 'test',
            ]
        );
    }

    public function getAttributeOptionInteface()
    {
        yield from [
            'Option already exist' => ['test', true],
            'Option does not exist' => ['color', false],
        ];
    }
}
