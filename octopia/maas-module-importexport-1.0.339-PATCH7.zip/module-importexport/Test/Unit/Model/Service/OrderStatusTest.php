<?php

namespace Maas\ImportExport\Test\Unit\Model\Service;

use Maas\Sales\Model\Service\Data\OrderStatus as DataStatus;
use Maas\ImportExport\Model\Service\OrderStatus;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterfaceFactory;
use Maas\Sales\Api\Data\SalesQuoteItemInfoInterfaceFactory;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderExtensionInterfaceFactory;
use Magento\Sales\Api\Data\OrderItemExtension;
use Magento\Sales\Api\Data\OrderItemExtensionInterface;
use Magento\Sales\Api\Data\OrderItemExtensionInterfaceFactory;
use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Sales\Model\Order;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Sales\Exception\UnknownStatus;
use Maas\Shipping\Model\ShipmentManager;
use Magento\Sales\Model\Order\Item;

/**
 * Class OrderstatusTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Service
 */
class OrderstatusTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    private $objectManager;

    /** @var MockObject */
    private $orderMock;

    /**
     * @var Item[]
     */
    private $orderItemMock;

    /**
     * @var PHPUnit_Framework_MockObject_MockObject|null
     */
    private $orderItemMockExtensionAttributes;

    /**
     * @var OrderStatus
     */
    private $instance;

    /** @var SalesOrderItemInfoInterface */
    private $orderItemExtensionExtraInfo;

    /** @var array */
    private $orderStatusHistory = [];

    /** @var string */
    private $orderMockStatus;

    /** @var string */
    private $orderMockState;

    /**
     * Set up
     */
    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->orderItemMock[] = $this->createMock(Item::class);
        $this->orderItemMock[0]->expects($this->any())->method('getSku')->willReturn('Test SKU');
        $this->orderItemMock[0]->expects($this->any())->method('setExtensionAttributes')->willReturnCallback(function (
            $p
        ) {
            $this->orderItemMockExtensionAttributes = $p;
            return $this;
        });
        $this->orderItemMock[0]->expects($this->any())->method('getExtensionAttributes')->willReturnReference($this->orderItemMockExtensionAttributes);

        $this->orderItemExtensionExtraInfo = $this->getMockBuilder(SalesOrderItemInfoInterface::class)
            ->setMethods(['getOfferMaasId'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
        $this->orderItemExtensionExtraInfo->expects($this->any())->method('getOfferId')->willReturn('152');
        $this->orderItemExtensionExtraInfo->expects($this->any())->method('getOfferMaasId')->willReturn('42');

        $this->orderItemMockExtensionAttributes = AnyBuilder::createForClass(
            $this,
            OrderItemExtensionInterface::class,
            [
                'getExtraInfo' => [$this->any(), $this->orderItemExtensionExtraInfo, AnyBuilder::RETURN_VALUE],
                'setExtraInfo' => [
                    $this->any(),
                    function (
                        $p
                    ) {
                        $this->orderItemExtensionExtraInfo = $p;
                        return $this;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $this->orderMock = $this->createMock(Order::class);
        $this->orderMock->expects($this->any())->method('getItems')->willReturnReference($this->orderItemMock);
        $this->orderMock->expects($this->any())->method('addCommentToStatusHistory')->willReturnCallback(function ($p) {
            $this->orderStatusHistory[] = $p;
            return $this;
        });
        $this->orderMock->expects($this->any())->method('setStatus')->willReturnCallback(function ($p) {
            $this->orderMockStatus = $p;
            return $this;
        });
        $this->orderMock->expects($this->any())->method('getStatus')->willReturnCallback(function () {
            return $this->orderMockStatus;
        });
        $this->orderMock->expects($this->any())->method('setState')->willReturnCallback(function ($p) {
            $this->orderMockState = $p;
            return $this;
        });
        $this->orderMock->expects($this->any())->method('getState')->willReturnCallback(function () {
            return $this->orderMockState;
        });

        $shipmentManagerMock = AnyBuilder::createForClass(
            $this,
            ShipmentManager::class,
            [
                'setShipment' => [$this->any(), true, AnyBuilder::RETURN_VALUE]
            ]
        )->build();

        /*$dataStatus = $this->createMock(DataStatus::class);
        $dataStatus->expects($this->any())->method('getStatusWorkflow')->willReturnCallback(function ($init, $target) {
            return [$target];
        });*/
        $dataStatus = $this->objectManager->getObject(DataStatus::class);

        $this->instance = $this->objectManager->getObject(
            OrderStatus::class,
            [
                'shipmentManager' => $shipmentManagerMock,
                'dataStatus' => $dataStatus
            ]
        );

        $this->orderMockStatus = 'maas_order_exported';
    }

    public function testUpdateProcessing()
    {
        $statusData = [
            'status' => 'Processing',
            'items' => [
                [
                    'offer' => [
                        'offerId' => 42
                    ],
                    'parcel' => [
                        'parcelNumber' => 27
                    ]
                ]
            ]
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_PROCESSING, $order->getStatus());
        $this->assertEquals(1, count($this->orderStatusHistory));
    }

    public function testUpdateInPreparation()
    {
        $statusData = [
            'status' => 'InPreparation'
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_IN_PREPARATION, $order->getStatus());
        $this->assertEquals(3, count($this->orderStatusHistory));
    }

    public function testUpdateWaiting()
    {
        $statusData = [
            'status' => 'Shipped'
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_SHIPPED, $order->getStatus());
        $this->assertEquals(3, count($this->orderStatusHistory));
    }

    public function testUpdateDelivered()
    {
        $statusData = [
            'status' => 'Delivered'
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_DELIVERED, $order->getStatus());
        $this->assertEquals(4, count($this->orderStatusHistory));
    }

    public function testUpdateRejected()
    {
        $statusData = [
            'status' => 'Rejected'
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_REJECTED, $order->getStatus());
        $this->assertEquals(2, count($this->orderStatusHistory));
    }

    public function testUpdateCancelled()
    {
        $statusData = [
            'status' => 'Cancelled'
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_CANCELED, $order->getStatus());
        $this->assertEquals(1, count($this->orderStatusHistory));
    }

    public function testSetStatusUnknown()
    {
        $statusData = [
            'status' => 'testUnknownStatus'
        ];
        try {
            $order = $this->instance->update($this->orderMock, $statusData);
            $this->assertTrue(false);
        } catch (UnknownStatus $e) {
            $this->assertTrue(true);
        } catch (\Exception $e) {
            $this->assertTrue(false);
        }
    }

    public function testItemsStatus()
    {
        $statusData = [
            'status' => 'Accepted'
        ];
        $order = $this->instance->update($this->orderMock, $statusData);

        $this->assertEquals(DataStatus::STATUS_ACCEPTED, $order->getStatus());
        $this->assertEquals(2, count($this->orderStatusHistory));
    }
}
