<?php


namespace Maas\ImportExport\Test\Unit\Model\Service;

use PHPUnit\Framework\TestCase;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Eav\Model\Entity\Attribute\AbstractAttribute;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SimpleDataObjectConverter;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Catalog\Model\ProductFactory;
use Magento\ConfigurableProduct\Api\Data\OptionValueInterfaceFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\ConfigurableProduct\Helper\Product\Options\Factory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Api\SearchCriteria;
use Maas\ImportExport\Model\Service\CreateConfigurableFromSimpleProduct;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Catalog\Api\Data\ProductSearchResultsInterface;
use Magento\Framework\Api\Filter;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;
use Magento\ConfigurableProduct\Api\Data\OptionInterface;
use Magento\Catalog\Api\Data\ProductExtensionInterface;

class CreateConfigurableFromSimpleProductTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $filterBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $searchCriteriaBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $sortOrderBuilder;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $productConfigurable;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $optionsFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionFactory;
    /**
     * @var CreateConfigurableFromSimpleProduct
     */
    private $stub;

    public function initTest($products, $nbTimesProduct, $collectionData = [])
    {
        $eav = $this->createMockAttribute();
        $productSearchResultsInterface = AnyBuilder::createForClass($this, ProductSearchResultsInterface::class, [
            'getItems' => [$this->any(), $products, AnyBuilder::RETURN_VALUE],
        ])
            ->build();
        $filter = AnyBuilder::createForClass($this, Filter::class)
            ->build();
        $optionInterface = AnyBuilder::createForClass($this, OptionInterface::class)
            ->build();
        $sortOrder = AnyBuilder::createForClass($this, SortOrder::class)
            ->build();
        $collection = AnyBuilder::createForClass($this, Collection::class, [
            'addAttributeToSelect' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'addAttributeToFilter' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'getData' => [$this->any(), $collectionData, AnyBuilder::RETURN_VALUE],
        ])
            ->build();
        $searchCriteriaInterface = AnyBuilder::createForClass($this, SearchCriteriaInterface::class)
            ->build();

        $this->productRepository = AnyBuilder::createForClass($this, ProductRepositoryInterface::class, [
            'getList' => [$this->once(), $productSearchResultsInterface, AnyBuilder::RETURN_VALUE],
            'get' => [$this->any(), $this->createMockProduct([$eav]), AnyBuilder::RETURN_VALUE],
        ])
            ->build();

        $this->filterBuilder = AnyBuilder::createForClass($this, FilterBuilder::class, [
            'setField' => [$this->once(), null, AnyBuilder::RETURN_SELF],
            'setConditionType' => [$this->once(), null, AnyBuilder::RETURN_SELF],
            'create' => [$this->once(), $filter, AnyBuilder::RETURN_VALUE],
        ])
            ->build();

        $this->searchCriteriaBuilder = AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'addFilters' => [$this->once(), null, AnyBuilder::RETURN_SELF],
            'setSortOrders' => [$this->once(), null, AnyBuilder::RETURN_SELF],
            'create' => [$this->once(), $searchCriteriaInterface, AnyBuilder::RETURN_VALUE],
        ])
            ->build();

        $this->sortOrderBuilder = AnyBuilder::createForClass($this, SortOrderBuilder::class, [
            'setField' => [$this->once(), null, AnyBuilder::RETURN_SELF],
            'setConditionType' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'create' => [$this->once(), $sortOrder, AnyBuilder::RETURN_VALUE],
        ])
            ->build();
        $this->productConfigurable = AnyBuilder::createForClass($this, Configurable::class, [
            'canUseAttribute' => [$this->any(), true, AnyBuilder::RETURN_VALUE]
        ])
            ->build();

        $this->productFactory = AnyBuilder::createForClass($this, ProductFactory::class, [
            'create' => [$nbTimesProduct, $this->createMockProduct([$eav]), AnyBuilder::RETURN_VALUE]
        ])
            ->build();
        $this->optionsFactory = AnyBuilder::createForClass($this, Factory::class, [
            'create' => [$this->any(), [$optionInterface], AnyBuilder::RETURN_VALUE]
        ])
            ->build();
        $this->collectionFactory = AnyBuilder::createForClass($this, CollectionFactory::class, [
            'create' => [$this->any(), $collection, AnyBuilder::RETURN_VALUE],
        ])
            ->build();
        $this->stub = new CreateConfigurableFromSimpleProduct(
            $this->productRepository,
            $this->searchCriteriaBuilder,
            $this->filterBuilder,
            $this->sortOrderBuilder,
            $this->productFactory,
            $this->productConfigurable,
            $this->collectionFactory,
            $this->optionsFactory
        );
    }

    public function testConfigurableSkuDoesNotExist()
    {
        $eav = $this->createMockAttribute();
        $product = $this->createMockProduct([$eav]);
        $this->initTest([2 => $product], $this->once(), [['id' => 3, 'sku' => '']]);
        $this->stub->createConfigurableWithAssociatedSimpleProduct();
    }

    public function testConfigurableSkuExist()
    {
        $eav = $this->createMockAttribute();
        $product = $this->createMockProduct([$eav]);
        $this->initTest([2 => $product], $this->never(), [['id' => 5, 'sku' => 'PNEU_configurable']]);
        $this->stub->createConfigurableWithAssociatedSimpleProduct();
    }

    public function testConfigurableMultipleProductSimpleWithConfigurableAttributesDataSuperiorToZerao()
    {
        $eav1 = $this->createMockAttribute(2, 4);
        $eav2 = $this->createMockAttribute(3, 4);
        $eav3 = $this->createMockAttribute(3, 5);
        $product1 = $this->createMockProduct([$eav1,$eav2, $eav3]);
        $product2 = $this->createMockProduct([$eav1,$eav2, $eav3], 'otherVaritionGroupId');
        $this->initTest([2 => $product1, 3 => $product2], $this->never(), [['id' => 5, 'sku' => 'PNEU_configurable']]);
        $this->stub->createConfigurableWithAssociatedSimpleProduct();
    }

    public function testIsNotAttributeInfo()
    {
        $eav = $this->createMockAttribute(2, 1, 'text');
        $product = $this->createMockProduct([$eav]);
        $this->initTest([2 => $product], $this->never(), [['id' => 5, 'sku' => 'PNEU_configurable']]);
        $this->stub->createConfigurableWithAssociatedSimpleProduct();
    }

    private function createMockAttribute($optionId = 2, $attributeId = 1, $select = 'select')
    {
        $abstractAttribute =  AnyBuilder::createForClass($this, AbstractSource::class, [
            'getOptionId' => [$this->any(), $optionId , AnyBuilder::RETURN_VALUE]
        ])->build();

        return AnyBuilder::createForClass($this, Attribute::class, [
            'getSource' => [$this->any(), $abstractAttribute , AnyBuilder::RETURN_VALUE],
            'getStoreLabel' => [$this->any(), 0 , AnyBuilder::RETURN_VALUE],
            'getId' => [$this->any(), $attributeId , AnyBuilder::RETURN_VALUE],
            'getBackendType' => [$this->any(), $select , AnyBuilder::RETURN_VALUE],
            'getAttributeCode' => [$this->any(), '' , AnyBuilder::RETURN_VALUE],
        ])->build();
    }

    private function createMockProduct($eavAttribute, $varitiongroup = 'MyVaritionGroup')
    {
        $productExtensionInterface = AnyBuilder::createForClass($this, ProductExtensionInterface::class, [
            'setConfigurableProductOptions' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();

        return AnyBuilder::createForClass($this, Product::class, [
            'getAttributes' => [$this->any(), $eavAttribute, AnyBuilder::RETURN_VALUE],
            'getSku' => [$this->any(), 'PNEU_configurable', AnyBuilder::RETURN_VALUE],
            'getAttributeText' => [$this->any(), 'AZZEFR', AnyBuilder::RETURN_VALUE],
            'getId' => [$this->any(), 2, AnyBuilder::RETURN_VALUE],
            'setAssociatedProductIds' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'getExtensionAttributes' => [$this->any(), $productExtensionInterface, AnyBuilder::RETURN_VALUE],
            'setExtensionAttributes' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'getMaasVariationGroupId' => [$this->any(), $varitiongroup, AnyBuilder::RETURN_VALUE],
        ])->build();
    }
}
