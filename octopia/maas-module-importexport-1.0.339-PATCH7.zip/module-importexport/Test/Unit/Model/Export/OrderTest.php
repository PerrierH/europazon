<?php

namespace Maas\ImportExport\Test\Unit\Model\Export;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Maas\Core\Test\Builder\Order\OrderCollectionBuilder;
use Maas\Core\Test\Builder\Order\OrderCollectionFactoryBuilder;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;
use Maas\ImportExport\Cron\Import\Offer\Offer;
use Maas\ImportExport\Model\Export\Order;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order as SalesOrder;
use Magento\Tax\Api\OrderTaxManagementInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Tax\Api\Data\OrderTaxDetailsInterface;
use Magento\Tax\Api\Data\OrderTaxDetailsAppliedTaxInterface;
use Magento\Sales\Model\Order\Address;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Catalog\Model\Product;
use Maas\ImportExport\Test\Builder\Model\AbstractApiBuilder;
use Magento\Framework\HTTP\ZendClientFactory;
use Exception;
use PHPUnit_Framework_MockObject_MockObject;
use stdClass;
use Magento\Sales\Api\Data\OrderItemExtensionInterface;
use Maas\Sales\Api\Data\SalesOrderItemInfoInterface;
use Maas\Offer\Model\Service\Offer as OfferService;
use Maas\Offer\Model\Offer as OfferModel;

/**
 * Class OrderTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Export
 */
class OrderTest extends TestCase
{
    private $arrayToCompare = [
        'reference' => 'IncrementId1',
        'purchaseDate' => '28/08/2020',
        'currencyCode' => 'EUR',
        'salesChannelDiscountType' => 'percent',
        'salesChannelDiscount' => 50,
        'totalPrice' => 250,
        'totalPriceWithoutVAT' => 218.33,
        'VATRate' => 0,
        'customerReference' => 2,
        'shipping' => [
            'civility' => 'Mr',
            'lastName' => 'Testeur',
            'firstName' => 'Test',
            'companyName' => 'Clever',
            'addressLine1' => '21 rue du test',
            'addressLine2' => '',
            'addressLine3' => '',
            'postalCode' => '31000',
            'city' => 'Toulouse',
            'stateOrRegion' => 'Haute Garonne',
            'countryCode' => 'FR',
            'phone' => '0650505050',
            'mobile' => '',
            'email' => 't@test.mail',
            'delivery' => [
                'mode' => 'Standard',
                'deliveryNetworkType' => '',
                'deliveryNetwork' => '',
                'pickUpId' => '',
                'deliveryDate' => ''
            ]
        ],
        'billing' => [
            'civility' => 'Mr',
            'lastName' => 'Testeur',
            'firstName' => 'Test',
            'companyName' => 'Clever',
            'addressLine1' => '21 rue du test',
            'addressLine2' => '',
            'addressLine3' => '',
            'postalCode' => '31000',
            'city' => 'Toulouse',
            'stateOrRegion' => 'Haute Garonne',
            'countryCode' => 'FR',
            'phone' => '0650505050',
            'mobile' => '',
            'email' => 't@test.mail',
            'tax' => [
                'vatNumber' => null
            ]
        ],
        'items' => [
            [
                'productId' => 0,
                'label' => 'productName0',
                'condition' => '',
                'productState' => null,
                'syncDate' => '11/02/10',
                'fromCountry' => '',
                'seller' => [
                    'id' => '6',
                    'name' => 'Cdiscount'
                ],
                'quantity' => 2,
                'packagingOption' => '',
                'groupCode' => '',
                'delivery' => [
                    'mode' => 'Standard',
                    'deliveryNetworkType' => '',
                    'deliveryNetwork' => '',
                    'pickUpId' => '',
                    'deliveryDate' => ''
                ],
                'pricing' => [
                    'unitSalesPrice' => 125,
                    'unitSalesPriceWithoutVAT' => 104.2,
                    'VATRateSalesPrice' => 20,
                    'commissionPrice' => '',
                    'VATRateCommissionPrice' => '',
                    'salesChannelDiscountType' => 'percent',
                    'salesChannelDiscount' => null,
                    'sellerDiscountType' => '',
                    'sellerDiscount' => '',
                    'shippingCosts' => '',
                    'shippingCostsWithoutVAT' => '',
                    'VATRateShippingCost' => '',
                    'taxes' => [
                        [
                            'code' => '',
                            'value' => 0
                        ]
                    ]
                ]
            ],
            [
                'productId' => 1,
                'label' => 'productName1',
                'condition' => '',
                'productState' => null,
                'syncDate' => '11/02/10',
                'fromCountry' => '',
                'seller' => [
                    'id' => '6',
                    'name' => 'Cdiscount'
                ],
                'quantity' => 2,
                'packagingOption' => '',
                'groupCode' => '',
                'delivery' => [
                    'mode' => 'Standard',
                    'deliveryNetworkType' => '',
                    'deliveryNetwork' => '',
                    'pickUpId' => '',
                    'deliveryDate' => ''
                ],
                'pricing' => [
                    'unitSalesPrice' => 125,
                    'unitSalesPriceWithoutVAT' => 104.2,
                    'VATRateSalesPrice' => 20,
                    'commissionPrice' => '',
                    'VATRateCommissionPrice' => '',
                    'salesChannelDiscountType' => 'percent',
                    'salesChannelDiscount' => null,
                    'sellerDiscountType' => '',
                    'sellerDiscount' => '',
                    'shippingCosts' => '',
                    'shippingCostsWithoutVAT' => '',
                    'VATRateShippingCost' => '',
                    'taxes' => [
                        [
                            'code' => '',
                            'value' => 0
                        ]
                    ]
                ]
            ]
        ]
    ];
    private $serializer;
    /**
     * @var MockObject
     */
    private $scopeConfig;
    /**
     * @var MockObject
     */
    private $orderTaxManagement;
    /**
     * @var Order
     */
    private $instance;
    /**
     * @var ObjectManager
     */
    private $objectManager;

    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;

    /** @var OfferService */
    private $offerService;

    /** @var bool */
    private $orderExportIncludesDiscounts;

    const SHIPPING_ADDRESS = 'ShippingAddress';
    const BILLING_ADDRESS = 'BillingAddress';

    /**
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    public function initTest()
    {
        return OrderBuilder::create($this)
            ->withAddress(self::SHIPPING_ADDRESS)
            ->withAddress(self::BILLING_ADDRESS)
            ->withSalesOrderInfo()
            ->withPayment()
            ->withProductItems(
                [
                    [
                        'item' => [
                            'getProductId' => [$this->any(), 0],
                            'getName' => [$this->any(), 'productName0'],
                            'getExtensionAttributes' => [
                                $this->any(),
                                AnyBuilder::createForClass(
                                    $this,
                                    OrderItemExtensionInterface::class,
                                    [
                                        'getExtraInfo' => [
                                            $this->any(),
                                            AnyBuilder::createForClass(
                                                $this,
                                                SalesOrderItemInfoInterface::class,
                                                [
                                                    'getOfferMaasId' => [$this->any(), '12345678']
                                                ]
                                            )->build()
                                        ]
                                    ]
                                )->build()
                            ]
                        ],
                        'product' => []
                    ],
                    [
                        'item' => [
                            'getProductId' => [$this->any(), 1],
                            'getName' => [$this->any(), 'productName1'],
                            'getExtensionAttributes' => [
                                $this->any(),
                                AnyBuilder::createForClass(
                                    $this,
                                    OrderItemExtensionInterface::class,
                                    [
                                        'getExtraInfo' => [
                                            $this->any(),
                                            AnyBuilder::createForClass(
                                                $this,
                                                SalesOrderItemInfoInterface::class,
                                                [
                                                    'getOfferMaasId' => [$this->any(), 'ABCDEFGH']
                                                ]
                                            )->build()
                                        ]
                                    ]
                                )->build()
                            ]
                        ],
                        'product' => []
                    ]
                ]
            )
            ->build();
    }

    /**
     * Changed to be manually callable because of the need to position $this->orderExportIncludesDiscounts
     */
    protected function _setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);
        $this->abstractApiBuilder->setConfigOrderExportIncludesDiscounts($this->orderExportIncludesDiscounts);

        $this->orderTaxManagement = $this->getMockBuilder(OrderTaxManagementInterface::class)
            ->disableOriginalConstructor()
            ->setMethods(['getOrderTaxDetails'])
            ->getMockForAbstractClass();

        $this->offerService = AnyBuilder::createForClass(
            $this,
            OfferService::class,
            [
                'getOfferById' => [
                    $this->any(),
                    function ($v) {
                        return AnyBuilder::createForClass(
                            $this,
                            OfferModel::class,
                            [
                                'getMaasEntityId' => [$this->any(), $v],
                                'getCondition' => [$this->any(), 'new']
                            ]
                        )->build();
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderTaxManagement' => $this->orderTaxManagement,
                'offerService' => $this->offerService
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Order::class,
            $di
        );
    }

    public function testDoExecuteWithoutDiscountsExport()
    {
        $this->_testDoExecute(false);
    }

    public function testDoExecuteWithDiscountsExport()
    {
        $this->_testDoExecute(true);
    }

    public function _testDoExecute($exportWithDiscounts)
    {
        $this->orderExportIncludesDiscounts = $exportWithDiscounts;
        $this->_setUp();
        $order = $this->initTest();

        $orderCollection = OrderCollectionBuilder::create($this)->withOrders([$order])->build();
        $orderCollectionFactory = OrderCollectionFactoryBuilder::create($this)->withCollection($orderCollection)->build();

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory,
                'orderTaxManagement' => $this->orderTaxManagement,
                'offerService' => $this->offerService
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Order::class,
            $di
        );

        $result = $this->instance->execute();

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(1, $result['successItemsCount']);
        $this->assertEquals('', $result['error']);
    }

    public function testDoExecuteException()
    {
        $this->_setUp();

        $order = $this->initTest();

        $orderCollection = OrderCollectionBuilder::create($this)->withOrders([$order])->build();
        $orderCollectionFactory = OrderCollectionFactoryBuilder::create($this)->withCollection($orderCollection)->build();

        $httpClientFactory = ZendClientFactoryBuilder::create($this)
            ->addConfig(['request_throw_exception' => true])
            ->build();

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory,
                'orderTaxManagement' => $this->orderTaxManagement,
                'httpClientFactory' => $httpClientFactory,
                'offerService' => $this->offerService
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Order::class,
            $di
        );

        $result = $this->instance->execute();

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(1, $result['errorItemsCount']);
        $this->assertEquals(1, $result['error']);
        $this->assertNotEquals('', $result['message']);
    }

    public function testDoExecuteNoOrders()
    {
        $this->_setUp();
        $orderCollection = OrderCollectionBuilder::create($this)->withOrders([])->build();
        $orderCollectionFactory = OrderCollectionFactoryBuilder::create($this)->withCollection($orderCollection)->build();

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory,
                'orderTaxManagement' => $this->orderTaxManagement
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Order::class,
            $di
        );

        $result = $this->instance->execute(['orderId' => '5']);

        $this->assertEquals(0, $result['itemsCount']);
        $this->assertEquals(0, $result['successItemsCount']);
        $this->assertEquals('', $result['error']);
    }

    public function testCheckStatusFailed()
    {
        $this->_setUp();
        $order = OrderBuilder::create($this)
            ->addConfig([
                'getStatus' => [$this->any(), 'pending']
            ])
            ->withPayment([
                'getMethod' => [$this->any(), 'test_method']
            ])
            ->build();

        $orderCollection = OrderCollectionBuilder::create($this)->withOrders([$order])->build();
        $orderCollectionFactory = OrderCollectionFactoryBuilder::create($this)->withCollection($orderCollection)->build();

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory,
                'orderTaxManagement' => $this->orderTaxManagement
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Order::class,
            $di
        );

        $result = $this->instance->execute();

        $this->assertEquals(0, $result['itemsCount']);
        $this->assertEquals(0, $result['errorItemsCount']);
        $this->assertEquals(0, $result['successItemsCount']);
    }
}
