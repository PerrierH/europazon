<?php

namespace Maas\ImportExport\Test\Unit\Model;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase as CoreAbstractTestCase;
use Magento\Framework\DataObject;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use PHPUnit_Framework_MockObject_MockObject;

/**
 * Class AbstractMqTestCase
 *
 * @package Maas\ImportExport\Test\Unit\Model
 */
class AbstractMqTestCase extends CoreAbstractTestCase
{
    const RANDOM_MODULE_1 = 'Magento_AModule';
    const RANDOM_MODULE_2 = 'Magento_AnotherModule';
    const RANDOM_MODULE_3 = 'ThirdParty_SomeModule';
    const RANDOM_MODULE_4 = 'Maas_OurModule';

    const SUBJECT_1 = 'maas_mymodule.subject1';
    const SUBJECT_2 = 'maas_mymodule.subject2';
    const SUBJECT_3 = 'maas_mymodule.subject3';
    const SUBJECT_4 = 'maas_mymodule.subject4';

    const SUBJECT_5 = 'maas_mymodule.subject5';
    const SUBJECT_6 = 'maas_mymodule.subject6';

    const CONNECTION_DB = 'db';
    const CONNECTION_RABBIT = 'rabbitmq';
    const CONNECTION_KAFKA = 'kafka';

    const SUFFIX_QUEUE = 'queue';
    const SUFFIX_TOPIC = 'topic';

    /**
     * @param string[] $modulesToInclude
     *
     * @return PHPUnit_Framework_MockObject_MockObject
     */
    protected function getModuleListMock($modulesToInclude)
    {
        $list = [
            self::RANDOM_MODULE_1 => [],
            self::RANDOM_MODULE_2 => []
        ];
        foreach($modulesToInclude as $module)
        {
            $list[$module] = [];
        }
        $list[self::RANDOM_MODULE_3] = [];
        $list[self::RANDOM_MODULE_4] = [];

        return AnyBuilder::createForClass($this, ModuleListProxy::class, [
            'getAll' => [1, $list]
        ])->build();
    }

    /**
     * @param $moduleToInclude
     *
     * @return array[]
     */
    protected function getModulesList($modulesToInclude)
    {
        $result = [
            self::RANDOM_MODULE_1 => [],
            self::RANDOM_MODULE_2 => []
        ];
        foreach($modulesToInclude as $module)
        {
            $result[$module] = [];
        }
        $result[self::RANDOM_MODULE_3] = [];
        $result[self::RANDOM_MODULE_4] = [];
        return $result;
    }

    /**
     * @param string $suffix
     *
     * @return string[]
     */
    protected function getValidRequestedQueues($suffix)
    {
        $result = [];
        foreach([self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4] as $subject)
        {
            foreach([self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA] as $connection)
            {
                $result[] = $subject.'.'.$connection.'.'.$suffix;
            }
        }
        return $result;
    }

    /**
     * @param string $suffix
     *
     * @return string[]
     */
    protected function getInvalidRequestedQueues($suffix)
    {
        $result = [];
        foreach([self::SUBJECT_5, self::SUBJECT_6] as $subject)
        {
            foreach([self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA] as $connection)
            {
                $result[] = $subject.'.'.$connection.'.'.$suffix;
            }
        }
        return $result;
    }

    /**
     * @return string[]
     */
    protected function getRcasonMqQueues()
    {
        $result = [];
        foreach([self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4] as $subject)
        {
            foreach([self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA] as $connection)
            {
                $result[] = $subject.'.'.$connection.'.'.self::SUFFIX_QUEUE;
            }
        }
        return $result;
    }

    /**
     * @return string[]
     */
    protected function getMagentoTopics()
    {
        $result = [];
        foreach([self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4] as $subject)
        {
            foreach([self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA] as $connection)
            {
                $result[] = ['name' => $subject.'.'.$connection.'.'.self::SUFFIX_TOPIC];
            }
        }
        return $result;
    }

    /**
     * @return string[]
     */
    protected function getMagentoQueues()
    {
        $result = [];
        foreach([self::SUBJECT_1, self::SUBJECT_2, self::SUBJECT_3, self::SUBJECT_4] as $subject)
        {
            foreach([self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA] as $connection)
            {
                $result[] = AnyBuilder::createForClass($this, DataObject::class, [
                    'getName' => [1, $subject.'.'.$connection.'.'.self::SUFFIX_QUEUE]
                ])->build();
            }
        }
        return $result;
    }
}
