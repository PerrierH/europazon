<?php

namespace Maas\ImportExport\Test\Unit\Model;

use Maas\Core\Api\Data\TokenInterface;
use Maas\Core\Model\Http\Client;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\ResourceModel\Token\CollectionFactory;
use Maas\Core\Model\Token;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Model\Authentication;
use Maas\ImportExport\Test\Builder\Model\AbstractApiBuilder;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use PHPUnit_Framework_MockObject_MockObject;
use Zend_Http_Response;

class AuthenticationTest extends TestCase
{
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $httpClientFactory;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $configProvider;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $serializer;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $reportFactory;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $reportRepository;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $reportCollectionFactory;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $tokenRepository;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $collectionFactory;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $tokenFactory;
    /**
     * @var Authentication
     */
    private $stub;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $cache;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $csvLoggerManagement;
    /**
     * @var PHPUnit_Framework_MockObject_MockObject
     */
    private $dateTime;


    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;
    /** @var ObjectManager */
    private $objectManager;

    public function testApiCallError()
    {
        $expected = [
            'status' => 'error',
            'response' => ['error' => 400, 'response' => 'Wrong authen'],
            'error' => true
        ];
        $this->initTest('{"error":400,"response":"Wrong authen"}', 400);
        $report = AnyBuilder::createForClass(
            $this,
            Report::class,
            [
                'initLog' => [$this->any(), null, AnyBuilder::RETURN_SELF],
                'log' => [$this->any(), true]
            ]
        )->build();
        $response = $this->stub->doExecute($report, []);
        $this->assertEquals($expected, $response, 'should be an array with status error');
    }

    public function initTest($jsonResponse, $jsonResponseStatus)
    {
        $zendHttpResponse = AnyBuilder::createForClass($this, Zend_Http_Response::class, [
            'getBody' => [$this->once(), $jsonResponse, AnyBuilder::RETURN_VALUE],
            'getStatus' => [$this->once(), $jsonResponseStatus, AnyBuilder::RETURN_VALUE]
        ])->build();
        $httpClient = AnyBuilder::createForClass($this, Client::class, [
            'request' => [$this->once(), $zendHttpResponse, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->httpClientFactory = AnyBuilder::createForClass($this, ClientFactory::class, [
            'create' => [$this->once(), $httpClient, AnyBuilder::RETURN_VALUE]
        ])->build();
        $tokenInterface = AnyBuilder::createForClass($this, TokenInterface::class, [
            'setEnabled' => [$this->atMost(1), null, AnyBuilder::RETURN_SELF],
            'save' => [$this->atMost(1), null, AnyBuilder::RETURN_SELF],
            'getData' => [$this->atMost(1), [], AnyBuilder::RETURN_VALUE],
        ])->build();
        $this->tokenRepository = AnyBuilder::createForClass($this, TokenRepository::class, [
            'getEnabledToken' => [$this->atMost(1), $tokenInterface, AnyBuilder::RETURN_VALUE],
            'save' => [$this->atMost(1), $tokenInterface, AnyBuilder::RETURN_VALUE],
            'truncateTokenTable' => [$this->any()]
        ])->build();
        $this->collectionFactory = AnyBuilder::createForClass($this, CollectionFactory::class)->build();
        $token = AnyBuilder::createForClass($this, Token::class)->build();
        $this->tokenFactory = AnyBuilder::createForClass($this, TokenFactory::class, [
            'create' => [$this->atMost(1), $token, AnyBuilder::RETURN_VALUE]
        ])->build();

        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'httpClientFactory' => $this->httpClientFactory,
                'tokenRepository' => $this->tokenRepository,
                'collectionFactory' => $this->collectionFactory,
                'tokenFactory' => $this->tokenFactory
            ]
        );

        $this->stub = $this->objectManager->getObject(
            Authentication::class,
            $di
        );
    }

    public function testApiCallSuccess()
    {
        $expected = [
            'status' => 'success',
            'response' => ['success' => 200, 'response' => 'good authen'],
            'error' => false
        ];
        $this->initTest(
            '{"success":200, "response":"good authen"}',
            200
        );
        $report = AnyBuilder::createForClass($this, Report::class)->build();
        $response = $this->stub->doExecute($report, []);
        $this->assertEquals($expected, $response, 'should be an array with status success');
    }
}
