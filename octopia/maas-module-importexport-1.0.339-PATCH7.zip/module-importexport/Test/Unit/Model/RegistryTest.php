<?php

namespace Maas\ImportExport\Test\Unit\Model;

use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Maas\ImportExport\Model\Registry;

class RegistryTest extends TestCase
{

    /** @var Registry */
    public $instance;

    /** @var ObjectManager */
    private $objectManager;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->instance = $this->objectManager->getObject(
            Registry::class
        );
    }

    /**
     * @dataProvider registryValues
     */
    public function testIsCurrentlyImporting($value)
    {
        $this->instance->setCurrentlyImporting($value);
        $this->assertEquals($value, $this->instance->isCurrentlyImporting());
    }

    public function registryValues()
    {
        yield from [
            "Importing" => [true],
            "Not importing" => [false],
        ];
    }
}
