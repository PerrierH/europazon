<?php

namespace Maas\ImportExport\Test\Unit\Model\Config\Source;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Model\Config\Source\MqMode;
use Maas\Core\Model\Service\MessageQueue\Config;
use Maas\ImportExport\Test\Unit\Model\AbstractMqTestCase;

class MqModeTest extends AbstractMqTestCase
{
    public function testToOptionArray()
    {
        $configOptionsServiceMock = AnyBuilder::createForClass($this, Config::class, [
            'getBrokerCodes' => [1, [self::CONNECTION_DB, self::CONNECTION_RABBIT, self::CONNECTION_KAFKA]]
        ])->build();

        $instance = $this->getObject(MqMode::class, [
            'configOptionsService' => $configOptionsServiceMock
        ]);

        $this->assertEquals([
            ['value' => self::CONNECTION_DB, 'label' => __('Database')],
            ['value' => self::CONNECTION_RABBIT, 'label' => __('RabbitMQ')],
            ['value' => self::CONNECTION_KAFKA, 'label' => __('Other: %1', self::CONNECTION_KAFKA)]
        ], $instance->toOptionArray());
    }
}
