<?php

namespace Maas\ImportExport\Test\Unit\Model\Config\Source;

use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Maas\ImportExport\Model\Config\Source\Environment;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\App\Config\Initial\Reader;


/**
 * Used to uninstall registry from the database and deployment config
 */
class EnvironmentTest extends TestCase
{
    /** @var MockObject|Environment */
    private $environment;

    public function testEnvironment()
    {
        $reader = $this->createMock(Reader::class);
        $reader->expects($this->once())->method('read')
            ->will($this->returnValue([
                'data' => [
                    'default' => [
                        'maas_api' => [
                            'production' => ['value' => ''],
                            'test' => ['value' => ''],
                            'sandbox' => ['value' => ''],
                        ]
                    ],
                ],
            ]));

        $this->environment = (new ObjectManager($this))->getObject(
            Environment::class,
            [
                'initialConfigReader' => $reader
            ]
        );

        $this->assertEquals(
            [
                'production' => __('env_production'),
                'test' => __('env_test'),
                'sandbox' => __('env_sandbox'),
            ],
            $this->environment->toOptionArray()
        );
    }

}