<?php

namespace Maas\ImportExport\Test\Unit\Model\Import;

use Exception;
use Maas\Core\Model\Config;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Service\ProductImage;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Csv;
use Maas\Log\Model\ResourceModel\Report\Collection;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory;
use Maas\Offer\Api\Data\OfferDeliveryInterface;
use Maas\Offer\Api\Data\OfferDeliveryInterfaceFactory;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\Data\OfferInterfaceFactory;
use Maas\Offer\Api\Data\OfferInventoryInterface;
use Maas\Offer\Api\Data\OfferInventoryInterfaceFactory;
use Maas\Offer\Api\Data\OfferPriceInterface;
use Maas\Offer\Api\Data\OfferPriceInterfaceFactory;
use Maas\Offer\Api\OfferDeliveryRepositoryInterface;
use Maas\Offer\Api\OfferInventoryRepositoryInterface;
use Maas\Offer\Api\OfferPriceRepositoryInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Seller\Api\Data\SellerInterface;
use Maas\Seller\Api\Data\SellerInterfaceFactory;
use Maas\Seller\Api\SellerRepositoryInterface;
use Magento\Framework\Api\Filter;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchResults;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Stdlib\DateTime\DateTime;

/***
 * Class AbstractConsumerTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Import
 */
abstract class AbstractConsumerTest extends AbstractTestCase
{
    protected $messageMock;
    protected $reportMock;

    protected $reportLog = [];
    protected $reportWarningItemsCount = 0;
    protected $reportSuccessItemsCount = 0;
    protected $reportErrorItemsCount = 0;
    protected $reportDeltaWarningItemsCount = 0;
    protected $reportDeltaSuccessItemsCount = 0;
    protected $reportDeltaErrorItemsCount = 0;

    protected $reportRepository;
    protected $reportCollectionItems;
    protected $reportCollectionParams;
    protected $reportCollectionFactory;

    protected $message;

    protected $offerRepository;
    protected $offerPriceRepository;
    protected $offerPriceInterfaceFactory;
    protected $offerInventoryId;

    protected $filterBulder;
    protected $searchCriteriaBuilder;

    protected $reportId;
    protected $coreConfig;

    protected $triggerExceptionOnSave;
    protected $triggerExceptionOnOfferSave;
    protected $offerInventoryInterfaceFactory;
    protected $offerInventoryRepository;
    protected $csvLoggerManagementMock;
    protected $csvRows = [];
    protected $dateTimeMock;
    protected $offerId = null;
    protected $offerInterfaceFactory;
    protected $offerDeliveryRepository;
    protected $offerDeliveryId;
    protected $offerDeliveryMode;
    protected $offerDeliveryInterfaceFactory;
    protected $sellerRepository;
    protected $sellerInterfaceFactory;
    protected $sellerId;
    protected $productImageService;
    protected $uploadedImage = null;
    protected $uploadedImageExpectedCode = null;

    /***
     * @param int $reportId
     * @param string $messageClass
     * @param array $messageData
     * @param string $updatedAt
     */
    function initMessageMock($reportId, $messageClass, $messageData, $updatedAt)
    {
        $this->message = $this->getInstanceMock($messageClass, [], [
            'getReportId' => [$this->any(), $reportId],
            'getEntities' => [$this->any(), $this->createMessageEntities($messageData, $updatedAt)]
        ], false);
    }

    /**
     * @param array $messageData
     * @param string $updatedAt
     *
     * @return object[]
     */
    abstract function createMessageEntities($messageData, $updatedAt);

    function initReportData($reportId)
    {
        $this->reportId = $reportId;

        $report = $this->getInstanceMock(
            ReportInterface::class, [],
            [
                'log' => [
                    $this->any(),
                    function ($message) {
                        $this->reportLog[] = $message;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setWarningItemsCount' => [
                    $this->any(),
                    function ($c) {
                        echo "Setting Warning Items count $c\n";
                        $this->reportWarningItemsCount = $c;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getWarningItemsCount' => [
                    $this->any(),
                    function () {
                        return $this->reportWarningItemsCount;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setSuccessItemsCount' => [
                    $this->any(),
                    function ($c) {
                        echo "Setting Warning Items count $c\n";
                        $this->reportSuccessItemsCount = $c;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getSuccessItemsCount' => [
                    $this->any(),
                    function () {
                        return $this->reportSuccessItemsCount;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setErrorItemsCount' => [
                    $this->any(),
                    function ($c) {
                        $this->reportErrorItemsCount = $c;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getErrorItemsCount' => [
                    $this->any(),
                    function () {
                        return $this->reportErrorItemsCount;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getId' => [
                    $this->any(),
                    function () {
                        return $this->reportId;
                    },
                    self::RETURN_CALLBACK
                ],


                'setDeltaSuccessItemsCount' => [
                    $this->any(),
                    function ($c) {
                        $this->reportDeltaSuccessItemsCount = $c;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getDeltaSuccessItemsCount' => [
                    $this->any(),
                    function () {
                        return $this->reportDeltaSuccessItemsCount;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setDeltaWarningItemsCount' => [
                    $this->any(),
                    function ($c) {
                        $this->reportDeltaWarningItemsCount = $c;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getDeltaWarningItemsCount' => [
                    $this->any(),
                    function () {
                        return $this->reportDeltaWarningItemsCount;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setDeltaErrorItemsCount' => [
                    $this->any(),
                    function ($c) {
                        $this->reportDeltaErrorItemsCount = $c;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'getDeltaErrorItemsCount' => [
                    $this->any(),
                    function () {
                        return $this->reportDeltaErrorItemsCount;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],

            ], false);

        $this->reportCollectionItems = [$report];

        $reportRepositoryMethods = $reportId ? [
            'get' => [$this->any(), $report, self::RETURN_REFERENCE, [$reportId]],
            'save' => [
                $this->any(),
                function ($object) {
                    if (!$this->reportId) {
                        $this->reportId = 1;
                    }
                    if ($this->reportDeltaSuccessItemsCount > 0) {
                        $this->reportSuccessItemsCount += $this->reportDeltaSuccessItemsCount;
                        $this->reportDeltaSuccessItemsCount = 0;
                    }
                    if ($this->reportDeltaWarningItemsCount > 0) {
                        $this->reportWarningItemsCount += $this->reportDeltaWarningItemsCount;
                        $this->reportDeltaWarningItemsCount = 0;
                    }
                    if ($this->reportDeltaErrorItemsCount > 0) {
                        $this->reportErrorItemsCount += $this->reportDeltaErrorItemsCount;
                        $this->reportDeltaErrorItemsCount = 0;
                    }
                },
                self::RETURN_CALLBACK
            ]
        ] : [];

        $this->reportRepository = $this->getInstanceMock(ReportRepositoryInterface::class, [], $reportRepositoryMethods,
            false);

        $this->reportCollectionParams = ['filters' => [], 'page_size' => 100];
        $reportCollection = $this->getInstanceMock(Collection::class, null, [
            'addFieldToFilter' => [],
            'setPageSize' => [],
            'getSize' => [$this->any(), count($this->reportCollectionItems)],
            'getFirstItem' => [$this->any(), reset($this->reportCollectionItems)]
        ], false);

        $reportCollection->expects($this->any())->method('addFieldToFilter')->willReturnCallback(function (
            $key,
            $value
        ) use (&$reportCollection) {
            $this->reportCollectionParams['filters'][$key] = $value;
            return $reportCollection;
        });
        $reportCollection->expects($this->any())->method('setPageSize')->willReturnCallback(function ($pageSize) use (
            &
            $reportCollection
        ) {
            $this->reportCollectionParams['page_size'] = $pageSize;
            return $reportCollection;
        });

        $this->reportCollectionFactory = $this->getInstanceMock(CollectionFactory::class,
            [], [
                'create' => [$this->any(), $reportCollection]
            ]);
    }

    protected function initSearchCriteriaBuilders()
    {
        $filterMock = $this->getInstanceMock(Filter::class, [], []);
        $searchCriteriaMock = $this->getInstanceMock(SearchCriteria::class, [], []);

        $this->filterBulder = $this->getInstanceMock(FilterBuilder::class, [], [
            'setField' => [$this->any(), null, self::RETURN_SELF],
            'setConditionType' => [$this->any(), null, self::RETURN_SELF],
            'setValue' => [$this->any(), null, self::RETURN_SELF],
            'create' => [$this->any(), $filterMock, self::RETURN_REFERENCE]
        ]);
        $this->searchCriteriaBuilder = $this->getInstanceMock(SearchCriteriaBuilder::class, [], [
            'addFilters' => [$this->any(), null, self::RETURN_SELF],
            'create' => [$this->any(), $searchCriteriaMock, self::RETURN_REFERENCE]
        ]);
    }

    protected function initOfferPriceFactory()
    {
        $this->offerPriceInterfaceFactory = $this->getInstanceMock(OfferPriceInterfaceFactory::class,
            [], [
                'create' => [$this->any(), $this->getInstanceMock(OfferPriceInterface::class, [], [], false)]
            ]);
    }

    /**
     * @param int $offerId
     * @param bool $offerExists
     * @param array $additionalData
     */
    protected function initOfferRepository($offerId, $offerExists, $additionalData = [])
    {
        $this->offerId = $offerId;
        if ($offerExists) {
            $offerMethods = [
                'getId' => [
                    $this->any(),
                    function () {
                        return $this->offerId;
                    },
                    self::RETURN_CALLBACK
                ],
                'setId' => [],
            ];
            foreach ($additionalData as $key => $value) {
                $offerMethods[$key] = [$this->any(), $value];
            }
            $offerMock = $this->getInstanceMock(OfferInterface::class, [], $offerMethods, false);
            $offerMock->expects($this->any())->method('setId')->willReturnCallback(function ($id) use (&$offerMock) {
                $this->offerId = $id;
                return $offerMock;
            });

            $offerItemsList = $this->getInstanceMock(SearchResults::class, [], [
                'getItems' => [$this->any(), [$offerMock]]
            ], false);
        } else {
            $offerMock = null;
            $offerItemsList = $this->getInstanceMock(SearchResults::class, [], [
                'getItems' => [$this->any(), []]
            ], false);
        }
        $this->offerRepository = $this->getInstanceMock(OfferRepositoryInterface::class, [], [
            'get' => [
                $this->any(),
                function ($requestedId) use ($offerExists, $offerMock) {
                    if ($offerExists) {
                        return $offerMock;
                    }
                    throw new NoSuchEntityException('no offer');
                },
                self::RETURN_CALLBACK,
                [$offerId]
            ],
            'getList' => [$this->any(), $offerItemsList],
            'save' => [
                $this->atMost(2),
                function ($object) {
                    if ($this->triggerExceptionOnOfferSave) {
                        throw new Exception('Cannot save');
                    }
                    if (!$this->offerId) {
                        $this->offerId = 1;
                    }
                    return $object;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
    }

    protected function initOfferInventoryFactory()
    {
        $instance = $this->getInstanceMock(OfferInventoryInterface::class, [], [
            'getId' => [
                $this->any(),
                function () {
                    return $this->offerInventoryId;
                },
                self::RETURN_CALLBACK
            ],
            'setStock' => [$this->any(), null, self::RETURN_SELF],
            'setSupplyMode' => [$this->any(), null, self::RETURN_SELF],
            'setSyncDate' => [$this->any(), null, self::RETURN_SELF]
        ], false);
        $this->offerInventoryInterfaceFactory = $this->getInstanceMock(OfferInventoryInterfaceFactory::class,
            [], [
                'create' => [
                    $this->any(),
                    function () use (&$instance) {
                        $this->offerInventoryId = null;
                        return $instance;
                    },
                    self::RETURN_CALLBACK
                ]
            ]);
    }

    protected function initOfferFactory()
    {
        $this->offerInterfaceFactory = $this->getInstanceMock(OfferInterfaceFactory::class,
            [], [
                'create' => [$this->any(), $this->getInstanceMock(OfferInterface::class, [], [], false)]
            ]);
    }

    /**
     * @param string $entityUpdatedAt
     * @param bool $offerExists
     */
    protected function initOfferInventoryRepository($entityUpdatedAt, $offerExists)
    {
        $items = $entityUpdatedAt ? [
            $this->getInstanceMock(OfferInventoryInterface::class, [], [
                'getId' => [
                    $this->any(),
                    function () {
                        return $this->offerInventoryId;
                    },
                    self::RETURN_CALLBACK
                ],
                'getSyncDate' => [$this->any(), $entityUpdatedAt],
                'setStock' => [$this->any(), null, self::RETURN_SELF],
                'setSupplyMode' => [$this->any(), null, self::RETURN_SELF],
                'setSyncDate' => [$this->any(), null, self::RETURN_SELF]
            ], false)
        ] : [];

        $searchResult = $this->getInstanceMock(SearchResults::class, [], [
            'getItems' => [
                $offerExists ? 1 : 0,
                function () use ($items) {
                    $this->offerInventoryId = 1;
                    return $items;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
        $this->offerInventoryRepository = $this->getInstanceMock(OfferInventoryRepositoryInterface::class, [], [
            'getList' => [$this->any(), $searchResult],
            'save' => [
                $this->atMost(2),
                function ($object) {
                    if ($this->triggerExceptionOnSave) {
                        throw new Exception('Cannot save');
                    }
                    $this->offerInventoryId = 1;
                    return $object;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
    }

    /**
     * @param bool $entityExists
     * @param bool $offerExists
     */
    protected function initOfferDeliveryRepository($entityExists, $offerExists)
    {
        $item = $this->getInstanceMock(OfferDeliveryInterface::class, [], [
            'getId' => [
                $this->any(),
                function () {
                    return $this->offerDeliveryId;
                },
                self::RETURN_CALLBACK
            ],
            'setInventoryId' => [$this->any(), null, self::RETURN_SELF],
            'setMode' => [],
            'getMode' => [
                $this->any(),
                function () {
                    return $this->offerDeliveryMode;
                },
                self::RETURN_CALLBACK
            ],
            'setMinDelay' => [$this->any(), null, self::RETURN_SELF],
            'setMaxDelay' => [$this->any(), null, self::RETURN_SELF],
            'setShippingCost' => [$this->any(), null, self::RETURN_SELF]
        ], false);
        $item->expects($this->any())->method('setMode')->willReturnCallback(function ($mode) use (&$item) {
            $this->offerDeliveryMode = $mode;
            return $item;
        });
        $items = $entityExists ? [$item] : [];

        $searchResult = $this->getInstanceMock(SearchResults::class, [], [
            'getItems' => [
                $this->any(),
                function () use ($items) {
                    $this->offerDeliveryId = 1;
                    $this->offerDeliveryMode = 'standard';
                    return $items;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
        $this->offerDeliveryRepository = $this->getInstanceMock(OfferDeliveryRepositoryInterface::class, [], [
            'getList' => [$this->any(), $searchResult],
            'save' => [
                $this->atMost(2),
                function ($object) {
                    if ($this->triggerExceptionOnSave) {
                        throw new Exception('Cannot save');
                    }
                    $this->offerDeliveryId = 1;
                    return $object;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
    }

    protected function initOfferDeliveryFactory()
    {
        $instance = $this->getInstanceMock(OfferDeliveryInterface::class, [], [
            'getId' => [
                $this->any(),
                function () {
                    return $this->offerDeliveryId;
                },
                self::RETURN_CALLBACK
            ],
            'setInventoryId' => [$this->any(), null, self::RETURN_SELF],
            'setMode' => [],
            'getMode' => [
                $this->any(),
                function () {
                    return $this->offerDeliveryMode;
                },
                self::RETURN_CALLBACK
            ],
            'setMinDelay' => [$this->any(), null, self::RETURN_SELF],
            'setMaxDelay' => [$this->any(), null, self::RETURN_SELF],
            'setShippingCost' => [$this->any(), null, self::RETURN_SELF]
        ], false);
        $instance->expects($this->any())->method('setMode')->willReturnCallback(function ($mode) use (&$instance) {
            $this->offerDeliveryMode = $mode;
            return $instance;
        });
        $this->offerDeliveryInterfaceFactory = $this->getInstanceMock(OfferDeliveryInterfaceFactory::class,
            [], [
                'create' => [
                    $this->any(),
                    function () use (&$instance) {
                        $this->offerDeliveryId = null;
                        $this->offerDeliveryMode = null;
                        return $instance;
                    },
                    self::RETURN_CALLBACK
                ]
            ]);
    }

    protected function initSellerFactory()
    {
        $this->sellerInterfaceFactory = $this->getInstanceMock(SellerInterfaceFactory::class,
            [], [
                'create' => [
                    $this->any(),
                    $this->getInstanceMock(SellerInterface::class, [], [
                        'getId' => [
                            $this->any(),
                            function () {
                                return $this->sellerId;
                            },
                            self::RETURN_CALLBACK
                        ],
                        'setMaasEntityId' => [$this->any(), null, self::RETURN_SELF]
                    ], false)
                ]
            ]);
    }

    /**
     * @param string $entityUpdatedAt
     * @param string $sellerId
     */
    protected function initSellerRepository($entityUpdatedAt, $sellerId)
    {
        $this->sellerId = $sellerId;
        $items = $sellerId ? [
            $this->getInstanceMock(SellerInterface::class, [], [
                'getId' => [
                    $this->any(),
                    function () {
                        return $this->sellerId;
                    },
                    self::RETURN_CALLBACK
                ],
                'getSyncDate' => [$this->any(), $entityUpdatedAt],
                'setMaasEntityId' => [$this->any(), null, self::RETURN_SELF]
            ], false)
        ] : [];

        $searchResult = $this->getInstanceMock(SearchResults::class, [], [
            'getItems' => [$this->any(), $items]
        ], false);
        $this->sellerRepository = $this->getInstanceMock(SellerRepositoryInterface::class, [], [
            'getList' => [$this->any(), $searchResult],
            'save' => [
                $this->atMost(2),
                function ($object) {
                    if ($this->triggerExceptionOnSave) {
                        throw new Exception('Cannot save');
                    }
                    if (!$this->sellerId) {
                        $this->sellerId = 1;
                    }
                    return $object;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
    }

    /**
     * @param string $entityUpdatedAt
     * @param bool $offerExists
     */
    protected function initOfferPriceRepository($entityUpdatedAt, $offerExists)
    {
        $items = $entityUpdatedAt ? [
            $this->getInstanceMock(OfferPriceInterface::class, [], [
                'getSyncDate' => [$this->any(), $entityUpdatedAt]
            ], false)
        ] : [];

        $searchResult = $this->getInstanceMock(SearchResults::class, [], [
            'getItems' => [$offerExists ? 1 : 0, $items]
        ], false);
        $this->offerPriceRepository = $this->getInstanceMock(OfferPriceRepositoryInterface::class, [], [
            'getList' => [$this->any(), $searchResult],
            'save' => [
                $this->atMost(2),
                function ($object) {
                    if ($this->triggerExceptionOnSave) {
                        throw new Exception('Cannot save');
                    }
                    return $object;
                },
                self::RETURN_CALLBACK
            ]
        ], false);
    }

    /**
     * @param string $code
     * @param int $expectedUploadCalls
     */
    protected function initProductImageService($code, $expectedUploadCalls)
    {
        $this->uploadedImageExpectedCode = $code;

        $this->productImageService = $this->getInstanceMock(ProductImage::class, [], [
            'upload' => [
                $expectedUploadCalls ? 1 : 0,
                function ($url, $code) {
                    if ($code != $this->uploadedImageExpectedCode) {
                        throw new Exception('Unexpected image upload code');
                    }
                    $this->uploadedImage = $url;
                    return $url;
                },
                self::RETURN_CALLBACK
            ]
        ]);
    }

    /**
     * @param bool $perfEnabled
     */
    protected function initCoreConfig($perfEnabled)
    {
        $this->coreConfig = $this->getInstanceMock(Config::class, [], [
            'isInventoryPerfEnabled' => [$this->any(), $perfEnabled],
            'isPricePerfEnabled' => [$this->any(), $perfEnabled],
            'isDeliveryPerfEnabled' => [$this->any(), $perfEnabled],

            'isOfferPerfEnabled' => [$this->any(), $perfEnabled],
            'isImagesOfferImportPerfEnabled' => [$this->any(), $perfEnabled],
            'isSellerPerfEnabled' => [$this->any(), $perfEnabled],
            'isDeleteOfferPerfEnabled' => [$this->any(), $perfEnabled],
        ]);
    }

    protected function initCsvLogger()
    {
        $csvLoggerMock = $this->getInstanceMock(Csv::class, [], [
            'newRow' => [
                $this->any(),
                function ($row) {
                    $this->csvRows[] = $row;
                },
                self::RETURN_CALLBACK
            ],
            'storeMicrotimeStart' => [
                $this->any(),
                function ($field) {
                    end($this->csvRows)[$field] = 'microtime';
                },
                self::RETURN_CALLBACK
            ],
            'saveRow' => [
                $this->any(),
                function () {

                },
                self::RETURN_CALLBACK
            ],
        ]);

        $this->csvLoggerManagementMock = $this->getInstanceMock(CsvLoggerManagement::class, [],
            [
                'getCsvLogger' => [$this->any(), $csvLoggerMock, self::RETURN_REFERENCE]
            ]);
    }

    protected function initDateTime()
    {
        $this->dateTimeMock = $this->getInstanceMock(DateTime::class, [], [
            'timestamp' => [
                $this->any(),
                function ($value) {
                    return strtotime($value);
                },
                self::RETURN_CALLBACK
            ]
        ]);
    }
}