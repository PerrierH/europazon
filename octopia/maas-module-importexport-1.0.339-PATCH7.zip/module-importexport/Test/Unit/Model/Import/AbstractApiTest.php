<?php

namespace Maas\ImportExport\Test\Unit\Model\Import;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Model\Config as MaasConfig;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Test\Builder\Model\AbstractApiBuilder;
use Maas\Log\Api\Data\JobInterface;
use Maas\Log\Api\Data\JobSearchResultsInterface;
use Maas\Log\Api\JobRepositoryInterface;
use Maas\Log\Model\Report;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Serialize\Serializer\Json;
use PHPUnit\Framework\TestCase;
use Magento\Framework\Api\Filter;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Maas\Log\Api\ReportRepositoryInterface as ReportRepository;
use Maas\Log\Api\Data\ReportInterface;

/**
 * Class AbstractApiTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Import\Price
 */
class AbstractApiTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockBuilder
     */
    private $apiBuilder;

    /**
     * @var array
     */
    private $dependencies;

    public function setup()
    {
        $abstractApiBuilder = AbstractApiBuilder::create($this);

        $this->apiBuilder = $this->getMockBuilder(AbstractApi::class);
        $this->dependencies = $abstractApiBuilder->getDi();
        $searchCriteria = AnyBuilder::createForClass($this, SearchCriteria::class)->build();
        $searchCriteriaBuilder = AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'addFilters' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'create' => [$this->any(), $searchCriteria],
        ])->build();
        $this->dependencies['searchCriteriaBuilder'] = $searchCriteriaBuilder;
        $filter = AnyBuilder::createForClass($this, Filter::class)->build();
        $filterBuilder = AnyBuilder::createForClass($this, FilterBuilder::class, [
            'setConditionType' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'setField' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'setValue' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'create' => [$this->any(), $filter],
        ])->build();

        $this->dependencies['filterBuilder'] = $filterBuilder;
        $tokenFactory = $this->dependencies['tokenFactory'];
        unset($this->dependencies['tokenFactory']);
        $this->dependencies['tokenFactory'] = $tokenFactory;
    }

    /**
     * @dataProvider getEndPointUrlProvider
     *
     * @param string $url
     * @param array|null $args
     * @param string $expected
     */
    public function testGetEndPointUrl($url, $args, $expected)
    {
        $configProvider = $this->getMockBuilder(MaasConfig::class)
            ->disableOriginalConstructor()
            ->getMock();
        $configProvider->expects($this->any())->method('getProductsApiUrl')->willReturn($url);

        $this->dependencies['configProvider'] = $configProvider;

        $api = $this->apiBuilder
            ->setConstructorArgs($this->dependencies)
            ->setMethods(['getArgs'])
            ->getMock();
        $api->expects($this->any())->method('getArgs')->willReturn($args);

        $this->assertEquals($expected, $api->getEndPointUrl());
    }

    public function getEndPointUrlProvider()
    {
        yield 'url with no parameters' => [
            'url' => 'http://test.test.com',
            'args' => [],
            'expected' => 'http://test.test.com',
        ];
        yield 'url with parameters' => [
            'url' => 'http://test.test.com',
            'args' => ['arg1' => 'value', 'arg2' => 'other value'],
            'expected' => 'http://test.test.com?arg1=value&arg2=other value',
        ];
    }

    /**
     * @dataProvider startProcessProvider
     *
     * @param $launched
     * @param $expectedException
     */
    public function testStartProcess($launched, $expectedException)
    {
        $api = $this->apiBuilder
            ->setConstructorArgs($this->dependencies)
            ->setMethods(['checkIfCommandLaunched', 'initLog'])
            ->getMock();
        $api->expects($this->once())->method('checkIfCommandLaunched')->willReturn($launched);
        $report = AnyBuilder::createForClass($this, Report::class, ['getId' => [$this->any(), 2]])->build();
        $api->expects($this->atMost(1))->method('initLog')->willReturn($report);

        if ($expectedException) {
            $this->expectException(AlreadyExistsException::class);
            $api->startProcess();
        } else {
            $this->assertEquals($api->startProcess(), $report);
        }
    }

    public function startProcessProvider()
    {
        yield 'no import currently lanched' => [
            'launched' => false,
            'expectedException' => false,
        ];
        yield 'import already lanched' => [
            'launched' => true,
            'expectedException' => true,
        ];
    }

    /**
     * @param $jobInterface
     */
    public function testGetApiResponse()
    {
        $serializer = $this->createMock(Json::class);
        $serializer->expects($this->once())->method('unserialize')->willReturn('test');

        $this->dependencies['serializer'] = $serializer;
        $api = $this->apiBuilder
            ->setConstructorArgs($this->dependencies)
            ->setMethods(['setArgs', 'apiCall'])
            ->getMock();
        $api->expects($this->once())->method('setArgs')->willReturnSelf();
        $api->expects($this->once())->method('apiCall')->willReturn(['response' => 'serialized test', 'status' => 200]);

        $this->assertEquals('test', $api->getApiResponse([]));
    }
}
