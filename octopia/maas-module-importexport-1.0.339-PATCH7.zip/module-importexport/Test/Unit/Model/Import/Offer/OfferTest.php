<?php

namespace Maas\ImportExport\Test\Unit\Model\Import\Price;

use Maas\ImportExport\Model\Import\Offer\Offer;
use Maas\ImportExport\Test\Unit\Model\Import\AbstractImportExportApiTest;

/**
 * Class OfferTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Import\Price
 */
class OfferTest extends AbstractImportExportApiTest
{
    /**
     * @return string
     */
    protected function getInstanceClass()
    {
        return Offer::class;
    }

    /**
     * @return string
     */
    protected function getRequestEndpoint()
    {
        return Offer::API_REQUEST_ENDPOINT;
    }
}