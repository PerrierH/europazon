<?php

namespace Maas\ImportExport\Test\Unit\Model\Import\Offer;

use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Maas\ImportExport\Api\Data\Offer\ConditionInterface;
use Maas\ImportExport\Api\Data\Offer\OfferImagesInterface;
use Maas\ImportExport\Api\Data\Offer\OfferInterface;
use Maas\ImportExport\Api\Data\Offer\SellerInterface as ImporExportSellerInterface;
use Maas\ImportExport\Api\Data\OfferImportMessageInterface;
use Maas\ImportExport\Model\Import\Offer\Consumer;
use Maas\ImportExport\Test\Unit\Model\Import\AbstractConsumerTest;

/**
 * Class ConsumerTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Import\Price
 */
class ConsumerTest extends AbstractConsumerTest
{
    const EARLIER_DATE = '2021-06-01';
    const LATER_DATE = '2021-07-01';

    /**
     * @param int $reportId
     * @param bool $entityIsUpdated
     * @param bool $perfEnabled
     * @param bool $exceptionOnSave
     * @param bool $importedIsNewer
     * @param string $offerStatus
     * @param bool $sellerExists
     * @param array|null $images
     * @param int $expectedSuccess
     * @param int $expectedWarning
     * @param int $expectedError
     * @param string $expectedUploadedImage
     *
     * @dataProvider getTestProcessData
     */
    public function testProcessReport(
        $reportId,
        $entityIsUpdated,
        $perfEnabled,
        $exceptionOnSave,
        $importedIsNewer,
        $offerStatus,
        $sellerExists,
        $images,
        $expectedSuccess,
        $expectedWarning,
        $expectedError,
        $expectedUploadedImage
    ) {
        $importedUpdatedAt = $importedIsNewer ? self::LATER_DATE : self::EARLIER_DATE;
        if ($entityIsUpdated) {
            $existingOfferUpdatedAt = $importedIsNewer ? self::EARLIER_DATE : self::LATER_DATE;
        } else {
            $existingOfferUpdatedAt = null;
        }

        $messageData = [
            [
                'offer_id' => 5,
                'status' => $offerStatus,
                'seller_id' => 6,
                'seller_name' => 'Some Seller',
                'images' => $images
            ]
        ];

        $this->triggerExceptionOnOfferSave = $exceptionOnSave;
        $this->uploadedImageExpectedCode = 'maas_offer';

        $this->initReportData($reportId);
        $this->initMessageMock($reportId, OfferImportMessageInterface::class, $messageData,
            $importedUpdatedAt);
        $this->initOfferRepository($entityIsUpdated ? 5 : null, $entityIsUpdated,
            ['getSyncDate' => $existingOfferUpdatedAt]);
        $this->initSearchCriteriaBuilders();
        $this->initCoreConfig($perfEnabled);
        $this->initCsvLogger();
        $this->initDateTime();
        $this->initSellerRepository($existingOfferUpdatedAt, $sellerExists ? 6 : null);
        $this->initSellerFactory();
        $this->initOfferFactory();
        $this->initProductImageService('maas_offer', $expectedUploadedImage ? 1 : 0);

        $instance = $this->getObject(Consumer::class, [
            'reportCollectionFactory' => $this->reportCollectionFactory,
            'reportRepository' => $this->reportRepository,

            'sellerRepository' => $this->sellerRepository,
            'sellerInterfaceFactory' => $this->sellerInterfaceFactory,

            'offerRepository' => $this->offerRepository,
            'offerFactory' => $this->offerInterfaceFactory,
            'filterBuilder' => $this->filterBulder,
            'searchCriteriaBuilder' => $this->searchCriteriaBuilder,
            'coreConfig' => $this->coreConfig,
            'csvLoggerManagement' => $this->csvLoggerManagementMock,
            'dateTime' => $this->dateTimeMock,
            'productImageService' => $this->productImageService
        ]);
        $instance->process($this->message);

        $this->assertEquals($expectedSuccess, $this->reportSuccessItemsCount + $this->reportDeltaSuccessItemsCount);
        $this->assertEquals($expectedWarning, $this->reportWarningItemsCount + $this->reportDeltaWarningItemsCount);
        $this->assertEquals($expectedError, $this->reportErrorItemsCount + $this->reportDeltaErrorItemsCount);
        $this->assertEquals($expectedUploadedImage, $this->uploadedImage);

    }

    /**
     * @return array[]
     */
    public function getTestProcessData()
    {
        return [
            'id zero' => [
                'reportId' => 0,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id not zero' => [
                'reportId' => 1,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id zero, update' => [
                'reportId' => 0,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id not zero, update' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id zero, exception on save' => [
                'reportId' => 0,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 0,
                'expectedWarning' => 0,
                'expectedError' => 1,
                'expectedUploadedImage' => null
            ],
            'id not zero, exception on save' => [
                'reportId' => 1,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 0,
                'expectedWarning' => 0,
                'expectedError' => 1,
                'expectedUploadedImage' => null
            ],
            'id zero, update, exception on save' => [
                'reportId' => 0,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 0,
                'expectedWarning' => 0,
                'expectedError' => 1,
                'expectedUploadedImage' => null
            ],
            'id not zero, update, exception on save' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 0,
                'expectedWarning' => 0,
                'expectedError' => 1,
                'expectedUploadedImage' => null
            ],

            'id zero, old data' => [
                'reportId' => 0,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id not zero, old data' => [
                'reportId' => 1,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id zero, update, old data' => [
                'reportId' => 0,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id not zero, update, old data' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id zero, exception on save, old data' => [
                'reportId' => 0,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 0,
                'expectedWarning' => 0,
                'expectedError' => 1,
                'expectedUploadedImage' => null
            ],
            'id not zero, exception on save, old data' => [
                'reportId' => 1,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 0,
                'expectedWarning' => 0,
                'expectedError' => 1,
                'expectedUploadedImage' => null
            ],
            'id zero, update, exception on save, old data' => [
                'reportId' => 0,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'id not zero, update, exception on save, old data' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => true,
                'importedIsNewer' => false,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'deleting offer' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => false,
                'offerStatus' => null,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'not importing offer' => [
                'reportId' => 1,
                'entityIsUpdated' => false,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => false,
                'offerStatus' => null,
                'sellerExists' => true,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'new seller' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => false,
                'images' => null,
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => null
            ],
            'with images, use large' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => ['small' => 'a.jpg', 'medium' => 'b.jpg', 'large' => 'c.jpg'],
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => 'c.jpg'
            ],
            'with images, use medium' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => ['small' => 'a.jpg', 'medium' => 'b.jpg'],
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => 'b.jpg'
            ],
            'with images, use small' => [
                'reportId' => 1,
                'entityIsUpdated' => true,
                'perfEnabled' => true,
                'exceptionOnSave' => false,
                'importedIsNewer' => true,
                'offerStatus' => Consumer::STATUS_ACTIVE,
                'sellerExists' => true,
                'images' => ['small' => 'a.jpg'],
                'expectedSuccess' => 1,
                'expectedWarning' => 0,
                'expectedError' => 0,
                'expectedUploadedImage' => 'a.jpg'
            ]
        ];

    }

    /**
     * @param array $messageData
     * @param string $updatedAt
     *
     * @return array
     */
    function createMessageEntities($messageData, $updatedAt)
    {
        $entities = [];
        foreach ($messageData as $entityData) {
            if ($entityData['images']) {
                $imagesMethods = [];
                foreach ([
                             'getLarge' => $entityData['images']['large'] ?? null,
                             'getMedium' => $entityData['images']['medium'] ?? null,
                             'getSmall' => $entityData['images']['small'] ?? null,
                         ] as $getter => $value) {
                    $imagesMethods[$getter] = [
                        $this->atMost(2),
                        $this->getInstanceMock(ImageInterface::class,
                            [], [
                                'getUrl' => [$this->atMost(5), $value]
                            ], false)
                    ];

                }

                $images = $this->getInstanceMock(OfferImagesInterface::class, [], $imagesMethods, false);
            } else {
                $images = null;
            }


            $entities[] = $this->getInstanceMock(OfferInterface::class, [], [
                'getOfferId' => [$this->any(), $entityData['offer_id']],
                'getUpdatedAt' => [$this->any(), $updatedAt],
                'getStatus' => [$this->any(), $entityData['status']],
                'getSeller' => [
                    $this->any(),
                    $this->getInstanceMock(ImporExportSellerInterface::class, [], [
                        'getId' => [$this->any(), $entityData['seller_id']],
                        'getName' => [$this->any(), $entityData['seller_name']]
                    ], false)
                ],
                'getCondition' => [$this->any(), $this->getInstanceMock(ConditionInterface::class, [], [], false)],
                'getImages' => [$this->atMost(2), $images]
            ], false);
        }
        return $entities;
    }
}