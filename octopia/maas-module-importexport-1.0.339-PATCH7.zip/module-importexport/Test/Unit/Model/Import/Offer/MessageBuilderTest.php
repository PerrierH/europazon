<?php

namespace Maas\ImportExport\Test\Unit\Model\Import\Offer;

use Maas\ImportExport\Model\Import\Offer\MessageBuilder;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Maas\ImportExport\Model\Config\Proxy;
use Maas\ImportExport\Api\Data\OfferImportMessageInterfaceFactory;
use Maas\ImportExport\Model\Import\Offer\Message;

/**
 * Class MessageBuilderTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Import\Offer
 */
class MessageBuilderTest extends TestCase
{

    /** @var MessageBuilder */
    private $instance;
    /** @var ObjectManager */
    private $objectManager;
    /** @var int */
    private $numberPerMessage;

    private $entities;
    private $reportId;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $config = AnyBuilder::createForClass(
            $this,
            Proxy::class,
            [
                'getOffersNumberPerMessage' => [
                    $this->any(),
                    function () {
                        return $this->numberPerMessage;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $message = AnyBuilder::createForClass(
            $this,
            Message::class,
            [
                'setReportId' => [
                    $this->any(),
                    function($reportId){
                        $this->reportId = $reportId;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'setEntities' => [
                    $this->any(),
                    function($entities){
                        $this->entities = $entities;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $factory = AnyBuilder::createForClass(
            $this,
            OfferImportMessageInterfaceFactory::class,
            [
                'create' => [
                    $this->any(),
                    $message
                ]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            MessageBuilder::class,
            [
                'factory' => $factory,
                'config' => $config
            ]
        );
    }

    public function testAddEntity(){
        $this->assertEquals(0, $this->instance->getEntityCount());

        $this->instance->addEntity('Entity1');
        $this->assertEquals(1, $this->instance->getEntityCount());

        $this->instance->addEntity('Entity2');
        $this->instance->addEntity('Entity3');
        $this->assertEquals(3, $this->instance->getEntityCount());
    }

    /**
     * @param int $nbEntities
     * @param int $numberPerMessage
     * @param bool $expected
     *
     * @dataProvider providerIsSpaceLeft
     */
    public function testIsSpaceLeft($nbEntities, $numberPerMessage, $expected)
    {
        for($i=0; $i<$nbEntities; $i++){
            $this->instance->addEntity('entity'.$i);
        }
        $this->numberPerMessage = $numberPerMessage;

        $result = $this->instance->isSpaceLeft('entity');

        $this->assertEquals($expected, $result);
    }

    public function providerIsSpaceLeft()
    {
        yield from [
            [3, 4, true],
            [2, 2, false],
            [4, 3, false]
        ];
    }

    /**
     * @param $reportId
     * @param $entities
     *
     * @dataProvider providerBuild
     */
    public function testBuild($reportId, $entities){

        $this->instance->setReportId($reportId);
        foreach($entities as $entity){
            $this->instance->addEntity($entity);
        }

        $this->instance->build();

        $this->assertEquals($reportId, $this->reportId);
        $this->assertEquals(count($entities), count($this->entities));
    }

    public function providerBuild()
    {
        yield from [
            [3, ['entity1', 'entity2']],
            [2, []],
            [4, ['entity1', 'entity2', 'entity3', 'entity4', 'entity5']]
        ];
    }

}
