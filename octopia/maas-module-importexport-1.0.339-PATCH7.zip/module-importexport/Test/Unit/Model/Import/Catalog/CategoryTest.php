<?php

namespace Maas\ImportExport\Test\Unit\Model\Import\Catalog;

use Magento\Eav\Api\Data\AttributeSetInterface;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Model\Import\Catalog\Category;
use PHPUnit\Framework\TestCase;
use Maas\Catalog\Model\Config as ConfigModel;
use Maas\Core\Model\TokenRepository;
use Symfony\Component\Console\Helper\ProgressBarFactory;
use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Maas\ImportExport\Model\Config;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Service\CreateAttributeSet;
use Maas\Log\Api\ReportRepositoryInterface as ReportRepository;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Catalog\Model\Category as CategoryModel;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\State;
use Magento\Framework\HTTP\ZendClientFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Store\Model\App\Emulation;
use Maas\ImportExport\Model\Service\CreateProductAttribute;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Maas\Core\Model\TokenFactory;
use ReflectionClass;
use stdClass;
use Symfony\Component\Console\Output\OutputInterface;

class CategoryTest extends TestCase
{
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $httpClientFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $configProvider;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $reportFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $reportRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $reportCollectionFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $tokenRepository;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $categoryFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $emulation;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $state;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $catalogConfig;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $progressBarFactory;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $cache;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $csvLoggerManagement;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $createProductAttribute;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $createAttributeSet;
    /**
     * @var Category
     */
    private $stub;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $dateTime;
    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $tokenFactory;

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $output;

    public function initializedArgumentConstructor($isCategory = true)
    {
        $attributeSet = AnyBuilder::createForClass($this, AttributeSetInterface::class)->build();
        $productAttributeInterface = AnyBuilder::createForClass($this, ProductAttributeInterface::class)->build();
        $category = AnyBuilder::createForClass($this, CategoryModel::class, [
            'loadByAttribute' => [$this->any(), null, $isCategory ? AnyBuilder::RETURN_SELF : AnyBuilder::RETURN_VALUE],
            'save' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'move' => [$this->any(), null, AnyBuilder::RETURN_SELF],
        ])->build();
        $this->httpClientFactory = AnyBuilder::createForClass($this, ZendClientFactory::class)->build();
        $this->configProvider = AnyBuilder::createForClass($this, Config::class, [
            'getCategoryApiUrl' => [$this->any(), 'http://daystowote.cluster023.hosting.ovh.net']
        ])->build();
        $this->reportFactory = AnyBuilder::createForClass($this, ReportFactory::class)->build();
        $this->reportRepository = AnyBuilder::createForClass($this, ReportRepository::class)->build();
        $this->reportCollectionFactory = AnyBuilder::createForClass($this, ReportCollectionFactory::class)->build();
        $this->tokenRepository = AnyBuilder::createForClass($this, TokenRepository::class)->build();
        $this->categoryFactory = AnyBuilder::createForClass($this, CategoryFactory::class, [
            'create' => [$this->any(), $category]
        ])->build();
        $this->emulation = AnyBuilder::createForClass($this, Emulation::class, [
            'startEnvironmentEmulation' => [$this->any()]
        ])->build();
        $this->state = AnyBuilder::createForClass($this, State::class, [
            'setAreaCode' => [$this->any()]
        ])->build();
        $this->catalogConfig = AnyBuilder::createForClass($this, ConfigModel::class, [
            'getMaasRootCategory' => [$this->any(), 'maas']
        ])->build();
        $progressBar = AnyBuilder::createForClass($this, stdClass::class, [
            'setFormat' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'start' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'advance' => [$this->any(), null, AnyBuilder::RETURN_SELF],
            'finish' => [$this->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $this->progressBarFactory = AnyBuilder::createForClass($this, progressBarFactory::class, [
            'create' => [$this->any(), $progressBar]
        ])->build();
        $this->cache = AnyBuilder::createForClass($this, CacheInterface::class)->build();
        $this->csvLoggerManagement = AnyBuilder::createForClass($this, CsvLoggerManagement::class)->build();
        $this->createProductAttribute = AnyBuilder::createForClass($this, CreateProductAttribute::class, [
            'createProductAttributeByCode' => [$this->any(), $productAttributeInterface]
        ])->build();
        $this->createAttributeSet = AnyBuilder::createForClass($this, CreateAttributeSet::class, [
            'createAttributeSetByName' => [$this->any(), $attributeSet]
        ])->build();
        $this->dateTime = AnyBuilder::createForClass($this, DateTime::class)->build();
        $this->tokenFactory = AnyBuilder::createForClass($this, TokenFactory::class)->build();
    }

    protected function invokeMethod(&$object, $methodName, array $parameters = [])
    {
        $reflection = new ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }

    public function testTestGetEndpointUrlNoArgs()
    {
        $this->initializedArgumentConstructor();
        $serializer = $this->getMockSerializer();
        $categoryMocked = $this->getMockCategory($serializer);
        $apiUrlTest = 'http://daystowote.cluster023.hosting.ovh.net/icv_api/public/api/v0.2/categories';
        $url = $categoryMocked->getEndPointUrl();
        $this->assertEquals($apiUrlTest, $url, 'Should return url ovh');
    }

    public function testTestGetEndpointUrlWithArgs()
    {
        $this->initializedArgumentConstructor();
        $serializer = $this->getMockSerializer();
        $categoryMocked = $this->getMockCategory($serializer);
        $apiUrlTest = 'http://daystowote.cluster023.hosting.ovh.net/icv_api/public/api/v0.2/categories?category=1';
        $categoryMocked->setArgs(['category' => 1]);
        $url = $categoryMocked->getEndPointUrl();
        $this->assertEquals($apiUrlTest, $url, 'Should return url ovh');
    }

    public function testGetApiResponse()
    {
        $this->initializedArgumentConstructor();
        $serializer = $this->getMockSerializer(['unserialize' => [$this->any(), 'test']]);
        $categoryMocked = $this->getMockCategory($serializer);

        $jsonResponse = $categoryMocked->getApiResponse();
        $this->assertEquals('test', $jsonResponse, 'should return test');
    }

    public function testDoExecuteError()
    {
        $this->initializedArgumentConstructor();
        $serializer = $this->getMockSerializer(['unserialize' => [$this->any(), 'test']]);
        $categoryMocked = $this->getMockCategory($serializer);

        $report = AnyBuilder::createForClass($this, Report::class, [
            'log' => [$this->any()]
        ])->build();
        $returnValue = $this->invokeMethod($categoryMocked, 'doExecute', [$report]);

        $this->assertEquals(0, $returnValue['itemsCount']);
        $this->assertEquals(0, $returnValue['warningItemsCount']);
        $this->assertEquals(0, $returnValue['successItemsCount']);
        $this->assertEquals(0, $returnValue['errorItemsCount']);
        $this->assertTrue($returnValue['error']);
        $this->assertNotEmpty($returnValue['message']);
    }


    /**
     * @dataProvider getConditions
     *
     * @param $isCategory
     * @param $containCount
     * @param $isLevel3
     * @param $label
     */
    public function testDoExecuteNoError($isCategory, $containCount, $isLevel3, $label)
    {
        $expectedValue = [
            'itemsCount' => 584,
            'warningItemsCount' => 0,
            'successItemsCount' => (empty($containCount) || empty($label)) ? 0 : 1,
            'errorItemsCount' => empty($label) ? 1 : 0,
            'error' => false,
            'message' => 'a:0:{}'
        ];


        $attributeValueNolabel = [
            "code" => "A01",
        ];
        $atttributeValue = array_merge($attributeValueNolabel, $label);
        $apiResponseNocount = [
            "totalItemCount" => 584,
            "items" => [
                [
                    "categoryId" => $isCategory ? "A01F01" : "A01T05",
                    "label" => "Gros electroménager",
                    "level" => $isLevel3 ? '3' : '2',
                    "parentCategoryId" => "A01T05",
                    "attributes" => [
                        $atttributeValue
                    ],
                    "updatedAt" => "2020-09-20T10:10:59"
                ]
            ]
        ];
        $apiResponse = array_merge($apiResponseNocount, $containCount);
        $report = AnyBuilder::createForClass($this, Report::class, [
            'log' => [$this->any()],
            'save' => [$this->any(), null, AnyBuilder::RETURN_SELF],
        ])->build();
        $this->initializedArgumentConstructor($isCategory);
        $serializer = $this->getMockSerializer([
            'unserialize' => [
                $this->any(),
                $apiResponse
            ]
        ]);
        $categoryMocked = $this->getMockCategory($serializer);

        $returnValue = $this->invokeMethod($categoryMocked, 'doExecute', [$report, ['page' => [1], 'limit' => 100]]);
        $this->assertEquals($expectedValue, $returnValue, 'should return array with error false');
    }


    private function getMockCategory($serializer)
    {
        $category = $this->getMockBuilder(Category::class)
            ->setMethods(['apiCall', 'prepareAndSaveData', 'getOutput'])
            ->setConstructorArgs(
                [
                    $this->httpClientFactory,
                    $this->configProvider,
                    $serializer,
                    $this->reportFactory,
                    $this->reportRepository,
                    $this->reportCollectionFactory,
                    $this->tokenRepository,
                    $this->categoryFactory,
                    $this->emulation,
                    $this->state,
                    $this->catalogConfig,
                    $this->cache,
                    $this->csvLoggerManagement,
                    $this->createProductAttribute,
                    $this->createAttributeSet,
                    $this->dateTime,
                    $this->progressBarFactory,
                    $this->tokenFactory
                ]
            )
            ->getMock();
        $category->expects($this->any())
            ->method('apiCall')
            ->willReturn(['response' => 'a:1:{s:4:"page";s:4:"test";}']);

        $output =  AnyBuilder::createForClass($this, OutputInterface::class, [
            "write" => [$this->any(), PHP_EOL]
        ])->build();

        $category->expects($this->any())
            ->method('getOutput')
            ->willReturn($output);

        $category->expects($this->any())
            ->method('prepareAndSaveData')
            ->willReturn(
                [
                    'itemsCount' => 1,
                    'warningItemsCount' => 0,
                    'errorItemsCount' => 0,
                    'successItemsCount' => 1,
                    'error' => false,
                    'message' => []
                ]
            );
        return $category;
    }

    private function getMockSerializer($config = [])
    {
        return AnyBuilder::createForClass($this, SerializerInterface::class, $config)->build();
    }

    public function getConditions()
    {
        yield from[
            'Category does not exist and response contain count' => [
                false,
                ["count" => 50],
                false,
                ["label" => "Ordinateurs"]
            ],
            'Category  exist and response contain count ' => [true, ["count" => 50], false, ["label" => "Ordinateurs"]],
            'Category  exist and response does not contain count ' => [true, [], false, ["label" => "Ordinateurs"]],
            'Category  level 3 ' => [false, ["count" => 50], true, ["label" => "Ordinateurs"]],
            'Category  level 3 and get error on label ' => [false, ["count" => 50], true, []],
        ];
    }

    private function getMockOutPutInterface($nbTimes)
    {
        return AnyBuilder::createForClass($this, OutputInterface::class, [
            "write" => [$nbTimes, PHP_EOL, AnyBuilder::RETURN_VALUE]
        ])->build();
    }
}
