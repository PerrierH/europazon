<?php

namespace Maas\ImportExport\Test\Unit\Model\Import;

use Maas\Core\Test\Unit\AbstractTestCase;
use Maas\ImportExport\Model\Config;

/**
 * Class AbstractImportExportApiTest
 *
 * @package Maas\ImportExport\Test\Unit\Model\Import
 */
abstract class AbstractImportExportApiTest extends AbstractTestCase
{
    const PRODUCTS_API_URL = 'https://api-server.com';

    /**
     * @dataProvider getEndpointUrlSamples
     *
     * TODO 1671 : re-activate test
    public function testGetEndpointUrl($args, $expected)
    {
        $configMock = $this->getInstanceMock(Config::class, [], [
            'getProductsApiUrl' => [1, self::PRODUCTS_API_URL]
        ]);

        $instance = $this->getObject($this->getInstanceClass(), [
            'configProvider' => $configMock
        ]);
        $instance->setArgs($args);
        $this->assertEquals($expected, $instance->getEndPointUrl());
    }
     */

    /**
     * @return string
     */
    abstract protected function getInstanceClass();

    public function getEndpointUrlSamples()
    {
        return [
            'without args' => ['args' => [], 'expected' => self::PRODUCTS_API_URL . $this->getRequestEndpoint()],
            'with args' => [
                'args' => ['a' => 1, 'b' => 2],
                'expected' => self::PRODUCTS_API_URL . $this->getRequestEndpoint() . '?a=1&b=2'
            ]
        ];
    }

    /**
     * @return string
     */
    abstract protected function getRequestEndpoint();
}