<?php

namespace Maas\ImportExport\Test\Unit\Model\Import\Order;

use Exception;
use Maas\ImportExport\Exception\OperationAlreadyLaunch;
use Maas\ImportExport\Model\AbstractApi;
use Maas\ImportExport\Model\Import\Order\Status;
use Maas\Log\Model\ResourceModel\Report\Collection as ReportCollection;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Maas\ImportExport\Test\Builder\Model\AbstractApiBuilder;
use Magento\Sales\Model\Order;
use Magento\Framework\HTTP\ZendClientFactory;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;

class StatusTest extends TestCase
{
    /** @var Status */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);
    }

    public function testDoExecute()
    {
        $order = $this->getMockBuilder(Order::class)
            ->disableOriginalConstructor()
            ->getMock();

        $orderCollection = $this->abstractApiBuilder->getOrderCollection([$order]);

        $orderCollectionFactory = $this->abstractApiBuilder->getOrderCollectionFactory($orderCollection);

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Status::class,
            $di
        );

        $result = $this->instance->execute();

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(1, $result['successItemsCount']);
        $this->assertEquals('', $result['error']);
    }

    /** TODO 1671 : re-activate test
    public function testDoExecuteAlreadyLaunched()
    {
        $reportCollection = $this->getMockBuilder(ReportCollection::class)
            ->setMethods([
                'addFieldToFilter',
                'getSize',
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
        $reportCollection->expects($this->any())->method('addFieldToFilter')->willReturn($reportCollection);
        $reportCollection->expects($this->any())->method('getSize')->willReturn(1);

        $reportCollectionFactory = $this->getMockBuilder(ReportCollectionFactory::class)
            ->setMethods([
                'create'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $reportCollectionFactory->expects($this->any())->method('create')->willReturn($reportCollection);

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'reportCollectionFactory' => $reportCollectionFactory
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Status::class,
            $di
        );

        $this->expectException(OperationAlreadyLaunch::class);

        $result = $this->instance->execute();
    }
    */

    public function testDoExecuteException()
    {
        $order = $this->getMockBuilder(Order::class)
            ->disableOriginalConstructor()
            ->getMock();

        $orderCollection = $this->abstractApiBuilder->getOrderCollection([$order]);

        $orderCollectionFactory = $this->abstractApiBuilder->getOrderCollectionFactory($orderCollection);

        $httpClientFactory = $this->getMockBuilder(ZendClientFactory::class)
            ->setMethods([
                'create'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $httpClientFactory->expects($this->any())->method('create')->willReturnCallback(function () {
            throw new Exception(__('Exception message'));
        });

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory,
                'httpClientFactory' => $httpClientFactory
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Status::class,
            $di
        );

        $result = $this->instance->execute();

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(1, $result['errorItemsCount']);
        $this->assertEquals(1, $result['error']);
        $this->assertNotEquals('', $result['message']);
    }

    public function testDoRequestException()
    {
        $order = $this->getMockBuilder(Order::class)
            ->disableOriginalConstructor()
            ->getMock();

        $orderCollection = $this->abstractApiBuilder->getOrderCollection([$order]);

        $orderCollectionFactory = $this->abstractApiBuilder->getOrderCollectionFactory($orderCollection);

        $httpClientFactory = ZendClientFactoryBuilder::create(
            $this,
            ['request_throw_exception' => true]
        )
            ->build();

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory,
                'httpClientFactory' => $httpClientFactory
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Status::class,
            $di
        );

        $result = $this->instance->execute(['scheduleId' => 1]);

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(1, $result['errorItemsCount']);
        $this->assertEquals(1, $result['error']);
        $this->assertNotEquals('', $result['message']);
    }

    public function testDoExecuteNoOrders()
    {
        $orderCollection = $this->abstractApiBuilder->getOrderCollection([]);

        $orderCollectionFactory = $this->abstractApiBuilder->getOrderCollectionFactory($orderCollection);

        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'orderCollectionFactory' => $orderCollectionFactory
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Status::class,
            $di
        );

        $result = $this->instance->execute(['orderId' => '5']);

        $this->assertEquals(0, $result['itemsCount']);
        $this->assertEquals(0, $result['successItemsCount']);
        $this->assertEquals('', $result['error']);
    }

}
