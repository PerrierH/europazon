<?php

namespace Maas\ImportExport\Test\Unit\Model;

use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Maas\ImportExport\Model\ImportMessage;

class ImportMessageTest extends TestCase
{

    /** @var ImportMessage */
    public $instance;

    /** @var ObjectManager */
    private $objectManager;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->instance = $this->objectManager->getObject(
            ImportMessage::class
        );
    }


    public function testReportId()
    {
        $value = 42;
        $this->instance->setReportId($value);
        $this->assertEquals($value, $this->instance->getReportId());
    }

    public function testMessage()
    {
        $value = 'Dummy message';
        $this->instance->setEntities([$value]);
        $this->assertEquals([$value], $this->instance->getEntities());
    }

}
