<?php

namespace Maas\ImportExport\Test\Unit\Plugin\Import\Catalog\Product;

use Closure;
use Maas\ImportExport\Model\Registry;
use Maas\ImportExport\Plugin\Import\Catalog\Product\PreventProductAfterSaveOnImport;
use Magento\Catalog\Model\Product;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Product\ProductBuilder;

class PreventProductAfterSaveOnImportTest extends TestCase
{

    /**
     * @var \PHPUnit_Framework_MockObject_MockObject
     */
    private $registry;
    /**
     * @var PreventProductAfterSaveOnImport
     */
    private $stub;

    public function initTest($isImporting)
    {
        $this->registry =  AnyBuilder::createForClass($this, Registry::class, [
            "isCurrentlyImporting" => [$this->once(), $isImporting , AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->stub = new PreventProductAfterSaveOnImport(
            $this->registry
        );
    }

    public function testIsCurrentlyImporting()
    {
        $this->initTest(true);
        $product = ProductBuilder::create($this)->build();
        $closure = function () {
            return true;
        };
        $prod = $this->stub->aroundAfterSave($product, $closure);
        $this->assertEquals($product, $prod, 'Should return the product');
    }


    public function testIsNotCurrentlyImporting()
    {
        $this->initTest(false);
        $product = ProductBuilder::create($this)->build();
        $closure = function () {
            return true;
        };
        $clos = $this->stub->aroundAfterSave($product, $closure);
        $this->assertEquals(true, $clos, 'Should return the value in the closure');
    }
}
