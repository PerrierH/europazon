<?php

namespace Maas\ImportExport\Test\Builder\Model;

use Maas\Core\Test\Builder\AnyBuilder;
use Maas\ImportExport\Model\AbstractApi;
use Maas\Log\Model\Error;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Maas\ImportExport\Model\Config as MaasConfig;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Magento\Framework\App\CacheInterface;
use Maas\Log\Model\Csv;
use Maas\Log\Model\ResourceModel\Report\Collection as ReportCollection;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Api\ReportRepositoryInterface as ReportRepository;
use Maas\Core\Model\TokenRepository;
use Maas\Core\Model\Token;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Model\ResourceModel\Order\Collection as OrderCollection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;

/**
 * Class AbstractApiBuilder
 *
 * @package Maas\ImportExport\Test\Builder\Model
 * @codeCoverageIgnore Class used in tests, will not be tested itself
 */
class AbstractApiBuilder
{
    /** @var TestCase */
    private $testCase;
    private $data;
    /** @var array */
    private $di;

    /** @var ObjectManager */
    private $objectManager;

    /** @var bool */
    private $orderExportIncludesDiscounts = false;

    /**
     * @param TestCase $testCase
     * @param array $data
     *
     * @return AbstractApiBuilder
     */
    public static function create(TestCase $testCase, $data = [])
    {
        $self = new self();
        $self->testCase = $testCase;
        $self->data = $data;
        $self->di = [];
        return $self;
    }

    /**
     * @param array $data
     *
     * @return $this
     */
    public function addConfig(array $data)
    {
        $this->data = array_merge($this->data, $data);
        return $this;
    }

    /**
     * @return array
     */
    public function getDi()
    {
        if (count($this->di) === 0) {
            $this->build();
        }
        return $this->di;
    }

    public function build()
    {
        $this->di['httpClientFactory'] = ZendClientFactoryBuilder::create($this->testCase)->build();

        $configProvider = $this->testCase->getMockBuilder(MaasConfig::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'getPaymentMethodsExportStatus',
                'getApiUrl',
                'getApiClientId',
                'getApiClientSecret',
                'getAuthApiUrl',
                'getGrcApiUrl',
                'getOrdersExportIncludeDiscounts',
                'getApiVersion'
            ])
            ->getMock();
        $configProvider->expects($this->testCase->any())->method('getPaymentMethodsExportStatus')->willReturn(
            [
                'test_method' => ['processing']
            ]
        );
        $configProvider->expects($this->testCase->any())->method('getApiUrl')->willReturn('http://test.test.com');
        $configProvider->expects($this->testCase->any())->method('getApiClientId')->willReturn('id');
        $configProvider->expects($this->testCase->any())->method('getApiClientSecret')->willReturn('secret');
        $configProvider->expects($this->testCase->any())->method('getAuthApiUrl')->willReturn('http://test.test.com');
        $configProvider->expects($this->testCase->any())->method('getGrcApiUrl')->willReturn('http://test.test.com');
        $configProvider->expects($this->testCase->any())->method('getOrdersExportIncludeDiscounts')->willReturnCallback(function(){
            return $this->orderExportIncludesDiscounts;
        });
        $configProvider->expects($this->testCase->any())->method('getApiVersion')->willReturn('V1');
        $this->di['configProvider'] = $configProvider;

        $serializer = new Json();
        $this->di['serializer'] = $serializer;

        $report = $this->testCase->getMockBuilder(Report::class)
            ->setMethods([
                'getId',
                'log',
                'save'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $report->expects($this->testCase->any())->method('getId')->willReturn(42);
        $report->expects($this->testCase->any())->method('log')->willReturn(true);
        $report->expects($this->testCase->any())->method('save')->willReturn(true);

        $reportFactory = $this->testCase->getMockBuilder(ReportFactory::class)
            ->setMethods([
                'create'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $reportFactory->expects($this->testCase->any())->method('create')->willReturn($report);
        $this->di['reportFactory'] = $reportFactory;

        $reportRepository = $this->testCase->getMockBuilder(ReportRepository::class)
            ->setMethods([
                'generateLogReport',
                'closeLogReport',
                'save',
                'get',
                'delete',
                'deleteById',
                'getList'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $reportRepository->expects($this->testCase->any())->method('generateLogReport')->willReturn($report);
        $reportRepository->expects($this->testCase->any())->method('closeLogReport')->willReturn($report);
        $reportRepository->expects($this->testCase->any())->method('get')->willReturn($report);
        $this->di['reportRepository'] = $reportRepository;

        $reportCollection = $this->testCase->getMockBuilder(ReportCollection::class)
            ->setMethods([
                'addFieldToFilter',
                'getSize'
            ])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
        $reportCollection->expects($this->testCase->any())->method('addFieldToFilter')->willReturn($reportCollection);
        $reportCollection->expects($this->testCase->any())->method('getSize')->willReturn(0);

        $reportCollectionFactory = $this->testCase->getMockBuilder(ReportCollectionFactory::class)
            ->setMethods([
                'create'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $reportCollectionFactory->expects($this->testCase->any())->method('create')->willReturn($reportCollection);
        $this->di['reportCollectionFactory'] = $reportCollectionFactory;

        $token = AnyBuilder::createForClass(
            $this->testCase,
            Token::class,
            [
                'getCreatedAt' => [$this->testCase->any(), date('Y-m-d H:i:s')],
                'getExpiredIn' => [$this->testCase->any(), 900],
                'getTokenType' => [$this->testCase->any(), 'dummy_token_type'],
                'getAccessToken' => [$this->testCase->any(), 'dummy_access_token']
            ]
        )->build();

        $tokenRepository = $this->testCase->getMockBuilder(TokenRepository::class)
            ->setMethods([
                'getEnabledToken',
                'save',
                'truncateTokenTable'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $tokenRepository->expects($this->testCase->any())->method('getEnabledToken')->willReturn($token);
        $tokenRepository->expects($this->testCase->any())->method('save')->willReturn($token);
        $tokenRepository->expects($this->testCase->any())->method('truncateTokenTable');
        $this->di['tokenRepository'] = $tokenRepository;

        $cache = AnyBuilder::createForClass($this->testCase, CacheInterface::class, [
            'load' => [
                $this->testCase->any(),
                function ($key) {
                    if ($key == AbstractApi::TOKEN_CACHE_KEY) {
                        $serializer = new Json();
                        return $serializer->serialize([
                            'created_at' => date('Y-m-d H:i:s'),
                            'expired_in' => 900,
                            'token_type' => 'dummy_token_type',
                            'access_token' => 'dummy_access_token'
                        ]);
                    }

                    return true;
                },
                AnyBuilder::RETURN_CALLBACK
            ]
        ])->build();
        $this->di['cache'] = $cache;
        $csv = AnyBuilder::createForClass($this->testCase, Csv::class, [
            'finalizeRow' => [$this->testCase->any(), null, AnyBuilder::RETURN_SELF]
        ])->build();
        $csvLoggerManagement = AnyBuilder::createForClass($this->testCase, CsvLoggerManagement::class, [
            'getCsvLogger' => [$this->testCase->any(), $csv, AnyBuilder::RETURN_VALUE]
        ])->build();
        $this->di['csvLoggerManagement'] = $csvLoggerManagement;
        $dateTime = AnyBuilder::createForClass($this->testCase, DateTime::class, [
            'date' => [$this->testCase->any(), '10/02/2021']
        ])->build();
        $this->di['dateTime'] = $dateTime;
        $tokenFactory = AnyBuilder::createForClass($this->testCase, TokenFactory::class, [
            'create' => [$this->testCase->any(), $token]
        ])->build();
        $this->di['tokenFactory'] = $tokenFactory;

        $errorLogger = AnyBuilder::createForClass(
            $this->testCase,
            Error::class
        )->build();
        $this->di['errorLogger'] = $errorLogger;
    }

    public function resetDi()
    {
        $this->di = null;
    }


    /**
     * @param array $orders
     *
     * @return MockObject
     */
    public function getOrderCollection(array $orders)
    {
        $orderCollection = $this->testCase->getMockBuilder(OrderCollection::class)
            ->setMethods([
                'addFieldToFilter',
                'getItems'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $orderCollection->expects($this->testCase->any())->method('getItems')->willReturn($orders);

        return $orderCollection;
    }

    /**
     * @param OrderCollection $orderCollection
     *
     * @return MockObject
     */
    public function getOrderCollectionFactory(OrderCollection $orderCollection)
    {
        $orderCollectionFactory = $this->testCase->getMockBuilder(OrderCollectionFactory::class)
            ->setMethods([
                'create'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $orderCollectionFactory->expects($this->testCase->any())->method('create')->willReturn($orderCollection);
        return $orderCollectionFactory;
    }

    /**
     * @param bool $flag
     *
     * @return $this
     */
    public function setConfigOrderExportIncludesDiscounts($flag)
    {
        $this->orderExportIncludesDiscounts = $flag;
        return $this;
    }
}
