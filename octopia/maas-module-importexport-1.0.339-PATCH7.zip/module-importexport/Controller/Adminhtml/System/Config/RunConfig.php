<?php

namespace Maas\ImportExport\Controller\Adminhtml\System\Config;

use Exception;
use Maas\ImportExport\Model\AbstractApi;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;

/**
 * Class RunConfig
 *
 * @package Maas\ImportExport\Controller\Adminhtml\System\Config
 * We have decide to not test Controller
 * @codeCoverageIgnore
 */
class RunConfig extends Action
{
    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;
    /**
     * @var AbstractApi
     */
    protected $abstractApi;


    /**
     * RunConfig constructor.
     *
     * @param Context $context
     * @param AbstractApi $abstractApi
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
        Context $context,
        AbstractApi $abstractApi,
        JsonFactory $resultJsonFactory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->abstractApi = $abstractApi;
        parent::__construct($context);
    }


    /**
     * @return ResponseInterface|Json|ResultInterface
     */
    public function execute()
    {
        $result = $this->resultJsonFactory->create();
        try {
            $res = $this->abstractApi->connect($this->getRequest()->getParams(), false);
            return $result->setData($res);
        } catch (Exception $e) {
            return $result->setData(['status' => 'error', 'response' => $e->getMessage()]);
        }
    }
}
