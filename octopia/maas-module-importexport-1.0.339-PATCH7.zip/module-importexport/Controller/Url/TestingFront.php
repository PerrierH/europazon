<?php

namespace Maas\ImportExport\Controller\Url;

use Maas\Log\Api\ReportRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class TestingFront
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Controller\Url
 */
class TestingFront extends Action
{
    /**
     * @var ReportRepositoryInterface
     */
    private $reportRepository;
    /**
     * @var SearchCriteriaInterface
     */
    private $searchCriteria;

    public function __construct(
        Context $context,
        ReportRepositoryInterface $reportRepository,
        SearchCriteriaInterface $searchCriteria
    ) {
        $this->reportRepository = $reportRepository;
        $this->searchCriteria = $searchCriteria;
        parent::__construct($context);
    }

    /**
     * This action render random number for each request
     */
    public function execute()
    {
        $header = $this->getRequest()->getHeader('custom-header');
        $timeStamp = $this->getRequest()->getParam('timestamp');
        if ($header === 'testing_url' && $timeStamp) {
            $result = $this->resultFactory->create(ResultFactory::TYPE_JSON);
            $countReports = $this->reportRepository->getList($this->searchCriteria)->getTotalCount();
            $result->setData(['timeStamp' => $timeStamp, 'headerValue' => $header, 'reports' => $countReports]);
            return $result;
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $norouteUrl = $this->_url->getUrl('noroute');
        return $resultRedirect->setUrl($norouteUrl);
    }
}
