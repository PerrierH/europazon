<?php

namespace Maas\ImportExport\Cron\Export\Order;

use Exception;
use Maas\Core\Model\Config;
use Maas\ImportExport\Model\Export\Order;
use Magento\Cron\Model\Schedule;

/**
 * Class Orders
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Export\Order
 */
class Orders
{
    /** @var Order */
    protected $order;

    /**
     * @var Config
     */
    private $configModel;

    /**
     * Orders constructor.
     *
     * @param Order $order
     * @param Config $configModel
     */
    public function __construct(
        Order $order,
        Config $configModel
    ) {
        $this->order = $order;
        $this->configModel = $configModel;
    }

    /**
     * @param Schedule $schedule
     *
     * @throws Exception
     */
    public function execute(Schedule $schedule)
    {
        if ($this->configModel->isModuleEnabled()) {
            $args = [
                'scheduleId' => $schedule->getId()
            ];
            $this->order->execute($args);
        }
        return $this;
    }
}
