<?php

namespace Maas\ImportExport\Cron\Import\Seller;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Seller
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Seller
 */
class Seller extends CommandRunner
{

    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:seller";
    }
}
