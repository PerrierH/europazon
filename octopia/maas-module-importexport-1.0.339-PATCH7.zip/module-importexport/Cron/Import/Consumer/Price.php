<?php

namespace Maas\ImportExport\Cron\Import\Consumer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Price
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Consumer
 */
class Price extends CommandRunner
{

    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:offer:price:consumer";
    }
}
