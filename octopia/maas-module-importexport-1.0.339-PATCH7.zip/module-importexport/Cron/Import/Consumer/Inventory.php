<?php

namespace Maas\ImportExport\Cron\Import\Consumer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Inventory
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Consumer
 */
class Inventory extends CommandRunner
{
    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:offer:inventory:consumer";
    }
}
