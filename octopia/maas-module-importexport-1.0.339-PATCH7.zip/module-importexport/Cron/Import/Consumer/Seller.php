<?php

namespace Maas\ImportExport\Cron\Import\Consumer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Seller
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Consumer
 */
class Seller extends CommandRunner
{

    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:seller:consumer";
    }
}
