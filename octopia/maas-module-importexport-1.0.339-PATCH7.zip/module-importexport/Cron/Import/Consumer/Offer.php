<?php

namespace Maas\ImportExport\Cron\Import\Consumer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Offer
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Consumer
 */
class Offer extends CommandRunner
{

    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:offer:consumer";
    }
}
