<?php

namespace Maas\ImportExport\Cron\Import\Consumer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Consumer
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Consumer
 */
class Product extends CommandRunner
{
    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:product:consumer";
    }
}
