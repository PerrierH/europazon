<?php

namespace Maas\ImportExport\Cron\Import\Offer;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Offer
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Offer
 */
class Offer extends CommandRunner
{

    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:offer";
    }
}
