<?php

namespace Maas\ImportExport\Cron\Import\Order;

use Exception;
use Maas\Core\Model\Config;
use Maas\ImportExport\Model\Import\Order\Status as ImportOrderStatus;
use Magento\Cron\Model\Schedule;

/**
 * Class OrderStatus
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import
 */
class Status
{
    /** @var ImportOrderStatus */
    protected $orderStatus;

    /**
     * @var Config
     */
    private $configModel;

    /**
     * Status constructor.
     *
     * @param ImportOrderStatus $orderStatus
     * @param Config $configModel
     */
    public function __construct(
        ImportOrderStatus $orderStatus,
        Config $configModel
    ) {
        $this->orderStatus = $orderStatus;
        $this->configModel = $configModel;
    }

    /**
     * @param Schedule $schedule
     *
     * @throws Exception
     */
    public function execute(Schedule $schedule)
    {
        if ($this->configModel->isModuleEnabled()) {
            $args = [
                'scheduleId' => $schedule->getId()
            ];
            $this->orderStatus->execute($args);
        }

        return $this;
    }
}
