<?php

namespace Maas\ImportExport\Cron\Import\Catalog;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Category
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Catalog
 */
class Category extends CommandRunner
{

    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:category";
    }
}