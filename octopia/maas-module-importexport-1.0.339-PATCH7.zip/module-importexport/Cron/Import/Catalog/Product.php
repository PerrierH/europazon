<?php


namespace Maas\ImportExport\Cron\Import\Catalog;

use Maas\Core\Model\Service\CommandRunner;

/**
 * Class Product
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Cron\Import\Catalog
 */
class Product extends CommandRunner
{
    /**
     * @return mixed|string
     */
    protected function getCommandName()
    {
        return "maas:import:product";
    }
}
