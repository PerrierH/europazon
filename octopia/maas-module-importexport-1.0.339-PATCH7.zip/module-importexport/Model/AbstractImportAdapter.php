<?php

namespace Maas\ImportExport\Model;

/**
 * Class AbstractImportAdapter
 *
 * @package Maas\ImportExport\Model
 */
abstract class AbstractImportAdapter
{
    /**
     * @var int
     */
    protected $reportId = 0;

    /**
     * @param AbstractImportExportApi $api
     *
     * @return array
     */
    abstract public function doRequest(AbstractImportExportApi $api);

    /**
     * @param AbstractImportExportApi $api
     *
     * @return array
     */
    protected function doOriginalRequest(AbstractImportExportApi $api)
    {
        return $api->doRequest($this->getEndPointUrl($api), $api->getMethod(), $api->getHeaders(), $api->getBody(),
            $api->getPostsParams());
    }

    protected function getEndPointUrl(AbstractImportExportApi $api)
    {
        return $api->getEndPointUrl();
    }

    public function getTotalItemsCount(AbstractImportExportApi $api)
    {
        $result = $api->getApiResponse(['limit' => 1]);
        return $result['totalItemCount'];
    }

    public function getAdditionalInfo(AbstractImportExportApi $api, \Zend_Http_Response $result)
    {
        return null;
    }

    /**
     * @param int $reportId
     *
     * @return $this
     */
    public function setReportId($reportId)
    {
        $this->reportId = $reportId;
        return $this;
    }

    /**
     * @return int
     */
    public function getReportId()
    {
        return $this->reportId;
    }
}
