<?php

namespace Maas\ImportExport\Model;

use DateInterval;
use DateTime as PhpDateTime;
use Exception;
use Maas\Core\Api\Data\TokenInterface;
use Maas\Core\Model\Http\Client;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\HTTP\ZendClientFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Zend_Http_Client;
use Zend_Http_Response;

/**
 * Class AbstractApi
 *
 * @package Maas\ImportExport\Model
 * @codeCoverageIgnore
 */
class AbstractApi
{
    public const API_REQUEST_ENDPOINT = '';

    const MAAS_LOG_ACTION = '';

    const MAAS_LOG_MODULE = '';

    const MAAS_LOG_OPERATION_TYPE = '';

    const CACHE_KEY_MAAS_REPORT_ID = '';

    const TOKEN_CACHE_KEY = 'maas_token';

    const CACHE_TAG_IMPORTEXPORT_BY_REPORT = 'maas_importexport_report_%s';

    const TOTAL_ITEMS_COUNT_URL = '/count';

    const FILTER_STATUS = '?status=ANY';

    /**
     * @var string
     */
    protected $method;
    /**
     * @var ClientFactory
     */
    protected $httpClientFactory;
    /**
     * @var Config
     */
    protected $configProvider;
    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var DateTime
     */
    protected $dateTime;
    /**
     * @var TokenRepository
     */
    protected $reportCollectionFactory;
    /**
     * @var string
     */
    protected $body;
    /**
     * @var array
     */
    protected $args;
    /**
     * @var array
     */
    protected $headers;
    /**
     * @var ErrorLogger
     */
    protected $errorLogger;
    /**
     * @var array
     */
    private $postParams;
    /**
     * @var TokenFactory
     */
    private $tokenFactory;

    /**
     * AbstractApi constructor.
     *
     * @param ClientFactory $httpClientFactory
     * @param Config $configProvider
     * @param SerializerInterface $serializer
     * @param TokenRepository $tokenRepository
     * @param CacheInterface $cache
     * @param DateTime $dateTime
     * @param TokenFactory $tokenFactory
     * @param ErrorLogger $errorLogger
     */
    public function __construct(
        ClientFactory $httpClientFactory,
        Config $configProvider,
        SerializerInterface $serializer,
        TokenRepository $tokenRepository,
        CacheInterface $cache,
        DateTime $dateTime,
        TokenFactory $tokenFactory,
        ErrorLogger $errorLogger
    )
    {
        $this->httpClientFactory = $httpClientFactory;
        $this->configProvider = $configProvider;
        $this->serializer = $serializer;
        $this->tokenRepository = $tokenRepository;
        $this->cache = $cache;
        $this->dateTime = $dateTime;
        $this->tokenFactory = $tokenFactory;
        $this->errorLogger = $errorLogger;
    }

    /**
     * @return string
     */
    public function getEndPointUrl()
    {
        return '#';
    }

    /**
     * Useless we will mock the result
     *
     * @codeCoverageIgnore
     * @return string
     */
    public function getMethod()
    {
        if (!$this->method) {
            return Zend_Http_Client::GET;
        }
        return $this->method;
    }

    /**
     * @param string $method
     */
    public function setMethod($method)
    {
        $this->method = $method;
    }

    /**
     * Useless we will mock the result
     *
     * @codeCoverageIgnore
     * @return string
     */
    public function getBody()
    {
        return $this->body;
    }

    /**
     * @param string $body
     */
    public function setBody($body)
    {
        $this->body = $body;
    }

    /**
     * Useless we will mock the result
     *
     * @codeCoverageIgnore
     * @return array
     */
    public function getPostsParams()
    {
        return $this->postParams;
    }

    /**
     * Useless we will mock the result
     *
     * @codeCoverageIgnore
     * @return array
     */
    public function getArgs()
    {
        return $this->args;
    }

    /**
     * @param array $args
     */
    public function setArgs($args)
    {
        $this->args = $args;
    }

    /**
     * Useless we will mock the result
     *
     * @codeCoverageIgnore
     * @return array
     */
    public function getHeaders()
    {
        if (!$this->headers) {
            if ($this->isAuthEnabled()) {
                $token = $this->getToken();
                $tokenType = $token->getTokenType();
                $accessToken = $token->getAccessToken();
                return [
                    "Authorization: $tokenType $accessToken",
                    "Content-Type: application/json"
                ];
            }
            return [];
        }
        return $this->headers;
    }

    /**
     * @param array $headers
     */
    public function setHeaders($headers)
    {
        $this->headers = $headers;
    }

    /**
     * If the Auth API URL is empty, the Auth API is disabled, and returned headers are empty.
     *
     * @return bool
     */
    protected function isAuthEnabled()
    {
        return (bool)trim($this->configProvider->getAuthApiUrl());
    }

    /**
     * @return TokenInterface
     * @throws Exception
     */
    protected function getToken()
    {
        $token = $this->loadTokenFromCache();
        if (!$token) {
            $token = $this->getNewToken();
        } elseif ($this->isTokenExpired($token)) {
            $token = $this->getNewToken();
        }
        if (!$token) {
            throw new AuthenticationException(__('Cannot authenticate. Token not generated'));
        }
        return $token;
    }

    /**
     * @return string|null
     */
    private function getNewToken()
    {
        $connection = $this->connect();
        return $connection['token'];
    }

    /**
     * @return TokenInterface|null
     * @throws Exception
     */
    public function loadTokenFromCache()
    {
        $tokenData = $this->cache->load(static::TOKEN_CACHE_KEY);
        if ($tokenData) {
            $token = $this->tokenFactory->create();
            $token->setData($this->serializer->unserialize($tokenData));
            return $token;
        }
        return null;
    }

    /**
     * @param Report $report
     * @param null $args
     *
     * @return array
     */
    public function connect(array $args = null)
    {
        $clientId = $args['clientId'] ?? $this->configProvider->getApiClientId();
        $clientSecret = $args['clientSecret'] ?? $this->configProvider->getApiClientSecret();
        $token = null;
        $error = false;
        $response = null;

        $requestHeaders = [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Basic ' . base64_encode($clientId . ':' . $clientSecret)
        ];

        $response = $this->doRequest($this->getAuthenticationUrl(), Zend_Http_Client::POST, $requestHeaders,
            null, ['grant_type' => 'client_credentials']);

        if ($response['status'] == 200) {
            $result = $this->serializer->unserialize($response['response']);
            $token = $this->saveToken($result);
            $status = 'success';
        } else {
            $status = 'error';
            $error = true;
            $this->errorLogger->error(sprintf('Error when trying to connect to api. Error detail: %s',
                $response['response']));
        }

        return ['status' => $status, 'error' => $error, 'response' => $response, 'token' => $token];
    }

    /**
     * Function to create CURL Request to External Server
     *
     * @param $uri
     * @param $method
     * @param array $headers
     * @param mixed $body
     * @param mixed $postParams
     *
     * @return array
     * @throws Zend_Http_Client_Exception
     */
    public function doRequest($uri, $method, $headers = [], $body = null, $postParams = null)
    {
        $response = [];

        try {
            /** @var Client $client */
            $client = $this->httpClientFactory->create();
            $client->setUri($uri);
            $client->setMethod($method);
            $client->setHeaders($headers);
            $client->setConfig(['timeout' => 60]);

            if ($body != null) {
                $client->setRawData($this->serializer->serialize($body));
            }
            if ($postParams != null) {
                $client->setParameterPost($postParams);
            }
            $result = $client->request();
            $response['headers'] = $result->getHeaders();

            $response['response'] = $result->getBody();
            if (empty($response['response'])) {
                $response['response'] = $result->getMessage();
            }
            $response['status'] = $result->getStatus();
            $additional = $this->getAdditionalInfo($result);
            if (is_array($additional)) {
                $response['.additional'] = $additional;
            }
        } catch (Exception $ex) {
            // Report the exception to the user
            $response['response'] = $ex->getMessage();
            $response['status'] = 500;
            $this->errorLogger->error($ex->getMessage());
            $this->errorLogger->error('Uri: ' . $uri);
            $this->errorLogger->error('Body: ' . json_encode($body));
        }
        $response['uri'] = $uri;
        return $response;
    }

    /**
     * @param Zend_Http_Response $result
     * @param $response
     *
     * @return array|null
     */
    protected function getAdditionalInfo(Zend_Http_Response $result)
    {
        return null;
    }

    /**
     * @return string
     */
    public function getAuthenticationUrl()
    {
        return $this->configProvider->getTokenApiUrl() ;
    }

    /**
     * @param $response
     *
     * @return TokenInterface
     */
    private function saveToken($response)
    {
        $token = $this->tokenFactory->create();
        $this->tokenRepository->truncateTokenTable();
        $token->setData($response);
        $token->setData('created_at', $this->dateTime->date());
        $token = $this->tokenRepository->save($token);
        $this->cache->save($this->serializer->serialize($token->getData()), self::TOKEN_CACHE_KEY);
        return $token;
    }

    /**
     * @param TokenInterface $token
     *
     * @return bool
     * @throws Exception
     */
    private function isTokenExpired(TokenInterface $token)
    {
        $createdTokenDate = new PhpDatetime($token->getCreatedAt());
        $createdTokenDate->add(new DateInterval('PT' . ($token->getExpiredIn() - 15) . 'S'));
        $dateNow = new PhpDatetime('NOW');
        return $createdTokenDate < $dateNow;
    }

    /**
     * @return Report
     */
    protected function getLastReport()
    {
        return $this->reportCollectionFactory->create()
            ->addOrder('updated_at')
            ->addFilter('status', 'success')
            ->getFirstItem();
    }
}
