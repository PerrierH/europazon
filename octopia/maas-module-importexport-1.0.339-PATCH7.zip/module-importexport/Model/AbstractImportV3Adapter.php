<?php

namespace Maas\ImportExport\Model;

use Maas\ImportExport\Model\Service\Client\Curl;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;
use Maas\Log\Model\ResourceModel\Report as ReportResource;

/**
 * Class AbstractImportV3Adapter
 *
 * @package Maas\ImportExport\Model
 */
abstract class AbstractImportV3Adapter extends AbstractImportAdapter
{
    const TOTAL_ITEMS_COUNT_CACHE_KEY = 'maas-importexport-total-items-count-%s';

    const CACHE_KEY_CURSOR = 'cursor_%s';
    /**
     * @var Curl
     */
    protected $curlClient = null;

    /**
     * @var CurlFactory
     */
    protected $curlClientFactory;

    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var ReportResource
     */
    protected $reportResource;

    /**
     * AbstractImportAdapter Constructor
     *
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     * @param ReportResource $reportResource
     */
    public function __construct(
        CurlFactory    $curlClientFactory,
        CacheInterface $cache,
        ReportResource $reportResource
    )
    {
        $this->curlClientFactory = $curlClientFactory;
        $this->cache = $cache;
        $this->reportResource = $reportResource;
    }

    /**
     * @param AbstractImportExportApi $api
     *
     * @return array
     */
    public function doRequest(AbstractImportExportApi $api)
    {
        $this->capitalizeBearer($api);
        $this->addAllFields($api);
        $this->addFilters($api);
        $this->handlePagination($api);
        $result = $this->doOriginalRequest($api);
        if (array_key_exists('headers', $result)) {
            $this->setCursor($result['headers']);
        }
        if ($result['status'] >= 400) {
            return $result;
        }
        $responseContents = json_decode($result['response'] ?? '', 1);
        $responseContents = $this->convertResult($api, $responseContents);
        $result['response'] = json_encode($responseContents);
        return $result;
    }

    /**
     * @param AbstractImportExportApi $api
     * @param $result
     *
     * @return array
     */
    protected function convertResult(AbstractImportExportApi $api, $result)
    {
        $totalItemsCount = $this->cache->load(sprintf(self::TOTAL_ITEMS_COUNT_CACHE_KEY, $this->reportId));
        return [
            'totalItemsCount' => $totalItemsCount ? intval($totalItemsCount) : 0,
            'count' => count($result['items']),
            'items' => $this->convertItems($result['items'])
        ];
    }

    /**
     * @param AbstractImportExportApi $api
     *
     * @return int|mixed
     */
    public function getTotalItemsCount(AbstractImportExportApi $api)
    {
        $this->capitalizeBearer($api);
        $headers = $api->getHeaders();
        $headersAssoc = [];
        foreach ($headers as $header) {
            $headerParts = explode(':', $header);
            if (count($headerParts) >= 2) {
                $headerName = array_shift($headerParts);
                $headerParts[0] = ltrim($headerParts[0]);
                $headersAssoc[$headerName] = implode(':', $headerParts);
            }
        }
        if (is_null($this->curlClient)) {
            $this->curlClient = $this->curlClientFactory->create();
        }
        $this->curlClient->setHeaders($headersAssoc);
        $totalItemsCount = 0;
        $url = $this->getEndPointUrl($api);
        $filters = $this->getCurrentFilters($api);
        $this->curlClient->get($url . $api::TOTAL_ITEMS_COUNT_URL . '?' . $filters);
        if ($this->curlClient->getStatus() == 200) {
            $body = json_decode($this->curlClient->getBody() ?? '', true);
            $totalItemsCount = array_key_exists('count', $body) ? $body['count'] : 0;
        } else {
            $this->curlClient->callHead($url);
            if ($this->curlClient->getStatus() == 200) {
                $result = $this->curlClient->getHeaders();
                $indexXTotalCount = array_key_exists('X-Total-Count', $result) ? 'X-Total-Count' : 'x-total-count';
                $totalItemsCount = $result[$indexXTotalCount] ? intval($result[$indexXTotalCount]) : 0;
            }
            $this->cache->remove(sprintf(self::CACHE_KEY_CURSOR, $this->getEntityType()));
        }
        $this->cache->save(
            $totalItemsCount,
            sprintf(self::TOTAL_ITEMS_COUNT_CACHE_KEY, $this->reportId),
            [sprintf(AbstractImportExportApi::CACHE_TAG_IMPORTEXPORT_BY_REPORT, $this->reportId)]);
        return $totalItemsCount;
    }

    /**
     * @param AbstractImportExportApi $api
     */
    protected function capitalizeBearer(AbstractImportExportApi $api)
    {
        $headers = $api->getHeaders();
        foreach ($headers as $i => $header) {
            if (strpos($header, 'Authorization: bearer') !== false) {
                $headers[$i] = str_replace('Authorization: bearer', 'Authorization: Bearer', $header);
            }
        }
        $api->setHeaders($headers);
    }

    protected function handlePagination(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        if (isset($args['page'])) {
            $cursor = $this->cache->load(sprintf(self::CACHE_KEY_CURSOR, $this->getEntityType()));
            if ($cursor) {
                $args['cursor'] = $cursor;
            }
            unset($args['page']);
        }
        $api->setArgs($args);
    }


    /**
     * @param array $response
     * @return void
     */
    protected function setCursor(array $responseHeaders)
    {
        $cursor = array_key_exists('Link', $responseHeaders) ? preg_match('/cursor=(.*?)&(.*)>; rel="next"/', $responseHeaders['Link'], $match) : false;
        if ($cursor && count($match) > 1) {
            $cursor = \str_replace('=', '%3D', $match[1]);
            if ($cursor != $this->cache->load(sprintf(self::CACHE_KEY_CURSOR, $this->getEntityType()))) {
                $this->cache->save($cursor, sprintf(self::CACHE_KEY_CURSOR, $this->getEntityType()));
            }
        }
    }

    /**
     * @return string
     */
    protected function getEntityType()
    {
        return $this->entityType;
    }

    /**
     * @param AbstractImportExportApi $api
     * @return string
     */
    protected function getCurrentFilters(AbstractImportExportApi $api)
    {
        $this->addFilters($api);
        $args = $api->getArgs();
        return is_array($args) && sizeof($args) ? http_build_query($args) : '';
    }

    /**
     * @param $module
     * @param $action
     * @param $operationType
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function hasRan($module, $action, $operationType)
    {
        return $this->reportResource->getFirstRunHasExecuted($module, $action, $operationType, true);
    }

    /**
     * @param $date
     * @return mixed
     */
    protected function convertToApiDate($date = '0000-00-00 00:00:00')
    {
        return str_replace(' ', 'T', $date) . 'Z';
    }

    abstract protected function convertItems($items);

    abstract protected function addAllFields(AbstractImportExportApi $api);

    abstract protected function addFilters(AbstractImportExportApi $api);
}
