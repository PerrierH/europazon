<?php

namespace Maas\ImportExport\Model;

use Maas\Log\Model\Csv;
use Maas\Log\Model\CsvFactory;

/**
 * Class CsvLoggerManagement
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model
 */
class CsvLoggerManagement
{
    /**
     * @var CsvFactory
     */
    protected $csvLoggerFactory;

    public function __construct(
        CsvFactory $csvLoggerFactory
    )
    {
        $this->csvLoggerFactory = $csvLoggerFactory;
    }

    /**
     * @param int $reportId
     * @param array $csvHeaders
     * @param string $maasLogModule
     * @param string $maasLogAction
     * @param string $filePrefix
     * @return Csv
     */
    public function getCsvLogger(
        int $reportId,
        array $csvHeaders,
        string $maasLogModule,
        string $maasLogAction,
        string $filePrefix
    )
    {
        $csvLogger = $this->csvLoggerFactory->create();
        $csvLogger->initializeNewFile(
            $csvHeaders,
            $maasLogModule,
            $maasLogAction,
            $filePrefix . '-' . $reportId . '.csv'
        );

        return $csvLogger;
    }
}
