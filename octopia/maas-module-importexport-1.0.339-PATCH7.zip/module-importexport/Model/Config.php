<?php

namespace Maas\ImportExport\Model;

use Maas\Core\Model\Config as CoreConfig;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 * No test for this class because
 * The result will be mocked
 *
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model
 */
class Config extends CoreConfig
{
    /*  System Config -> General */
    public const XML_PATH_ENVIRONMENT = 'maas_general/general/environment';

    /*  System Config -> API Configuration */
    public const XML_PATH_ENVIRONMENTS = 'maas_api';

    /*  System Config -> Authentication Config */
    public const XML_PATH_AUTH_API_CLIENT_ID = 'maas_general/authentication/api_client_id';
    public const XML_PATH_AUTH_API_CLIENT_SECRET = 'maas_general/authentication/api_client_secret';

    /* System Config -> Import Catalog -> Process number */
    public const XML_PATH_IMPORT_CATALOG_PRODUCTS_PARALLEL_PROCESSES_NUMBER = 'maas_products/advanced/parallel_processes_number';
    public const XML_PATH_IMPORT_CATALOG_PRODUCTS_CONSUMER_PROCESSES_NUMBER = 'maas_products/advanced/consumer_processes_number';
    public const XML_PATH_IMPORT_CATALOG_PRODUCTS_PER_MESSAGE = 'maas_products/advanced/products_per_message';

    /* Products */
    public const XML_PATH_IMPORT_CATALOG_PRODUCTS_LIMIT = 'maas_products/advanced/products_limit';
    public const XML_PATH_IMPORT_CATALOG_MAXIMUM_PRODUCTS_TO_IMPORT = 'maas_products/advanced/max_products_to_import';
    public const XML_PATH_IMPORT_CATALOG_PRODUCTS_DISABLE_IMPORT_IMAGES = 'maas_products/advanced/disable_import_images';
    public const XML_PATH_IMPORT_CATALOG_PRODUCTS_DELTA_ENABLE = 'maas_products/general/catalog_product_import_delta_enabled';


    /* Categories */
    public const XML_PATH_IMPORT_CATALOG_CATEGORIES_LIMIT = 'maas_categories/advanced/categories_limit';
    public const XML_PATH_IMPORT_CATALOG_CATEGORIES_PARALLEL_PROCESSES_NUMBER = 'maas_categories/advanced/parallel_processes_number';
    public const XML_PATH_IMPORT_CATALOG_CATEGORIES_CONSUMER_PROCESSES_NUMBER = 'maas_categories/advanced/consumer_processes_number';
    public const XML_PATH_IMPORT_CATALOG_CATEGORIES_PER_MESSAGE = 'maas_categories/advanced/categories_per_message';
    public const XML_PATH_IMPORT_CATALOG_CATEGORIES_TO_EXCLUDE = 'maas_categories/advanced/categories_to_exclude';

    /* Offers */
    public const XML_PATH_IMPORT_CATALOG_OFFERS_LIMIT = 'maas_offers/advanced/offers_limit';
    public const XML_PATH_IMPORT_CATALOG_OFFERS_CONSUMER_PROCESSES_NUMBER = 'maas_offers/advanced/offer_consumer_processes_number';
    public const XML_PATH_IMPORT_CATALOG_OFFERS_PER_MESSAGE = 'maas_offers/advanced/offers_per_message';
    public const XML_PATH_IMPORT_CATALOG_BEST_OFFER_LIMIT = 'maas_bestoffer/general/bestoffer_limit';
    public const XML_PATH_IMPORT_CATALOG_BEST_OFFER_MAX = 'maas_bestoffer/general/bestoffer_max';
    public const XML_PATH_IMPORT_CATALOG_BEST_OFFER_PARALLEL_PROCESSES_NUMBER = 'maas_bestoffer/general/bestoffer_parallel_processes_number';
    public const XML_PATH_IMPORT_CATALOG_MAXIMUM_OFFERS_TO_IMPORT = 'maas_offers/advanced/max_offers_to_import';
    public const XML_PATH_IMPORT_CATALOG_OFFERS_DELTA_ENABLE = 'maas_offers/general/offer_offer_import_delta_enabled';

    /* Sellers */
    public const XML_PATH_IMPORT_CATALOG_SELLERS_LIMIT = 'maas_sellers/advanced/sellers_limit';
    public const XML_PATH_IMPORT_CATALOG_SELLERS_PER_MESSAGE = 'maas_sellers/advanced/sellers_per_message';
    public const XML_PATH_IMPORT_CATALOG_SELLERS_CONSUMER_PROCESSES_NUMBER = 'maas_sellers/advanced/seller_consumer_processes_number';
    public const XML_PATH_IMPORT_CATALOG_SELLERS_PARALLEL_PROCESSES_NUMBER = 'maas_sellers/advanced/seller_parallel_processes_number';
    public const XML_PATH_IMPORT_CATALOG_SELLERS_DELTA_ENABLE = 'maas_sellers/general/seller_seller_import_delta_enabled';

    /* Orders */
    public const XML_PATH_EXPORT_ORDER_INCLUDE_DISCOUNT = 'maas_orders/general/order_orders_export_discounted';

    /**
     * Value used to represent an unlimited number of RabbitMQ retries
     */
    const RABBITMQ_RETRIES_UNLIMITED = -1;

    /** @var array */
    private $envConfig;

    /**
     * Function to Api client Id
     *
     * @param null $scopeCode
     *
     * @return string|null
     */
    public function getApiClientId($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_AUTH_API_CLIENT_ID, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to get Api Client Secret
     *
     * @param null $scopeCode
     *
     * @return string|null
     */
    public function getApiClientSecret($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_AUTH_API_CLIENT_SECRET, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the connexion method to use in a message queue
     *
     * @param null $scopeCode
     *
     * @return string
     */
    public function getMessageQueueConnectionMethod($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_MESSAGE_QUEUE_CONNECTION_TYPE, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the number of parallel process to import catalog
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getProductsParallelProcessNumber($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_PRODUCTS_PARALLEL_PROCESSES_NUMBER,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Function to retrieve the consumer parallel process number
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getProductsConsumerProcessNumber($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_PRODUCTS_CONSUMER_PROCESSES_NUMBER,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        ) ?? 1;
    }

    /**
     * Function to retrieve the products limit by page in api calls
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getProductsLimit($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_PRODUCTS_LIMIT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the products limit by page in api calls
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getMaximumProductsToImport($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_MAXIMUM_PRODUCTS_TO_IMPORT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Returns TRUE if import product images disabled
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function isProductsImportingImagesDisabled($scopeCode = null)
    {
        return $this->isSetFlag(
            self::XML_PATH_IMPORT_CATALOG_PRODUCTS_DISABLE_IMPORT_IMAGES,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Function to retrieve the offers limit by page in api calls
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getMaximumOffersToImport($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_MAXIMUM_OFFERS_TO_IMPORT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the consumer parallel process number
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getCategoriesConsumerProcessNumber($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_CATEGORIES_CONSUMER_PROCESSES_NUMBER,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        ) ?? 1;
    }

    /**
     * Function to retrieve the categories limit by page in api calls
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getCategoriesLimit($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_CATEGORIES_LIMIT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Returns Number of categories to publish in queue message
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function getCategoriesNumberPerMessage($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_CATEGORIES_PER_MESSAGE,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Returns list of categories to exclude
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function getCategoriesToExclude($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_CATEGORIES_TO_EXCLUDE,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Function to retrieve the offers consumer parallel process number
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getOffersConsumerProcessNumber($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_OFFERS_CONSUMER_PROCESSES_NUMBER,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        ) ?? 1;
    }

    /**
     * Function to retrieve the offers limit by page in api calls
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getOffersLimit($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_OFFERS_LIMIT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the best offers limit by page
     *
     * @param null $scopeCode
     * @return string
     */
    public function getBestOffersLimit($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_BEST_OFFER_LIMIT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to retrieve the number of parallel process for bestoffer
     *
     * @param null $scopeCode
     * @return int
     */
    public function getBestOffersProcessesNumber($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_BEST_OFFER_PARALLEL_PROCESSES_NUMBER,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Function to retrieve the best offers max
     *
     * @param null $scopeCode
     * @return string
     */
    public function getBestOffersMax($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_BEST_OFFER_MAX, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }


    /**
     * Function to get Catgory Api URL
     *
     * @return string|null
     */
    public function getCategoryApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }
        return $this->envConfig['categories_api_url'] ?? '';
    }

    /**
     * Returns Number of product to publish in queue message
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function getProductsNumberPerMessage($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_PRODUCTS_PER_MESSAGE,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Returns Number of offers to publish in queue message
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function getOffersNumberPerMessage($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_OFFERS_PER_MESSAGE,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Returns TRUE if exported amounts must include discounts if applicable, FALSE otherwise
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function getOrdersExportIncludeDiscounts($scopeCode = null)
    {
        return $this->isSetFlag(
            self::XML_PATH_EXPORT_ORDER_INCLUDE_DISCOUNT,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Function to retrieve the sellers limit by page in api calls
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getSellersLimit($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_SELLERS_LIMIT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Returns Number of sellers to publish in queue message
     *
     * @param null|string $scopeCode
     *
     * @return bool
     */
    public function getSellersNumberPerMessage($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_SELLERS_PER_MESSAGE,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Function to retrieve the sellers consumer parallel process number
     *
     * @param null $scopeCode
     *
     * @return int
     */
    public function getSellersConsumerProcessNumber($scopeCode = null)
    {
        return $this->getValue(
            self::XML_PATH_IMPORT_CATALOG_SELLERS_CONSUMER_PROCESSES_NUMBER,
            $scopeCode,
            ScopeInterface::SCOPE_WEBSITE
        ) ?? 1;
    }

    /**
     * Function to get Environment
     *
     * @param null $scopeCode
     *
     * @return string|null
     */
    public function getEnvironment($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_ENVIRONMENT, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to get Environments Data
     *
     * @param string|null $scopeCode
     *
     * @return string|null
     */
    public function getEnvironments($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_ENVIRONMENTS, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * Function to get Api URL
     *
     * @return string|null
     */
    public function getApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }

        return $this->envConfig['api_url'];
    }

    /**
     * Function to get Api URL
     *
     * @return string|null
     */
    public function getAuthApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }
        return $this->envConfig['auth_api_url'];
    }

    /**
     * Function to get Api URL
     *
     * @return string|null
     */
    public function getTokenApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }
        return $this->envConfig['token_api_url'];
    }

    /**
     * Function to get Products Api URL
     *
     * @return string|null
     */
    public function getProductsApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }
        return $this->envConfig['products_api_url'];
    }

    /**
     * Function to get Offers Api URL
     *
     * @return string|null
     */
    public function getOffersApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }

        return $this->envConfig['offers_api_url'];
    }

    /**
     * Function to get Orders Api URL
     *
     * @return string|null
     */
    public function getOrdersApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }

        return $this->envConfig['orders_api_url'];
    }

    /**
     * Function to get Orders Api URL
     *
     * @return string|null
     */
    public function getSellersApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }

        return $this->envConfig['sellers_api_url'];
    }

    /**
     * Function to get Discussion Api URL
     *
     * @return string|null
     */
    public function getGrcApiUrl()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }

        return $this->envConfig['discussions_api_url'];
    }

    /**
     * Function to get API version
     *
     * @return string|null
     */
    public function getApiVersion()
    {
        if ($this->envConfig === null) {
            $this->envConfig = $this->getEnvConfig();
        }

        return $this->isDeveloperMode() ?  $this->envConfig['api_version'] : 'V3';
    }

    /**
     * @return string
     */
    protected function getEnvConfig()
    {
        $envs = $this->getEnvironments();
        return $envs[$this->getEnvironment()];
    }

    /**
     * @param $scopeCode
     * @return string|null
     */
    public function getCatalogProductImportDeltaEnabled($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_PRODUCTS_DELTA_ENABLE, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * @param $scopeCode
     * @return string|null
     */
    public function getCatalogOfferImportDeltaEnabled($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_OFFERS_DELTA_ENABLE, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * @param $scopeCode
     * @return string|null
     */
    public function getCatalogSellerImportDeltaEnabled($scopeCode = null)
    {
        return $this->getValue(self::XML_PATH_IMPORT_CATALOG_SELLERS_DELTA_ENABLE, $scopeCode, ScopeInterface::SCOPE_WEBSITE);
    }
}
