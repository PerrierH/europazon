<?php

namespace Maas\ImportExport\Model;

use Maas\ImportExport\Model\Service\Client\Curl;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;

/**
 * Class AbstractImportV2Adapter
 *
 * @package Maas\ImportExport\Model
 */
abstract class AbstractImportV2Adapter extends AbstractImportAdapter
{
    const TOTAL_ITEMS_COUNT_CACHE_KEY = 'maas-importexport-total-items-count-%s';

    /**
     * @var Curl
     */
    protected $curlClient = null;

    /**
     * @var CurlFactory
     */
    protected $curlClientFactory;

    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * AbstractImportAdapter Constructor
     *
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     */
    public function __construct(
        CurlFactory    $curlClientFactory,
        CacheInterface $cache
    )
    {
        $this->curlClientFactory = $curlClientFactory;
        $this->cache = $cache;
    }

    /**
     * @param AbstractImportExportApi $api
     *
     * @return array
     */
    public function doRequest(AbstractImportExportApi $api)
    {
        $this->capitalizeBearer($api);
        $this->addAllFields($api);
        $this->handlePagination($api);

        $result = $this->doOriginalRequest($api);
        if ($result['status'] >= 400) {
            return $result;
        }
        $responseContents = json_decode($result['response'] ?? '', 1);
        $responseContents = $this->convertResult($api, $responseContents);
        $result['response'] = json_encode($responseContents);
        return $result;
    }

    /**
     * @param AbstractImportExportApi $api
     * @param $result
     *
     * @return array
     */
    protected function convertResult(AbstractImportExportApi $api, $result)
    {
        $totalItemsCount = $this->cache->load(sprintf(self::TOTAL_ITEMS_COUNT_CACHE_KEY, $this->reportId));
        return [
            'totalItemsCount' => $totalItemsCount ? intval($totalItemsCount) : 0,
            'count' => count($result['items']),
            'items' => $this->convertItems($result['items'])
        ];
    }

    /**
     * @param AbstractImportExportApi $api
     *
     * @return int|mixed
     */
    public function getTotalItemsCount(AbstractImportExportApi $api)
    {
        $this->capitalizeBearer($api);
        $headers = $api->getHeaders();
        $headersAssoc = [];
        foreach ($headers as $header) {
            $headerParts = explode(':', $header);
            if (count($headerParts) >= 2) {
                $headerName = array_shift($headerParts);
                $headerParts[0] = ltrim($headerParts[0]);
                $headersAssoc[$headerName] = implode(':', $headerParts);
            }
        }
        if (is_null($this->curlClient)) {
            $this->curlClient = $this->curlClientFactory->create();
        }
        $this->curlClient->setHeaders($headersAssoc);
        $url = $this->getEndPointUrl($api);
        $this->curlClient->callHead($url);
        $totalItemsCount = 0;
        if ($this->curlClient->getStatus() == 200) {
            $result = $this->curlClient->getHeaders();
            // @TODO [DSI_5245-1638] : Choose between lowercase and Uppercase when the API result will be stable
            $indexXTotalCount = array_key_exists('X-Total-Count', $result) ? 'X-Total-Count' : 'x-total-count';
            $totalItemsCount = $result[$indexXTotalCount] ? intval($result[$indexXTotalCount]) : 0;
            // @TODO END
        }
        $this->cache->save(
            $totalItemsCount,
            sprintf(self::TOTAL_ITEMS_COUNT_CACHE_KEY, $this->reportId),
            [sprintf(AbstractImportExportApi::CACHE_TAG_IMPORTEXPORT_BY_REPORT, $this->reportId)]);
        return $totalItemsCount;
    }

    /**
     * @param AbstractImportExportApi $api
     */
    protected function capitalizeBearer(AbstractImportExportApi $api)
    {
        $headers = $api->getHeaders();
        foreach ($headers as $i => $header) {
            if (strpos($header, 'Authorization: bearer') !== false) {
                $headers[$i] = str_replace('Authorization: bearer', 'Authorization: Bearer', $header);
            }
        }
        $api->setHeaders($headers);
    }

    protected function handlePagination(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        if (isset($args['page'])) {
            $args['pageIndex'] = $args['page'] - 1;
            unset($args['page']);
        }

        if (isset($args['limit'])) {
            $args['pageSize'] = $args['limit'];
            unset($args['limit']);
        }
        $api->setArgs($args);
    }

    abstract protected function convertItems($items);

    abstract protected function addAllFields(AbstractImportExportApi $api);
}