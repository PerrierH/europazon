<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\AttributeInterface;
use Maas\ImportExport\Api\Data\Catalog\AttributesGroupInterface;
use Magento\Framework\DataObject;

/**
 * Class AttributesGroup
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class AttributesGroup extends DataObject implements AttributesGroupInterface
{

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData('code');
    }

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        return $this->setData('code', $code);
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return $this->getData('label');
    }

    /**
     * @param string $label
     *
     * @return $this
     */
    public function setLabel($label)
    {
        return $this->setData('label', $label);
    }

    /**
     * @return int
     */
    public function getPosition()
    {
        return $this->getData('position');
    }

    /**
     * @param int $position
     *
     * @return $this
     */
    public function setPosition($position)
    {
        return $this->setData('position', $position);
    }

    /**
     * @return AttributeInterface[]
     */
    public function getAttributes()
    {
        return $this->getData('attributes');
    }

    /**
     * @param AttributeInterface[] $attributes
     *
     * @return $this
     */
    public function setAttributes($attributes)
    {
        return $this->setData('attributes', $attributes);
    }

}
