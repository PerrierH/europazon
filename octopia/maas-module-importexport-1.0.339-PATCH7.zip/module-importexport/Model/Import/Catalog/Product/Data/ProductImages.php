<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\ProductImagesInterface;
use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Magento\Framework\DataObject;

/**
 * Class ProductImages
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class ProductImages extends DataObject implements ProductImagesInterface
{
    /**
     * @return ImageInterface[]
     */
    public function getSmall()
    {
        return $this->getDataOrDefault('small', []);
    }

    /**
     * Returns a field's value, or a default value if none exists
     *
     * @param string $key
     * @param mixed $defaultValue
     *
     * @return mixed
     */
    protected function getDataOrDefault($key, $defaultValue)
    {
        return $this->hasData($key) ? $this->getData($key) : $defaultValue;
    }

    /**
     * @param ImageInterface[] $small
     *
     * @return $this
     */
    public function setSmall($small)
    {
        return $this->setData('small', $small);
    }

    /**
     * @return ImageInterface[]
     */
    public function getMedium()
    {
        return $this->getDataOrDefault('medium', []);
    }

    /**
     * @param ImageInterface[] $medium
     *
     * @return $this
     */
    public function setMedium($medium)
    {
        return $this->getData('medium', $medium);
    }

    /**
     * @return ImageInterface[]
     */
    public function getLarge()
    {
        return $this->getDataOrDefault('large', []);
    }

    /**
     * @param ImageInterface[] $large
     *
     * @return $this
     */
    public function setLarge($large)
    {
        return $this->setData('large', $large);
    }

}
