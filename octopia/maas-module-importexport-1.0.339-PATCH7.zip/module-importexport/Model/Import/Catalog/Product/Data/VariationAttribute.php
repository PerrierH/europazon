<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\VariationAttributeInterface;
use Magento\Framework\DataObject;

/**
 * Class VariationAttribute
 *
 * @package Maas\ImportExport\Data\Catalog\Data
 * @codeCoverageIgnore
 */
class VariationAttribute extends DataObject implements VariationAttributeInterface
{
    /**
     * @return string
     */
    public function getLabel()
    {
        return $this->getData('label');
    }

    /**
     * @param string $label
     *
     * @return $this
     */
    public function setLabel($label)
    {
        return $this->setData('label', $label);
    }

    /**
     * @return string[]
     */
    public function getValues()
    {
        return $this->getData('values');
    }

    /**
     * @param string[] $values
     *
     * @return $this
     */
    public function setValues($values)
    {
        return $this->setData('values', $values);
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData('code');
    }

    /**
     * @param string $code
     * @return $this
     */
    public function setCode($code)
    {
        return $this->setData('code', $code);
    }
}
