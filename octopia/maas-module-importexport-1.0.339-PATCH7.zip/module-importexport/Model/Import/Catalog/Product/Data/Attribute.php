<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\AttributeInterface;
use Magento\Framework\DataObject;

/**
 * Class Attribute
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class Attribute extends DataObject implements AttributeInterface
{
    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData('code');
    }

    /**
     * @param $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        return $this->setData('code', $code);
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return $this->getData('label');
    }

    /**
     * @param $label
     *
     * @return $this
     */
    public function setLabel($label)
    {
        return $this->setData('label', $label);
    }

    /**
     * @return string[]|string|null
     */
    public function getValue()
    {
        return $this->getData('value');
    }

    /**
     * @param string[]|string|null $value
     *
     * @return $this
     */
    public function setValue($value)
    {
        return $this->setData('value', $value);
    }

    /**
     * @return string
     */
    public function getValueType()
    {
        return $this->getData('valueType');
    }

    /**
     * @param $valueType
     *
     * @return $this
     */
    public function setValueType($valueType)
    {
        return $this->setData('valueType', $valueType);
    }

    /**
     * @return string
     */
    public function getUnit()
    {
        return $this->getData('unit');
    }

    /**
     * @param $unit
     *
     * @return $this
     */
    public function setUnit($unit)
    {
        return $this->setData('unit', $unit);
    }

    /**
     * @return int
     */
    public function getPosition()
    {
        return $this->getData('position');
    }

    /**
     * @param int $position
     *
     * @return $this
     */
    public function setPosition($position)
    {
        return $this->setData('position', $position);
    }
}
