<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\BrandImagesInterface;
use Maas\ImportExport\Api\Data\Catalog\BrandInterface;
use Magento\Framework\DataObject;

/**
 * Class Brand
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class Brand extends DataObject implements BrandInterface
{
    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData('code');
    }

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        return $this->setData('code', $code);
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return $this->getData('label');
    }

    /**
     * @param string $label
     *
     * @return $this
     */
    public function setLabel($label)
    {
        return $this->setData('label', $label);
    }

    /**
     * @return BrandImagesInterface
     */
    public function getImage()
    {
        return $this->getData('image');
    }

    /**
     * @param BrandImagesInterface $images
     *
     * @return $this
     */
    public function setImage(BrandImagesInterface $images)
    {
        return $this->setData('image', $images);
    }

}
