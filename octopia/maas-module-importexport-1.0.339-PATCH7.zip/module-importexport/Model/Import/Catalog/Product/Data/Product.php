<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\AttributesGroupInterface;
use Maas\ImportExport\Api\Data\Catalog\BrandInterface;
use Maas\ImportExport\Api\Data\Catalog\ProductImagesInterface;
use Maas\ImportExport\Api\Data\Catalog\ProductInterface;
use Maas\ImportExport\Api\Data\Catalog\VariationAttributeInterface;
use Magento\Framework\DataObject;

/**
 * Class Product
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class Product extends DataObject implements ProductInterface
{
    /**
     * @return string
     */
    public function getProductId()
    {
        return $this->getData('productId');
    }

    /**
     * @param string $productId
     *
     * @return $this
     */
    public function setProductId($productId)
    {
        return $this->setData('productId', $productId);
    }

    /**
     * @return string
     */
    public function getGtin()
    {
        return $this->getData('gtin');
    }

    /**
     * @param string $gtin
     *
     * @return $this
     */
    public function setGtin($gtin)
    {
        return $this->setData('gtin', $gtin);
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->getData('title');
    }

    /**
     * @param string $title
     *
     * @return $this
     */
    public function setTitle($title)
    {
        return $this->setData('title', $title);
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->getData('description');
    }

    /**
     * @param string $description
     *
     * @return $this
     */
    public function setDescription($description)
    {
        return $this->setData('description', $description);
    }

    /**
     * @return BrandInterface
     */
    public function getBrand()
    {
        return $this->getData('brand');
    }

    /**
     * @param BrandInterface $brand
     *
     * @return $this
     */
    public function setBrand(BrandInterface $brand)
    {
        return $this->setData('brand', $brand);
    }

    /**
     * @return string
     */
    public function getCategoryId()
    {
        return $this->getData('categoryId');
    }

    /**
     * @param string $categoryId
     *
     * @return $this
     */
    public function setCategoryId($categoryId)
    {
        return $this->setData('categoryId', $categoryId);
    }

    /**
     * @return ProductImagesInterface
     */
    public function getImages()
    {
        return $this->getData('images');
    }

    /**
     * @param ProductImagesInterface $images
     *
     * @return $this
     */
    public function setImages(ProductImagesInterface $images)
    {
        return $this->setData('images', $images);
    }

    /**
     * @return int
     */
    public function getWeight()
    {
        return $this->getData('weight');
    }

    /**
     * @param int $weight
     *
     * @return $this
     */
    public function setWeight($weight)
    {
        return $this->setData('weight', $weight);
    }

    /**
     * @return string
     */
    public function getVariationGroupId()
    {
        return $this->getData('variationGroupId');
    }

    /**
     * @param string $variationGroupId
     *
     * @return $this
     */
    public function setVariationGroupId($variationGroupId)
    {
        return $this->setData('variationGroupId', $variationGroupId);
    }

    /**
     * @return VariationAttributeInterface[]
     */
    public function getVariationAttributes()
    {
        return $this->getData('variationAttributes');
    }

    /**
     * @param VariationAttributeInterface[] $variationAttributes
     *
     * @return $this
     */
    public function setVariationAttributes($variationAttributes)
    {
        return $this->setData('variationAttributes', $variationAttributes);
    }

    /**
     * @return AttributesGroupInterface[]
     */
    public function getAttributesGroup()
    {
        return $this->getData('attributesGroup');
    }

    /**
     * @param AttributesGroupInterface[] $attributesGroup
     *
     * @return $this
     */
    public function setAttributesGroup($attributesGroup)
    {
        return $this->setData('attributesGroup', $attributesGroup);
    }

    /**
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData('updatedAt');
    }

    /**
     * @param string $updatedAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData('updatedAt', $updatedAt);
    }

    /**
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData('createdAt');
    }

    /**
     * @param string $createdAt
     *
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData('createdAt', $createdAt);
    }

    /**
     * @return string
     */
    public function getStatus()
    {
        return $this->getData('status');
    }

    /**
     * @param string $status
     *
     * @return $this
     */
    public function setStatus($status)
    {
        return $this->setData('status', $status);
    }

    /**
     * @return string|null
     */
    public function getThirdLevelCategoryLabel()
    {
        return $this->getData('thirdLevelCategoryLabel');
    }

    /**
     * @param string $thirdLevelLabel
     * @return $this
     */
    public function setThirdLevelCategoryLabel($thirdLevelLabel)
    {
        return $this->setData('thirdLevelCategoryLabel', $thirdLevelLabel);
    }

    /**
     * @inheirtDoc
     */
    public function getAttributeSetId(): ?int
    {
        return $this->getData('attribute_set_id');
    }

    /**
     * @inheirtDoc
     */
    public function setAttributeSetId(?int $attributeSetId)
    {
        return $this->setData('attribute_set_id', $attributeSetId);
    }
}
