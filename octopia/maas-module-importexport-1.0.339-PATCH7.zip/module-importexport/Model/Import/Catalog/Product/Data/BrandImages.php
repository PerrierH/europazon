<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Data;

use Maas\ImportExport\Api\Data\Catalog\BrandImagesInterface;
use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Magento\Framework\DataObject;

/**
 * Class Images
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class BrandImages extends DataObject implements BrandImagesInterface
{
    /**
     * @return ImageInterface
     */
    public function getSmall()
    {
        return $this->getData('small');
    }

    /**
     * @param ImageInterface $small
     *
     * @return $this
     */
    public function setSmall(ImageInterface $small)
    {
        return $this->setData('small', $small);
    }

    /**
     * @return ImageInterface
     */
    public function getMedium()
    {
        return $this->getData('medium');
    }

    /**
     * @param ImageInterface $medium
     *
     * @return $this
     */
    public function setMedium(ImageInterface $medium)
    {
        return $this->getData('medium', $medium);
    }

    /**
     * @return ImageInterface
     */
    public function getLarge()
    {
        return $this->getData('large');
    }

    /**
     * @param ImageInterface $large
     *
     * @return $this
     */
    public function setLarge(ImageInterface $large)
    {
        return $this->setData('large', $large);
    }

}
