<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product;

use Maas\ImportExport\Api\Data\ProductImportMessageInterfaceFactory;
use Maas\ImportExport\Model\Import\AbstractMessageBuilder;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;

/**
 * Class MessageBuilder
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product
 */
class MessageBuilder extends AbstractMessageBuilder
{

    /**
     * @var ConfigProxy
     */
    private $config;

    /**
     * MessageBuilder constructor.
     * @param ProductImportMessageInterfaceFactory $factory
     * @param ConfigProxy $config
     */
    public function __construct(
        ProductImportMessageInterfaceFactory $factory,
        ConfigProxy $config
    )
    {
        $this->config = $config;
        parent::__construct($factory);
    }

    /**
     * @inheritDoc
     */
    public function isSpaceLeft($entity)
    {
        return count($this->entities) < $this->config->getProductsNumberPerMessage();
    }


}
