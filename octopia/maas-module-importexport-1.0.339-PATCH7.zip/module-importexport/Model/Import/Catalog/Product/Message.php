<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product;

use Maas\ImportExport\Api\Data\ProductImportMessageInterface;
use Maas\ImportExport\Model\ImportMessage;

/**
 * Class Message
 *
 * Message to send. The logic is in the parent class, and the implemented interface
 * allows serializing/unserializing without any class matching issues
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product
 */
class Message extends ImportMessage implements ProductImportMessageInterface
{
}
