<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Type;

use Magento\ConfigurableImportExport\Model\Import\Product\Type\Configurable as ConfigurableAlias;

/**
 * Importing configurable products
 * @package Magento\ConfigurableImportExport\Model\Import\Product\Type
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Configurable extends ConfigurableAlias
{
    /**
     * In case we've dynamically added new attribute option during import we need to add it to our cache
     * in order to keep it up to date.
     *
     * @todo Try an optimal solution in order to update only the need part of the cache (Check AddAttributeOption)
     *
     */
    public function refreshCacheAttributes()
    {
        // Need to force reload attribute cache
        self::$commonAttributesCache = [];
        $this->_initAttributes();
    }
}