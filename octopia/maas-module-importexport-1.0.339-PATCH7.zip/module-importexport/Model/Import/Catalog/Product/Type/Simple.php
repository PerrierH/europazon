<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Type;
use Magento\CatalogImportExport\Model\Import\Product\Type\Simple as SimpleAlias;

/**
 * Import entity simple product type
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Simple extends SimpleAlias
{
    
}