<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product;

use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Model\Product as ProductModel;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use \Magento\CatalogImportExport\Model\Import\Product as Product;
use \Magento\CatalogImportExport\Model\Import\Product\RowValidatorInterface as RowValidatorInterface;
use Magento\CatalogImportExport\Model\Import\Product\Validator as ValidatorAlias;
use Magento\Eav\Api\AttributeOptionManagementInterface;
use Magento\Eav\Api\Data\AttributeOptionInterfaceFactory;
use Magento\Eav\Api\Data\AttributeOptionLabelInterfaceFactory;
use Magento\Eav\Model\Entity\Attribute\OptionLabel;
use Magento\Eav\Model\Entity\Attribute\Source\Table;
use Magento\Eav\Model\Entity\Attribute\Source\TableFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Stdlib\StringUtils;
use Psr\Log\LoggerInterface;

/**
 * Class Validator
 * @package Maas\ImportExport\Model\Import\Catalog\Product
 */
class Validator extends ValidatorAlias
{
    /**
     * @var array
     */
    protected $dynamicallyOptionAdded = [];

    /**
     * @var ProductAttributeRepositoryInterface
     */
    protected $attributeRepository;

    /**
     * @var TableFactory
     */
    protected $tableFactory;

    /**
     * @var AttributeOptionLabelInterfaceFactory
     */
    protected $optionLabelFactory;

    /**
     * @var AttributeOptionInterfaceFactory
     */
    protected $optionFactory;

    /**
     * @var array
     */
    protected $attributeValues;

    /**
     * @var LoggerInterface
     */
    private $_logger;

    /**
     * @var AttributeOptionManagementInterface
     */
    private  $attributeOptionManagement;

    /**
     * Validator constructor.
     * @param StringUtils $string
     * @param AttributeOptionManagementInterface $attributeOptionManagement
     * @param ProductAttributeRepositoryInterface $attributeRepository
     * @param AttributeOptionLabelInterfaceFactory $optionLabelFactory
     * @param AttributeOptionInterfaceFactory $optionFactory
     * @param TableFactory $tableFactory
     * @param LoggerInterface $logger
     * @param array $validators
     */
    public function __construct(
        StringUtils $string,
        AttributeOptionManagementInterface $attributeOptionManagement,
        ProductAttributeRepositoryInterface $attributeRepository,
        AttributeOptionLabelInterfaceFactory $optionLabelFactory,
        AttributeOptionInterfaceFactory $optionFactory,
        TableFactory $tableFactory,
        LoggerInterface $logger,
        array $validators = []
    ) {
        $this->attributeRepository = $attributeRepository;
        $this->attributeOptionManagement = $attributeOptionManagement;
        $this->optionLabelFactory = $optionLabelFactory;
        $this->optionFactory = $optionFactory;
        $this->_logger = $logger;
        $this->tableFactory = $tableFactory;
        parent::__construct($string, $validators);
    }

    /**
     * @param string $attrCode
     * @param array $attrParams
     * @param array $rowData
     * @return bool
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @throws LocalizedException
     */
    public function isAttributeValid($attrCode, array $attrParams, array $rowData)
    {
        $this->_rowData = $rowData;
        if (isset($rowData['product_type']) && !empty($attrParams['apply_to'])
            && !in_array($rowData['product_type'], $attrParams['apply_to'])
        ) {
            return true;
        }

        if (!$this->isRequiredAttributeValid($attrCode, $attrParams, $rowData)) {
            $this->_addMessages(
                [
                    sprintf(
                        $this->context->retrieveMessageTemplate(
                            RowValidatorInterface::ERROR_VALUE_IS_REQUIRED
                        ),
                        $attrCode
                    )
                ]
            );
            return false;
        }

        if (!isset($rowData[$attrCode]) || !strlen(trim($rowData[$attrCode]))) {
            return true;
        }
        switch ($attrParams['type']) {
            case 'varchar':
            case 'text':
                $valid = $this->textValidation($attrCode, $attrParams['type']);
                break;
            case 'decimal':
            case 'int':
                $valid = $this->numericValidation($attrCode, $attrParams['type']);
                break;
            case 'select':
            case 'boolean':
            case 'multiselect':
                $values = $this->context->parseMultiselectValues($rowData[$attrCode]);
                $valid = true;

                // Start custom
                foreach ($values as $value) {

                    // If option not exist and not already dynamically added
                    if (!empty($value) && !isset($attrParams['options'][strtolower($value)]) && !isset($this->dynamicallyOptionAdded[$attrCode][strtolower($value)]) && $attrParams['type'] != 'boolean') {

                        // Add option dynamically
                        if ($this->createOrGetId($attrCode, $value)) {
                            // Add new option value dynamically created to the different entityTypeModel cache
                            $entityTypeModel = $this->context->retrieveProductTypeByName($rowData['product_type']);
                            $configurableEntityTypeModel = $this->context->retrieveProductTypeByName('configurable');

                            // Refresh attributes cache for entityTypeModel cache
                            if ($entityTypeModel) {
                                $entityTypeModel->reinitAttributes();
                            }

                            if ($configurableEntityTypeModel) {
                                $configurableEntityTypeModel->refreshCacheAttributes();
                            }

                            $this->dynamicallyOptionAdded[$attrCode][strtolower($value)] = true;
                            $attrParams['options'][strtolower($value)] = true;
                        }
                    }
                }

                if (isset($this->dynamicallyOptionAdded[$attrCode])) {
                    foreach ($this->dynamicallyOptionAdded[$attrCode] as $key => $value) {
                        $attrParams['options'][$key] = $value;
                    }
                }
                // end custom
                foreach ($values as $value) {
                    $valid = $valid && isset($attrParams['options'][strtolower($value)]);
                }
                if (!$valid) {
                    $this->_addMessages(
                        [
                            sprintf(
                                $this->context->retrieveMessageTemplate(
                                    RowValidatorInterface::ERROR_INVALID_ATTRIBUTE_OPTION
                                ),
                                $attrCode
                            )
                        ]
                    );
                }

                break;
            case 'datetime':
                $val = trim($rowData[$attrCode]);
                $valid = strtotime($val) !== false;
                if (!$valid) {
                    $this->_addMessages([RowValidatorInterface::ERROR_INVALID_ATTRIBUTE_TYPE]);
                }
                break;
            default:
                $valid = true;
                break;
        }

        if ($valid && !empty($attrParams['is_unique'])) {
            if (isset($this->_uniqueAttributes[$attrCode][$rowData[$attrCode]])
                && ($this->_uniqueAttributes[$attrCode][$rowData[$attrCode]] != $rowData[Product::COL_SKU])) {
                $this->_addMessages([RowValidatorInterface::ERROR_DUPLICATE_UNIQUE_ATTRIBUTE]);
                return false;
            }
            $this->_uniqueAttributes[$attrCode][$rowData[$attrCode]] = $rowData[Product::COL_SKU];
        }

        if (!$valid) {
            $this->setInvalidAttribute($attrCode);
        }

        return (bool)$valid;

    }

    /**
     * Get attribute by code.
     *
     * @param string $attributeCode
     * @return ProductAttributeInterface
     * @throws NoSuchEntityException
     */
    public function getAttribute($attributeCode)
    {
        return $this->attributeRepository->get($attributeCode);
    }

    /**
     * @param $attributeCode
     * @param $label
     * @return int
     * @throws LocalizedException
     * @throws \Exception
     */
    public function createOrGetId($attributeCode, $label) {
        if (strlen($label) < 1) {
            throw new LocalizedException(
                __('Label for %1 must not be empty.', $attributeCode)
            );
        }
        try {
            $optionId = $this->getOptionId($attributeCode, $label);
            if (!$optionId) {
                // If no, add it.

                /** @var OptionLabel $optionLabel */
                $optionLabel = $this->optionLabelFactory->create();
                $optionLabel->setStoreId(0);
                $optionLabel->setLabel($label);

                $option = $this->optionFactory->create();
                $option->setLabel($optionLabel->getLabel());
                $option->setStoreLabels([$optionLabel]);
                $option->setSortOrder(0);
                $option->setIsDefault(false);

                $this->attributeOptionManagement->add(
                    ProductModel::ENTITY,
                    $this->getAttribute($attributeCode)->getAttributeId(),
                    $option
                );
                // Get the inserted ID. Should be returned from the installer, but it isn't.
                $optionId = $this->getOptionId($attributeCode, $label, true);
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
        // Does it already exist?
        return $optionId;
    }

    /**
     * Find the ID of an option matching $label, if any.
     *
     * @param string $attributeCode Attribute code
     * @param string $label Label to find
     * @param bool $force If true, will fetch the options even if they're already cached.
     * @return int|false
     * @throws NoSuchEntityException
     */
    public function getOptionId($attributeCode, $label, $force = false)
    {
        /** @var Attribute $attribute */
        $attribute = $this->getAttribute($attributeCode);

        // Build option array if necessary
        if ($force === true || !isset($this->attributeValues[ $attribute->getAttributeId() ])) {
            $this->attributeValues[ $attribute->getAttributeId() ] = [];
            // We have to generate a new sourceModel instance each time through to prevent it from
            // referencing its _options cache. No other way to get it to pick up newly-added values.
            /** @var Table $sourceModel */
            $sourceModel = $this->tableFactory->create();
            $sourceModel->setAttribute($attribute);
            foreach ($sourceModel->getAllOptions() as $option) {
                $this->attributeValues[ $attribute->getAttributeId() ][ $option['label'] ] = $option['value'];
            }
        }
        // Return option ID if exists
        if (isset($this->attributeValues[ $attribute->getAttributeId() ][ $label ])) {
            return $this->attributeValues[ $attribute->getAttributeId() ][ $label ];
        }
        // Return false if does not exist
        return false;
    }
}
