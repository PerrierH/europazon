<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product;

use Magento\CatalogImportExport\Model\Import\Product\CategoryProcessor as StandardCategoryProcessor;

/**
 * Class CategoryProcessor
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product
 * @codeCoverageIgnore No logic, delegates to parent
 */
class CategoryProcessor extends StandardCategoryProcessor
{
    /**
     * @return $this
     */
    public function reinitCategories()
    {
        $this->categories = [];
        $this->initCategories();
        return $this;
    }
}