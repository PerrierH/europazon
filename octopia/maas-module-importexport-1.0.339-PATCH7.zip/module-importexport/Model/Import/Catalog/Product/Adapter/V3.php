<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Adapter;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\AbstractImportV3Adapter;
use Maas\ImportExport\Model\Import\Catalog\Product\Adapter\Converter\Product;
use Maas\ImportExport\Model\Service\Client\Curl;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;
use Maas\ImportExport\Model\Import\Catalog\Product as ProductModel;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\ImportExport\Model\Config\Proxy as ConfigModel;

/**
 * Class V3
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product\Adapter
 */
class V3 extends AbstractImportV3Adapter
{
    const API_REQUEST_ENDPOINT = '/products';

    /**
     * @var Converter\Product
     */
    protected $productConverter;

    /**
     * @var ConfigModel
     */
    protected $configModel;

    /**
     * @var string
     */
    protected $entityType = 'catalog_product';


    /**
     * V3 constructor.
     *
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     * @param Product $productConverter
     * @param ReportResource $reportResource
     * @param ConfigModel $configModel
     */
    public function __construct(
        CurlFactory    $curlClientFactory,
        CacheInterface $cache,
        Product        $productConverter,
        ReportResource $reportResource,
        ConfigModel    $configModel
    )
    {
        parent::__construct($curlClientFactory, $cache, $reportResource);
        $this->productConverter = $productConverter;
        $this->configModel = $configModel;
    }

    /**
     * @param AbstractImportExportApi $api
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function addAllFields(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        $args['fields'] = 'productId,gtin,title,description,updatedAt,brand,category,images,attributes,groupReference,variantAttributes';

        $api->setArgs($args);
    }

    /**
     * @param AbstractImportExportApi $api
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function addFilters(AbstractImportExportApi $api)
    {
        if ($result = $this->hasRan(ProductModel::MAAS_LOG_MODULE, ProductModel::MAAS_LOG_ACTION, ProductModel::MAAS_LOG_OPERATION_TYPE)) {
            $maxProductsToImport = $this->configModel->getMaximumProductsToImport();
            $args = $api->getArgs();
            if (!$maxProductsToImport && $this->configModel->getCatalogProductImportDeltaEnabled()) {
                if (isset($result['sync_date'])) {
                    $args['updatedAtMin'] = $this->convertToApiDate($result['sync_date']);
                }
            }
            $args['status'] = 'ANY';
            $api->setArgs($args);
        }
    }

    /**
     * @param AbstractImportExportApi $api
     * @return string
     */
    protected function getEndPointUrl(AbstractImportExportApi $api)
    {
        $url = rtrim($api->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        $args = $api->getArgs();
        if ($args && array_key_exists('cursor', $args)) {
            $cursor = $args['cursor'];
            unset($args['cursor']);
        }

        return is_array($api->getArgs()) && sizeof($api->getArgs()) ? $url . '?' . http_build_query($args)
            . (isset($cursor) ? '&cursor=' . $cursor : '') : $url;
    }

    /**
     * @param $items
     * @return array
     */
    protected function convertItems($items)
    {
        $convertedItems = [];
        foreach ($items as $item) {
            $convertedItem = $this->productConverter->convertItemData($item);
            if ($convertedItem) {
                $convertedItems[] = $convertedItem;
            }
        }
        return $convertedItems;
    }
}
