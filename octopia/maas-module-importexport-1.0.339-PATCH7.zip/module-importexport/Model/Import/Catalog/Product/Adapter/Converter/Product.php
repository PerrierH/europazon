<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Adapter\Converter;

use DateTime;
use Exception;
use Maas\ImportExport\Model\Service\CategoryAttributeSetResolver;
use Magento\Eav\Api\Data\AttributeSetInterface;

/**
 * Class Product
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product\Adapter\Converter
 */
class Product
{
    /**
     * @var array
     */
    protected static $attributesDataInCache = [];

    /**
     * @var array
     */
    protected static $attributesSetInCache = [];

    /**
     * @var CategoryAttributeSetResolver
     */
    protected $categoryAttributeSetResolver;

    /**
     * Product constructor.
     * @param CategoryAttributeSetResolver $categoryAttributeSetResolver
     */
    public function __construct(CategoryAttributeSetResolver $categoryAttributeSetResolver)
    {
        $this->categoryAttributeSetResolver = $categoryAttributeSetResolver;
    }

    /**
     * @param array $item
     * @return array
     * @throws Exception
     */
    public function convertItemData(array $item): array
    {
        if (array_key_exists('categoryId', $item)) {
            $itemReturned = [];
            $categoryMaasId = $item['categoryId'];
            $attributeSet = $this->resolveAttributeSetFromCategoryMaasId($categoryMaasId);
            if ($attributeSet && $attributeSet->getId()) {
                $itemReturned['attribute_set_id'] = $attributeSet->getId();
            }
            return $itemReturned;
        }
        $createdAt = date("Y-m-d H:i:s");
        $maasUpdatedAt = $this->convertTimeFormat($item['updatedAt']);
        $categoryMaasId = is_array($item['category']) ? $item['category']['secondLevelId'] : $item['category'];

        $attributesDataForCategory = [];
        $attributeSet = $this->resolveAttributeSetFromCategoryMaasId($categoryMaasId);
        if (array_key_exists($categoryMaasId, self::$attributesDataInCache)) {
            $attributesDataForCategory = self::$attributesDataInCache[$categoryMaasId];
        } elseif ($attributeSet && $attributeSet->getId()) {
            $attributesDataForCategory = $this->categoryAttributeSetResolver
                ->getAttributesDataByAttributeSet($attributeSet);
            self::$attributesDataInCache[$categoryMaasId] = $attributesDataForCategory;
        }

        $brand = [
            'code' => array_key_exists('brand', $item) ? $item['brand']['code'] : '',
            'label' => array_key_exists('brand', $item) ? $item['brand']['label'] : '',
            'image' => []
        ];
        $convertedImages = [];
        if (array_key_exists('images', $item)) {
            foreach ($item['images'] as $imagesData) {
                if (array_key_exists('renditions', $imagesData)) {
                    foreach ($imagesData['renditions'] as $rendition) {
                        $key = strtolower($rendition['name']);
                        if (!array_key_exists($key, $convertedImages)) {
                            $convertedImages[$key] = [];
                        }
                        $convertedImages[$key][] = [
                            'format' => $key,
                            'title' => $item['title'] . ' - ' . $rendition['name'],
                            'url' => $rendition['url'],
                            'size' => '0',
                            'width' => $rendition['width'],
                            'height' => $rendition['height'],
                            'updated_at' => $createdAt
                        ];
                    }
                } else {
                    $convertedImages['Large'][] = [
                        'format' => 'Large',
                        'title' => $item['title'],
                        'url' => $imagesData['url'],
                        'size' => '0',
                        'width' => '700',
                        'height' => '700',
                        'updated_at' => $createdAt
                    ];
                }
            }
        }
        $labelToValue = [];
        if (array_key_exists('attributes', $item)) {
            foreach ($item['attributes'] as $attributeData) {
                if (array_key_exists('label', $attributeData)) {
                    if (array_key_exists('value', $attributeData)) {
                        $labelToValue[$attributeData['label']] = $attributeData['value'];
                    } else {
                        $labelToValue[$attributeData['label']] = $attributeData['values'];
                    }
                }
            }
        }
        $attributes = $this->resolveAttributes($labelToValue, $attributesDataForCategory);
        $attributesGroup = [[
            'code' => 'General',
            'label' => 'General',
            'position' => 0,
            'createdAt' => $createdAt,
            'updatedAt' => $createdAt,
            'attributes' => $attributes
        ]];
        $itemReturned = [
            'productId' => array_key_exists('id', $item) ? $item['id'] : $item['productId'],
            'gtin' => (array_key_exists('gtin', $item) ? $item['gtin'] : $item['productId']),
            'title' => $item['title'],
            'description' => array_key_exists('description', $item) ? $item['description'] : '',
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
            'maas_updated_at' => $maasUpdatedAt,
            'status' => 'active',
            'brand' => $brand,
            'categoryId' => $categoryMaasId,
            'thirdLevelCategoryLabel' => is_array($item['category']) && array_key_exists('thirdLevelLabel', $item['category']) ? $item['category']['thirdLevelLabel'] : '',
            'images' => $convertedImages,
            'variationGroupId' => array_key_exists('groupReference', $item) ? $item['groupReference'] : '',
            'variationAttributes' => array_key_exists('variantAttributes', $item) ? $item['variantAttributes'] : '',
            'attributesGroup' => $attributesGroup
        ];
        if ($attributeSet && $attributeSet->getId()) {
            $itemReturned['attribute_set_id'] = $attributeSet->getId();
        }
        return $itemReturned;
    }

    /**
     * @param string $time
     * @return string
     * @throws Exception
     */
    protected function convertTimeFormat(string $time): string
    {
        return (new DateTime($time))->format('Y-m-d H:i:s');
    }

    /**
     * Resolve attributes from the maas category
     *
     * @param array $labelsToValue
     * @param array $attributesDataForCategory
     * @return array
     */
    protected function resolveAttributes(array $labelsToValue, array $attributesDataForCategory): array
    {
        $mapped = [];
        foreach ($labelsToValue as $label => $value) {
            $attributeCode = isset($attributesDataForCategory[$label]) ?
                $attributesDataForCategory[$label]['attribute_code'] : null;
            if ($attributeCode) {
                $mapped[] = [
                    'code' => 'att_' . substr($attributeCode, 9),
                    'label' => $label,
                    'value' => $value,
                    'valueType' => 'TEXT',
                    'unit' => null,
                    'position' => null
                ];
            }
        }
        return $mapped;
    }

    /**
     * Resolve the attribute set from category maas id
     *
     * @param string $categoryMaasId
     * @return AttributeSetInterface
     */
    private function resolveAttributeSetFromCategoryMaasId(string $categoryMaasId): ?AttributeSetInterface
    {
        if (array_key_exists($categoryMaasId, self::$attributesSetInCache)) {
            $attributeSet = self::$attributesSetInCache[$categoryMaasId];
        } else {
            $attributeSet = $this->categoryAttributeSetResolver->getAttributeSetByCategory($categoryMaasId);
            self::$attributesSetInCache[$categoryMaasId] = $attributeSet;
        }

        return $attributeSet;
    }
}
