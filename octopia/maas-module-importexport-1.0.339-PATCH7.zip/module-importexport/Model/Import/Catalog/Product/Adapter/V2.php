<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Adapter;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\AbstractImportV2Adapter;
use Maas\ImportExport\Model\Import\Catalog\Product\Adapter\Converter\Product;
use Maas\ImportExport\Model\Service\Client\Curl;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;

/**
 * Class V2
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product\Adapter
 */
class V2 extends AbstractImportV2Adapter
{
    const API_REQUEST_ENDPOINT = '/products';

    /**
     * @var Converter\Product
     */
    protected $productConverter;


    /**
     * V2 constructor.
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     * @param Product $productConverter
     */
    public function __construct(
        CurlFactory $curlClientFactory,
        CacheInterface $cache,
        Product $productConverter
    ) {
        parent::__construct($curlClientFactory, $cache);
        $this->productConverter = $productConverter;
    }

    /**
     * @param AbstractImportExportApi $api
     */
    protected function addAllFields(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        $args['fields'] = 'id,gtin,title,description,updatedAt,brand,category,images,attributes';
        $api->setArgs($args);
    }

    /**
     * @param AbstractImportExportApi $api
     * @return string
     */
    protected function getEndPointUrl(AbstractImportExportApi $api)
    {
        $url = rtrim($api->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        return is_array($api->getArgs()) && sizeof($api->getArgs()) ? $url . '?' . http_build_query($api->getArgs()) : $url;
    }

    /**
     * @param $items
     * @return array
     */
    protected function convertItems($items)
    {
        $convertedItems = [];
        foreach ($items as $item) {
            $convertedItem = $this->productConverter->convertItemData($item);
            if ($convertedItem) {
                $convertedItems[] = $convertedItem;
            }
        }
        return $convertedItems;
    }
}
