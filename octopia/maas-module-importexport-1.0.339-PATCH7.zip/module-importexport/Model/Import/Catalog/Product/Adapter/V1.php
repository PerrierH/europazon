<?php

namespace Maas\ImportExport\Model\Import\Catalog\Product\Adapter;

use Maas\ImportExport\Model\AbstractImportAdapter;
use Maas\ImportExport\Model\AbstractImportExportApi;

/**
 * Class V1
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Product\Adapter
 */
class V1 extends AbstractImportAdapter
{

    /**
     * @inheritDoc
     */
    public function doRequest(AbstractImportExportApi $api)
    {
        return $this->doOriginalRequest($api);
    }
}