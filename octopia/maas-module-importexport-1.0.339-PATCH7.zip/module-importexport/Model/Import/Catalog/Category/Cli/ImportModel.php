<?php

namespace Maas\ImportExport\Model\Import\Catalog\Category\Cli;

use Maas\ImportExport\Model\Import\Catalog\Category;
use Maas\Log\Model\Report;
use Maas\Sales\Exception\UnknownStatus;

/**
 * Class ImportModel
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Category\Cli
 */
class ImportModel extends Category
{
    protected $cliArgs = [];

    /**
     * @param array|null $args
     * @param bool|bool $echo
     *
     * @return array
     */
    public function execute(array $args = null, bool $echo = true)
    {
        $this->cliArgs = $args;
        return parent::execute($args, $echo);
    }


    /**
     * @param array|null $args
     *
     * @return array|bool|float|int|string|null
     * @throws UnknownStatus
     */
    public function getApiResponse(array $args = null)
    {
        return $args;
    }

    public function getTotalItemsCount()
    {
        if (is_array($this->cliArgs) &&
            isset($this->cliArgs['itemsCount'])
        ) {
            return $this->cliArgs['itemsCount'];
        }
        return 0;
    }

    /**
     * @return Report
     */
    public function getReport()
    {
        return $this->report;
    }

    /**
     * @param array $result
     */
    protected function endLog(array $result)
    {
        // keep the report open
        $itemCount = array_key_exists('itemsCount', $result) ? $result['itemsCount'] : 0;
        $this->report->setItemsCount($itemCount);
    }
}