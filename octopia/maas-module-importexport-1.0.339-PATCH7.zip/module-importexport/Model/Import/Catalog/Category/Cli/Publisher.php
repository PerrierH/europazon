<?php

namespace Maas\ImportExport\Model\Import\Catalog\Category\Cli;

use Maas\ImportExport\Api\Data\AbstractImportMessageInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class Publisher
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Category\Cli
 */
class Publisher extends \Maas\ImportExport\Model\Import\Catalog\Category\Publisher
{
    protected $messages = [];

    /**
     * @param mixed $entityData
     *
     * @return $this
     * @throws LocalizedException
     */
    public function enqueueEntity($entityData)
    {
        if (!$this->messageBuilder->isSpaceLeft($entityData)) {
            $this->messages[] = $this->messageBuilder->build();
        }
        $this->messageBuilder->addEntity($entityData);
        return $this;
    }

    /**
     * @return $this
     * @throws LocalizedException
     */
    public function publishRemaining()
    {
        if ($this->messageBuilder->getEntityCount()) {
            /** @var AbstractImportMessageInterface $message */
            $this->messages[] = $this->messageBuilder->build();
        }
        return $this;
    }

    /**
     * @return array
     */
    public function getMessages()
    {
        return $this->messages;
    }
}