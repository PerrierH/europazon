<?php

namespace Maas\ImportExport\Model\Import\Catalog\Category;

use Exception;
use Maas\Catalog\Model\Config as CatalogConfig;
use Maas\Catalog\Model\Service\AttributeCode;
use Maas\Core\Model\Config;
use Maas\Core\Model\Service\MessageQueue\ConsumerInterface;
use Maas\ImportExport\Api\Data\Catalog\Category\AttributeInterface;
use Maas\ImportExport\Api\Data\Catalog\CategoryInterface;
use Maas\ImportExport\Api\Data\CategoryImportMessageInterface;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Import\AbstractConsumer;
use Maas\ImportExport\Model\Import\Catalog\Category;
use Maas\ImportExport\Model\Import\MessageQueue;
use Maas\ImportExport\Model\Service\CategoryImage;
use Maas\ImportExport\Model\Service\CreateAttributeSet;
use Maas\ImportExport\Model\Service\CreateCategoryAttribute;
use Maas\ImportExport\Model\Service\CreateProductAttribute;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Csv;
use Maas\Log\Model\Report;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Offer\Api\OfferRepositoryInterface;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Model\Category as CategoryModel;
use Magento\Catalog\Model\Category\Type;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\Indexer\Category\Product as ProductIndexer;
use Magento\Catalog\Model\ResourceModel\Category\Collection as CategoryCollection;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Indexer\IndexerRegistry;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Store\Model\App\Emulation;
use Magento\Store\Model\StoreManagerInterface;
use Magento\UrlRewrite\Model\Exception\UrlAlreadyExistsException;
use Maas\ImportExport\Model\Config as ImportExportConfig;

/**
 * Class Consumer
 *
 * Consumer for category entities
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Category
 */
class Consumer extends AbstractConsumer implements ConsumerInterface
{
    const MAAS_CATEGORIES_TREE = 'maas_categories_tree_array';

    /**
     * @var ReportInterface
     */
    protected $report;

    /**
     * @var ConfigModel
     */
    protected $catalogConfig;
    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;
    /**
     * @var CategoryFactory
     */
    protected $categoryFactory;
    /**
     * @var Emulation
     */
    private $emulation;
    /**
     * @var ReportRepositoryInterface
     */
    private $reportRepository;
    /**
     * @var IndexerRegistry
     */
    private $indexerRegistry;

    /**
     * @var CreateAttributeSet
     */
    private $createAttributeSet;

    /**
     * @var MessageQueue
     */
    private $messageQueue;

    /**
     * @var CategoryCollectionFactory
     */
    private $categoryCollectionFactory;

    /**
     * @var CategoryCollection
     */
    private $categories;

    /**
     * @var array
     */
    private $categoriesData;

    /**
     * @var CategoryModel
     */
    private $rootCategory;

    /**
     * @var CategoryModel
     */
    private $errorCategory;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var AttributeCode
     */
    private $attributeCodeService;

    /**
     * @var ImportExportConfig
     */
    private $importExportConfig;
    private CreateProductAttribute $createProductAttribute;
    protected ReportManagementInterface $reportManagement;


    /**
     * Consumer constructor.
     *
     * @param ModuleListProxy $moduleList
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OfferRepositoryInterface $offerRepository
     * @param DateTime $dateTime
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param Config $coreConfig
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param CatalogConfig $catalogConfig
     * @param CategoryRepositoryInterface $categoryRepository
     * @param Emulation $emulation
     * @param ReportRepositoryInterface $reportRepository
     * @param CategoryFactory $categoryFactory
     * @param IndexerRegistry $indexerRegistry
     * @param CreateAttributeSet $createAttributeSet
     * @param MessageQueue $messageQueue
     * @param CreateProductAttribute $createProductAttribute
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param StoreManagerInterface $storeManager
     * @param AttributeCode $attributeCodeService
     * @param ImportExportConfig $importExportConfig
     */
    public function __construct(
        ModuleListProxy             $moduleList,
        FilterBuilder               $filterBuilder,
        SearchCriteriaBuilder       $searchCriteriaBuilder,
        OfferRepositoryInterface    $offerRepository,
        DateTime                    $dateTime,
        CsvLoggerManagement         $csvLoggerManagement,
        Config                      $coreConfig,
        CacheInterface              $cache,
        SerializerInterface         $serializer,
        ReportCollectionFactory     $reportCollectionFactory,
        CatalogConfig               $catalogConfig,
        CategoryRepositoryInterface $categoryRepository,
        Emulation                   $emulation,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        CategoryFactory             $categoryFactory,
        IndexerRegistry             $indexerRegistry,
        CreateAttributeSet          $createAttributeSet,
        MessageQueue                $messageQueue,
        CreateProductAttribute      $createProductAttribute,
        CategoryCollectionFactory   $categoryCollectionFactory,
        StoreManagerInterface       $storeManager,
        AttributeCode               $attributeCodeService,
        ImportExportConfig          $importExportConfig
    )
    {
        $this->catalogConfig = $catalogConfig;
        $this->categoryRepository = $categoryRepository;
        $this->emulation = $emulation;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->categoryFactory = $categoryFactory;
        $this->indexerRegistry = $indexerRegistry;
        $this->createAttributeSet = $createAttributeSet;
        $this->messageQueue = $messageQueue;
        $this->createProductAttribute = $createProductAttribute;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->storeManager = $storeManager;
        $this->attributeCodeService = $attributeCodeService;
        $this->importExportConfig = $importExportConfig;
        parent::__construct(
            $moduleList,
            $filterBuilder,
            $searchCriteriaBuilder,
            $offerRepository,
            $dateTime,
            $csvLoggerManagement,
            $cache,
            $coreConfig,
            $serializer,
            $reportCollectionFactory
        );
    }

    /**
     * Load the report id from cache
     */
    protected function loadReportIdFromCache(): ?int
    {
        $reportId = $this->cache->load($this->getReportIdKey());
        return $reportId ?? null;
    }

    /**
     * @param string $module
     * @param string $action
     * @param $status
     * @return DataObject|bool
     */
    protected function getStartedImportReportObject(string $module, string $action, $status = Report::STATUS_STARTED)
    {
        $collection = $this->reportCollectionFactory->create();
        /** @var AbstractDb $collection */
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', $status
            )
            ->setPageSize(1);

        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }

        return false;
    }

    /**
     * Get started report from cache or from the database
     */
    protected function getReport() : ReportInterface
    {
        $reportId = $this->loadReportIdFromCache();
        if ($reportId == null || $reportId == 0) {
            $currentReport = $this->getStartedImportReportObject();
            $reportId = $currentReport->getId();
            $this->saveReportIdInCache($reportId);
            return $currentReport;
        }
        return $this->reportRepository->get($reportId);
    }

    /**
     * @param CategoryImportMessageInterface $message
     *
     * @throws NoSuchEntityException|ValidatorException
     */
    public function process($message)
    {
        $this->invalidateIndexer();
        $this->reportId = $message->getReportId();
        if ($this->reportId == 0) {
            $this->report = $this->getStartedImportReportObject(Category::MAAS_LOG_MODULE, Category::MAAS_LOG_ACTION);
            $this->reportId = $this->report->getId();
        } else {
            $this->report = $this->reportRepository->get($this->reportId);
        }
        // import categories flagged as active
        $this->importCategories($message);

        // Update Report Status when all messages are consumed
        $this->messageQueue->setQueueName(Category::QUEUE_MESSAGE_NAME);
        if ($this->report->isJobOver()) {
            $this->assignParentIdToCategories();
            $this->reportManagement->close($this->report);
            $this->clearCacheOnJobOver();
            $this->cache->remove(self::MAAS_CATEGORIES_TREE);
        }
    }

    private function invalidateIndexer()
    {
        $productIndexer = $this->indexerRegistry->get(ProductIndexer::INDEXER_ID);
        $productIndexer->invalidate();
    }

    /**
     * @param $message
     *
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @throws InputException
     * @throws StateException
     */
    public function importCategories($message)
    {
        $this->categoriesData = $this->getCachedValue(self::MAAS_CATEGORIES_TREE);
        $rootCategoryId = $this->catalogConfig->getMaasRootCategory();
        $this->rootCategory = $this->categoryRepository->get($rootCategoryId);
        $maasErrorCategoryId = $this->catalogConfig->getMaasErrorCategory();
        $this->errorCategory = $this->categoryRepository->get($maasErrorCategoryId);
        $successItemsCount = 0;
        $warningItemsCount = 0;
        $errorItemsCount = 0;
        $errorMessages = [];
        $this->categories = $this->getMaasCategories();

        foreach ($message->getEntities() as $item) {

            try {
                if (!$item->getLabel()) {
                    $this->report->log(__("The Category label is empty"));
                    $errorItemsCount++;
                    continue;
                }
                if (!$item->getCategoryId()) {
                    $this->report->log(__("The Category id is mandatory"));
                    $errorItemsCount++;
                    continue;
                }
                if ($this->isCategoryToExclude($item->getLabel())) {
                    $this->report->log(sprintf("The Category %s --> %s is excluded", $item->getCategoryId(), $item->getLabel()));
                    $successItemsCount++;
                    continue;
                }
                $this->report->log('Start creating category :' . $item->getCategoryId() . '-->' . $item->getLabel());
                $date = date('Y/m/d h:i:s', time());
                list($category, $status) = $this->handleCategoryCreate($item, $date);
                if (is_null($status)) {
                    $this->populateCategoriesData($category, $item);
                    $successItemsCount++;
                    //continue;
                }
                $category->setName($item->getLabel());
                $category->setUpdatedAt($item->getUpdatedAt());
                $category->setMaasUpdatedAt($item->getUpdatedAt());
                try {
                    if ($status == 'Updated') {
                        $this->updateCategoryByStoreView($category, $item);
                    } else {
                        $category->save();
                    }
                } catch (UrlAlreadyExistsException $ex) {
                    $this->report->log('Category Url already exists');
                    $errorItemsCount++;
                    $errorMessages[] = $ex->getMessage();
                    continue;
                } catch (CouldNotSaveException $ex) {
                    $this->report->log('Could not save category :' . ($item->getLabel() ?? '') . ' : ' . $ex->getMessage());
                    $errorItemsCount++;
                    $errorMessages[] = $ex->getMessage();
                    continue;
                }
                $this->populateCategoriesData($category, $item);
                $this->importAttributes($item);

                $logMessage = $date . " " . $item->getCategoryId() . " " . $item->getLabel() . " " . $status . PHP_EOL;
                $this->report->log($logMessage);
                $successItemsCount++;
            } catch (Exception $e) {
                $this->report->log('Error while creating category :' . ($item->getLabel() ?? '') . ' : ' . $e->getMessage());
                $errorItemsCount++;
                $errorMessages[] = $e->getMessage();
                continue;
            }
        }

        $this->cache->save($this->serializer->serialize($this->categoriesData), self::MAAS_CATEGORIES_TREE);
        $message = empty($errorMessages) ? '' : implode("<br />", array_unique($errorMessages));

        $this->report->setDeltaSuccessItemsCount($successItemsCount);
        $this->report->setDeltaWarningItemsCount($warningItemsCount);
        $this->report->setDeltaErrorItemsCount($errorItemsCount);
        $this->report->setMessage($message);
        $this->reportRepository->save($this->report);
    }

    /**
     * @param CategoryInterface $item
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    private function importAttributes(CategoryInterface $item)
    {
        if ((string)$item->getLevel() == '2') {
            $attributeSet = $this->createAttributeSet->createOrGetAttributeSet($item);
            $attributeGroupId = $this->createAttributeSet->getAttributeGroupId($attributeSet);
            foreach ($item->getAttributes() as $attribute) {
                if ($attribute->getRequired()  && strtolower($attribute->getRequired()) <> 'optional') {
                    $properties = $this->unserializeProperties($attribute);
                    $this->createProductAttribute->createProductAttributeByCode(
                        $this->attributeCodeService->generate($attribute->getLabel()),
                        $attribute->getLabel(),
                        $attributeSet,
                        $attributeGroupId,
                        $properties ?? [],
                        $attribute->getOptions() ?? []
                    );
                }
            }
        }
    }

    /**
     * @param $key
     *
     * @return array|bool|float|int|string|null
     */
    public function getCachedValue($key)
    {
        $cacheValue = $this->cache->load($key);
        if (empty($cacheValue)) {
            return [];
        }
        return $this->serializer->unserialize($cacheValue);
    }

    /**
     * @return array|null
     */
    private function getMaasCategories()
    {
        $loadedCategories = $this->categoryCollectionFactory->create()
            ->addAttributeToSelect(['maas_category_id', 'url_key', 'maas_updated_at'])
            ->addFieldToFilter('maas_is_maas_category', 1)
            ->getItems();

        $maasCategories = [];
        foreach ($loadedCategories as $category) {
            $maasCategories[$category->getMaasCategoryId()] = $category;

        }

        return $maasCategories;
    }

    /**
     * Check if the label of category are excluded
     *
     * @param string $label
     * @return bool
     */
    private function isCategoryToExclude(string $label): bool
    {
        $categoriesToExclude = $this->importExportConfig->getCategoriesToExclude();
        if ($categoriesToExclude) {
            $categoriesToExcludeArray = explode(',', $categoriesToExclude);
            foreach ($categoriesToExcludeArray as $category) {
                if (strpos($label, $category) !== FALSE) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param CategoryInterface $item
     * @param string $date
     *
     * @return array
     */
    protected function handleCategoryCreate(CategoryInterface $item, $date)
    {
        $category = $this->checkIfCategoryExists($item->getCategoryId());
        $parent = $this->retrieveParentCategory($item->getParentCategoryId());

        if (!$category) {
            $this->report->log('Category Not exists');
            $category = $this->categoryFactory->create();
            $category->setMaasCategoryId($item->getCategoryId());
            $category->setMaasIsMaasCategory(true);
            $category->setIncludeInMenu(false);
            $category->setIsActive(0);
            $category->setPath($parent->getPath());
            $urlKey = str_replace(' ', '-', $item->getLabel()) . '-' . $item->getCategoryId();
            $category->setUrlKey($urlKey);
            $status = 'Created';
        } else {
            $this->report->log('Category exists. --> Id:' . $category->getId());
            if ($category->getMaasUpdatedAt() === $item->getUpdatedAt()) {
                $status = 'Already up-to-date';
                $logMessage = $date . " " . $item->getCategoryId() . " " . $item->getLabel() . " " . $status . PHP_EOL;
                $this->report->log($logMessage);
                $status = null;
            } else {
                $category->setPath(sprintf('%s/%s', $parent->getPath(), $category->getId()));
                $status = 'Updated';
            }
        }

        $category->setParentId($parent->getId());
        return [$category, $status];
    }

    /**
     * @param $maasCategoryId
     *
     * @return null|CategoryModel
     */
    private function checkIfCategoryExists($maasCategoryId)
    {
        if ($this->categories) {
            return array_key_exists($maasCategoryId, $this->categories) ? $this->categories[$maasCategoryId] : null;
        }
        return null;
    }

    /**
     * @param $maasParentCategoryId
     *
     * @return CategoryModel
     */
    private function retrieveParentCategory($maasParentCategoryId)
    {
        if (is_null($maasParentCategoryId)) {
            return $this->rootCategory;
        }
        $parent = $this->checkIfCategoryExists($maasParentCategoryId);
        if (is_null($parent)) {
            $parentData = array_key_exists($maasParentCategoryId, $this->categoriesData) ?
                $this->categoriesData[$maasParentCategoryId]['categoryObject'] : $this->errorCategory->toArray();
            $parent = $this->categoryFactory->create();
            $parent->setData($parentData);
        }
        return $parent;
    }

    /**
     * @param CategoryModel $category
     * @param CategoryInterface $item
     */
    private function populateCategoriesData(CategoryModel $category, CategoryInterface $item)
    {
        $this->categoriesData[$item['categoryId']]['categoryObject'] = $category->toArray();
        $this->categoriesData[$item['categoryId']]['parentId'] = $item->getParentCategoryId();
        $this->categoriesData[$item['categoryId']]['id'] = $category->getId();
        $this->categoriesData[$item['categoryId']]['level'] = $item->getLevel();
    }

    /**
     * @param CategoryModel $category
     * @param CategoryInterface $item
     */
    private function updateCategoryByStoreView(CategoryModel $category, CategoryInterface $item)
    {
        foreach ($this->getStores() as $storeId) {
            $category->setStoreId($storeId);
            $urlKey = str_replace(' ', '-', $item->getLabel()) . '-' . $item->getCategoryId();
            $category->setUrlKey($urlKey);
            $category->save();
        }
    }

    /**
     * @return array
     */
    private function getStores()
    {
        $stores[] = 0;
        foreach ($this->storeManager->getStores() as $store) {
            $stores[] = $store->getStoreId();
        }
        return $stores;
    }

    /**
     * @param AttributeInterface $attribute
     *
     * @return array
     */
    protected function unserializeProperties(AttributeInterface $attribute)
    {
        $properties = $attribute->getProperties();
        if (!$properties) {
            return [];
        }
        // first unserialize
        $properties = $this->serializer->unserialize($properties);
        if ($properties && !is_array($properties)) {
            $properties = $this->serializer->unserialize($properties);
        }
        return is_array($properties) ? $properties : [];
    }

    /**
     * @return void
     */
    private function assignParentIdToCategories()
    {
        $productIndexer = $this->indexerRegistry->get(ProductIndexer::INDEXER_ID);
        $cachedCategoriesData = $this->getCachedValue(self::MAAS_CATEGORIES_TREE);
        foreach ($cachedCategoriesData as $data) {
            try {
                $subCategory = $this->categoryFactory->create();
                $subCategory->setData($data['categoryObject']);
                if (key_exists($data['parentId'], $cachedCategoriesData) && !is_null($data['parentId'])) {
                    if ($cachedCategoriesData[$data['parentId']]['id'] == $subCategory->getParentId()) {
                        $this->report->log('Category:' . $subCategory->getId() . ' has a parent');
                    } else {
                        $this->report->log('Moving category:' . $subCategory->getId() . ' to category:' . $cachedCategoriesData[$data['parentId']]['id']);
                        $subCategory->move($cachedCategoriesData[$data['parentId']]['id'], null);
                    }
                }
            } catch (UrlAlreadyExistsException $ex) {
                $this->report->log('Moving category:' . $subCategory->getId() . ' to error category:' . $this->errorCategory->getId());
                $this->report->log('Error detail:' . $ex->getMessage());
                $subCategory->move($this->errorCategory->getId(), null);
            }
        }
        $productIndexer->reindexAll();
    }

    /**
     * @param int $reportId
     *
     * @return Csv
     */
    public function getCsvLogger($reportId)
    {
        if (is_null($this->csvLogger)) {
            $this->csvLogger = $this->csvLoggerManagement->getCsvLogger(
                $reportId,
                Category::CSV_LOG_HEADERS,
                Category::MAAS_LOG_MODULE,
                Category::MAAS_LOG_ACTION,
                Category::CSV_LOG_FILE_PREFIX
            );
        }
        return $this->csvLogger;
    }
}
