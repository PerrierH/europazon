<?php

namespace Maas\ImportExport\Model\Import\Catalog\Category\Data;

use Maas\ImportExport\Api\Data\Catalog\CategoryInterface;
use Magento\Framework\DataObject;

class Category extends DataObject implements CategoryInterface
{

    /**
     * @return string
     */
    public function getCategoryId()
    {
        return $this->getData('categoryId');
    }

    /**
     * @param string $categoryId
     */
    public function setCategoryId($categoryId)
    {
        $this->setData('categoryId', $categoryId);
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return $this->getData('label');
    }

    /**
     * @param string $label
     */
    public function setLabel($label)
    {
        $this->setData('label', $label);
    }

    /**
     * @return string
     */
    public function getLevel()
    {
        return $this->getData('level');
    }

    /**
     * @param string $level
     */
    public function setLevel($level)
    {
        $this->setData('level', $level);
    }

    /**
     * @return string
     */
    public function getParentCategoryId()
    {
        return $this->getData('parentCategoryId');
    }

    /**
     * @param string $parentCategoryId
     */
    public function setParentCategoryId($parentCategoryId)
    {
        $this->setData('parentCategoryId', $parentCategoryId);
    }

    /**
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData('updatedAt');
    }

    /**
     * @param string $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->setData('updatedAt', $updatedAt);
    }

    /**
     * @return \Maas\ImportExport\Api\Data\Catalog\Category\AttributeInterface[]|null
     */
    public function getAttributes()
    {
        return $this->getData('attributes');
    }

    /**
     * @param \Maas\ImportExport\Api\Data\Catalog\Category\AttributeInterface[] $attributes
     * @return Category
     */
    public function setAttributes($attributes)
    {
        return $this->setData('attributes', $attributes);
    }
}