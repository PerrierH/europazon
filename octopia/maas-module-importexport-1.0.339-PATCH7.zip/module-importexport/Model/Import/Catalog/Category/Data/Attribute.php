<?php

namespace Maas\ImportExport\Model\Import\Catalog\Category\Data;

use Maas\ImportExport\Api\Data\Catalog\Category\AttributeInterface;
use Magento\Framework\DataObject;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Class Attribute
 *
 * @package Maas\ImportExport\Model\Catalog\Category\Data
 * @codeCoverageIgnore
 */
class Attribute extends DataObject implements AttributeInterface
{
    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * Attribute constructor.
     * @param SerializerInterface $serializer
     * @param array $data
     */
    public function __construct(
        SerializerInterface $serializer,
        array $data = []
    )
    {
        $this->serializer = $serializer;
        parent::__construct($data);
    }

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData('code');
    }

    /**
     * @param $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        return $this->setData('code', $code);
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return $this->getData('label');
    }

    /**
     * @param $label
     *
     * @return $this
     */
    public function setLabel($label)
    {
        return $this->setData('label', $label);
    }

    /**
     * @return string
     */
    public function getProperties()
    {
        return $this->getData('properties');
    }

    /**
     * @param array $properties
     * @return Attribute
     */
    public function setProperties($properties)
    {
        return $this->setData('properties', $this->serializer->serialize($properties));
    }

    /**
     * @return string[]
     */
    public function getOptions()
    {
        return $this->getData('options');
    }

    /**
     * @param string[] $options
     * @return Attribute
     */
    public function setOptions($options)
    {
        return $this->setData('options', $options);
    }

    /**
     * @return string
     */
    public function getRequired()
    {
        return $this->getData('required');
    }

    /**
     * @param string $required
     * @return $this
     */
    public function setRequired($required)
    {
        return $this->setData('required', $required);
    }
}
