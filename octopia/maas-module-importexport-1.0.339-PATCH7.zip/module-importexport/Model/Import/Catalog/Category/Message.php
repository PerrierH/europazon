<?php

namespace Maas\ImportExport\Model\Import\Catalog\Category;

use Maas\ImportExport\Api\Data\CategoryImportMessageInterface;
use Maas\ImportExport\Model\ImportMessage;

/**
 * Class Message
 *
 * Message to send. The logic is in the parent class, and the implemented interface
 * allows serializing/unserializing without any class matching issues
 *
 * @package Maas\ImportExport\Model\Import\Catalog\Category
 */
class Message extends ImportMessage implements CategoryImportMessageInterface
{
}
