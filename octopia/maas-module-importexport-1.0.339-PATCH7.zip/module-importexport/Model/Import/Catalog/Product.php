<?php

namespace Maas\ImportExport\Model\Import\Catalog;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\Log\Model\Report;

/**
 * Class Product
 *
 * @package Maas\ImportExport\Model\Import\Catalog
 */
class Product extends AbstractImportExportApi
{
    public const API_REQUEST_ENDPOINT = '/icv_api/public/api/products';

    public const MAAS_LOG_ACTION = 'Import_Products';

    public const MAAS_LOG_MODULE = 'Maas_ImportExport';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_IMPORT;

    public const CSV_LOG_HEADERS = ['date', 'report_id', 'operation', 'sku', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'import-products';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_import_product_maas_report_id';

    const QUEUE_MESSAGE_NAME = 'maas_importexport.import_catalog_product.%s.queue';

	const DEPENDENCY_CATEGORY_MESSAGE_ERROR = 'stopped due to categories';

    /**
     * @var string
     */
    protected $dependencyNotImportedErrorMessage = 'This process has been stopped due to categories not having been imported beforehand. Importing categories instead.';

    /**
     * @var string
     */
    protected $dependencyImportingErrorMessage = 'This process has been stopped due to categories currently being imported.';

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return $this->configProvider->getProductsApiUrl();
    }
}
