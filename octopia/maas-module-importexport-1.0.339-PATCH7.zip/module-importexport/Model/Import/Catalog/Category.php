<?php

namespace Maas\ImportExport\Model\Import\Catalog;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\Log\Model\Report;

/**
 * Class Category
 *
 * @package Maas\ImportExport\Model\Import\Catalog
 * @codeCoverageIgnore
 */
class Category extends AbstractImportExportApi
{
    public const MAAS_LOG_ACTION = 'Import_Categories';

    public const MAAS_LOG_MODULE = 'Maas_ImportExport';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_IMPORT;

    public const API_REQUEST_ENDPOINT = '/icv_api/public/api/v0.2/categories';

    public const CSV_LOG_HEADERS = ['date', 'report_id', 'operation', 'category_id', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'import-categories';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_import_category_maas_report_id';

    const QUEUE_MESSAGE_NAME = 'maas_importexport.import_catalog_category.%s.queue';

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return $this->configProvider->getCategoryApiUrl();
    }
}
