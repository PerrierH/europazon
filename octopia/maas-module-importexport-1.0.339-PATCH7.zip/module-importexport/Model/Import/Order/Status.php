<?php

namespace Maas\ImportExport\Model\Import\Order;

use Exception;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\ImportExport\Model\AbstractImportAdapter;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\Config;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Service\OrderStatus as OrderStatusService;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\CsvFactory;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Sales\Model\SalesOrderInfo;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessor;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;

/**
 * Class Status
 *
 * @package Maas\ImportExport\Model\Import\Order
 */
class Status extends AbstractImportExportApi
{
    public const API_REQUEST_ENDPOINT = '/orders';

    public const MAAS_LOG_ACTION = 'Update_Orders_Status';

    public const MAAS_LOG_MODULE = 'Maas_ImportExport';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_IMPORT;

    public const CSV_LOG_HEADERS = ['date', 'report_id', 'operation', 'order_id', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'order-status';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_import_order_status_maas_report_id';

    /** @var CollectionFactory */
    private $orderCollectionFactory;

    /** @var OrderStatusService */
    private $orderStatusService;

    /** @var JoinProcessor */
    private $joinProcessor;


    /**
     * Status constructor.
     *
     * @param ClientFactory $httpClientFactory
     * @param Config $configProvider
     * @param SerializerInterface $serializer
     * @param TokenRepository $tokenRepository
     * @param CacheInterface $cache
     * @param DateTime $dateTime
     * @param TokenFactory $tokenFactory
     * @param ErrorLogger $errorLogger
     * @param ReportFactory $reportFactory
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ReportResource $reportResource
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param CollectionFactory $orderCollectionFactory
     * @param JoinProcessor $joinProcessor
     * @param OrderStatusService $orderStatusService
     * @param AbstractImportAdapter[] $adapters
     */
    public function __construct(
        ClientFactory $httpClientFactory,
        Config $configProvider,
        SerializerInterface $serializer,
        TokenRepository $tokenRepository,
        CacheInterface $cache,
        DateTime $dateTime,
        TokenFactory $tokenFactory,
        ErrorLogger $errorLogger,
        ReportFactory $reportFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        ReportCollectionFactory $reportCollectionFactory,
        ReportResource $reportResource,
        CsvLoggerManagement $csvLoggerManagement,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        CollectionFactory $orderCollectionFactory,
        JoinProcessor $joinProcessor,
        OrderStatusService $orderStatusService,
        array $adapters = []
    )
    {
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->orderStatusService = $orderStatusService;
        $this->joinProcessor = $joinProcessor;

        parent::__construct(
            $httpClientFactory,
            $configProvider,
            $serializer,
            $tokenRepository,
            $cache,
            $dateTime,
            $tokenFactory,
            $errorLogger,
            $reportFactory,
            $reportRepository,
            $reportManagement,
            $reportCollectionFactory,
            $reportResource,
            $csvLoggerManagement,
            $searchCriteriaBuilder,
            $filterBuilder,
            $adapters
        );
    }

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return $this->configProvider->getOrdersApiUrl();
    }

    /**
     * @param array|null $args
     *
     * @return array
     */
    protected function doExecute(array $args = null)
    {
        $report = $this->loadReportFromCache();
        //Create collection
        $collection = $this->orderCollectionFactory->create();
        $this->joinProcessor->process($collection);
        $collection
            ->addFieldToFilter('extension_attribute_extra_info.order_type', ['eq' => SalesOrderInfo::ORDER_TYPE_MAAS])
            ->addFieldToFilter('extension_attribute_extra_info.exported', ['eq' => true])
            ->addFieldToFilter('main_table.status', ['neq' => Order::STATE_CANCELED]);

        if ($args !== null && array_key_exists('orderId', $args)) {
            $collection->addAttributeToFilter('entity_id', ['in' => explode(',', $args['orderId'])]);
        }

        // Process orders
        $error = false;
        $successItemsCount = 0;
        $errorItemsCount = 0;
        $errorMessages = [];
        $args = [];
        if (count($collection->getItems()) > 0) {
            foreach ($collection->getItems() as $order) {
                try {
                    /** @var Order $order */
                    $report->log(sprintf('Starting update status for order %s', $order->getIncrementId()));
                    if (!$order->getOrderMaasId()) {
                        throw new Exception(__('Order mass id is null for order %1', $order->getIncrementId()));
                    }
                    $args['id'] = $order->getOrderMaasId();
                    $this->setArgs($args);
                    $result = $this->apiCall();
                    $result = $this->serializer->unserialize($result['response']);
                    $this->orderStatusService->update($order, $result);
                    $successItemsCount++;
                    $report->log(sprintf(
                        'Order status successfully updated for order %s',
                        $order->getIncrementId()
                    ));
                } catch (Exception $e) {
                    $error = true;
                    $errorMessages[] = $e->getMessage();
                    $errorItemsCount++;
                    $report->log(sprintf('Error when updating status of the order %s', $order->getIncrementId()));
                }
                $report->setSuccessItemsCount($successItemsCount);
                $report->setErrorItemsCount($errorItemsCount);
                $report->save();
            }
        } else {
            $report->log(sprintf('No order to update'), true);
        }

        return [
            'itemsCount' => count($collection->getItems()),
            'errorItemsCount' => $errorItemsCount,
            'successItemsCount' => $successItemsCount,
            'error' => $error,
            'message' => $this->formatErrorMessages($errorMessages)
        ];
    }

    /**
     * @return string
     */
    public function getEndPointUrl()
    {
        $url = rtrim($this->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        $args = $this->getArgs();
        if ($args && array_key_exists('id', $args)) {
            $url = $url . '/' . $args['id'];
        }
        return $url;
    }
}
