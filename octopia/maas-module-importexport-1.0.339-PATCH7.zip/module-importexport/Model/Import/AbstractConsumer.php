<?php

namespace Maas\ImportExport\Model\Import;

use Maas\Core\Model\Config;
use Maas\Core\Model\Service\AbstractModuleDependant;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\Log\Model\Csv;
use Maas\Log\Model\Report;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Framework\Data\Collection\AbstractDb;

/**
 * Class AbstractConsumer
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import
 */
abstract class AbstractConsumer extends AbstractModuleDependant
{
    /** @var SearchCriteriaBuilder */
    public $searchCriteriaBuilder;

    /** @var DateTime */
    public $dateTime;

    /**
     * @var OfferRepositoryInterface
     */
    protected $offerRepository;

    /**
     * @var CsvLoggerManagement
     */
    protected $csvLoggerManagement;

    /**
     * @var Csv
     */
    protected $csvLogger;

    /**
     * @var Config
     */
    protected $coreConfig;
    /**
     * @var int
     */
    protected $reportId;
    /**
     * @var string
     */
    protected $offerMaasId;
    /**
     * @var int
     */
    protected $bestOfferRank;

    /** @var CacheInterface */
    protected $cache;

    /** @var SerializerInterface */

    protected $serializer;

    /** @var FilterBuilder */
    protected $filterBuilder;

    /**
     * @var ReportCollectionFactory
     */
    protected $reportCollectionFactory;

    /**
     * AbstractConsumer constructor.
     *
     * @param ModuleListProxy $moduleList
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OfferRepositoryInterface $offerRepository
     * @param DateTime $dateTime
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param CacheInterface $cache
     * @param Config $coreConfig
     * @param SerializerInterface $serializer
     * @param ReportCollectionFactory $reportCollectionFactory
     */
    public function __construct(
        ModuleListProxy $moduleList,
        FilterBuilder $filterBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        OfferRepositoryInterface $offerRepository,
        DateTime $dateTime,
        CsvLoggerManagement $csvLoggerManagement,
        CacheInterface $cache,
        Config $coreConfig,
        SerializerInterface $serializer,
        ReportCollectionFactory $reportCollectionFactory
    )
    {
        parent::__construct($moduleList);
        $this->filterBuilder = $filterBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->dateTime = $dateTime;
        $this->offerRepository = $offerRepository;
        $this->csvLoggerManagement = $csvLoggerManagement;
        $this->csvLogger = null;
        $this->coreConfig = $coreConfig;
        $this->cache = $cache;
        $this->serializer = $serializer;
        $this->reportCollectionFactory = $reportCollectionFactory;
    }

    /**
     * @param string|null $newDate
     * @param string|null $oldDate
     *
     * @return bool
     */
    public function isNewer(string $newDate = null, string $oldDate = null)
    {
        if (($newDate == null) || ($oldDate === null)) {
            return true;
        }
        return ($this->dateTime->timestamp($newDate) > $this->dateTime->timestamp($oldDate));
    }

    /**
     * @param $reportId
     *
     * @return mixed
     */
    abstract public function getCsvLogger($reportId);

    /**
     * @param $maasOfferId
     *
     * @return OfferInterface|null
     */
    protected function getOffer($maasOfferId)
    {
        $searchCriteria = $this->getSearchCriteria($maasOfferId);
        $offerItem = $this->offerRepository->getList($searchCriteria)->getItems();
        return sizeof($offerItem) ? current($offerItem): null;
    }

    /**
     * @param string $value
     *
     * @return SearchCriteria
     */
    public function getSearchCriteria(string $value, string $field = 'maas_entity_id')
    {
        $filter = $this->filterBuilder
            ->setField($field)
            ->setConditionType('eq')
            ->setValue($value)
            ->create();
        return $this->searchCriteriaBuilder
            ->addFilters([$filter])
            ->create();
    }

    /**
     * @param bool $saveTime
     */
    protected function endRow($saveTime = true)
    {
        if ($saveTime) {
            $this->csvLogger->storeMicrotimeFinish(['save_time', 'total_time']);
        } else {
            $this->csvLogger->storeMicrotimeFinish(['total_time']);
        }
        $this->csvLogger->finalizeRow();
    }

    /**
     * @param $rowData
     */
    protected function setNewRow($rowData)
    {
        $data = [
            'date' => $this->dateTime->date(),
            'report_id' => $this->reportId,
            'offer_id' => $this->offerMaasId,
            'best_offer_rank' => $this->bestOfferRank
        ];
        $newDataRow = array_merge($data, $rowData);
        $this->csvLogger->newRow($newDataRow);
        $this->csvLogger->storeMicrotimeStart('total_time');
    }

    /**
     * @param string $module
     * @param string $action
     * @param $status
     * @return DataObject|bool
     */
    protected function getStartedImportReportObject(string $module, string $action, $status = Report::STATUS_STARTED)
    {
        $collection = $this->reportCollectionFactory->create();
        /** @var AbstractDb $collection */
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', $status
            )
            ->setPageSize(1);

        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }

        return false;
    }

    /**
     *
     */
    protected function clearCacheOnJobOver()
    {
        //$this->cache->clean([sprintf(AbstractImportExportApi::CACHE_TAG_IMPORTEXPORT_BY_REPORT, $this->reportId)]);
    }
}
