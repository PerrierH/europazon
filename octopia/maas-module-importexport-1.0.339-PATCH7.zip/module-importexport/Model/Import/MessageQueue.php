<?php

namespace Maas\ImportExport\Model\Import;


use Maas\Core\Model\Service\MessageQueue\Publisher;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\ObjectManagerInterface;
use Maas\Core\Model\Service\AbstractModuleDependant;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;

/**
 * Class MessageQueue
 *
 * @package Maas\ImportExport\Model\Import
 * @codeCoverageIgnore Delegates most logic, database operations
 */
class MessageQueue extends AbstractModuleDependant
{
    const MAGENTO_QUEUE_RESOURCEMODEL = '\\Magento\\MysqlMq\\Model\\ResourceModel\\Queue';
    const RCASON_QUEUE_COLLECTION = '\\Rcason\\MqMysql\Model\\ResourceModel\\Queue\\Message\\CollectionFactory';


    /**
     * @var array
     */
    protected $modules;

    /**
     * @var ModuleListProxy
     */
    protected $moduleList;

    /**
     * @var bool
     */
    protected $initialized;

    /**
     * AbstractModuleDependant constructor.
     *
     * @param ModuleListProxy $moduleList
     */

    /**
     * @var ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * @var mixed
     */
    protected $queueClassModel;

    /**
     * @var ConfigProxy
     */
    protected $configModel;

    /**
     * @var string
     */
    private $queueName;


    /**
     * MessageQueue constructor.
     * @param ModuleListProxy $moduleList
     * @param ObjectManagerInterface $objectManager
     * @param ConfigProxy $configModel
     */
    public function __construct(
        ModuleListProxy $moduleList,
        ObjectManagerInterface $objectManager,
        ConfigProxy $configModel
    ) {
        $this->objectManager = $objectManager;
        $this->configModel = $configModel;
        parent::__construct($moduleList);
    }

    /**
     * Get Remaining Messages
     * @return int
     */
    public function getRemainingMessages()
    {
        $this->queueClassModel = null;
        if ($this->isModuleActive(Publisher::RCASONMQ_MODULE)) {
            $this->queueClassModel = $this->objectManager->create(self::RCASON_QUEUE_COLLECTION);
            return $this->getRcasonMqRemainingMessages();
        } else {
            if ($this->areModulesActive([Publisher::MAGENTO_MODULE1, Publisher::MAGENTO_MODULE2])) {
                $this->queueClassModel = $this->objectManager->create(self::MAGENTO_QUEUE_RESOURCEMODEL);
                return $this->getMagentoRemainingMessages();
            }
        }

        return 0;
    }

    /**
     * @return int
     */
    private function getRcasonMqRemainingMessages()
    {
        // Create collection instance and apply filter
        $collection = $this->queueClassModel->create()
            ->addFieldToFilter('status', 0)
            ->addFieldToFilter('queue_name', $this->getQueueName());

        return $collection->getSize();
    }


    /**
     * @param string $messageQueueName
     */
    public function setQueueName(string $messageQueueName)
    {
        $connectionMethod = $this->configModel->getMessageQueueConnectionMethod();
        $this->queueName = sprintf($messageQueueName, $connectionMethod);
    }

    /**
     * @return string
     */
    protected function getQueueName()
    {
        return $this->queueName;
    }

    /**
     * @return int
     */
    private function getMagentoRemainingMessages()
    {
        $messages = $this->queueClassModel->getMessages($this->getQueueName());
        return sizeof($messages);
    }
}