<?php


namespace Maas\ImportExport\Model\Import\Offer\Adapter;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\AbstractImportV2Adapter;
use Maas\ImportExport\Model\Import\Offer\Adapter\Converter\Offer;
use Maas\ImportExport\Model\Service\Client\Curl;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;

/**
 * Class V2
 *
 * @package Maas\ImportExport\Model\Import\Offer\Adapter
 */
class V2 extends AbstractImportV2Adapter
{
    const API_REQUEST_ENDPOINT = '/offers';
    const CONVERTER_METHOD = 'convertOfferItemData';

    /**
     * @var Offer
     */
    protected $converter;


    /**
     * V2 constructor.
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     * @param Offer $converter
     */
    public function __construct(
        CurlFactory $curlClientFactory,
        CacheInterface $cache,
        Offer $converter
    ) {
        parent::__construct($curlClientFactory, $cache);
        $this->converter = $converter;
    }

    /**
     * @param AbstractImportExportApi $api
     */
    protected function addAllFields(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        $args['fields'] = 'id,productTitle,condition,updatedAt,status,productId,sellerId,shopName,currencyCode,price,inventory';
        $api->setArgs($args);
    }

    /**
     * @param AbstractImportExportApi $api
     *
     * @return string
     */
    protected function getEndPointUrl(AbstractImportExportApi $api)
    {
        $url = rtrim($api->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        return is_array($api->getArgs()) && sizeof($api->getArgs()) ? $url . '?' . http_build_query($api->getArgs()) : $url;
    }

    /**
     * @return string
     */
    protected function getConverterMethod()
    {
        return self::CONVERTER_METHOD;
    }

    /**
     * @param array $items
     *
     * @return array
     */
    protected function convertItems($items)
    {
        $convertedItems = [];
        $method = $this->getConverterMethod();
        foreach ($items as $item) {
            $convertedItem = $this->converter->$method($item);
            if($convertedItem)
            {
                $convertedItems[] = $convertedItem;
            }
        }
        return $convertedItems;
    }
}
