<?php

namespace Maas\ImportExport\Model\Import\Offer\Adapter\Converter;

/**
 * Class Offer
 * @package Maas\ImportExport\Model\Import\Offer\Adapter\Converter
 */
class Offer
{
    /**
     * @param array $item
     *
     * @return array
     */
    public function convertOfferItemData($item)
    {
        return [
            'offerId' => array_key_exists('id', $item) ? $item['id'] : $item['offerId'],
            'productId' => $item['productId'],
            'condition' => [
                'condition' => array_key_exists('condition', $item) ? $item['condition'] : null,
                'subCondition' => null,
                'comment' => null
            ],
            'seller' => [
                'id' => $item['sellerId'],
                'name' => array_key_exists('shopName', $item) ? $item['shopName'] : null,
            ],
            'created_at' => $item['updatedAt'],
            'updated_at' => $item['updatedAt'],
            'status' => $item['status'],
            'price' => $this->convertPriceItemData($item),
            'inventory' => $this->convertInventoryItemData($item),
            'bestOfferRank' => $this->getBestOfferRankValue($item)
        ];
    }

    /**
     * @param array $item
     * @return int|null
     */
    private function getBestOfferRankValue($item)
    {
        if (array_key_exists('bestOfferRank', $item['price'])) {
            return $item['price']['bestOfferRank'];
        } elseif (array_key_exists('bestOfferRank', $item)) {
            return $item['bestOfferRank'];
        }

        return null;
    }

    /**
     * @param $item
     * @return array
     */
    private function convertPriceItemData($item)
    {
        $taxes = [];
        $taxCollection = array_key_exists('taxCollection', $item['price']) ? $item['price']['taxCollection'] : $item['price']['taxes'];
        foreach ($taxCollection as $tax) {
            $tax['type'] = strtolower($tax['type']);
            $taxes[] = $tax;
        }

        return [
            'offerId' => array_key_exists('id', $item) ? $item['id'] : $item['offerId'],
            'price' => $item['price']['price'],
            'currency' => $item['currencyCode'],
            'taxes' => $taxes,
            'originalPrice' => array_key_exists('originPrice', $item['price']) ? $item['price']['originPrice'] : '',
            'delivery' => $item['inventory']['deliveryModes'],
            'startDate' => null, 'endDate' => null, 'discountID' => null,
            'created_at' => array_key_exists('updatedAt', $item['price']) ? $item['price']['updatedAt'] : $item['updatedAt'],
            'updated_at' => array_key_exists('updatedAt', $item['price']) ? $item['price']['updatedAt'] : $item['updatedAt'],
        ];
    }


    /**
     * @param $item
     * @return array
     */
    private function convertInventoryItemData($item)
    {
        $deliveryModes = [];

        foreach ($item['inventory']['deliveryModes'] as $deliveryMode) {
            $deliveryModes[] = [
                'mode' => ucfirst($deliveryMode['mode'] ?? ''),
                'minDelay' => array_key_exists('minDelay', $deliveryMode) ? $deliveryMode['minDelay'] : $deliveryMode['minDeliveryTime'],
                'maxDelay' => array_key_exists('maxDelay', $deliveryMode) ? $deliveryMode['maxDelay'] : $deliveryMode['maxDeliveryTime'],
                'shippingCost' => array_key_exists('cost', $deliveryMode) ? $deliveryMode['cost'] : $deliveryMode['shippingCost'],
                'additionalShippingCost' => $deliveryMode['additionalShippingCost'],
            ];
        }

        return [
            'offerId' => array_key_exists('id', $item) ? $item['id'] : $item['offerId'],
            'stock' => array_key_exists('stock', $item['inventory']) ? $item['inventory']['stock'] : 0,
            'supplyMode' => $item['inventory']['supplyMode'],
            'deliveries' => $deliveryModes,
            'updated_at' => $item['updatedAt']
        ];
    }

}