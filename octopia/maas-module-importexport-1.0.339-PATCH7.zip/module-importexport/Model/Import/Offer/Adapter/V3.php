<?php

namespace Maas\ImportExport\Model\Import\Offer\Adapter;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\AbstractImportV3Adapter;
use Maas\ImportExport\Model\Import\Offer\Adapter\Converter\Offer;
use Maas\ImportExport\Model\Service\Client\Curl;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;
use Maas\ImportExport\Model\Import\Offer\Offer as OfferModel;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\ImportExport\Model\Config\Proxy as ConfigModel;

/**
 * Class V3
 * @package Maas\ImportExport\Model\Import\Offer\Adapter
 */
class V3 extends AbstractImportV3Adapter
{
    const API_REQUEST_ENDPOINT = '/offers';
    const CONVERTER_METHOD = 'convertOfferItemData';

    /**
     * @var Offer
     */
    protected $converter;

    /**
     * @var string
     */
    protected $entityType = 'offer';

    /**
     * @var ConfigModel
     */
    protected $configModel;

    /**
     * V3 constructor.
     *
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     * @param Offer $converter
     * @param ReportResource $reportResource
     * @param ConfigModel $configModel
     */
    public function __construct(
        CurlFactory $curlClientFactory,
        CacheInterface $cache,
        Offer $converter,
        ReportResource $reportResource,
        ConfigModel $configModel
    )
    {
        parent::__construct($curlClientFactory, $cache, $reportResource);
        $this->converter = $converter;
        $this->configModel = $configModel;
    }

    /**
     * @param AbstractImportExportApi $api
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function addAllFields(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        $args['fields'] = 'offerId,condition,updatedAt,status,productId,sellerId,currencyCode,price,inventory,warrantyDuration,bestOfferRank';
        $api->setArgs($args);
    }

    /**
     * @param AbstractImportExportApi $api
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function addFilters(AbstractImportExportApi $api)
    {
        if ($result = $this->hasRan(OfferModel::MAAS_LOG_MODULE, OfferModel::MAAS_LOG_ACTION, OfferModel::MAAS_LOG_OPERATION_TYPE)) {
            $maxOffersToImport = $this->configModel->getMaximumOffersToImport();
            $args = $api->getArgs();
            if (!$maxOffersToImport && $this->configModel->getCatalogOfferImportDeltaEnabled()) {
                if (isset($result['sync_date'])) {
                    $args['updatedAtMin'] = $this->convertToApiDate($result['sync_date']);
                }
            }
            $args['status'] = 'ANY';
            $api->setArgs($args);
        }
    }

    /**
     * @param AbstractImportExportApi $api
     * @return string
     */
    protected function getEndPointUrl(AbstractImportExportApi $api)
    {
        $url = rtrim($api->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        $args = $api->getArgs();
        if ($args && array_key_exists('cursor', $args)) {
            $cursor = $args['cursor'];
            unset($args['cursor']);
        }
        return is_array($api->getArgs()) && sizeof($api->getArgs()) ? $url . '?' . http_build_query($args)
            . (isset($cursor) ? '&cursor=' . $cursor : '') : $url;
    }

    /**
     * @param $items
     * @return array
     */
    protected function convertItems($items)
    {
        $convertedItems = [];
        $method = $this->getConverterMethod();
        foreach ($items as $item) {
            $convertedItem = $this->converter->$method($item);
            if ($convertedItem) {
                $convertedItems[] = $convertedItem;
            }
        }
        return $convertedItems;
    }

    /**
     * @return string
     */
    protected function getConverterMethod()
    {
        return self::CONVERTER_METHOD;
    }
}
