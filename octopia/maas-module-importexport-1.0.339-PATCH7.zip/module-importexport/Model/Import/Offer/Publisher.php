<?php

namespace Maas\ImportExport\Model\Import\Offer;

use Maas\ImportExport\Api\Data\Offer\OfferInterface;
use Maas\ImportExport\Api\Data\Offer\OfferInterfaceFactory;
use Maas\ImportExport\Model\Service\Import;
use Maas\ImportExport\Model\Service\MessageQueue\AbstractImportPublisher;
use Magento\Framework\Api\DataObjectHelper;

/**
 * Class Publisher
 *
 * Extends the generic import publisher proxy by injecting the correct classes into the constructor.
 * Doing this via di.xml does not instantiate a factory, but injects an array with a class name instead.
 *
 * @package Maas\ImportExport\Model\Import\Offer
 *
 * @codeCoverageIgnore\Maas\ImportExport\Api\Data\OfferImportMessageInterface
 */
class Publisher extends AbstractImportPublisher
{
    public function __construct(
        \Maas\Core\Model\Service\MessageQueue\Publisher $publisher,
        MessageBuilder $messageBuilder,
        DataObjectHelper $dataObjectHelper,
        Import $importService,
        OfferInterfaceFactory $offerFactory
    ) {
        parent::__construct(
            $publisher,
            $messageBuilder,
            $dataObjectHelper,
            $importService,
            $offerFactory,
            OfferInterface::class
        );
    }
}
