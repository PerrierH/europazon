<?php

namespace Maas\ImportExport\Model\Import\Offer;

use Maas\ImportExport\Api\Data\OfferImportMessageInterface;
use Maas\ImportExport\Model\ImportMessage;

/**
 * Class Message
 *
 * Message to send. The logic is in the parent class, and the implemented interface
 * allows serializing/unserializing without any class matching issues
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer
 */
class Message extends ImportMessage implements OfferImportMessageInterface
{
}
