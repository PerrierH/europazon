<?php


namespace Maas\ImportExport\Model\Import\Offer\Data;

use Maas\ImportExport\Api\Data\Offer\ConditionInterface;
use Maas\ImportExport\Api\Data\Offer\Price\PriceInterface;
use Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface;
use Maas\ImportExport\Api\Data\Offer\OfferImagesInterface;
use Maas\ImportExport\Api\Data\Offer\OfferInterface;
use Maas\ImportExport\Api\Data\Offer\SellerInterface;
use Magento\Framework\DataObject;

/**
 * Class Offer
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data
 */
class Offer extends DataObject implements OfferInterface
{

    /**
     * @return string
     */
    public function getOfferId()
    {
        return $this->getData(self::OFFER_ID);
    }

    /**
     * @return string
     */
    public function getProductId()
    {
        return $this->getData(self::PRODUCT_ID);
    }

    /**
     * @return ConditionInterface
     */
    public function getCondition()
    {
        return $this->getData(self::CONDITION);
    }

    /**
     * @return PriceInterface
     */
    public function getPrice()
    {
        return $this->getData(self::PRICE);
    }

    /**
     * @return InventoryInterface
     */
    public function getInventory()
    {
        return $this->getData(self::INVENTORY);
    }
    
    /**
     * @return SellerInterface
     */
    public function getSeller()
    {
        return $this->getData(self::SELLER);
    }

    /**
     * @return OfferImagesInterface
     */
    public function getImages()
    {
        return $this->getData(self::IMAGES);
    }

    /**
     * @return string
     */
    public function getBestOfferRank()
    {
        return $this->getData(self::BEST_OFFER_RANK);
    }

    /**
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATE_AT);
    }

    /**
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATE_AT);
    }

    /**
     * @return string
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * @return string|null
     */
    public function getWarrantyDuration()
    {
        return $this->getData(self::WARRANTY_DURATION);
    }

    /**
     * @param string $offerId
     *
     * @return Offer
     */
    public function setOfferId($offerId)
    {
        return $this->setData(self::OFFER_ID, $offerId);
    }

    /**
     * @param string $productId
     *
     * @return Offer
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * @param ConditionInterface $condition
     *
     * @return Offer
     */
    public function setCondition($condition)
    {
        return $this->setData(self::CONDITION, $condition);
    }

    /**
     * @param PriceInterface $price
     * @return Offer
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * @param InventoryInterface $inventory
     * @return Offer
     */
    public function setInventory($price)
    {
        return $this->setData(self::INVENTORY, $price);
    }

    /**
     * @param SellerInterface $seller
     *
     * @return Offer
     */
    public function setSeller($seller)
    {
        return $this->setData(self::SELLER, $seller);
    }

    /**
     * @param OfferImagesInterface $images
     *
     * @return Offer
     */
    public function setImages(OfferImagesInterface $images)
    {
        return $this->setData(self::IMAGES, $images);
    }

    /**
     * @param string $bestOfferRank
     *
     * @return Offer
     */
    public function setBestOfferRank($bestOfferRank)
    {
        return $this->setData(self::BEST_OFFER_RANK, $bestOfferRank);
    }

    /**
     * @param string $updatedAt
     *
     * @return Offer
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATE_AT, $updatedAt);
    }

    /**
     * @param $createAt
     *
     * @return Offer
     */
    public function setCreatedAt($createAt)
    {
        return $this->setData(self::CREATE_AT, $createAt);
    }

    /**
     * @param string $status
     *
     * @return Offer
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }


    /**
     * @param $warrantyDuration
     *
     * @return Offer
     */
    public function setWarrantyDuration($warrantyDuration)
    {
        return $this->setData(self::WARRANTY_DURATION, $warrantyDuration);
    }
}
