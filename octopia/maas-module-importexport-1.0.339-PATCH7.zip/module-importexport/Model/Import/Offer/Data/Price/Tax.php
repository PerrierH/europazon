<?php

namespace Maas\ImportExport\Model\Import\Offer\Data\Price;

use Maas\ImportExport\Api\Data\Offer\Price\TaxInterface;
use Magento\Framework\DataObject;

/**
 * Class Taxes
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data\Price
 */
class Tax extends DataObject implements TaxInterface
{

    /**
     * @return string
     */
    public function getCode()
    {
        return $this->getData(self::CODE);
    }

    /**
     * @return string
     */
    public function getType()
    {
        return $this->getData(self::TYPE);
    }

    /**
     * @return float
     */
    public function getValue()
    {
        return $this->getData(self::VALUE);
    }

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setCode($code)
    {
        return $this->setData(self::CODE, $code);
    }

    /**
     * @param string $type
     *
     * @return $this
     */
    public function setType($type)
    {
        return $this->setData(self::TYPE, $type);
    }

    /**
     * @param float $value
     *
     * @return $this
     */
    public function setValue($value)
    {
        return $this->setData(self::VALUE, $value);
    }
}
