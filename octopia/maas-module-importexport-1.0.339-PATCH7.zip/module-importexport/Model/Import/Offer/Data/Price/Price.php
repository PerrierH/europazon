<?php
namespace Maas\ImportExport\Model\Import\Offer\Data\Price;

use Maas\ImportExport\Api\Data\Offer\Price\PriceInterface;
use Maas\ImportExport\Api\Data\Offer\Price\TaxInterface;
use Magento\Framework\DataObject;

/**
 * Class Price
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data\Price
 */
class Price extends DataObject implements PriceInterface
{

    /**
     * @return string
     */
    public function getOfferId()
    {
        return $this->getData(self::OFFER_ID);
    }

    /**
     * @return float
     */
    public function getPrice()
    {
        return $this->getData(self::PRICE);
    }

    /**
     * @return string
     */
    public function getCurrency()
    {
        return $this->getData(self::CURRENCY);
    }

    /**
     * @return TaxInterface[]
     */
    public function getTaxes()
    {
        return $this->getData(self::TAXES);
    }

    /**
     * @return float
     */
    public function getOriginalPrice()
    {
        return $this->getData(self::ORIGINAL_PRICE);
    }

    /**
     * @return string
     */
    public function getStartDate()
    {
        return $this->getData(self::START_DATE);
    }

    /**
     * @return string
     */
    public function getEndDate()
    {
        return $this->getData(self::END_DATE);
    }

    /**
     * @return string
     */
    public function getDiscountId()
    {
        return $this->getData(self::DISCOUNT_ID);
    }

    /**
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId)
    {
        return $this->setData(self::OFFER_ID, $offerId);
    }

    /**
     * @param float $price
     *
     * @return $this
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * @param string $currency
     *
     * @return $this
     */
    public function setCurrency($currency)
    {
        return $this->setData(self::CURRENCY, $currency);
    }

    /**
     * @param TaxInterface[] $taxes
     *
     * @return $this
     */
    public function setTaxes($taxes)
    {
        return $this->setData(self::TAXES, $taxes);
    }

    /**
     * @param float $originalPrice
     *
     * @return $this
     */
    public function setOriginalPrice($originalPrice)
    {
        return $this->setData(self::ORIGINAL_PRICE, $originalPrice);
    }

    /**
     * @param string $startDate
     *
     * @return $this
     */
    public function setStartDate($startDate)
    {
        return $this->setData(self::START_DATE, $startDate);
    }

    /**
     * @param string $endDate
     *
     * @return $this
     */
    public function setEndDate($endDate)
    {
        return $this->setData(self::END_DATE, $endDate);
    }

    /**
     * @param string $discountId
     *
     * @return $this
     */
    public function setDiscountId($discountId)
    {
        return $this->setData(self::DISCOUNT_ID, $discountId);
    }

    /**
     * @param string $createdAt
     *
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * @param string $updatedAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
}
