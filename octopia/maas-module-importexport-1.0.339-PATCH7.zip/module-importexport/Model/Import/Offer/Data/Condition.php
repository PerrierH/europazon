<?php


namespace Maas\ImportExport\Model\Import\Offer\Data;

use Maas\ImportExport\Api\Data\Offer\ConditionInterface;
use Magento\Framework\DataObject;

/**
 * Class Condition
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data
 */
class Condition extends DataObject implements ConditionInterface
{

    /**
     * @return string
     */
    public function getCondition()
    {
        return $this->getData(self::CONDITION);
    }

    /**
     * @return string
     */
    public function getSubCondition()
    {
        return $this->getData(self::SUB_CONDITION);
    }

    /**
     * @return string
     */
    public function getComment()
    {
        return $this->getData(self::COMMENT);
    }

    /**
     * @param string $condition
     *
     * @return Condition
     */
    public function setCondition($condition)
    {
        return $this->setData(self::CONDITION, $condition);
    }

    /**
     * @param string $subCondition
     *
     * @return Condition
     */
    public function setSubCondition($subCondition)
    {
        return $this->setData(self::SUB_CONDITION, $subCondition);
    }

    /**
     * @param string $comment
     *
     * @return Condition
     */
    public function setComment($comment)
    {
        return $this->setData(self::COMMENT, $comment);
    }
}
