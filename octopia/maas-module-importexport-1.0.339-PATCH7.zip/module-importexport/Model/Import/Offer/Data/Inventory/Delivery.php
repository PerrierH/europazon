<?php

namespace Maas\ImportExport\Model\Import\Offer\Data\Inventory;

use Maas\ImportExport\Api\Data\Offer\Inventory\DeliveryInterface;
use Magento\Framework\DataObject;

/**
 * Class Delivery
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data\Inventory
 */
class Delivery extends DataObject implements DeliveryInterface
{

    /**
     * @return string
     */
    public function getMode()
    {
        return $this->getData(self::MODE);
    }
    /**
     * @return string
     */
    public function getMinDelay()
    {
        return $this->getData(self::MIN_DELAY);
    }
    /**
     * @return string
     */
    public function getMaxDelay()
    {
        return $this->getData(self::MAX_DELAY);
    }
    /**
     * @return string
     */
    public function getShippingCost()
    {
        return $this->getData(self::SHIPPING_COST);
    }
    /**
     * @param string $mode
     *
     * @return $this
     */
    public function setMode($mode)
    {
        return $this->setData(self::MODE, $mode);
    }
    /**
     * @param string $minDelay
     *
     * @return $this
     */
    public function setMinDelay($minDelay)
    {
        return $this->setData(self::MIN_DELAY, $minDelay);
    }
    /**
     * @param string $maxDelay
     *
     * @return $this
     */
    public function setMaxDelay($maxDelay)
    {
        return $this->setData(self::MAX_DELAY, $maxDelay);
    }
    /**
     * @param string $shippingCost
     *
     * @return $this
     */
    public function setShippingCost($shippingCost)
    {
        return $this->setData(self::SHIPPING_COST, $shippingCost);
    }

    /**
     * @param string $shippingCost
     * @return $this
     */
    public function getAdditionalShippingCost()
    {
        return $this->getData(self::ADDITIONAL_SHIPPING_COST);
    }

    /**
     * @param string $additionalShippingCost
     * @return $this
     */
    public function setAdditionalShippingCost($additionalShippingCost)
    {
        return $this->setData(self::ADDITIONAL_SHIPPING_COST, $additionalShippingCost);
    }
}
