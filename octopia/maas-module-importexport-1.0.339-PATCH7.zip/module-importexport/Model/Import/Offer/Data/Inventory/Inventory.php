<?php

namespace Maas\ImportExport\Model\Import\Offer\Data\Inventory;

use Maas\ImportExport\Api\Data\Offer\Inventory\DeliveryInterface;
use Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface;
use Magento\Framework\DataObject;

/**
 * Class Inventory
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data\Inventory
 */
class Inventory extends DataObject implements InventoryInterface
{

    /**
     * @return string
     */
    public function getOfferId()
    {
        return $this->getData(self::OFFER_ID);
    }
    /**
     * @return string
     */
    public function getStock()
    {
        return $this->getData(self::STOCK);
    }
    /**
     * @return string
     */
    public function getSupplyMode()
    {
        return $this->getData(self::SUPPLY_MODE);
    }
    /**
     * @return DeliveryInterface[]
     */
    public function getDeliveries()
    {
        return $this->getData(self::DELIVERIES);
    }
    /**
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }
    /**
     * @param string $offerId
     *
     * @return $this
     */
    public function setOfferId($offerId)
    {
        return $this->setData(self::OFFER_ID, $offerId);
    }
    /**
     * @param string $stock
     *
     * @return Inventory
     */
    public function setStock($stock)
    {
        return $this->setData(self::STOCK, $stock);
    }
    /**
     * @param string $supplyMode
     *
     * @return Inventory
     */
    public function setSupplyMode($supplyMode)
    {
        return $this->setData(self::SUPPLY_MODE, $supplyMode);
    }
    /**
     * @param DeliveryInterface[] $deliveries
     *
     * @return Inventory
     */
    public function setDeliveries($deliveries)
    {
        return $this->setData(self::DELIVERIES, $deliveries);
    }
    /**
     * @param string $updatedAt
     *
     * @return Inventory
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
}
