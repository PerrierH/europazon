<?php


namespace Maas\ImportExport\Model\Import\Offer\Data;

use Maas\ImportExport\Api\Data\Offer\SellerInterface;
use Magento\Framework\DataObject;

/**
 * Class Seller
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data
 */
class Seller extends DataObject implements SellerInterface
{

    /**
     * @return int
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @param int $id
     *
     * @return Seller
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @param string $name
     *
     * @return Seller
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }
}
