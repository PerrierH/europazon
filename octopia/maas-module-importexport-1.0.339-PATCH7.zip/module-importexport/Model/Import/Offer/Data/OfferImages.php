<?php


namespace Maas\ImportExport\Model\Import\Offer\Data;

use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Maas\ImportExport\Api\Data\Offer\OfferImagesInterface;
use Magento\Framework\DataObject;

/**
 * Class OfferImages
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Model\Import\Offer\Data
 */
class OfferImages extends DataObject implements OfferImagesInterface
{

    /**
     * @return ImageInterface
     */
    public function getSmall()
    {
        return $this->getData(self::SMALL);
    }

    /**
     * @param ImageInterface $small
     *
     * @return OfferImages
     */
    public function setSmall(ImageInterface $small)
    {
        return $this->setData(self::SMALL, $small);
    }

    /**
     * @return ImageInterface
     */
    public function getMedium()
    {
        return $this->getData(self::MEDIUM);
    }

    /**
     * @param ImageInterface $medium
     *
     * @return OfferImages
     */
    public function setMedium(ImageInterface $medium)
    {
        return $this->setData(self::MEDIUM, $medium);
    }

    /**
     * @return ImageInterface
     */
    public function getLarge()
    {
        return $this->getData(self::LARGE);
    }

    /**
     * @param ImageInterface $large
     *
     * @return OfferImages
     */
    public function setLarge(ImageInterface $large)
    {
        return $this->setData(self::LARGE, $large);
    }
}
