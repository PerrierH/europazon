<?php


namespace Maas\ImportExport\Model\Import\Offer;

use Exception;
use Maas\Core\Model\Config;
use Maas\ImportExport\Api\Data\Offer\OfferImagesInterface;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Import\AbstractConsumer;
use Maas\Core\Model\Service\MessageQueue\ConsumerInterface;
use Maas\ImportExport\Api\Data\OfferImportMessageInterface;
use Maas\ImportExport\Model\Import\MessageQueue;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Csv;
use Maas\Offer\Api\Data\OfferInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Offer\Model\Service\ProductSynchro;
use Maas\Seller\Api\Data\SellerInterface;
use Maas\ImportExport\Api\Data\Offer\SellerInterface as ImporExportSellerInterface;
use Maas\Seller\Api\SellerRepositoryInterface;
use Maas\Seller\Api\Data\SellerInterfaceFactory;
use Maas\Offer\Api\Data\OfferInterfaceFactory;
use Maas\ImportExport\Model\Registry;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\StateException;
use Maas\ImportExport\Model\Service\ProductImage;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Psr\Log\LogLevel;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\ImportExport\Console\Command\Import\Offer\Api;
use Magento\Framework\Api\Search\FilterGroupBuilder;

/**
 * Class Consumer
 *
 * @package Maas\ImportExport\Model\Import\Offer
 */
class Consumer extends AbstractConsumer implements ConsumerInterface
{
    const STATUS_ACTIVE = 'active';

    /**
     * @var OfferInterfaceFactory
     */
    private $offerFactory;

    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var SellerRepositoryInterface
     */
    private $sellerRepository;
    /**
     * @var SellerInterfaceFactory
     */
    private $sellerInterfaceFactory;

    /** @var ProductImage */
    private $productImageService;

    /**
     * @var ProductSynchro
     */
    private $productSynchro;

    /**
     * @var ReportRepositoryInterface
     */
    private $reportRepository;
    /**
     * @var string
     */
    private $sku;

    /**
     * @var Csv|null
     */
    private $logger;

    /**
     * @var ReportInterface
     */
    private $report;

    /**
     * @var MessageQueue
     */
    private $messageQueue;

    /**
     * @var FilterGroupBuilder
     */
    private $filterGroupBuilder;
    protected ReportManagementInterface $reportManagement;

    /**
     * Consumer constructor.
     *
     * @param ModuleListProxy $moduleList
     * @param OfferRepositoryInterface $offerRepository
     * @param OfferInterfaceFactory $offerInterfaceFactory
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param SellerRepositoryInterface $sellerRepository
     * @param SellerInterfaceFactory $sellerInterfaceFactory
     * @param Registry $registry
     * @param ProductSynchro $productSynchro
     * @param ProductImage $productImageService
     * @param DateTime $dateTime
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param Config $coreConfig
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param MessageQueue $messageQueue
     * @param FilterGroupBuilder $filterGroupBuilder
     */
    public function __construct(
        ModuleListProxy           $moduleList,
        OfferRepositoryInterface  $offerRepository,
        OfferInterfaceFactory     $offerInterfaceFactory,
        FilterBuilder             $filterBuilder,
        SearchCriteriaBuilder     $searchCriteriaBuilder,
        SellerRepositoryInterface $sellerRepository,
        SellerInterfaceFactory    $sellerInterfaceFactory,
        Registry                  $registry,
        ProductSynchro            $productSynchro,
        ProductImage              $productImageService,
        DateTime                  $dateTime,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        CsvLoggerManagement       $csvLoggerManagement,
        Config                    $coreConfig,
        CacheInterface            $cache,
        SerializerInterface       $serializer,
        ReportCollectionFactory   $reportCollectionFactory,
        MessageQueue              $messageQueue,
        FilterGroupBuilder        $filterGroupBuilder
    )
    {
        $this->offerFactory = $offerInterfaceFactory;
        $this->registry = $registry;
        $this->sellerRepository = $sellerRepository;
        $this->sellerInterfaceFactory = $sellerInterfaceFactory;
        $this->productImageService = $productImageService;
        $this->productSynchro = $productSynchro;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->messageQueue = $messageQueue;
        $this->filterGroupBuilder = $filterGroupBuilder;

        parent::__construct(
            $moduleList,
            $filterBuilder,
            $searchCriteriaBuilder,
            $offerRepository,
            $dateTime,
            $csvLoggerManagement,
            $cache,
            $coreConfig,
            $serializer,
            $reportCollectionFactory
        );
    }

    /**
     * @param OfferImportMessageInterface $message
     *
     * @throws CouldNotSaveException
     * @throws FileSystemException
     * @throws InputException
     * @throws StateException
     */
    public function process($message)
    {
        $this->registry->setCurrentlyImporting(true);
        $this->reportId = $message->getReportId();
        if ($this->reportId == 0) {
            $this->report = $this->getStartedImportReportObject(Offer::MAAS_LOG_MODULE, Offer::MAAS_LOG_ACTION);
            $this->reportId = $this->report->getId();
        } else {
            $this->report = $this->reportRepository->get($this->reportId);
        }

        $this->logger = $this->getCsvLogger($this->reportId);
        foreach ($message->getEntities() as $offerData) {
            $this->processEntity($offerData);
        }

        $this->messageQueue->setQueueName(Offer::QUEUE_MESSAGE_NAME);
        if ($this->report->isJobOver()) {
            $this->reportManagement->close($this->report);
            $this->cache->remove(Offer::CACHE_KEY_MAAS_REPORT_ID);
            $this->clearCacheOnJobOver();
        }
    }

    /**
     * @param $reportId
     * @return Csv|null
     */
    public function getCsvLogger($reportId)
    {
        if (is_null($this->csvLogger)) {
            $this->csvLogger = $this->csvLoggerManagement->getCsvLogger(
                $reportId,
                Offer::CSV_LOG_HEADERS,
                Offer::MAAS_LOG_MODULE,
                Offer::MAAS_LOG_ACTION,
                Offer::CSV_LOG_FILE_PREFIX
            );
        }
        return $this->csvLogger;
    }


    // No need to test this function
    // it had been tested in consumer price and inventory
    // @codeCoverageIgnoreStart

    /**
     * @param \Maas\ImportExport\Api\Data\Offer\OfferInterface $offerData
     */
    public function processEntity($offerData)
    {
        $this->offerMaasId = $offerData->getOfferId();

        if (is_null($offerData->getBestOfferRank())) {
            $this->report->log(
                sprintf('%s %s [INFO]  Best offer rank is null', $this->dateTime->date(), $this->offerMaasId),
                false,
                LogLevel::INFO
            );
            $this->report->setDeltaWarningItemsCount(1);
            $this->reportRepository->save($this->report);
            return;
        }

        $this->sku = $offerData->getProductId();
        $this->bestOfferRank = $offerData->getBestOfferRank() ?: 1;
        $newOffer = false;
        try {
            $dataSeller = $offerData->getSeller();
            $offer = $this->getOfferByProductAndBestOffer($this->sku, $this->bestOfferRank);
            if ($offer) {
                if (strtolower($offerData->getStatus()) != self::STATUS_ACTIVE) {
                    $this->deleteOffer($offer);
                    return;
                } elseif (!$this->isNewer($offerData->getUpdatedAt(), $offer->getSyncDate())) {
                    $this->report->log(
                        sprintf('%s %s [INFO]  Offer up to date', $this->dateTime->date(), $this->offerMaasId),
                        false,
                        LogLevel::INFO
                    );
                    $this->report->setDeltaSuccessItemsCount(1);
                    $this->reportRepository->save($this->report);
                    return;
                } elseif ($offer->getSellerId() != $dataSeller->getId()) {
                    $this->deleteOffer($offer, false);
                    $newOffer = true;
                    $offer = $this->offerFactory->create();
                }
            } else {
                if (strtolower($offerData->getStatus()) != self::STATUS_ACTIVE) {
                    $this->report->log(
                        sprintf('%s %s [INFO]  Offer is not active', $this->dateTime->date(), $this->offerMaasId),
                        false,
                        LogLevel::INFO
                    );
                    $this->report->setDeltaSuccessItemsCount(1);
                    $this->reportRepository->save($this->report);
                    return;
                }
                $newOffer = true;
                $offer = $this->offerFactory->create();
            }

            /* Create Seller */
            $seller = $this->createSeller($dataSeller);
            /* Import Offer images */
            if ($offerData->getImages() !== null) {
                $this->processImages($offer, $offerData->getImages());
            }
            $dataCondition = $offerData->getCondition();
            if ($isConfigEnabled = $this->coreConfig->isOfferPerfEnabled()) {
                $this->setNewRow([
                    'operation' => 'Create Offer item in database',
                    'sku' => $this->sku,
                ]);
            }

            $offer->setMaasEntityId($this->offerMaasId);
            $offer->setSellerId($seller->getId());
            $offer->setProductId($offerData->getProductId());
            $offer->setCondition($dataCondition->getCondition());
            $offer->setSubCondition($dataCondition->getSubCondition());
            $offer->setComment($dataCondition->getComment());
            $offer->setBestOffer($offerData->getBestOfferRank());
            $offer->setSyncDate($offerData->getUpdatedAt());
            $offer->setWarrantyDuration($offerData->getWarrantyDuration());

            $this->offerRepository->save($offer);
            if ($isConfigEnabled) {
                $this->endRow();
            }
            $this->reportNewOrUpdateOffer($newOffer);

            $this->report->setDeltaSuccessItemsCount(1);
            $this->registry->setCurrentlyImporting(false);
        } catch (Exception $e) {
            $this->report->log(
                sprintf('%s %s [ERROR] An error has occurred: %s %s', $this->dateTime->date(), $this->offerMaasId, $e->getMessage(), $e->getTraceAsString()),
                false,
                LogLevel::ERROR
            );
            $this->report->setDeltaErrorItemsCount(1);
            $this->report->setMessage($e->getMessage());
        }
        $this->reportRepository->save($this->report);
    }
    // @codeCoverageIgnoreEnd

    /**
     * @param OfferInterface $offer
     * @param bool $flag
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws StateException
     */
    private function deleteOffer(OfferInterface $offer, $flag = true)
    {
        $this->report->log(
            sprintf('%s %s [INFO]  Offer not active and deleted in database (Offer, price, inventories) ', $this->dateTime->date(), $offer->getMaasEntityId()),
            false,
            LogLevel::INFO
        );

        if ($isConfigEnabled = $this->coreConfig->isDeleteOfferPerfEnabled()) {
            $this->setNewRow([
                'operation' => 'Delete Offer',
                'sku' => $this->sku,
            ]);
        }
        $this->productSynchro->shouldDeleteOffer($offer);
        if ($isConfigEnabled) {
            $this->endRow(false);
        }
        if ($flag) {
            $this->report->setDeltaSuccessItemsCount(1);
            $this->reportRepository->save($this->report);
        }
    }

    /**
     * @param ImporExportSellerInterface $dataSeller
     *
     * @return SellerInterface
     */
    private function createSeller(ImporExportSellerInterface $dataSeller)
    {
        $seller = $this->getSeller($dataSeller->getId());
        if (!$seller) {
            $seller = $this->sellerInterfaceFactory->create();
        }
        if ($isConfigEnabled = $this->coreConfig->isSellerPerfEnabled()) {
            $this->setNewRow([
                'operation' => 'Create Seller item in database',
                'sku' => $this->sku,
            ]);
        }
        $seller->setMaasEntityId($dataSeller->getId())
            ->setName($dataSeller->getName());
        if ($isConfigEnabled) {
            $this->logger->storeMicrotimeStart('save_time');
        }
        $seller = $this->sellerRepository->save($seller);
        if ($isConfigEnabled) {
            $this->endRow();
        }

        return $seller;
    }

    /**
     * @param $sellerId
     *
     * @return SellerInterface
     */
    private function getSeller($sellerId)
    {
        $searchCriteria = $this->getSearchCriteria($sellerId);
        $sellerItem = $this->sellerRepository->getList($searchCriteria)->getItems();
        return current($sellerItem);
    }

    /**
     * @param OfferInterface $offer
     * @param OfferImagesInterface $images
     *
     * @throws FileSystemException
     */
    private function processImages(OfferInterface $offer, OfferImagesInterface $images)
    {
        if ($isConfigEnabled = $this->coreConfig->isImagesOfferImportPerfEnabled()) {
            $this->setNewRow([
                'operation' => 'Import offer images',
                'sku' => $this->sku,
            ]);
        }

        if (!empty($images->getLarge())) {
            $image = $images->getLarge();
        }
        if (!empty($images->getMedium()) && !$image->getUrl()) {
            $image = $images->getMedium();
        }
        if (!empty($images->getSmall()) && !$image->getUrl()) {
            $image = $images->getSmall();
        }
        if (!empty($image) && $image->getUrl()) {
            $offer->setImage($this->productImageService->upload(
                $image->getUrl(),
                'maas_offer'
            ));
        }
        if ($isConfigEnabled) {
            $this->endRow(false);
        }
    }

    /**
     * @param bool $newOffer
     */
    private function reportNewOrUpdateOffer(bool $newOffer)
    {
        if ($newOffer) {
            $this->report->log(
                sprintf('%s %s [INFO] Offer created in database', $this->dateTime->date(), $this->offerMaasId),
                false,
                LogLevel::INFO
            );
        } else {
            $this->report->log(
                sprintf('%s %s [INFO] Offer updated in database', $this->dateTime->date(), $this->offerMaasId),
                false,
                LogLevel::INFO
            );
        }
    }

    /**
     * @param $productId
     * @param $bestOffer
     * @return false|mixed|null
     */
    protected function getOfferByProductAndBestOffer($productId, $bestOffer)
    {
        $searchCriteria = $this->getSearchCriteriaGroup($productId, $bestOffer);
        $offerItem = $this->offerRepository->getList($searchCriteria)->getItems();
        return sizeof($offerItem) ? current($offerItem) : null;
    }

    /**
     * @param $productId
     * @param $bestOffer
     * @return \Magento\Framework\Api\SearchCriteria
     */
    private function getSearchCriteriaGroup($productId, $bestOffer)
    {
        $filterProduct = $this->filterBuilder
            ->setField('product_id')
            ->setConditionType('eq')
            ->setValue($productId)
            ->create();
        $filterBestOffer = $this->filterBuilder
            ->setField('best_offer')
            ->setConditionType('eq')
            ->setValue($bestOffer)
            ->create();
        $filterGroupProduct = $this->filterGroupBuilder
            ->setFilters([$filterProduct])
            ->create();
        $filterGroupBestOffer = $this->filterGroupBuilder
            ->setFilters([$filterBestOffer])
            ->create();
        $this->searchCriteriaBuilder->setFilterGroups([$filterGroupProduct, $filterGroupBestOffer]);
        return $this->searchCriteriaBuilder->create();
    }
}
