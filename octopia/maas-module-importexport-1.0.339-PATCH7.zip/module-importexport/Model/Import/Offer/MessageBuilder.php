<?php

namespace Maas\ImportExport\Model\Import\Offer;

use Maas\ImportExport\Api\Data\OfferImportMessageInterfaceFactory;
use Maas\ImportExport\Model\Import\AbstractMessageBuilder;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;
/**
 * Class OfferBuilder
 *
 * @package Maas\ImportExport\Model\ImportMessage
 */
class MessageBuilder extends AbstractMessageBuilder
{
    /**
     * @var ConfigProxy
     */
    private $config;

    /**
     * MessageBuilder constructor.
     *
     * @param OfferImportMessageInterfaceFactory $factory
     * @param ConfigProxy $config
     */
    public function __construct(
        OfferImportMessageInterfaceFactory $factory,
        ConfigProxy $config
    )
    {
        $this->config = $config;
        parent::__construct($factory);
    }

    /**
     * @inheritDoc
     */
    public function isSpaceLeft($entity)
    {
        return count($this->entities) < $this->config->getOffersNumberPerMessage();
    }
}
