<?php

namespace Maas\ImportExport\Model\Import\Common\Data;

use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Magento\Framework\DataObject;

/**
 * Class Image
 *
 * @package Maas\ImportExport\Model\Catalog\Data
 * @codeCoverageIgnore
 */
class Image extends DataObject implements ImageInterface
{
    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->getData('title');
    }

    /**
     * @param string $title
     *
     * @return $this
     */
    public function setTitle($title)
    {
        return $this->setData('title', $title);
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        return $this->getData('url');
    }

    /**
     * @param string $url
     *
     * @return $this
     */
    public function setUrl($url)
    {
        return $this->setData('url', $url);
    }

    /**
     * @return int
     */
    public function getSize()
    {
        return $this->getData('size');
    }

    /**
     * @param int $size
     *
     * @return $this
     */
    public function setSize($size)
    {
        return $this->setData('size', $size);
    }

    /**
     * @return int
     */
    public function getWidth()
    {
        return $this->getData('width');
    }

    /**
     * @param int $width
     *
     * @return $this
     */
    public function setWidth($width)
    {
        return $this->setData('width', $width);
    }

    /**
     * @return int
     */
    public function getHeight()
    {
        return $this->getData('height');
    }

    /**
     * @param int $height
     *
     * @return $this
     */
    public function setHeight($height)
    {
        return $this->setData('height', $height);
    }

    /**
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData('updatedAt');
    }

    /**
     * @param string $updatedAt
     *
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData('updatedAt', $updatedAt);
    }
}
