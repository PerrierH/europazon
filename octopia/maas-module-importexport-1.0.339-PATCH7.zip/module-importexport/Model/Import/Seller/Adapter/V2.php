<?php

namespace Maas\ImportExport\Model\Import\Seller\Adapter;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\AbstractImportV2Adapter;


/**
 * Class V2
 *
 * @package Maas\ImportExport\Model\Import\Seller\Adapter
 */
class V2 extends AbstractImportV2Adapter
{
    const API_REQUEST_ENDPOINT = '/sellers';

    /**
     * @param AbstractImportExportApi $api
     */
    protected function addAllFields(AbstractImportExportApi $api) {}

    /**
     * @param $items
     * @return mixed
     */
    protected function convertItems($items)
    {
        //No need to convert for seller entity
        return $items;
    }

    /**
     * @param AbstractImportExportApi $api
     */
    protected function handlePagination(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        if (isset($args['page'])) {
            $args['pageIndex'] = $args['page'];
            unset($args['page']);
        }

        if (isset($args['limit'])) {
            $args['pageSize'] = $args['limit'];
            unset($args['limit']);
        }
        $api->setArgs($args);
    }
}
