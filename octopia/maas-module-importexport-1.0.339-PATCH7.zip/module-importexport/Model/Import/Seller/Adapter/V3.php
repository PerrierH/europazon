<?php

namespace Maas\ImportExport\Model\Import\Seller\Adapter;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\Config\Proxy as ConfigModel;
use Maas\ImportExport\Model\Service\Client\CurlFactory;
use Magento\Framework\App\CacheInterface;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\ImportExport\Model\Import\Seller\Seller as SellerModel;

/**
 * Class V3
 */
class V3 extends V2
{
    /**
     * @var ConfigModel
     */
    protected $configModel;

    /**
     * @var ReportResource
     */
    protected $reportResource;


    /**
     * V3 constructor.
     *
     * @param CurlFactory $curlClientFactory
     * @param CacheInterface $cache
     * @param ConfigModel $configModel
     * @param ReportResource $reportResource
     */
    public function __construct(
        CurlFactory    $curlClientFactory,
        CacheInterface $cache,
        ConfigModel    $configModel,
        ReportResource $reportResource
    )
    {
        parent::__construct($curlClientFactory, $cache);
        $this->configModel = $configModel;
        $this->reportResource = $reportResource;
    }

    /**
     * @param AbstractImportExportApi $api
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function doRequest(AbstractImportExportApi $api)
    {
        $this->capitalizeBearer($api);
        $this->addAllFields($api);
        $this->addFilters($api);
        $this->handlePagination($api);

        $result = $this->doOriginalRequest($api);
        if ($result['status'] >= 400) {
            return $result;
        }
        $responseContents = json_decode($result['response'] ?? '', 1);
        $responseContents = $this->convertResult($api, $responseContents);
        $result['response'] = json_encode($responseContents);
        return $result;
    }


    /**
     * @param AbstractImportExportApi $api
     * @return AbstractImportExportApi
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function addFilters(AbstractImportExportApi $api)
    {
        $args = $api->getArgs();
        if ($result = $this->hasRan(SellerModel::MAAS_LOG_MODULE, SellerModel::MAAS_LOG_ACTION, SellerModel::MAAS_LOG_OPERATION_TYPE)) {
            if ($this->configModel->getCatalogSellerImportDeltaEnabled()) {
                if (isset($result['sync_date'])) {
                    $args['subscriptionUpdateAtMin'] = $this->convertToApiDate($result['sync_date']);
                }
            }
        } else {
            $args['subscriptionState'] = 'Active';
        }
        $api->setArgs($args);

        return $api;
    }


    /**
     * @param AbstractImportExportApi $api
     * @return string
     */
    protected function getEndPointUrl(AbstractImportExportApi $api)
    {
        $url = rtrim($api->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        $args = $api->getArgs();
        return is_array($api->getArgs()) && sizeof($api->getArgs()) ? $url . '?' . http_build_query($args) : $url;
    }


    /**
     * @param $module
     * @param $action
     * @param $operationType
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function hasRan($module, $action, $operationType)
    {
        return $this->reportResource->getFirstRunHasExecuted($module, $action, $operationType, true);
    }

    /**
     * @param $date
     * @return string
     */
    protected function convertToApiDate($date = '0000-00-00 00:00:00')
    {
        return str_replace(' ', 'T', $date) . 'Z';
    }

}
