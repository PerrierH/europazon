<?php

namespace Maas\ImportExport\Model\Import\Seller;

use Maas\ImportExport\Api\Data\SellerImportMessageInterfaceFactory;
use Maas\ImportExport\Model\Import\AbstractMessageBuilder;
use Maas\ImportExport\Model\Config\Proxy as ConfigProxy;

/**
 * Class MessageBuilder
 *
 * @package Maas\ImportExport\Model\Import\Seller
 */
class MessageBuilder extends AbstractMessageBuilder
{
    /**
     * @var ConfigProxy
     */
    private $config;

    /**
     * MessageBuilder constructor.
     *
     * @param SellerImportMessageInterfaceFactory $factory
     * @param ConfigProxy $config
     */
    public function __construct(
        SellerImportMessageInterfaceFactory $factory,
        ConfigProxy $config
    )
    {
        $this->config = $config;
        parent::__construct($factory);
    }

    /**
     * @inheritDoc
     */
    public function isSpaceLeft($entity)
    {
        return count($this->entities) < $this->config->getSellersNumberPerMessage();
    }
}
