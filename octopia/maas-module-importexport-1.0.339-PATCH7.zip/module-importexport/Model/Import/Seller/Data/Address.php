<?php

namespace Maas\ImportExport\Model\Import\Seller\Data;

use Maas\ImportExport\Api\Data\Seller\AddressInterface;
use Maas\Seller\Model\AddressTrait;
use Magento\Framework\DataObject;

class Address extends DataObject implements AddressInterface
{
    use AddressTrait;

    /**
     * @inheritDoc
     */
    public function getAppartmentNumber()
    {
        return $this->getData(self::APPARTMENTNUMBER);
    }

    /**
     * @inheritDoc
     */
    public function setAppartmentNumber($appartmentNumber)
    {
        return $this->setData(self::APPARTMENTNUMBER, $appartmentNumber);
    }
}