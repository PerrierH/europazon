<?php

namespace Maas\ImportExport\Model\Import\Seller\Data;

use Maas\ImportExport\Api\Data\Seller\SellerInterface;
use Magento\Framework\DataObject;

/**
 * Class Seller
 *
 * @package Maas\ImportExport\Model\Import\Seller\Data
 */
class Seller extends DataObject implements SellerInterface
{
    /**
     * @inheritDoc
     */
    public function getSellerId()
    {
        return $this->getData(self::SELLER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * @inheritDoc
     */
    public function getCreationDate()
    {
        return $this->getData(self::CREATION_DATE);
    }

    /**
     * @inheritDoc
     */
    public function setCreationDate($creationDate)
    {
        return $this->setData(self::CREATION_DATE, $creationDate);
    }

    /**
     * @inheritDoc
     */
    public function getLastUpdateDate()
    {
        return $this->getData(self::LAST_UPDATE_DATE);
    }

    /**
     * @inheritDoc
     */
    public function setLastUpdateDate($lastUpdateDate)
    {
        return $this->setData(self::LAST_UPDATE_DATE, $lastUpdateDate);
    }

    /**
     * @inheritDoc
     */
    public function getShopName()
    {
        return $this->getData(self::SHOP_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setShopName($shopName)
    {
        return $this->setData(self::SHOP_NAME, $shopName);
    }

    /**
     * @inheritDoc
     */
    public function getShopUrl()
    {
        return $this->getData(self::SHOP_URL);
    }

    /**
     * @inheritDoc
     */
    public function setShopUrl($shopUrl)
    {
        return $this->setData(self::SHOP_URL, $shopUrl);
    }

    /**
     * @inheritDoc
     */
    public function getShopLogo()
    {
        return $this->getData(self::SHOP_LOGO);
    }

    /**
     * @inheritDoc
     */
    public function setShopLogo($shopLogo)
    {
        return $this->setData(self::SHOP_LOGO, $shopLogo);
    }

    /**
     * @inheritDoc
     */
    public function getCompanyRegistrationNumber()
    {
        return $this->getData(self::COMPANY_REGISTRATION_NUMBER);
    }

    /**
     * @inheritDoc
     */
    public function setCompanyRegistrationNumber($companyRegistrationNumber)
    {
        return $this->setData(self::COMPANY_REGISTRATION_NUMBER, $companyRegistrationNumber);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryModes()
    {
        return $this->getData(self::DELIVERY_MODES);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryModes($deliveryModes)
    {
        return $this->setData(self::DELIVERY_MODES, $deliveryModes);
    }

    /**
     * @inheritDoc
     */
    public function getSubscription()
    {
        return $this->getData(self::SUBSCRIPTION);
    }

    /**
     * @inheritDoc
     */
    public function setSubscription($subscription)
    {
        return $this->setData(self::SUBSCRIPTION, $subscription);
    }

    /**
     * @inheritDoc
     */
    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    /**
     * @inheritDoc
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * @inheritDoc
     */
    public function getSalesAdvicesEmail()
    {
        return $this->getData(self::SALES_ADVICES_EMAIL);
    }

    /**
     * @inheritDoc
     */
    public function setSalesAdvicesEmail($salesAdvicesEmail)
    {
        return $this->setData(self::SALES_ADVICES_EMAIL, $salesAdvicesEmail);
    }

    /**
     * @inheritDoc
     */
    public function getNotificationsEmail()
    {
        return $this->getData(self::NOTIFICATIONS_EMAIL);
    }

    /**
     * @inheritDoc
     */
    public function setNotificationsEmail($notificationsEmail)
    {
        return $this->setData(self::NOTIFICATIONS_EMAIL, $notificationsEmail);
    }

    /**
     * @inheritDoc
     */
    public function getState()
    {
        return $this->getData(self::STATE);
    }

    /**
     * @inheritDoc
     */
    public function setState($state)
    {
        return $this->setData(self::STATE, $state);
    }

    /**
     * @inheritDoc
     */
    public function getSubState()
    {
        return $this->getData(self::SUB_STATE);
    }

    /**
     * @inheritDoc
     */
    public function setSubState($subState)
    {
        return $this->setData(self::SUB_STATE, $subState);
    }

    /**
     * @inheritDoc
     */
    public function getMobileNumber()
    {
        return $this->getData(self::MOBILE_NUMBER);
    }

    /**
     * @inheritDoc
     */
    public function setMobileNumber($mobileNumber)
    {
        return $this->setData(self::MOBILE_NUMBER, $mobileNumber);
    }

    /**
     * @inheritDoc
     */
    public function getAddress()
    {
        return $this->getData(self::ADDRESS);
    }

    /**
     * @inheritDoc
     */
    public function setAddress($address)
    {
        return $this->setData(self::ADDRESS, $address);
    }

    /**
     * @inheritDoc
     */
    public function getShippingCountry()
    {
        return $this->getData(self::SHIPPING_COUNTRY);
    }

    /**
     * @inheritDoc
     */
    public function setShippingCountry($shippingCountry)
    {
        return $this->setData(self::SHIPPING_COUNTRY, $shippingCountry);
    }

    /**
     * @inheritDoc
     */
    public function getLegalCompanyName()
    {
        return $this->getData(self::LEGAL_COMPANY_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setLegalCompanyName($legalCompanyName)
    {
        return $this->setData(self::LEGAL_COMPANY_NAME, $legalCompanyName);
    }

    /**
     * @inheritDoc
     */
    public function getLegalStatus()
    {
        return $this->getData(self::LEGAL_STATUS);
    }

    /**
     * @inheritDoc
     */
    public function setLegalStatus($legalStatus)
    {
        return $this->setData(self::LEGAL_STATUS, $legalStatus);
    }

    /**
     * @inheritDoc
     */
    public function getCompanyCapital()
    {
        return $this->getData(self::COMPANY_CAPITAL);
    }

    /**
     * @inheritDoc
     */
    public function setCompanyCapital($companyCapital)
    {
        return $this->setData(self::COMPANY_CAPITAL, $companyCapital);
    }

    /**
     * @inheritDoc
     */
    public function getIntracomVat()
    {
        return $this->getData(self::INTRACOM_VAT);
    }

    /**
     * @inheritDoc
     */
    public function setIntracomVat($intracomVat)
    {
        return $this->setData(self::INTRACOM_VAT, $intracomVat);
    }

    /**
     * @inheritDoc
     */
    public function getIsFulfillment()
    {
        return $this->getData(self::IS_FULFILLMENT);
    }

    /**
     * @inheritDoc
     */
    public function setIsFulfillment($isFulfillment)
    {
        return $this->setData(self::IS_FULFILLMENT, $isFulfillment);
    }

    /**
     * @inheritDoc
     */
    public function getLegalTerms()
    {
        return $this->getData(self::LEGAL_TERMS);
    }

    /**
     * @inheritDoc
     */
    public function setLegalTerms($legalTerms)
    {
        return $this->setData(self::LEGAL_TERMS, $legalTerms);
    }
}