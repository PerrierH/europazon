<?php

namespace Maas\ImportExport\Model\Import\Seller\Data;

use Maas\ImportExport\Api\Data\Seller\LogoInterface;
use Magento\Framework\DataObject;

/**
 * Class Logo
 *
 * @package Maas\ImportExport\Model\Import\Seller\Data
 */
class Logo extends DataObject implements LogoInterface
{
    /**
     * @inheritDoc
     */
    public function getPosition()
    {
        return $this->getData(self::POSITION);
    }

    /**
     * @inheritDoc
     */
    public function setPosition($position)
    {
        return $this->setData(self::POSITION, $position);
    }

    /**
     * @inheritDoc
     */
    public function getUrl()
    {
        return $this->getData(self::URL);
    }

    /**
     * @inheritDoc
     */
    public function setUrl($url)
    {
        return $this->setData(self::URL, $url);
    }

    /**
     * @inheritDoc
     */
    public function getRenditions()
    {
        return $this->getData(self::RENDITIONS);
    }

    /**
     * @inheritDoc
     */
    public function setRenditions($renditions)
    {
        return $this->setData(self::RENDITIONS, $renditions);
    }
}