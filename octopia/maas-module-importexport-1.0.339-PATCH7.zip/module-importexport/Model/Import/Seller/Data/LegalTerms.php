<?php

namespace Maas\ImportExport\Model\Import\Seller\Data;

use Maas\ImportExport\Api\Data\Seller\LegalTermsInterface;
use Magento\Framework\DataObject;

class LegalTerms extends DataObject implements LegalTermsInterface
{

    /**
     * @inheritDoc
     */
    public function getDescription()
    {
        return $this->getData(self::DESCRIPTION);
    }

    /**
     * @inheritDoc
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * @inheritDoc
     */
    public function getLanguageCode()
    {
        return $this->getData(self::LANGUAGECODE);
    }

    /**
     * @inheritDoc
     */
    public function setLanguageCode($languageCode)
    {
        return $this->setData(self::LANGUAGECODE, $languageCode);
    }
}