<?php

namespace Maas\ImportExport\Model\Import\Seller;

use Exception;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\Log\Model\Csv;
use Maas\Log\Model\Report;
use Maas\Sales\Exception\UnknownStatus;
use Zend_Http_Client;
use Zend_Http_Response;

/**
 * Class Seller
 *
 * @package Maas\ImportExport\Model\Import\Seller
 */
class Seller extends AbstractImportExportApi
{

    public const API_REQUEST_ENDPOINT = '/sellers';
    public const API_REQUEST_ENDPOINT_COUNT = '/sellers/count';
    public const API_REQUEST_ENDPOINT_ADDRESSES = '/sellers/%s/addresses';
    public const API_REQUEST_ENDPOINT_LEGAL_TERMS = '/sellers/%s/legal-terms';

    public const MAAS_LOG_ACTION = 'Import_Sellers';

    public const MAAS_LOG_MODULE = 'Maas_ImportExport';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_IMPORT;

    public const CSV_LOG_HEADERS = ['date', 'report_id', 'operation', 'seller_id', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'import-sellers';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_import_seller_maas_report_id';

    const QUEUE_MESSAGE_NAME = 'maas_importexport.import_seller.%s.queue';

    /**
     * @var bool
     */
    protected $saveReportAfterAdditionalApiCalls = false;

    /**
     * @return null[]|string[]
     */
    public function apiCall()
    {
        $result = parent::apiCall();
        if ($this->getMethod() != Zend_Http_Client::GET) {
            return $result;
        }

        /* Used to calculate api response time */
        $reportId = $this->loadReportIdFromCache();
        $logger = $this->getCsvLogger($reportId);

        $items = $this->getItemsFromResponseIfValid($result);
        if ($items) {
            $itemIds = [];
            foreach ($items as $item) {
                $itemIds[] = $item['sellerId'];
            }
            $this->saveReportAfterAdditionalApiCalls = false;
            $report = $this->loadReportFromCache();
            $items = $this->callSecondaryApi($items, $logger, $report,
                'Address Api call', static::API_REQUEST_ENDPOINT_ADDRESSES,
                'address', 'no addresses'
            );
            $items = $this->callSecondaryApi($items, $logger, $report,
                'Legal terms Api call', static::API_REQUEST_ENDPOINT_LEGAL_TERMS,
                'legal_terms', 'no legal terms', true
            );
            $result = $this->setItemsToResponse($result, $items);
            if ($this->saveReportAfterAdditionalApiCalls) {
                $this->reportRepository->save($report);
            }
        }
        return $result;
    }

    /**
     * @param array $response
     *
     * @return array|null
     */
    private function getItemsFromResponseIfValid($response)
    {
        if (is_array($response) && array_key_exists('status', $response) && $response['status'] == 200
            && array_key_exists('response', $response)) {
            $decoded = json_decode($response['response'] ?? '', true);
            if (array_key_exists('items', $decoded) && is_array($decoded['items'])) {
                return $decoded['items'];
            }
        }
        return null;
    }

    /**
     * @param array $items
     * @param Csv $logger
     * @param Report $report
     * @param string $operationLabel
     * @param string $apiPathTemplate
     * @param string $resultKey
     * @param string $noDataErrorMessage
     *
     * @return array
     */
    private function callSecondaryApi(
        $items,
        $logger,
        $report,
        $operationLabel,
        $apiPathTemplate,
        $resultKey,
        $noDataErrorMessage,
        $enableEmptyResult = false
    )
    {
        $resultItems = [];
        $reportId = $report->getId();
        foreach ($items as $item) {
            $logger->newRow([
                'date' => $this->dateTime->date(),
                'report_id' => $reportId,
                'operation' => $operationLabel,
                'seller_id' => $item['sellerId']
            ]);
            $logger->storeMicrotimeStart('total_time');
            $url = rtrim($this->configProvider->getSellersApiUrl(), '/') . sprintf($apiPathTemplate, $item['sellerId']);
            $response = $this->doRequest($url, $this->getMethod(), $this->getHeaders(), $this->getBody(),
                $this->getPostsParams());
            $subItems = $this->getItemsFromResponseIfValid($response);
            $logger->storeMicrotimeFinish('total_time');
            $logger->finalizeRow();
            if ($subItems || $enableEmptyResult) {
                $item[$resultKey] = $subItems ?? [];
                $resultItems[] = $item;
            } else {
                $logger->addRow([
                    'date' => $this->dateTime->date(),
                    'report_id' => $reportId,
                    'operation' => 'Incomplete seller data rejected',
                    'seller_id' => $item['sellerId']
                ]);
                if ($report) {
                    $report->log(sprintf('%s [INFO] Incomplete seller excluded (%s): %s', $this->dateTime->date(),
                        $noDataErrorMessage, $item['sellerId']));
                    $report->setDeltaWarningItemsCount($report->getDeltaWarningItemsCount() + 1);
                    $this->saveReportAfterAdditionalApiCalls = true;
                }
                $resultItems[] = null;
            }
        }
        return $resultItems;
    }

    /**
     * @param array $response
     * @param array $items
     *
     * @return array
     */
    private function setItemsToResponse($response, $items)
    {
        $decoded = json_decode($response['response'] ?? '', true);
        $decoded['items'] = $items;
        $response['response'] = json_encode($decoded);
        return $response;
    }

    public function getTotalItemsCount()
    {
        if (!$this->getMode()) {
            return 0;
        }
        $adapter = $this->getAdapter();
        $api = $this;
        if ($adapter) {
            // add filter args
            $api = $adapter->addFilters($this);
        }
        return $this->getTotalItemsCountFromGet($api);
    }

    /**
     * @param $api
     * @return int|mixed
     * @throws Exception
     */
    public function getTotalItemsCountFromGet($api)
    {
        try {
            $args = $api->getArgs();
            $filters = is_array($args) && sizeof($args) ? http_build_query($args) : '';
            $response = $this->doRequest(rtrim($this->getApiUrl(), '/') . self::API_REQUEST_ENDPOINT_COUNT . '?' . $filters, Zend_Http_Client::GET, $this->getHeaders());
            $result = $this->serializer->unserialize($response['response']);
            if (isset($result) && isset($result['count'])) {
                return $result['count'];
            }
        } catch (Exception $e) {
            if ($response['status'] > 400) {
                $error = sprintf('Error connecting with API Get Sellers: %s', $response['response']);
            } else {
                $error = sprintf('Error connecting with API Get Sellers: %s', $e->getMessage());
            }
            $this->report->log($error);
            throw new Exception($error);
        }
        return 0;
    }

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return $this->configProvider->getSellersApiUrl();
    }

    /**
     * @param Report $report
     * @param array|null $args
     *
     * @return array
     * @throws Exception
     */
    protected function doExecute(array $args = null)
    {
        try {
            return parent::doExecute($args);
        } catch (Exception $e) {
            $this->report->log(__('Error connecting with API GET Sellers: %s', $e->getMessage()));
            throw $e;
        }
    }

    /**
     * @param Zend_Http_Response $result
     *
     * @return array
     */
    protected function getAdditionalInfo(Zend_Http_Response $result)
    {
        $additional = parent::getAdditionalInfo($result);
        // @TODO [DSI_5245-1638] : Choose between lowercase and Uppercase when the API result will be stable
        $itemsCount = $result->getHeader('X-Total-Count');
        $itemsCount = !$itemsCount ? $result->getHeader('x-total-count') : $itemsCount;
        // @TODO END
        if ($itemsCount) {
            if (!is_array($additional)) {
                $additional = [];
            }
            $additional['totalCount'] = (int)$itemsCount;
        }
        return $additional;
    }
}
