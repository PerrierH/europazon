<?php


namespace Maas\ImportExport\Model\Import\Seller;

use Exception;
use Maas\Core\Model\Config;
use Maas\Core\Model\Service\MessageQueue\ConsumerInterface;
use Maas\ImportExport\Api\Data\Seller\LogoRenditionInterface;
use Maas\ImportExport\Api\Data\Seller\SellerInterface;
use Maas\ImportExport\Api\Data\SellerImportMessageInterface;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Import\AbstractConsumer;
use Maas\ImportExport\Model\Import\MessageQueue;
use Maas\ImportExport\Model\Service\ProductImage;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Offer\Api\Data\OfferInterfaceFactory;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\Seller\Api\Data\SellerInterface as SaveableSellerInterface;
use Maas\Seller\Api\Data\SellerInterfaceFactory;
use Maas\Seller\Api\Data\SellerShopLogoRenditionInterface;
use Maas\Seller\Api\Data\SellerShopLogoRenditionInterfaceFactory;
use Maas\Seller\Api\SellerRepositoryInterface;
use Maas\Seller\Model\AddressFactory;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Psr\Log\LogLevel;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;

/**
 * Class Consumer
 *
 * @package Maas\ImportExport\Model\Import\Seller
 */
class Consumer extends AbstractConsumer implements ConsumerInterface
{
    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;

    /**
     * @var SellerRepositoryInterface
     */
    protected $sellerRepository;

    /**
     * @var SellerInterfaceFactory
     */
    protected $sellerFactory;

    /**
     * @var MessageQueue
     */
    protected $messageQueue;

    /**
     * @var ReportInterface
     */
    protected $report;

    /**
     * @var int
     */
    private $sellerMaasId;

    /**
     * @var ProductImage
     */
    private $productImageService;

    /**
     * @var SellerShopLogoRenditionInterfaceFactory
     */
    private $sellerShopLogoRenditionFactory;

    /**
     * @var AddressFactory
     */
    private $addressFactory;
    protected ReportManagementInterface $reportManagement;

    /**
     * Consumer constructor.
     *
     * @param ModuleListProxy $moduleList
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OfferRepositoryInterface $offerRepository
     * @param DateTime $dateTime
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param CacheInterface $cache
     * @param Config $coreConfig
     * @param SerializerInterface $serializer
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ReportRepositoryInterface $reportRepository
     * @param SellerRepositoryInterface $sellerRepository
     * @param SellerInterfaceFactory $sellerFactory
     * @param MessageQueue $messageQueue
     * @param ProductImage $productImageService
     * @param SellerShopLogoRenditionInterfaceFactory $sellerShopLogoRenditionFactory
     * @param AddressFactory $addressFactory
     */
    public function __construct(
        ModuleListProxy $moduleList,
        FilterBuilder $filterBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        OfferRepositoryInterface $offerRepository,
        DateTime $dateTime,
        CsvLoggerManagement $csvLoggerManagement,
        CacheInterface $cache,
        Config $coreConfig,
        SerializerInterface $serializer,
        ReportCollectionFactory $reportCollectionFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        SellerRepositoryInterface $sellerRepository,
        SellerInterfaceFactory $sellerFactory,
        MessageQueue $messageQueue,
        ProductImage $productImageService,
        SellerShopLogoRenditionInterfaceFactory $sellerShopLogoRenditionFactory,
        AddressFactory $addressFactory
    )
    {
        parent::__construct($moduleList, $filterBuilder, $searchCriteriaBuilder, $offerRepository, $dateTime,
            $csvLoggerManagement, $cache, $coreConfig, $serializer, $reportCollectionFactory);

        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->sellerRepository = $sellerRepository;
        $this->sellerFactory = $sellerFactory;
        $this->messageQueue = $messageQueue;
        $this->productImageService = $productImageService;
        $this->sellerShopLogoRenditionFactory = $sellerShopLogoRenditionFactory;
        $this->addressFactory = $addressFactory;
    }

    /**
     * @param SellerImportMessageInterface $message
     */
    public function process($message)
    {
        $this->reportId = $message->getReportId();
        if ($this->reportId == 0) {
            $this->report = $this->getStartedImportReportObject(Seller::MAAS_LOG_MODULE, Seller::MAAS_LOG_ACTION);
            $this->reportId = $this->report->getId();
        } else {
            $this->report = $this->reportRepository->get($this->reportId);
        }
        $this->logger = $this->getCsvLogger($this->reportId);
        if ($this->report->getWarningItemsCount() + $this->report->getSuccessItemsCount() == 0) {
            $this->report->log(sprintf('%d sellers to import', $this->report->getItemsCount()));
        }
        foreach ($message->getEntities() as $sellerData) {
            $this->processEntity($sellerData);
        }

        // Update Report Status when all messages are consumed
        if ($this->report->isJobOver()) {
            $this->reportManagement->close($this->report);
            $this->clearCacheOnJobOver();
        }
    }

    /**
     * @inheritDoc
     */
    public function getCsvLogger($reportId)
    {
        if (is_null($this->csvLogger)) {
            $this->csvLogger = $this->csvLoggerManagement->getCsvLogger(
                $reportId,
                Seller::CSV_LOG_HEADERS,
                Seller::MAAS_LOG_MODULE,
                Seller::MAAS_LOG_ACTION,
                Seller::CSV_LOG_FILE_PREFIX
            );
        }
        return $this->csvLogger;
    }

    /**
     * @param SellerInterface $sellerData
     */
    public function processEntity($sellerData)
    {
        $this->sellerMaasId = $sellerData->getSellerId();
        $seller = $this->getSeller($this->sellerMaasId);
        if ($seller) {
            $newSeller = false;
        } else {
            $newSeller = true;
            $seller = $this->sellerFactory->create();
        }
        try {
            if ($isConfigEnabled = $this->coreConfig->isSellerPerfEnabled()) {
                $this->setNewRow([
                    'operation' => 'Create Seller in database',
                    'seller_id' => $this->sellerMaasId,
                ]);
            }

            $logoName = null;
            $logoPosition = 0;
            $renditions = [];

            $logo = $sellerData->getShopLogo();
            if ($logo) {
                $logoUrl = $logo->getUrl();
                $logoPosition = $logo->getPosition() ?? 0;

                if ($logoUrl && $this->productImageService->upload($logoUrl, 'maas_seller')) {
                    $logoName = '/' . basename($this->productImageService->getNewFileName($logoUrl));
                }

                $renditions = $logo->getRenditions();
                if (!$renditions) {
                    $renditions = [];
                }
            }

            $seller->setMaasEntityId($this->sellerMaasId)
                ->setName($sellerData->getShopName())
                ->setSyncDate($sellerData->getLastUpdateDate())
                ->setShopLogo($logoName)
                ->setShopLogoPosition($logoPosition)
                ->setShopLogoRenditions($this->createSaveableRenditions($renditions));

            foreach ([
                         'url' => 'getShopUrl',
                         'company_registration_number' => 'getCompanyRegistrationNumber',
                         'email' => 'getEmail',
                         'sales_advices_email' => 'getSalesAdvicesEmail',
                         'notifications_email' => 'getNotificationsEmail',
                         'state' => 'getState',
                         'substate' => 'getSubState',
                         'mobile' => 'getMobileNumber',
                         'shipping_country' => 'getShippingCountry',
                         'legal_company_name' => 'getLegalCompanyName',
                         'legal_status' => 'getLegalStatus',
                         'company_capital' => 'getCompanyCapital',
                         'intracom_vat' => 'getIntracomVat',
                         'is_fulfillment' => 'getIsFulfillment'
                     ] as $attributeCode => $getter) {
                $seller->setCustomAttribute($attributeCode, $sellerData->$getter());
            }

            $addresses = [];
            foreach ($sellerData->getAddress() as $addressData) {
                $addresses[] = $this->addressFactory->create()
                    ->setType($addressData->getType())
                    ->setAddress1($addressData->getAddress1())
                    ->setAddress2($addressData->getAddress2())
                    ->setAppartment($addressData->getAppartmentNumber())
                    ->setBuilding($addressData->getBuilding())
                    ->setZipCode($addressData->getZipCode())
                    ->setCity($addressData->getCity())
                    ->setCounty($addressData->getCounty())
                    ->setCountry($addressData->getCountry())
                    ->setInstructions($addressData->getInstructions());
            }
            $seller->setAddresses($addresses);

            foreach ($sellerData->getLegalTerms() as $legalTerms) {
                $seller->setCustomAttribute('legal_terms', $legalTerms->getDescription());
            }
            $this->sellerRepository->save($seller);
            if ($isConfigEnabled) {
                $this->endRow();
            }
            $this->reportNewOrUpdateSeller($newSeller);
            $this->report->setDeltaSuccessItemsCount(1);
        } catch (Exception $e) {
            $pattern = $newSeller ? '%s %s [ERROR] An error has occurred during creation: %s'
                : '%s %s [ERROR] An error has occurred during update: %s';
            $this->report->log(
                sprintf(__($pattern), $this->dateTime->date(), $this->sellerMaasId, $e->getMessage()),
                false,
                LogLevel::ERROR
            );
            $this->report->setDeltaErrorItemsCount(1);
            $this->report->setMessage($e->getMessage());
        }
        $this->report = $this->reportRepository->save($this->report);
    }

    /**
     * @param $maasSellerId
     *
     * @return SaveableSellerInterface
     */
    private function getSeller($maasSellerId)
    {
        $searchCriteria = $this->getSearchCriteria($maasSellerId);
        $sellerItem = $this->sellerRepository->getList($searchCriteria)->getItems();
        return current($sellerItem);
    }

    /**
     * @param LogoRenditionInterface[] $importedRenditions
     *
     * @return SellerShopLogoRenditionInterface[]
     */
    private function createSaveableRenditions($importedRenditions)
    {
        $saveableRenditions = [];
        foreach ($importedRenditions as $importedRendition) {
            $logoUrl = $importedRendition->getUrl();
            $this->productImageService->upload($logoUrl, 'maas_seller');
            $path = '/' . basename($this->productImageService->getNewFileName($logoUrl));

            /** @var SellerShopLogoRenditionInterface $saveableRendition */
            $saveableRendition = $this->sellerShopLogoRenditionFactory->create();
            $saveableRendition
                ->setName($importedRendition->getName())
                ->setPath($path)
                ->setWidth($importedRendition->getWidth())
                ->setHeight($importedRendition->getHeight());
            $saveableRenditions[] = $saveableRendition;
        }

        return $saveableRenditions;
    }

    /**
     * @param bool $newOffer
     */
    private function reportNewOrUpdateSeller(bool $newSeller)
    {
        if ($newSeller) {
            $this->report->log(
                sprintf('%s [INFO] Seller %s created in database', $this->dateTime->date(), $this->sellerMaasId),
                false,
                LogLevel::INFO
            );
        } else {
            $this->report->log(
                sprintf('%s [INFO] Seller %s updated in database', $this->dateTime->date(), $this->sellerMaasId),
                false,
                LogLevel::INFO
            );
        }
    }
}
