<?php

namespace Maas\ImportExport\Model\Import\Seller;

use Maas\Core\Model\Service\MessageQueue\Publisher as GenericPublisher;
use Maas\ImportExport\Api\Data\Seller\SellerInterface;
use Maas\ImportExport\Api\Data\Seller\SellerInterfaceFactory;
use Maas\ImportExport\Model\Service\Import;
use Maas\ImportExport\Model\Service\MessageQueue\AbstractImportPublisher;
use Magento\Framework\Api\DataObjectHelper;

/**
 * Class Publisher
 *
 * Extends the generic import publisher proxy by injecting the correct classes into the constructor.
 * Doing this via di.xml does not instantiate a factory, but injects an array with a class name instead.
 *
 * @package Maas\ImportExport\Model\Import\Seller
 *
 * @codeCoverageIgnore
 */
class Publisher extends AbstractImportPublisher
{
    public function __construct(
        GenericPublisher $publisher,
        MessageBuilder $messageBuilder,
        DataObjectHelper $dataObjectHelper,
        Import $importService,
        SellerInterfaceFactory $offerFactory
    ) {
        parent::__construct(
            $publisher,
            $messageBuilder,
            $dataObjectHelper,
            $importService,
            $offerFactory,
            SellerInterface::class
        );
    }
}
