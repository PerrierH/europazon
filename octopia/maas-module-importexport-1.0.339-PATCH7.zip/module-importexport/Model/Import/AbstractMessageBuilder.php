<?php

namespace Maas\ImportExport\Model\Import;

use Maas\ImportExport\Api\Data\AbstractImportMessageInterface;

/**
 * Class AbstractMessageBuilder
 *
 * @package Maas\ImportExport\Model\ImportMessage
 */
abstract class AbstractMessageBuilder
{
    /** @var array */
    protected $entities = [];

    /** @var int */
    protected $reportId = null;

    /** @var mixed|null */
    protected $factory = null;

    /**
     * AbstractBuilder constructor.
     * @param mixed $factory
     */
    public function __construct(
        $factory
    )
    {
        $this->factory = $factory;
    }

    /**
     * @param mixed $entity
     * @return boolean
     */
    abstract public function isSpaceLeft($entity);

    /**
     * @param mixed $entity
     * @return $this
     */
    public function addEntity($entity)
    {
        $this->entities[] = $entity;
        return $this;
    }

    /**
     * @return int
     */
    public function getEntityCount()
    {
        return count($this->entities);
    }

    /**
     * @param int $reportId
     * @return $this
     */
    public function setReportId($reportId)
    {
        $this->reportId = $reportId;
        return $this;
    }

    /**
     * @return AbstractImportMessageInterface
     */
    public function build()
    {
        /** @var AbstractImportMessageInterface $message */
        $message = $this->factory->create();
        $message->setReportId($this->reportId);
        $message->setEntities($this->entities);

        $this->entities = [];

        return $message;
    }
}
