<?php

namespace Maas\ImportExport\Model\ResourceModel;

use Magento\Framework\Exception\LocalizedException;
use Magento\ImportExport\Model\ResourceModel\Import\Data;

/**
 * Class Import
 *
 * @package Maas\ImportExport\Model\ResourceModel
 * @codeCoverageIgnore Database operations
 */
class Import
{
    /**
     * @var Data
     */
    private $data;

    /**
     * Import constructor.
     *
     * @param Data $data
     */
    public function __construct(
        Data $data
    ) {
        $this->data = $data;
    }


    /**
     * @param $entityTypeCode
     *
     * @throws LocalizedException
     */
    public function cleanTableImportExportImportData($entityTypeCode)
    {
        $condition = ['entity = ?' => $entityTypeCode];
        $this->data->getConnection()->delete($this->data->getMainTable(), $condition);
    }

    /**
     * @param string $entity
     *
     * @return array
     * @throws LocalizedException
     */
    public function getRow(string $entity)
    {
        $select = $this->data
            ->getConnection()
            ->select()
            ->from($this->data->getMainTable())
            ->where('entity = ?', $entity);
        return $this->data->getConnection()->fetchRow($select);
    }
}
