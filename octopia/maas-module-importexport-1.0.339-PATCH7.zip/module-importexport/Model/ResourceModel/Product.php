<?php

namespace Maas\ImportExport\Model\ResourceModel;

use Maas\Catalog\Model\ResourceModel\Product as ProductResource;

/**
 * Class Product
 *
 * @package Maas\ImportExport\Model\ResourceModel
 * @codeCoverageIgnore Database operations
 */
class Product
{
    /**
     * @var ProductResource
     */
    protected $productResource;
    /**
     * @var array
     */
    protected $preloadedStatuses = [];
    /**
     * @var array
     */
    protected $skusToPreload = [];

    /**
     * Product constructor.
     *
     * @param ProductResource $productResource
     */
    public function __construct(
        ProductResource $productResource
    )
    {
        $this->productResource = $productResource;
    }

    /**
     * @return $this
     */
    public function clearIdsToPreload()
    {
        $this->skusToPreload = [];
        $this->preloadedStatuses = [];
        return $this;
    }

    /**
     * @param string $sku
     *
     * @return $this
     */
    public function addIdToPreload($sku)
    {
        $this->skusToPreload[] = $sku;
        $this->preloadedStatuses[$sku] = false;
        return $this;
    }

    /**
     * @return $this
     */
    public function preloadProductIdStatus()
    {
        $rows = $this->productResource->getProductsIdsBySkus($this->skusToPreload);
        foreach ($rows as $sku => $data) {
            $this->preloadedStatuses[$sku] = $data;
        }
        return $this;
    }


    /**
     * Entity ID not called directly, so that Staging mode which uses a different ID could be handled by Magento core.
     * @param string $sku
     * @return false|int|mixed
     */
    public function productSkuExists($sku)
    {
        return $this->preloadedStatuses[$sku] ?? ($this->productResource->getIdBySku($sku));
    }

    /**
     * @param $offerIds
     * @return array
     */
    public function preloadProductIdsByOfferIds($offerIds)
    {
        return $this->productResource->getProductsIdsByOfferIds($offerIds);
    }

    /**
     * @return string|null
     */
    public function createSequenceProduct()
    {
        return $this->productResource->createSequenceProduct();
    }
}