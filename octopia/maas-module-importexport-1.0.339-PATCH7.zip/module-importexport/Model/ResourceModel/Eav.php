<?php

namespace Maas\ImportExport\Model\ResourceModel;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\Option;

/**
 * Class Eav
 *
 * @package Maas\ImportExport\Model\ResourceModel
 */
class Eav
{
    /**
     * @var Option
     */
    protected $optionResource;

    /**
     * @param Option $optionResource
     */
    public function __construct(
        Option $optionResource
    )
    {
        $this->optionResource = $optionResource;
    }

    /**
     * @param $optionsToAdd
     *
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function createOptionsIfNotExist($optionsToAdd)
    {
        $optionsAdded = false;
        $connection = $this->optionResource->getConnection();
        $select = $connection->select()->from(['o' => $this->optionResource->getMainTable()], ['attribute_id'])
            ->join(['v' => $this->optionResource->getTable('eav_attribute_option_value')], 'o.option_id = v.option_id and v.store_id = 0', ['v.value'])
            ->where('o.attribute_id in (?)', array_keys($optionsToAdd));

        $existingOptions = [];
        foreach($connection->fetchAll($select) as $row)
        {
            $existingOptions[$row['attribute_id']][] = $row['value'];
        }
        foreach($optionsToAdd as $attributeId => $valueOptionsToAdd)
        {
            foreach($valueOptionsToAdd as $valueToAdd)
            {
                if(isset($existingOptions[$attributeId]) && in_array($valueToAdd, $existingOptions[$attributeId]))
                {
                    continue;
                }
                $connection->insert($this->optionResource->getMainTable(), ['attribute_id' => $attributeId]);
                $connection->insert($this->optionResource->getTable('eav_attribute_option_value'), [
                    'value' => trim($valueToAdd), 'option_id' => new \Zend_Db_Expr('LAST_INSERT_ID()'), 'store_id' => 0
                ]);

                $optionsAdded = true;
            }
        }
        return $optionsAdded;
    }
}