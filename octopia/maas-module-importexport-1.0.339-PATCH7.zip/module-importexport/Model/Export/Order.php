<?php

namespace Maas\ImportExport\Model\Export;

use Exception;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\Config;
use Maas\Catalog\Model\Config as CatalogConfig;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Offer\Model\Service\Offer as OfferService;
use Maas\Sales\Exception\NoMatchingOctopiaPaymentCode;
use Maas\Sales\Exception\OfferMissing;
use Maas\Sales\Exception\UnknownStatus;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\SalesOrderInfoRepository;
use Maas\Sales\Model\Service\Data\OrderStatus;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessor;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Address;
use Magento\Sales\Model\Order\Item;
use Magento\Sales\Model\ResourceModel\Order\Collection;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Tax\Api\OrderTaxManagementInterface;
use Zend_Http_Client;

/**
 * Class ExportOrder
 *
 * @package Maas\ImportExport\Model
 */
class Order extends AbstractImportExportApi
{
    public const API_REQUEST_ENDPOINT = '/orders';

    public const MAAS_LOG_ACTION = 'Export_Orders';

    public const MAAS_LOG_MODULE = 'Maas_ImportExport';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_EXPORT;

    public const CSV_LOG_HEADERS = ['report_id', 'operation', 'order_id', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'export-orders';

    public const CACHE_KEY_MAAS_REPORT_ID = 'maas_export_order_maas_report_id';

    public const UNSPECIFIED_CIVILITY = 'Unspecified';

    public const ROUND_PRECISION = 4;

    /**
     * @var OrderTaxManagementInterface
     */
    protected $orderTaxManagement;
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /** @var CollectionFactory */
    private $orderCollectionFactory;

    /** @var JoinProcessor */
    private $joinProcessor;

    /** @var OrderRepositoryInterface */
    private $orderRepository;

    /** @var SalesOrderInfoRepository */
    private $orderInfoRepository;

    /** @var OfferService */
    private $offerService;

    /**
     * @var CatalogConfig
     */
    protected $catalogConfig;

    /**
     * Order Constructor
     *
     * @param ClientFactory $httpClientFactory
     * @param Config $configProvider
     * @param SerializerInterface $serializer
     * @param TokenRepository $tokenRepository
     * @param CacheInterface $cache
     * @param DateTime $dateTime
     * @param TokenFactory $tokenFactory
     * @param ErrorLogger $errorLogger
     * @param ReportFactory $reportFactory
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ReportResource $reportResource
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param ScopeConfigInterface $scopeConfig
     * @param OrderTaxManagementInterface $orderTaxManagement
     * @param CollectionFactory $orderCollectionFactory
     * @param JoinProcessor $joinProcessor
     * @param OrderRepositoryInterface $orderRepository
     * @param SalesOrderInfoRepository $orderInfoRepository
     * @param CatalogConfig $catalogConfig
     * @param OfferService $offerService
     * @param array $adapters
     */
    public function __construct(
        ClientFactory $httpClientFactory,
        Config $configProvider,
        SerializerInterface $serializer,
        TokenRepository $tokenRepository,
        CacheInterface $cache,
        DateTime $dateTime,
        TokenFactory $tokenFactory,
        ErrorLogger $errorLogger,
        ReportFactory $reportFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        ReportCollectionFactory $reportCollectionFactory,
        ReportResource $reportResource,
        CsvLoggerManagement $csvLoggerManagement,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        ScopeConfigInterface $scopeConfig,
        OrderTaxManagementInterface $orderTaxManagement,
        CollectionFactory $orderCollectionFactory,
        JoinProcessor $joinProcessor,
        OrderRepositoryInterface $orderRepository,
        SalesOrderInfoRepository $orderInfoRepository,
        CatalogConfig $catalogConfig,
        OfferService $offerService,
        array $adapters = []
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->orderTaxManagement = $orderTaxManagement;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->joinProcessor = $joinProcessor;
        $this->orderRepository = $orderRepository;
        $this->orderInfoRepository = $orderInfoRepository;
        $this->offerService = $offerService;
        $this->catalogConfig = $catalogConfig;

        parent::__construct(
            $httpClientFactory,
            $configProvider,
            $serializer,
            $tokenRepository,
            $cache,
            $dateTime,
            $tokenFactory,
            $errorLogger,
            $reportFactory,
            $reportRepository,
            $reportManagement,
            $reportCollectionFactory,
            $reportResource,
            $csvLoggerManagement,
            $searchCriteriaBuilder,
            $filterBuilder,
            $adapters
        );
    }

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return $this->configProvider->getOrdersApiUrl();
    }

    /**
     * @param array|null $args
     * @return array
     */
    protected function doExecute(array $args = null)
    {
        //Create collection
        $collection = $this->getOrderCollection($args);
        $report = $this->loadReportFromCache();
        if (count($collection->getItems()) == 0) {
            if ($report) {
                $report->log(__('No order to export'), true);
            }
            return [
                'itemsCount' => 0,
                'errorItemsCount' => 0,
                'successItemsCount' => 0,
                'error' => false,
                'message' => ''
            ];
        }

        // Process orders
        $error = false;
        $totalItemsCount = 0;
        $errorItemsCount = 0;
        $successItemsCount = 0;
        $errorMessages = [];
        foreach ($collection->getItems() as $order) {
            if ($this->checkOrderStatus($order)) {
                $totalItemsCount++;
                try {
                    /** @var \Magento\Sales\Model\Order $order */
                    if ($report) {
                        $report->log(__('Starting export for order %1', $order->getIncrementId()));
                    }
                    $this->setBody($this->exportOrderToJson($order));
                    $this->setMethod(Zend_Http_Client::POST);
                    $result = $this->apiCall();
                    if ($report) {
                        $report->log($result['response']);
                    }
                    if ($result['status'] >= 400 && $result['status'] != 409) {
                        throw new UnknownStatus($result['response']);
                    } elseif ($result['status'] == 409) {
                        $error = true;
                        $errorMessages[] = $result['response'];
                        $errorItemsCount++;
                        if ($report) {
                            $report->log(__('Error when exporting order %1', $order->getIncrementId()));
                        }
                    } else {
                        $successItemsCount++;
                        if ($report) {
                            $report->log(__('Export successful for order %1', $order->getIncrementId()));
                        }
                    }
                    $orderMaasId = $this->extractOrderMaasId($result);
                    $extraInfo = $order->getExtensionAttributes()->getExtraInfo();
                    $extraInfo->setExported(true);
                    $extraInfo->setOrderMaasId($orderMaasId);
                    $this->orderInfoRepository->save($extraInfo);
                    $order->setStatus(OrderStatus::STATUS_EXPORTED);
                    $order->addCommentToStatusHistory(__('Order sent to the sales channel interface'));
                    if ($orderMaasId) {
                        $order->addCommentToStatusHistory(__('Order is created successfully on the api'));
                    } elseif (isset($result['response']['errors'])) {
                        $order->addCommentToStatusHistory(__('Error response api :%1', $result['response']['errors']));
                    } else {
                        $order->addCommentToStatusHistory(__('Error response api'));
                    }
                    $this->orderRepository->save($order);
                } catch (Exception $e) {
                    $error = true;
                    $errorMessages[] = $e->getMessage();
                    $errorItemsCount++;
                    if ($report) {
                        $report->log(__('Error when exporting order %1', $order->getIncrementId()));
                    }
                }
            }
        }
        return [
            'itemsCount' => $totalItemsCount,
            'errorItemsCount' => $errorItemsCount,
            'successItemsCount' => $successItemsCount,
            'error' => $error,
            'message' => $this->formatErrorMessages($errorMessages)
        ];
    }

    /**
     * @param array|null $args
     *
     * @return Collection
     */
    private function getOrderCollection(array $args = null)
    {
        $collection = $this->orderCollectionFactory->create();
        $this->joinProcessor->process($collection);
        $collection->addFieldToFilter(
            'extension_attribute_extra_info.order_type',
            ['eq' => SalesOrderInfo::ORDER_TYPE_MAAS]
        );
        $collection->addFieldToFilter(
            'extension_attribute_extra_info.exported',
            ['null' => true]
        );

        if ($args !== null && array_key_exists('orderId', $args)) {
            $collection->addAttributeToFilter(
                'entity_id',
                ['in' => explode(',', $args['orderId'])]
            );
        }
        return $collection;
    }

    /**
     * @param OrderInterface $order
     *
     * @return bool
     */
    private function checkOrderStatus(OrderInterface $order)
    {
        $paymentMethods = $this->configProvider->getPaymentMethodsExportStatus();
        if (
            isset($paymentMethods[$order->getPayment()->getMethod()])
            && is_array($paymentMethods[$order->getPayment()->getMethod()])
            && in_array($order->getStatus(), $paymentMethods[$order->getPayment()->getMethod()])
        ) {
            return true;
        }

        return false;
    }

    /**
     * Get the matching Octopia Payment Code for a Magento Order
     *
     * @param OrderInterface $order
     * @return mixed
     * @throws NoMatchingOctopiaPaymentCode|LocalizedException
     */
    private function getOctopiaPaymentCode(OrderInterface $order)
    {
        $report = $this->loadReportFromCache();
        $paymentMethods = $this->configProvider->getOctopiaPaymentCodeByMagentoPaymentCode();
        if (isset($paymentMethods[$order->getPayment()->getMethod()])
            && $paymentMethods[$order->getPayment()->getMethod()]) {
            return $paymentMethods[$order->getPayment()->getMethod()];
        }
        $error = __('The Octopia payment method is not selected for the Magento Payment method %1', $order->getPayment()->getMethodInstance()->getTitle());
        if ($report) {
            $report->log($error);
        }
        throw new NoMatchingOctopiaPaymentCode($error);
    }


    /**
     * @param OrderInterface $order
     * @return array
     * @throws NoMatchingOctopiaPaymentCode|LocalizedException
     */
    public function exportOrderToJson(OrderInterface $order)
    {
        $orderToExport['reference'] = $order->getIncrementId();
        $orderToExport['businessOrder'] = false;
        $orderToExport['seller'] = ['id' => $order->getExtensionAttributes()->getExtraInfo()->getSellerMaasId()];
        $orderToExport['customer'] = ['reference' => $order->getCustomerId()];
        $orderToExport['purchasedAt'] = $this->apiFormatDate($order->getCreatedAt());
        $orderToExport['payment'] = ['method' => $this->getOctopiaPaymentCode($order)];
        $orderToExport['currencyCode'] = $order->getOrderCurrencyCode();
        $orderToExport['billingAddress'] = $this->getBillingAdress($order);
        $orderToExport['lines'] = $this->getOrderItems($order);
        return $orderToExport;
    }

    /**
     * @param $date
     *
     * @return string
     */
    private function apiFormatDate($date)
    {
        if ($date) {
            return str_replace(' ', 'T', $date) . 'Z';
        }
        return '';
    }

    /**
     * @param OrderInterface $order
     *
     * @return array
     */
    private function getBillingAdress(OrderInterface $order)
    {
        /** @var Address $billingAddress */
        $billingAddress = $order->getBillingAddress();

        return [
            'civility' => $billingAddress->getPrefix() ?? $this::UNSPECIFIED_CIVILITY,
            'firstName' => $billingAddress->getFirstname(),
            'lastName' => $billingAddress->getLastname(),
            'companyName' => $billingAddress->getCompany() ?? '',
            //// @TODO some field are missing for company:   companyRegistrationNumberType, companyRegistrationNumber ,companyVatNumber
            'companyRegistrationNumberType' => '',
            'companyRegistrationNumber' => '',
            'companyVatNumber' => '',
            'addressLine1' => $billingAddress->getStreetLine(1),
            'addressLine2' => $billingAddress->getStreetLine(2),
            'postalCode' => $billingAddress->getPostcode(),
            'city' => $billingAddress->getCity(),
            'stateOrRegion' => $billingAddress->getRegion(),
            'countryCode' => $billingAddress->getCountryId(),
        ];
    }

    /**
     * @param OrderInterface $order
     *
     * @return array
     */
    private function getOrderItems(OrderInterface $order)
    {
        $productInfoExport = [];
        $orderItems = $order->getItems();
        $activatedTaxesCodes = $this->catalogConfig->getTaxCategoriesCodes('');

        foreach ($orderItems as $item) {
            $itemInfoToExport = [];
            if ($item->getParentItem()) {
                continue;
            }
            $extraInfo = $item->getExtensionAttributes()->getExtraInfo();

            $itemInfoToExport['quantity'] = (int)$item->getQtyOrdered();
            $offerUnitSalesPrice = (float)$extraInfo->getOriginalPrice();
            if (!$extraInfo->getOriginalPrice() && $extraInfo->getOriginalPrice() == 0.00) {
                $offerUnitSalesPrice = (float)$item->getOriginalPrice();
            }
            $offerShippingCost = $extraInfo->getOriginalShippingAmount();
            $discountedShippingCost = $extraInfo->getShippingAmount();

            $weeeTaxesApplied = json_decode($item->getWeeeTaxApplied() ?? '', true) ?? [];
            $weeTaxesAmountTotal = 0;

            $taxAppliedByCodes = [];
            foreach ($weeeTaxesApplied as $weeeTaxApplied) {
                $weeTaxesAmountTotal += $weeeTaxApplied['amount_incl_tax'];
                if (array_key_exists('title', $weeeTaxApplied) && array_key_exists('amount_incl_tax', $weeeTaxApplied)) {
                    $taxAppliedByCodes[strtolower($weeeTaxApplied['title'])] = $weeeTaxApplied['amount_incl_tax'];
                }
            }

            $offerUnitSalesPriceSales = $item->getPriceInclTax() + $weeTaxesAmountTotal - ($item->getDiscountAmount() / $item->getQtyOrdered()); //Add the wee taxes

            [$offerTaxes, $sellingTaxes] = $this->getTaxes(
                $item,
                $activatedTaxesCodes,
                $taxAppliedByCodes,
                $offerUnitSalesPrice,
                $offerShippingCost,
                $discountedShippingCost,
                $weeTaxesAmountTotal
            );

            $itemInfoToExport['offerPrice'] = [
                'unitSalesPrice' => $offerUnitSalesPrice,
                'shippingCost' => $offerShippingCost * $item->getQtyOrdered(),
                'taxes' => $offerTaxes
            ];

            $itemInfoToExport['sellingPrice'] = [
                'unitSalesPrice' => (float)$offerUnitSalesPriceSales,
                'shippingCost' => $discountedShippingCost * $item->getQtyOrdered(),
                'taxes' => $sellingTaxes
            ];

            $itemInfoToExport['offer'] = [
                'id' => $extraInfo->getOfferMaasId(),
                'productId' => $item->getSku(),
                'condition' => $extraInfo->getCondition()
            ];

            $itemInfoToExport['delivery'] = [
                'mode' => $extraInfo->getShippingMethod(),
                'promisedAtMin' => $this->apiFormatDate($extraInfo->getDeliveryDateMin()),
                'promisedAtMax' => $this->apiFormatDate($extraInfo->getDeliveryDateMax())
            ];

            $itemInfoToExport['shippingAddress'] = $this->getShippingAddress($order);

            $productInfoExport[] = $itemInfoToExport;
        }

        return $productInfoExport;
    }

    /**
     * @param Item $item
     * @param array $activatedTaxesCodes
     * @param array $taxAppliedByCodes
     * @param float $offerUnitSalesPrice
     * @param float $offerShippingCost
     * @param float $weeTaxesAmountTotal
     * @return array
     */
    private function getTaxes($item, $activatedTaxesCodes, $taxAppliedByCodes, $offerUnitSalesPrice, $offerShippingCost, $discountedShippingCost, $weeTaxesAmountTotal): array
    {
        $offerTaxes = $sellingTaxes = [];
        $extraInfo = $item->getExtensionAttributes()->getExtraInfo();
        $originalTaxes = json_decode($extraInfo->getOriginalTaxes() ?? '', true);
        if ($originalTaxes) {
            $qty = $item->getQtyOrdered();
            foreach ($originalTaxes as $originalTax) {
                $value = (float)$originalTax['value'];
                if (!is_null($value)) {
                    $code = (string)$originalTax['code'];
                    $sellingTax = $offerTax = [
                        'code' => $code,
                        'target' => 'Offer'
                    ];
                    $code = strtolower($code);
                    if ($code == 'vat') {
                        $offerTax = array_merge($offerTax, [
                            'amount' => round($offerUnitSalesPrice * (1 - 1 / (1 + $value)), $this::ROUND_PRECISION),
                            'rate' => $value * 100,
                        ]);
                        $sellingTax = array_merge($sellingTax, [
                            'amount' => round($item->getTaxAmount() / (int)$item->getQtyOrdered(), $this::ROUND_PRECISION),
                            'rate' => (float)$item->getTaxPercent(),
                        ]);
                    } else if ($code == 'shippingvat') {
                        $offerTax = array_merge($offerTax, [
                            'target' => 'ShippingFees',
                            'amount' => round(($offerShippingCost * (1 - 1 / (1 + $value))) * $qty, $this::ROUND_PRECISION),
                            'rate' => $value * 100,
                        ]);
                        $sellingTax = array_merge($sellingTax, [
                            'target' => 'ShippingFees',
                            'amount' => round(($discountedShippingCost * (1 - 1 / (1 + $value))) * $qty, $this::ROUND_PRECISION),
                            'rate' => $value * 100,
                        ]);
                    } else if (in_array($code, $activatedTaxesCodes)) {
                        $offerTax = [];
                        $sellingTax = array_merge($sellingTax, [
                            'amount' => round(array_key_exists($code, $taxAppliedByCodes) ? (float)$taxAppliedByCodes[$code] : 0, $this::ROUND_PRECISION),
                            'rate' => $value * 100,
                        ]);
                    } else {
                        $offerTax = [];
                        $sellingTax = [];
                    }
                    if (count($offerTax)) {
                        $offerTaxes[] = $offerTax;
                    }
                    if (count($sellingTax)) {
                        $sellingTaxes[] = $sellingTax;
                    }
                }
            }
        }
        return [$offerTaxes, $sellingTaxes];
    }

    /**
     * @param OrderInterface $order
     *
     * @return array
     */
    private function getShippingAddress(OrderInterface $order)
    {
        /** @var  Address $shippingAddress */
        $shippingAddress = $order->getShippingAddress();

        $shippingAddressData = [
            'civility' => $shippingAddress->getPrefix() ?? self::UNSPECIFIED_CIVILITY,
            'firstName' => $shippingAddress->getFirstname(),
            'lastName' => $shippingAddress->getLastname(),
            'companyName' => $shippingAddress->getCompany() ?? '',
            'addressLine1' => $shippingAddress->getStreetLine(1),
            'addressLine2' => $shippingAddress->getStreetLine(2),
            'phone' => $shippingAddress->getTelephone(),
            'email' => $shippingAddress->getEmail(),
            'postalCode' => $shippingAddress->getPostcode(),
            'city' => $shippingAddress->getCity(),
            'stateOrRegion' => $shippingAddress->getRegion(),
            'countryCode' => $shippingAddress->getCountryId(),
        ];

        if ($shippingAddress->getLongitude() && $shippingAddress->getLatitude()) {
            $shippingAddressData["longitude"] = $shippingAddress->getLongitude();
            $shippingAddressData["latitude"] = $shippingAddress->getLatitude();
        }
        return $shippingAddressData;
    }

    /**
     * @param $result
     * @return false|mixed|string
     */
    public function extractOrderMaasId($result)
    {
        if (isset($result['headers']['Location']) && !empty($result['headers']['Location'])) {
            $pattern = explode('/orders/', $result['headers']['Location']);
            return end($pattern);
        }
        return '';
    }
}
