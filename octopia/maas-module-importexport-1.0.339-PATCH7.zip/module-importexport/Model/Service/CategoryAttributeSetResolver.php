<?php

namespace Maas\ImportExport\Model\Service;

use Magento\Catalog\Api\AttributeSetRepositoryInterface;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Api\Data\CategoryInterface;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Eav\Api\Data\AttributeInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Magento\Eav\Model\Entity\Attribute\Set;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Catalog\Model\ResourceModel\Category\Collection as CategoryCollection;

/**
 * Class CategoryAttributeSetResolver
 *
 * @package Maas\ImportExport\Model\Service
 */
class CategoryAttributeSetResolver
{
    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var CategoryFactory
     */
    protected $categoryFactory;

    /**
     * @var AttributeSetRepositoryInterface
     */
    protected $attributeSetRepository;

    /**
     * @var CategoryRepositoryInterface
     */
    private $categoryRepository;

    /**
     * @var CategoryCollectionFactory
     */
    private $categoryCollectionFactory;

    /**
     * @var ProductAttributeRepositoryInterface
     */
    private $productAttributeRepository;

    /**
     * CategoryAttributeSetResolver constructor.
     *
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param SerializerInterface $serializer
     * @param CacheInterface $cache
     * @param CategoryFactory $categoryFactory
     * @param AttributeSetRepositoryInterface $attributeSetRepository
     * @param CategoryRepositoryInterface $categoryRepository
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param ProductAttributeRepositoryInterface $productAttributeRepository
     */
    public function __construct(
        SearchCriteriaBuilder $searchCriteriaBuilder,
        SerializerInterface $serializer,
        CacheInterface $cache,
        CategoryFactory $categoryFactory,
        AttributeSetRepositoryInterface $attributeSetRepository,
        CategoryRepositoryInterface $categoryRepository,
        CategoryCollectionFactory $categoryCollectionFactory,
        ProductAttributeRepositoryInterface $productAttributeRepository

    ) {
        $this->serializer = $serializer;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->cache = $cache;
        $this->categoryFactory = $categoryFactory;
        $this->attributeSetRepository = $attributeSetRepository;
        $this->categoryRepository = $categoryRepository;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->productAttributeRepository = $productAttributeRepository;
    }

    /**
     * @param $key
     *
     * @return array|bool|float|int|string|null
     */
    protected function getCachedValue($key)
    {
        $cacheValue = $this->cache->load($key);
        if (empty($cacheValue)) {
            return [];
        }
        return $this->serializer->unserialize($cacheValue);
    }

    /**
     * Clear cache
     */
    public function clearCache()
    {
        $this->cache->remove(self::CACHE_KEY_CATEGORY_LEVEL_TOW);
        $this->cache->remove(self::CACHE_KEY_ATTRIBUTESET_NAMES);
    }

    /**
     * Get attributes data by attribute set
     *
     * @param AttributeSetInterface $attributeSet
     * @return array|null
     */
    public function getAttributesDataByAttributeSet(AttributeSetInterface $attributeSet): ?array
    {
        if ($attributeSet) {
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter('attribute_set_id', $attributeSet->getId())->create();
            $attributeList = $this->productAttributeRepository->getList($searchCriteria)->getItems();
            $attributes = [];
            /** @var AttributeInterface $attribute */
            foreach ($attributeList as $attribute) {
                if (substr($attribute->getAttributeCode(), 0, 5) == 'maas_') {
                    $attributes[$attribute->getDefaultFrontendLabel()] = [
                        'attribute_code' => $attribute->getAttributeCode(),
                        'additional_data' => $attribute->getAdditionalData()
                    ];
                }
            }
            return $attributes;
        }

        return null;
    }

    /**
     * Get the attribute set by the third level category
     *
     * @param string $categoryMaasId
     * @return AttributeSetInterface|null
     */
    public function getAttributeSetByCategory(string $categoryMaasId): ?AttributeSetInterface
    {
        $criteria = $this->searchCriteriaBuilder->addFilter('maas_category_id', $categoryMaasId)->create();
        $results = $this->attributeSetRepository->getList($criteria);
        if ($results->getTotalCount()  > 0) {
            $items = $results->getItems();
            return reset($items);
        }
        return null;
    }
}
