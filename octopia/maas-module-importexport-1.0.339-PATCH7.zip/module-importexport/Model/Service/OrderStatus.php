<?php

namespace Maas\ImportExport\Model\Service;

use Maas\Sales\Exception\UnknownStatus;
use Maas\Sales\Model\Service\Data\OrderStatus as DataStatus;
use Maas\Shipping\Model\ShipmentManager;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderItemRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Maas\Sales\Model\Service\OrderType;
use \Exception;

/**
 * Class OrderStatus
 *
 * @package Maas\ImporExport\Model\Service
 */
class OrderStatus
{
    /** @var OrderRepositoryInterface */
    private $orderRepositoryInterface;

    /** @var OrderItemRepositoryInterface */
    private $orderItemRepositoryInterface;

    /** @var ShipmentManager */
    private $shipmentManager;

    private $status = null;

    /** @var DataStatus */
    private $dataStatus;

    /**
     * @var OrderType
     */
    private $orderTypeService;

    private $commentByStatus = [
        DataStatus::STATUS_PROCESSING => 'Order created in the Sales interface channel.',
        DataStatus::STATUS_IN_PREPARATION => 'Order in preparation by the seller.',
        DataStatus::STATUS_SHIPPED => 'Order sent by the seller.',
        DataStatus::STATUS_DELIVERED => 'Order delivered to the customer.',
        DataStatus::STATUS_REJECTED => 'Order rejected by maas. Connect to the sales channel back office to get more details',
        DataStatus::STATUS_CANCELED => 'Order cancelled by maas. Connect to the sales channel back office to get more details',
        DataStatus::STATUS_ACCEPTED => 'Order accepted by the seller',
    ];

    /**
     * OrderStatus constructor.
     *
     * @param OrderRepositoryInterface $orderRepositoryInterface
     * @param OrderItemRepositoryInterface $orderItemRepositoryInterface
     * @param ShipmentManager $shipmentManager
     * @param DataStatus $dataStatus
     * @param OrderType $orderTypeService
     */
    public function __construct(
        OrderRepositoryInterface     $orderRepositoryInterface,
        OrderItemRepositoryInterface $orderItemRepositoryInterface,
        ShipmentManager              $shipmentManager,
        DataStatus                   $dataStatus,
        OrderType                    $orderTypeService
    )
    {
        $this->orderRepositoryInterface = $orderRepositoryInterface;
        $this->orderItemRepositoryInterface = $orderItemRepositoryInterface;
        $this->shipmentManager = $shipmentManager;
        $this->dataStatus = $dataStatus;
        $this->orderTypeService = $orderTypeService;
    }

    /**
     * @param OrderInterface $order
     * @param array $statusData
     *
     * @return OrderInterface
     * @throws Exception
     */
    public function update(OrderInterface $order, array $statusData)
    {
        $itemStatusData = $this->extractItemStatusData($statusData);
        $this->setStatusData($statusData['status']);

        $statusList = $this->dataStatus->getStatusWorkflow($order->getStatus(), $this->status, $this->isFulFillmentOrder($order));

        foreach ($statusList as $status) {
            if (!is_null($status) && $status != $order->getStatus()) {
                $order->setStatus($status);
                $this->setItemsStatusData($order, $itemStatusData);
            }
        }

        return $order;
    }

    /**
     * @param OrderInterface $order
     * @return bool
     */
    private function isFulFillmentOrder(OrderInterface $order)
    {
        return $this->orderTypeService->isOrderMarketplace($order);
    }

    /**
     * @param array $statusData
     *
     * @return array
     */
    private function extractItemStatusData($statusData)
    {
        $itemStatusData = [];
        if (isset($statusData['lines'])) {
            foreach ($statusData['lines'] as $itemStatus) {
                $itemStatusData[$itemStatus['offer']['id']] = $itemStatus;
            }
        }
        return $itemStatusData;
    }

    /**
     * @param string $statusData
     *
     * @throws UnknownStatus
     */
    private function setStatusData($statusData)
    {
        $this->status = $this->dataStatus->getMaasStatusByStatus($statusData);
        if ($this->status == null) {
            throw new UnknownStatus('Unknown status: ' . $statusData);
        }
    }

    /**
     * @param string $status
     *
     * @return \Magento\Framework\Phrase
     */
    private function getCommentByStatus($status)
    {
        return __($this->commentByStatus[$status]);
    }

    /**
     * @param OrderInterface $order
     * @param $itemStatusData
     *
     * @throws AlreadyExistsException
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    private function setItemsStatusData(OrderInterface $order, $itemStatusData)
    {
        foreach ($order->getItems() as $item) {
            $extraInfo = $item->getExtensionAttributes()->getExtraInfo();
            $offerMaasId = $extraInfo->getOfferMaasId();
            
            if (isset($itemStatusData[$offerMaasId])) {
                //set order item ric status
                $extraInfo->setStatus(array_key_exists('status', $itemStatusData[$offerMaasId])
                    ? $itemStatusData[$offerMaasId]['status'] : null);
                
                if ( array_key_exists('parcels', $itemStatusData[$offerMaasId]) && count($itemStatusData[$offerMaasId]['parcels'])) {
                    // creating the associated shipment
                    $this->shipmentManager->setShipment($item, current($itemStatusData[$offerMaasId]['parcels']));
                }
            }
        }
        $order->addCommentToStatusHistory($this->getCommentByStatus($order->getStatus()));
        $this->orderRepositoryInterface->save($order);
    }
}
