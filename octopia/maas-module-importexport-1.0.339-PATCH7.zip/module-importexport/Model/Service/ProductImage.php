<?php

namespace Maas\ImportExport\Model\Service;

use Maas\Catalog\Model\Service\MediaProcessor;
use Maas\ImportExport\Api\Data\Common\ImageInterface;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Gallery\Processor;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem\Io\File;
use Magento\MediaStorage\Model\File\Uploader;

/**
 * Class UploadImage
 *
 * @package Maas\ImportExport\Model\Service
 */
class ProductImage
{
    /** @var DirectoryList */
    protected $directoryList;

    /** @var File */
    protected $file;

    /** @var Processor */
    private $processor;

    /** @var MediaProcessor */
    private $mediaProcessor;

    /**
     * UploadImage constructor.
     *
     * @param DirectoryList $directoryList
     * @param File $file
     */
    public function __construct(
        DirectoryList $directoryList,
        File $file,
        Processor $processor,
        MediaProcessor $mediaProcessor
    )
    {
        $this->directoryList = $directoryList;
        $this->file = $file;
        $this->processor = $processor;
        $this->mediaProcessor = $mediaProcessor;
    }

    /**
     * @param ProductInterface $product
     * @param ImageInterface $image
     * @param bool $exclude
     * @param array $imageType
     *
     * @return bool|string
     * @throws FileSystemException
     * @throws LocalizedException
     */
    public function addToMediaGallery(
        ProductInterface $product,
        ImageInterface $image,
        $exclude = true,
        array $imageType = []
    )
    {
        $newFileName = $this->getNewFileName($image->getUrl());
        /** read file from URL and copy it to the new destination */
        $result = $this->file->read($image->getUrl(), $newFileName);
        if ($result) {
            /** add saved file to the $product gallery */
            $fileName = $this->processor->addImage($product, $newFileName, $imageType, true, $exclude);
            $this->processor->updateImage($product, $fileName, ['label' => $image->getTitle()]);
            $this->mediaProcessor->updateMassInfo($product, $fileName, ['image_url' => $image->getUrl()]);
        }

        return $result;
    }

    /**
     * @param string $sourceFileName
     * @param string $dir
     *
     * @return string
     * @throws FileSystemException
     */
    public function getNewFileName(string $sourceFileName, string $dir = 'tmp')
    {
        /** @var string $tmpDir */
        $tmpDir = $this->getMediaDir($dir);
        /** create folder if it is not exists */
        $this->file->checkAndCreateFolder($tmpDir);
        /** @var string $newFileName */
        return $tmpDir . Uploader::getCorrectFileName(baseName($sourceFileName));
    }

    /**
     * @param string $dir
     *
     * @return string
     * @throws FileSystemException
     */
    protected function getMediaDir(string $dir = 'tmp')
    {
        return $this->directoryList->getPath(DirectoryList::MEDIA) . DIRECTORY_SEPARATOR . $dir . DIRECTORY_SEPARATOR;
    }

    /**
     * @param string $sourceFileName
     * @param string $dir
     *
     * @return bool|string
     * @throws FileSystemException
     *
     * @codeCoverageIgnore
     */
    public function upload(string $sourceFileName, string $dir = 'tmp')
    {
        $newFileName = $this->getNewFileName($sourceFileName, $dir);
        return $this->file->read($sourceFileName, $newFileName);
    }

    /**
     * @param string $sourceFileName
     * @param string $targetName
     *
     * @return bool|string
     * @throws FileSystemException
     * @codeCoverageIgnore
     */
    public function uploadToImport(string $sourceFileName, $targetName = null)
    {
        $tmpDir = $this->directoryList->getPath(DirectoryList::MEDIA)
            . DIRECTORY_SEPARATOR
            . 'catalog/product'
            . DIRECTORY_SEPARATOR;

        if (is_null($targetName)) {
            $fileData = parse_url($sourceFileName);
            $fileName = substr((array_key_exists('query',
                $fileData) ? $fileData['path'] . $fileData['query'] : $fileData['path']), -90);
            $targetName = Uploader::getCorrectFileName($fileName);
        }

        $tmpDir .= $targetName[0] . DIRECTORY_SEPARATOR . $targetName[1] . DIRECTORY_SEPARATOR;
        $this->file->checkAndCreateFolder($tmpDir);
        $result = $this->file->read($sourceFileName, $tmpDir . $targetName);
        if ($result === true) {
            return DIRECTORY_SEPARATOR . $targetName[0] . DIRECTORY_SEPARATOR . $targetName[1] . DIRECTORY_SEPARATOR . $targetName;
        }
        return $result;
    }

    /**
     * @param string $sourceFileName
     *
     * @return string
     */
    public function getTargetFileName(string $sourceFileName)
    {
        $fileData = parse_url($sourceFileName);
        $fileName = substr((array_key_exists('query',
            $fileData) ? $fileData['path'] . $fileData['query'] : $fileData['path']), -90);
        return Uploader::getCorrectFileName($fileName);
    }

    /**
     * @param Product $product
     * @param ProductAttributeMediaGalleryEntryInterface $mediaGalleryEntry
     *
     * @codeCoverageIgnore
     */
    public function removeFromMediaGallery(
        ProductInterface $product,
        ProductAttributeMediaGalleryEntryInterface $mediaGalleryEntry
    )
    {
        $this->processor->removeImage($product, $mediaGalleryEntry->getFile());
    }

    /**
     * @param ProductInterface $product
     *
     * @return array
     */
    public function getMediaGalleryImageAsArray(ProductInterface $product)
    {
        $result = [];
        if ($product->getMediaGalleryEntries() === null) {
            return [];
        }

        foreach ($product->getMediaGalleryEntries() as $entry) {
            /** @var ProductAttributeMediaGalleryEntryInterface $entry */
            $maasInfo = $entry->getExtensionAttributes()->getMaasInfo();
            $result[$maasInfo->getImageUrl()] = $entry;
        }
        return $result;
    }
}
