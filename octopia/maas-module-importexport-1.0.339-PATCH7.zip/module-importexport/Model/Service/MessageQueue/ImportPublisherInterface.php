<?php

namespace Maas\ImportExport\Model\Service\MessageQueue;

use Magento\Framework\Exception\LocalizedException;

interface ImportPublisherInterface
{
    /**
     * @param string $entityType
     *
     * @return $this
     */
    public function setEntityType($entityType);

    /**
     * @param int $reportId
     *
     * @return $this
     */
    public function setReportId($reportId);

    /**
     * @param mixed $entityData
     *
     * @throws LocalizedException
     */
    public function publish($entityData);
}
