<?php

namespace Maas\ImportExport\Model\Service\MessageQueue;

use Maas\ImportExport\Model\Import\AbstractMessageBuilder;
use Maas\ImportExport\Model\Import\Catalog\Product\Publisher;
use Maas\ImportExport\Model\ImportMessage\AbstractBuilder;
use Maas\ImportExport\Model\Service\Import;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Exception\LocalizedException;

/**
 * Class ImportPublisher
 *
 * Uses the Publisher to emit import entity-specific messages
 *
 * @package Maas\ImportExport\Model\Service\MessageQueue
 *
 * @codeCoverageIgnore
 */
abstract class AbstractImportPublisher
{

    const QUEUE_NAME_PREFIX = 'maas_importexport.import_';

    /**
     * @var Publisher
     */
    protected $publisher;

    /**
     * @var string
     */
    protected $entityType;

    /**
     * @var int
     */
    protected $reportId;

    /**
     * @var AbstractMessageBuilder
     */
    protected $messageBuilder;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var object
     */
    protected $dataObjectFactory;

    /**
     * @var string
     */
    protected $dataObjectClass;
    protected Import $importService;

    public function __construct(
        \Maas\Core\Model\Service\MessageQueue\Publisher $publisher,
        AbstractMessageBuilder $builder,
        DataObjectHelper $dataObjectHelper,
        Import $importService,
        $dataObjectFactory,
        $dataObjectClass
    ) {
        $this->publisher = $publisher;
        $this->messageBuilder = $builder;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectFactory = $dataObjectFactory;
        $this->dataObjectClass = $dataObjectClass;
        $this->importService = $importService;
    }

    /**
     * @param string $entityType
     *
     * @return $this
     */
    public function setEntityType($entityType)
    {
        $this->entityType = $entityType;
        return $this;
    }

    /**
     * @param int $reportId
     *
     * @return $this
     */
    public function setReportId($reportId)
    {
        $this->reportId = $reportId;
        $this->messageBuilder->setReportId($reportId);
        return $this;
    }


    /**
     * @param mixed $entityData
     *
     * @return $this|Publisher
     * @throws LocalizedException
     */
    public function publish($entityData)
    {
        $dataObject = $this->dataObjectFactory->create();
        $this->importService->prepareDataKeys($entityData);
        $this->dataObjectHelper->populateWithArray(
            $dataObject, $entityData, $this->dataObjectClass
        );
        $this->enqueueEntity($dataObject);
        return $this;
    }

    /**
     * @param mixed $entityData
     *
     * @return $this
     * @throws LocalizedException
     */
    public function enqueueEntity($entityData)
    {
        if (!$this->messageBuilder->isSpaceLeft($entityData))
        {
            /** @var AbstractImportMessageInterface $message */
            $message = $this->messageBuilder->build();
            $this->publisher->publish(self::QUEUE_NAME_PREFIX . $this->entityType, $message);
        }
        $this->messageBuilder->addEntity($entityData);
        return $this;
    }

    /**
     * @return $this
     * @throws LocalizedException
     */
    public function publishRemaining()
    {
        if ($this->messageBuilder->getEntityCount())
        {
            /** @var AbstractImportMessageInterface $message */
            $message = $this->messageBuilder->build();
            $this->publisher->publish(self::QUEUE_NAME_PREFIX . $this->entityType, $message);
        }
        return $this;
    }
}
