<?php


namespace Maas\ImportExport\Model\Service;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Eav\Model\Entity\Attribute\AbstractAttribute;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SimpleDataObjectConverter;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Catalog\Model\ProductFactory;
use Magento\ConfigurableProduct\Api\Data\OptionValueInterfaceFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\ConfigurableProduct\Helper\Product\Options\Factory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Exception\LocalizedException;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class CreateConfigurableFromSimpleProduct
 *
 * @package Maas\ImportExport\Model\Service
 */
class CreateConfigurableFromSimpleProduct
{
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var FilterBuilder
     */
    private $filterBuilder;
    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;
    /**
     * @var SortOrderBuilder
     */
    private $sortOrderBuilder;
    /**
     * @var ProductFactory
     */
    private $productFactory;
    /**
     * @var Configurable
     */
    private $productConfigurable;
    /**
     * @var array
     */
    private $associatedProductIds = [];
    /**
     * @var string
     */
    private $configurableSku;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;
    /**
     * @var array
     */
    private $configurableAttributesData = [];
    /**
     * @var Factory
     */
    private $optionsFactory;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * CreateConfigurableFromSimpleProduct constructor.
     *
     * @param ProductRepositoryInterface $productRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param SortOrderBuilder $sortOrderBuilder
     * @param ProductFactory $productFactory
     * @param Configurable $productConfigurable
     * @param CollectionFactory $collection
     * @param Factory $optionFactory
     * @param EditionInterface $edition
     */
    public function __construct(
        ProductRepositoryInterface $productRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        SortOrderBuilder $sortOrderBuilder,
        ProductFactory $productFactory,
        Configurable $productConfigurable,
        CollectionFactory $collection,
        Factory $optionFactory,
        EditionInterface         $edition
    ) {
        $this->productRepository = $productRepository;
        $this->filterBuilder = $filterBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->sortOrderBuilder = $sortOrderBuilder;
        $this->productFactory = $productFactory;
        $this->productConfigurable = $productConfigurable;
        $this->optionsFactory = $optionFactory;
        $this->collectionFactory = $collection;
        $this->edition = $edition;
    }

    /**
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     * @throws LocalizedException
     */
    public function createConfigurableWithAssociatedSimpleProduct()
    {
        $variationGroupIds = [];
        $searchCriteria = $this->createSearchCriteria();
        $simplesProductWithVariationGroupId = $this->productRepository->getList($searchCriteria)->getItems();
        $configurable = null;
        $lastKey = end($simplesProductWithVariationGroupId)->getId();
        $attributesConfiguration = [];
        foreach ($simplesProductWithVariationGroupId as $key => $simpleProduct) {
            /** @var Product $variationGroupId */
            $variationGroupId = $simpleProduct->getMaasVariationGroupId();
            $configurableExistSku = $this->getIsSku($variationGroupId);
            $attributes = $simpleProduct->getAttributes();
            if (!in_array($variationGroupId, $variationGroupIds)) {
                $attributesForConfiguration = $simpleProduct->getMaasVariationAttributes();
                $attributesCodeConfiguration = explode(',', $attributesForConfiguration);
                $attributesConfiguration = $this->getConfigurationFrom($attributes, $attributesCodeConfiguration);
            }
            if ($configurable !== null && !in_array($variationGroupId, $variationGroupIds)) {
                $this->createConfigurations($configurable);
            }
            $configurable = $this->getConfigurable($configurableExistSku, $simpleProduct, $attributes);
            $variationGroupIds[] = $variationGroupId;
            if ($configurable != null) {
                $attributeIds = $this->createConfigurableAttributeWithOptionFrom(
                    $attributesConfiguration,
                    $simpleProduct
                );
                if ($attributeIds != []) {
                    $this->associateProductIdsFrom($simpleProduct, $configurable);
                    if ($key == $lastKey) {
                        $this->createConfigurations($configurable);
                    }
                }
            }
        }
    }

    /**
     * @return SearchCriteria
     */
    private function createSearchCriteria()
    {
        $filter = $this->filterBuilder
            ->setField('maas_variation_group_id')
            ->setConditionType('notnull')
            ->create();
        $sortOrder = $this->sortOrderBuilder
            ->setField('maas_variation_group_id')
            ->setDirection('DESC')
            ->create();
        $this->searchCriteriaBuilder->addFilters([$filter]);
        $this->searchCriteriaBuilder->setSortOrders([$sortOrder]);
        return $this->searchCriteriaBuilder->create();
    }

    /**
     * @param string $variationGroupId
     *
     * @return mixed
     */
    private function getIsSku(string $variationGroupId)
    {
        $data = $this->collectionFactory
            ->create()
            ->addAttributeToSelect('sku')
            ->addAttributeToFilter('type_id', 'configurable')
            ->addAttributeToFilter('maas_variation_group_id', $variationGroupId)
            ->getData();
        return array_shift($data)['sku'];
    }

    /**
     * @param AbstractAttribute $attribute
     *
     * @return mixed
     */
    private function createProduct(AbstractAttribute $attribute)
    {
        return $attribute->getAttributeCode();
    }


    /**
     * @param string $setttersGetter
     *
     * @return bool
     */
    private function shouldSetValue(string $setttersGetter)
    {
        return (
            $setttersGetter !== 'sku'
            && $setttersGetter !== 'type_id'
            && $setttersGetter !== $this->edition->getLinkField()
            && $setttersGetter !== 'visibility'
        );
    }

    /**
     * @param ProductInterface $simpleProduct
     * @param Product $configurable
     * @param string $setttersGetter
     */
    private function setValueFrom(ProductInterface $simpleProduct, Product $configurable, string $setttersGetter)
    {
        $setter = 'set' . SimpleDataObjectConverter::snakeCaseToUpperCamelCase($setttersGetter);
        $getter = 'get' . SimpleDataObjectConverter::snakeCaseToUpperCamelCase($setttersGetter);
        $configurable->$setter($simpleProduct->$getter());
    }


    /**
     * @param AbstractAttribute[] $attributes
     *
     * @return array
     */
    private function findSettersAndGettersFrom(array $attributes)
    {
        return array_map([$this, 'createProduct'], $attributes);
    }

    /**
     * @param Product $configurable
     * @param string $configurableSku
     */
    private function setSpecificValue(Product $configurable, string $configurableSku)
    {
        $configurable->setTypeId('configurable')
            ->setSku($configurableSku)
            ->setVisibility(4);
    }

    /**
     * @param AbstractAttribute[] $attributes
     *
     * @param array $attributesCodeConfiguration
     *
     * @return AbstractAttribute[]
     */
    private function getConfigurationFrom(array $attributes, array $attributesCodeConfiguration)
    {
        return array_filter($attributes, function ($attribute) use ($attributesCodeConfiguration) {
            return in_array($attribute->getAttributeCode(), $attributesCodeConfiguration);
        });
    }

    /**
     * @param AbstractAttribute $attribute
     * @param array $attributeValues
     *
     * @return array|array[]
     */
    private function createConfigurableAttributeData(AbstractAttribute $attribute, array $attributeValues)
    {
        $values = [
            'attribute_id' => $attribute->getId(),
            'code' => $attribute->getAttributeCode(),
            'label' => $attribute->getStoreLabel(),
            'position' => '0',
        ];
        if (count($this->configurableAttributesData) == 0) {
            $values['values'] = $attributeValues;
            return [$values];
        }
        $count = count($this->configurableAttributesData);
        foreach ($this->configurableAttributesData as $key => $configurableAttributeData) {
            if (array_key_exists(0, $attributeValues)) {
                if ($attributeValues[0]['attribute_id'] == $configurableAttributeData['attribute_id']) {
                    $attributeValue = array_shift($attributeValues);
                    $this->configurableAttributesData[$key]['values'][] = $attributeValue;
                } elseif ($key == $count - 1) {
                    $values['values'] = $attributeValues;
                    $this->configurableAttributesData[] = $values;
                }
            }
        }
        return $this->configurableAttributesData;
    }

    /**
     * @param AbstractAttribute $attribute
     * @param string $optionLabel
     *
     * @return array
     * @throws LocalizedException
     */
    private function createAttributeValues(AbstractAttribute $attribute, string $optionLabel)
    {
        $optionId = $attribute->getSource()->getOptionId($optionLabel);
        return [
            'label' => $optionLabel,
            'attribute_id' => $attribute->getId(),
            'value_index' => $optionId
        ];
    }

    /**
     * @param ProductInterface $configurable
     *
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws StateException
     */
    private function createConfigurations(ProductInterface $configurable)
    {
        $configurableOptions = $this->optionsFactory->create($this->configurableAttributesData);
        $extensionConfigurableAttributes = $configurable->getExtensionAttributes();
        $extensionConfigurableAttributes->setConfigurableProductOptions($configurableOptions);
        $configurable->setExtensionAttributes($extensionConfigurableAttributes);
        $this->productRepository->save($configurable);
        $this->configurableAttributesData = [];
        $configurable->setAssociatedProductIds([]);
        $this->associatedProductIds = [];
    }


    /**
     * @param AbstractAttribute[] $attributesConfiguration
     * @param ProductInterface $simpleProduct
     *
     * @return array
     * @throws LocalizedException
     */
    private function createConfigurableAttributeWithOptionFrom(
        array $attributesConfiguration,
        ProductInterface $simpleProduct
    ) {
        $attributeIds = [];
        foreach ($attributesConfiguration as $attribute) {
            $optionLabel = $simpleProduct->getAttributeText($attribute->getAttributeCode());
            if (!empty($optionLabel)) {
                $attributeValues = [];
                $attributeValues [] = $this->createAttributeValues($attribute, $optionLabel);
                $this->configurableAttributesData = $this->createConfigurableAttributeData(
                    $attribute,
                    $attributeValues
                );
                $attributeIds[] = $attribute->getId();
            }
        }
        return $attributeIds;
    }

    /**
     * @param ProductInterface $simpleProduct
     * @param ProductInterface $configurable
     */
    private function associateProductIdsFrom(ProductInterface $simpleProduct, ProductInterface $configurable)
    {
        $this->associatedProductIds[] = $simpleProduct->getId();
        $configurable->setAssociatedProductIds($this->associatedProductIds);
        $configurable->setCanSaveConfigurableAttributes(true);
    }

    /**
     * @param AbstractAttribute[] $attributes
     * @param ProductInterface $simpleProduct
     *
     * @return Product
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws StateException
     */
    private function createNewConfigurableFrom(array $attributes, ProductInterface $simpleProduct)
    {
        /** @var Product $configurable */
        $configurable = $this->productFactory->create();
        $settersGetters = $this->findSettersAndGettersFrom($attributes);
        foreach ($settersGetters as $setterGetter) {
            if ($this->shouldSetValue($setterGetter)) {
                $this->setValueFrom($simpleProduct, $configurable, $setterGetter);
            }
        }
        $this->configurableSku = $simpleProduct->getSku() . '_configurable';
        $this->setSpecificValue($configurable, $this->configurableSku);
        $this->productRepository->save($configurable);
        return $configurable;
    }

    /**
     * @param string|null $configurableExistSku
     * @param ProductInterface $simpleProduct
     * @param AbstractAttribute[] $attributes
     *
     * @return ProductInterface|Product
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    private function getConfigurable($configurableExistSku, ProductInterface $simpleProduct, array $attributes)
    {
        if (!empty($configurableExistSku)) {
            $this->configurableSku = $configurableExistSku;
            return $this->productRepository->get($configurableExistSku);
        }
        return $this->createNewConfigurableFrom($attributes, $simpleProduct);
    }
}
