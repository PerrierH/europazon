<?php

namespace Maas\ImportExport\Model\Service\Client;

use Magento\Framework\HTTP\Client\Curl as CurlClient;

/**
 * Class Curl
 *
 * The legacy Magento/Zend client does not allow sending HEAD requests
 *
 * @package Maas\ImportExport\Model\Service\Client
 */
class Curl extends CurlClient
{
    /**
     * Make HEAD request
     *
     * @param string $uri uri relative to host, ex. "/index.php"
     * @return void
     */
    public function callHead($uri)
    {
        $this->makeRequest("HEAD", $uri);
    }
}
