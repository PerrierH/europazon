<?php

declare(strict_types=1);

namespace Maas\ImportExport\Model\Service;

use Magento\Framework\Api\SimpleDataObjectConverter;
use Magento\Framework\App\ProductMetadataFactory;

class Import
{
    private ProductMetadataFactory $productMetadataFactory;

    private array $cache = [];

    public function __construct(ProductMetadataFactory $productMetadataFactory)
    {
        $this->productMetadataFactory = $productMetadataFactory;
    }

    public function prepareDataKeys(&$data): void
    {
        $version = $this->productMetadataFactory->create()->getVersion();
        if (version_compare($version, '2.4.4', '<')) {
            return;
        }

        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $this->prepareDataKeys($value);
            }
            if (!isset($this->cache[$key])) {
                $this->cache[$key] = SimpleDataObjectConverter::camelCaseToSnakeCase($key);
            }
            $data[$this->cache[$key]] = $value;
        }
    }
}