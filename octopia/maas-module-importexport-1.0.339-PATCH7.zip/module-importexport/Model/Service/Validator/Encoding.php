<?php

namespace Maas\ImportExport\Model\Service\Validator;

use InvalidArgumentException;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Class Encoding
 *
 * @package Maas\ImportExport\Model\Service\Validator
 */
class Encoding
{
    /**
     * @var Json
     */
    protected $jsonSerializer;

    /**
     * @param Json $jsonSerializer
     */
    public function __construct(
        Json $jsonSerializer
    ) {
        $this->jsonSerializer = $jsonSerializer;
    }

    /**
     * @param $data
     *
     * @return false|string
     */
    public function validate($data)
    {
        try {
            $encodedData = $this->jsonSerializer->serialize($data);
        } catch (InvalidArgumentException $e) {
            return $e->getMessage();
        }
        
        if (json_last_error() !== JSON_ERROR_NONE && empty($encodedData)) {
            return json_last_error_msg();
        }
        return false;
    }
}