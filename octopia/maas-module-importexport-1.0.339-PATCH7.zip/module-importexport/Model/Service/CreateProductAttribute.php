<?php


namespace Maas\ImportExport\Model\Service;

use Maas\ImportExport\Api\Data\Catalog\CategoryInterface;
use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory;
use Magento\Catalog\Model\Product\Attribute\Repository;
use Magento\Eav\Api\Data\AttributeInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Catalog\Api\AttributeSetRepositoryInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use Magento\Eav\Api\Data\AttributeOptionInterfaceFactory;
use Magento\Eav\Model\AttributeManagement;

/**
 * Class CreateAttribute
 * @package Maas\ImportExport\Model\Service
 */
class CreateProductAttribute extends BuilderCreator
{
    /**
     * @var AttributeFactory
     */
    private $attributeFactory;
    /**
     * @var Repository
     */
    private $attributeRepository;
    /**
     * @var AttributeSetRepositoryInterface
     */
    private $attributeSetRepository;
    /**
     * @var AttributeOptionInterfaceFactory
     */
    private $attributeOptionInterfaceFactory;
    /**
     * @var AttributeManagement
     */
    private $attributeManagement;

    /**
     * CreateAttributeOnFly constructor.
     *
     * @param AttributeFactory $attributeFactory
     * @param Repository $attributeRepository
     * @param FilterBuilder $filterBuilder
     * @param FilterGroupBuilder $filterGroupBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param AttributeSetRepositoryInterface $attributeSetRepository
     * @param AttributeOptionInterfaceFactory $attributeOptionInterfaceFactory
     * @param AttributeManagement $attributeManagement
     */
    public function __construct(
        AttributeFactory $attributeFactory,
        Repository $attributeRepository,
        FilterBuilder $filterBuilder,
        FilterGroupBuilder $filterGroupBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        AttributeSetRepositoryInterface $attributeSetRepository,
        AttributeOptionInterfaceFactory $attributeOptionInterfaceFactory,
        AttributeManagement $attributeManagement
    )
    {
        $this->attributeFactory = $attributeFactory;
        $this->attributeRepository = $attributeRepository;
        $this->attributeSetRepository = $attributeSetRepository;
        $this->attributeOptionInterfaceFactory = $attributeOptionInterfaceFactory;
        $this->attributeManagement = $attributeManagement;
        parent::__construct($filterBuilder, $filterGroupBuilder, $searchCriteriaBuilder);
    }

    /**
     * @param string $code
     * @param string $label
     * @param AttributeSetInterface|null $attributeSet
     * @param int $attributeGroupId
     * @param array $option []
     * @param array $attributeOption
     *
     * @return ProductAttributeInterface|AttributeInterface
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    public function createProductAttributeByCode(
        string $code,
        string $label,
        ?AttributeSetInterface $attributeSet,
        int $attributeGroupId = 0,
        array $option = [],
        array $attributeOption = []
    )
    {
        $attributeItem = $this->getAttributeIfExist($code);
        $attribute = null;

        $addVariation = $this->isVariationToAdd($option);
        if (empty($attributeItem)) {
            $attributeData = $this->attributeDefaultValues($label, $code, $option);
            $this->updateFilterVisibility($attributeData);
            $attribute = $this->attributeFactory->create();
            $attribute->addData($attributeData);
            $this->attributeRepository->save($attribute);
        } else {
            $attribute = array_shift($attributeItem);
            if ($attribute->getDefaultFrontendLabel() !== $label) {
                $attribute->setDefaultFrontendLabel($label);
                $this->attributeRepository->save($attribute);
            }
        }
        $this->attributeManagement->assign(
            ProductAttributeInterface::ENTITY_TYPE_CODE,
            $attributeSet->getId(),
            $attributeGroupId,
            $attribute->getAttributeCode(),
            null
        );
        $attribute = $this->processAttributeOption($attribute, $attributeOption);
        if ($addVariation && $attributeSet) {
            $additionalData = json_decode($attribute->getAdditionalData() ?? '', true) ?? [];
            $existingIds = $additionalData['maas_is_variation'] ?? [];
            if (!is_array($existingIds)) {
                $existingIds = [$existingIds];
            }
            $existingIds[] = reset($attributeSet)->getId();
            $additionalData['maas_is_variation'] = $existingIds;
            $attribute->setAdditionalData(json_encode($additionalData));
            $this->attributeRepository->save($attribute);
        }
        return $attribute;
    }

    /**
     * @param array $attributeData
     *
     * @return $this
     */
    protected function updateFilterVisibility(&$attributeData)
    {
        if(in_array($attributeData['frontend_input'], ['select', 'multiselect']))
        {
            $attributeData['is_filterable'] = 1;
            $attributeData['is_filterable_in_search'] = 1;
            $attributeData['is_visible_in_advanced_search'] = 1;
        }
        return $this;
    }

    /**
     * @param array $option
     *
     * @return bool
     */
    protected function isVariationToAdd($option)
    {
        if(isset($option['additional_data']))
        {
            $jsonDecoded = json_decode($option['additional_data'] ?? '', true);
            return isset($jsonDecoded['maas_is_variation']) && $jsonDecoded['maas_is_variation'];
        }
        return false;
    }

    /**
     * @param ProductAttributeInterface $attribute
     * @param array $attributeOption
     *
     * @return ProductAttributeInterface|AttributeInterface|mixed
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    protected function processAttributeOption($attribute, $attributeOption)
    {
        if (!empty($attributeOption)) {
            if(isset($attributeOption['value']))
            {
                $attribute = $this->createOption($attribute, $attributeOption['value']);
            }
            else
            {
                if(isset(reset($attributeOption)['value']))
                {
                    $attribute = $this->createOptions($attribute, $attributeOption);
                }
            }
        }
        return $attribute;
    }

    /**
     * @param string $code
     * @param string $label
     * @param array $options
     *
     * @return array
     */
    private function attributeDefaultValues(string $label, string $code, array $options = [])
    {
        return array_merge([
            'frontend_label' => [$label, ""],
            'frontend_input' => 'textarea',
            'is_required' => '0',
            'update_product_preview_image' => '0',
            'use_product_image_for_swatch' => '0',
            'visual_swatch_validation' => '',
            'visual_swatch_validation_unique' => '',
            'text_swatch_validation' => '',
            'text_swatch_validation_unique' => '',
            'dropdown_attribute_validation' => '',
            'dropdown_attribute_validation_unique' => '',
            'attribute_code' => $code,
            'is_global' => '1',
            'default_value_text' => '',
            'default_value_yesno' => '0',
            'default_value_date' => '',
            'default_value_textarea' => '',
            'is_unique' => '0',
            'frontend_class' => '',
            'is_used_in_grid' => '0',
            'is_visible_in_grid' => '0',
            'is_filterable_in_grid' => '0',
            'is_searchable' => '1',
            'is_comparable' => '0',
            'is_used_for_promo_rules' => '0',
            'is_html_allowed_on_front' => '1',
            'is_visible_on_front' => '1',
            'used_in_product_listing' => '0',
            'used_for_sort_by' => '0',
            'swatch_input_type' => 'dropdown',
            'source_model' => null,
            'backend_model' => null,
            'backend_type' => 'text',
            'is_filterable' => 0,
            'is_filterable_in_search' => 0
        ], $options);
    }

    /**
     * @param string $code
     *
     * @return ProductAttributeInterface[]|AttributeInterface[]
     */
    public function getAttributeIfExist(string $code)
    {
        $searchCriteria = $this->getSearchCriteria($code);
        return $this->attributeRepository->getList($searchCriteria)->getItems();
    }

    /**
     * @param $code
     *
     * @return SearchCriteria
     */
    private function getSearchCriteria(string $code)
    {
        $filterMaas = $this->getFilter('attribute_code', $code);
        $filterMagento = $this->getFilter('attribute_code', $code);
        $filterGroup = $this->getFilterGroup([$filterMaas, $filterMagento]);
        return $this->getSearchCriteriaGroup([$filterGroup]);
    }

    /**
     * @param AttributeInterface $attribute
     * @param string $value
     *
     * @return ProductAttributeInterface|AttributeInterface
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    private function createOption(AttributeInterface $attribute, string $value)
    {
        $isOption = $this->isOptionExist($attribute, $value);
        if ($isOption) {
            return $attribute;
        }
        /** @var AttributeOptionInterface $attributeOptionInterface */
        $attributeOptionInterface = $this->attributeOptionInterfaceFactory->create();
        $attributeOptionInterface->setLabel($value);
        $attributeOptionInterface->setValue($value);
        $attribute->setOptions([$attributeOptionInterface]);
        return $this->attributeRepository->save($attribute);
    }

    /**
     * @param AttributeInterface $attribute
     * @param array $values
     *
     * @return ProductAttributeInterface|AttributeInterface
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    private function createOptions(AttributeInterface $attribute, $values)
    {
        $attributeOptions = [];
        foreach($values as $value)
        {
            if ($this->isOptionExist($attribute, $value['value'])) {
                continue;
            }
            /** @var AttributeOptionInterface $attributeOptionInterface */
            $attributeOptionInterface = $this->attributeOptionInterfaceFactory->create();
            $attributeOptionInterface->setLabel($value['value']);
            $attributeOptions[] = $attributeOptionInterface;
        }
        if($attributeOptions)
        {
            $attribute->setOptions($attributeOptions);
            return $this->attributeRepository->save($attribute);
        }
        return $attribute;
    }

    /**
     * @param AttributeInterface $attribute
     * @param string $value
     *
     * @return false|AttributeInterface
     */
    private function isOptionExist(AttributeInterface $attribute, string $value)
    {
        $attributeOptions = $attribute->getOptions();
        array_shift($attributeOptions);
        foreach ($attributeOptions as $opt) {
            if ($opt->getLabel() == $value) {
                return $attribute;
            }
        }
        return false;
    }
}
