<?php

namespace Maas\ImportExport\Model\Service;

use Magento\Framework\Api\AbstractSimpleObject;
use Magento\Framework\Api\Filter;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\Search\FilterGroup;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;

abstract class BuilderCreator
{
    private FilterBuilder $filterBuilder;
    private FilterGroupBuilder $filterGroupBuilder;
    private SearchCriteriaBuilder $searchCriteriaBuilder;

    /**
     * @param FilterBuilder $filterBuilder
     * @param FilterGroupBuilder $filterGroupBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        FilterBuilder $filterBuilder,
        FilterGroupBuilder $filterGroupBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->filterBuilder = $filterBuilder;
        $this->filterGroupBuilder = $filterGroupBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * @param string $field
     * @param string $value
     * @param string $condition
     * @return Filter
     */
    protected function getFilter(string $field, string $value, string $condition = 'eq'): Filter
    {
        return $this->filterBuilder
            ->setField($field)
            ->setValue($value)
            ->setConditionType($condition)
            ->create();
    }

    /**
     * @param Filter[] $filters
     * @return AbstractSimpleObject
     */
    protected function getFilterGroup(array $filters): AbstractSimpleObject
    {
        return $this->filterGroupBuilder
            ->setFilters($filters)
            ->create();
    }

    /**
     * @param FilterGroup[] $filterGroup
     * @return SearchCriteria
     */
    protected function getSearchCriteriaGroup(array $filterGroup): SearchCriteria
    {
        return $this->searchCriteriaBuilder->setFilterGroups($filterGroup)->create();
    }
}
