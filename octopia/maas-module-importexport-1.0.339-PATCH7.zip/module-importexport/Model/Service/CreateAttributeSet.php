<?php

namespace Maas\ImportExport\Model\Service;

use Maas\AttributeSet\Api\Data\AttributeSetInfoInterfaceFactory;
use Maas\AttributeSet\Model\AttributeSetInfoFactory;
use Maas\ImportExport\Api\Data\Catalog\CategoryInterface;
use Magento\Catalog\Api\AttributeSetRepositoryInterface;
use Magento\Catalog\Api\ProductAttributeGroupRepositoryInterface;
use Magento\Eav\Api\AttributeSetManagementInterface;
use Magento\Eav\Api\Data\AttributeSetInterfaceFactory;
use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Eav\Api\Data\AttributeSetInterface;
use Magento\Framework\Api\Filter;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Maas\ImportExport\Model\Service\CreateProductAttribute;

/**
 * Class CreateAttributeSet
 * @package Maas\ImportExport\Model\Service
 */
class CreateAttributeSet extends BuilderCreator
{
    private AttributeSetInterfaceFactory $attributeSetFactory;
    private AttributeSetManagementInterface $attributeSetManagement;
    private AttributeSetRepositoryInterface $attributeSetRepository;
    private AttributeSetInfoFactory $attributeSetInfoFactory;
    private ProductAttributeGroupRepositoryInterface $productAttributeGroupRepository;

    /**
     * CreateAttributeSet constructor.
     *
     * @param FilterBuilder $filterBuilder
     * @param FilterGroupBuilder $filterGroupBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param AttributeSetInterfaceFactory $attributeSetFactory
     * @param AttributeSetManagementInterface $attributeSetManagement
     * @param AttributeSetRepositoryInterface $attributeSetRepository
     * @param AttributeSetInfoFactory $attributeSetInfoFactory
     * @param ProductAttributeGroupRepositoryInterface $productAttributeGroupRepository
     */
    public function __construct(
        FilterBuilder $filterBuilder,
        FilterGroupBuilder $filterGroupBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        AttributeSetInterfaceFactory $attributeSetFactory,
        AttributeSetManagementInterface $attributeSetManagement,
        AttributeSetRepositoryInterface $attributeSetRepository,
        AttributeSetInfoFactory $attributeSetInfoFactory,
        ProductAttributeGroupRepositoryInterface $productAttributeGroupRepository
    ) {
        $this->attributeSetFactory = $attributeSetFactory;
        $this->attributeSetManagement = $attributeSetManagement;
        $this->attributeSetRepository = $attributeSetRepository;
        $this->attributeSetInfoFactory = $attributeSetInfoFactory;
        $this->productAttributeGroupRepository = $productAttributeGroupRepository;
        parent::__construct($filterBuilder, $filterGroupBuilder, $searchCriteriaBuilder);
    }

    /**
     * Create or Get Attribute Set
     *
     * @param CategoryInterface $item
     * @return AttributeSetInterface
     * @throws InputException
     * @throws NoSuchEntityException|LocalizedException
     */
    public function createOrGetAttributeSet(CategoryInterface $item): AttributeSetInterface
    {
        try {
            $attributeSet = $this->getAttributeSetByCategoryMaas($item->getCategoryId());
            if (!$attributeSet) {
                $attributeDefaultMaas = $this->getAttributeSetByName('Maas');
                $attributeDefaultMaasId = $attributeDefaultMaas->getId();
                /** @var  AttributeSetInterface $attributeSet */
                $attributeSet = $this->attributeSetFactory->create();
                $attributeSet->setAttributeSetName('Maas ' . $item->getLabel())
                    ->setEntityTypeId($attributeDefaultMaas->getEntityTypeId());
                $this->setExtraInfoToAttributeSet($attributeSet, $item);
                $attributeSet = $this->attributeSetManagement->create(
                    ProductAttributeInterface::ENTITY_TYPE_CODE,
                    $attributeSet,
                    $attributeDefaultMaasId
                );
            }
        } catch (\Exception $e) {
            $attributeSet = $this->getAttributeSetByName('Maas ' . $item->getLabel());
            if ($attributeSet && $attributeSet->getId()) {
                $this->setExtraInfoToAttributeSet($attributeSet, $item);
                $this->attributeSetRepository->save($attributeSet);
            }
        }
        return $attributeSet;
    }

    /**
     * @param $attributeSet
     * @param $item
     * @return void
     */
    private function setExtraInfoToAttributeSet(& $attributeSet, $item)
    {
        $attributeSetExtensionAttributes = $attributeSet->getExtensionAttributes();
        //create the extra info
        $extraInfo = $this->attributeSetInfoFactory->create();
        $extraInfo->setMaasCategoryId($item->getCategoryId());
        $attributeSetExtensionAttributes->setData('extra_info', $extraInfo);
        $attributeSet->setExtensionAttributes($attributeSetExtensionAttributes);

    }

    /**
     * @param string $name
     * @return AttributeSetInterface|null
     */
    protected function getAttributeSetByName(string $name): ?AttributeSetInterface
    {
        return $this->getAttributeSetByFilterGroup($this->getFilter('attribute_set_name', $name));
    }

    /**
     * @param string $categoryMaasId
     * @return AttributeSetInterface|null
     */
    protected function getAttributeSetByCategoryMaas(string $categoryMaasId): ?AttributeSetInterface
    {
        return $this->getAttributeSetByFilterGroup($this->getFilter('maas_category_id', $categoryMaasId));
    }

    /**
     * @param Filter $filter
     * @return AttributeSetInterface|null
     */
    private function getAttributeSetByFilterGroup(Filter $filter): ?AttributeSetInterface
    {
        $filterGroup = $this->getFilterGroup([$filter]);
        $searchCriteriaAttributeSet = $this->getSearchCriteriaGroup([$filterGroup]);
        $attributeSets = $this->attributeSetRepository->getList($searchCriteriaAttributeSet)->getItems();
        if (empty($attributeSets)) {
            return null;
        }
        return array_shift($attributeSets);
    }


    /**
     * @param AttributeSetInterface $attributeSet
     * @return int
     */
    public function getAttributeGroupId(AttributeSetInterface $attributeSet): int
    {
        $filterAttributeSetIdMaas = $this->getFilter('attribute_set_id', $attributeSet->getId());
        $filterGroupCode = $this->getFilter('attribute_group_code', 'octopia');
        $filterGroupAttributeSetIdMaas = $this->getFilterGroup([$filterAttributeSetIdMaas]);
        $filterGroupGroupCode = $this->getFilterGroup([$filterGroupCode]);

        $searchCriteriaEavAttributeGroup = $this->getSearchCriteriaGroup([
            $filterGroupAttributeSetIdMaas,
            $filterGroupGroupCode
        ]);
        $attributeGroupItem = $this->productAttributeGroupRepository
            ->getList($searchCriteriaEavAttributeGroup)
            ->getItems();
        if (empty($attributeGroupItem)) {
            return 0;
        }
        return array_shift($attributeGroupItem)->getId();
    }
}
