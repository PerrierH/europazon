<?php

namespace Maas\ImportExport\Model;

use Maas\ImportExport\Api\Data\AbstractImportMessageInterface;

/**
 * Class ImportMessage
 *
 * @package Maas\ImportExport\Model
 */
class ImportMessage implements AbstractImportMessageInterface
{
    /**
     * @var int
     */
    protected $reportId;

    /**
     * @var array
     */
    protected $entities = [];

    /**
     * @inheritDoc
     */
    public function getReportId()
    {
        return $this->reportId;
    }

    /**
     * @inheritDoc
     */
    public function setReportId($reportId)
    {
        $this->reportId = $reportId;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getEntities()
    {
        return $this->entities;
    }

    /**
     * @inheritDoc
     */
    public function setEntities($entities)
    {
        $this->entities = $entities;
        return $this;
    }
}
