<?php

namespace Maas\ImportExport\Model;

/**
 * Class Registry
 *
 * @package Maas\ImportExport\Model
 */
class Registry
{
    /**
     * @var bool
     */
    protected $isImporting = false;

    /**
     * @return bool
     */
    public function isCurrentlyImporting()
    {
        return $this->isImporting;
    }

    /**
     * @param $isImporting
     *
     * @return $this
     */
    public function setCurrentlyImporting($isImporting)
    {
        $this->isImporting = $isImporting;
        return $this;
    }

}
