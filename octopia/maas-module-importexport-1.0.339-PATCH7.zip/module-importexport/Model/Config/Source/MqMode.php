<?php

namespace Maas\ImportExport\Model\Config\Source;

use Maas\Core\Model\Service\MessageQueue\Config;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class MqMode
 *
 * @package Maas\ImportExport\Model\Config\Source
 */
class MqMode implements ArrayInterface
{
    /**
     * @var Config
     */
    protected $configOptionsService;

    /** @var array */
    protected $options;

    /**
     * MqMode constructor.
     *
     * @param Config $configOptionsService
     */
    public function __construct(
        Config $configOptionsService
    ) {
        $this->configOptionsService = $configOptionsService;
        $this->options = null;
    }

    /**
     * @inheritDoc
     */
    public function toOptionArray()
    {
        if (is_null($this->options)) {
            $optionCodes = $this->configOptionsService->getBrokerCodes();
            $this->options = [];
            foreach ($optionCodes as $optionCode) {
                $this->options[] = [
                    'value' => $optionCode,
                    'label' => $this->getOptionLabel($optionCode)
                ];
            }
        }
        return $this->options;
    }

    /**
     * @param string $code
     *
     * @return string
     */
    protected function getOptionLabel($code)
    {
        switch ($code) {
            case 'db':
                return __('Database');
            case 'rabbitmq':
                return __('RabbitMQ');
            default:
                return __('Other: %1', $code);
        }
    }
}
