<?php

namespace Maas\ImportExport\Model\Config\Source;

use Magento\Framework\App\Config\Initial\Reader;
use Magento\Framework\DataObject;
use Magento\Framework\Option\ArrayInterface;
use Maas\ImportExport\Model\Config;
/**
 * Class Environment
 *
 * @package Maas\ImportExport\Model\Config\Source
 */
class Environment implements ArrayInterface
{
    /** @var array */
    private $devEnvironments = ['preprod', 'recette', 'mock'];

    /** @var Reader */
    private $initialConfigReader;

    /** @var Config */
    private $config;

    /**
     * Environment constructor.
     *
     * @param Reader $initialConfigReader
     * @param Config $config
     */
    public function __construct(
        Reader $initialConfigReader,
        Config $config
    )
    {
        $this->initialConfigReader = $initialConfigReader;
        $this->config = $config;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $initialData = new DataObject($this->initialConfigReader->read());

        $environments = [];
        $envs = $initialData->getData('data/default/maas_api');
        $envs = is_array($envs) ? array_keys($envs) : [];
        foreach ($envs as $env) {
            if (!$this->config->isDeveloperMode() && in_array($env, $this->devEnvironments) ) {
                continue;
            }
            $environments[$env] = __('env_' . $env);
        }

        return $environments;
    }
}
