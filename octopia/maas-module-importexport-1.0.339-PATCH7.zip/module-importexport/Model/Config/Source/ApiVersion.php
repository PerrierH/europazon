<?php

namespace Maas\ImportExport\Model\Config\Source;

use Maas\Core\Model\Service\MessageQueue\Config;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class ApiVersion
 *
 * @package Maas\ImportExport\Model\Config\Source
 */
class ApiVersion implements ArrayInterface
{
    /**
     * @var Config
     */
    protected $configOptionsService;

    /** @var array */
    protected $options = null;

    protected const VERSIONS = ['V1', 'V2', 'V3'];

    /**
     * @inheritDoc
     */
    public function toOptionArray()
    {
        if (is_null($this->options)) {
            $this->options = [];
            foreach (self::VERSIONS as $version) {
                $this->options[] = [
                    'value' => $version,
                    'label' => $version
                ];
            }
        }
        return $this->options;
    }
}
