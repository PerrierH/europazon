<?php

namespace Maas\ImportExport\Model;

use Exception;
use DateInterval;
use DateTime as PhpDateTime;
use InvalidArgumentException;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\ImportExport\Exception\EmptyResponse;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Csv;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Sales\Exception\UnknownStatus;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Zend_Http_Response;

abstract class AbstractImportExportApi extends AbstractApi
{
    const MODE_DISABLED = false;
    const MODE_DEFAULT = 'V1';
    const MODES = ['V1', 'V2', 'V3'];

    const FIRST_RUN_STATE_NOT_RUN = 0;
    const FIRST_RUN_STATE_RUNNING = 1;
    const FIRST_RUN_STATE_RUN = 2;

    /**
     * @var SerializerInterface
     */
    protected $serializer;
    /**
     * @var ReportFactory
     */
    protected $reportFactory;
    /**
     * @var ReportRepositoryInterface
     */
    protected $reportRepository;
    /**
     * @var Csv
     */
    protected $csvLogger;
    /**
     * @var CsvLoggerManagement
     */
    protected $csvLoggerManagement;
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;
    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var ReportCollectionFactory
     */
    protected $reportCollectionFactory;
    /**
     * @var ReportResource
     */
    protected $reportResource;

    /**
     * @var Report
     */
    protected $report;

    /**
     * @var AbstractImportAdapter[]
     */
    protected $adapters;

    /**
     * @var bool|string
     */
    protected $modeOverride;

    /**
     * @var string
     */
    protected $dependencyNotImportedErrorMessage = 'This process has been stopped due to required imports not having been executed beforehand. Importing dependencies instead.';

    /**
     * @var string
     */
    protected $dependencyImportingErrorMessage = 'This process has been stopped due to required imports currently being executed.';
    protected ReportManagementInterface $reportManagement;

    /**
     * AbstractImportExportApi constructor.
     *
     * @param ClientFactory $httpClientFactory
     * @param Config $configProvider
     * @param SerializerInterface $serializer
     * @param TokenRepository $tokenRepository
     * @param CacheInterface $cache
     * @param DateTime $dateTime
     * @param TokenFactory $tokenFactory
     * @param ErrorLogger $errorLogger
     * @param ReportFactory $reportFactory
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ReportResource $reportResource
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param array $adapters
     */
    public function __construct(
        ClientFactory $httpClientFactory,
        Config $configProvider,
        SerializerInterface $serializer,
        TokenRepository $tokenRepository,
        CacheInterface $cache,
        DateTime $dateTime,
        TokenFactory $tokenFactory,
        ErrorLogger $errorLogger,
        ReportFactory $reportFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        ReportCollectionFactory $reportCollectionFactory,
        ReportResource $reportResource,
        CsvLoggerManagement $csvLoggerManagement,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        array $adapters = []
    )
    {
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->reportFactory = $reportFactory;
        $this->reportResource = $reportResource;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->reportCollectionFactory = $reportCollectionFactory;
        $this->csvLoggerManagement = $csvLoggerManagement;
        $this->csvLogger = null;
        $this->adapters = $adapters;

        parent::__construct($httpClientFactory, $configProvider, $serializer, $tokenRepository, $cache, $dateTime,
            $tokenFactory, $errorLogger);

        $this->modeOverride = false;
    }


    /**
     * @return ReportInterface|null
     */
    public function loadReportFromCache()
    {
        try {
            return $this->reportRepository->get($this->loadReportIdFromCache());
        } catch (NoSuchEntityException $nsee) {
        }
        return null;
    }

    /**
     * @return int|null
     */
    public function loadReportIdFromCache()
    {
        $reportId = $this->cache->load(static::CACHE_KEY_MAAS_REPORT_ID);
        return $reportId ?? null;
    }

    public function getReportIdKey() : string
    {
        return static::CACHE_KEY_MAAS_REPORT_ID;
    }


    /**
     * @param array|null $args
     * @param bool|bool $echo
     *
     * @return array
     */
    public function execute(array $args = null, bool $echo = true)
    {
        if (!$this->getMode()) {
            return [];
        }
        if (!$this->report) {
            $this->startProcess($args);
        }

        /* Execute CLI */
        $result = $this->doExecute($args);

        /* End Log Maas */
        $this->endLog($result);

        return $result;
    }

    /**
     * If the API URL has ann explicit "v2", consider it a V2 API.
     * If the API URL is empty, the API is disabled.
     *
     * @return string|bool
     */
    public function getMode()
    {
        if ($this->modeOverride) {
            $selectedMode = $this->modeOverride;
        } else {
            $api = trim($this->getApiUrl());
            if (!$api) {
                $selectedMode = self::MODE_DISABLED;
            } else {
                $selectedMode = $this->configProvider->getApiVersion();
            }
        }
        if (in_array($selectedMode, self::MODES)) {
            return $selectedMode;
        }
        return self::MODE_DEFAULT;

    }

    /**
     * @return string
     */
    abstract public function getApiUrl();

    /**
     * @throws Exception
     */
    public function startProcess(array $args = null): Report
    {
        /* Empecher l'execution simultanee de la meme commande CLI */
        $isCommandLaunched = $this->checkIfCommandLaunched(
            static::MAAS_LOG_MODULE,
            static::MAAS_LOG_ACTION,
            Report::STATUS_STARTED
        );
        if ($isCommandLaunched) {
            /** @var ReportInterface $report */
            $report = $isCommandLaunched;
            /* check if job timeout exceeded */
            if ($this->isJobTimeoutExceeded($report)) {
                $report->setMessage("Job timeout exceeded");
                $this->reportManagement->close($report);
            } elseif ($report->isJobOver()) {
                $this->reportManagement->close($report);
            } else {
                throw new AlreadyExistsException(__('%1 operation is already launched', static::MAAS_LOG_ACTION));
            }
        }
        /* Init Maas Log */
        $this->report = $this->initLog($args);
        /* Save Report ID in cache */
        $this->saveReportIdInCache($this->report->getId());
        return $this->report;
    }

    /**
     * @param $module
     * @param $action
     * @param $status
     * @return bool
     */
    protected function checkIfCommandLaunched($module, $action, $status)
    {
        $collection = $this->reportCollectionFactory->create();
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', $status)
            ->setPageSize(1);
        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }

        return false;
    }

    /**
     * Check if Import Job Timout expired
     * @param Report $report
     * @return bool
     * @throws Exception
     */
    protected function isJobTimeoutExceeded(Report $report)
    {
        $jobTimeout = $this->configProvider->getJobTimeout();
        if (is_null($jobTimeout)) {
            return false;
        }
        $reportUpdatedAt = new PhpDatetime($report->getData('updated_at'));
        $reportUpdatedAt->add(new DateInterval('PT' . $jobTimeout . 'M'));
        $dateNow = new PhpDatetime('NOW');
        return $reportUpdatedAt < $dateNow;
    }

    /**
     * @param array|null $args
     * @param bool $echo
     *
     * @return Report
     */
    protected function initLog(array $args = null, bool $echo = true)
    {
        /** @var Report $newReport */
        $newReport = $this->reportFactory->create();
        $newReport->setEcho($echo);
        if (($args != null) && array_key_exists('scheduleId', $args)) {
            $newReport->setScheduleId($args['scheduleId']);
        }

        return $this->reportRepository->generateLogReport(
            $newReport,
            static::MAAS_LOG_MODULE,
            static::MAAS_LOG_ACTION,
            static::MAAS_LOG_OPERATION_TYPE
        );
    }

    /**
     * @param int $reportId
     *
     * @codeCoverageIgnore
     */
    public function saveReportIdInCache(int $reportId)
    {
        $this->cache->save($reportId, static::CACHE_KEY_MAAS_REPORT_ID);
    }

    /**
     * function doExecute
     *
     * @param array|null $args
     *
     * @return array
     * @throws UnknownStatus|EmptyResponse
     */
    protected function doExecute(array $args = null)
    {
        return $this->getApiResponse($args);
    }

    /**
     * @param array|null $args
     *
     * @return array|bool|float|int|string|null
     * @throws UnknownStatus
     * @throws EmptyResponse
     */
    public function getApiResponse(array $args = null)
    {
        $this->setArgs($args);
        $result = $this->apiCall();
        if ($result['status'] >= 400) {
            // if 401 => Unauthorized
            if ($result['status'] == 401) {
                $result = $this->retryApiCall();
            } else {
                throw new UnknownStatus(sprintf('Url:%s - Error message:%s', $result['uri'], $result['response']));
            }
        }
        if (!isset($result['response']) && $result['response'] == '') {
            throw new EmptyResponse(__('Url:%1 - Error the response is empty', $result['uri']));
        }
        try {
            $response = $this->serializer->unserialize($result['response']);
        } catch (InvalidArgumentException $invalidArgumentException) {
            // if the status is 200, yet the body can't be unserialized, it's probably a correctly executed HEAD request
            $response = [];
        }
        if (isset($result['.additional'])) {
            $response['.additional'] = $result['.additional'];
        }
        return $response;
    }

    /**
     * function apiCall to process the Api calls
     *
     * @return null[]|string[]
     */
    public function apiCall()
    {
        $adapter = $this->getAdapter();
        if ($adapter) {
            $response = $adapter->doRequest($this);
        } else {
            $response = $this->doRequest($this->getEndPointUrl(), $this->getMethod(), $this->getHeaders(),
                $this->getBody(),
                $this->getPostsParams());
        }
        return $response;
    }

    /**
     * @return AbstractImportAdapter|null
     */
    protected function getAdapter()
    {
        $mode = $this->getMode();
        if (!$mode) {
            return null;
        }
        if (isset($this->adapters[$mode])) {
            $this->adapters[$mode]->setReportId($this->loadReportIdFromCache() ?: 0);
            return $this->adapters[$mode];
        }
        return null;
    }

    /**
     * @return string
     */
    public function getEndPointUrl()
    {
        $url = rtrim($this->getApiUrl(), '/') . static::API_REQUEST_ENDPOINT;
        return is_array($this->getArgs()) && sizeof($this->getArgs()) ? $url . '?' . http_build_query($this->getArgs()) : $url;
    }

    /**
     * @return null[]|string[]
     */
    private function retryApiCall()
    {
        $this->connect();
        $this->setHeaders([]);
        return $this->apiCall();
    }

    /**
     * @param array $result
     */
    protected function endLog(array $result)
    {
        $itemCount = array_key_exists('itemsCount', $result) ? $result['itemsCount'] : 0;
        $this->report->setItemsCount($itemCount);
        $successItemsCount = array_key_exists('successItemsCount', $result) ? $result['successItemsCount'] : 0;
        $this->report->setSuccessItemsCount($successItemsCount);
        $warningItemsCount = array_key_exists('warningItemsCount', $result) ? $result['warningItemsCount'] : 0;
        $this->report->setWarningItemsCount($warningItemsCount);
        $errorItemsCount = array_key_exists('errorItemsCount', $result) ? $result['errorItemsCount'] : 0;
        $this->report->setErrorItemsCount($errorItemsCount);
        $message = array_key_exists('message', $result) ? $result['message'] : '';
        $this->report->setMessage($message);
        $this->reportRepository->close($this->report);
    }

    /**
     * @param int $reportId
     *
     * @return Csv
     */
    public function getCsvLogger($reportId)
    {
        if (is_null($this->csvLogger)) {
            $this->csvLogger = $this->csvLoggerManagement->getCsvLogger(
                $reportId,
                static::CSV_LOG_HEADERS,
                static::MAAS_LOG_MODULE,
                static::MAAS_LOG_ACTION,
                static::CSV_LOG_FILE_PREFIX
            );
        }
        return $this->csvLogger;
    }

    /**
     *
     * @return DataObject|bool
     */
    public function getStartedImportReportObject()
    {
        return $this->reportCollectionFactory->create()
            ->addFieldToFilter('module', static::MAAS_LOG_MODULE)
            ->addFieldToFilter('action', static::MAAS_LOG_ACTION)
            ->addFieldToFilter('status', Report::STATUS_STARTED)
            ->getFirstItem();
    }

    /**
     * @param bool|string $modeOverride
     *
     * @return $this
     */
    public function setModeOverride($modeOverride)
    {
        $this->modeOverride = $modeOverride;
        return $this;
    }

    public function getTotalItemsCount()
    {
        if (!$this->getMode()) {
            return 0;
        }
        $adapter = $this->getAdapter();
        if ($adapter) {
            return $adapter->getTotalItemsCount($this);
        }
        $result = $this->getApiResponse(['limit' => 1]);
        return $result['totalItemCount'];
    }

    /**
     * @return int
     * @throws LocalizedException
     */
    public function getFirstRunState()
    {
        if ($this->reportResource->getFirstRunHasExecuted(
            static::MAAS_LOG_MODULE, static::MAAS_LOG_ACTION, static::MAAS_LOG_OPERATION_TYPE
        )) {
            return self::FIRST_RUN_STATE_RUN;
        } else {
            if ($this->reportResource->getFirstRunIsExecuting(
                static::MAAS_LOG_MODULE, static::MAAS_LOG_ACTION, static::MAAS_LOG_OPERATION_TYPE
            )) {
                return self::FIRST_RUN_STATE_RUNNING;
            } else {
                return self::FIRST_RUN_STATE_NOT_RUN;
            }
        }
    }

    /**
     * @param int $state
     * @param int|null $scheduleId
     *
     * @return string|null
     */
    public function getFirstRunErrorMessage($state, $scheduleId = null)
    {
        $message = null;
        if ($state == self::FIRST_RUN_STATE_NOT_RUN) {
            $message = $this->dependencyNotImportedErrorMessage;
        } else {
            if ($state == self::FIRST_RUN_STATE_RUNNING) {
                $message = $this->dependencyImportingErrorMessage;
            }
        }
        if (!is_null($message)) {
            $this->createAbortedReport($message, $scheduleId);
        }
        return $message;
    }

    /**
     * @param string $message
     * @param int|null $scheduleId
     */
    protected function createAbortedReport($message, $scheduleId)
    {
        $newAbortedReport = $this->reportFactory->create();
        /** @var Report $newAbortedReport */
        $newAbortedReport->setModule(static::MAAS_LOG_MODULE);
        $newAbortedReport->setAction(static::MAAS_LOG_ACTION);
        $newAbortedReport->setOperationType(static::MAAS_LOG_OPERATION_TYPE);
        $newAbortedReport->setStatus(Report::STATUS_ABORTED);
        $newAbortedReport->setScheduleId($scheduleId);
        $newAbortedReport->setMessage($message);
        $newAbortedReport->setCurrentDateAsStartedAt()->setCurrentDateAsEndedAt();
        $this->reportRepository->save($newAbortedReport);
    }

    /**
     * @return Report
     */
    protected function getLastReport()
    {
        $collection = $this->reportCollectionFactory->create()
            ->addOrder('updated_at')
            ->addFieldToFilter('status', 'success')
            ->addFieldtoFilter('action', static::MAAS_LOG_ACTION)
            ->addFieldToFilter('module', static::MAAS_LOG_MODULE)
            ->setPageSize(1);
        return $collection->getFirstItem();
    }

    /**
     * @param Zend_Http_Response $result
     * @param $response
     *
     * @return array|null
     */
    protected function getAdditionalInfo(Zend_Http_Response $result)
    {
        $adapter = $this->getAdapter();
        if ($adapter) {
            return $adapter->getAdditionalInfo($this, $result);
        }
        return null;
    }

    /**
     * Deduplicate and format error messages before display
     *
     * @param array $errorMessages
     * @return string
     */
    protected function formatErrorMessages($errorMessages)
    {
        return empty($errorMessages) ? '' : implode("<br />", array_unique($errorMessages));
    }

}
