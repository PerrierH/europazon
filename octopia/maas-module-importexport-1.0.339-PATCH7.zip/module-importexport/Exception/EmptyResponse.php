<?php

namespace Maas\ImportExport\Exception;

use Magento\Framework\Exception\LocalizedException;

class EmptyResponse extends LocalizedException
{

}
