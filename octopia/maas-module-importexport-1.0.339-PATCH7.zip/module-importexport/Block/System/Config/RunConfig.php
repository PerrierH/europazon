<?php

namespace Maas\ImportExport\Block\System\Config;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

/**
 * Class RunConfig
 *
 * @package Maas\ImportExport\Block\System\Config
 * there is no logic inside and all out put will be mocked
 * @codeCoverageIgnore
 */
class RunConfig extends Field
{
    /**
     * @var string
     */
    protected $_template = 'Maas_ImportExport::system/config/run_config.phtml';

    /**
     * @return string
     */
    public function getAjaxUrl()
    {
        return $this->getUrl('maas_import_export/system_config/runConfig', ['form_key' => $this->getFormKey()]);
    }

    /**
     * Generate synchronize button html
     *
     * @return string
     */
    public function getButtonHtml()
    {
        $button = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        )->setData(
            [
                'id' => 'run-test',
                'label' => __('Test Configuration'),
                'class' => 'primary'
            ]
        );

        return $button->toHtml();
    }

    /**
     * @param AbstractElement $element
     *
     * @return string
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    protected function _getElementHtml(AbstractElement $element)
    {
        return $this->_toHtml();
    }
}
