<?php

namespace Maas\ImportExport\Block\Adminhtml\Order\View\Tab;

use Maas\Sales\Model\Service\OrderType;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Sales\Model\Order;

/**
 * Class ExportPreview
 * @package Maas\ImportExport\Block\Adminhtml\Order\View\Tab
 */
class ExportPreview extends \Magento\Backend\Block\Template implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Template
     *
     * @var string
     */
    protected $_template = 'Maas_ImportExport::order/view/tab/export_preview.phtml';

    /**
     * Core registry
     *
     * @var ?Registry
     */
    protected ?Registry $coreRegistry = null;

    /**
     * @var \Maas\ImportExport\Model\Export\Order
     */
    private \Maas\ImportExport\Model\Export\Order $exportOrder;

    /**
     * @var OrderType
     */
    private OrderType $orderTypeService;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param \Maas\ImportExport\Model\Export\Order $exportOrder
     * @param OrderType $orderTypeService
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        \Maas\ImportExport\Model\Export\Order $exportOrder,
        OrderType $orderTypeService,
        array $data = []
    ) {
        $this->coreRegistry = $registry;
        $this->exportOrder = $exportOrder;
        $this->orderTypeService = $orderTypeService;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve order model instance
     *
     * @return Order
     */
    public function getOrder()
    {
        return $this->coreRegistry->registry('current_order');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Octopia preview of order export');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Octopia preview of order export');
    }

    /**
     * @return false|string
     */
    public function exportOrder()
    {
        $order = $this->getOrder();
        try {
            $orderData = $this->exportOrder->exportOrderToJson($order);
            return json_encode($orderData, JSON_PRETTY_PRINT);
        } catch (\Exception $e) {
            $this->_logger->critical($e);
            return $e->getMessage();
        }
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return $this->orderTypeService->isOrderMarketplace($this->getOrder());;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
}
