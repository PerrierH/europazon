<?php

namespace Maas\ImportExport\Plugin;

use Closure;
use Magento\Framework\App\DeploymentConfig;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Rcason\MqAmqp\Setup\Recurring;

/**
 * Class PreventAmqpModuleFromCrashingUpdate
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Plugin
 */
class PreventAmqpModuleFromCrashingUpdate
{
    /** @var DeploymentConfig */
    protected $deploymentConfig;

    /**
     * PreventAmqpModuleFromCrashingUpdate constructor.
     *
     * @param DeploymentConfig $deploymentConfig
     */
    public function __construct(
        DeploymentConfig $deploymentConfig
    ) {
        $this->deploymentConfig = $deploymentConfig;
    }

    /**
     * @param Recurring $subject
     * @param Closure $proceed
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function aroundInstall(
        Recurring $subject,
        Closure $proceed,
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        if ($this->deploymentConfig->get('ce_mq/amqp')) {
            $proceed($setup, $context);
        }
    }
}
