<?php

namespace Maas\ImportExport\Plugin\Model\ResourceModel\Import;

use Maas\ImportExport\Model\ResourceModel\Import;
use Magento\Framework\Exception\LocalizedException;
use Magento\ImportExport\Model\ResourceModel\Import\Data as MagentoData;

/**
 * Class Data
 *
 * @package Maas\ImportExport\Plugin\Model\ResourceModel\Import
 * @codeCoverageIgnore
 */
class Data
{
    /**
     * @var Import
     */
    private $import;

    /**
     * AbstractEntity constructor.
     *
     * @param Import $import
     */
    public function __construct(
        Import $import
    )
    {
        $this->import = $import;
    }


    /**
     * @param MagentoData $subject
     * @param callable $proceed
     * @throws LocalizedException
     */
    public function aroundCleanBunches(MagentoData $subject, callable $proceed)
    {
        try {
            $this->import->cleanTableImportExportImportData($subject->getEntityTypeCode());
        }catch (LocalizedException $e){
            //Do nothing
        }
    }
}
