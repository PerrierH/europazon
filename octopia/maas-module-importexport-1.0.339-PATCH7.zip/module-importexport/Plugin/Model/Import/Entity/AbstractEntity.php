<?php

namespace Maas\ImportExport\Plugin\Model\Import\Entity;

use Maas\ImportExport\Model\ResourceModel\Import;
use Magento\Framework\Exception\LocalizedException;
use Magento\ImportExport\Model\Import\Entity\AbstractEntity as MagentoAbstractEntity;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class AbstractEntity
 *
 * @package Maas\ImportExport\Plugin\Model\Import\Entity
 * @codeCoverageIgnore
 */
class AbstractEntity
{
    /**
     * @var Import
     */
    private $import;


    /**
     * @var EditionInterface
     */
    public $edition;

    /**
     * AbstractEntity constructor.
     *
     * @param Import $import
     * @param EditionInterface $edition
     */
    public function __construct(
        Import           $import,
        EditionInterface $edition

    )
    {
        $this->import = $import;
        $this->edition = $edition;
    }

    /**
     * @param MagentoAbstractEntity $subject
     *
     * @throws LocalizedException
     */
    public function afterImportData(MagentoAbstractEntity $subject)
    {
        try {
            $this->import->cleanTableImportExportImportData($subject->getEntityTypeCode());
        } catch (LocalizedException $e) {
            //Do nothing
        }
    }
}
