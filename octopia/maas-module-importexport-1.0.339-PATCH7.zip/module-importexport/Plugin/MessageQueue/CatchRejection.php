<?php

namespace Maas\ImportExport\Plugin\MessageQueue;

use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\Import\Catalog\Product as ProductImport;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Report;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\MessageQueue\EnvelopeInterface;
use Magento\Framework\MessageQueue\QueueInterface;
use Magento\MysqlMq\Model\QueueManagement;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;

class CatchRejection
{
    private ReportCollectionFactory $reportCollectionFactory;
    private ReportRepositoryInterface $reportRepository;
    protected ReportManagementInterface $reportManagement;
    protected ReportResource $reportResource;
    private CacheInterface $cache;
    private int $reportId = 0;
    private ?ReportInterface $report = null;

    public function __construct(
        ReportCollectionFactory $reportCollectionFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        ReportResource $reportResource,
        CacheInterface $cache
    ) {
        $this->reportCollectionFactory = $reportCollectionFactory;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->reportResource = $reportResource;
        $this->cache = $cache;
    }

    /**
     * Catch error after rejection to set in the report import
     */
    public function afterReject(
        QueueInterface $subject,
        $result,
        EnvelopeInterface $envelope,
        bool $requeue = true,
        ?string $rejectionMessage = null
    ) {
        $properties = $envelope->getProperties();
        if ($properties[QueueManagement::MESSAGE_NUMBER_OF_TRIALS] >= 3 || !$requeue) {
            if ($this->report) {
                if ($this->reportId == 0) {
                    $this->report = $this->getStartedImportReportObject(
                        ProductImport::MAAS_LOG_MODULE,
                        ProductImport::MAAS_LOG_ACTION
                    );
                    $this->reportId = $this->report->getId();
                } elseif ($this->reportId > 0) {
                    try {
                        $this->report = $this->reportRepository->get($this->reportId);
                    } catch (\Exception $e) {
                        //Do nothing
                    }
                }
            }
            if ($this->report) {
                if ($rejectionMessage) {
                    $this->report->warning($rejectionMessage);
                }
                $body = json_decode($envelope->getBody() ?? '');
                if ($body->entities) {
                    $this->report->setDeltaWarningItemsCount(count($body->entities));
                    $this->reportRepository->save($this->report);
                }
                // Update Report Status when all messages are consumed
                if ($this->report->isJobOver()) {
                    $this->reportManagement->close($this->report);
                    /** Clean cache */
                    $this->cache->remove(ProductImport::CACHE_KEY_MAAS_REPORT_ID);
                    $this->clearCacheOnJobOver();
                }
            }
        }
    }

    /**
     * Get the started report
     */
    protected function getStartedImportReportObject(
        string $module,
        string $action,
        string $status = Report::STATUS_STARTED
    ): ?ReportInterface {
        $collection = $this->reportCollectionFactory->create();
        $collection->addFieldToFilter('module', $module)
            ->addFieldToFilter('action', $action)
            ->addFieldToFilter('status', $status)
            ->setPageSize(1);
        if ($collection->getSize()) {
            return $collection->getFirstItem();
        }
        return null;
    }

    /**
     * Clear report cache on job over
     */
    protected function clearCacheOnJobOver()
    {
        $this->cache->clean([
            sprintf(AbstractImportExportApi::CACHE_TAG_IMPORTEXPORT_BY_REPORT, $this->report->getId())
        ]);
    }
}
