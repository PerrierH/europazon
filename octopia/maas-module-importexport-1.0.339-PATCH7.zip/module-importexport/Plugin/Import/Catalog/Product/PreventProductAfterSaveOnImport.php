<?php

namespace Maas\ImportExport\Plugin\Import\Catalog\Product;

use Closure;
use Maas\ImportExport\Model\Registry;
use Magento\Catalog\Model\Product;

/**
 * Class PreventProductAfterSaveOnImport
 *
 * @package Maas\ImportExport\Plugin\Import\Catalog\Product
 */
class PreventProductAfterSaveOnImport
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * PreventProductAfterSaveOnImport constructor.
     *
     * @param Registry $registry
     */
    public function __construct(
        Registry $registry
    ) {
        $this->registry = $registry;
    }

    /**
     * @param Product $product
     * @param Closure $proceed
     *
     * @return Product|mixed
     */
    public function aroundAfterSave(Product $product, Closure $proceed)
    {
        if (!$this->registry->isCurrentlyImporting()) {
            return $proceed();
        } else {
            return $product;
        }
    }
}
