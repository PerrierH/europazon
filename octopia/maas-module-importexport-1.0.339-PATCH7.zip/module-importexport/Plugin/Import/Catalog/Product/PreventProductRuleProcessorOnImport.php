<?php

namespace Maas\ImportExport\Plugin\Import\Catalog\Product;

use Closure;
use Maas\ImportExport\Model\Registry;
use Magento\CatalogRule\Model\Indexer\Product\ProductRuleProcessor;

/**
 * Class PreventProductRuleProcessorOnImport
 * @codeCoverageIgnore
 * @package Maas\ImportExport\Plugin\Import\Catalog\Product
 */
class PreventProductRuleProcessorOnImport
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * PreventProductRuleProcessorOnImport constructor.
     *
     * @param Registry $registry
     */
    public function __construct(
        Registry $registry
    ) {
        $this->registry = $registry;
    }

    /**
     * @param ProductRuleProcessor $subject
     * @param Closure $proceed
     * @param int $id
     * @param bool $forceReindex
     */
    public function aroundReindexRow(
        ProductRuleProcessor $subject,
        Closure $proceed,
        $id,
        $forceReindex = false
    ) {
        if (!$this->registry->isCurrentlyImporting()) {
            $proceed($id, $forceReindex);
        }
    }
}
