<?php

namespace Maas\ImportExport\Plugin\Import\Catalog\Product;

use Magento\CatalogImportExport\Model\Import\Proxy\Product\ResourceModelFactory;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class AddWhereToCategoryProductUnset
 *
 * @package Maas\ImportExport\Plugin\Import\Catalog\Product
 */
class AddWhereToCategoryProductUnset
{
    protected $inSelect = null;

    /**
     * @var CollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var ResourceModelFactory
     */
    protected $resourceFactory;

    /**
     * @var null
     */
    protected $resource = null;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * @param CollectionFactory $categoryCollectionFactory
     * @param ResourceModelFactory $resourceFactory
     * @param EditionInterface $edition
     */
    public function __construct(
        CollectionFactory    $categoryCollectionFactory,
        ResourceModelFactory $resourceFactory,
        EditionInterface     $edition
    )
    {
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->resourceFactory = $resourceFactory;
        $this->edition = $edition;
        $this->resource = null;
        $this->inSelect = null;
    }

    protected function getSelectToAdd()
    {
        if (is_null($this->inSelect)) {
            $linkField = $this->edition->getLinkField();
            /** @var \Magento\Catalog\Model\ResourceModel\Category\Collection $collection */
            $collection = $this->categoryCollectionFactory->create();
            $collection->addAttributeToSelect($linkField);
            $collection->addAttributeToFilter('maas_is_maas_category', 1);
            $collection->load();
            $this->inSelect = $collection->getSelect();
            $this->inSelect->reset(\Zend_Db_Select::COLUMNS);
            $this->inSelect->columns($linkField);
        }
        return $this->inSelect;
    }

    protected function getResource()
    {
        if (is_null($this->resource)) {
            $this->resource = $this->resourceFactory->create();
        }
        return $this->resource;
    }

    /**
     * To overload with a plugin, because of constructors
     *
     * @param int[] $delProductId
     *
     * @return string
     */
    public function afterGetWhereForCategoryProductDeletion(\Maas\Core\Model\Import\Product $subject, $result, $delProductId)
    {
        return $result . ' AND ' . $this->getResource()->getConnection()->quoteInto('category_id in (?)', $this->getSelectToAdd());
    }
}
