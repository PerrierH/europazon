<?php

namespace Maas\Catalog\Api;

use Maas\Catalog\Api\Data\MediaGalleryInfoInterface;
use Maas\Catalog\Api\Data\MediaGalleryInfoSearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Interface MediaGalleryInfoRepositoryInterface
 *
 * @package Maas\Catalog\Api
 */
interface MediaGalleryInfoRepositoryInterface
{

    /**
     * @param MediaGalleryInterface $mediaGalleryInfo
     *
     * @return MediaGalleryInfoInterface
     */
    public function save(MediaGalleryInfoInterface $mediaGalleryInfo);

    /**
     * @param int $id
     *
     * @return MediaGalleryInfoInterface
     */
    public function get($id);

    /**
     * @param MediaGalleryInfoInterface $mediaGalleryInfo
     */
    public function delete(MediaGalleryInfoInterface $mediaGalleryInfo);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return MediaGalleryInfoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
