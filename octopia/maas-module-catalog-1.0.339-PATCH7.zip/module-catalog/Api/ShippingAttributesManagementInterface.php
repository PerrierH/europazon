<?php

namespace Maas\Catalog\Api;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Magento\Catalog\Api\Data\ProductInterface;

/**
 * Interface ShippingMethodManagementInterface
 *
 * @package Maas\Catalog\Api
 */
interface ShippingAttributesManagementInterface
{
    /**
     * @param ProductInterface $product
     * @param string $scopeCode
     * @param string $currency
     * @param bool $asArrays
     * @param float $qty
     * @param bool $includeNameInEstimate
     *
     * @return ShippingMethodInterface[]
     */
    public function getShippingMethodsFromEntity(
        ProductInterface $product,
        $scopeCode = null,
        $currency = null,
        $asArrays = false,
        $qty = null,
        $includeNameInEstimate = false
    );

    /**
     * The return type is an array to handle cases where no entity can be returned in API.
     *
     * @param ProductInterface $product
     * @param string $scopeCode
     * @param string $currency
     * @param float $qty
     * @param bool $includeNameInEstimate
     *
     * @return ShippingMethodInterface[]
     */
    public function formatShippingMethodAndDeliveries(
        ProductInterface $product,
        $scopeCode = null,
        $currency = null,
        $qty = null,
        $includeNameInEstimate = true
    );
}
