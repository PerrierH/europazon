<?php

namespace Maas\Catalog\Api\Data;


/**
 * Interface MediaGalleryInfoInterface
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Api\Data
 */
interface MediaGalleryInfoInterface
{
    /**
     * @return int
     */
    public function getValueId();

    /**
     * @param int $value_id
     *
     * @return $this
     */
    public function setValueId(int $value_id);

    /**
     * @return string
     */
    public function getImageUrl();

    /**
     * @param string|null $image_url
     * @return $this
     */
    public function setImageUrl($image_url);
}
