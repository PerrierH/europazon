<?php

namespace Maas\Catalog\Api\Data;

use Magento\Framework\Model\AbstractModel;

/**
 * Interface ShippingMethodInterface
 *
 * @package Maas\Catalog\Api\Data
 */
interface ShippingMethodInterface
{
    const CODE = 'code';
    const LABEL = 'label';
    const AMOUNT = 'amount';
    const BASE_AMOUNT = 'base_amount';
    const AMOUNT_FOR_QTY = 'amount_for_qty';
    const BASE_AMOUNT_FOR_QTY = 'base_amount_for_qty';
    const MIN_DELAY = 'min_delay';
    const MAX_DELAY = 'max_delay';
    const PRODUCT_ID = 'product_id';
    const ESTIMATION = 'estimation';

    /**
     * @return int
     */
    public function getProductId();

    /**
     * @return string
     */
    public function getCode();

    /**
     * @return string
     */
    public function getLabel();

    /**
     * @return float
     */
    public function getAmount();

    /**
     * @return float
     */
    public function getBaseAmount();

    /**
     * @return float
     */
    public function getAmountForQty();

    /**
     * @return float
     */
    public function getBaseAmountForQty();

    /**
     * @return int
     */
    public function getMinDelay();

    /**
     * @return int
     */
    public function getMaxDelay();

    /**
     * @return string
     */
    public function getEstimation();

    /**
     * @param int $productId
     *
     * @return $this
     */
    public function setProductId($productId);

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setCode($code);

    /**
     * @param string $label
     *
     * @return $this
     */
    public function setLabel($label);

    /**
     * @param float $amount
     *
     * @return $this
     */
    public function setAmount($amount);

    /**
     * @param float $baseAmount
     *
     * @return $this
     */
    public function setBaseAmount($baseAmount);

    /**
     * @param float $amountForQty
     *
     * @return $this
     */
    public function setAmountForQty($amountForQty);

    /**
     * @param float $baseAmountForQty
     *
     * @return $this
     */
    public function setBaseAmountForQty($baseAmountForQty);

    /**
     * @param int $minDelay
     *
     * @return $this
     */
    public function setMinDelay($minDelay);

    /**
     * @param float $qty
     * @param string $scopeCode
     * @param AbstractModel|string|null $currency
     *
     * @return float
     */
    public function getCalculatedAmountForQuantity($qty, $scopeCode, $currency);

    /**
     * @param float $qty
     *
     * @return float
     */
    public function getCalculatedBaseAmountForQuantity($qty);

    /**
     * @param int $maxDelay
     *
     * @return $this
     */
    public function setMaxDelay($maxDelay);

    /**
     * @param string $estimation
     *
     * @return $this
     */
    public function setEstimation($estimation);
}
