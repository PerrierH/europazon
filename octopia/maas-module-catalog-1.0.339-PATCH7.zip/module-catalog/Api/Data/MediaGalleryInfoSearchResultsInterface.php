<?php

namespace Maas\Catalog\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface MediaGalleryInfoSearchResultsInterface
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Api\Data
 */
interface MediaGalleryInfoSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get infos list.
     *
     * @return MediaGalleryInfoInterface[]
     */
    public function getItems();

    /**
     * Set infos list.
     *
     * @param MediaGalleryInfoInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
