/**
 */

define([
    'jquery',
    'mage/translate'
], function ($) {
    'use strict';

    return function (widget) {

        $.widget('mage.configurable', widget, {
            options: {
                superSelector: '.super-attribute-select',
                selectSimpleProduct: '[name="selected_configurable_option"]',
                priceHolderSelector: '.price-box',
                spConfig: {},
                state: {},
                priceFormat: {},
                optionTemplate: '<%- data.label %>' +
                    '<% if (typeof data.finalPrice.value !== "undefined") { %>' +
                    ' <%- data.finalPrice.formatted %>' +
                    '<% } %>',
                mediaGallerySelector: '[data-gallery-role=gallery-placeholder]',
                mediaGalleryInitial: null,
                slyOldPriceSelector: '.sly-old-price',
                normalPriceLabelSelector: '.product-info-main .normal-price .price-label',

                /**
                 * Defines the mechanism of how images of a gallery should be
                 * updated when user switches between configurations of a product.
                 *
                 * As for now value of this option can be either 'replace' or 'prepend'.
                 *
                 * @type {String}
                 */
                gallerySwitchStrategy: 'replace',
                tierPriceTemplateSelector: '#tier-prices-template',
                tierPriceBlockSelector: '[data-role="tier-price-block"]',
                tierPriceTemplate: '',
                sellerNameSelector: '.product-info-main .maas-seller-name',
                sellerTemplate: '<div class="maas-seller-name">' +
                    '<h3>' +
                    '<a href="%2">' +
                    $.mage.__('Sold by %1') +
                    '</a>' +
                    '</h3>' +
                    '</div>',
                deliveryInfoSelector: '.product-info-main .product-info-delivery',
                deliveryTemplate: '<div class="maas-delivery-info">%1' +
                    '</div>',
            },

            /**
             * Configure an option, initializing it's state and enabling related options, which
             * populates the related option's selection and resets child option selections.
             * @private
             * @param {*} element - The element associated with a configurable option.
             */
            _configureElement: function (element) {
                this.simpleProduct = this._getSimpleProductId(element);

                if (element.value) {
                    this.options.state[element.config.id] = element.value;

                    if (element.nextSetting) {
                        element.nextSetting.disabled = false;
                        this._fillSelect(element.nextSetting);
                        this._resetChildren(element.nextSetting);
                    } else {
                        if (!!document.documentMode) { //eslint-disable-line
                            this.inputSimpleProduct.val(element.options[element.selectedIndex].config.allowedProducts[0]);
                        } else {
                            this.inputSimpleProduct.val(element.selectedOptions[0].config.allowedProducts[0]);
                        }
                    }
                } else {
                    this._resetChildren(element);
                }

                this._reloadPrice();
                this._displayRegularPriceBlock(this.simpleProduct);
                this._displayTierPriceBlock(this.simpleProduct);
                this._displayNormalPriceLabel();
                this._changeProductImage();
                this._changeProductSeller();
                this._changeProductDelivery();
            },
            /**
             * Change displayed product seller according to chosen options of configurable product
             *
             * @private
             */
            _changeProductSeller: function () {
                var html = '';
                var options = Object.values(this.options.state);
                //full options selection is mandatory
                if (options.every(element => element !== false)) {
                    html = this.simpleProduct !== undefined &&
                    this.options.spConfig.sellers[this.simpleProduct]['sellerName'] !== null ?
                        this.options.sellerTemplate.replace('%1',
                            this.options.spConfig.sellers[this.simpleProduct]['sellerName']).replace('%2',
                            this.options.spConfig.sellers[this.simpleProduct]['sellerUrl']) : '';
                }
                
                $(this.options.sellerNameSelector).html(html);
                
            },
            /**
             * Change displayed product delivery info according to chosen options of configurable product
             *
             * @private
             */
            _changeProductDelivery: function () {
                var html = '';
                var options = Object.values(this.options.state);
                //full options selection is mandatory
                if (options.every(element => element !== false)) {
                    html = this.simpleProduct !== undefined &&
                    this.options.spConfig.deliveries[this.simpleProduct]['deliveries'] !== null ?
                        this.options.deliveryTemplate.replace('%1',
                            this.options.spConfig.deliveries[this.simpleProduct]['deliveries']) : '';
                }

                $(this.options.deliveryInfoSelector).html(html);
            }
        });

        return $.mage.configurable;
    }
});