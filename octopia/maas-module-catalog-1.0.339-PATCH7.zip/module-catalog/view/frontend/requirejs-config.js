/**
 */

var config = {

    config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'Maas_Catalog/js/configurable-mixin': true
            }
        }
    }
};
