<?php

namespace Maas\Catalog\Plugin\Catalog\Block\View\Attributes;

use Maas\Catalog\Model\ResourceModel\Product;
use Maas\Catalog\Model\Service\AttributeCode;
use Magento\Catalog\Block\Product\View\Attributes;

/**
 * Class ShowAdditionalInformation
 *
 * @package Maas\Catalog\Plugin\Catalog\Block\View\Attributes
 */
class ShowAdditionalInformation
{
    /**
     * @var AttributeCode
     */
    private $attributeCode;

    /**
     * @var Product
     */
    private $productResource;

    /**
     * @param AttributeCode $attributeCode
     */
    public function __construct(
        AttributeCode $attributeCode,
        Product $productResource
    ) {
        $this->attributeCode = $attributeCode;
        $this->productResource = $productResource;
    }

    /**
     * @param Attributes $subject
     * @param array $result
     * @param array $excludeAttr
     *
     * @return array
     */
    public function afterGetAdditionalData(
        Attributes $subject,
        $result,
        array $excludeAttr = []
    ) {
        $product = $subject->getProduct();

        // using a resource to retrieve an attribute that is not usually visible on front
        $additional = $this->productResource->getAttributeRawValue($product->getId(), 'maas_additional_information',
            $product->getStoreId());

        if (!$additional) {
            return $result;
        }
        $additional = json_decode($additional ?? '', true);
        if (!$additional) {
            return $result;
        }
        foreach ($additional as $label => $value) {
            $code = $this->attributeCode->generate($label);
            $result[$code] = [
                'label' => $label,
                'value' => $value,
                'code' => $code
            ];
        }
        return $result;
    }
}