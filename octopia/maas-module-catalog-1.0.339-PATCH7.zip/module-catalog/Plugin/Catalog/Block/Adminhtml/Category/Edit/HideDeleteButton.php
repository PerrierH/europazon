<?php

namespace Maas\Catalog\Plugin\Catalog\Block\Adminhtml\Category\Edit;

use Magento\Catalog\Block\Adminhtml\Category\Edit\DeleteButton;
use Magento\Catalog\Model\Category;

/**
 * Class HideDeleteButton
 *
 * @package Maas\Catalog\Plugin\Catalog\Block\Adminhtml\Category\Edit
 */
class HideDeleteButton
{
    /**
     * @var Category
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $category;

    /**
     * @param DeleteButton $subject
     * @param $result
     * @return array
     */
    public function afterGetButtonData(DeleteButton $subject, $result)
    {
        $this->category = $subject->getCategory();
        if ($this->category->getMaasIsMaasCategory()) {
             return [];
        }
        return $result;
    }
}
