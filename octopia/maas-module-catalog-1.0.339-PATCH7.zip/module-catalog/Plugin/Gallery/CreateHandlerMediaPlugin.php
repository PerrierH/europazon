<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Maas\Catalog\Plugin\Gallery;

use Maas\Catalog\Api\MediaGalleryInfoRepositoryInterface;
use Maas\Catalog\Api\Data\MediaGalleryInfoInterface;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Gallery\CreateHandler as MagentoCreateHandler;

/**
 * Plugin for catalog product gallery create/update handlers.
 */
class CreateHandlerMediaPlugin
{
    /** @var MediaGalleryInfoRepositoryInterface */
    private $repository;

    /** @var array */
    private $imageToRemove = [];

    /**
     * CreateHandlerMediaPlugin constructor.
     *
     * @param MediaGalleryInfoRepositoryInterface $repository
     */
    public function __construct(
        MediaGalleryInfoRepositoryInterface $repository
    ) {
        $this->repository = $repository;
    }

    /**
     * Execute before Plugin
     *
     * @param MagentoCreateHandler $mediaGalleryCreateHandler
     * @param Product $product
     * @param array $arguments
     *
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function beforeExecute(
        MagentoCreateHandler $mediaGalleryCreateHandler,
        Product $product,
        array $arguments = []
    ) {
        $mediaGallery = $product->getMediaGallery();
        if (!empty($mediaGallery['images'])) {
            foreach ($mediaGallery['images'] as $media) {
                if (array_key_exists('removed', $media) && $media['removed'] !== null) {
                    $this->imageToRemove[$media['value_id']] = $media['value_id'];
                }
            }
        }
    }

    /**
     * Execute plugin
     *
     * @codeCoverageIgnore
     *
     * @param MagentoCreateHandler $mediaGalleryCreateHandler
     * @param Product $product
     *
     * @return Product
     */
    public function afterExecute(
        MagentoCreateHandler $mediaGalleryCreateHandler,
        Product $product
    ) {
        $mediaCollection = $product->getMediaGalleryEntries();
        if (!empty($mediaCollection)) {
            foreach ($mediaCollection as $media) {
                if (in_array($media->getId(), $this->imageToRemove)) {
                    continue;
                }
                /** @var MediaGalleryInfoInterface $info */
                $info = $media->getExtensionAttributes()->getMaasInfo();
                if ($info->getImageUrl() !== null) {
                    $this->repository->save($info);
                }
            }
        }
        return $product;
    }

    /**
     * @return array
     * @codeCoverageIgnore
     */
    public function getImageToRemove()
    {
        return $this->imageToRemove;
    }
}
