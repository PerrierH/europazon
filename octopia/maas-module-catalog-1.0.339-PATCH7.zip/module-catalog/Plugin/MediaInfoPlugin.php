<?php


namespace Maas\Catalog\Plugin;

use Magento\Catalog\Model\ResourceModel\Product\Gallery;
use Maas\Catalog\Model\ResourceModel\MediaGalleryInfo;
use Magento\Framework\DB\Select;

/**
 * Class MediaInfoPlugin
 *
 * @codeCoverageIgnore
 *
 * @package Maas\Catalog\Plugin
 */
class MediaInfoPlugin
{
    /**
     * @var MediaGalleryInfo
     */
    protected $mediaGalleryInfoResourceModel;

    /**
     * @param MediaGalleryInfo $mediaGalleryInfoResourceModel
     */
    public function __construct(MediaGalleryInfo $mediaGalleryInfoResourceModel)
    {
        $this->mediaGalleryInfoResourceModel = $mediaGalleryInfoResourceModel;
    }

    /**
     * Plugin for after duplicate action
     *
     * @param Gallery $originalResourceModel
     * @param array $valueIdMap
     *
     * @return array
     *
     */
    public function afterDuplicate(Gallery $originalResourceModel, array $valueIdMap)
    {
        $mediaGalleryEntitiesData = $this->mediaGalleryInfoResourceModel->loadByIds(array_keys($valueIdMap));
        foreach ($mediaGalleryEntitiesData as $row) {
            $row['value_id'] = $valueIdMap[$row['value_id']];
            $this->mediaGalleryInfoResourceModel->insertOnDuplicate($row);
        }

        return $valueIdMap;
    }

    /**
     * Plugin for after create batch base select action
     *
     * @param Gallery $originalResourceModel
     * @param Select $select
     *
     * @return Select
     */
    public function afterCreateBatchBaseSelect(Gallery $originalResourceModel, Select $select)
    {
        return $select->joinLeft(
            ['maas_info' => $originalResourceModel->getTable('maas_media_gallery_info')],
            implode(
                ' AND ',
                [
                    'value.value_id = maas_info.value_id',
                ]
            ),
            ['image_url' => 'maas_info.image_url']
        );
    }
}
