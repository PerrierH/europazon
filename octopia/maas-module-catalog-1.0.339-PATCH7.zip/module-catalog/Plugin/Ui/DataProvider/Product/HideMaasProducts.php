<?php

namespace Maas\Catalog\Plugin\Ui\DataProvider\Product;

use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Catalog\Ui\DataProvider\Product\ProductDataProvider;

/**
 * Class HideMaasProducts
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Plugin\Ui\DataProvider\Product
 */
class HideMaasProducts
{
    /**
     * @param ProductDataProvider $subject
     * @param Collection $result
     *
     * @return Collection
     */
    public function afterGetCollection(ProductDataProvider $subject, Collection $result)
    {

        if (!$result->isLoaded()) {
            $result->addAttributeToFilter(
                'maas_is_maas_product',
                [['neq' => '1'], ['null' => true]],
                'left'
            );
        }

        return $result;
    }


}