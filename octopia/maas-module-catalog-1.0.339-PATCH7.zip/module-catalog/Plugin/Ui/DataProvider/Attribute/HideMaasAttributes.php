<?php

namespace Maas\Catalog\Plugin\Ui\DataProvider\Attribute;

use Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection;
use Magento\ConfigurableProduct\Ui\DataProvider\Attributes;

/**
 * Class HideMaasAttributes
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Plugin\Ui\DataProvider\Attribute
 */
class HideMaasAttributes
{

    /**
     * @param Attributes $subject
     * @param Collection $result
     *
     * @return Collection
     */
    public function afterGetCollection(Attributes $subject, Collection $result)
    {
        $result->getSelect()->where('`main_table`.`attribute_code` not like \'maas_%\'');

        return $result;
    }


}