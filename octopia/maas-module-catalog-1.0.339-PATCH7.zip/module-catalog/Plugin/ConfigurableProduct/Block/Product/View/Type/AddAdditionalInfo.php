<?php
/**
 */
declare(strict_types=1);

namespace Maas\Catalog\Plugin\ConfigurableProduct\Block\Product\View\Type;

use Magento\ConfigurableProduct\Block\Product\View\Type\Configurable as Subject;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\UrlInterface;
use Maas\Catalog\Model\ShippingAttributesManagement as ShippingManagement;


/**
 * Class for adding info about sellers and deliveries.
 */
class AddAdditionalInfo
{
    /**
     * @var Json 
     */
    private $jsonSerializer;

    /**
     * @var ShippingManagement 
     */
    private $shippingManagement;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;
    
    /**
     * @param Json $jsonSerializer
     * @param ShippingManagement $shippingManagement
     */
    public function __construct(
        Json $jsonSerializer,
        ShippingManagement $shippingManagement,
        UrlInterface $urlBuilder
    ) {
        $this->jsonSerializer = $jsonSerializer;
        $this->shippingManagement = $shippingManagement;
        $this->urlBuilder = $urlBuilder;
    }

    /**
     * @param Subject $configurable
     * @param string $result
     * @return string
     */
    public function afterGetJsonConfig(Subject $configurable, string $result): string
    {
        $jsonConfig = $this->jsonSerializer->unserialize($result);

        $jsonConfig['sellers'] = $this->getOptionSellers($configurable);
        $jsonConfig['deliveries'] = $this->getOptionDeliveries($configurable);

        return $this->jsonSerializer->serialize($jsonConfig);
    }

    /**
     * @param $configurable
     * @return array
     */
    private function getOptionSellers($configurable)
    {
        $sellers = [];
        foreach ($configurable->getAllowProducts() as $product) {
            $sellers[$product->getId()] = 
                [
                   'sellerName' => $product->getMaasOfferSellerFrontName(),
                   'sellerUrl' => $this->getSellerPageUrl($product)   
                ];
        }
        
        return $sellers;
    }

    /**
     * @param $configurable
     * @return array
     */
    private function getOptionDeliveries($configurable)
    {
        $deliveries = [];
        foreach ($configurable->getAllowProducts() as $product) {
            $deliveries[$product->getId()] =
                [
                    'deliveries' => $this->shippingManagement->formatShippingMethodAndDeliveries($product)
                ];
        }

        return $deliveries;
    }

    /**
     * @param $product
     * @return string
     */
    private function getSellerPageUrl($product)
    {
        return $this->urlBuilder->getUrl(
            'seller/view',
            [
                'id' => $product->getMaasOfferSellerId(),
                'product' => $product->getId()
            ]
        );
    }
}
