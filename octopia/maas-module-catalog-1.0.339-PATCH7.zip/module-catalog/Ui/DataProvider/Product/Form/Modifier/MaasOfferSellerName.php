<?php

namespace Maas\Catalog\Ui\DataProvider\Product\Form\Modifier;

use Maas\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractReadOnly;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class MaasOfferSellerName
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 * @codeCoverageIgnore
 */
class MaasOfferSellerName extends AbstractReadOnly
{
    public $attribute = 'maas_offer_seller_name';
}
