<?php

namespace Maas\Catalog\Ui\DataProvider\Product\Form\Modifier;

use Maas\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractReadOnly;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class MaasOfferSellerFrontName
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 * @codeCoverageIgnore
 */
class MaasOfferSellerFrontName extends AbstractReadOnly
{
    public $attribute = 'maas_offer_seller_front_name';
}
