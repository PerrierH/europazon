<?php

namespace Maas\Catalog\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class AbstractReadOnly
 *
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 * @codeCoverageIgnore
 */
class AbstractReadOnly extends AbstractModifier
{
    /** @var string */
    public $attribute;

    private $arrayManager;

    public function __construct(ArrayManager $arrayManager)
    {
        $this->arrayManager = $arrayManager;
    }

    public function modifyData(array $data)
    {
        return $data;
    }

    public function modifyMeta(array $meta)
    {
        $path = $this->arrayManager->findPath($this->attribute, $meta, null, 'children');
        if($path === null){
            return $meta;
        }
        return $this->arrayManager->set(
            "{$path}/arguments/data/config/disabled",
            $meta,
            true
        );
    }
}
