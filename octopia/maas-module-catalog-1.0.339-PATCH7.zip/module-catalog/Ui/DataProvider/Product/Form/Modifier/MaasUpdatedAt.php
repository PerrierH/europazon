<?php

namespace Maas\Catalog\Ui\DataProvider\Product\Form\Modifier;

use Maas\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractReadOnly;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class MaasUpdatedAt
 *
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 * @codeCoverageIgnore
 */
class MaasUpdatedAt extends AbstractReadOnly
{
    public $attribute = 'maas_updated_at';
}
