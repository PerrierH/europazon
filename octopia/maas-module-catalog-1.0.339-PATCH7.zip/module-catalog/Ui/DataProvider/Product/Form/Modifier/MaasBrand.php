<?php

namespace Maas\Catalog\Ui\DataProvider\Product\Form\Modifier;

use Maas\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractReadOnly;
use Magento\Framework\Stdlib\ArrayManager;

/**
 * Class MaasBrand
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 * @codeCoverageIgnore
 */
class MaasBrand extends AbstractReadOnly
{
    public $attribute = 'maas_brand';
}
