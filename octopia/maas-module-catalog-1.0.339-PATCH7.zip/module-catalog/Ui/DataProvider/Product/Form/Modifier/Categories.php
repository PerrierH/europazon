<?php

namespace Maas\Catalog\Ui\DataProvider\Product\Form\Modifier;

use Maas\Catalog\Model\Config;
use Magento\Backend\Model\Auth\Session;
use Magento\Catalog\Model\Category as CategoryModel;
use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Catalog\Model\ResourceModel\Category\Collection;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Framework\App\Cache\Type\Block;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\DB\Helper as DbHelper;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Magento\Framework\UrlInterface;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class Categories
 *
 * @package Maas\Catalog\Ui\DataProvider\Product\Form\Modifier
 */
class Categories extends \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\Categories
{
    /**
     * @var CacheInterface
     */
    protected $cache;

    /**
     * @var SerializerInterface
     */
    protected $serializer;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var Config
     */
    protected $catalogConfig;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * @param LocatorInterface $locator
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param DbHelper $dbHelper
     * @param UrlInterface $urlBuilder
     * @param ArrayManager $arrayManager
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param Session $session
     * @param Config $catalogConfig
     * @param EditionInterface $edition
     */
    public function __construct(
        LocatorInterface          $locator,
        CategoryCollectionFactory $categoryCollectionFactory,
        DbHelper                  $dbHelper,
        UrlInterface              $urlBuilder,
        ArrayManager              $arrayManager,
        CacheInterface            $cache,
        SerializerInterface       $serializer,
        Session                   $session,
        Config                    $catalogConfig,
        EditionInterface          $edition
    )
    {
        $this->cache = $cache;
        $this->serializer = $serializer;
        $this->session = $session;
        $this->catalogConfig = $catalogConfig;
        $this->edition = $edition;
        parent::__construct($locator, $categoryCollectionFactory, $dbHelper, $urlBuilder, $arrayManager);
        $this->edition = $edition;
    }

    /**
     * Retrieve categories tree
     *
     * @param string|null $filter
     *
     * @return array
     * @throws LocalizedException
     * @since 101.0.0
     */
    protected function getCategoriesTree($filter = null)
    {
        $storeId = (int)$this->locator->getStore()->getId();
        $product = $this->locator->getProduct();
        $productIsMaas = $product->getId() && $product->getData('maas_is_maas_product');

        $cachedCategoriesTree = $this->cache
            ->load($this->getCategoriesTreeCacheIdWithMaasContext($storeId, $productIsMaas, (string)$filter));
        if (!empty($cachedCategoriesTree)) {
            return $this->serializer->unserialize($cachedCategoriesTree);
        }

        $categoriesTree = $this->retrieveCategoriesTree(
            $storeId,
            $this->retrieveShownCategoriesIdsWithMaasContext($storeId, $productIsMaas, (string)$filter)
        );

        $this->cache->save(
            $this->serializer->serialize($categoriesTree),
            $this->getCategoriesTreeCacheIdWithMaasContext($storeId, $productIsMaas, (string)$filter),
            [
                CategoryModel::CACHE_TAG,
                Block::CACHE_TAG
            ]
        );
        return $categoriesTree;
    }

    /**
     * Get cache id for categories tree.
     *
     * @param int $storeId
     * @param string $filter
     *
     * @return string
     */
    private function getCategoriesTreeCacheIdWithMaasContext(
        int    $storeId,
        bool   $productIsMaas,
        string $filter = ''
    ): string
    {
        $maasSegment = $productIsMaas ? 'maas' : 'core';
        if ($this->session->getUser() !== null) {
            return self::CATEGORY_TREE_ID
                . '_' . $maasSegment
                . '_' . (string)$storeId
                . '_' . $this->session->getUser()->getAclRole()
                . '_' . $filter;
        }
        return self::CATEGORY_TREE_ID
            . '_' . $maasSegment
            . '_' . (string)$storeId
            . '_' . $filter;
    }

    /**
     * Retrieve tree of categories with attributes.
     *
     * @param int $storeId
     * @param array $shownCategoriesIds
     *
     * @return array|null
     * @throws LocalizedException
     */
    private function retrieveCategoriesTree(int $storeId, array $shownCategoriesIds): ?array
    {
        /* @var $collection Collection */
        $collection = $this->categoryCollectionFactory->create();

        $collection->addAttributeToFilter($this->edition->getLinkField(), ['in' => array_keys($shownCategoriesIds)])
            ->addAttributeToSelect(['name', 'is_active', 'parent_id'])
            ->setStoreId($storeId);

        $categoryById = [
            CategoryModel::TREE_ROOT_ID => [
                'value' => CategoryModel::TREE_ROOT_ID,
                'optgroup' => null,
            ],
        ];

        foreach ($collection as $category) {
            foreach ([$category->getId(), $category->getParentId()] as $categoryId) {
                if (!isset($categoryById[$categoryId])) {
                    $categoryById[$categoryId] = ['value' => $categoryId];
                }
            }

            $categoryById[$category->getId()]['is_active'] = $category->getIsActive();
            $categoryById[$category->getId()]['label'] = $category->getName();
            $categoryById[$category->getId()]['__disableTmpl'] = true;
            $categoryById[$category->getParentId()]['optgroup'][] = &$categoryById[$category->getId()];
        }
        return $categoryById[CategoryModel::TREE_ROOT_ID]['optgroup'];
    }

    /**
     * Retrieve filtered list of categories id.
     *
     * @param int $storeId
     * @param string $filter
     *
     * @return array
     * @throws LocalizedException
     */
    private function retrieveShownCategoriesIdsWithMaasContext(
        int    $storeId,
        bool   $productIsMaas,
        string $filter = ''
    ): array
    {
        /* @var $matchingNamesCollection Collection */
        $matchingNamesCollection = $this->categoryCollectionFactory->create();
        $linkField = $this->edition->getLinkField();
        if (!empty($filter)) {
            $matchingNamesCollection->addAttributeToFilter(
                'name',
                ['like' => $this->dbHelper->addLikeEscape($filter, ['position' => 'any'])]
            );
        }

        if (!$productIsMaas) {
            $categoryId = $this->catalogConfig->getMaasRootCategory();
            if ($categoryId) {
                $matchingNamesCollection->addAttributeToFilter(
                    'path', ['nlike' => '%/' . $categoryId . '/%'], 'left');
                $matchingNamesCollection->addAttributeToFilter(
                    $linkField, ['neq' => $categoryId], 'left');
            }
        }

        $matchingNamesCollection->addAttributeToSelect('path')
            ->addAttributeToFilter($linkField, ['neq' => CategoryModel::TREE_ROOT_ID])
            ->setStoreId($storeId);

        $shownCategoriesIds = [];

        /** @var CategoryModel $category */
        foreach ($matchingNamesCollection as $category) {
            foreach (explode('/', $category->getPath()) as $parentId) {
                $shownCategoriesIds[$parentId] = 1;
            }
        }
        return $shownCategoriesIds;
    }
}
