<?php

namespace Maas\Catalog\Ui\DataProvider\Product;

use Magento\Catalog\Ui\DataProvider\Product\ProductDataProvider as originProductDataProvider;

/**
 * Class ProductDataProvider
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Ui\DataProvider\Product
 */
class ProductDataProvider extends originProductDataProvider
{

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (!$this->collection->isLoaded()) {
            $this->collection->addAttributeToFilter(
                'maas_is_maas_product',
                [['neq' => '1'], ['null' => true]],
                'left'
            );
        }

        return parent::getData();
    }
}
