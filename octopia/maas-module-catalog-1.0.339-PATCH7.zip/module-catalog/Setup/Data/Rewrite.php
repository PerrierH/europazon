<?php

namespace Maas\Catalog\Setup\Data;

use Magento\Catalog\Model\ResourceModel\Category\Collection as CategoryCollection;
use Magento\Catalog\Model\ResourceModel\Product\Collection as ProductCollection;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\UrlRewrite\Model\ResourceModel\UrlRewrite;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class Rewrite
 *
 * Using collections in order to be able to handle the eventuality of content staging being enabled
 *
 * @package Maas\Catalog\Setup\Data
 * @codeCoverageIgnore
 */
class Rewrite
{
    /**
     * @var UrlRewrite
     */
    protected $urlRewriteResource;

    /**
     * @var CategoryCollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var ProductCollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * Rewrite constructor.
     *
     * @param UrlRewrite $urlRewriteResource
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param EditionInterface $edition
     */
    public function __construct(
        UrlRewrite $urlRewriteResource,
        CategoryCollectionFactory $categoryCollectionFactory,
        ProductCollectionFactory $productCollectionFactory,
        EditionInterface         $edition
    ) {
        $this->urlRewriteResource = $urlRewriteResource;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->edition = $edition;
    }

    public function deleteMaasProductRewrites()
    {
        /** @var ProductCollection $collection */
        $collection = $this->productCollectionFactory->create();
        $collection->addFieldToFilter('maas_is_maas_product', 1);

        // chunk in bunches of 50 to handle volume
        $entityIdsChunks = array_chunk($collection->getColumnValues($this->edition->getLinkField()), 50);
        $connection = $this->urlRewriteResource->getConnection();
        foreach ($entityIdsChunks as $entityIdsChunk) {
            $connection->delete(
                $this->urlRewriteResource->getMainTable(),
                $connection->quoteInto("entity_type = 'product' AND entity_id in (?)", $entityIdsChunk)
            );
        }
    }

    public function deleteMaasCategoryRewrites()
    {
        /** @var CategoryCollection $collection */
        $collection = $this->categoryCollectionFactory->create();
        $collection->addFieldToFilter('maas_is_maas_category', 1);

        // chunk in bunches of 50 to handle volume
        $entityIdsChunks = array_chunk($collection->getColumnValues($this->edition->getLinkField()), 50);
        $connection = $this->urlRewriteResource->getConnection();
        foreach ($entityIdsChunks as $entityIdsChunk) {
            $connection->delete(
                $this->urlRewriteResource->getMainTable(),
                $connection->quoteInto("entity_type = 'category' AND entity_id in (?)", $entityIdsChunk)
            );
        }
    }
}
