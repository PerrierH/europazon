<?php

namespace Maas\Catalog\Setup\Data;

use Maas\Catalog\Model\Product\Attribute\Backend\Timestamp;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;

/**
 * Class AttributeProductMaasData
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Setup\Data
 */
class AttributeProductMaasData
{
    /**
     * @return array
     */
    public function getAttributes()
    {
        return [
            'maas_brand' => $this->createAttribute('Brand', [
                'visible_on_front' => true,
                'type' => 'int',
                'input' => 'select',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'is_visible_in_grid' => true,
                'is_filterable_in_grid' => true,
                'visible_in_advanced_search' => true,
                'filterable_in_search' => true

            ]),
            'maas_sync_date' => $this->createAttribute(
                'SyncDate',
                [
                    'input' => 'text',
                    'type' => 'datetime'
                ]
            ),
            'maas_offer_id' => $this->createAttribute('Offer ID', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_is_maas_product' => $this->createAttribute('Is Maas Product', [
                'type' => 'int',
                'input' => 'boolean',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                'default' => '0'
            ]),
            'maas_category_id' => $this->createAttribute('Category_maas_id'),
            'maas_brand_code' => $this->createAttribute('Maas Brand Code'),
            'maas_variation_group_id' => $this->createAttribute('Maas Variation Group Id'),
            'maas_variation_attributes' => $this->createAttribute('Maas Variation Group Attributes', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_brand_image' => $this->createAttribute('Maas Brand Image', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_discount_id' => $this->createAttribute('Maas Discount Id', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_currency' => $this->createAttribute('Maas Currency', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_offer_condition' => $this->createAttribute('Maas Offer Condition'),
            'maas_offer_sub_condition' => $this->createAttribute('Maas Offer SubCondition'),
            'maas_offer_condition_comment' => $this->createAttribute('Maas Offer Condition Comment', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_offer_seller_name' => $this->createAttribute('Maas Offer Seller Name', [
                'visible_on_front' => true,
                'type' => 'int',
                'input' => 'select',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'is_visible_in_grid' => true,
                'is_filterable_in_grid' => true,
                'visible_in_advanced_search' => true,
                'filterable_in_search' => true
            ]),
            'maas_offer_seller_id' => $this->createAttribute('Maas Offer Seller Id', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_offer_updated_at' => $this->createAttribute(
                'Maas Offer Update At',
                [
                    'input' => 'text',
                    'type' => 'datetime',
                    'backend' => Timestamp::class
                ]
            ),
            'maas_offer_image' => $this->createAttribute('Maas Offer Image', [
                'is_used_in_grid' => false,
                'used_in_product_listing' => false,
            ]),
            'maas_offer_price_updated_at' => $this->createAttribute(
                'Maas Offer Price Update At',
                [
                    'input' => 'text',
                    'type' => 'datetime',
                    'backend' => Timestamp::class
                ]
            ),
            'maas_offer_inv_updated_at' => $this->createAttribute(
                'Maas Offer Inventory Update At',
                [
                    'input' => 'text',
                    'type' => 'datetime',
                    'backend' => Timestamp::class
                ]
            ),
            'maas_supply_mode' => $this->createAttribute('Supply Mode', [
                'is_used_in_grid' => false
            ]),
            'maas_delivery_standard_min' => $this->createAttribute(
                'Standard delivery min',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_delivery_standard_max' => $this->createAttribute(
                'Standard delivery max',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_delivery_standard_cost' => $this->createAttribute(
                'Standard delivery cost',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_delivery_express_min' => $this->createAttribute(
                'Express delivery Delay min',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_delivery_express_max' => $this->createAttribute(
                'Express delivery Delay max',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_delivery_express_cost' => $this->createAttribute(
                'Express delivery Cost',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_updated_at' => $this->createAttribute(
                'Maas Update Date',
                [
                    'input' => 'text',
                    'type' => 'datetime',
                    'is_used_in_grid' => false,
                    'used_in_product_listing' => false
                ]
            ),
        ];
    }

    /**
     * @return array
     */
    public function getAttributesFor1_0_1()
    {
        return [
            'maas_delivery_standard_acost' => $this->createAttribute(
                'Standard delivery additional cost',
                [
                    'is_used_in_grid' => false
                ]
            ),
            'maas_delivery_express_acost' => $this->createAttribute(
                'Express delivery additional cost',
                [
                    'is_used_in_grid' => false
                ]
            )
        ];
    }

    /**
     * @return array|array[]
     */
    public function getAttributesFor1_0_3()
    {
        // reinserting the atributes 1.0.1 due to an issue with assignment to attribute sets
        return array_merge($this->getAttributesFor1_0_1(), [
            'maas_shipping_country' => $this->createAttribute(
                'Seller Shipping Country',
                [
                    'is_used_in_grid' => false,
                    'is_filterable_in_search' => false,
                    'used_in_product_listing' => false
                ]
            )
        ]);
    }


    /**
     * @return array|array[]
     */
    public function getAttributesFor1_0_4()
    {
        return [
            'maas_origin_price' => $this->createAttribute(
                'Origin price',
                [
                    'is_used_in_grid' => false,
                    'is_filterable_in_search' => false,
                    'used_in_product_listing' => false,
                    'type' => 'varchar',
                    'input' => 'text'
                ]
            )
        ];
    }

    /**
     * @return array|array[]
     */
    public function getAttributesFor1_0_5()
    {
        return [
            'maas_level3_category' => $this->createAttribute(
                'Level 3 Category',
                [
                    'is_used_in_grid' => false,
                    'type' => 'varchar',
                    'input' => 'text'
                ]
            ),
            'maas_additional_information' => $this->createAttribute(
                'Additional Information',
                [
                    'is_used_in_grid' => false,
                    'type' => 'text',
                    'input' => 'textarea'
                ]
            )
        ];
    }

    /**
     * @return array|array[]
     */
    public function getAttributesFor1_0_9()
    {
        return [
            'maas_warranty_duration' => $this->createAttribute(
                'Warranty duration',
                [
                    'is_used_in_grid' => false,
                    'type' => 'varchar',
                    'input' => 'text',
                    'visible_on_front' => true,
                    'is_visible_in_grid' => true,
                ]
            )
        ];
    }

    /**
     * @return array|array[]
     */
    public function getAttributesFor1_0_10()
    {
        return [
            'maas_original_taxes' => $this->createAttribute(
                'Original Taxes',
                [
                    'type' => 'text',
                    'input' => 'textarea',
                    'visible_on_front' => false,
                    'used_in_product_listing' => false,
                    'is_used_in_grid' => false,
                    'is_visible_in_grid' => false,
                    'is_filterable_in_search' => false,
                    'default' => '[]'
                ]
            )
        ];
    }

    /**
     * @return array[]
     */
    public function getAttributesFor1_0_11()
    {
        return [
            'maas_offer_seller_front_name' => $this->createAttribute(
                'Maas Offer Seller Front Name',
                [
                    'visible_on_front' => true,
                    'visible' => true,
                    'type' => 'varchar',
                    'input' => 'text'
                ]
            )
        ];
    }

    /**
     * @param string $label
     * @param array $options
     *
     * @return array
     */
    private function createAttribute(string $label, array $options = [])
    {
        return array_merge([
            'type' => 'text',
            'backend' => '',
            'frontend' => '',
            'label' => $label,
            'input' => 'text',
            'class' => '',
            'source' => '',
            'global' => ScopedAttributeInterface::SCOPE_GLOBAL,
            'visible' => true,
            'required' => false,
            'user_defined' => true,
            'default' => '',
            'searchable' => false,
            'filterable' => false,
            'comparable' => false,
            'visible_on_front' => false,
            'is_used_in_grid' => true,
            'used_in_product_listing' => true,
            'unique' => false,
            'apply_to' => ''
        ], $options);
    }
}
