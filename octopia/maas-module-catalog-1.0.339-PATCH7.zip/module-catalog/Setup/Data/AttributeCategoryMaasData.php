<?php

namespace Maas\Catalog\Setup\Data;

use Maas\Catalog\Model\Config;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Eav\Model\Entity\Attribute\Source\Boolean;

/**
 * Class AttributeCategoryMaasData
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Setup\Data
 */
class AttributeCategoryMaasData
{
    /**
     * @return array
     */
    public function getAttributes()
    {
        return [
            Config::MAAS_IS_MAAS_CATEGORY => $this->createAttribute(
                Config::MAAS_IS_MAAS_CATEGORY_LABEL, [
                    'type' => 'int',
                    'input' => 'boolean',
                    'source' => Boolean::class,
                    'sort_order' => 100,
                    'global' => ScopedAttributeInterface::SCOPE_STORE,
                    'user_defined' => true
                ]
            ),
            Config::MAAS_CATEGORY_ID => $this->createAttribute(
                Config::MAAS_CATEGORY_ID_LABEL, [
                    'type' => 'varchar',
                    'input' => 'text',
                    'sort_order'   => 100,
                    'source'       => '',
                    'global'       => 1,
                    'visible'      => true,
                    'user_defined' => true,
                    'default'      => null
                ]
            ),
            'maas_updated_at' => $this->createAttribute(
                'Maas Update Date',
                [
                    'input' => 'text',
                    'type' => 'datetime',
                    'visible' => true,
                ]
            )
        ];
    }
    /**
     * @param string $label
     * @param array $options
     *
     * @return array
     */
    private function createAttribute(string $label, array $options = [])
    {
        return array_merge([
            'label' => $label,
            'user_defined' => true,
            'required' => false,
            'default' => ''
        ], $options);
    }
}