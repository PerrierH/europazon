<?php

namespace Maas\Catalog\Setup;

use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Eav\Setup\EavSetup;
use Magento\Catalog\Model\Product;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeData extends AbstractData implements UpgradeDataInterface
{

    /**
     * @inheritDoc
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_1');
        }

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            /** @var CategorySetup $categorySetup */
            $categorySetup = $this->categorySetupFactory->create(['setup' => $setup]);
            $this->createMaasErrorCategory($setup, $categorySetup);
        }

        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_3');
        }

        if (version_compare($context->getVersion(), '1.0.4', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_4');
        }

        if (version_compare($context->getVersion(), '1.0.5', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_5');
        }

        if (version_compare($context->getVersion(), '1.0.6', '<')) {
            /** @var EavSetup $eavSetup */
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->updateAttribute(ProductAttributeInterface::ENTITY_TYPE_CODE, 'maas_additional_information',
                [
                    'is_searchable' => true,
                    'is_filterable' => true
                ]);
        }

        if (version_compare($context->getVersion(), '1.0.7', '<')) {
            /** @var EavSetup $eavSetup */
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->updateAttribute(ProductAttributeInterface::ENTITY_TYPE_CODE, 'maas_additional_information',
                [
                    'is_filterable' => false
                ]);
        }

        if (version_compare($context->getVersion(), '1.0.8', '<')) {
            /** @var EavSetup $eavSetup */
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->updateAttribute(ProductAttributeInterface::ENTITY_TYPE_CODE, 'maas_shipping_country',
                [
                    'used_in_product_listing' => true
                ]);
        }

        if (version_compare($context->getVersion(), '1.0.8', '<')) {
            /** @var EavSetup $eavSetup */
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->reinstallAttributes($eavSetup, ['maas_brand', 'maas_offer_seller_name']);
        }

        if (version_compare($context->getVersion(), '1.0.9', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_9');
        }

        if (version_compare($context->getVersion(), '1.0.10', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_10');
        }

        if (version_compare($context->getVersion(), '1.0.11', '<')) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $this->createAttributeProductsMaas($eavSetup, 'getAttributesFor1_0_11');
        }

        $setup->endSetup();
    }

    /**
     * @param EavSetup $eavSetup
     * @param string $method
     *
     * @throws LocalizedException
     * @throws Zend_Validate_Exception
     */
    protected function reinstallAttributes(EavSetup $eavSetup, $attributes, $method = 'getAttributes')
    {
        foreach ($this->attributeProductMaasData->$method() as $attributeCode => $values) {
            if (in_array($attributeCode, $attributes)) {
                $eavSetup->removeAttribute(Product::ENTITY, $attributeCode);
                $eavSetup->addAttribute(
                    Product::ENTITY,
                    $attributeCode,
                    $values
                );
                $this->addAttributeToSetAttributeMaas($eavSetup, $attributeCode);
            }
        }
    }

}
