<?php

namespace Maas\Catalog\Setup;

use Exception;
use Maas\Catalog\Model\Config;
use Maas\Catalog\Setup\Data\Rewrite;
use Maas\Log\Model\Error as ErrorLogger;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Setup\CategorySetup;
use Magento\Catalog\Setup\CategorySetupFactory;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\State;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Registry;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;
use Magento\Eav\Api\AttributeRepositoryInterface;

/**
 * Class Uninstall
 *
 * @package Maas\Catalog\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    public const  TABLE_MAAS_MEDIA_GALLERY_INFO = 'maas_media_gallery_info';
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;
    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;
    /**
     * @var Registry
     */
    protected $registry;
    /**
     * @var State
     */
    protected $state;
    /**
     * @var ErrorLogger
     */
    protected $errorLogger;
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;
    /**
     * @var Config
     */
    private $config;
    /**
     * @var CategoryRepositoryInterface
     */
    private $categoryRepository;
    /**
     * Category setup factory
     *
     * @var CategorySetupFactory
     */
    private $categorySetupFactory;
    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;
    /**
     * @var AttributeRepositoryInterface
     */
    private $attributeRepository;
    /**
     * @var CategoryFactory
     */
    private $categoryFactory;

    /**
     * @var Rewrite
     */
    private $rewrite;

    /**
     * Uninstall constructor.
     *
     * @param EavSetupFactory $eavSetupFactory
     * @param Config $config
     * @param CategoryRepositoryInterface $categoryRepository
     * @param CategorySetupFactory $categorySetupFactory
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param ProductRepositoryInterface $productRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param Registry $registry
     * @param State $state
     * @param ErrorLogger $errorLogger
     * @param AttributeRepositoryInterface $attributeRepository
     * @param CategoryFactory $categoryFactory
     * @param Rewrite $rewrite
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        Config $config,
        CategoryRepositoryInterface $categoryRepository,
        CategorySetupFactory $categorySetupFactory,
        ModuleDataSetupInterface $moduleDataSetup,
        ProductRepositoryInterface $productRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        Registry $registry,
        State $state,
        ErrorLogger $errorLogger,
        AttributeRepositoryInterface $attributeRepository,
        CategoryFactory $categoryFactory,
        Rewrite $rewrite
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->config = $config;
        $this->categoryRepository = $categoryRepository;
        $this->categorySetupFactory = $categorySetupFactory;
        $this->moduleDataSetup = $moduleDataSetup;
        $this->productRepository = $productRepository;
        $this->filterBuilder = $filterBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->registry = $registry;
        $this->state = $state;
        $this->errorLogger = $errorLogger;
        $this->attributeRepository = $attributeRepository;
        $this->categoryFactory = $categoryFactory;
        $this->rewrite = $rewrite;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $uninstaller = $setup;

        // deleting all rewrites
        $this->rewrite->deleteMaasCategoryRewrites();
        $this->rewrite->deleteMaasProductRewrites();

        /* Remove Maas products */
        $this->deleteMaasProducts($setup);

        /* Remove Maas Categories */
        $this->removeMaasCategories();

        /* Remove Maas_Catalog Custom Attributes */
        $this->removeMaasCatalogAttributes();

        /* Remove Category Attribute group */
        $this->removeMaasAttributeGroup();

        /* Remove Data from Config Table */
        $this->removeConfigData($uninstaller);

        /* Remove Maas products */
        $this->removeMaasMediaInfo($uninstaller);

        $setup->endSetup();
    }


    /**
     * @param SchemaSetupInterface $setup
     */
    private function deleteMaasProducts(SchemaSetupInterface $setup)
    {
        $connection = $setup->getConnection();
        $connection->query("DELETE FROM " . $connection->getTableName('catalog_product_entity') . "
                WHERE entity_id IN (
                    SELECT entity_id FROM " . $connection->getTableName('catalog_product_entity_int') . " WHERE attribute_id in (
                        SELECT attribute_id from " . $connection->getTableName('eav_attribute') . " where attribute_code like 'maas_is_maas_product'
                    )
                )
        ");
    }

    /**
     * @throws InputException
     * @throws StateException
     */
    private function removeMaasCategories()
    {
        $categories = $this->categoryFactory->create()->getCollection()->addFieldToFilter('maas_is_maas_category',
            1)->getItems();
        if ($categories) {
            foreach ($categories as $category) {
                try {
                    $this->categoryRepository->delete($category);
                } catch (NoSuchEntityException $exception) {
                    echo $exception->getMessage();
                }
            }
        }
    }

    /**
     * Remove Maas_Catalog Custom Attributes
     *
     * @return void
     */
    private function removeMaasCatalogAttributes()
    {
        $filter = [
            'field' => 'attribute_code',
            'condition' => 'like',
            'value' => 'maas_%'
        ];
        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create();
        /* Remove maas_is_maas_category */
        $eavSetup->removeAttribute(Category::ENTITY, Config::MAAS_IS_MAAS_CATEGORY);
        $eavSetup->removeAttribute(Category::ENTITY, Config::MAAS_CATEGORY_ID);
        /* Remove product attribute attribute maas*/
        $searchCriteriaProduct = $this->getSearchCriteria($filter);
        $attributesMaas = $this->attributeRepository->getList(Product::ENTITY, $searchCriteriaProduct)->getItems();
        foreach ($attributesMaas as $attribute) {
            $eavSetup->removeAttribute(Product::ENTITY, $attribute->getAttributeCode());
        }
    }

    /**
     * @param $criteria
     *
     * @return SearchCriteria
     */
    public function getSearchCriteria($criteria)
    {
        $filter = $this->filterBuilder
            ->setField($criteria['field'])
            ->setConditionType($criteria['condition'])
            ->setValue($criteria['value'])
            ->create();
        $this->searchCriteriaBuilder->addFilters([$filter]);
        return $this->searchCriteriaBuilder->create();
    }

    /**
     * Remove Maas Attribute group
     *
     * @return void
     */
    private function removeMaasAttributeGroup()
    {
        try {
            /** @var CategorySetup $categorySetup */
            $categorySetup = $this->categorySetupFactory->create(['setup' => $this->moduleDataSetup]);
            $entityTypeId = $categorySetup->getEntityTypeId(Category::ENTITY);
            $attributeSetId = $categorySetup->getDefaultAttributeSetId($entityTypeId);
            $categorySetup->removeAttributeGroup($entityTypeId, $attributeSetId, 'maas-plugin');
        } catch (Exception $exception) {
            echo $exception->getMessage();
        }
    }

    /**
     * @param SchemaSetupInterface $uninstaller
     *
     * @return void
     */
    private function removeConfigData($uninstaller)
    {
        $defaultConnection = $uninstaller->getConnection(ResourceConnection::DEFAULT_CONNECTION);
        $configTable = $uninstaller->getTable('core_config_data');
        $defaultConnection->delete($configTable, "`path` = 'maas_categories/general/maas_root_category'");
    }

    /**
     * @param SchemaSetupInterface $uninstaller
     *
     * @return void
     */
    private function removeMaasMediaInfo($uninstaller)
    {
        $uninstaller->getConnection()->dropTable(self::TABLE_MAAS_MEDIA_GALLERY_INFO);
    }
}
