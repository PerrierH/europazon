<?php


namespace Maas\Catalog\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 *
 * @package Maas\Catalog\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        /** @var Magento\Framework\DB\Adapter\AdapterInterface $connection */
        $connection = $setup->getConnection();
        $this->createTableMediaGalleryInfo($setup, $connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     */
    protected function createTableMediaGalleryInfo(SchemaSetupInterface $setup, $connection)
    {
        if (!$setup->tableExists('maas_media_gallery_info')) {
            $table = $connection->newTable(
                $setup->getTable('maas_media_gallery_info')
            )
                ->addColumn(
                    'value_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable' => false,
                        'unsigned' => true,
                    ],
                    'Media Value Id'
                )
                ->addColumn(
                    'image_url',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true,
                    ],
                    'Image Url'
                )
                ->setComment('maas_media_gallery_info Table');
            $connection->createTable($table);
            $connection->addForeignKey(
                $connection->getForeignKeyName(
                    $connection->getTableName(
                        'maas_media_gallery_info'
                    ),
                    'value_id',
                    'catalog_product_entity_media_gallery',
                    'value_id'
                ),
                'maas_media_gallery_info',
                'value_id',
                'catalog_product_entity_media_gallery',
                'value_id'
            );
        }
    }
}
