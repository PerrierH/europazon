<?php

namespace Maas\Catalog\Setup;

use Maas\Catalog\Model\Config;
use Maas\Catalog\Setup\Data\AttributeProductMaasData;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Setup\CategorySetupFactory;
use Magento\Catalog\Setup\CategorySetup;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Exception\LocalizedException;
use Zend_Validate_Exception;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use magento\Catalog\Model\ResourceModel\Category as CategoryResourceModel;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;

abstract class AbstractData
{
    /**
     * @var AttributeProductMaasData
     */
    protected $attributeProductMaasData;
    /**
     * @var EavSetupFactory
     */
    protected $eavSetupFactory;

    /**
     * Category setup factory
     *
     * @var CategorySetupFactory
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $categorySetupFactory;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var CategoryResourceModel
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $categoryResourceModel;

    /**
     * @var CollectionFactory
     */
    protected $attributeSetCollectionFactory;

    /**
     * AbstractData constructor.
     *
     * @param AttributeProductMaasData $attributeProductMaasData
     * @param EavSetupFactory $eavSetupFactory
     * @param CategorySetupFactory $categorySetupFactory
     * @param CategoryRepositoryInterface $categoryRepository
     * @param CategoryResourceModel $categoryResourceModel
     * @param CollectionFactory $attributeSetCollectionFactory
     */
    public function __construct(
        AttributeProductMaasData    $attributeProductMaasData,
        EavSetupFactory             $eavSetupFactory,
        CategorySetupFactory        $categorySetupFactory,
        CategoryRepositoryInterface $categoryRepository,
        CategoryResourceModel       $categoryResourceModel,
        CollectionFactory           $attributeSetCollectionFactory
    )
    {
        $this->attributeProductMaasData = $attributeProductMaasData;
        $this->eavSetupFactory = $eavSetupFactory;
        $this->categorySetupFactory = $categorySetupFactory;
        $this->categoryRepository = $categoryRepository;
        $this->categoryResourceModel = $categoryResourceModel;
        $this->attributeSetCollectionFactory = $attributeSetCollectionFactory;
    }

    /**
     * @param EavSetup $eavSetup
     * @param string $method
     *
     * @throws LocalizedException
     * @throws Zend_Validate_Exception
     */
    protected function createAttributeProductsMaas(EavSetup $eavSetup, $method = 'getAttributes')
    {
        foreach ($this->attributeProductMaasData->$method() as $attributeCode => $values) {
            $eavSetup->addAttribute(
                Product::ENTITY,
                $attributeCode,
                $values
            );
            $this->addAttributeToSetAttributeMaas($eavSetup, $attributeCode);
        }
    }

    /**
     * @param EavSetup $eavSetup
     * @param $attributeCode
     */
    protected function addAttributeToSetAttributeMaas(EavSetup $eavSetup, $attributeCode)
    {
        $sets = $this->attributeSetCollectionFactory->create()
            ->addFieldToSelect('attribute_set_id')
            ->addFieldToFilter([
                'attribute_set_name',
                'attribute_set_name'
            ], [
                ['like' => 'Maas %'],
                ['eq' => 'Maas']
            ]);
        /** @var $sets \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection */
        $ids = $sets->getColumnValues('attribute_set_id');
        $attributeId = $eavSetup->getAttribute(Product::ENTITY, $attributeCode, 'attribute_id');
        foreach ($ids as $attributeSetId) {
            $groupId = $eavSetup->getAttributeGroup(Product::ENTITY, $attributeSetId, 'Octopia', 'attribute_group_id');
            $eavSetup->addAttributeToSet(Product::ENTITY, $attributeSetId, $groupId, $attributeId);
        }
    }

    /**
     * Create maas error category
     * @param ModuleDataSetupInterface $setup
     * @param CategorySetup $categorySetup
     */
    protected function createMaasErrorCategory(ModuleDataSetupInterface $setup, CategorySetup $categorySetup)
    {
        $maasRootCategoryId = $this->getMaasRootCategoryId($setup);

        /* Load Maas root category */
        $maasRootCategory = $this->categoryRepository->get($maasRootCategoryId);

        /* Create Maas Error category */
        $maasErrorCategory = $categorySetup->createCategory()
            ->setName(Config::MAAS_ERROR_CATEGORY_NAME)
            ->setLevel(2)
            ->setIncludeInMenu(false)
            ->setParentId($maasRootCategoryId)
            ->setIsActive(0)
            ->setPath($maasRootCategory->getPath())
            ->setCustomAttribute(Config::MAAS_IS_MAAS_CATEGORY, true)
            ->setStoreId(0);

        $this->categoryResourceModel->save($maasErrorCategory);

        /* Set the category in module configuration system */
        $data = [
            'scope' => 'default',
            'scope_id' => 0,
            'path' => Config::XML_PATH_MAAS_ERROR_CATEGORY,
            'value' => $maasErrorCategory->getId(),
        ];

        $setup->getConnection()->insertOnDuplicate(
            $setup->getTable('core_config_data'),
            $data,
            ['value']
        );
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @return int|null
     */
    private function getMaasRootCategoryId(ModuleDataSetupInterface $setup)
    {
        $connection = $setup->getConnection();
        $select = $connection->select()->from($setup->getTable('core_config_data'))->where('path like ?', Config::XML_PATH_MAAS_CATEGORY);
        $result = $connection->fetchRow($select);
        return $result ? intval($result['value']) : null;
    }
}