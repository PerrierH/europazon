<?php

namespace Maas\Catalog\Setup;

use Maas\Catalog\Model\Config;
use Maas\Catalog\Model\Config\Proxy as CatalogConfig;
use Maas\Catalog\Setup\Data\AttributeCategoryMaasData;
use Maas\Catalog\Setup\Data\AttributeProductMaasData;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Setup\CategorySetup;
use Magento\Catalog\Setup\CategorySetupFactory;
use Magento\Eav\Api\AttributeSetManagementInterface;
use Magento\Eav\Model\Entity\Attribute\Set;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\App\Cache\Type\Config as ConfigCache;
use Magento\Framework\App\Cache\TypeListInterface as TypeListInterfaceAlias;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use magento\Catalog\Model\ResourceModel\Category as CategoryResourceModel;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;

/**
 * @codeCoverageIgnore
 */
class InstallData extends AbstractData implements InstallDataInterface
{
    /**
     * @var TypeListInterfaceAlias
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $cacheTypeList;

    /**
     * Category setup factory
     *
     * @var CategorySetupFactory
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $categorySetupFactory;

    /**
     * @var ModuleDataSetupInterface
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */

    private $moduleDataSetup;
    /**
     * @var AttributeSetFactory
     */
    private $attributeSetFactory;

    /**
     * @var AttributeSetManagementInterface
     */
    private $attributeSetManagement;

    /**
     * @var AttributeCategoryMaasData
     */
    private $attributeCategoryMaasData;


    /**
     * InstallData constructor.
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param CategorySetupFactory $categorySetupFactory
     * @param CategoryRepositoryInterface $categoryRepository
     * @param CategoryResourceModel $categoryResourceModel
     * @param CollectionFactory $attributeSetCollectionFactory
     * @param TypeListInterfaceAlias $cacheTypeList
     * @param EavSetupFactory $eavSetupFactory
     * @param AttributeSetFactory $attributeSetFactory
     * @param AttributeSetManagementInterface $attributeSetManagement
     * @param AttributeProductMaasData $attributeProductMaasData
     * @param AttributeCategoryMaasData $attributeCategoryMaasData
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CategorySetupFactory $categorySetupFactory,
        CategoryRepositoryInterface $categoryRepository,
        CategoryResourceModel $categoryResourceModel,
        CollectionFactory $attributeSetCollectionFactory,
        TypeListInterfaceAlias $cacheTypeList,
        EavSetupFactory $eavSetupFactory,
        AttributeSetFactory $attributeSetFactory,
        AttributeSetManagementInterface $attributeSetManagement,
        AttributeProductMaasData $attributeProductMaasData,
        AttributeCategoryMaasData $attributeCategoryMaasData
    )
    {
        parent::__construct(
            $attributeProductMaasData, $eavSetupFactory, $categorySetupFactory,
            $categoryRepository, $categoryResourceModel, $attributeSetCollectionFactory
        );
        $this->moduleDataSetup = $moduleDataSetup;
        $this->cacheTypeList = $cacheTypeList;
        $this->attributeSetFactory = $attributeSetFactory;
        $this->attributeSetManagement = $attributeSetManagement;
        $this->attributeCategoryMaasData = $attributeCategoryMaasData;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedFunctionParameter)
     * @throws LocalizedException
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        /** @var CategorySetup $categorySetup */
        $categorySetup = $this->categorySetupFactory->create(['setup' => $setup]);
        $this->createIsMaasCategoryAttribute($categorySetup);
        $this->createMaasCategory($categorySetup);

        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $this->createAttributeSetAndGroupMaas($eavSetup);
        $this->createAttributeProductsMaas($eavSetup);
        $setup->endSetup();
    }

    /**
     * Create maas_is_maas_category attribute
     *
     * @param $categorySetup
     */
    private function createIsMaasCategoryAttribute($categorySetup)
    {
        $groupAttributes = [];
        $groupAttributesOrder = 10;

        foreach ($this->attributeCategoryMaasData->getAttributes() as $attributeCode => $values) {
            $categorySetup->addAttribute(
                Category::ENTITY, $attributeCode, $values
            );
            $groupAttributes[$attributeCode] = ['group' => 'maas_plugin', 'sort' => $groupAttributesOrder];
            $groupAttributesOrder += 10;
        }

        $entityTypeId = $categorySetup->getEntityTypeId(Category::ENTITY);
        $attributeSetId = $categorySetup->getDefaultAttributeSetId($entityTypeId);

        $groups = [
            'maas_plugin' => ['name' => 'Maas plugin', 'code' => 'maas-plugin', 'sort' => 6, 'id' => null]
        ];

        foreach ($groups as $k => $groupProp) {
            $categorySetup->addAttributeGroup($entityTypeId, $attributeSetId, $groupProp['name'], $groupProp['sort']);
            $groups[$k]['id'] = $categorySetup->getAttributeGroupId($entityTypeId, $attributeSetId, $groupProp['code']);
        }

        // update attributes group and sort
        foreach ($groupAttributes as $attributeCode => $attributeProp) {
            $categorySetup->addAttributeToGroup(
                $entityTypeId,
                $attributeSetId,
                $groups[$attributeProp['group']]['id'],
                $attributeCode,
                $attributeProp['sort']
            );
        }
    }

    /**
     * Create default maas category
     *
     * @param $categorySetup
     */
    private function createMaasCategory($categorySetup)
    {
        $rootCategoryId = Category::TREE_ROOT_ID;
        /* Load root Category */
        $rootCategory = $categorySetup->createCategory();
        $this->categoryResourceModel->load($rootCategory, $rootCategoryId);

        /* Create Maas category */
        $category = $categorySetup->createCategory()
            ->setName(Config::MAAS_CATEGORY_NAME)
            ->setLevel(1)
            ->setIncludeInMenu(false)
            ->setParentId($rootCategoryId)
            ->setIsActive(1)
            ->setPath($rootCategory->getPath())
            ->setCustomAttribute(Config::MAAS_IS_MAAS_CATEGORY, true)
            ->setStoreId(0);

        $this->categoryResourceModel->save($category);

        /* Set the category in module configuration system */
        $data = [
            'scope' => 'default',
            'scope_id' => 0,
            'path' => Config::XML_PATH_MAAS_CATEGORY,
            'value' => $category->getId(),
        ];

        $this->moduleDataSetup->getConnection()->insertOnDuplicate(
            $this->moduleDataSetup->getTable('core_config_data'),
            $data,
            ['value']
        );

        $this->cacheTypeList->cleanType(ConfigCache::TYPE_IDENTIFIER);
    }


    /**
     * @param EavSetup $eavSetup
     *
     * @throws LocalizedException
     */
    protected function createAttributeSetAndGroupMaas(EavSetup $eavSetup)
    {
        $entityTypeId = $eavSetup->getEntityTypeId(Product::ENTITY);
        $defaultAttributeSetId = $eavSetup->getDefaultAttributeSetId($entityTypeId);
        /** @var Set $attributeSet */
        $attributeSet = $this->attributeSetFactory->create();
        $attributeSet->setName('Maas');
        $attributeSet->setEntityId(Product::ENTITY);
        $attributeSet->setSortOrder(3);
        $createdAttributeSet = $this->attributeSetManagement->create(
            Product::ENTITY,
            $attributeSet,
            $defaultAttributeSetId
        );
        $eavSetup->addAttributeGroup($entityTypeId, $createdAttributeSet->getAttributeSetId(), 'Octopia');
    }
}
