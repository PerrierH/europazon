<?php

namespace Maas\Catalog\Model\Product\Attribute\Backend;

use DateTime;
use Magento\Eav\Model\Entity\Attribute\Backend\AbstractBackend;
use Magento\Framework\DataObject;

/**
 * Class Timestamp
 *
 * @package Maas\Catalog\Model\Product\Attribute\Backend
 */
class Timestamp extends AbstractBackend
{
    /**
     * @param DataObject $object
     */
    public function beforeSave($object)
    {
        $code = $this->getAttribute()->getAttributeCode();
        $timestamp = $object->getData($code);
        if (is_numeric($timestamp)) {
            $value = $this->formatDateFromTimestamp($timestamp);
            $object->setData($code, $value);
        }
    }

    /**
     * @return String
     * @codeCoverageIgnore
     */
    public function formatDateFromTimestamp($timestamp)
    {
        return (new DateTime())->setTimestamp($timestamp)->format('Y-m-d H:i:s');
    }
}
