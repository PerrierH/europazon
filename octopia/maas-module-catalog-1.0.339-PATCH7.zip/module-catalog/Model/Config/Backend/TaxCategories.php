<?php

namespace Maas\Catalog\Model\Config\Backend;


use Exception;
use Maas\Catalog\Model\Config;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Value;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\Registry;
use Magento\Framework\App\Cache\Manager;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Catalog\Model\Product;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory;

/**
 * Class TaxCategories
 * @package Maas\Catalog\Model\Config\Backend
 */
class TaxCategories extends Value
{
    /** Wee tax enable xml path */
    const XML_PATH_TAX_WEE_ENABLE = 'tax/weee/enable';

    /**
     * @var Manager
     */
    protected $cacheManager;

    /**
     * @var WriterInterface
     */
    protected $configWriter;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var EavSetupFactory
     */
    protected $eavSetupFactory;

    /**
     * @var ModuleDataSetupInterface
     */
    protected $setup;

    /**
     * @var CollectionFactory
     */
    protected $attributeSetCollectionFactory;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param ScopeConfigInterface $scopeConfig
     * @param TypeListInterface $cacheTypeList
     * @param WriterInterface $configWriter
     * @param Manager $cacheManager
     * @param Config $config
     * @param EavSetupFactory $eavSetupFactory
     * @param ModuleDataSetupInterface $setup
     * @param CollectionFactory $attributeSetCollectionFactory
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context                  $context,
        Registry                 $registry,
        ScopeConfigInterface     $scopeConfig,
        TypeListInterface        $cacheTypeList,
        WriterInterface          $configWriter,
        Manager                  $cacheManager,
        Config                   $config,
        EavSetupFactory          $eavSetupFactory,
        ModuleDataSetupInterface $setup,
        CollectionFactory        $attributeSetCollectionFactory,
        AbstractResource         $resource = null,
        AbstractDb               $resourceCollection = null,
        array                    $data = []
    )
    {
        parent::__construct($context, $registry, $scopeConfig, $cacheTypeList, $resource, $resourceCollection, $data);
        $this->eavSetupFactory = $eavSetupFactory;
        $this->configWriter = $configWriter;
        $this->cacheManager = $cacheManager;
        $this->scopeConfig = $scopeConfig;
        $this->config = $config;
        $this->setup = $setup;
        $this->attributeSetCollectionFactory = $attributeSetCollectionFactory;
    }

    /**
     * @return TaxCategories
     * @throws LocalizedException
     * @throws \Zend_Validate_Exception
     */
    public function afterSave()
    {
        if ($this->getPath() === Config::XML_PATH_TAX_CATEGORIES) {
            $this->configWriter->save(self::XML_PATH_TAX_WEE_ENABLE, 1);
            $this->configCacheClean();

            if ($this->getValue() && is_array($taxCategories = explode(',', $this->getValue()))) {
                foreach ($taxCategories as $taxCategoryLabel) {
                    if ($taxCategoryLabel) {
                        $attributeCode = 'maas_' . $this->getTfpAttributeCodeFromLabel($taxCategoryLabel);
                        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->setup]);
                        
                        $eavSetup->addAttribute(
                            Product::ENTITY,
                            $attributeCode,
                            $this->getTfpAttributeValues($taxCategoryLabel)
                        );
                        
                        $this->addAttributeToSetAttributeMaas($eavSetup, $attributeCode);
                    }
                }
            }
        }
        return parent::afterSave();
    }

    /**
     * @param EavSetup $eavSetup
     * @param $attributeCode
     */
    protected function addAttributeToSetAttributeMaas(EavSetup $eavSetup, $attributeCode)
    {
        $sets = $this->attributeSetCollectionFactory->create()
            ->addFieldToSelect('attribute_set_id')
            ->addFieldToFilter([
                'attribute_set_name',
                'attribute_set_name'
            ], [
                ['like' => 'Maas %'],
                ['eq' => 'Maas']
            ]);
        /** @var $sets \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\Collection */
        $ids = $sets->getColumnValues('attribute_set_id');
        $attributeId = $eavSetup->getAttribute(Product::ENTITY, $attributeCode, 'attribute_id');
        foreach ($ids as $attributeSetId) {
            $groupId = $eavSetup->getAttributeGroup(Product::ENTITY, $attributeSetId, 'Octopia', 'attribute_group_id');
            $eavSetup->addAttributeToSet(Product::ENTITY, $attributeSetId, $groupId, $attributeId);
        }
    }

    /**
     * @param $taxCategory
     * @return array
     */
    private function getTfpAttributeValues($taxCategoryLabel)
    {
        return [
            'type' => 'static',
            'backend' => 'Magento\Weee\Model\Attribute\Backend\Weee\Tax',
            'label' => $taxCategoryLabel,
            'input' => 'weee',
            'visible' => true,
            'required' => false,
            'user_defined' => true,
            'visible_on_front' => true
        ];
    }

    /**
     * @param $taxCategoryLabel
     * @return string
     */
    public function getTfpAttributeCodeFromLabel($taxCategoryLabel)
    {
        $taxCategoryCode = str_replace(' ', '_', $taxCategoryLabel);
        $taxCategoryCode = preg_replace('/[^a-zA-Z0-9_]/', '_', $taxCategoryCode);
        $taxCategoryCode = preg_replace('/_+/', '_', $taxCategoryCode);
        return strtolower($taxCategoryCode);
    }

    /**
     * @return void
     */
    private function configCacheClean()
    {
        $this->cacheManager->clean(['config']);
    }
}