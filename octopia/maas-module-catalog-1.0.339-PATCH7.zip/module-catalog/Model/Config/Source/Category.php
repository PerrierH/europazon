<?php

namespace Maas\Catalog\Model\Config\Source;

use Magento\Catalog\Model\Category as CategoryModel;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\ResourceModel\Category\Collection;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Framework\Option\ArrayInterface;

/**
 * Class Category
 *
 * @package Maas\Catalog\Model\Config\Source
 */
class Category implements ArrayInterface
{
    /**
     * @var CollectionFactory
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $categoryCollectionFactory;

    public function __construct(
        CollectionFactory $categoryCollectionFactory
    )
    {
        $this->categoryCollectionFactory = $categoryCollectionFactory;
    }

    /**
     * Get category collection
     *
     * @param bool $isActive
     * @param bool|int $level
     * @param bool|string $sortBy
     * @param bool|int $pageSize
     * @return Collection or array
     */
    public function getCategoryCollection($isActive = true, $level = false, $sortBy = false, $pageSize = false)
    {
        $collection = $this->categoryCollectionFactory->create();
        $collection->addAttributeToSelect(['name', 'path', 'parent_id']);

        // select only active categories
        if ($isActive) {
            $collection->addIsActiveFilter();
        }

        // select categories of certain level
        if ($level) {
            $collection->addLevelFilter($level);
        }

        // sort categories by some value
        if ($sortBy) {
            $collection->addOrderField($sortBy);
        }

        // select certain number of categories
        if ($pageSize) {
            $collection->setPageSize($pageSize);
        }

        return $collection;
    }

    public function toOptionArray()
    {
        $categories = $this->getCategoryCollection(true, false, 'path', false);
        $catagoryList = [];

        foreach ($categories as $category) {
            $hyphen = '---';
            /** @var CategoryModel $category */
            $count = (substr_count($category->getPath(), '/') > 1) ? substr_count($category->getPath(), '/') : 2;
            $hyphen = str_repeat($hyphen, $count - 1);
            $catagoryList[] = ['value' => $category->getId(), 'label' => $hyphen . __($category->getName())];
        }

        return $catagoryList;
    }
}
