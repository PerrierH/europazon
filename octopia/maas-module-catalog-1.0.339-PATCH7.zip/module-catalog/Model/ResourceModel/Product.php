<?php

namespace Maas\Catalog\Model\ResourceModel;

use Exception;
use Magento\Catalog\Model\ResourceModel\Product as ProductResource;

/**
 * @codeCoverageIgnore
 */
class Product extends ProductResource
{
    /**
     * Get product ids by their sku
     *
     * @param array $productSkuList
     * @return array
     */
    public function getProductsIdsBySkus(array $productSkuList)
    {
        $linkField = $this->getLinkField();
        $select = $this->getConnection()->select()
            ->from(['catalog_product_entity' => $this->getTable('catalog_product_entity')],
                [])
            ->join(['eav_entity_type' => $this->getTable('eav_entity_type')],
                "eav_entity_type.entity_type_code = 'catalog_product'",
                [])

            //look for maas_updated_at
            ->join(['eav_attribute' => $this->getTable('eav_attribute')],
                "eav_attribute.attribute_code = 'maas_updated_at' and eav_attribute.entity_type_id = eav_entity_type.entity_type_id",
                [])
            ->join(
                $this->getTable('catalog_product_entity_datetime'),
                str_replace('%s', $linkField, 'catalog_product_entity_datetime.%s=catalog_product_entity.%s and catalog_product_entity_datetime.attribute_id=eav_attribute.attribute_id'),
                []
            )
            //look for maas_variation_group_id
            ->join(['eav_attribute2' => $this->getTable('eav_attribute')],
                "eav_attribute2.attribute_code = 'maas_variation_group_id' and eav_attribute2.entity_type_id = eav_entity_type.entity_type_id",
                [])
            ->joinLeft(['catalog_product_entity_text' => $this->getTable('catalog_product_entity_text')],
                str_replace('%s', $linkField, 'catalog_product_entity_text.%s = catalog_product_entity.%s and catalog_product_entity_text.attribute_id=eav_attribute2.attribute_id'),
                [])
            ->joinLeft(['catalog_product_super_link' => $this->getTable('catalog_product_super_link')],
                'catalog_product_super_link.product_id = catalog_product_entity.entity_id',
                [])
            ->joinLeft(['catalog_product_super_link2' => $this->getTable('catalog_product_super_link')],
                'catalog_product_super_link2.parent_id = catalog_product_super_link.parent_id',
                [])
            ->joinLeft(['catalog_product_entity2' => $this->getTable('catalog_product_entity')],
                "catalog_product_entity2.entity_id = catalog_product_super_link2.product_id",
                [])
            ->joinLeft(['catalog_product_entity3' => $this->getTable('catalog_product_entity')],
                'catalog_product_entity3.entity_id = catalog_product_super_link2.parent_id',
                []);
        $columns = [
            //Product columns
            'entity_id' => "entity_id",
            'sku' => "catalog_product_entity.sku",
            'parent_sku' => "catalog_product_entity3.sku",
            'parent_entity_id' => "catalog_product_super_link.parent_id",
            'brother_id' => "catalog_product_super_link2.product_id",
            'brother_sku' => "catalog_product_entity2.sku",
            'maas_updated_at' => "catalog_product_entity_datetime.value",
            'maas_variation_group_id' => "catalog_product_entity_text.value"
        ];
        if ($this->isEnterprise()) {
            $columns['row_id'] = "row_id";
            $select->join(
                ['sequence_product' => $this->getTable('sequence_product')],
                "sequence_product.sequence_value = catalog_product_entity.row_id",
                []
            );
        }

        $select->columns($columns);
        $select->where('catalog_product_entity.sku IN (?)', $productSkuList)
            ->order(new \Zend_Db_Expr("entity_id ASC, brother_id ASC"));

        return $this->getConnection()->fetchAll($select);
    }

    /**
     * @return string|null
     */
    public function createSequenceProduct()
    {
        try {
            $connection = $this->getConnection();
            $sequence_product = $connection->getTableName('sequence_product');
            $connection->insert($sequence_product, []);
            return $connection->lastInsertId($sequence_product);
        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * Check edition magento
     * @return bool
     */
    private function isEnterprise()
    {
        return ($this->getLinkField() != 'entity_id');
    }


    /**
     * Get product ids by offerId
     * @param array $offerIdList
     * @return array
     */
    public function getProductsIdsByOfferIds(array $offerIdList)
    {
        $linkField = $this->getLinkField();
        $select = $this->getConnection()->select()->from(
            ['cpe' => $this->getTable('catalog_product_entity')],
            ['entity_id']
        )->join(
            ['cpet' => $this->getTable('catalog_product_entity_text')],
            str_replace('%s', $linkField, 'cpet.%s = cpe.%s'),
            []
        )->join(
            ['eav' => $this->getTable('eav_attribute')],
            "eav.attribute_id = cpet.attribute_id AND eav.attribute_code = 'maas_offer_id'",
            []
        )->join(
            ['offer' => $this->getTable('maas_offer')],
            'offer.entity_id = cpet.value',
            ['maas_entity_id']
        )->where(
            'offer.maas_entity_id IN (?)',
            $offerIdList
        );

        if ($this->isEnterprise()) {
            $select->join(
                ['sequence_product' => $this->getTable('sequence_product')],
                "sequence_product.sequence_value = cpe.row_id",
                []
            );
        }

        $result = [];
        foreach ($this->getConnection()->fetchAll($select) as $row) {
            $result[$row['maas_entity_id']] = $row['entity_id'];
        }

        return $result;
    }
}
