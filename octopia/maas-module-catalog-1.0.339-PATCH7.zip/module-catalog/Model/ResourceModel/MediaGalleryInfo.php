<?php

namespace Maas\Catalog\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class MediaGalleryInfo
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Model\ResourceModel
 */
class MediaGalleryInfo extends AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('maas_media_gallery_info', 'value_id');
        $this->_isPkAutoIncrement = false;
    }

    /**
     * @param array $data
     * @param array $fields
     *
     * @return int
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function insertOnDuplicate(array $data, array $fields = [])
    {
        return $this->getConnection()->insertOnDuplicate($this->getMainTable(), $data, $fields);
    }

    /**
     * @param array $ids
     *
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function loadByIds(array $ids)
    {
        $select = $this->getConnection()->select()->from(
            $this->getMainTable()
        )->where(
            'value_id IN(?)',
            $ids
        );

        return $this->getConnection()->fetchAll($select);
    }
}
