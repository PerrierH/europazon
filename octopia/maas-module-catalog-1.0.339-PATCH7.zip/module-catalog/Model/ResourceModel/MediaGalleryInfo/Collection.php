<?php

namespace Maas\Catalog\Model\ResourceModel\MediaGalleryInfo;

use Maas\Catalog\Model\ResourceModel\MediaGalleryInfo as MediaGalleryInfoResourceModel;
use Maas\Catalog\Model\MediaGalleryInfo;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 *
 * @package Maas\Catalog\Model\ResourceModel\MediaGalleryInfo
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /**
     * Initialize users resource collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            MediaGalleryInfo::class,
            MediaGalleryInfoResourceModel::class
        );
    }
}
