<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Maas\Catalog\Model;

use Maas\Catalog\Api\Data\MediaGalleryInfoInterface;
use Maas\Catalog\Api\Data\MediaGalleryInfoInterfaceFactory;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryExtensionFactory;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterfaceFactory;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Attribute\Backend\Media\EntryConverterInterface;
use Magento\Catalog\Model\Product\Attribute\Backend\Media\ImageEntryConverter as MagentoImageEntryConverter;
use Magento\Framework\Api\DataObjectHelper;

/**
 * Converter for External Video media gallery type
 */
class ImageEntryConverter implements EntryConverterInterface
{
    /**
     * @var MagentoImageEntryConverter
     */
    private $converter;

    /**
     * @var ProductAttributeMediaGalleryEntryInterfaceFactory
     */
    private $mediaGalleryEntryFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var MediaGalleryInfoInterfaceFactory
     */
    private $mediaGalleryInfoFactory;

    /**
     * @var ProductAttributeMediaGalleryEntryExtensionFactory
     */
    private $mediaGalleryEntryExtensionFactory;

    /**
     * ImageEntryConverter constructor.
     *
     * @param MagentoImageEntryConverter $converter
     */
    public function __construct(
        MagentoImageEntryConverter $converter,
        ProductAttributeMediaGalleryEntryInterfaceFactory $mediaGalleryEntryFactory,
        DataObjectHelper $dataObjectHelper,
        MediaGalleryInfoInterfaceFactory $mediaGalleryInfoFactory,
        ProductAttributeMediaGalleryEntryExtensionFactory $mediaGalleryEntryExtensionFactory
    ) {
        $this->converter = $converter;
        $this->mediaGalleryEntryFactory = $mediaGalleryEntryFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->mediaGalleryInfoFactory = $mediaGalleryInfoFactory;
        $this->mediaGalleryEntryExtensionFactory = $mediaGalleryEntryExtensionFactory;
    }

    /**
     * @return string
     * @codeCoverageIgnore
     */
    public function getMediaEntryType()
    {
        return $this->converter->getMediaEntryType();
    }

    /**
     * @param Product $product
     * @param array $rowData
     *
     * @return ProductAttributeMediaGalleryEntryInterface
     * @codeCoverageIgnore
     */
    public function convertTo(Product $product, array $rowData)
    {
        $entry = $this->converter->convertTo($product, $rowData);
        $mediaGalleryInfo = $this->mediaGalleryInfoFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $mediaGalleryInfo,
            $rowData,
            MediaGalleryInfoInterface::class
        );
        $entryExtension = $this->mediaGalleryEntryExtensionFactory->create();
        $entryExtension->setMaasInfo($mediaGalleryInfo);
        $entry->setExtensionAttributes($entryExtension);
        return $entry;
    }

    /**
     * {@inheritdoc}
     */
    public function convertFrom(ProductAttributeMediaGalleryEntryInterface $entry)
    {
        $dataFromPreviewImageEntry = $this->converter->convertFrom($entry);
        $infoContent = $entry->getExtensionAttributes()->getMaasInfo();
        $entryArray = [
            'image_url' => $infoContent->getImageUrl(),
        ];
        return array_merge($dataFromPreviewImageEntry, $entryArray);
    }
}
