<?php

namespace Maas\Catalog\Model;

use Maas\Catalog\Api\Data\MediaGalleryInfoInterface;
use Maas\Catalog\Api\Data\MediaGalleryInfoSearchResultsInterfaceFactory;
use Maas\Catalog\Api\MediaGalleryInfoRepositoryInterface;
use Maas\Catalog\Model\ResourceModel\MediaGalleryInfo\CollectionFactory;
use Maas\Core\Model\AbstractRepository;

/**
 * Class MediaGalleryInfoRepository
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Model
 */
class MediaGalleryInfoRepository extends AbstractRepository implements MediaGalleryInfoRepositoryInterface
{
    /**
     * @inheritDoc
     */
    public function save(MediaGalleryInfoInterface $mediaGalleryInfo)
    {
        return $this->_save($mediaGalleryInfo);
    }

    /**
     * @inheritDoc
     */
    public function delete(MediaGalleryInfoInterface $mediaGalleryInfo)
    {
        $this->_delete($mediaGalleryInfo);
    }
}
