<?php

namespace Maas\Catalog\Model;

use Exception;
use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Maas\Catalog\Api\Data\ShippingMethodInterfaceFactory;
use Maas\Catalog\Api\ShippingAttributesManagementInterface;
use Maas\Catalog\Model\Service\ProductDelivery;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Store\Model\StoreManagerInterface;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class ShippingAttributesManagement
 *
 * @package Maas\Catalog\Model
 */
class ShippingAttributesManagement implements ShippingAttributesManagementInterface
{
    const ATTRIBUTE_NAME_PATTERN_SHIPPING_AMOUNT = 'maas_delivery_%s_cost';
    const ATTRIBUTE_NAME_PATTERN_DELIVERY_MIN_DELAY = 'maas_delivery_%s_min';
    const ATTRIBUTE_NAME_PATTERN_DELIVERY_MAX_DELAY = 'maas_delivery_%s_max';

    /**
     * @var Config
     */
    protected Config $config;

    /**
     * @var ShippingMethodInterfaceFactory
     */
    protected ShippingMethodInterfaceFactory $shippingMethodFactory;

    /**
     * @var ProductDelivery
     */
    protected ProductDelivery $productDeliveryService;

    /**
     * @var TimezoneInterface
     */
    protected TimezoneInterface $localeDate;

    /**
     * @var StoreManagerInterface
     */
    protected StoreManagerInterface $storeManager;

    /**
     * @var CollectionFactory
     */
    protected CollectionFactory $productCollectionFactory;

    /**
     * @var PriceCurrencyInterface
     */
    protected PriceCurrencyInterface $priceCurrency;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * ShippingAttributesManagement constructor.
     *
     * @param Config $config
     * @param StoreManagerInterface $storeManager
     * @param CollectionFactory $productCollectionFactory
     * @param ShippingMethodInterfaceFactory $shippingMethodFactory
     * @param ProductDelivery $productDeliveryService
     * @param TimezoneInterface $localeDate
     * @param PriceCurrencyInterface $priceCurrency
     * @param EditionInterface $edition
     */
    public function __construct(
        Config                         $config,
        StoreManagerInterface          $storeManager,
        CollectionFactory              $productCollectionFactory,
        ShippingMethodInterfaceFactory $shippingMethodFactory,
        ProductDelivery                $productDeliveryService,
        TimezoneInterface              $localeDate,
        PriceCurrencyInterface         $priceCurrency,
        EditionInterface               $edition

    )
    {
        $this->config = $config;
        $this->storeManager = $storeManager;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->shippingMethodFactory = $shippingMethodFactory;
        $this->productDeliveryService = $productDeliveryService;
        $this->localeDate = $localeDate;
        $this->priceCurrency = $priceCurrency;
        $this->edition = $edition;
    }

    /**
     * @param int[] $productIds
     * @param bool $asAssocArray
     * @param ?string $scopeCode
     *
     * @return array|Collection
     * @throws LocalizedException
     * @throws NoSuchEntityException
     *
     * @codeCoverageIgnore
     */
    public function getProductsWithDeliveryAttributes(array $productIds, bool $asAssocArray = false, string $scopeCode = null)
    {
        $storeId = $this->storeManager->getStore($scopeCode)->getId();
        $attributeCodes = $this->getUsedShipmentAttributes($scopeCode);
        $linkField = $this->edition->getLinkField();
        $productCollection = $this->productCollectionFactory->create();
        /** @var $productCollection Collection */
        $productCollection->setStoreId($storeId);

        $productCollection->joinAttribute('name', 'catalog_product/name', $linkField, null,
            'left');
        foreach ($attributeCodes as $attributeCode) {
            $productCollection->joinAttribute($attributeCode, 'catalog_product/' . $attributeCode, $linkField, null,
                'left');
        }
        $productCollection->addIdFilter($productIds);
        if ($asAssocArray) {
            $products = [];
            foreach ($productCollection as $product) {
                $products[$product->getId()] = $product;
            }
            return $products;
        } else {
            return $productCollection;
        }
    }

    /**
     * @param string|int|null $scopeCode
     *
     * @return array
     */
    public function getUsedShipmentAttributes($scopeCode = null)
    {
        $attributes = [];
        foreach (array_keys($this->config->getManagedShippingMethods($scopeCode)) as $code) {
            $attributes[] = sprintf(self::ATTRIBUTE_NAME_PATTERN_SHIPPING_AMOUNT, $code);
            $attributes[] = sprintf(self::ATTRIBUTE_NAME_PATTERN_DELIVERY_MIN_DELAY, $code);
            $attributes[] = sprintf(self::ATTRIBUTE_NAME_PATTERN_DELIVERY_MAX_DELAY, $code);
        }
        return $attributes;
    }

    /**
     * @inheritDoc
     */
    public function formatShippingMethodAndDeliveries(
        ProductInterface $product,
                         $scopeCode = null,
                         $currency = null,
                         $qty = null,
                         $includeNameInEstimate = true
    )
    {
        $methods = $this->getShippingMethodsFromEntity(
            $product,
            $scopeCode,
            $currency,
            false,
            $qty,
            $includeNameInEstimate
        );
        $minDelay = INF;
        $minDelayMethod = null;
        foreach ($methods as $method) {
            if ($method->getMinDelay() < $minDelay) {
                $minDelay = $method->getMinDelay();
                $minDelayMethod = $method;
            }
        }

        return !is_null($minDelayMethod) ? $minDelayMethod->getData('estimation') : '';

    }

    /**
     * @inheritDoc
     */
    public function getShippingMethodsFromEntity(
        ProductInterface $product,
                         $scopeCode = null,
                         $currency = null,
                         $asArrays = false,
                         $qty = null,
                         $includeNameInEstimate = false
    )
    {
        $methods = [];

        foreach ($this->config->getManagedShippingMethods() as $code => $label) {
            $baseAmount = $this->getCustomAttribute($product,
                sprintf(self::ATTRIBUTE_NAME_PATTERN_SHIPPING_AMOUNT, $code));
            $minDelay = $this->getCustomAttribute($product,
                sprintf(self::ATTRIBUTE_NAME_PATTERN_DELIVERY_MIN_DELAY, $code));
            $maxDelay = $this->getCustomAttribute($product,
                sprintf(self::ATTRIBUTE_NAME_PATTERN_DELIVERY_MAX_DELAY, $code));
            if ($baseAmount || $minDelay || $maxDelay) {

                $amount = $this->priceCurrency->convert($baseAmount, $this->storeManager->getStore($scopeCode),
                    $currency);

                /** @var ShippingMethodInterface $method */
                $method = $this->shippingMethodFactory->create();

                $method->setCode($code)->setLabel(__($label))->setBaseAmount($baseAmount)
                    ->setAmount($amount)->setMinDelay($minDelay)->setMaxDelay($maxDelay)
                    ->setProductId($product->getId());

                if ($minDelay && $maxDelay) {
                    $this->setFormattedShippingEstimation($method, $includeNameInEstimate);
                }

                if (!is_null($qty)) {
                    $method->setAmountForQty($method->getCalculatedAmountForQuantity($qty,
                        $this->storeManager->getStore($scopeCode), $currency));
                    $method->setBaseAmountForQty($method->getCalculatedBaseAmountForQuantity($qty));
                }

                $methods[$code] = $asArrays ? $method->getData() : $method;
            }
        }

        return $methods;
    }

    /**
     * @param $item
     * @param $includeNameInEstimate
     * @return array
     * @throws
     */
    public function getShippingMethodsFromQuote($item, $includeNameInEstimate = false)
    {
        $methods = [];
        foreach ($this->config->getManagedShippingMethods() as $code => $label) {
            $baseAmount = $item->getProduct()->getData(sprintf(self::ATTRIBUTE_NAME_PATTERN_SHIPPING_AMOUNT, $code));
            $minDelay = $item->getProduct()->getData(sprintf(self::ATTRIBUTE_NAME_PATTERN_DELIVERY_MIN_DELAY, $code));
            $maxDelay = $item->getProduct()->getData(sprintf(self::ATTRIBUTE_NAME_PATTERN_DELIVERY_MAX_DELAY, $code));
            if ($baseAmount || $minDelay || $maxDelay) {
                $amount = $this->priceCurrency->convert($baseAmount);
                /** @var ShippingMethodInterface $method */
                $method = $this->shippingMethodFactory->create();
                $method->setCode($code)
                    ->setLabel(__($label))
                    ->setBaseAmount($baseAmount)
                    ->setAmount($amount)
                    ->setMinDelay($minDelay)
                    ->setMaxDelay($maxDelay)
                    ->setProductId($item->getProductId());
                if ($minDelay && $maxDelay) {
                    $this->setFormattedShippingEstimation($method, $includeNameInEstimate);
                }
                $methods[$code] = $method;
            }
        }
        return $methods;
    }

    /**
     * @param ProductInterface $product
     * @param string $code
     *
     * @return string|null
     */
    public function getCustomAttribute($product, $code)
    {
        $attribute = $product->getCustomAttribute($code);
        return $attribute ? $attribute->getValue() : null;
    }

    /**
     * @param ShippingMethodInterface $method
     * @param bool $includeNameInEstimate
     *
     * @return $this
     * @throws Exception
     */
    protected function setFormattedShippingEstimation($method, $includeNameInEstimate)
    {
        if ($includeNameInEstimate) {
            $method->setEstimation(
                $this->productDeliveryService->assembleDeliveryEstimatedDatesFromDelays(
                    $method->getMinDelay(), $method->getMaxDelay(),
                    __("%5\$sDelivery between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                    $this->localeDate,
                    '<strong>' . ucfirst($method->getLabel() ?? '') . '</strong> '
                )
            );
        } else {
            $method->setEstimation(
                $this->productDeliveryService->assembleDeliveryEstimatedDatesFromDelays(
                    $method->getMinDelay(), $method->getMaxDelay(),
                    __("Delivered between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                    $this->localeDate
                )
            );
        }
        return $this;
    }
}
