<?php

namespace Maas\Catalog\Model;

use Maas\Catalog\Api\Data\ShippingMethodInterface;
use Magento\Framework\DataObject;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class ShippingMethod
 *
 * @package Maas\Catalog\Model
 * @codeCoverageIgnore
 */
class ShippingMethod extends DataObject implements ShippingMethodInterface
{
    /** @var StoreManagerInterface */
    protected $storeManager;

    /** @var PriceCurrencyInterface */
    protected $priceCurrency;

    /**
     * ShippingMethod constructor.
     *
     * @param StoreManagerInterface $storeManager
     * @param PriceCurrencyInterface $priceCurrency
     * @param array $data
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        PriceCurrencyInterface $priceCurrency,
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        $this->priceCurrency = $priceCurrency;
        parent::__construct($data);
    }

    /**
     * @inheritDoc
     */
    public function getCode()
    {
        return $this->getData(self::CODE);
    }

    /**
     * @inheritDoc
     */
    public function getLabel()
    {
        return $this->getData(self::LABEL);
    }

    /**
     * @inheritDoc
     */
    public function getAmount()
    {
        return $this->getData(self::AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function getMinDelay()
    {
        return $this->getData(self::MIN_DELAY);
    }

    /**
     * @inheritDoc
     */
    public function getMaxDelay()
    {
        return $this->getData(self::MAX_DELAY);
    }

    /**
     * @inheritDoc
     */
    public function setCode($code)
    {
        return $this->setData(self::CODE, $code);
    }

    /**
     * @inheritDoc
     */
    public function setLabel($label)
    {
        return $this->setData(self::LABEL, $label);
    }

    /**
     * @inheritDoc
     */
    public function setAmount($amount)
    {
        return $this->setData(self::AMOUNT, $amount);
    }

    /**
     * @inheritDoc
     */
    public function setBaseAmount($baseAmount)
    {
        return $this->setData(self::BASE_AMOUNT, $baseAmount);
    }

    /**
     * @inheritDoc
     */
    public function setMinDelay($minDelay)
    {
        return $this->setData(self::MIN_DELAY, $minDelay);
    }

    /**
     * @inheritDoc
     */
    public function setMaxDelay($maxDelay)
    {
        return $this->setData(self::MAX_DELAY, $maxDelay);
    }

    /**
     * @inheritDoc
     */
    public function getProductId()
    {
        return $this->getData(self::PRODUCT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * @inheritDoc
     */
    public function getEstimation()
    {
        return $this->getData(self::ESTIMATION);
    }

    /**
     * @inheritDoc
     */
    public function setEstimation($estimation)
    {
        return $this->setData(self::ESTIMATION, $estimation);
    }

    /**
     * @inheritDoc
     */
    public function getCalculatedAmountForQuantity($qty, $scopeCode, $currency)
    {
        return $this->priceCurrency->convert($this->getCalculatedBaseAmountForQuantity($qty),
            $this->storeManager->getStore($scopeCode),
            $currency);
    }

    /**
     * @inheritDoc
     */
    public function getCalculatedBaseAmountForQuantity($qty)
    {
        return $this->getBaseAmount() * $qty;
    }

    /**
     * @inheritDoc
     */
    public function getBaseAmount()
    {
        return $this->getData(self::BASE_AMOUNT);
    }

    /**
     * @inheritDoc
     */
    public function getAmountForQty()
    {
        return $this->getData(self::AMOUNT_FOR_QTY);
    }

    /**
     * @inheritDoc
     */
    public function getBaseAmountForQty()
    {
        return $this->getData(self::BASE_AMOUNT_FOR_QTY);
    }

    /**
     * @inheritDoc
     */
    public function setAmountForQty($amountForQty)
    {
        return $this->setData(self::AMOUNT_FOR_QTY, $amountForQty);
    }

    /**
     * @inheritDoc
     */
    public function setBaseAmountForQty($baseAmountForQty)
    {
        return $this->setData(self::BASE_AMOUNT_FOR_QTY, $baseAmountForQty);
    }
}
