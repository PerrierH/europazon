<?php

namespace Maas\Catalog\Model;

use Maas\Core\Model\Config as CoreConfig;

/**
 * Class Config
 *
 * @package Maas\Catalog\Model
 * @codeCoverageIgnore
 */
class Config extends CoreConfig
{
    /* Module */
    public const MAAS_CATEGORY_NAME = 'Maas_Plugin';
    public const MAAS_IS_MAAS_CATEGORY = 'maas_is_maas_category';
    public const MAAS_CATEGORY_ID = 'maas_category_id';
    public const MAAS_IS_MAAS_CATEGORY_LABEL = 'Is from Mass';
    public const MAAS_CATEGORY_ID_LABEL = 'Maas Category Id';
    public const MAAS_ERROR_CATEGORY_NAME = 'Categories in error';

    /*  System Config -> Advanced Settings */
    public const XML_PATH_MAAS_CATEGORY = 'maas_categories/general/maas_root_category';
    /* No backend configuration */
    public const XML_PATH_MAAS_MANAGED_SHIPPING_METHODS = 'maas_catalog/managed_shipping_methods';
    /* Maas Error category */
    public const XML_PATH_MAAS_ERROR_CATEGORY = 'maas_categories/general/maas_error_category';

    /* Octopia Tax Categories */
    const XML_PATH_TAX_CATEGORIES = 'maas_tax/general/tax_categories';

    // tax defaults
    const CONFIG_XML_PATH_DEFAULT_COUNTRY = 'tax/defaults/country';
    const CONFIG_XML_PATH_DEFAULT_REGION = 'tax/defaults/region';
    const CONFIG_XML_PATH_DEFAULT_POSTCODE = 'tax/defaults/postcode';

    /**
     * @return string|null
     */
    public function getMaasRootCategory()
    {
        return $this->getValue(self::XML_PATH_MAAS_CATEGORY);
    }


    /**
     * @return string|null
     */
    public function getManagedShippingMethods()
    {
        return $this->getValue(self::XML_PATH_MAAS_MANAGED_SHIPPING_METHODS);
    }

    /**
     * @return string|null
     */
    public function getMaasErrorCategory()
    {
        return $this->getValue(self::XML_PATH_MAAS_ERROR_CATEGORY);
    }

    /**
     * @return string|null
     */
    public function getTaxCategories()
    {
        return $this->getValue(self::XML_PATH_TAX_CATEGORIES);
    }

    /**
     * @param $taxCategoryLabel
     * @return string
     */
    public function getTaxCategoriesCodesFromLabel($taxCategoryLabel)
    {
        $taxCategoryLabel = str_replace(' ', '_', $taxCategoryLabel);
        $taxCategoryLabel = preg_replace('/[^a-zA-Z0-9_,]/', '_', $taxCategoryLabel);
        $taxCategoryLabel = preg_replace('/_+/', '_', $taxCategoryLabel);
        return strtolower($taxCategoryLabel);
    }

    /**
     * @param $prefix
     * @return array|string[]
     */
    public function getTaxCategoriesCodes($prefix = 'maas_')
    {
        $taxCategories = ($this->getTaxCategories())? explode(',', $this->getTaxCategories()) : [];
        foreach ($taxCategories as $index => $taxCategory) {
            if ($taxCategory) {
                $taxCategories[$index] = $prefix . $this->getTaxCategoriesCodesFromLabel($taxCategory);
            }
        }
        return $taxCategories;
    }

    /**
     * @return string|null
     */
    public function getDefaultCountry()
    {
        return $this->getValue(self::CONFIG_XML_PATH_DEFAULT_COUNTRY);
    }

    /**
     * @return string|null
     */
    public function getDefaultRegion()
    {
        return $this->getValue(self::CONFIG_XML_PATH_DEFAULT_REGION);
    }
}
