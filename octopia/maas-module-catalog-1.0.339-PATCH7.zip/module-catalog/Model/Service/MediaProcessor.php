<?php


namespace Maas\Catalog\Model\Service;


use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Gallery\Processor;

/**
 * Class MediaProcessor
 *
 * @package Maas\Catalog\Model\Service
 */
class MediaProcessor
{
    /**
     * @var Processor
     */
    private $processor;

    /**
     * MediaProcessor constructor.
     *
     * @param Processor $processor
     */
    public function __construct(
        Processor $processor
    ) {
        $this->processor = $processor;
    }

    /**
     * Update image in gallery
     *
     * @param Product $product
     * @param string $file
     * @param array $data
     *
     * @return $this
     * @codeCoverageIgnore
     */
    public function updateMassInfo(Product $product, $file, $data)
    {
        $attrCode = $this->processor->getAttribute()->getAttributeCode();
        $mediaGalleryData = $product->getData($attrCode);

        $formattedMediaGalleryData = $this->formatData($mediaGalleryData, $file, $data);

        if ($formattedMediaGalleryData !== null) {
            $product->setData($attrCode, $formattedMediaGalleryData);
        }
        return $this;
    }

    /**
     * @param $mediaGalleryData array
     * @param $file string
     * @param $data array
     *
     * @return array
     */
    public function formatData($mediaGalleryData, $file, $data)
    {
        $fieldsMap = [
            'image_url' => 'image_url',
        ];

        if (!isset($mediaGalleryData['images']) || !is_array($mediaGalleryData['images'])) {
            return null;
        }

        foreach ($mediaGalleryData['images'] as &$image) {
            if ($image['file'] == $file) {
                foreach ($fieldsMap as $mappedField => $realField) {
                    if (isset($data[$mappedField])) {
                        $image[$realField] = $data[$mappedField];
                    }
                }
            }
        }
        return $mediaGalleryData;
    }
}
