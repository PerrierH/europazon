<?php

namespace Maas\Catalog\Model\Service;

use Magento\Framework\Filter\Translit;

/**
 * Class AttributeCode
 *
 * @package Maas\Catalog\Model\Service
 */
class AttributeCode
{
    /**
     * @var Translit
     */
    protected $translit;

    /**
     * @param Translit $translit
     */
    public function __construct(
        Translit $translit
    ) {
        $this->translit = $translit;
    }

    /**
     * @param string $label
     * @param string $prefix
     */
    public function generate($label, $prefix = 'maas_')
    {
        $result = preg_replace("/[^A-Za-z0-9]/", '_', strtolower($this->translit->filter($label)));
        while(strpos($result, '__') !== false)
        {
            $result = str_replace('__', '_', $result);
        }

        return substr($prefix . trim($result, '_'), 0, 30);
    }
}