<?php

namespace Maas\Catalog\Model\Service;

use DateInterval;
use DateTime;
use Exception;
use IntlDateFormatter;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

/**
 * Class ProductDelivery
 *
 * @package Maas\Catalog\Model\Service
 */
class ProductDelivery
{
    /**
     * @param $product
     * @param TimezoneInterface $localeDate
     * @param DateTime|null $minDate
     * @param DateTime|null $maxDate
     *
     * @return false|string
     * @throws Exception
     */
    public function getDeliveryEstimatedDates(
        $product,
        TimezoneInterface $localeDate,
        DateTime $minDate = null,
        DateTime $maxDate = null,
        string $shippingMethod = null
    )
    {
        if ($shippingMethod) {
            $shippingMethod = '<strong>' . ucfirst($shippingMethod ?? '') . '</strong> ';
        } else {
            $shippingMethod = '<strong>Express<strong> ';
        }

        if (($minDate === null) && ($maxDate === null)) {
            $minDelay = $product->getMaasDeliveryExpressMin();
            $maxDelay = $product->getMaasDeliveryExpressMax();

            if ($minDelay === null) {
                $shippingMethod = '<strong>Standard</strong> ';
                $minDelay = $product->getMaasDeliveryStandardMin();
                $maxDelay = $product->getMaasDeliveryStandardMax();
            }

            if ($minDelay === null) {
                return false;
            }

            return $this->assembleDeliveryEstimatedDatesFromDelays(
                $minDelay, $maxDelay,
                __("%5\$sDelivery between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                $localeDate,
                $shippingMethod
            );
        } else {
            return $this->assembleDeliveryEstimatedDates(
                $minDate, $maxDate,
                __("%5\$sDelivery between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                $localeDate,
                $shippingMethod
            );
        }
    }

    /**
     * @param $minDelay
     * @param $maxDelay
     * @param $stringFormat
     * @param $localeDate
     * @param string $shippingMethod
     *
     * @return string
     * @throws Exception
     */
    public function assembleDeliveryEstimatedDatesFromDelays($minDelay, $maxDelay, $stringFormat, $localeDate, $shippingMethod = '')
    {
        /** @var DateTime $minDate */
        $minDate = $localeDate->date();
        $minDate->add(new DateInterval('P' . $minDelay . 'D'));
        /** @var DateTime $maxDate */
        $maxDate = $localeDate->date();
        $maxDate->add(new DateInterval('P' . $maxDelay . 'D'));

        return $this->assembleDeliveryEstimatedDates($minDate, $maxDate, $stringFormat, $localeDate, $shippingMethod);
    }

    /**
     * @param $minDate
     * @param $maxDate
     * @param $stringFormat
     * @param $localeDate
     * @param string $shippingMethod
     *
     * @return string
     */
    public function assembleDeliveryEstimatedDates($minDate, $maxDate, $stringFormat, $localeDate, $shippingMethod = '')
    {
        return sprintf(
            $stringFormat,
            __(date('l', $minDate->getTimestamp())),
            $localeDate->formatDate($minDate, IntlDateFormatter::LONG, false),
            __(date('l', $maxDate->getTimestamp())),
            $localeDate->formatDate($maxDate, IntlDateFormatter::LONG, false),
            $shippingMethod
        );
    }
}
