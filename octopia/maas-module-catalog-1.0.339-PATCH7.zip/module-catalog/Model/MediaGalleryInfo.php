<?php

namespace Maas\Catalog\Model;

use Maas\Catalog\Api\Data\MediaGalleryInfoInterface;
use Maas\Catalog\Model\ResourceModel\MediaGalleryInfo as MediaGalleryInfoResourceModel;
use Magento\Framework\Model\AbstractModel;

/**
 * Class MediaGalleryInfo
 *
 * @codeCoverageIgnore
 * @package Maas\Catalog\Model
 */
class MediaGalleryInfo extends AbstractModel implements MediaGalleryInfoInterface
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(MediaGalleryInfoResourceModel::class);
    }

    /**
     * @return int
     */
    public function getValueId()
    {
        return $this->getData('value_id');
    }

    /**
     * @param int $value_id
     *
     * @return $this
     */
    public function setValueId(int $value_id)
    {
        $this->setData('value_id', $value_id);
        return $this;
    }

    /**
     * @return string
     */
    public function getImageUrl()
    {
        return $this->getData('image_url');
    }

    /**
     * @param string|null $image_url
     * @return $this
     */
    public function setImageUrl($image_url)
    {
        $this->setData('image_url', $image_url);
        return $this;
    }

    /**
     * @return int|mixed
     */
    public function getId()
    {
        return $this->getValueId();
    }

    /**
     * Identifier setter
     *
     * @param mixed $value
     *
     * @return $this
     */
    public function setId($value)
    {
        return $this->setValueId($value);
    }
}
