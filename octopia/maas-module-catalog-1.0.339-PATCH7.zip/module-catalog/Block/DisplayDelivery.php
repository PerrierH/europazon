<?php

namespace Maas\Catalog\Block;

use Maas\Catalog\Model\Service\ProductDelivery;
use Maas\Catalog\Model\ShippingAttributesManagement;
use Maas\Core\Model\Config;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template\Context;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;


/**
 * Class DisplayDelivery
 *
 * @package Maas\Catalog\Block
 */
class DisplayDelivery extends AbstractTemplate
{
    /**
     * @var string
     */
    protected $_template = "Maas_Catalog::delivery.phtml";

    /**
     * @var string
     */
    private $delivery = '';

    /**
     * @var ShippingAttributesManagement
     */
    private $shippingAttributesManagement;

    /**
     * DisplayDelivery constructor.
     *
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param Config $config
     * @param ProductDelivery $productDeliveryService
     * @param array $data
     */
    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        Config $config,
        ShippingAttributesManagement $shippingAttributesManagement,
        array $data = []
    ) {
        $this->shippingAttributesManagement = $shippingAttributesManagement;
        parent::__construct($context, $productRepository, $config, $data);
    }

    /**
     * @return bool
     * @throws NoSuchEntityException
     */
    public function renderDelivery()
    {
        return $this->isMaasProduct() && $this->isMaasPluginEnable() && $this->displayDelivery();
    }

    /**
     * @return array|\Maas\Catalog\Api\Data\ShippingMethodInterface[]|mixed|string
     * @throws NoSuchEntityException
     */
    public function displayDelivery()
    {
        $product = $this->getProduct();
        if (empty($this->delivery) && !empty($product) && ($product->getTypeId() !== Configurable::TYPE_CODE)) {
            $this->delivery = $this->shippingAttributesManagement->formatShippingMethodAndDeliveries($product) ?? '';
        }

        return $this->delivery;
    }
}
