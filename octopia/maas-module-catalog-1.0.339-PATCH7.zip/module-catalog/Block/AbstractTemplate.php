<?php

namespace Maas\Catalog\Block;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Maas\Core\Model\Config;

/**
 * Class DisplaySeller
 *
 * @package Maas\Catalog\Block
 */
class AbstractTemplate extends Template
{
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var Config
     */
    protected $config;

    /** @var ProductInterface */
    protected $product;

    /**
     * AbstractTemplate constructor.
     *
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param Config $config
     * @param array $data
     */
    public function __construct(
        Context                    $context,
        ProductRepositoryInterface $productRepository,
        Config                     $config,
        array                      $data = []
    )
    {
        $this->config = $config;
        $this->productRepository = $productRepository;
        parent::__construct($context, $data);
    }

    /**
     * @return ProductInterface
     * @throws NoSuchEntityException
     */
    protected function getProduct()
    {
        if ($this->product === null) {
            $productId = ($this->getRequest()->getParam('product_id') ? $this->getRequest()->getParam('product_id')
                : $this->getRequest()->getParam('id'));
            $this->product = $this->productRepository->getById($productId);
        }
        return $this->product;
    }

    /**
     * @param ProductInterface $product
     *
     * @return mixed
     */
    protected function isMaasProduct()
    {
        return $this->getProduct()->getMaasIsMaasProduct();
    }

    /**
     * @return bool
     */
    protected function isMaasPluginEnable()
    {
        return $this->config->isModuleEnabled();
    }

    /**
     * @return string|null
     * @throws NoSuchEntityException
     */
    public function getProductType()
    {
        return $this->getProduct()->getTypeId();
    }
}
