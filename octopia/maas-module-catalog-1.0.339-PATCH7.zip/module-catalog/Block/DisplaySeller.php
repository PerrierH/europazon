<?php

namespace Maas\Catalog\Block;

use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class DisplaySeller
 *
 * @package Maas\Catalog\Block
 */
class DisplaySeller extends AbstractTemplate
{
    /**
     * @var string
     */
    protected $_template = "Maas_Catalog::seller.phtml";

    /**
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function displaySellerName()
    {
        $product = $this->getProduct();
        
        return !empty($product) && !$this->isConfigurable($product) ? $product->getMaasOfferSellerFrontName() : '';
    }

    /**
     * @return bool
     * @throws NoSuchEntityException
     */
    public function isRenderSellerName()
    {
        return $this->isMaasProduct() && $this->isMaasPluginEnable();
    }

    /**
     * @param $product
     *
     * @return bool
     */
    private function isConfigurable($product)
    {
        return $product->getTypeId() === Configurable::TYPE_CODE;
    }

    public function getSellerPageUrl()
    {
        return $this->_urlBuilder->getUrl(
            'seller/view',
            [
                'id' => $this->getProduct()->getMaasOfferSellerId(),
                'product' => $this->getProduct()->getId()
            ]
        );
    }
}
