<?php


namespace Maas\Catalog\Test\Unit\Model\Product\Attribute\Backend;

use Maas\Catalog\Model\Product\Attribute\Backend\Timestamp;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Eav\Model\Entity\Attribute\AbstractAttribute;
use Magento\Framework\DataObject;
use PHPUnit\Framework\TestCase;

class TimestampTest extends TestCase
{
    /**
     * @var AbstractAttribute
     */
    private $attribute;

    /**
     * @var Timestamp
     */
    private $instance;

    public function setup()
    {
        $this->attribute = AnyBuilder::createForClass(
            $this,
            AbstractAttribute::class,
            [
                'getAttributeCode' => [$this->any(), 'Attribute name', AnyBuilder::RETURN_VALUE]
            ])
            ->build();

        $this->instance = AnyBuilder::createForClass(
            $this,
            Timestamp::class,
            [
                'getAttribute' => [
                    $this->any(),
                    $this->attribute,
                    AnyBuilder::RETURN_VALUE,
                ],
                'formatDateFromTimestamp' => [
                    $this->any(),
                    function ($date) {
                        return $date;
                    },
                    AnyBuilder::RETURN_CALLBACK,
                ]
            ])
            ->setCreateAsFullMock(true)
            ->build();
    }

    /**
     * @dataProvider beforeSaveProvider
     *
     * @param $date
     * @param $expected
     */
    public function testBeforeSave($date, $expectedSetDataCall)
    {
        $dataObject = AnyBuilder::createForClass(
            $this,
            DataObject::class,
            [
                'getData' => [
                    $this->any(),
                    $date,
                    AnyBuilder::RETURN_VALUE,
                ],
                'setData' => [
                    $expectedSetDataCall,
                    null,
                    AnyBuilder::RETURN_SELF,
                ],
            ])
            ->build();

        $this->instance->beforeSave($dataObject);
    }

    public function beforeSaveProvider()
    {
        yield 'nominal case' => [
            'timestamp' => '1617005135',
            'expectedSetDataCall' => $this->once(),
        ];
        yield 'timestamp is not numeric' => [
            'timestamp' => 'not a number',
            'expectedSetDataCall' => $this->never(),
        ];
    }
}
