<?php

namespace Maas\Catalog\Test\Unit\Model\Config\Source;

use PHPUnit\Framework\TestCase;
use Maas\Catalog\Model\Config\Source\Category;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Catalog\Model\ResourceModel\Category\Collection;
use Magento\Catalog\Model\Category as ModelCategory;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;

class CategoryTest extends TestCase
{


    /**
     * @var object
     */
    private $categoryCollectionFactory;
    private $stub;
    /**
     * @var \Magento\TestFramework\Helper\ObjectManager
     */
    private $objectManagerHelper;

    public function setUp()
    {
        $this->objectManagerHelper = new ObjectManager($this);
        $this->categoryCollectionFactory = $this->createPartialMock(CollectionFactory::class, ['create']);
        $this->stub = new Category($this->categoryCollectionFactory);
    }

    public function testShouldReturnOption()
    {
        $expectedOptions = [
            [
                'value' => 2,
                'label' => 'Maas'
            ]
        ];
        $collectionCategory = $this->getMockCollectionCategory();

        $this->categoryCollectionFactory->expects($this->any())->method('create')->willReturn($collectionCategory);
        $options = $this->stub->toOptionArray();
        $this->assertEquals($expectedOptions, $options, 'Shoud retun some option');
    }

    public function testShouldReturnCategoryCollection()
    {
        $collectionCategory = $this->getMockCollectionCategory();
        $this->categoryCollectionFactory->expects($this->any())->method('create')->willReturn($collectionCategory);
        $collection = $this->stub->getCategoryCollection(true, true, true, true);
        $this->assertInstanceOf(Collection::class, $collection , 'should be a category collection');
    }

    private function getMockCollectionCategory()
    {
        $category = $this->getMockBuilder(ModelCategory::class)
            ->disableOriginalConstructor()
            ->getMock();
        $category->expects($this->any())->method('getPath')->willReturn('Category/Maas');
        $category->expects($this->any())->method('getName')->willReturn('Maas');
        $category->expects($this->any())->method('getId')->willReturn(2);

        return $this->objectManagerHelper->getCollectionMock(Collection::class, [$category]);
    }
}
