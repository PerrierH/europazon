<?php

namespace Maas\Catalog\Test\Unit\Block;

use DateInterval;
use DateTime;
use Maas\Catalog\Block\DisplayDelivery;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\Element\Template\Context;
use Maas\Core\Model\Config;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Framework\App\RequestInterface;
use Magento\Catalog\Model\Product\Type\AbstractType;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Maas\Catalog\Model\Service\ProductDelivery;

/**
 * Class DisplaySellerTest
 *
 * @package Maas\Catalog\Test\Unit\Block
 */
class ProductDeliveryTest extends TestCase
{
    /**
     * @var ProductDelivery
     */
    private $instance;

    private $objectManager;

    private $product;

    private $timezone;

    private $productGetMaasDeliveryExpressMin = 3;
    private $productGetMaasDeliveryExpressMax = 5;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->product = AnyBuilder::createForClass(
            $this,
            ProductInterface::class,
            [
                'getMaasDeliveryExpressMin' => [
                    $this->any(),
                    function () {
                        return $this->productGetMaasDeliveryExpressMin;
                    },
                    AnyBuilder::RETURN_CALLBACK

                ],
                'getMaasDeliveryExpressMax' => [
                    $this->any(),
                    function () {
                        return $this->productGetMaasDeliveryExpressMax;
                    },
                    AnyBuilder::RETURN_CALLBACK

                ]
            ]
        )->build();
        $this->timezone = AnyBuilder::createForClass(
            $this,
            TimezoneInterface::class,
            [
                'date' => [
                    $this->any(),
                    function () {
                        return new DateTime();
                    },
                    AnyBuilder::RETURN_CALLBACK
                ],
                'formatDate' => [
                    $this->any(),
                    function ($date) {
                        return date('j F Y', $date->getTimestamp());
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            ProductDelivery::class
        );
    }


    /**
     * @param $minDelay
     * @param $maxDelay
     *
     * @throws \Exception
     * @dataProvider displayDeliveryProvider
     * TODO 1671 : re-activate test
    public function testDisplayDelivery($minDelay, $maxDelay)
    {
        $this->productGetMaasDeliveryExpressMin = $minDelay;
        $this->productGetMaasDeliveryExpressMax = $maxDelay;

        if ($minDelay === null) {
            $expected = false;
        } else {
            $expectedMinDate = new DateTime();
            $expectedMinDate->add(new DateInterval('P' . $minDelay . 'D'));
            $expectedMaxDate = new DateTime();
            $expectedMaxDate->add(new DateInterval('P' . $maxDelay . 'D'));
            $expected = sprintf(
                __("%5\$sDelivery between <span class='date'>%s %s</span> and <span class='date'>%s %s</span>"),
                date('l', $expectedMinDate->getTimestamp()),
                date('j F Y', $expectedMinDate->getTimestamp()),
                date('l', $expectedMaxDate->getTimestamp()),
                date('j F Y', $expectedMaxDate->getTimestamp()),
                ''
            );
        }

        $result = $this->instance->getDeliveryEstimatedDates($this->product, $this->timezone);

        $this->assertEquals($expected, $result);
    }
    */

    public function displayDeliveryProvider()
    {
        yield from [
            [2, 5],
            [3, 7],
            [null, 5]
        ];
    }
}
