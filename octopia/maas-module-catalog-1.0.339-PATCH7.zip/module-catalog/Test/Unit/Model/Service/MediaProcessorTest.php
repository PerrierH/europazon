<?php


namespace Maas\Catalog\Test\Unit\Model\Service;


use Maas\Catalog\Model\Service\MediaProcessor;
use Magento\Catalog\Model\Product\Gallery\Processor;
use PHPUnit\Framework\TestCase;

/**
 * Class MediaProcessorTest
 *
 * @package Maas\Catalog\Test\Unit\Model\Service
 */
class MediaProcessorTest extends TestCase
{
    /**
     * @var MediaProcessor
     */
    private $mediaProcessor;

    /**
     * set up
     */
    public function setUp()
    {
        $this->mediaProcessor = $this->getMockBuilder(MediaProcessor::class)
            ->setConstructorArgs([$this->createMock(Processor::class)])
            ->setMethods()
            ->getMock();
    }

    /**
     * @dataProvider formatDataProvider
     *
     * @param $input
     * @param $expected
     */
    public function testFormatData($input, $expected)
    {
        $this->assertEquals(
            $expected,
            $this->mediaProcessor->formatData(
                $input['mediaGalleryData'], $input['file'], $input['data']
            )
        );
    }

    public function formatDataProvider()
    {
        return [
            'not images to format' => [
                [
                    'mediaGalleryData' => ['videos' => []],
                    'file' => 'file',
                    'data' => ['value' => 'test', 'image_url' => 'www.mytesturl.test/img.jpg'],
                ],
                null
            ],
            'an image needs formating' => [
                [
                    'mediaGalleryData' => [
                        'videos' => [],
                        'images' => [
                            ['value' => 'test', 'file' => 'file']
                        ],
                    ],
                    'file' => 'file',
                    'data' => ['value' => 'test2', 'image_url' => 'www.mytesturl.test/img.jpg'],
                ],
                'mediaGalleryData' => [
                    'videos' => [],
                    'images' => [
                        ['value' => 'test', 'file' => 'file', 'image_url' => 'www.mytesturl.test/img.jpg']
                    ],
                ]
            ],
        ];
    }
}
