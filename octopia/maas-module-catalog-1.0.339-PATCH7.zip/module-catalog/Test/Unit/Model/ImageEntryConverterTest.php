<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Maas\Catalog\Test\Unit\Model;

use Maas\Catalog\Api\Data\MediaGalleryInfoInterface;
use Maas\Catalog\Api\Data\MediaGalleryInfoInterfaceFactory;
use Maas\Catalog\Model\ImageEntryConverter;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryExtensionFactory;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryExtensionInterface;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface;
use Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterfaceFactory;
use Magento\Catalog\Model\Product\Attribute\Backend\Media\ImageEntryConverter as MagentoImageEntryConverter;
use Magento\Framework\Api\DataObjectHelper;
use PHPUnit\Framework\TestCase;

/**
 * Converter for External Video media gallery type
 */
class ImageEntryConverterTest extends TestCase
{
    /**
     * @var ProductAttributeMediaGalleryEntryInterfaceFactory
     */
    private $mediaGalleryEntryFactory;
    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;
    /**
     * @var MediaGalleryInfoInterfaceFactory
     */
    private $mediaGalleryInfoFactory;
    /**
     * @var ProductAttributeMediaGalleryEntryExtensionFactory
     */
    private $mediaGalleryEntryExtensionFactory;

    public function setUp()
    {
        $this->mediaGalleryEntryFactory = $this->createMock(ProductAttributeMediaGalleryEntryInterfaceFactory::class);
        $this->dataObjectHelper = $this->createMock(DataObjectHelper::class);
        $this->mediaGalleryInfoFactory = $this->createMock(MediaGalleryInfoInterfaceFactory::class);
        $this->mediaGalleryEntryExtensionFactory = $this->createMock(ProductAttributeMediaGalleryEntryExtensionFactory::class);
    }

    /**
     * @dataProvider convertFromProvider
     *
     * @param $input
     * @param $expected
     */
    public function testConvertFrom($input, $expected)
    {
        $converter = $this->createMock(MagentoImageEntryConverter::class);
        $converter->expects($this->any())->method('convertFrom')->willReturn($input['dataFromPreviewImageEntry']);

        $imageEntryConverter = $this->getMockBuilder(ImageEntryConverter::class)
            ->setConstructorArgs([
                'converter' => $converter,
                'mediaGalleryEntryFactory' => $this->mediaGalleryEntryFactory,
                'dataObjectHelper' => $this->dataObjectHelper,
                'mediaGalleryInfoFactory' => $this->mediaGalleryInfoFactory,
                'mediaGalleryEntryExtensionFactory' => $this->mediaGalleryEntryExtensionFactory,
            ])
            ->setMethods()
            ->getMock();

        $maasInfo = $this->createMock(MediaGalleryInfoInterface::class);
        $maasInfo->expects($this->any())->method('getImageUrl')->willReturn($input['imageUrl']);

        $galleryEntryExtension = $this->createMock(ProductAttributeMediaGalleryEntryExtensionInterface::class);
        $galleryEntryExtension->expects($this->any())->method('getMaasInfo')->willReturn($maasInfo);

        $entry = $this->createMock(ProductAttributeMediaGalleryEntryInterface::class);
        $entry->expects($this->any())->method('getExtensionAttributes')
            ->willReturn($galleryEntryExtension);

        $this->assertEquals($expected, $imageEntryConverter->convertFrom($entry));
    }

    public function convertFromProvider()
    {
        return [
            'maas info media convertion, nominal case' => [
                [
                    'dataFromPreviewImageEntry' => [
                        'name' => 'my image',
                        'type' => 'jpeg',
                        'size' => '200ko',
                    ],
                    'imageUrl' => 'www.my-image-url.test'
                ],
                [
                    'name' => 'my image',
                    'type' => 'jpeg',
                    'size' => '200ko',
                    'image_url' => 'www.my-image-url.test'
                ]
            ]
        ];
    }
}
