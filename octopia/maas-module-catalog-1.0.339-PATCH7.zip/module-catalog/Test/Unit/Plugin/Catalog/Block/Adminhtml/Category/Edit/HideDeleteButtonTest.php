<?php

namespace Maas\Catalog\Test\Unit\Plugin\Catalog\Block\Adminhtml\Category\Edit;

use Magento\Catalog\Block\Adminhtml\Category\Edit\DeleteButton;
use Magento\Catalog\Model\Category;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Maas\Catalog\Plugin\Catalog\Block\Adminhtml\Category\Edit\HideDeleteButton;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\MockObject\MockObject;

class HideDeleteButtonTest extends TestCase
{
    /**
     * @var HideDeleteButton
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $plugin;

    /**
     * @var DeleteButton|MockObject
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    private $subject;

    /**
     * @var Category|MockObject
     * @SuppressWarnings(PHPMD.ProtectedClassMember)
     */
    protected $categoryMock;

    /**
     * Set up
     */
    protected function setUp()
    {

        $this->subject = $this->getMockBuilder(DeleteButton::class)
            ->disableOriginalConstructor()
            ->setMethods(['getCategory'])
            ->getMock();

        $this->categoryMock = $this->createPartialMock(
            Category::class,
            ['getMaasIsMaasCategory']
        );

        $this->subject->expects($this->once())->method('getCategory')->willReturn($this->categoryMock);

        $this->plugin = (new ObjectManager($this))->getObject(
            HideDeleteButton::class,
            []
        );
    }

    public function testHideDeleteButton()
    {
        $this->categoryMock->expects($this->once())
            ->method('getMaasIsMaasCategory')
            ->willReturn(true);


        $finalResult = [];
        $result = [
            'id' => 'delete',
            'label' => __('Delete'),
            'class' => 'delete',
            'sort_order' => 10
        ];
        $this->assertEquals($finalResult, $this->plugin->afterGetButtonData($this->subject, $result));
    }

    public function testDisplayDeleteButton()
    {
        $this->categoryMock->expects($this->once())
            ->method('getMaasIsMaasCategory')
            ->willReturn(false);

        $result = [
            'id' => 'delete',
            'label' => __('Delete'),
            'class' => 'delete',
            'sort_order' => 10
        ];

        $this->assertEquals($result, $this->plugin->afterGetButtonData($this->subject, $result));
    }
}
