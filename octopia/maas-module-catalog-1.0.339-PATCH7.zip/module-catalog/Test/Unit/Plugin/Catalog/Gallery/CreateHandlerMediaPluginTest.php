<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Maas\Catalog\Test\Unit\Plugin\Catalog\Gallery;

use Maas\Catalog\Plugin\Gallery\CreateHandlerMediaPlugin;
use Maas\Catalog\Api\MediaGalleryInfoRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Gallery\CreateHandler as MagentoCreateHandler;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\MockObject\MockObject;

/**
 * Plugin for catalog product gallery create/update handlers.
 */
class CreateHandlerMediaPluginTest extends TestCase
{
    /**
     * @var MockObject
     */
    protected $createHandler;

    /**
     * @var MockObject
     */
    protected $repository;

    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->createHandler = $this->createMock(MagentoCreateHandler::class);
        $this->repository = $this->createMock(MediaGalleryInfoRepositoryInterface::class);
    }

    /**
     * @dataProvider beforeExecuteProvider
     *
     * @param array $mediaGallery
     */
    public function testBeforeExecute($mediaGallery, $expected)
    {
        $product = $this->createPartialMock(Product::class, ['getMediaGallery']);
        $product->expects($this->once())->method('getMediaGallery')->willReturn($mediaGallery);

        /** @var CreateHandlerMediaPlugin $plugin */
        $plugin = $this->objectManager->getObject(
            CreateHandlerMediaPlugin::class,
            ['repository' => $this->repository]
        );

        $plugin->BeforeExecute($this->createHandler, $product);
        $this->assertEquals($expected, $plugin->getImageToRemove());
    }

    public function beforeExecuteProvider()
    {
        return [
            'media gallery with images to delete' => [
                [
                    'images' => [
                        0 => [
                            'value_id' => 123,
                            'removed' => 1
                        ],
                        1 => [
                            'value_id' => 456,
                            'removed' => 1
                        ],
                        2 => [
                            'value_id' => 789
                        ]
                    ]
                ],
                [
                    '123' => '123',
                    '456' => '456',
                ]
            ],
            'media gallery with no images to delete' => [
                [
                    'images' => [
                        1 => [
                            'value_id' => 123,
                            'removed' => null
                        ],
                        2 => [
                            'value_id' => 456
                        ]
                    ]
                ],
                []
            ],
            'media gallery without images' => [
                [],
                []
            ],
        ];
    }
}
