<?php

namespace Maas\Catalog\Test\Unit\Block;

use DateInterval;
use DateTime;
use Maas\Catalog\Block\DisplayDelivery;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\Element\Template\Context;
use Maas\Core\Model\Config;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Framework\App\RequestInterface;
use Magento\Catalog\Model\Product\Type\AbstractType;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Stdlib\DateTime\Timezone;
use Maas\Catalog\Model\Service\ProductDelivery;

/**
 * Class DisplaySellerTest
 *
 * @package Maas\Catalog\Test\Unit\Block
 */
class DisplayDeliveryTest extends TestCase
{
    /**
     * @var MockObject
     */
    private $context;
    /**
     * @var MockObject
     */
    private $productRepositoryInterface;
    /**
     * @var MockObject
     */
    private $config;
    /**
     * @var DisplayDelivery
     */
    private $instance;
    /**
     * @var ObjectManager
     */
    private $objectManager;
    /**
     * @var MockObject
     */
    private $request;

    private $productDeliveryService;

    private $product;

    private $configIsModuleEnabled = true;
    private $productMaasIsMaasProduct = true;
    private $productGetMaasDeliveryExpressMin = 3;
    private $productDeliveryEstimatedDates;

    const DUMMYDATESSTRING1 = 'dummyDatesString1';
    const DUMMYDATESSTRING2 = 'dummyDatesString2';

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->request = AnyBuilder::createForClass(
            $this,
            RequestInterface::class
        )->build();
        $this->context = AnyBuilder::createForClass(
            $this,
            Context::class,
            [
                'getRequest' => [
                    $this->any(),
                    $this->request
                ],
                'getLocaleDate' => [
                    $this->any(),
                    AnyBuilder::createForClass(
                        $this,
                        TimezoneInterface::class
                    )->build()
                ]
            ]
        )->build();
        $this->product = AnyBuilder::createForClass(
            $this,
            ProductInterface::class,
            [
                'getMaasDeliveryExpressMin' => [
                    $this->any(),
                    function(){
                        return $this->productGetMaasDeliveryExpressMin;
                    },
                    AnyBuilder::RETURN_CALLBACK

                ],
                'getMaasDeliveryExpressMax' => [$this->any(), 5],
                'getMaasIsMaasProduct' => [
                    $this->any(),
                    function(){
                        return $this->productMaasIsMaasProduct;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->productRepositoryInterface = AnyBuilder::createForClass(
            $this,
            ProductRepository::class,
            [
                'getById' => [
                    $this->any(),
                    function () {
                        return $this->product;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->productDeliveryService = AnyBuilder::createForClass(
            $this,
            ProductDelivery::class,
            [
                'getDeliveryEstimatedDates' => [
                    $this->any(),
                    function(){
                        return $this->productDeliveryEstimatedDates;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
        $this->config = AnyBuilder::createForClass(
            $this,
            Config::class,
            [
                'isModuleEnabled' => [
                    $this->any(),
                    function(){
                        return $this->configIsModuleEnabled;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
    }

    /**
     * @dataProvider renderDeliveryProvider
     */
    public function testRenderDelivery($maasIsMaasProduct, $isModuleEnabled, $deliveryEstimatedDates, $expected){
        $this->productMaasIsMaasProduct = $maasIsMaasProduct;
        $this->configIsModuleEnabled = $isModuleEnabled;
        $this->productDeliveryEstimatedDates = $deliveryEstimatedDates;

        $this->getInstance();

        $result = $this->instance->renderDelivery();

        $this->assertEquals($expected, $result);
    }

    /** TODO 1671 : re-activate test
    public function testDisplayDelivery()
    {
        $this->productDeliveryEstimatedDates = self::DUMMYDATESSTRING1;
        $this->getInstance();
        $result = $this->instance->displayDelivery();

        $this->assertEquals(self::DUMMYDATESSTRING1, $result);

        $this->productDeliveryEstimatedDates = self::DUMMYDATESSTRING2;
        $result = $this->instance->displayDelivery();

        $this->assertEquals(self::DUMMYDATESSTRING1, $result);
    }
    */

    public function renderDeliveryProvider(){
        yield from [
            [true, true, self::DUMMYDATESSTRING1, true],
            [true, false, self::DUMMYDATESSTRING1, false],
            [false, true, self::DUMMYDATESSTRING2, false],
            [true, true, false, false]
        ];
    }

    private function getInstance()
    {
        $this->instance = $this->getMockBuilder(DisplayDelivery::class)
            ->setConstructorArgs(
                [
                    'context' => $this->context,
                    'productRepository' => $this->productRepositoryInterface,
                    'config' => $this->config,
                    'productDeliveryService' => $this->productDeliveryService,
                    'data' => []
                ]
            )
            ->setMethods(['formatDate'])
            ->getMock();
    }
}
