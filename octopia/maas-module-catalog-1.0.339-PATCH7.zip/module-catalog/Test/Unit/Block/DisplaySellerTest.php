<?php

namespace Maas\Catalog\Test\Unit\Block;

use Maas\Catalog\Block\DisplaySeller;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\View\Element\Template\Context;
use Maas\Core\Model\Config;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Magento\Framework\App\RequestInterface;
use Magento\Catalog\Model\Product\Type\AbstractType;
use Magento\Framework\Url;

/**
 * Class DisplaySellerTest
 *
 * @package Maas\Catalog\Test\Unit\Block
 */
class DisplaySellerTest extends TestCase
{
    /**
     * @var MockObject
     */
    private $context;
    /**
     * @var MockObject
     */
    private $productRepositoryInterface;
    /**
     * @var MockObject
     */
    private $config;
    /**
     * @var DisplaySeller
     */
    private $stub;
    /**
     * @var ObjectManager
     */
    private $objectManager;
    /**
     * @var MockObject
     */
    private $request;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $urlBuilder = AnyBuilder::createForClass(
            $this,
            Url::class,
            [
                'getUrl' => [
                    $this->any(),
                    function ($path, $params) {
                        $url = $path;
                        foreach ($params as $key => $value) {
                            $url .= '/' . $key . '/' . $value;
                        }
                        return $url;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $this->context = AnyBuilder::createForClass(
            $this,
            Context::class,
            [
                'getUrlBuilder' => [$this->any(), $urlBuilder]
            ]
        )->build();
        $this->productRepositoryInterface = $this->createMock(ProductRepository::class);
        $this->config = $this->createMock(Config::class);
        $this->request = $this->createMock(RequestInterface::class);
        $data = [];
        $this->stub = $this->objectManager->getObject(
            DisplaySeller::class,
            [
                'context' => $this->context,
                'productRepository' => $this->productRepositoryInterface,
                'config' => $this->config,
                '_request' => $this->request,
                $data
            ]
        );
    }

    /**
     * @return MockObject
     */
    private function initTest()
    {
        $productInterface = $this->getMockProductInterface();
        $this->request->expects($this->any())->method('getParam')->willReturn(2);
        $productInterface->expects($this->any())->method('getMaasOfferId')->willReturn(5);
        return $productInterface;
    }

    /**
     * @throws NoSuchEntityException
     */
    public function testDisplaySellerNameForSimpleProduct()
    {
        $productInterface = $this->initTest();
        $productInterface->expects($this->any())->method('getTypeId')->willReturn('simple');
        $productInterface->expects($this->any())->method('getMaasOfferSellerName')->willReturn('1001 Pneu');
        $this->productRepositoryInterface->expects($this->any())->method('getById')->willReturn($productInterface);
        $name = $this->stub->displaySellerName();
        $this->assertEquals('1001 Pneu', $name, 'should display a name');
    }

    /**
     * @throws NoSuchEntityException
     */
    public function testDisplaySellerNameForConfigurableProduct()
    {
        $product1 = $productInterface = $this->getMockProductInterface();
        $product2 = $productInterface = $this->getMockProductInterface();
        $product1->expects($this->any())->method('getMaasOfferId')->willReturn(8);
        $product1->expects($this->any())->method('getMaasOfferSellerName')->willReturn('1001 Pneu');
        $product2->expects($this->any())->method('getMaasOfferId')->willReturn(10);
        $product2->expects($this->any())->method('getMaasOfferSellerName')->willReturn('1001 Pneu');
        $productInterface = $this->initTest();
        $productType = $this->getMockAbstractType();
        $productInterface->expects($this->any())->method('getTypeId')->willReturn('configurable');
        $productType->expects($this->any())->method('getUsedProducts')->willReturn([$product1, $product2]);
        $productInterface->expects($this->any())->method('getTypeInstance')->willReturn($productType);
        $this->productRepositoryInterface->expects($this->any())->method('getById')->willReturn($productInterface);
        $name = $this->stub->displaySellerName();
        $this->assertEquals('1001 Pneu', $name, 'should display a name');
    }

    /**
     * @dataProvider shouldRenderBlock
     */
    public function testIsRenderSellerNameForProductNotMaas($moduleConfig, $isMaasProduct, $expectedValue)
    {
        $productInterface = $this->getMockProductInterface();
        $productInterface->expects($this->any())->method('getMaasIsMaasProduct')->willReturn($isMaasProduct);
        $this->config->expects($this->any())->method('isModuleEnabled')->willReturn($moduleConfig);
        $this->productRepositoryInterface->expects($this->any())->method('getById')->willReturn($productInterface);
        $isRender = $this->stub->isRenderSellerName();
        $this->assertEquals($expectedValue, $isRender);
    }

    public function testGetSellerPageUrl()
    {
        $productInterface = $this->getMockProductInterface();
        $productInterface->expects($this->any())->method('getId')->willReturn(42);
        $productInterface->expects($this->any())->method('getMaasOfferSellerId')->willReturn(27);
        $this->productRepositoryInterface->expects($this->any())->method('getById')->willReturn($productInterface);

        $url = $this->stub->getSellerPageUrl();

        $this->assertEquals('seller/view/id/27/product/42', $url);
    }


    /**
     * @return MockObject
     */
    private function getMockProductInterface()
    {
        return $this->getMockBuilder(ProductInterface::class)
            ->setMethods(['getMaasOfferId', 'getTypeInstance', 'getMaasIsMaasProduct', 'getMaasOfferSellerName','getMaasOfferSellerId'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return MockObject
     */
    private function getMockAbstractType()
    {
        return $this->getMockBuilder(AbstractType::class)
            ->setMethods(['getUsedProducts'])
            ->disableOriginalConstructor()
            ->getMockForAbstractClass();
    }

    /**
     * @return array
     */
    public function shouldRenderBlock()
    {
        return [
            'Module disabled and product is maas' => [false, true, false],
            'Module enable and product is not maas' => [true, false, false],
            'Module enable and product is maas' => [true, true, true]
        ];
    }
}
