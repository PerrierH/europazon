<?php

namespace Maas\Catalog\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\PageCache\Model\Cache\Type as CacheType;

/**
 * Class CacheClean
 */
class CacheClean implements ObserverInterface
{
    /**
     * @var CacheType
     */
    protected $cacheType;

    /**
     * @param CacheType $cacheType
     */
    public function __construct(CacheType $cacheType)
    {
        $this->cacheType = $cacheType;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $this->cleanCacheByTags($observer->getData('ids'));
    }

    /**
     * @param array $ids
     * @return void
     */
    private function cleanCacheByTags(array $ids)
    {
        if (count($ids)) {
            foreach ($ids as $id) {
                $this->cacheType->clean(\Zend_Cache::CLEANING_MODE_MATCHING_TAG, ['CAT_P_' . $id]);
            }
        }
    }
}
