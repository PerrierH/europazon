<?php

namespace Maas\Catalog\Observer;

use Exception;
use Maas\Core\Helper\Data;
use Maas\Core\Model\Config;
use Maas\Log\Model\Error as ErrorLogger;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Product\Collection as ProductCollectionObject;
use Magento\Framework\App\Cache\Frontend\Pool;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollection;
use Magento\Catalog\Model\ResourceModel\Product\Action as ProductAction;
use Magento\Indexer\Model\Indexer;
use Magento\Indexer\Model\Indexer\Collection;
use Magento\Indexer\Model\Indexer\CollectionFactory;
use Magento\Indexer\Model\IndexerFactory;

/**
 * Class DisableMaasProducts
 * @package Maas\Catalog\Observer
 * @codeCoverageIgnore
 */
class DisableMaasProducts implements ObserverInterface
{
    /**
     * @var ProductCollection
     */
    protected $productCollectionFactory;
    /**
     * @var IndexerFactory
     */
    protected $indexerFactory;
    /**
     * @var TypeListInterface
     */
    protected $cacheTypeList;
    /**
     * @var Pool
     */
    protected $cacheFrontendPool;
    /**
     * @var CollectionFactory
     */
    protected $indexerCollectionFactory;
    /**
     * @var ProductAction
     */
    private $productAction;
    /**
     * @var Config
     */
    private $config;
    /**
     * @var ErrorLogger
     */
    protected $errorLogger;

    /**
     * DisableMaasProducts constructor.
     * @param ProductCollection $productCollectionFactory
     * @param ProductAction $productAction
     * @param Config $config
     * @param ErrorLogger $errorLogger
     * @param IndexerFactory $indexerFactory
     * @param TypeListInterface $cacheTypeList
     * @param Pool $cacheFrontendPool
     * @param CollectionFactory $indexerCollectionFactory
     */
    public function __construct(
        ProductCollection $productCollectionFactory,
        ProductAction $productAction,
        Config $config,
        ErrorLogger $errorLogger,
        IndexerFactory $indexerFactory,
        TypeListInterface $cacheTypeList,
        Pool $cacheFrontendPool,
        CollectionFactory $indexerCollectionFactory
    ) {
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productAction = $productAction;
        $this->config = $config;
        $this->errorLogger = $errorLogger;
        $this->indexerFactory = $indexerFactory;
        $this->cacheFrontendPool = $cacheFrontendPool;
        $this->cacheTypeList = $cacheTypeList;
        $this->indexerCollectionFactory = $indexerCollectionFactory;
    }

    /**
     * @param Observer $observer
     * @codeCoverageIgnore
     */
    public function execute(Observer $observer)
    {
        try {
            $this->reindexProductIndexers();
            if (is_array($observer->getChangedPaths()) &&
                in_array(Data::MAAS_ENABLED, $observer->getChangedPaths()) &&
                !$this->config->isModuleEnabled()
            ) {
                $productIds = $this->getMaasProductIds();
                if (!empty($productIds)) {
                    $attributes = [
                        'status' => Status::STATUS_DISABLED
                    ];
                    $this->productAction->updateAttributes($productIds, $attributes, 0);
                    /** @var  Indexer $index */
                    $this->reindexProductIndexers();
                    $this->flushCache();
                }
            }
        } catch (Exception $e) {
            $this->errorLogger->error($e->getMessage());
        }
    }

    /**
     * flush front cache after disabling product
     */
    public function flushCache()
    {
        $_types = [
            'block_html',
            'collections',
            'full_page'
        ];

        foreach ($_types as $type) {
            $this->cacheTypeList->cleanType($type);
        }
        foreach ($this->cacheFrontendPool as $cacheFrontend) {
            $cacheFrontend->getBackend()->clean();
        }
    }

    /**
     * @return array
     */
    private function getMaasProductIds()
    {
        /** @var ProductCollectionObject $productCollection */
        $productCollection = $this->productCollectionFactory->create();
        $productCollection->addAttributeToSelect('entity_id,maas_is_maas_product');
        $productCollection->addAttributeToFilter('status', Status::STATUS_ENABLED);
        $productCollection->addAttributeToFilter('maas_is_maas_product', ['eq' => 1]);
        return $productCollection->getAllIds();
    }

    /**
     * reindex product indexers
     */
    private function reindexProductIndexers()
    {
        /** @var  Collection $indexerCollection */
        $indexerCollection = $this->indexerCollectionFactory->create();
        $allIds = $indexerCollection->getAllIds();

        foreach ($allIds as $id) {
            if (strpos($id, 'product') !== false) {
                $indexer = $this->indexerFactory->create()->load($id);
                $indexer->reindexAll();
            }
        }
    }
}
