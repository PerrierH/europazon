<?php

namespace Maas\Weee\Helper\Rewrite;

use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Quote\Model\Quote\Item\AbstractItem as QuoteAbstractItem;
use Magento\Sales\Model\Order\Item as OrderItem;

class Data extends \Magento\Weee\Helper\Data
{

    /**
     * @var Json
     */
    private $serializer = null;

    /**
     * Returns applied weee taxes
     *
     * @param QuoteAbstractItem $item
     * @return array
     */
    public function getApplied($item)
    {
        if ($item instanceof QuoteAbstractItem) {
            if ($item->getHasChildren()
                && ($item->isChildrenCalculated() || $item->getProduct()->getTypeId() === Configurable::TYPE_CODE)
            ) {
                $result = [];
                foreach ($item->getChildren() as $child) {
                    $childData = $this->getApplied($child);
                    if (is_array($childData)) {
                        $result = array_merge($result, $childData);
                    }
                }
                return $result;
            }
        }

        // if order item data is old enough then weee_tax_applied might not be valid
        $data = $item->getWeeeTaxApplied();
        if (empty($data)) {
            return [];
        }
        $serializer = $this->serializer ?: ObjectManager::getInstance()->get(Json::class);
        return $serializer->unserialize($item->getWeeeTaxApplied());
    }

    /**
     * Returns accumulated amounts for the item
     *
     * @param QuoteAbstractItem|OrderItem $item
     * @param string $functionName
     * @return float
     */
    protected function getRecursiveNumericAmount($item, $functionName)
    {
        if ($item instanceof QuoteAbstractItem || $item instanceof OrderItem) {
            if ($item->getHasChildren()
                && ($item->isChildrenCalculated() || $item->getProduct()->getTypeId() === Configurable::TYPE_CODE)
            ) {
                $result = 0;
                $children = $item instanceof OrderItem ? $item->getChildrenItems() : $item->getChildren();
                foreach ($children as $child) {
                    $childData = $this->getRecursiveNumericAmount($child, $functionName);
                    if (!empty($childData)) {
                        $result += $childData;
                    }
                }

                return $result;
            }
        }

        $data = $item->$functionName();
        if (empty($data)) {
            return 0;
        }
        return $data;
    }
}
