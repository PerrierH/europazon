<?php

namespace Maas\Payment\Model\Service;

use BadMethodCallException;
use Exception;
use Maas\Core\Model\Service\AbstractModuleDependant;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterface;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterfaceFactory;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Vault\Api\Data\PaymentTokenInterface;

/**
 * Class Braintree
 *
 * @package Maas\Payment\Model\Service
 */
class Braintree extends AbstractModuleDependant implements PaymentServiceInterface
{
    /** @var string Module used in 2.3 and lower */
    const MAGENTO_BRAINTREE_MODULE = 'Magento_Braintree';

    /** @var string class path used in 2.3 and lower */
    const MAGENTO_BRAINTREE = '\\Magento\\Braintree\\';

    /** @var string module used in 2.4 */
    const PAYPAL_BRAINTREE_MODULE = 'PayPal_Braintree';

    /** @var string class path used in for 2.4 */
    const PAYPAL_BRAINTREE = '\\Paypal\\Braintree\\';

    /** @var OrderPaymentExtensionInterfaceFactory */
    private $paymentExtensionFactory;

    /**
     * @var \Magento\Braintree\Gateway\Command\GetPaymentNonceCommand|\Paypal\Braintree\Gateway\Command\GetPaymentNonceCommand
     */
    private $delegatedGetPaymentNonceCommand;

    /** @var string */
    private $configProviderClass;

    /** @var string */
    private $dataAssignObserverClass;

    /** @var string */
    private $paypalConfigProviderClass;

    /**
     * Braintree constructor.
     *
     * @param OrderPaymentExtensionInterfaceFactory $paymentExtensionFactory
     * @param GetPaymentNonceCommand $getPaymentNonceCommand
     */
    public function __construct(
        OrderPaymentExtensionInterfaceFactory $paymentExtensionFactory
    ) {
        $this->paymentExtensionFactory = $paymentExtensionFactory;
    }

    /**
     * @param OrderInterface $firstOrder
     * @param OrderInterface $orders
     *
     * @return array
     */
    public function execute(OrderInterface $firstOrder, OrderInterface $order)
    {
        $this->initialize();
        $errorList = [];

        try {
            $paymentToken = $this->getPaymentToken($firstOrder);

            /** @var OrderInterface $order */
            $orderPayment = $order->getPayment();
            $this->setVaultPayment($orderPayment, $paymentToken);
        } catch (BadMethodCallException $e) {
            $incrementId = $order->getIncrementId();
            $errorList[$incrementId] = $e;
        } catch (Exception $e) {
            $incrementId = $order->getIncrementId();
            $errorList[$incrementId] = $e;
        }

        return $errorList;
    }

    /**
     * Returns payment token.
     *
     * @param OrderInterface $order
     *
     * @return PaymentTokenInterface
     * @throws BadMethodCallException
     */
    private function getPaymentToken(OrderInterface $order): PaymentTokenInterface
    {
        $orderPayment = $order->getPayment();
        $extensionAttributes = $this->getExtensionAttributes($orderPayment);
        $paymentToken = $extensionAttributes->getVaultPaymentToken();

        if ($paymentToken === null) {
            throw new BadMethodCallException('Vault Payment Token should be defined for placed order payment.');
        }

        return $paymentToken;
    }

    /**
     * Gets payment extension attributes.
     *
     * @param OrderPaymentInterface $payment
     *
     * @return OrderPaymentExtensionInterface
     */
    private function getExtensionAttributes(OrderPaymentInterface $payment): OrderPaymentExtensionInterface
    {
        $extensionAttributes = $payment->getExtensionAttributes();
        if (null === $extensionAttributes) {
            $extensionAttributes = $this->paymentExtensionFactory->create();
            $payment->setExtensionAttributes($extensionAttributes);
        }

        return $extensionAttributes;
    }

    /**
     * Sets vault payment method.
     *
     * @param OrderPaymentInterface $orderPayment
     * @param PaymentTokenInterface $paymentToken
     *
     * @return void
     */
    private function setVaultPayment(OrderPaymentInterface $orderPayment, PaymentTokenInterface $paymentToken)
    {
        $vaultMethod = $this->getVaultPaymentMethod(
            $orderPayment->getMethod()
        );
        $orderPayment->setMethod($vaultMethod);

        $publicHash = $paymentToken->getPublicHash();
        $customerId = $paymentToken->getCustomerId() ?? 0;

        $result = $this->delegatedGetPaymentNonceCommand->execute(
            ['public_hash' => $publicHash, 'customer_id' => $customerId]
        )
            ->get();

        $orderPayment->setAdditionalInformation(
            $this->dataAssignObserverClass::PAYMENT_METHOD_NONCE,
            $result['paymentMethodNonce']
        );
        $orderPayment->setAdditionalInformation(
            PaymentTokenInterface::PUBLIC_HASH,
            $publicHash
        );
        $orderPayment->setAdditionalInformation(
            PaymentTokenInterface::CUSTOMER_ID,
            $customerId
        );
        $orderPayment->setAdditionalInformation(
            'is_multishipping',
            1
        );
    }

    /**
     * Returns vault payment method.
     *
     * For placing sequence of orders, we need to replace the original method on the vault method.
     *
     * @param string $method
     *
     * @return string
     */
    private function getVaultPaymentMethod(string $method): string
    {
        $vaultPaymentMap = [
            $this->configProviderClass::CODE => $this->configProviderClass::CC_VAULT_CODE,
            $this->paypalConfigProviderClass::PAYPAL_CODE => $this->paypalConfigProviderClass::PAYPAL_VAULT_CODE
        ];

        return $vaultPaymentMap[$method] ?? $method;
    }

    /**
     * @inheritDoc
     */
    protected function initialize()
    {
        if (!$this->initialized) {
            parent::initialize();

            if ($this->isModuleActive(self::MAGENTO_BRAINTREE_MODULE)) {
                $braintreeNamespace = $this->objectManager->create(self::MAGENTO_BRAINTREE);
            } else {
                if ($this->isModuleActive(self::PAYPAL_BRAINTREE_MODULE)) {
                    $braintreeNamespace = $this->objectManager->create(self::PAYPAL_BRAINTREE);
                } else {
                    throw new LocalizedException(__('No supported Message Queue modules detected.'));
                }
            }

            $this->delegatedGetPaymentNonceCommand = $braintreeNamespace . 'Gateway\\Command\\GetPaymentNonceCommand';
            $this->configProviderClass = $braintreeNamespace . 'Model\\Ui\\ConfigProvider';
            $this->dataAssignObserverClass = $braintreeNamespace . 'Observer\\DataAssignObserver';
            $this->paypalConfigProviderClass = $braintreeNamespace . 'Model\\Ui\\PayPal\\ConfigProvider';
        }
    }
}
