<?php

namespace Maas\Payment\Model\Service;

use Magento\Sales\Api\Data\OrderInterface;

/**
 * Class DefaultMethod
 *
 * @package Maas\Payment\Model\Service
 */
class DefaultMethod implements PaymentServiceInterface
{

    /**
     * @param OrderInterface $firstOrder
     * @param OrderInterface $orders
     *
     * @return array
     */
    public function execute(OrderInterface $firstOrder, OrderInterface $order)
    {
        return [];
    }
}
