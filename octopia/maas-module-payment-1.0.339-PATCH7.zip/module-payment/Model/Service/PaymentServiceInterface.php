<?php

namespace Maas\Payment\Model\Service;

use Magento\Sales\Api\Data\OrderInterface;

/**
 * Interface PaymentServiceInterface
 *
 * @package Maas\Payment\Model\Service
 * @codeCoverageIgnore
 */
interface PaymentServiceInterface
{

    /**
     * @param OrderInterface $firstOrder
     * @param OrderInterface $orders
     *
     * @return array
     */
    public function execute(OrderInterface $firstOrder, OrderInterface $order);

}
