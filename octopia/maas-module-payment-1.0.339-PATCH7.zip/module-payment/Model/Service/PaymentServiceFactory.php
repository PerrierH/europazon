<?php

namespace Maas\Payment\Model\Service;

use Magento\Framework\Api\SimpleDataObjectConverter;
use Magento\Framework\ObjectManagerInterface;
use ReflectionException;

/**
 * Class PaymentServiceFactory
 *
 * @package Maas\Payment\Model\Service
 */
class PaymentServiceFactory
{

    const DEFAULT_PAYMENT_SERVICE = 'Maas\\Payment\\Model\\Service\\DefaultMethod';

    /**
     * @var ObjectManagerInterface
     */
    private $objectManager;

    /**
     * @param ObjectManagerInterface $objectManager
     */
    public function __construct(ObjectManagerInterface $objectManager)
    {
        $this->objectManager = $objectManager;
    }

    /**
     * @param string $paymentMethod
     *
     * @return PaymentServiceInterface
     */
    public function create(string $paymentMethod)
    {
        $class = 'Maas\\Payment\\Model\\Service\\' . SimpleDataObjectConverter::snakeCaseToUpperCamelCase($paymentMethod);
        try {
            $paymentService = $this->objectManager->create($class);
        } catch (ReflectionException $e) {
            $paymentService = $this->objectManager->create(self::DEFAULT_PAYMENT_SERVICE);
        }


        return $paymentService;
    }
}
