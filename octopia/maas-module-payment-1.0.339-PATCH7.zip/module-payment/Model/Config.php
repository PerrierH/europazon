<?php

namespace Maas\Payment\Model;

use Maas\Core\Model\Config as CoreConfig;

/**
 * Class Config
 *
 * @package Maas\Payment\Model
 * @codeCoverageIgnore
 */
class Config extends CoreConfig
{

}
