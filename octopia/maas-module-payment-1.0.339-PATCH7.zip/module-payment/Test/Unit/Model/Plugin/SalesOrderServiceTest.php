<?php

namespace Maas\Payment\Test\Unit\Plugin;

use Maas\Core\Test\Builder\Order\OrderBuilder;
use Maas\Payment\Plugin\SalesOrderService;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Payment\Model\Config;
use Maas\Sales\Model\Session;
use Maas\Payment\Model\Service\PaymentServiceFactory;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Service\OrderService;
use Maas\Payment\Model\Service\DefaultMethod;


class SalesOrderServiceTest extends TestCase
{

    /** @var SalesOrderService */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var Config */
    private $maasConfig;

    /** @var Session */
    private $maasSession;

    /** @var Order */
    private $firstOrderMock;

    /** @var Order */
    private $orderMock;

    /** @var OrderService */
    private $orderServiceMock;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $paymentDatas = [
            'getMethod' => [
                $this->any(),
                'braintree'
            ]
        ];

        $this->firstOrderMock = OrderBuilder::create($this)
            ->withPayment($paymentDatas)
            ->build();

        $this->orderMock = OrderBuilder::create($this)
            ->withPayment($paymentDatas)
            ->build();

        $this->maasConfig = $this->getMockBuilder(Config::class)
            ->disableOriginalConstructor()
            ->setMethods(['isModuleEnabled'])
            ->getMock();

        $this->maasSession = $this->getMockBuilder(Session::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'getFirstOrderId',
                'getFirstOrder'
            ])
            ->getMock();
        $this->maasSession->expects($this->any())->method('getFirstOrder')->willReturn($this->firstOrderMock);

        $this->orderServiceMock = AnyBuilder::createForClass(
            $this,
            OrderService::class
        )->build();

        $paymentServiceMock = AnyBuilder::createForClass(
            $this,
            DefaultMethod::class,
            [
                'execute' => [
                    $this->any(),
                    []
                ]
            ]
        )->build();

        $paymentServiceFactoryMock = AnyBuilder::createForClass(
            $this,
            PaymentServiceFactory::class,
            [
                'create' => [
                    $this->any(),
                    $paymentServiceMock
                ]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            SalesOrderService::class,
            [
                'maasConfig' => $this->maasConfig,
                'maasSession' => $this->maasSession,
                'paymentServiceFactory' => $paymentServiceFactoryMock
            ]
        );
    }

    /**
     * @dataProvider nothingToDoCases
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function testBeforePlaceNothingToDo($isModuleEnabled, $getFirstOrderId)
    {
        $this->maasConfig->expects($this->any())->method('isModuleEnabled')->willReturn($isModuleEnabled);
        $this->maasSession->expects($this->any())->method('getFirstOrderId')->willReturn($getFirstOrderId);

        $result = $this->instance->beforePlace($this->orderServiceMock, $this->orderMock);

        $this->assertNull($result);
    }

    public function testBeforePlace()
    {
        $this->maasConfig->expects($this->any())->method('isModuleEnabled')->willReturn(true);
        $this->maasSession->expects($this->any())->method('getFirstOrderId')->willReturn(42);

        $result = $this->instance->beforePlace($this->orderServiceMock, $this->orderMock);

        $this->assertEquals(true, is_array($result));
    }

    public function nothingToDoCases()
    {
        return [
            [false, null],
            [true, null],
            [false, 42]
        ];
    }
}
