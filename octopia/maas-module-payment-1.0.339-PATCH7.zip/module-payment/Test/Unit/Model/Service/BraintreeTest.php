<?php

namespace Maas\Payment\Test\Unit\Model\Service;

use Exception;
use Maas\Payment\Model\Service\Braintree;
use Magento\Braintree\Gateway\Command\GetPaymentNonceCommand;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterface;
use Magento\Sales\Model\Order;
use Magento\Vault\Model\PaymentToken;
use Magento\Vault\Api\Data\PaymentTokenInterface;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Maas\Core\Test\Builder\BuilderInterface;
use Magento\Braintree\Model\Ui\ConfigProvider;
use Magento\Braintree\Observer\DataAssignObserver;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterfaceFactory;


class BraintreeTest extends TestCase
{

    /** @var Braintree */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var Order */
    private $firstOrderMock;

    /** @var Order */
    private $orderMock;

    /** @var array */
    private $paymentAdditionalInformation = [];

    /** @var bool */
    private $throwException = false;

    /** @var string */
    private $publicHash;

    /** @var int */
    private $customerId = 0;

    private $paymentExtensionAttributesMock;

    private $getPaymentNonceCommandMock;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->publicHash = random_bytes(20);

        /** @var PaymentToken $paymentTokenMock */
        $paymentTokenMock = AnyBuilder::createForClass(
            $this,
            PaymentToken::class,
            [
                'getPublicHash' => [
                    $this->any(),
                    function () {
                        return $this->publicHash;
                    },
                    BuilderInterface::RETURN_CALLBACK
                ],
                'getCustomerId' => [
                    $this->any(),
                    function () {
                        return $this->customerId;
                    },
                    BuilderInterface::RETURN_CALLBACK
                ]
            ]
        )->build();

        $this->paymentExtensionAttributesMock = AnyBuilder::createForClass(
            $this,
            OrderPaymentExtensionInterface::class,
            [
                'getVaultPaymentToken' => [
                    $this->any(),
                    $paymentTokenMock
                ]
            ]
        )->build();

        $paymentDatas = [
            'getExtensionAttributes' => [
                $this->any(),
                $this->paymentExtensionAttributesMock
            ],
            'getMethod' => [
                $this->any(),
                ConfigProvider::CODE
            ],
            'setMethod' => [
                $this->any(),
                true
            ],
            'setAdditionalInformation' => [
                $this->any(),
                function ($p, $v) {
                    if (!$this->throwException) {
                        $this->paymentAdditionalInformation[$p] = $v;
                    } else {
                        throw new Exception('Exception message');
                    }
                },
                BuilderInterface::RETURN_CALLBACK
            ]
        ];

        $this->firstOrderMock = OrderBuilder::create($this)
            ->withPayment($paymentDatas)
            ->build();

        $this->orderMock = OrderBuilder::create($this)
            ->withPayment($paymentDatas)
            ->build();

        $this->getPaymentNonceCommandMock = AnyBuilder::createForClass(
            $this,
            GetPaymentNonceCommand::class,
            [
                'execute' => [
                    $this->any(),
                    null,
                    BuilderInterface::RETURN_SELF
                ],
                'get' => [
                    $this->any(),
                    ['paymentMethodNonce' => 'paymentMethodNonce']
                ]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            Braintree::class,
            [
                'getPaymentNonceCommand' => $this->getPaymentNonceCommandMock
            ]
        );
    }

    public function testExecute()
    {
        $this->instance->execute($this->firstOrderMock, $this->orderMock);

        $this->assertEquals('paymentMethodNonce',
            $this->paymentAdditionalInformation[DataAssignObserver::PAYMENT_METHOD_NONCE]);
        $this->assertEquals($this->publicHash, $this->paymentAdditionalInformation[PaymentTokenInterface::PUBLIC_HASH]);
        $this->assertEquals($this->customerId, $this->paymentAdditionalInformation[PaymentTokenInterface::CUSTOMER_ID]);
        $this->assertEquals(1, $this->paymentAdditionalInformation['is_multishipping']);
    }

    public function testExecuteException()
    {
        $this->throwException = true;

        $result = $this->instance->execute($this->firstOrderMock, $this->orderMock);

        $this->assertEquals(true, isset($result[$this->orderMock->getIncrementId()]));
    }

    public function testExecuteNoToken()
    {

        $this->paymentExtensionAttributesMock = AnyBuilder::createForClass(
            $this,
            OrderPaymentExtensionInterface::class,
            [
                'getVaultPaymentToken' => [
                    $this->any(),
                    null
                ]
            ]
        )->build();

        $paymentDatas = [
            'getExtensionAttributes' => [
                $this->any(),
                $this->paymentExtensionAttributesMock
            ],
            'setExtensionAttributes' => [
                $this->any(),
                true
            ],
            'getMethod' => [
                $this->any(),
                ConfigProvider::CODE
            ],
            'setMethod' => [
                $this->any(),
                true
            ],
            'setAdditionalInformation' => [
                $this->any(),
                function ($p, $v) {
                    if (!$this->throwException) {
                        $this->paymentAdditionalInformation[$p] = $v;
                    } else {
                        throw new Exception('Exception message');
                    }
                },
                BuilderInterface::RETURN_CALLBACK
            ]
        ];

        $this->firstOrderMock = OrderBuilder::create($this)
            ->withPayment($paymentDatas)
            ->build();

        $result = $this->instance->execute($this->firstOrderMock, $this->orderMock);

        $this->assertEquals(true, isset($result[$this->orderMock->getIncrementId()]));
    }

    public function testExecuteNoExtensionAttribute()
    {

        $paymentDatas = [
            'getExtensionAttributes' => [
                $this->any(),
                null
            ],
            'setExtensionAttributes' => [
                $this->any(),
                true
            ],
            'getMethod' => [
                $this->any(),
                ConfigProvider::CODE
            ],
            'setMethod' => [
                $this->any(),
                true
            ],
            'setAdditionalInformation' => [
                $this->any(),
                function ($p, $v) {
                    if (!$this->throwException) {
                        $this->paymentAdditionalInformation[$p] = $v;
                    } else {
                        throw new Exception('Exception message');
                    }
                },
                BuilderInterface::RETURN_CALLBACK
            ]
        ];

        $this->firstOrderMock = OrderBuilder::create($this)
            ->withPayment($paymentDatas)
            ->build();

        $paymentExtensionFactoryMock = AnyBuilder::createForClass(
            $this,
            OrderPaymentExtensionInterfaceFactory::class,
            [
                'create' => [
                    $this->any(),
                    $this->paymentExtensionAttributesMock
                ]
            ]
        )->build();

        $this->instance = $this->objectManager->getObject(
            Braintree::class,
            [
                'getPaymentNonceCommand' => $this->getPaymentNonceCommandMock,
                'paymentExtensionFactory' => $paymentExtensionFactoryMock
            ]
        );

        $result = $this->instance->execute($this->firstOrderMock, $this->orderMock);

        $this->assertEquals('paymentMethodNonce',
            $this->paymentAdditionalInformation[DataAssignObserver::PAYMENT_METHOD_NONCE]);
        $this->assertEquals($this->publicHash, $this->paymentAdditionalInformation[PaymentTokenInterface::PUBLIC_HASH]);
        $this->assertEquals($this->customerId, $this->paymentAdditionalInformation[PaymentTokenInterface::CUSTOMER_ID]);
        $this->assertEquals(1, $this->paymentAdditionalInformation['is_multishipping']);
    }

}
