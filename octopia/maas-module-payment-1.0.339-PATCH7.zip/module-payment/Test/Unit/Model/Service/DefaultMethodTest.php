<?php

namespace Maas\Payment\Test\Unit\Model\Service;

use Exception;
use Maas\Payment\Model\Service\DefaultMethod;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterface;
use Magento\Sales\Model\Order;
use PHPUnit\Framework\TestCase;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterfaceFactory;


class DefaultMethodTest extends TestCase
{

    /** @var DefaultMethod */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var Order */
    private $firstOrderMock;

    /** @var Order */
    private $orderMock;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->firstOrderMock = OrderBuilder::create($this)
            ->build();

        $this->orderMock = OrderBuilder::create($this)
            ->build();

        $this->instance = $this->objectManager->getObject(
            DefaultMethod::class
        );
    }

    public function testExecute()
    {
        $return = $this->instance->execute($this->firstOrderMock, $this->orderMock);

        $this->assertEquals([], $return);
    }
}
