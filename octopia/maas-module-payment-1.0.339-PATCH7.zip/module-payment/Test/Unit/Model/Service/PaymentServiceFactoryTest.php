<?php

namespace Maas\Payment\Test\Unit\Model\Service;

use Maas\Payment\Model\Service\PaymentServiceFactory;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Magento\Framework\App\ObjectManager as appObjectManager;

class PaymentServiceFactoryTest extends TestCase
{

    /** @var PaymentServiceFactory */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $objectManagerMock = $this->getMockBuilder(appObjectManager::class)
            ->setMethods(['create'])
            ->disableOriginalConstructor()
            ->getMock();
        $objectManagerMock->expects($this->any())->method('create')->willReturnCallback(function ($class) {
            return $this->objectManager->getObject($class);
        });

        $this->instance = $this->objectManager->getObject(
            PaymentServiceFactory::class,
            [
                'objectManager' => $objectManagerMock
            ]
        );
    }

    public function testCreate()
    {
        $res = $this->instance->create('test');

        $this->assertEquals('Maas\\Payment\\Model\\Service\\DefaultMethod', get_class($res));

        $res = $this->instance->create('braintree');

        $this->assertEquals('Maas\\Payment\\Model\\Service\\Braintree', get_class($res));

    }


}
