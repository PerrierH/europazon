<?php

namespace Maas\Payment\Plugin;

use Magento\Sales\Api\Data\OrderInterface;
use Maas\Payment\Model\Config;
use Maas\Sales\Model\Session;
use Maas\Payment\Model\Service\PaymentServiceFactory;
use Magento\Sales\Model\Service\OrderService;

/**
 * Class SalesOrderService
 *
 * @package Maas\Payment\Plugin
 */
class SalesOrderService
{

    /** @var Config */
    private $maasConfig;

    /** @var Session */
    private $maasSession;

    /** @var PaymentServiceFactory */
    private $paymentServiceFactory;

    /**
     * SalesOrderService constructor.
     *
     * @param Config $maasConfig
     * @param Session $maasSession
     * @param PaymentServiceFactory $paymentServiceFactory
     */
    public function __construct(
        Config $maasConfig,
        Session $maasSession,
        PaymentServiceFactory $paymentServiceFactory
    ) {
        $this->maasConfig = $maasConfig;
        $this->maasSession = $maasSession;
        $this->paymentServiceFactory = $paymentServiceFactory;
    }

    /**
     * @param OrderService $subject
     * @param OrderInterface $order
     *
     * @return mixed
     */
    public function beforePlace(
        OrderService $subject,
        OrderInterface $order
    ) {
        if ($this->maasConfig->isModuleEnabled() && ($this->maasSession->getFirstOrderId() !== null)) {
            $firstOrder = $this->maasSession->getFirstOrder();
            $paymentMethod = $firstOrder->getPayment()->getMethod();

            $paymentService = $this->paymentServiceFactory->create($paymentMethod);

            $paymentService->execute($firstOrder, $order);

            return [$order];
        } else {
            return null;
        }
    }
}
