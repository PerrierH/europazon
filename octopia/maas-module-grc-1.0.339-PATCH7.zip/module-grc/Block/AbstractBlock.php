<?php

namespace Maas\Grc\Block;

use Maas\Core\Model\TokenRepository;
use Maas\Grc\Model\Config;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Model\Order;

/**
 * Class AbstractBlock
 * No logic inside this class
 *
 * @codeCoverageIgnore
 * @package Maas\Grc\Block
 */
class AbstractBlock extends Template
{
    /** @var string */
    protected $_template = 'Maas_Grc::order/complaint/lists.phtml';

    /** @var Registry|null */
    protected $coreRegistry = null;

    /** @var TokenRepository */
    protected $tokenRepository;

    /** @var Resolver */
    protected $locale;

    /** @var HttpContext */
    protected $httpContext;

    /** @var Config */
    private $maasConfig;

    /** @var ExtensionAttributes */
    private $extensionAttributesService;

    /** @var TimezoneInterface */
    private $date;

    /**
     * AbstractBlock constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Config $config
     * @param ExtensionAttributes $extensionAttributes
     * @param TimezoneInterface $date
     * @param TokenRepository $tokenRepository
     * @param Resolver $locale
     * @param HttpContext $httpContext
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Config $config,
        ExtensionAttributes $extensionAttributes,
        TimezoneInterface $date,
        TokenRepository $tokenRepository,
        Resolver $locale,
        HttpContext $httpContext,
        array $data = []
    ) {
        $this->coreRegistry = $registry;
        $this->maasConfig = $config;
        $this->extensionAttributesService = $extensionAttributes;
        $this->date = $date;
        $this->tokenRepository = $tokenRepository;
        $this->locale = $locale;
        $this->httpContext = $httpContext;
        parent::__construct($context, $data);
    }

    /**
     * @return bool
     */
    public function isMaasOrder()
    {
        return ($this->extensionAttributesService
                ->getOrderExtensionAttributes($this->getOrder())
                ->getExtraInfo()
                ->getOrderType() == SalesOrderInfo::ORDER_TYPE_MAAS);
    }

    /**
     * @return bool
     */
    public function isMaasOrderExported()
    {
        return $this->extensionAttributesService
                ->getOrderExtensionAttributes($this->getOrder())
                ->getExtraInfo()
                ->getExported();
    }

    /**
     * Retrieve current order model instance
     *
     * @return Order
     */
    public function getOrder()
    {
        return $this->coreRegistry->registry('current_order');
    }

    /**
     * @return bool
     */
    public function isMaasEnabled()
    {
        return $this->maasConfig->isModuleEnabled();
    }


    /**
     * @param string $date
     *
     * @return string
     */
    public function getDateTime(string $date)
    {
        return $this->getDate($date) . ' - ' . $this->getTime($date);
    }

    /**
     * @param string $date
     *
     * @return string
     */
    public function getDate(string $date)
    {
        $date = $this->date->date(strtotime($date));
        return $this->formatDate($date);
    }

    /**
     * @param string $date
     *
     * @return string
     */
    public function getTime(string $date)
    {
        $date = $this->date->date(strtotime($date));
        return $this->formatTime($date);
    }


    /**
     * @return string
     */
    public function getApiUrl()
    {
        return $this->maasConfig->getGrcApiUrl();
    }

    /**
     * @return false|string
     */
    public function getLanguage()
    {
        return strstr($this->locale->getLocale(), '_', true);
    }

    /**
     * @return string
     */
    public function getSellerId()
    {
        $extension = $this->extensionAttributesService->getOrderExtensionAttributes($this->getOrder());
        return $extension->getExtraInfo()->getSellerMaasId();
    }

    /**
     * @return string
     */
    public function getCustomerId()
    {
        return $this->getOrder()->getCustomerId();
    }
}
