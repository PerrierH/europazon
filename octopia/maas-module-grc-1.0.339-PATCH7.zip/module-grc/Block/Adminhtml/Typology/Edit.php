<?php


namespace Maas\Grc\Block\Adminhtml\Typology;

use Magento\Backend\Block\Widget\Form\Container;

/**
 * Class Edit
 * @package Maas\Grc\Block\Adminhtml\Typology
 * @codeCoverageIgnore
 */
class Edit extends Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_objectId = 'status';
        $this->_controller = 'adminhtml_typology';
        $this->_blockGroup = 'Maas_Grc';
        $this->_mode = 'edit';
        $this->buttonList->remove('delete');
    }

    /**
     * Retrieve text for header element depending on loaded page
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        return __('Edit Order Typology');
    }
}
