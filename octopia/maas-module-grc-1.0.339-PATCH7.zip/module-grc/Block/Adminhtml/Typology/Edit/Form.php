<?php

namespace Maas\Grc\Block\Adminhtml\Typology\Edit;

use Maas\Grc\Api\TypologyRepositoryInterface;
use Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Framework\Data\FormFactory;
use Magento\Framework\Registry;
use Magento\Sales\Model\Order\Status;
use Magento\Framework\Data\Form as MagentoForm;
use Magento\Framework\Data\Form\Element\Fieldset as FormFieldset;

/**
 * Class Form
 * @package Maas\Grc\Block\Adminhtml\Typology\Edit
 * @codeCoverageIgnore
 */
class Form extends Generic
{
    /**
     * @var TypologyRepositoryInterface
     */
    private $typologyRepository;

    /**
     * Form constructor.
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param TypologyRepositoryInterface $typologyRepository
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        TypologyRepositoryInterface $typologyRepository,
        array $data = []
    )
    {
        $this->typologyRepository = $typologyRepository;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('edit_order_typology');
    }

    /**
     * Prepare form fields and structure
     *
     * @return \Magento\Sales\Block\Adminhtml\Order\Status\NewStatus\Form
     */
    protected function _prepareForm()
    {
        $id = $this->getRequest()->getParam('id');
        $typology = $this->typologyRepository->get($id);

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );
        $fieldset = $form->addFieldset(
            'general_fieldset',
            ['legend' => __('General')]
        );

        $form->addField(
            "entity_id",
            'hidden',
            ['name' => 'id']
        );

        $fieldset->addField(
            "enabled",
            'select',
            [
                'name' => 'enabled',
                'label' => __('Enabled'),
                'title' => __('Enabled'),
                'options' => $this->getYesNoOption(),
                'values' => '',
            ]
        );

        $this->addStoresToFieldset($typology, $form);

        if ($typology) {
            $form->addValues($typology->getData());
        }
        $form->setAction($this->getUrl('maasgrc/typology/save'));
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Add Fieldset with Store value
     *
     * @param Status $model
     * @param MagentoForm $form
     * @return void
     */
    protected function addStoresToFieldset($model, $form)
    {
        $labels = $model ? $model->getStoreValues() : [];
        if (!$this->_storeManager->isSingleStoreMode()) {
            $fieldset = $form->addFieldset(
                'store_values_fieldset',
                ['legend' => __('Store View Specific Labels'), 'class' => 'store-scope no-margin-top-tooltip']
            );
        } else {
            $fieldset = $form->addFieldset(
                'store_values_fieldset',
                ['legend' => __('Frontend Label')]
            );
            $store = $this->_storeManager->getDefaultStoreView();
            $fieldset->addField(
                "store_value_{$store->getId()}",
                'text',
                [
                    'name' => 'store_values[' . $store->getId() . ']',
                    'required' => false,
                    'label' => $store->getName(),
                    'value' => isset($labels[$store->getId()]) ? $labels[$store->getId()] : '',
                    'fieldset_html_class' => 'store'
                ]
            );
            return;
        }

        $renderer = $this->getLayout()->createBlock(Fieldset::class);
        $fieldset->setRenderer($renderer);

        $this->addWebsitesStoresToFieldset($fieldset, $labels);
    }

    /**
     * @param FormFieldset $fieldset
     * @param array $labels
     */
    private function addWebsitesStoresToFieldset($fieldset, $labels){
        foreach ($this->_storeManager->getWebsites() as $website) {
            $fieldset->addField(
                "w_{$website->getId()}_label",
                'note',
                ['label' => $website->getName(), 'fieldset_html_class' => 'website']
            );
            foreach ($website->getGroups() as $group) {
                $stores = $group->getStores();
                if (count($stores) == 0) {
                    continue;
                }
                $fieldset->addField(
                    "sg_{$group->getId()}_label",
                    'note',
                    ['label' => $group->getName(), 'fieldset_html_class' => 'store-group']
                );
                foreach ($stores as $store) {
                    $fieldset->addField(
                        "store_value_{$store->getId()}",
                        'text',
                        [
                            'name' => 'store_values[' . $store->getId() . ']',
                            'required' => false,
                            'label' => $store->getName(),
                            'value' => isset($labels[$store->getId()]) ? $labels[$store->getId()] : '',
                            'fieldset_html_class' => 'store'
                        ]
                    );
                }
            }
        }
    }

    /**
     * @param bool $defaultYes
     * @return array
     */
    private function getYesNoOption(bool $defaultYes = true)
    {
        $yesNoOptions = [
            '1' => __('Yes'),
            '0' => __('No')
        ];

        return $defaultYes
            ? $yesNoOptions
            : array_reverse($yesNoOptions);
    }
}
