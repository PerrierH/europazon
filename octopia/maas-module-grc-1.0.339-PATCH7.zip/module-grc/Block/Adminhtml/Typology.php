<?php

namespace Maas\Grc\Block\Adminhtml;

use Magento\Backend\Block\Widget\Grid\Container;

/**
 * Class Typology
 * @package Maas\Grc\Block\Adminhtml
 * @codeCoverageIgnore
 */
class Typology extends Container
{

    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_blockGroup = 'Maas_Grc';
        $this->_controller = 'adminhtml_typology';
        $this->_headerText = __('Grc Order Typology');
        parent::_construct();
        $this->buttonList->remove('add');
    }
}
