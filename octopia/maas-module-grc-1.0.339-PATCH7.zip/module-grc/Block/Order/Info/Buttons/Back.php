<?php

namespace Maas\Grc\Block\Order\Info\Buttons;

use Maas\Grc\Block\AbstractBlock;
use Magento\Framework\Phrase;

/**
 * Class Complaint
 *
 * @package Maas\Grc\Block\Order\Info\Buttons
 * @codeCoverageIgnore
 */
class Back extends AbstractBlock
{
    /**
     * @var string
     */
    protected $_template = 'Maas_Grc::order/info/buttons/back.phtml';

    /**
     * @return Phrase
     */
    public function getLabel()
    {
        return __('Back');
    }

    /**
     * Return back url for logged in and guest users
     *
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('sales/order/view', ['order_id' => $this->getOrder()->getId()]);
    }
}
