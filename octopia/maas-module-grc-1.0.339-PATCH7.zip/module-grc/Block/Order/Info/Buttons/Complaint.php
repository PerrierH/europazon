<?php

namespace Maas\Grc\Block\Order\Info\Buttons;

use Maas\Core\Model\TokenRepository;
use Maas\Grc\Block\AbstractBlock;
use Maas\Grc\Model\Config;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Phrase;
use Magento\Customer\Model\Context as CustomerContext;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\App\Http\Context as HttpContext;
use Maas\Sales\Model\Service\Data\OrderStatus;
use Maas\Grc\Model\Discussion\SearchTypologies;

/**
 * Class Complaint
 *
 * @package Maas\Grc\Block\Order\Info\Buttons
 * @codeCoverageIgnore
 */
class Complaint extends AbstractBlock
{
    /**
     * @var string
     */
    protected $_template = 'Maas_Grc::order/info/buttons/complaint.phtml';
    /** @var OrderStatus */
    private $orderStatus;
    /** @var SearchTypologies */
    private $searchTypologies;

    /**
     * Complaint constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Config $config
     * @param ExtensionAttributes $extensionAttributes
     * @param TimezoneInterface $date
     * @param TokenRepository $tokenRepository
     * @param Resolver $locale
     * @param HttpContext $httpContext
     * @param OrderStatus $orderStatus
     * @param SearchTypologies $searchTypologies
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Config $config,
        ExtensionAttributes $extensionAttributes,
        TimezoneInterface $date,
        TokenRepository $tokenRepository,
        Resolver $locale,
        HttpContext $httpContext,
        OrderStatus $orderStatus,
        SearchTypologies $searchTypologies,
        array $data = []
    ) {
        $this->orderStatus = $orderStatus;
        $this->searchTypologies = $searchTypologies;

        parent::__construct(
            $context,
            $registry,
            $config,
            $extensionAttributes,
            $date,
            $tokenRepository,
            $locale,
            $httpContext,
            $data
        );
    }

    /**
     * @return bool
     */
    public function shouldDisplay()
    {
        if (!$this->isMaasOrder() || !$this->isMaasOrderExported()) {
            return false;
        }

        $data = [
            'typologyCode' => 'order',
            'orderStatus' => $this->orderStatus->getStatusByMaasStatus($this->getOrder()->getStatus())
        ];
        $typologies = $this->searchTypologies->execute($data);
        if (is_array($typologies) && ($typologies['status'] < 400) && array_key_exists('message', $typologies)) {
            foreach ($typologies['message'] as $typology) {
                if (array_key_exists('typology', $typology) && ($typology['typology'] == 'order')) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @return false|string
     */
    public function getComplaintUrl()
    {
        if (!$this->httpContext->getValue(CustomerContext::CONTEXT_AUTH)) {
            return $this->getUrl('maasgrc/guest/complaint', ['order_id' => $this->getOrder()->getId()]);
        }
        return $this->getUrl('maasgrc/order/complaint', ['order_id' => $this->getOrder()->getId()]);
    }

    /**
     * @return Phrase
     */
    public function getLabel()
    {
        return __('Open a complaint');
    }

}
