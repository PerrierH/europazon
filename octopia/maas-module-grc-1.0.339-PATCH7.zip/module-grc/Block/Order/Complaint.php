<?php

namespace Maas\Grc\Block\Order;

use Exception;
use Maas\Core\Model\TokenRepository;
use Maas\Grc\Block\AbstractBlock;
use Maas\Grc\Model\Config;
use Maas\Grc\Model\Discussion\SearchTypologies;
use Maas\Grc\Model\Service\GetAllTypologyListDiscussions;
use Maas\Grc\Model\Typology\Source\OrderTypology;
use Maas\Sales\Model\Service\Data\OrderStatus;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\Registry;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\Template\Context;

/**
 * Class Complaint
 *
 * @package Maas\Grc\Block\Order
 * @codeCoverageIgnore
 */
class Complaint extends AbstractBlock
{
    /** @var string */
    protected $_template = 'Maas_Grc::order/complaint.phtml';

    /** @var OrderTypology */
    private $dataSource;

    /** @var OrderStatus */
    private $orderStatus;

    /** @var SearchTypologies */
    private $searchTypologies;

    /** @var GetAllTypologyListDiscussions */
    private $getDiscussionService;

    /**
     * Complaint constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Config $config
     * @param ExtensionAttributes $extensionAttributes
     * @param TimezoneInterface $date
     * @param TokenRepository $tokenRepository
     * @param Resolver $locale
     * @param HttpContext $httpContext
     * @param OrderTypology $dataSource
     * @param OrderStatus $orderStatus
     * @param SearchTypologies $searchTypologies
     * @param GetAllTypologyListDiscussions $getDiscussionService
     * @param array $data
     */
    public function __construct(
        Context             $context,
        Registry            $registry,
        Config              $config,
        ExtensionAttributes $extensionAttributes,
        TimezoneInterface   $date,
        TokenRepository     $tokenRepository,
        Resolver            $locale,
        HttpContext         $httpContext,
        OrderTypology       $dataSource,
        OrderStatus         $orderStatus,
        SearchTypologies    $searchTypologies,
        GetAllTypologyListDiscussions      $getDiscussionService,
        array               $data = []
    )
    {
        $this->dataSource = $dataSource;
        $this->orderStatus = $orderStatus;
        $this->searchTypologies = $searchTypologies;
        $this->getDiscussionService = $getDiscussionService;
        parent::__construct($context, $registry, $config, $extensionAttributes, $date, $tokenRepository, $locale,
            $httpContext, $data);
    }

    /**
     * Return back url for logged in and guest users
     *
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('sales/order/view', ['order_id' => $this->getOrder()->getId()]);
    }

    /**
     * @return array
     * @throws Exception
     */
    public function getTypologies()
    {
        $allowedTypologiyCodes = $this->getOrderStatutTypologies();
        return $this->dataSource->toOptionArray($allowedTypologiyCodes);
    }

    /**
     * @return array
     * @throws Exception
     */
    public function getOrderStatutTypologies()
    {
        $data = [
            'typologyCode' => 'order',
            'orderStatus' => "Shipped"
        ];
        $typologies = $this->searchTypologies->execute($data);
        $allDiscussions = $this->getDiscussionService->execute($this->getOrder()->getId(), $this->getOrder()->getIncrementId());
        if (($typologies != 'Error') && ($typologies['status'] < 400) && array_key_exists('message', $typologies)) {
            foreach ($typologies['message'] as $typology) {
                if (array_key_exists('typology', $typology) && ($typology['typology'] == 'order')) {
                    if(is_array($allDiscussions ) && count($allDiscussions)){
                       return array_diff($typology['subTypologyList'],$allDiscussions);
                    }else{
                       return $typology['subTypologyList'];
                    }
                }
            }
        }
        return [];
    }

    /**
     * @return void
     */
    protected function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Order # %1', $this->getOrder()->getRealOrderId()));
    }
}
