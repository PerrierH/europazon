<?php

namespace Maas\Grc\Block\Order\Complaint;

use Exception;
use Maas\Grc\Block\AbstractBlock;
use Maas\Grc\Model\Config;
use Maas\Grc\Model\Service\GetDiscussions;
use Maas\Grc\Model\Service\GetAttachments;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Maas\Core\Model\TokenRepository;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\App\Http\Context as HttpContext;

/**
 * Class Lists
 *
 * @package Maas\Grc\Block\Order\Complaint
 * @codeCoverageIgnore
 */
class Lists extends AbstractBlock
{
    /** @var string */
    protected $_template = 'Maas_Grc::order/complaint/lists.phtml';

    /** @var GetDiscussions */
    private $getDiscussionService;

    /** @var GetAttachments */
    private $getAttachmentsService;

    /**
     * @var Config
     */
    private $config;

    /**
     * Lists constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Config $config
     * @param ExtensionAttributes $extensionAttributes
     * @param GetDiscussions $getDiscussionService
     * @param GetAttachments $getAttachmentsService
     * @param TimezoneInterface $date
     * @param TokenRepository $tokenRepository
     * @param Resolver $locale
     * @param HttpContext $httpContext
     * @param array $data
     */
    public function __construct(
        Context             $context,
        Registry            $registry,
        Config              $config,
        ExtensionAttributes $extensionAttributes,
        GetDiscussions      $getDiscussionService,
        GetAttachments      $getAttachmentsService,
        TimezoneInterface   $date,
        TokenRepository     $tokenRepository,
        Resolver            $locale,
        HttpContext         $httpContext,
        array               $data = []
    )
    {
        $this->getDiscussionService = $getDiscussionService;
        $this->getAttachmentsService = $getAttachmentsService;
        $this->config = $config;
        parent::__construct(
            $context,
            $registry,
            $config,
            $extensionAttributes,
            $date,
            $tokenRepository,
            $locale,
            $httpContext,
            $data
        );
    }


    /**
     * @return array|string
     * @throws Exception
     */
    public function getDiscussions()
    {
        return $this->getDiscussionService->execute($this->getOrder()->getId(), $this->getOrder()->getIncrementId());
    }

    /**
     * @param $message
     * @return \Magento\Framework\Phrase
     */
    public function getSenderFromMessage($message)
    {
        $result = __('Unknown');
        $sellerUserType = $this->config->getCustomerContactPoint();
        if ($message['sender']['userType'] == 1) {
            $result = __('You');
        } elseif ($sellerUserType == 0) {
            $result = __('Seller');
        } elseif ($sellerUserType == 2) {
            $result = __('Customer care');
        }
        return $result;
    }

    /**
     * @param $message
     * @return bool
     */
    public function isSellerMessage($message)
    {
        $allowedMessages = [$this->config->getCustomerContactPoint(), config::SENDER_USER_ID];
        $receiver = (isset($message['receivers'])) ? current($message['receivers']) : [];
        if (in_array($message['sender']['userType'], $allowedMessages)
            && in_array($receiver['userType'], $allowedMessages)) {
            return false;
        }
        return true;
    }

    /**
     * @return array|string
     * @throws Exception
     */
    public function getAttachmentsByDiscussion($discussionId)
    {
        return $this->getAttachmentsService->execute($discussionId);
    }

    /**
     * Get Post Action URL
     *
     * @return string
     */
    public function getPostActionUrl()
    {
        return $this->getUrl('maasgrc/attachment/download');
    }

}
