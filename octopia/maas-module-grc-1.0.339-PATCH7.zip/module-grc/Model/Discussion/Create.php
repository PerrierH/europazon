<?php

namespace Maas\Grc\Model\Discussion;

use Maas\Grc\Model\AbstractApi;
use Maas\Grc\Model\Config;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class CreateMessage
 *
 * @package Maas\Grc\Model\Discussion
 */
class Create extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/discussions';

    public const API_METHOD = 'POST';

    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->orderId = $args['orderId'];
        unset($args['orderId']);

        try {
            $args['CustomerId'] = $this->customerSession->getCustomer()->getId();
            $args['typologyCode'] = 'Order';
            $args['message']['sender']['userId'] = $this->customerSession->getCustomer()->getId();
            $args['message']['sender']['userType'] = Config::SENDER_USER_ID;
            $args['message']['receivers'][0]['userId'] = $args['sellerId'];
            $args['message']['receivers'][0]['userType'] = $this->getSellerUserType();
        } catch (NoSuchEntityException $nsee) {
            // do nothing, let the API handle it
        }

        $this->setBody(
            $args
        );
        return $this->apiCall();
    }
}
