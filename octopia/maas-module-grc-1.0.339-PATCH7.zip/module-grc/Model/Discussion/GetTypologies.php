<?php

namespace Maas\Grc\Model\Discussion;

use Maas\Grc\Model\AbstractApi;

/**
 * Class CreateMessage
 *
 * @package Maas\Grc\Model\Discussion
 * @codeCoverageIgnore
 */
class GetTypologies extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/typologies?userType=%s&orderStatus=Shipped&typologyCode=Order';

    public const API_METHOD = 'GET';

    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->setArgs([
            'customer'
        ]);

        return $this->apiCall();
    }
}
