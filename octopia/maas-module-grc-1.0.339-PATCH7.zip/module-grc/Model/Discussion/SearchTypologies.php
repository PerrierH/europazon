<?php

namespace Maas\Grc\Model\Discussion;

use Maas\Grc\Model\AbstractApi;
use Zend_Json_Encoder;

/**
 * Class CreateMessage
 *
 * @package Maas\Grc\Model\Discussion
 */
class SearchTypologies extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/typologies?userType=%s&typologyCode=%s&orderStatus=%s';

    public const API_METHOD = 'GET';

    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->setArgs([
            'customer',
            $args['typologyCode'],
            $args['orderStatus']
        ]);

        return $this->apiCall();
    }
}
