<?php

namespace Maas\Grc\Model\Discussion;

use Exception;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\Grc\Model\Config as GrcConfig;
use Maas\Grc\Model\Email\Sender\GrcSender;
use Maas\ImportExport\Model\AbstractImportAdapter;
use Maas\ImportExport\Model\AbstractImportExportApi;
use Maas\ImportExport\Model\Config;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Log\Model\Report;
use Maas\Log\Model\ReportFactory;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\HTTP\ZendClientFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\OrderRepository;

class Notify extends AbstractImportExportApi
{

    public const API_REQUEST_ENDPOINT = '/discussions';

    public const MAAS_LOG_ACTION = 'Order_Notification';

    public const MAAS_LOG_MODULE = 'Maas_Grc';

    public const MAAS_LOG_OPERATION_TYPE = Report::OPERATION_TYPE_IMPORT;

    public const CSV_LOG_HEADERS = ['date', 'report_id', 'operation', 'save_time', 'total_time'];

    public const CSV_LOG_FILE_PREFIX = 'grc-orders-notification';

    const CACHE_KEY_MAAS_REPORT_ID = 'maas_grc_orders_notification_maas_report_id';

    /** @var OrderRepository */
    public $orderRepository;

    /** @var GrcSender */
    public $grcSender;

    public $grcConfig;

    /** @var OrderFactory */
    public $orderFactory;


    public $totalItemCount = 0;
    public $successItemsCount = 0;
    public $warningItemsCount = 0;
    public $errorItemsCount = 0;

    /**
     * Notify constructor.
     *
     * @param ClientFactory $httpClientFactory
     * @param Config $configProvider
     * @param SerializerInterface $serializer
     * @param TokenRepository $tokenRepository
     * @param CacheInterface $cache
     * @param DateTime $dateTime
     * @param TokenFactory $tokenFactory
     * @param ErrorLogger $errorLogger
     * @param ReportFactory $reportFactory
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ReportResource $reportResource
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterBuilder $filterBuilder
     * @param OrderRepository $orderRepository
     * @param GrcSender $grcSender
     * @param GrcConfig $grcConfig
     * @param OrderFactory $orderFactory
     * @param AbstractImportAdapter[] $adapters
     */
    public function __construct(
        ClientFactory $httpClientFactory,
        Config $configProvider,
        SerializerInterface $serializer,
        TokenRepository $tokenRepository,
        CacheInterface $cache,
        DateTime $dateTime,
        TokenFactory $tokenFactory,
        ErrorLogger $errorLogger,
        ReportFactory $reportFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        ReportCollectionFactory $reportCollectionFactory,
        ReportResource $reportResource,
        CsvLoggerManagement $csvLoggerManagement,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
        OrderRepository $orderRepository,
        GrcSender $grcSender,
        GrcConfig $grcConfig,
        OrderFactory $orderFactory,
        array $adapters = []
    ) {
        $this->orderRepository = $orderRepository;
        $this->grcSender = $grcSender;
        $this->grcConfig = $grcConfig;
        $this->orderFactory = $orderFactory;
        parent::__construct(
            $httpClientFactory,
            $configProvider,
            $serializer,
            $tokenRepository,
            $cache,
            $dateTime,
            $tokenFactory,
            $errorLogger,
            $reportFactory,
            $reportRepository,
            $reportManagement,
            $reportCollectionFactory,
            $reportResource,
            $csvLoggerManagement,
            $searchCriteriaBuilder,
            $filterBuilder,
            $adapters
        );
    }

    /**
     * @inheritDoc
     */
    public function getApiUrl()
    {
        return $this->configProvider->getGrcApiUrl();
    }

    protected function doExecute(array $args = null)
    {
        $error = false;
        $message = '';

        try {
            $date = $this->getLastReportDate();
            //Add date to args
            $params = [
                'sort' => 'createdAt',
                'updatedAtMin' => $date,
                'createdAtMax' => $date
            ];
            $pageIndex = 0;

            while (true) {
                $pageIndex++;
                $params['pageIndex'] = $pageIndex;

                //API call
                $result = $this->getApiResponse($params);

                if (array_key_exists('items', $result) && (count($result['items']) > 0)) {
                    $this->processItems($result['items']);
                } else {
                    break;
                }
            }

        } catch (Exception $e) {
            $this->report->log(__("Error while getting orders to notify"));
            $error = true;
            $message = $e->getMessage();
        }
        if (($this->errorItemsCount > 0) && ($this->errorItemsCount == $this->totalItemCount)) {
            $error = true;
        }

        return [
            'itemsCount' => $this->totalItemCount,
            'error' => $error,
            'message' => $message,
            'successItemsCount' => $this->successItemsCount,
            'warningItemsCount' => $this->warningItemsCount,
            'errorItemsCount' => $this->errorItemsCount
        ];
    }

    public function getLastReportDate()
    {
        //Get latest report
        /** @var Report $lastReport */
        $lastReport = $this->getLastReport();
        if ($lastReport->getId()) {
            $dt = strtotime($lastReport->getUpdatedAt());
        } else {
            $dt = strtotime(date('Y-m-d H:i:s') . ' -1 hour');
        }
        //Extract date time
        return date("Y-m-d\TH:i:s.000\Z", $dt);
    }

    public function processItems($items)
    {
        $this->totalItemCount += count($items);
        if ($this->totalItemCount > 0) {
            foreach ($items as $item) {
                $incrementId = $item['orderReference'];
                $this->report->log(sprintf('New message for the orderReference "%s"', $incrementId));
                $order = $this->getOrder($incrementId);
                if ($order !== null) {
                    $res = $this->grcSender->send($order);
                    if ($res) {
                        $this->successItemsCount += 1;
                        $this->report->log(sprintf('Email sent to the client for order "%s"',
                            $incrementId));
                    } else {
                        $this->errorItemsCount += 1;
                        $this->report->log(sprintf('Email not sent to the client for order "%s"',
                            $incrementId));
                    }
                } else {
                    $this->warningItemsCount += 1;
                    $this->report->log(sprintf('No order found with incrementId "%s"',
                        $incrementId));
                }
            }
        }
    }

    /**
     * @param array $items
     */
    public function getOrder($value)
    {
        $order = $this->orderFactory->create();
        $order->loadByIncrementId($value);
        if ($order->getId() !== null) {
            return $order;
        }
        return null;
    }
}
