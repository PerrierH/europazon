<?php

namespace Maas\Grc\Model\Discussion;

use Maas\Grc\Model\AbstractApi;

/**
 * Class Search
 *
 * @package Maas\Grc\Model\Discussion
 */
class Search extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/discussions?orderReference=%s&sort=%s&pageSize=%s';

    public const API_METHOD = 'GET';

    const PAGE_SIZE = 10;

    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->orderId = $args['orderId'];

        $this->setArgs([
            $args['orderReference'],
            'desc:updatedAt',
            self::PAGE_SIZE
        ]);

        return $this->apiCall();
    }
}
