<?php

namespace Maas\Grc\Model;

use Exception;
use Maas\Grc\Model\ResourceModel\Typology\Collection;
use Maas\Grc\Api\Data\TypologyInterface;
use Maas\Grc\Api\Data\TypologySearchResultsInterface;
use Maas\Grc\Api\TypologyRepositoryInterface;
use Maas\Grc\Model\ResourceModel\Typology\CollectionFactory as TypologyCollectionFactory;
use Maas\Grc\Model\ResourceModel\Typology as TypologyResource;
use Maas\Grc\Model\TypologyFactory as ModelTypologyFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Maas\Grc\Api\Data\TypologySearchResultsInterfaceFactory;

/**
 * Class TypologyRepository
 * @codeCoverageIgnore
 * @package Maas\Grc\Model
 * @codeCoverageIgnore
 */
class TypologyRepository implements TypologyRepositoryInterface
{
    /**
     * @var TypologyResource
     */
    protected $typologyResource;

    /**
     * @var TypologyCollectionFactory
     */
    protected $typologyCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var TypologyFactory
     */
    protected $modelTypologyFactory;

    /**
     * @var TypologySearchResultsInterfaceFactory
     */
    protected $typologySearchResultsInterfaceFactory;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * TypologyRepository constructor.
     * @param TypologyResource                      $typologyResource
     * @param TypologyCollectionFactory             $typologyCollectionFactory
     * @param CollectionProcessorInterface          $collectionProcessor
     * @param TypologyFactory                       $modelTypologyFactory
     * @param TypologySearchResultsInterfaceFactory $typologySearchResultsInterfaceFactory
     * @param SearchCriteriaBuilder                 $searchCriteriaBuilder
     */
    public function __construct(
        TypologyResource $typologyResource,
        TypologyCollectionFactory $typologyCollectionFactory,
        CollectionProcessorInterface $collectionProcessor,
        ModelTypologyFactory $modelTypologyFactory,
        TypologySearchResultsInterfaceFactory $typologySearchResultsInterfaceFactory,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->typologyResource = $typologyResource;
        $this->typologyCollectionFactory = $typologyCollectionFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->modelTypologyFactory = $modelTypologyFactory;
        $this->typologySearchResultsInterfaceFactory = $typologySearchResultsInterfaceFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * @param TypologyInterface $typology
     *
     * @return TypologyInterface
     * @throws AlreadyExistsException
     */
    public function save(TypologyInterface $typology)
    {
        $this->typologyResource->save($typology);
        return $typology;
    }

    /**
     * @param int $id
     *
     * @return TypologyInterface
     */
    public function get($id)
    {
        $typology = $this->modelTypologyFactory->create();
        $this->typologyResource->load($typology, $id);
        return $typology;
    }

    /**
     * @param TypologyInterface $typology
     *
     * @throws Exception
     */
    public function delete(TypologyInterface $typology)
    {
        $this->typologyResource->delete($typology);
    }

    /**
     * @param int $id
     *
     * @throws Exception
     */
    public function deleteById($id)
    {
        $typology = $this->get($id);
        $this->typologyResource->delete($typology);
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return TypologySearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var TypologySearchResultsInterface $typologySearchResults */
        $typologySearchResults = $this->typologySearchResultsInterfaceFactory->create();

        $collection = $this->typologyCollectionFactory->create();
        $this->collectionProcessor->process($searchCriteria, $collection);
        $collection->load();
        /** @var $typologySearchResults Collection */
        $typologySearchResults->setItems($collection->getItems());
        $typologySearchResults->setSearchCriteria($searchCriteria);
        $typologySearchResults->setTotalCount($collection->getSize());
        return $typologySearchResults;
    }

    /**
     * @return \Magento\Framework\DataObject[]
     */
    public function getTypologyWithMissingValue()
    {
        /** @var \Maas\Grc\Model\ResourceModel\Typology\Collection $collection */
        $collection = $this->typologyCollectionFactory->create();
        $collection->getTypologyWithMissingStoreValue();
        return $collection->getItems();
    }

    /**
     * @return bool
     */
    public function hasTypologyWithMissingValue()
    {
        return (count($this->getTypologyWithMissingValue()) > 0) ? true : false;
    }
}
