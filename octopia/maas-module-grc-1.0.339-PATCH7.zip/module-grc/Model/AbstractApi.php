<?php

namespace Maas\Grc\Model;

use Exception;
use Maas\Core\Model\Http\ClientFactory;
use Maas\Core\Model\TokenFactory;
use Maas\Core\Model\TokenRepository;
use Maas\Grc\Model\Config as GrcConfig;
use Maas\ImportExport\Model\AbstractApi as ImportExportAbstractApi;
use Maas\ImportExport\Model\Config as ImportExportConfig;
use Maas\Log\Model\Debug as DebugLogger;
use Maas\Log\Model\Error as ErrorLogger;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\HTTP\ZendClientFactory;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime\Proxy as DateTime;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;

/**
 * Class AbstractApi
 *
 * @package Maas\Grc\Model
 */
abstract class AbstractApi extends ImportExportAbstractApi
{
    public const API_METHOD = 'GET';

    /** @var int */
    public $orderId;

    /** @var Config */
    protected $config;

    /** @var CustomerSession */
    protected $customerSession;
    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;
    /**
     * @var ExtensionAttributes
     */
    protected $extensionAttributesService;

    /** @var Resolver */
    private $locale;

    /** @var Registry */
    private $coreRegistry = null;

    /** @var DebugLogger */
    private $debugLogger;

    /**
     * AbstractApi constructor.
     *
     * @param ClientFactory $httpClientFactory
     * @param ImportExportConfig $configProvider
     * @param SerializerInterface $serializer
     * @param TokenRepository $tokenRepository
     * @param CacheInterface $cache
     * @param DateTime $dateTime
     * @param TokenFactory $tokenFactory
     * @param ErrorLogger $errorLogger
     * @param Config $config
     * @param Resolver $locale
     * @param Registry $registry
     * @param CustomerSession $customerSession
     * @param OrderRepositoryInterface $orderRepository
     * @param ExtensionAttributes $extensionAttributesService
     */
    public function __construct(
        ClientFactory $httpClientFactory,
        ImportExportConfig $configProvider,
        SerializerInterface $serializer,
        TokenRepository $tokenRepository,
        CacheInterface $cache,
        DateTime $dateTime,
        TokenFactory $tokenFactory,
        ErrorLogger $errorLogger,
        GrcConfig $config,
        Resolver $locale,
        Registry $registry,
        CustomerSession $customerSession,
        OrderRepositoryInterface $orderRepository,
        ExtensionAttributes $extensionAttributesService,
        DebugLogger $debugLogger
    ) {
        $this->config = $config;
        $this->locale = $locale;
        $this->coreRegistry = $registry;
        $this->customerSession = $customerSession;
        $this->orderRepository = $orderRepository;
        $this->extensionAttributesService = $extensionAttributesService;
        $this->debugLogger = $debugLogger;

        parent::__construct($httpClientFactory, $configProvider, $serializer, $tokenRepository, $cache, $dateTime,
            $tokenFactory, $errorLogger);

    }

    /**
     * @param array|null $args
     *
     * @return array
     * @throws Exception
     */
    public function execute(array $args = null)
    {
        $this->setHeaders([
            'Accept-Language: ' . $this->getLanguage(),
            'Content-Type: application/json'
        ]);

        return $this->doExecute($args);
    }

    /**
     * @return false|string
     */
    public function getLanguage()
    {
        return strstr($this->locale->getLocale(), '_', true);
    }

    /**
     * abstract function apiCall to process the Api calls
     *
     * @return array
     */
    public function apiCall()
    {
        try {
            $logData = [
                'orderId' => $this->orderId,
                'url' => $this->getEndPointUrl(),
                'headers' => $this->headers,
                'data' => $this->serializer->serialize($this->body),
            ];

            $token = $this->getToken();
            $tokenType = $token->getTokenType();
            $accessToken = $token->getAccessToken();
            $this->addHeader("Authorization: $tokenType $accessToken");
            $apiResponse = $this->doRequest($this->getEndPointUrl(), static::API_METHOD, $this->headers, $this->body);
            try {
                $response = [
                    'message' => $this->serializer->unserialize($apiResponse['response']),
                    'status' => $apiResponse['status']
                ];
            } catch (Exception $e) {
                $response = [
                    'message' => $apiResponse['response'],
                    'status' => $apiResponse['status']
                ];
            }

            $logData['response'] = [
                'code' => $apiResponse['status'],
                'message' => $apiResponse['response']
            ];

        } catch (AuthenticationException $ex) {
            $logData['response'] = [
                'message' => $ex->getMessage(),
                'code' => $ex->getCode()
            ];
            $response = __('authentication error');
        } catch (Exception $ex) {
            $logData['response'] = [
                'message' => $ex->getMessage(),
                'code' => $ex->getCode()
            ];
            $response = 'Error';
        }

        $this->debug($logData);

        return $response;

    }

    /**
     * @return string
     */
    public function getEndPointUrl()
    {
        $args = ($this->args) ? vsprintf(static::API_REQUEST_ENDPOINT, $this->args) : static::API_REQUEST_ENDPOINT;
        return $this->configProvider->getGrcApiUrl() . $args;
    }

    /**
     * @param $header
     *
     * @return $this
     */
    public function addHeader($header)
    {
        $this->headers[] = $header;

        return $this;
    }

    /**
     * @param array $logData
     */
    public function debug(array $logData)
    {
        if (isset($logData['url']) && ((function_exists('str_contains') &&
                str_contains($logData['url'], '/attachments')) ||
            (function_exists('strpos') &&
                strpos($logData['url'], '/attachments') !== false))
        ) {
            return; // not log attachment data
        }
        $data = sprintf(
            '%s: %s -  %s',
            $logData['response']['code'],
            $logData['response']['message'],
            $this->serializer->serialize(
                [
                    'url' => isset($logData['url']) ? $logData['url'] : '',
                    'headers' => isset($logData['headers']) ? $logData['headers'] : '',
                    'body' => isset($logData['data']) ? $logData['data'] : '',
                    'response' => $logData['response']
                ]
            )
        );

        $this->debugLogger->debug($data);
    }

    /**
     * Retrieve current order model instance
     *
     * @return Order
     */
    public function getOrder()
    {
        return $this->coreRegistry->registry('current_order');
    }

    /**
     * Get Seller User Type
     *
     * @return int
     */
    public function getSellerUserType(): int
    {
        return $this->config->getCustomerContactPoint();
    }
}
