<?php
namespace Maas\Grc\Model;

use Maas\Grc\Api\Data\TypologyInterface;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManager;

/**
 * Class Typology
 *
 * @package Maas\Grc\Model
 * @codeCoverageIgnore
 */
class Typology extends AbstractModel implements TypologyInterface
{
    /** @var StoreManager  */
    private $storeManager;

    /**
     * Typology constructor.
     * @param Context               $context
     * @param Registry              $registry
     * @param StoreManager          $storeManager
     * @param AbstractResource|null $resource
     * @param AbstractDb|null       $resourceCollection
     * @param array                 $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        StoreManager $storeManager,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    protected function _construct()
    {
        $this->_init('Maas\Grc\Model\ResourceModel\Typology');
    }

    /**
     * @return string|null
     */
    public function getMaasCode()
    {
        return $this->_getData(self::MAAS_CODE);
    }

    /**
     * @param string $code
     *
     * @return $this
     */
    public function setMaasCode($code)
    {
        return $this->setData(self::MAAS_CODE, $code);
    }

    /**
     * @return array|null
     */
    public function getStoreValues()
    {
        return $this->getData(self::STORE_VALUES);
    }

    public function getStoreValue($storeId = null)
    {
        if(is_null($storeId)) {
            $storeId = $this->storeManager->getStore()->getId();
        }

        $storeValues = $this->getStoreValues();
        if (array_key_exists($storeId, $storeValues)) {
            return $storeValues[$storeId];
        }
        return null;
    }

    /**
     * @param array $storeValues
     * @return \Maas\Grc\Api\Data\this
     */
    public function setStoreValues($storeValues)
    {
        return $this->setData(self::STORE_VALUES, $storeValues);
    }

    /**
     * @return bool|null
     */
    public function getEnabled()
    {
        return $this->getData(self::ENABLED);
    }

    /**
     * @param bool $storeValues
     * @return \Maas\Grc\Api\Data\this|Typology
     */
    public function setEnabled($enabled)
    {
        return $this->setData(self::ENABLED, $enabled);
    }
}
