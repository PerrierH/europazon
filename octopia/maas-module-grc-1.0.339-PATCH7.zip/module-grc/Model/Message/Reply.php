<?php

namespace Maas\Grc\Model\Message;

use Maas\Grc\Model\AbstractApi;
use Maas\Grc\Model\Config;

/**
 * Class Reply
 *
 * @package Maas\Grc\Model\Message
 */
class Reply extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/messages';

    public const API_METHOD = 'POST';

    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->orderId = $args['orderId'];
        unset($args['orderId']);

        $args['sender']['userId'] = $this->customerSession->getCustomer()->getId();
        $args['sender']['userType'] = Config::SENDER_USER_ID;
        $args['receivers'][0]['userType'] = $this->getSellerUserType();
        $args['receivers'][0]['userId'] = $args['sellerId'];
        unset($args['sellerId']);
        $this->setBody(
            $args
        );
        return $this->apiCall();
    }
}
