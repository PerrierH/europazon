<?php

namespace Maas\Grc\Model\Message;

use Maas\Grc\Model\AbstractApi;

/**
 * Class Messages
 *
 * @package Maas\Grc\Model\Message
 */
class Get extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/messages?discussionId=%s&sort=%s';

    public const API_METHOD = 'GET';

    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->orderId = $this->getOrder()->getId();

        $this->setArgs([
            $args['id'],
            'createdAt'
        ]);
        return $this->apiCall();
    }
}
