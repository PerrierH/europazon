<?php

namespace Maas\Grc\Model\Typology\Source;

use Maas\Grc\Api\Data\TypologyInterface;
use Maas\Grc\Api\TypologyRepositoryInterface;
use Magento\Framework\Option\ArrayInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\FilterBuilder;

/**
 * Class OrderTypology
 * @package Maas\Grc\Model\Typology\Source
 * @codeCoverageIgnore
 */
class OrderTypology implements ArrayInterface
{
    /**
     * @var TypologyRepositoryInterface
     */
    private $typologyRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var FilterBuilder
     */
    private $filterBuilder;

    /**
     * OrderTypology constructor.
     * @param TypologyRepositoryInterface $typologyRepository
     */
    public function __construct(
        TypologyRepositoryInterface $typologyRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder
    )
    {
        $this->typologyRepository = $typologyRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * @param array $allowedCodes
     * @return array
     */
    public function toOptionArray($allowedCodes = null)
    {
        $filter = $this->filterBuilder
            ->setField('enabled')
            ->setConditionType('eq')
            ->setValue(1)
            ->create();
        $this->searchCriteriaBuilder->addFilters([$filter]);
        $searchCriteria = $this->searchCriteriaBuilder->create();
        $typologyList = $this->typologyRepository->getList($searchCriteria)->getItems();

        $return = [];
        /** @var TypologyInterface $typology */
        foreach ($typologyList as $typology) {
            $typologyObject = $this->typologyRepository->get($typology->getId());
            if (!empty($typologyObject->getStoreValue()) &&
                (!is_array($allowedCodes) || in_array($typologyObject->getMaasCode(), $allowedCodes))) {
                $return[$typologyObject->getMaasCode()] = $typologyObject->getStoreValue();
            }
        }
        return $return;
    }
}
