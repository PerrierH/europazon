<?php

namespace Maas\Grc\Model\Service;

use Exception;
use Maas\Grc\Model\Discussion\Search;
use Maas\Grc\Model\Message\Get;

class GetDiscussions
{

    /** @var Search */
    private $search;

    /** @var Get */
    private $getMessages;

    /**
     * GetDiscussions constructor.
     *
     * @param Search $search
     * @param Get $messages
     */
    public function __construct(
        Search $search,
        Get $messages
    )
    {
        $this->search = $search;
        $this->getMessages = $messages;
    }

    /**
     * @param string $orderId
     *
     * @return array|string
     * @throws Exception
     */
    public function execute(string $orderId, string $orderIncrementId)
    {
        $result = [];

        $searchResult = $this->search->execute([
            'orderId' => $orderId,
            'orderReference' => $orderIncrementId
        ]);

        if ($searchResult === 'Error') {
            $result = 'Error';
        } elseif ($searchResult instanceof \Magento\Framework\Phrase) {
            $result = $searchResult->getText();
        } else {
            if (is_array($searchResult['message'])
                && array_key_exists('items', $searchResult['message'])
                && (count($searchResult['message']['items']) > 0)) {
                foreach ($searchResult['message']['items'] as $discussion) {
                    $messages = $this->getMessages->execute(['id' => $discussion['discussionId']]);
                    if (is_array($messages['message'])
                        && array_key_exists('items', $messages['message'])
                        && (count($messages['message']['items']) > 0)) {
                        $discussion['messages'] = $messages['message']['items'];
                    } else {
                        $discussion['messages'] = 'No messages';
                    }
                    $result[] = $discussion;
                }
            } else {
                $result = 'No result';
            }
        }
        return $result;
    }

}
