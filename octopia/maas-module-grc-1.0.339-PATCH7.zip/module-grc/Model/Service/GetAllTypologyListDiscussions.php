<?php

namespace Maas\Grc\Model\Service;

use Exception;
use Maas\Grc\Model\Discussion\Search;

/**
 * Class GetAllTypologyListDiscussions
 *
 * @package Maas\Grc\Model\Service
 * @codeCoverageIgnore
 */
class GetAllTypologyListDiscussions
{

    /** @var Search */
    private $search;

    /**
     * GetAllTypologyListDiscussions constructor.
     *
     * @param Search $search
     */
    public function __construct(
        Search $search
    )
    {
        $this->search = $search;
    }

    /**
     * @param string $orderId
     *
     * @return array|string
     * @throws Exception
     */
    public function execute(string $orderId, string $orderIncrementId)
    {
        $result = [];
        $searchResult = $this->search->execute([
            'orderId' => $orderId,
            'orderReference' => $orderIncrementId
        ]);

        if ($searchResult === 'Error') {
            $result = 'Error';
        } elseif ($searchResult instanceof \Magento\Framework\Phrase) {
            $result = $searchResult->getText();
        } else {
            if (is_array($searchResult['message'])
                && array_key_exists('items', $searchResult['message'])
                && (count($searchResult['message']['items']) > 0)) {
                foreach ($searchResult['message']['items'] as $discussion) {
                    $result[] = $discussion['subTypologyCode'];
                }
            } else {
                $result = 'No result';
            }
        }
        return $result;
    }
}
