<?php

namespace Maas\Grc\Model\Service;


class FileAttachments
{
    const FILES_ALLOWED_EXTENSIONS = ['gif','bmp','tif','jpeg','pdf','png','jpg','doc','docx','xls'];
    const FILES_MAX_SIZE = 5242880; //1024 * 1024 * 5 gives 5 Mbytes


    /**
     * @param $files
     * @return array|array[]|string
     */
    public function prepareAttachments($files)
    {
        $fileName = pathinfo($files['fileupload']['name'], PATHINFO_FILENAME);
        $attachments = [];
        
        if (isset($files['fileupload']) && $fileName) {

            $fileExtension = pathinfo($files['fileupload']['name'], PATHINFO_EXTENSION);

            if (in_array($fileExtension, self::FILES_ALLOWED_EXTENSIONS)
                && $files['fileupload']['size'] <= self::FILES_MAX_SIZE) {

                $content = file_get_contents($files['fileupload']['tmp_name']);
                $attachments = [
                    [
                        'content' => base64_encode($content),
                        'attachmentName' => $fileName,
                        'fileFormat' => $fileExtension
                    ]
                ];
            }
            else {
                return 'Error';
            }
        }
        return $attachments;
    }
}
