<?php

namespace Maas\Grc\Model\Service;

use Exception;
use Maas\Grc\Model\Attachment\Search;

class GetAttachments
{
    /** @var Search */
    private $search;

    /**
     * GetAttachments constructor.
     *
     * @param Search $search
     */
    public function __construct(
        Search $search
    )
    {
        $this->search = $search;
    }

    /**
     * @param string $discussionId
     *
     * @return array|string
     * @throws Exception
     */
    public function execute(string $discussionId)
    {
        $result = [];
        $searchResult = $this->search->execute(['discussionId' => $discussionId]);
        if ($searchResult === 'Error') {
            $result = 'Error';
        } elseif ($searchResult instanceof \Magento\Framework\Phrase) {
            $result = $searchResult->getText();
        } elseif (is_array($searchResult['message'])
            && array_key_exists('items', $searchResult['message'])
            && (count($searchResult['message']['items']) > 0)) {
            foreach ($searchResult['message']['items'] as $attachment) {
                $result[$attachment['messageId']][] = $attachment;
            }
        } else {
            $result = 'No result';
        }

        return $result;
    }

}
