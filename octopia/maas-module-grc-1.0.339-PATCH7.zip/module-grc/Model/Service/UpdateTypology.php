<?php


namespace Maas\Grc\Model\Service;

use Exception;
use Maas\Grc\Api\Data\TypologyInterface as Typology;
use Maas\Grc\Api\TypologyRepositoryInterface;
use Maas\Grc\Model\Discussion\GetTypologies;
use Maas\Grc\Model\TypologyFactory;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Phrase;

/**
 * Class UpdateTypology
 *
 * @package Maas\Grc\Model\Service
 */
class UpdateTypology
{
    /**
     * @var GetTypologies
     */
    private $getTypologies;

    /**
     * @var TypologyRepositoryInterface
     */
    private $typologyRepository;

    /**
     * @var TypologyFactory
     */
    private $typologyFactory;

    /**
     * @var Array|null
     */
    private $typologyCodeList = null;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var ManagerInterface
     */
    private $messageManager;

    /**
     * UpdateTypology constructor.
     *
     * @param GetTypologies $getTypologies
     * @param TypologyRepositoryInterface $typologyRepository
     * @param TypologyFactory $typologyFactory
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param ManagerInterface $messageManager
     */
    public function __construct(
        GetTypologies $getTypologies,
        TypologyRepositoryInterface $typologyRepository,
        TypologyFactory $typologyFactory,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        ManagerInterface $messageManager
    )
    {
        $this->getTypologies = $getTypologies;
        $this->typologyRepository = $typologyRepository;
        $this->typologyFactory = $typologyFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->messageManager = $messageManager;
    }

    /**
     * @return bool
     * @throws Exception
     */
    public function hasTypologyWithMissingValue()
    {
        $searchCriteria = $this->searchCriteriaBuilder->create();
        if (count($this->typologyRepository->getList($searchCriteria)->getItems()) == 0) {
            $this->execute();
        }
        return (count($this->typologyRepository->getTypologyWithMissingValue()) > 0) ? true : false;
    }

    /**
     * @return bool
     * @throws Exception
     */
    public function execute()
    {
        // get typologies from api
        $response = $this->getTypologies->execute();
        if (!is_array($response) || !is_array($response['message'])) {
            if (is_string($response) || (is_object($response) && $response instanceof Phrase)) {
                $this->messageManager->addErrorMessage(__('Complaint motives could not be loaded: %1', $response));
            }
            return false;
        }

        foreach ($response['message'] as $item) {
            if (!is_array($item) || !array_key_exists('typology', $item) || $item['typology'] != 'order') {
                continue;
            }
            $this->update($item['subTypologyList']);
        }

        return true;
    }

    /**
     * @param array $typologyList
     */
    private function update(array $typologyList)
    {
        foreach ($this->getNewTypologyCode($typologyList) as $typologyCode) {
            /** @var Typology $typologyObject */
            $typologyObject = $this->typologyFactory->create();
            $typologyObject->setMaasCode($typologyCode);
            $typologyObject->setEnabled(true);
            $this->typologyRepository->save($typologyObject);
        }

        foreach ($this->getObsoleteTypologyCode($typologyList) as $id => $typologyCode) {
            $this->typologyRepository->deleteById($id);
        }
    }

    /**
     * @param $typologyList
     *
     * @return array
     */
    private function getNewTypologyCode($typologyList)
    {
        $oldTypologyList = $this->getDbTypologyCode();
        return array_diff($typologyList, $oldTypologyList);
    }

    /**
     * @return array|null
     */
    private function getDbTypologyCode()
    {
        if ($this->typologyCodeList === null) {
            $searchCriteria = $this->searchCriteriaBuilder->create();
            $typologyList = $this->typologyRepository->getList($searchCriteria)->getItems();

            $this->typologyCodeList = [];
            foreach ($typologyList as $typology) {
                $this->typologyCodeList[$typology->getId()] = $typology->getMaasCode();
            }
        }
        return $this->typologyCodeList;
    }

    /**
     * @param $typologyList
     *
     * @return array
     */
    private function getObsoleteTypologyCode($typologyList)
    {
        $oldTypologyList = $this->getDbTypologyCode();
        return array_diff($oldTypologyList, $typologyList);
    }
}
