<?php

namespace Maas\Grc\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class ContactPoint
 *
 * @codeCoverageIgnore
 * @package Maas\Grc\Model\Config\Source
 */
class ContactPoint implements ArrayInterface
{

    /**
     * Get customer contact points
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            [
                'label' => __('Marketplace seller'),
                'value' => 0,
            ],
            [
                'label' => __('Customer Care Service'),
                'value' => 2
            ]
        ];
    }
}
