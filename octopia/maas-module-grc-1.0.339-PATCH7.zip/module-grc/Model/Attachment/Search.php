<?php

namespace Maas\Grc\Model\Attachment;

use Maas\Grc\Model\AbstractApi;

/**
 * Class Search
 *
 * @package Maas\Grc\Model\Attachment
 */
class Search extends AbstractApi
{
    public const API_REQUEST_ENDPOINT = '/attachments?discussionId=%s';

    public const API_METHOD = 'GET';


    /**
     * @param array|null $args
     *
     * @return array|null
     */
    protected function doExecute(array $args = null)
    {
        $this->setArgs([
            $args['discussionId']
        ]);
        return $this->apiCall();
    }
}
