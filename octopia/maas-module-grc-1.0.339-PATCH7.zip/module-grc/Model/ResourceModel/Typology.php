<?php

namespace Maas\Grc\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Seller
 *
 * @package Maas\Seller\Model\ResourceModel
 * @codeCoverageIgnore
 */
class Typology extends AbstractDb
{
    const TYPOLOGY_TABLE_NAME = 'maas_grc_order_typology';
    const TYPOLOGY_STORE_TABLE_NAME = 'maas_grc_order_typology_store';

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(self::TYPOLOGY_TABLE_NAME, 'entity_id');
    }

    /**
     * @param $typologyId
     * @return array
     */
    public function getStoreValues($typologyId)
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName(self::TYPOLOGY_STORE_TABLE_NAME), ['store_id', 'value'])
            ->where('typology_id=?', $typologyId);
        return $connection->fetchAll($select);
    }

    /**
     * @param AbstractModel $object
     * @return AbstractDb
     */
    protected function _afterLoad(AbstractModel $object)
    {
        $storeValues = [];
        foreach ($this->getStoreValues($object->getId()) as $storeValue) {
            $storeValues[$storeValue['store_id']] = $storeValue['value'];
        }

        $object->setStoreValues($storeValues);
        return parent::_afterLoad($object);
    }

    /**
     * @param AbstractModel $object
     * @return AbstractDb
     */
    protected function _afterSave(AbstractModel $object)
    {
        if (!is_array($object->getStoreValues()) || count($object->getStoreValues()) == 0) {
            return parent::_afterSave($object);
        }

        $connection = $this->getConnection();
        foreach ($object->getStoreValues() as $storeId=>$value) {
            if (!empty($value)) {
                $connection->insertOnDuplicate(
                    self::TYPOLOGY_STORE_TABLE_NAME,
                    [
                        'typology_id' => $object->getId(),
                        'store_id' => $storeId,
                        'value' => $value,
                    ]
                );
            }
        }

        return parent::_afterSave($object);
    }
}
