<?php

namespace Maas\Grc\Model\ResourceModel\Typology;


use Maas\Grc\Model\ResourceModel\Typology;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

/**
 * Class Collection
 *
 * @package Maas\Seller\Model\ResourceModel\Seller
 * @codeCoverageIgnore
 */
class Collection extends AbstractCollection
{
    /** @var StoreManagerInterface  */
    private $storeManager;

    /**
     * Collection constructor.
     * @param EntityFactoryInterface $entityFactory
     * @param LoggerInterface        $logger
     * @param FetchStrategyInterface $fetchStrategy
     * @param ManagerInterface       $eventManager
     * @param StoreManagerInterface  $storeManager
     * @param AdapterInterface|null  $connection
     * @param AbstractDb|null        $resource
     */
    public function __construct(
        EntityFactoryInterface $entityFactory,
        LoggerInterface $logger,
        FetchStrategyInterface $fetchStrategy,
        ManagerInterface $eventManager,
        StoreManagerInterface $storeManager,
        AdapterInterface $connection = null,
        AbstractDb $resource = null
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
    }

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Maas\Grc\Model\Typology', 'Maas\Grc\Model\ResourceModel\Typology');
    }

    /**
     * @return void
     */
    public function getTypologyWithMissingStoreValue()
    {
        $storeValueTable = $this->getTable(Typology::TYPOLOGY_STORE_TABLE_NAME);
        $totalStoreNUmber = count($this->storeManager->getStores());

        $select = $this->getSelect();
        $select->joinLeft(
            ['store_value' => $storeValueTable],
            'main_table.entity_id = store_value.typology_id',
            ['store_value'=>'value']
        );
        $select->having('COUNT(store_value)  < '.$totalStoreNUmber);
        $select->group(['main_table.entity_id']);
    }
}
