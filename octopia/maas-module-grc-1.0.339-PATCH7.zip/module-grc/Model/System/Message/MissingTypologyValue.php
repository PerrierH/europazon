<?php

namespace Maas\Grc\Model\System\Message;

use Maas\Grc\Model\Service\UpdateTypology;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Notification\MessageInterface;
use Magento\Framework\UrlInterface;

/**
 * Class MissingTypologyValue
 * @package Maas\Grc\Model\Message
 * @codeCoverageIgnore
 */
class MissingTypologyValue implements MessageInterface
{
    /**
     * @var UpdateTypology
     */
    protected $UpdateTypology;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /***
     * @var Context
     */
    protected $actionContext;

    /**
     * MissingTypologyValue constructor.
     *
     * @param UpdateTypology $UpdateTypology
     * @param UrlInterface $urlBuilder
     * @param Context $actionContext
     */
    public function __construct(
        UpdateTypology $UpdateTypology,
        UrlInterface $urlBuilder,
        Context $actionContext
    ) {
        $this->UpdateTypology = $UpdateTypology;
        $this->urlBuilder = $urlBuilder;
        $this->actionContext = $actionContext;
    }

    /**
     * @return bool
     */
    public function isDisplayed()
    {
        // only display the message on the controller managed by this module
        $moduleName = $this->actionContext->getRequest()->getModuleName();
        return ($moduleName == 'maasgrc') && $this->UpdateTypology->hasTypologyWithMissingValue();
    }

    /**
     * Retrieve unique message identity
     *
     * @return string
     */
    public function getIdentity()
    {
        return hash("sha256",'MAAS_GRC_TYPOLOGY_MISSING_VALUE');
    }

    /**
     * Retrieve message text
     *
     * @return \Magento\Framework\Phrase
     */
    public function getText()
    {
        $url = $this->urlBuilder->getUrl('maasgrc/typology');
        //@codingStandardsIgnoreStart
        return __(
            'One or more complaints motive is missing a translation. Add them using the <a href="%1">Complaints motives</a> menu.',
            $url
        );
        //@codingStandardsIgnoreEnd
    }

    /**
     * Retrieve message severity
     *
     * @return int
     */
    public function getSeverity()
    {
        return self::SEVERITY_MAJOR;
    }
}
