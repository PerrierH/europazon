<?php

namespace Maas\Grc\Model\Email\Sender;

use Magento\Framework\DataObject;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender;

/**
 * Class GrcSender
 *
 * @package Maas\Grc\Model\Email\Sender
 * @codeCoverageIgnore delegates to standard
 */
class GrcSender extends Sender
{
    /**
     * Send email to customer
     *
     * @param Order $order
     * @param bool $notify
     * @param string $comment
     *
     * @return bool
     */
    public function send(Order $order)
    {
        $this->identityContainer->setStore($order->getStore());

        $transport = [
            'order' => $order,
            'store' => $order->getStore(),
            'order_data' => [
                'customer_name' => $order->getCustomerName(),
                'frontend_status_label' => $order->getFrontendStatusLabel()
            ]
        ];
        $transportObject = new DataObject($transport);

        $this->templateContainer->setTemplateVars($transportObject->getData());

        return $this->checkAndSend($order);
    }
}