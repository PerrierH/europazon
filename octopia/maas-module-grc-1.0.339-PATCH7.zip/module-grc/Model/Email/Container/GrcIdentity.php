<?php

namespace Maas\Grc\Model\Email\Container;

use Magento\Sales\Model\Order\Email\Container\Container;
use Magento\Sales\Model\Order\Email\Container\IdentityInterface;
use Magento\Store\Model\ScopeInterface;

/**
 * Class GrcIdentity
 *
 * @package Maas\Grc\Model\Email\Container
 * @codeCoverageIgnore delegates to standard, relies on database
 */
class GrcIdentity extends Container implements IdentityInterface
{
    /**
     * Configuration paths
     */
    const XML_PATH_EMAIL_COPY_METHOD = 'maas_grc/email_new_message_notification/copy_method';
    const XML_PATH_EMAIL_COPY_TO = 'maas_grc/email_new_message_notification/copy_to';
    const XML_PATH_EMAIL_IDENTITY = 'maas_grc/email_new_message_notification/identity';
    const XML_PATH_EMAIL_TEMPLATE = 'maas_grc/email_new_message_notification/template';
    const XML_PATH_EMAIL_ENABLED = 'maas_grc/email_new_message_notification/grc_notification_enabled';

    /**
     * Mail is enabled
     *
     * @return bool
     */
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_EMAIL_ENABLED,
            ScopeInterface::SCOPE_STORE,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * Addresses to copy transactional mails to
     *
     * @return array|bool
     */
    public function getEmailCopyTo()
    {
        $data = $this->getConfigValue(self::XML_PATH_EMAIL_COPY_TO, $this->getStore()->getStoreId());
        if (!empty($data)) {
            return array_map('trim', explode(',', $data));
        }
        return false;
    }

    /**
     * Copy email method
     *
     * @return string
     */
    public function getCopyMethod()
    {
        return $this->getConfigValue(self::XML_PATH_EMAIL_COPY_METHOD, $this->getStore()->getStoreId());
    }

    /**
     * Return template identifier (string if hardcoded, int if edited in BO)
     *
     * @return string|int
     */
    public function getGuestTemplateId()
    {
        return $this->getTemplateId();
    }

    /**
     * Return template identifier (string if hardcoded, int if edited in BO)
     *
     * @return string|int
     */
    public function getTemplateId()
    {
        return $this->getConfigValue(self::XML_PATH_EMAIL_TEMPLATE, $this->getStore()->getStoreId());
    }

    /**
     * Return identity
     *
     * @return string
     */
    public function getEmailIdentity()
    {
        return $this->getConfigValue(self::XML_PATH_EMAIL_IDENTITY, $this->getStore()->getStoreId());
    }
}