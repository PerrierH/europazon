<?php

namespace Maas\Grc\Model;

use Maas\Core\Model\Config as CoreConfig;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 *
 * @package Maas\Grc\Model
 * @codeCoverageIgnore
 */
class Config extends CoreConfig
{

    /*  System Config -> Discussions timeout */
    public const XML_PATH_DISCUSSION_TIMEOUT = 'maas_grc/general/edit_maas_timeout';

    /*  System Config -> Discussions contact point */
    public const XML_PATH_DISCUSSION_CONTACT_POINT = 'maas_grc/customer_contact/grc_customer_contact_point';

    const SENDER_USER_ID = 1;

    /**
     * Function to get Discussion Timeout
     *
     * @return string|null
     */
    public function getTimeout()
    {
        return $this->getValue(
            self::XML_PATH_DISCUSSION_TIMEOUT,
            null,
            ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Get Customer contact point
     *
     * @return int
     */
    public function getCustomerContactPoint()
    {
        return (int) $this->getValue(
            self::XML_PATH_DISCUSSION_CONTACT_POINT,
            null,
            ScopeInterface::SCOPE_WEBSITE
        );
    }
}
