<?php

namespace Maas\Grc\Cron;

use Maas\Grc\Model\Service\UpdateTypology as UpdateService;

/**
 * Class UpdateTypology
 * @package Maas\Grc\Cron
 * @codeCoverageIgnore
 */
class UpdateTypology
{
    /**
     * @var UpdateService
     */
    private $updateService;

    /**
     * UpdateTypology constructor.
     * @param UpdateService $updateService
     */
    public function __construct(
        UpdateService $updateService
    ) {
        $this->updateService = $updateService;
    }

    public function execute()
    {
        return $this->updateService->execute();
    }
}