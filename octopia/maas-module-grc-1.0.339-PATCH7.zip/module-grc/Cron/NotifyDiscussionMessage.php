<?php

namespace Maas\Grc\Cron;

use Maas\Grc\Model\Discussion\Notify;
use Magento\Cron\Model\Schedule;

/**
 * Class NotifyDiscussionMessage
 *
 * @package Maas\Grc\Cron
 * @codeCoverageIgnore
 */
class NotifyDiscussionMessage
{

    /** @var Notify */
    private $notify;

    /**
     * NotifyDiscussionMessage constructor.
     *
     * @param Notify $notify
     */
    public function __construct(
        Notify $notify
    )
    {
        $this->notify = $notify;
    }

    /**
     * @param Schedule $schedule
     */
    public function execute(Schedule $schedule)
    {
        return $this->notify->execute(
            [
                'scheduleId' => $schedule->getId()
            ]
        );
    }
}
