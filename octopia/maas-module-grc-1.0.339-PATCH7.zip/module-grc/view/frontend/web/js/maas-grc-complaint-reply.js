define([
    'jquery',
    'underscore',
    'mage/translate',
    'loader',
    'Maas_Grc/js/maas-grc-utils',
    'validation'
], function ($, __, $t, loader, grcUtils) {
    'use strict';

    $.widget('mage.maasGrcComplaintReply', {
        options: {
            selectors: {
                "form": '',
                "message": '',
                "messageContainer": ''
            },
            loaderIcon: ''
        },

        /**
         * Validation creation
         *
         * @protected
         */
        _create: function () {
            var self = this;
            var contextId = this.element[0].id;
            this.options.selectors.form = `#${contextId}`;
            this.options.selectors.message = `#${contextId} .maas-reply-message`;
            this.options.selectors.messageContainer = `#${contextId} .block-maas-grc-message`;

            this.element.validation({
                submitHandler: function (form) {
                    if ($(form).valid()) {
                        grcUtils.clearMessage(self.options.selectors.messageContainer);
                        self.sendMessage(form);
                    }
                    return false;
                }
            });

            $('#fileupload').on('change',function() {
                $.validator.validateSingleElement($(this));
            });
        },

        sendMessage: function (form) {
            var self = this;
            var data = new FormData($(form)[0]);
            var fileupload = $('#fileupload').val();

            $(form).loader({icon: self.options.loaderIcon});
            $(form).loader('show');
            const url = this.getUrl('')
            grcUtils.apiCall(
                self,
                url,
                'POST',
                data,
                function (that) {
                    $(form).loader('hide');
                    grcUtils.addMessage(
                        that.options.selectors.messageContainer,
                        $t('Message sent.'),
                        'success'
                    );
                    that.addTempMessage($(that.options.selectors.message).val());
                    $(that.options.selectors.message).val('');
                    $('#fileupload').val('');
                    $(that.options.selectors.messageContainer).fadeIn();
                    $(that.options.selectors.messageContainer).delay(5000).fadeOut();
                    if(fileupload) window.setTimeout(function(){location.reload()},3000);
                },
                function (that) {
                    $(form).loader('hide');
                    grcUtils.addMessage(
                        that.options.selectors.messageContainer,
                        $t('An error has occured. Try again later.'),
                        'error'
                    );
                }
            );
        },

        getUrl: function (url) {
            return this.options.url + url;
        },

        getHeaders: function () {
            return {
                'Content-Type': 'application/json'
            };
        },

        addTempMessage: function (message) {
            const d = $('<div/>', {"class": "maas-complaint-message"});
            $('<span/>', {"class": "maas-complaint-message-from"}).html($t('You') + ' ').appendTo(d);
            $('<span/>', {"class": "maas-complaint-message-date"}).html($t('Just now')).appendTo(d);
            $('<div/>', {"class": "maas-complaint-message-message"}).html(message.replace(/\n/g, "<br>")).appendTo(d);
            this.getComplainContentElement(true).append(d);
            this.scrollDown();
        },

        scrollDown: function () {
            const d = this.getComplainContentElement(true);
            this.getComplainContentElement(false).scrollTop(d.height());
        },

        getComplainContentElement: function (getChildDiv) {
            let findExpr = '.maas-complaint-messages';
            if (getChildDiv) {
                findExpr += '>div'
            }
            return $(this.options.selectors.form).closest('.maas-complaint-content').find(findExpr)
        }
    });

    return $.mage.maasGrcComplaintReply;
});
