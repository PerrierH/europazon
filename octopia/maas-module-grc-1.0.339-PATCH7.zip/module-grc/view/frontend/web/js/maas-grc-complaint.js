define([
    'jquery',
    'underscore',
    'mage/translate',
    'loader',
    'Maas_Grc/js/maas-grc-utils',
    'validation'
], function ($, __, $t, loader, grcUtils) {
    'use strict';

    $.widget('mage.maasGrcComplaint', {
        options: {
            messagediv: '#block-maas-grc-complaint-message',
            orderId: 0,
            loaderIcon: ''
        },

        /**
         * Validation creation
         *
         * @protected
         */
        _create: function () {
            var self = this;

            this.element.validation({
                submitHandler: function (form) {
                    if ($(form).valid()) {
                        grcUtils.clearMessage(self.options.messagediv);
                        self.createDiscussion(form);
                    }
                    return false;
                }
            });

            $('#fileupload').on('change',function() {
                $.validator.validateSingleElement($(this));
            });
        },

        createDiscussion: function (form) {
            var self = this;

            var data = new FormData($(form)[0]);

            $(form).loader({icon: self.options.loaderIcon});
            $(form).loader('show');
            const url = this.getUrl('create');
            grcUtils.apiCall(
                self,
                url,
                'POST',
                data,
                function (that) {
                    $(form).loader('hide');
                    $(form).hide();
                    grcUtils.addMessage(
                        that.options.messagediv,
                        `${$t('Message sent. To show order details')} <a href="${that.options.backUrl}">${$t('click here')}.</a>`,
                        'success'
                    );
                },
                function (that) {
                    $(form).loader('hide');
                    grcUtils.addMessage(
                        that.options.messagediv,
                        $t('An error has occured. Try again later.'), 'error'
                    );
                }
            );
        },

        getUrl: function (url) {
            return this.options.url + url;
        },

        getHeaders: function () {
            return {
                'Content-Type': 'application/json'
            };
        }

    });

    return $.mage.maasGrcComplaint;
});
