define(['jquery'], function ($) {

    return function () {
        $.validator.addMethod(
            'validate-maas-complaint-content',
            function (value, element) {
                const regex = RegExp("[^A-zÀ-ú0-9\\s\\'.,: \\-!?]+");
                return !regex.test(value);
            },
            $.mage.__('Please enter only letters, numbers and simple punctuation.')
        );

        $.validator.addMethod(
            'validate-filesize', function (v, elm) {
                var maxSize = 512000; //5 * 102400 for 5Mbytes;
                if (navigator.appName === "Microsoft Internet Explorer") {
                    if (elm.value) {
                        var oas = new ActiveXObject("Scripting.FileSystemObject");
                        var e = oas.getFile(elm.value);
                        var size = e.size;
                    }
                } else {
                    if (elm.files[0] !== undefined) {
                        size = elm.files[0].size;
                    }
                }
                if (size !== undefined && size > maxSize) {
                    return false;
                }
                return true;
            }, $.mage.__('The uploaded file is too large. Maximum size allowed: 5MB'));

        $.validator.addMethod(
            'validate-fileextensions', function (v, elm) {
                var extensions = ['gif','bmp','tif','jpeg','pdf','png','jpg','doc','docx','xls'];
                if (!v) {
                    return true;
                }
                with (elm) {
                    var ext = value.substring(value.lastIndexOf('.') + 1);
                    for (i = 0; i < extensions.length; i++) {
                        if (ext === extensions[i]) {
                            return true;
                        }
                    }
                }
                return false;
            }, $.mage.__('The uploaded file is not in a supported format (gif,bmp,tif,jpeg,pdf,png,jpg,doc,docx,xls'));
    }
});
