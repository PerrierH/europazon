define([
    'jquery',
    'underscore',
    'mage/url'
], function ($, _, urlBuilder) {
    'use strict';

    function apiCall(caller, url, method, data, successCallback, errorCallback)
    {
        $.ajax( {
                url : urlBuilder.build(url),
                type: method,
                data: data,
                processData: false,
                contentType: false
            }
        )
            .done(
                function () {
                    successCallback(caller);
                }
            )
            .fail(
                function () {
                    errorCallback(caller);
                }
            );
    }

    function addLog(data)
    {
        $.post(
            urlBuilder.build('maasgrc/log'),
            data
        );
    }

    function addMessage(containerSelector, message, type)
    {
        var html = `<div class="message-${type} ${type} message"><div>${message}</div></div>`;
        $(containerSelector).append(html);
    }

    function clearMessage(containerSelector)
    {
        $(containerSelector).empty();
    }

    return {
        apiCall: apiCall,
        addLog: addLog,
        addMessage: addMessage,
        clearMessage: clearMessage
    }
});
