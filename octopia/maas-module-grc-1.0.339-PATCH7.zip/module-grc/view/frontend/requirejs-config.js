var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Maas_Grc/js/validation-mixin': true
            }
        }
    },
    map: {
        '*': {
            maasGrcComplaint: 'Maas_Grc/js/maas-grc-complaint',
            maasGrcComplaintReply: 'Maas_Grc/js/maas-grc-complaint-reply'
        }
    }
}
