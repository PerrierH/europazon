<?php

namespace Maas\Grc\Test\Builder;

use Maas\Core\Model\TokenFactory;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Core\Test\Builder\Order\OrderBuilder;
use Maas\Grc\Model\Config as MaasConfig;
use Maas\Core\Model\TokenRepository;
use Maas\Core\Model\Token;
use Maas\ImportExport\Model\AbstractApi;
use Maas\Sales\Model\SalesOrderInfo;
use Maas\Sales\Model\Service\ExtensionAttributes;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\Registry;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderRepository;
use PHPUnit\Framework\TestCase;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;
use Magento\Customer\Model\Session as CustomerSession;
use StdClass;
use Maas\ImportExport\Model\Config as ImportExportConfig;
use Magento\Framework\App\Cache;

/**
 * Class AbstractApiBuilder
 *
 * @package Maas\ImportExport\Test\Builder\Model
 */
class AbstractApiBuilder
{
    /** @var TestCase */
    private $testCase;
    private $data;
    /** @var array */
    private $di;
    /** @var ObjectManager */
    private $objectManager;

    /**
     * @param TestCase $testCase
     * @param array $data
     *
     * @return AbstractApiBuilder
     */
    public static function create(TestCase $testCase, $data = [])
    {
        $self = new self();
        $self->testCase = $testCase;
        $self->objectManager = new ObjectManager($self->testCase);
        $self->data = $data;
        $self->di = [];
        return $self;
    }

    /**
     * @param array $data
     *
     * @return $this
     */
    public function addConfig(array $data)
    {
        $this->data = array_merge($this->data, $data);
        return $this;
    }

    /**
     * @return array
     */
    public function getDi()
    {
        if (count($this->di) === 0) {
            $this->build();
        }
        return $this->di;
    }

    public function build()
    {
        $serializer = new Json();
        $this->di['serializer'] = $serializer;

        $registry = $this->testCase->getMockBuilder(Registry::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'registry'
            ])
            ->getMock();
        $registry->expects($this->testCase->any())->method('registry')->willReturnCallback(function ($s) {
            if ($s == 'current_order') {
                $order = $this->testCase->getMockBuilder(Order::class)
                    ->disableOriginalConstructor()
                    ->getMock();
                $order->expects($this->testCase->any())->method('getId')->willReturn(42);
                return $order;
            } else {
                return true;
            }
        });
        $this->di['registry'] = $registry;

        $configProvider = $this->testCase->getMockBuilder(ImportExportConfig::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'getGrcApiUrl'
            ])
            ->getMock();
        $configProvider->expects($this->testCase->any())->method('getGrcApiUrl')->willReturn('http://test.test.com');
        $this->di['configProvider'] = $configProvider;

        $token = AnyBuilder::createForClass(
            $this->testCase,
            Token::class,
            [
                'getCreatedAt' => [$this->testCase->any(), date('Y-m-d H:i:s')],
                'getExpiredIn' => [$this->testCase->any(), 900],
                'getTokenType' => [$this->testCase->any(), 'dummy_token_type'],
                'getAccessToken' => [$this->testCase->any(), 'dummy_access_token']
            ]
        )->build();

        $tokenRepository = $this->testCase->getMockBuilder(TokenRepository::class)
            ->setMethods([
                'getEnabledToken'
            ])
            ->disableOriginalConstructor()
            ->getMock();
        $tokenRepository->expects($this->testCase->any())->method('getEnabledToken')->willReturn($token);
        $this->di['tokenRepository'] = $tokenRepository;

        $tokenFactory = AnyBuilder::createForClass($this->testCase, TokenFactory::class, [
            'create' => [$this->testCase->any(), $token]
        ])->build();
        $this->di['tokenFactory'] = $tokenFactory;

        $this->di['httpClientFactory'] = ZendClientFactoryBuilder::create($this->testCase)->build();

        $customerSessionMock = AnyBuilder::createForClass(
            $this->testCase,
            StdClass::class,
            [
                'getId' => [$this->testCase->any(), 27]
            ]
        )->build();
        $this->di['customerSession'] = AnyBuilder::createForClass(
            $this->testCase,
            CustomerSession::class,
            [
                'getCustomer' => [$this->testCase->any(), $customerSessionMock]
            ]
        )->build();

        $order = OrderBuilder::create(
            $this->testCase,
            []
        )->build();

        $this->di['orderRepository'] = AnyBuilder::createForClass(
            $this->testCase,
            OrderRepository::class,
            [
                'get' => [$this->testCase->any(), $order, AnyBuilder::RETURN_REFERENCE, [42]]
            ]
        )->build();

        $extraInfo = AnyBuilder::createForClass($this->testCase, SalesOrderInfo::class, [
            'getSellerMaasId' => [$this->testCase->any(), 1234]
        ])->build();

        $extensionAttributes = AnyBuilder::createForClass($this->testCase, OrderExtensionInterface::class, [
            'getExtraInfo' => [$this->testCase->any(), $extraInfo]
        ])->build();

        $this->di['extensionAttributesService'] = AnyBuilder::createForClass(
            $this->testCase,
            ExtensionAttributes::class,
            [
                'getOrderExtensionAttributes' => [$this->testCase->any(), $extensionAttributes, AnyBuilder::RETURN_REFERENCE, [$order]]
            ]
        )->build();

        $this->di['cache'] = AnyBuilder::createForClass(
            $this->testCase,
            Cache::class,
            [
                'load' => [
                    $this->testCase->any(),
                    function ($key) {
                        if ($key == AbstractApi::TOKEN_CACHE_KEY) {
                            $serializer = new Json();
                            return $serializer->serialize([
                                'created_at' => date('Y-m-d H:i:s'),
                                'expired_in' => 900,
                                'token_type' => 'dummy_token_type',
                                'access_token' => 'dummy_access_token'
                            ]);
                        }
                        
                        return true;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();
    }

    public function resetDi()
    {
        $this->di = null;
    }
}
