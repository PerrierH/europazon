<?php

namespace Maas\Grc\Test\Unit\Model\Message;

use Exception;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;
use Maas\Grc\Model\Message\Reply;
use Maas\Grc\Test\Builder\AbstractApiBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

class ReplyTest extends TestCase
{
    /** @var Reply */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);
    }

    public function testDoExecuteSuccess()
    {
        $this->instance = $this->objectManager->getObject(
            Reply::class,
            $this->abstractApiBuilder->getDi()
        );

        $result = $this->instance->execute(['orderId' => 42, 'guid' => 42]);

        $this->assertEquals(["message" => ["test", "data"], 'status' => 200], $result);
    }

    public function testDoExecuteError()
    {
        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'httpClientFactory' => ZendClientFactoryBuilder::create($this)->addConfig(['request_status' => 400])->build()
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Reply::class,
            $di
        );

        $result = $this->instance->execute(['orderId' => 42, 'guid' => 42]);

        $this->assertEquals(400, $result['status']);
    }
}
