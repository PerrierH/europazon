<?php

namespace Maas\Grc\Test\Unit\Model\Message;

use Exception;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;
use Maas\Grc\Model\Message\Get;
use Maas\Grc\Test\Builder\AbstractApiBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

class GetTest extends TestCase
{
    /** @var Get */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);
    }

    public function testDoExecuteSuccess()
    {
        $this->instance = $this->objectManager->getObject(
            Get::class,
            $this->abstractApiBuilder->getDi()
        );

        $result = $this->instance->execute(['id' => 42]);

        $this->assertEquals(["message" => ["test", "data"], 'status' => 200], $result);
    }

    public function testDoExecuteError()
    {
        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'httpClientFactory' => ZendClientFactoryBuilder::create($this)->addConfig(['request_status' => 400])->build()
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Get::class,
            $di
        );

        $result = $this->instance->execute(['id' => 42]);

        $this->assertEquals(400, $result['status']);
    }
}
