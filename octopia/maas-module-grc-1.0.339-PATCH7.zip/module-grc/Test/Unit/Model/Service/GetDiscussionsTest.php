<?php

namespace Maas\Grc\Test\Unit\Model\Service;

use Exception;
use Maas\Grc\Model\Message\Get;
use Maas\Grc\Model\Discussion\Search;
use Maas\Grc\Model\Service\GetDiscussions;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

class GetDiscussionsTest extends TestCase
{
    /** @var GetDiscussions */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    private $searchResult = [
        'message' => [
            'items' => [
                [
                    'discussionId' => 'ae294277-c403-4556-8ccb-d0cc73d6fa17',
                    'creationDate' => '2020-04-28T14:27:59.251Z',
                    'type' => 'Default',
                    'status' => 'In Progress',
                    'subject' =>
                        [
                            'type' => 'Product',
                            'subType' => 'ProductDestroyed',
                            'value' => 'P123456',
                            'orderRef' => 'AZERT456',
                            'title' => 'Produit P123456 cassé à la livraison',
                        ],
                    'to' => 'Customer care'
                ]
            ]
        ],
        'status' => 200
    ];
    private $searchResultError = 'Error';
    private $searchResultNoResult = [
        'message' => [
            'items' => []
        ],
        'status' => 200
    ];

    private $messagesResult = [
        'message' => [
            'items' =>
                [
                    [
                        'message' => 'Bonjour, j\'ai un problème avec ma commande. Pouvez-vous m\'aider ?',
                        'fromType' => 'Customer',
                        'from' => 'Michel',
                        'toType' => 'Customer care',
                        'to' => 'Jean',
                        'sendDate' => '2020-04-28T14:27:59.251Z',
                    ],
                    [
                        'message' => 'Bonjour Michel, Nous mettons votre demande en réclamation et allons procéder au retour du produit. Cordialement, Jean.',
                        'fromType' => 'Customer care',
                        'from' => 'Jean',
                        'toType' => 'Customer',
                        'to' => 'Michel',
                        'sendDate' => '2020-04-28T14:30:59.251Z',
                        'discussionTypeChange' => 'Claim',
                    ],
                    [
                        'message' => 'Bonjour Marie, Nous avons un retour à effectuer, pouvez-vous lancer le processus. Cordialement, Jean.',
                        'fromType' => 'Customer care',
                        'from' => 'Jean',
                        'toType' => 'SalesChannel',
                        'to' => 'Marie',
                        'sendDate' => '2020-04-28T14:35:59.251Z',
                        'private' => true,
                    ]
                ]
        ],
        'status' => 200
    ];
    private $messagesResultNoMessage = [
        'message' => [
            'items' => []
        ],
        'status' => 200
    ];

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
    }

    public function testExecute()
    {
        $searchMock = $this->getMockBuilder(Search::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $searchMock->expects($this->any())->method('execute')->willReturn($this->searchResult);

        $messagesMock = $this->getMockBuilder(Get::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $messagesMock->expects($this->any())->method('execute')->willReturn($this->messagesResult);

        $this->instance = $this->objectManager->getObject(
            GetDiscussions::class,
            [
                'search' => $searchMock,
                'messages' => $messagesMock
            ]
        );

        $result = $this->instance->execute(42, '00000042');

        $this->assertEquals(1, count($result));
        $this->assertEquals(3, count($result[0]['messages']));
    }

    public function testExecuteSearchError()
    {
        $searchMock = $this->getMockBuilder(Search::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $searchMock->expects($this->any())->method('execute')->willReturn($this->searchResultError);

        $messagesMock = $this->getMockBuilder(Get::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $messagesMock->expects($this->any())->method('execute')->willReturn($this->messagesResult);

        $this->instance = $this->objectManager->getObject(
            GetDiscussions::class,
            [
                'search' => $searchMock,
                'messages' => $messagesMock
            ]
        );

        $result = $this->instance->execute(42, '00000042');

        $this->assertEquals('Error', $result);
    }

    public function testExecuteSearchNoResult()
    {
        $searchMock = $this->getMockBuilder(Search::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $searchMock->expects($this->any())->method('execute')->willReturn($this->searchResultNoResult);

        $messagesMock = $this->getMockBuilder(Get::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $messagesMock->expects($this->any())->method('execute')->willReturn($this->messagesResult);

        $this->instance = $this->objectManager->getObject(
            GetDiscussions::class,
            [
                'search' => $searchMock,
                'messages' => $messagesMock
            ]
        );

        $result = $this->instance->execute(42, '00000042');

        $this->assertEquals('No result', $result);
    }

    public function testExecuteNoMessages()
    {
        $searchMock = $this->getMockBuilder(Search::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $searchMock->expects($this->any())->method('execute')->willReturn($this->searchResult);

        $messagesMock = $this->getMockBuilder(Get::class)
            ->disableOriginalConstructor()
            ->setMethods([
                'execute'
            ])
            ->getMock();
        $messagesMock->expects($this->any())->method('execute')->willReturn($this->messagesResultNoMessage);

        $this->instance = $this->objectManager->getObject(
            GetDiscussions::class,
            [
                'search' => $searchMock,
                'messages' => $messagesMock
            ]
        );

        $result = $this->instance->execute(42, '00000042');

        $this->assertEquals(1, count($result));
        $this->assertEquals('No messages', $result[0]['messages']);
    }
}
