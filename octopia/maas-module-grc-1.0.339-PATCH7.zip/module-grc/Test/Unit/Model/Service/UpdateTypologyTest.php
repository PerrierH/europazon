<?php


namespace Maas\Grc\Test\Unit\Model\Service;

use Maas\Grc\Api\Data\TypologyInterface as Typology;
use Maas\Grc\Api\TypologyRepositoryInterface;
use Maas\Grc\Model\Discussion\GetTypologies;
use Maas\Grc\Model\TypologyFactory;
use Maas\Grc\Model\Service\UpdateTypology;
use Maas\Core\Test\Builder\AnyBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteria;
use Magento\Framework\DataObject;
use PHPUnit\Framework\TestCase;

/**
 * Class UpdateTypology
 * @package Maas\Grc\Model\Service
 */
class UpdateTypologyTest extends TestCase
{
    protected function setUp() {\Magento\Framework\App\Bootstrap::create(BP, $_SERVER)->createApplication(\Magento\Framework\App\Http::class);}


    /**
     * @dataProvider executeProvider
     *
     * @param $typologyResponse
     * @param $typologyInDB
     * @param $return
     * @param $expectedSaveCall
     * @param $expectedDeleteCall
     */
    public function testExecute($typologyResponse, $typologyInDB, $return, $expectedSaveCall, $expectedDeleteCall)
    {
        $getTypologies = AnyBuilder::createForClass($this, GetTypologies::class, [
            'execute' => [$this->once(), $typologyResponse, AnyBuilder::RETURN_VALUE]
        ])->build();

        $getAllReturnValue = [];
        if (count($typologyInDB) > 0) {
            foreach ($typologyInDB as $id=>$typologyCode) {
                $getAllReturnValue[] = AnyBuilder::createForClass($this, Typology::class, [
                    'getId' => [$this->any(), $id, AnyBuilder::RETURN_VALUE],
                    'getMaasCode' => [$this->any(), $typologyCode, AnyBuilder::RETURN_VALUE]
                ])->build();
            }
        }

        $collection = AnyBuilder::createForClass($this, DataObject::class, [
            'getItems' => [$this->atMost(2), $getAllReturnValue, AnyBuilder::RETURN_VALUE],
        ])->build();

        $typologyRepository = AnyBuilder::createForClass($this, TypologyRepositoryInterface::class, [
            'getList' => [$this->atMost(2), $collection, AnyBuilder::RETURN_VALUE],
            'save' => [$expectedSaveCall, null, AnyBuilder::RETURN_SELF],
            'deleteById' => [$expectedDeleteCall, null, AnyBuilder::RETURN_SELF]
        ])->build();

        $typology = AnyBuilder::createForClass($this, Typology::class, [])->build();

        $typologyFactory = AnyBuilder::createForClass($this, TypologyFactory::class, [
            'create' => [$this->any(), $typology, AnyBuilder::RETURN_VALUE]
        ])->build();

        $searchCriteria = AnyBuilder::createForClass($this, SearchCriteria::class, [])->build();

        $searchCriteriaBuilder = AnyBuilder::createForClass($this, SearchCriteriaBuilder::class, [
            'create' => [$this->any(), $searchCriteria, AnyBuilder::RETURN_VALUE]
        ])->build();

        $entity = AnyBuilder::createForClass($this, UpdateTypology::class, [
        ])->setConstructorArgs([
            'getTypologies' => $getTypologies,
            'typologyRepository' => $typologyRepository,
            'typologyFactory' => $typologyFactory,
            'searchCriteriaBuilder' => $searchCriteriaBuilder,
        ])
            ->build();

        $this->assertEquals($return, $entity->execute());
    }

    public function executeProvider()
    {
        yield 'empty response' => [
            'typologyResponse' => null,
            '$typologyInDB' => [],
            'return' => false,
            'expectedSaveCall' => $this->never(),
            'expectedDeleteCall' => $this->never(),
        ];
        yield 'invalid response' => [
            'typologyResponse' => [
                'message' => [
                    [
                        "typology" => "notOrder",
                        "subTypologyList" => [
                            "SubTypo 1",
                        ]
                    ]
                ]
            ],
            '$typologyInDB' => [],
            'return' => true,
            'expectedSaveCall' => $this->never(),
            'expectedDeleteCall' => $this->never(),
        ];
        yield 'empty DB case' => [
            'typologyResponse' => [
                'message' => [
                    [
                        "typology" => "order",
                        "subTypologyList" => [
                            "missingProductsInOrder",
                            "productIsDamaged",
                            "productIsNotWorking"
                        ]
                    ],
                    [
                        "typology" => "notOrder",
                        "subTypologyList" => [
                            "SubTypo 1",
                        ]
                    ]
                ]
            ],
            '$typologyInDB' => [],
            'return' => true,
            'expectedSaveCall' => $this->exactly(3),
            'expectedDeleteCall' => $this->never(),
        ];
        yield 'nominal case' => [
            'typologyResponse' => [
                'message' => [
                    [
                        "typology" => "order",
                        "subTypologyList" => [
                            "missingProductsInOrder",
                            "productIsDamaged",
                            "productIsNotWorking",
                            "new1",
                            "new2"
                        ]
                    ],
                    [
                        "typology" => "notOrder",
                        "subTypologyList" => [
                            "SubTypo 1",
                        ]
                    ]
                ]
            ],
            '$typologyInDB' => [
                "missingProductsInOrder",
                "productIsDamaged",
                "productIsNotWorking",
                "old1",
                "old2",
            ],
            'return' => true,
            'expectedSaveCall' => $this->exactly(2),
            'expectedDeleteCall' => $this->exactly(2),
        ];
    }
}
