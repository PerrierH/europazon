<?php

namespace Maas\Grc\Test\Unit\Model\Discussion;

use Exception;
use Maas\Core\Model\Token;
use Maas\Core\Test\Builder\AnyBuilder;
use Maas\Grc\Model\Discussion\Notify;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Maas\ImportExport\Test\Builder\Model\AbstractApiBuilder;
use Maas\Grc\Model\Email\Sender\GrcSender;
use Magento\Sales\Model\OrderRepository;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Log\Model\ResourceModel\Report\Collection as ReportCollection;
use Maas\Log\Model\Report;
use Maas\Log\Model\Error as ErrorLogger;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;
use Magento\Framework\Api\SearchCriteria;
use \StdClass;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use Maas\Grc\Model\Config;


class NotifyTest extends TestCase
{
    /** @var Notify */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;

    /** @var int */
    public $alreadyLaunchedCollectionSize = 0;
    /** @var bool */
    public $grcSenderReturn = true;
    /** @var int */
    public $orderId = 42;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);

        $grcSender = AnyBuilder::createForClass(
            $this,
            GrcSender::class,
            [
                'send' => [
                    $this->any(),
                    function () {
                        return $this->grcSenderReturn;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $order = AnyBuilder::createForClass(
            $this,
            Order::class
        )->build();

        $orders = AnyBuilder::createForClass(
            $this,
            StdClass::class,
            [
                'getItems' => [$this->any(), [$order]]
            ]
        )->build();

        $orderRepository = AnyBuilder::createForClass(
            $this,
            OrderRepository::class,
            [
                'getList' => [$this->any(), $orders]
            ]
        )->build();

        $firstReport = AnyBuilder::createForClass(
            $this,
            Report::class,
            [
                'getUpdatedAt' => [$this->any(), '2021-05-18T00:00:00+00:00']
            ]
        )->build();

        $reportCollection = AnyBuilder::createForClass(
            $this,
            ReportCollection::class,
            [
                'addOrder' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'addFieldToFilter' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'getFirstItem' => [$this->any(), $firstReport],
                'getSize' => [
                    $this->any(),
                    function () {
                        return $this->alreadyLaunchedCollectionSize;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $reportCollectionFactory = AnyBuilder::createForClass(
            $this,
            ReportCollectionFactory::class,
            [
                'create' => [$this->any(), $reportCollection]
            ]
        )->build();

        $searchCriteria = AnyBuilder::createForClass($this, SearchCriteria::class)->build();

        $searchCriteriaBuilder = AnyBuilder::createForClass(
            $this,
            SearchCriteriaBuilder::class,
            [
                'addFilters' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'create' => [$this->any(), $searchCriteria]
            ]
        )->build();

        $filterBuilder = AnyBuilder::createForClass(
            $this,
            FilterBuilder::class,
            [
                'setField' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'setConditionType' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'setValue' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'create' => [$this->any(), true]
            ]
        )->build();

        $order = AnyBuilder::createForClass(
            $this,
            Order::class,
            [
                'load' => [$this->any(), true, AnyBuilder::RETURN_SELF],
                'getId' => [
                    $this->any(),
                    function () {
                        return $this->orderId;
                    },
                    AnyBuilder::RETURN_CALLBACK
                ]
            ]
        )->build();

        $orderFactory = AnyBuilder::createForClass(
            $this,
            OrderFactory::class,
            [
                'create' => [$this->any(), $order]
            ]
        )->build();

        $grcConfig = AnyBuilder::createForClass(
            $this,
            Config::class,
            [
                'getSalesChannelIdentifier' => [$this->any(), 'DummySalesChannel']
            ]
        )->build();

        $httpClientFactory = ZendClientFactoryBuilder::create($this)
            ->addConfig(
                [
                    'request_body' => [
                        '{"totalItems":1, "items":[{"orderReference":"00000001"}]}',
                        '{"totalItems":1, "items":[]}'
                    ]
                ]
            )
            ->build();

        $this->di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'grcSender' => $grcSender,
                'orderRepository' => $orderRepository,
                'reportCollectionFactory' => $reportCollectionFactory,
                'searchCriteriaBuilder' => $searchCriteriaBuilder,
                'filterBuilder' => $filterBuilder,
                'httpClientFactory' => $httpClientFactory,
                'orderFactory' => $orderFactory,
                'grcConfig' => $grcConfig
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Notify::class,
            $this->di
        );
    }

    public function testExecute()
    {
        $result = $this->instance->execute([]);

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(1, $result['successItemsCount']);
        $this->assertEquals(0, $result['warningItemsCount']);
        $this->assertEquals(0, $result['errorItemsCount']);
    }

    public function testExecuteUnknownOrder()
    {
        $this->orderId = null;

        $result = $this->instance->execute([]);

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(0, $result['successItemsCount']);
        $this->assertEquals(1, $result['warningItemsCount']);
        $this->assertEquals(0, $result['errorItemsCount']);
    }

    public function testExecuteErrorSending()
    {
        $this->grcSenderReturn = false;

        $result = $this->instance->execute([]);

        $this->assertEquals(1, $result['itemsCount']);
        $this->assertEquals(0, $result['successItemsCount']);
        $this->assertEquals(0, $result['warningItemsCount']);
        $this->assertEquals(1, $result['errorItemsCount']);
    }

}
