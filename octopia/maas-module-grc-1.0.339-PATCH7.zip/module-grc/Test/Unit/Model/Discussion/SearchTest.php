<?php

namespace Maas\Grc\Test\Unit\Model\Discussion;

use Exception;
use Maas\Core\Test\Builder\ZendClientFactoryBuilder;
use Maas\Grc\Model\Discussion\Search;
use Maas\Grc\Test\Builder\AbstractApiBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

class SearchTest extends TestCase
{
    /** @var Search */
    private $instance;

    /** @var ObjectManager */
    private $objectManager;

    /** @var AbstractApiBuilder */
    private $abstractApiBuilder;

    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);
        $this->abstractApiBuilder = AbstractApiBuilder::create($this);

        $this->instance = $this->objectManager->getObject(
            Search::class,
            $this->abstractApiBuilder->getDi()
        );
    }

    public function testDoExecute()
    {
        $result = $this->instance->execute(['orderId' => 42, 'orderReference' => '00000042']);

        $this->assertEquals(["message" => ["test", "data"], 'status' => 200], $result);
    }

    public function testDoExecuteError()
    {
        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'httpClientFactory' => ZendClientFactoryBuilder::create($this)->addConfig(['request_status' => 400])->build()
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Search::class,
            $di
        );

        $result = $this->instance->execute(['orderId' => 42, 'orderReference' => '00000042']);

        $this->assertEquals(["message" => ["test", "data"], 'status' => 400], $result);
    }

    public function testDoExecuteException()
    {
        $di = array_merge(
            $this->abstractApiBuilder->getDi(),
            [
                'httpClientFactory' => ZendClientFactoryBuilder::create($this)->addConfig(['request_throw_exception' => true])->build()
            ]
        );

        $this->instance = $this->objectManager->getObject(
            Search::class,
            $di
        );

        $result = $this->instance->execute(['orderId' => 42, 'orderReference' => '00000042']);

        $this->assertEquals(["message" => "Exception message", 'status' => 500], $result);
    }

    public function testArgs()
    {

        $data = [
            'arg1' => 'test1',
            'arg2' => 'test2'
        ];

        $this->instance->setArgs($data);

        $this->assertEquals($data, $this->instance->getArgs());
    }

    public function testHeaders()
    {

        $data1 = [
            'header1',
            'header2'
        ];
        $header3 = 'header3';
        $data2 = array_merge($data1, [$header3]);

        $this->instance->setHeaders($data1);

        $this->assertEquals($data1, $this->instance->getHeaders());

        $this->instance->addHeader($header3);

        $this->assertEquals($data2, $this->instance->getHeaders());
    }

    public function testBody()
    {

        $data = 'Test Body';

        $this->instance->setBody($data);

        $this->assertEquals($data, $this->instance->getBody());
    }
}
