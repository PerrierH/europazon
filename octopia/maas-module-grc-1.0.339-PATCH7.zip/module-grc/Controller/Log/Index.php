<?php

namespace Maas\Grc\Controller\Log;

use Maas\Log\Model\Debug;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

/**
 * Class Index
 *
 * @package Maas\Grc\Controller\Log
 * @codeCoverageIgnore
 */
class Index extends Action
{
    /** @var Debug */
    private $debugLogger;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param Debug $debugLogger
     */
    public function __construct(
        Context $context,
        Debug $debugLogger
    )
    {
        $this->debugLogger = $debugLogger;
        parent::__construct($context);

    }

    /**
     * @return void
     */
    public function execute()
    {
        $params = $this->_request->getParams();
        $this->debug($params);
    }

    /**
     * @param array $logData
     */
    public function debug(array $logData)
    {
        $data = sprintf(
            '%s: %s -  %s',
            $logData['response']['code'],
            $logData['response']['message'],
            $this->serializer->serialize(
                [
                    'url' => $logData['url'],
                    'headers' => $logData['headers'],
                    'body' => $logData['data'],
                    'response' => $logData['response']
                ]
            )
        );

        $this->debugLogger->debug($data);
    }

}
