<?php

namespace Maas\Grc\Controller\Ajax;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Maas\Grc\Model\Discussion\Create as CreateDiscussion;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\Result\Json;
use Maas\Grc\Model\Service\FileAttachments;


/**
 * Class Create
 *
 * @package Maas\Grc\Controller\Log
 * @codeCoverageIgnore
 */
class Create extends Action
{
    /** @var CreateDiscussion */
    private $discussion;

    /** @var JsonFactory */
    private $jsonFactory;

    /** @var FileAttachments */
    private $fileAttachments;

    /**
     * @param Context $context
     * @param CreateDiscussion $discussion
     * @param JsonFactory $jsonFactory
     * @param FileAttachments $fileAttachments
     */
    public function __construct(
        Context          $context,
        CreateDiscussion $discussion,
        JsonFactory      $jsonFactory,
        FileAttachments  $fileAttachments
    )
    {
        $this->discussion = $discussion;
        $this->jsonFactory = $jsonFactory;
        $this->fileAttachments = $fileAttachments;

        parent::__construct($context);
    }

    /**
     * @return Json
     * @throws \Exception
     */
    public function execute()
    {
        $resultJson = $this->jsonFactory->create();
        $params = $this->_request->getParams();

        if (empty($params) || (strlen($params['subject']) > 120) || (strlen($params['message']['body']) > 5000)) {
            $resultJson->setData(['Error', 'params' => $params]);
            $resultJson->setHttpResponseCode(400);
            return $resultJson;
        }

        $files = $this->_request->getFiles();
        $attachments = $this->fileAttachments->prepareAttachments($files);

        if ($attachments === 'Error') {
            $resultJson->setData(['Error']);
            $resultJson->setHttpResponseCode(500);
            return $resultJson;
        } else {
            $params['message']['attachments'] = $attachments;
        }

        $response = $this->discussion->execute($params);

        if (($response == 'Error') || ($response['status'] >= 400)) {
            $resultJson->setData(['Error', 'response' => $response]);
            $resultJson->setHttpResponseCode(500);
        } else {
            $resultJson->setData($response);
        }

        return $resultJson;
    }

}
