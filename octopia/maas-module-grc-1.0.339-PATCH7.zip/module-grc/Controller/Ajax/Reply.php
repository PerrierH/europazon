<?php

namespace Maas\Grc\Controller\Ajax;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Maas\Grc\Model\Message\Reply as Message;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\Result\Json;
use Maas\Grc\Model\Service\FileAttachments;


/**
 * Class Reply
 *
 * @package Maas\Grc\Controller\Ajax
 * @codeCoverageIgnore
 */
class Reply extends Action
{
    /** @var Message */
    private $message;

    /** @var JsonFactory */
    private $jsonFactory;

    /** @var FileAttachments */
    private $fileAttachments;


    /**
     * @param Context $context
     * @param Message $message
     * @param JsonFactory $jsonFactory
     * @param FileAttachments $fileAttachments
     */
    public function __construct(
        Context         $context,
        Message         $message,
        JsonFactory     $jsonFactory,
        FileAttachments $fileAttachments
    )
    {
        $this->message = $message;
        $this->jsonFactory = $jsonFactory;
        $this->fileAttachments = $fileAttachments;

        parent::__construct($context);
    }

    /**
     * @return Json
     * @throws \Exception
     */
    public function execute()
    {
        $resultJson = $this->jsonFactory->create();
        $params = $this->_request->getParams();

        if (empty($params) || (strlen($params['body']) > 5000)) {
            $resultJson->setData(['Error', 'params' => $params]);
            $resultJson->setHttpResponseCode(400);
            return $resultJson;
        }

        $files = $this->_request->getFiles();
        $attachments = $this->fileAttachments->prepareAttachments($files);

        if ($attachments === 'Error') {
            $resultJson->setData(['Error']);
            $resultJson->setHttpResponseCode(500);
            return $resultJson;
        } else {
            $params['attachments'] = $attachments;
        }

        $response = $this->message->execute($params);

        if (($response == 'Error') || ($response['status'] >= 400)) {
            $resultJson->setData(['Error']);
            $resultJson->setHttpResponseCode(500);
        } else {
            $resultJson->setData($response);
        }

        return $resultJson;
    }

}
