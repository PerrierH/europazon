<?php

namespace Maas\Grc\Controller\Order;

use Magento\Sales\Controller\AbstractController\View;

/**
 * Class Complaint
 *
 * @package Maas\Grc\Controller\Order
 * @codeCoverageIgnore
 */
class Complaint extends View
{
    /**
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        parent::execute();
        $this->_view->loadLayout();
        $this->_view->renderLayout();
    }
}
