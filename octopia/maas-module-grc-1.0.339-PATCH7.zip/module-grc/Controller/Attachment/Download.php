<?php

namespace Maas\Grc\Controller\Attachment;

use Exception;
use Magento\Framework\App\Action\Action;

class Download extends Action
{
    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        try {
            $this->downloadFile($this->_request->getPost());
            return;
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(__('An error occurred while download the attachment'));
        }
        return $this->_redirect($this->_redirect->getRefererUrl());
    }

    /**
     * Download attachment
     * @param $data
     * @return void
     */
    private function downloadFile($data)
    {
        $content = base64_decode($data['file_content']);
        $filename = sprintf('%s.%s', $data['file_name'], $data['file_type']);
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . $filename);
        echo $content;
    }

}
