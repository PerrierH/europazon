<?php

namespace Maas\Grc\Controller\Adminhtml\Typology;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 *
 * @method \Magento\Framework\App\Request\Http getRequest()
 * @method \Magento\Framework\App\Response\Http getResponse()
 * @codeCoverageIgnore
 * @package Maas\Grc\Controller\Adminhtml\Typology
 */
class Index extends Action
{
    /**
     * @inheritdoc
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $this->_setActiveMenu('Maas_Grc::typology');
        $resultPage->addBreadcrumb(__('Core'), __('Complaints motives'));
        $resultPage->getConfig()->getTitle()->prepend(__('Complaints motives'));

        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Maas_Grc::typology');
    }
}
