<?php
namespace Maas\Grc\Controller\Adminhtml\Typology;

use Maas\Grc\Api\TypologyRepositoryInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\Redirect;

/**
 * Class Save
 * @package Magento\Sales\Controller\Adminhtml\Order\Status
 * @codeCoverageIgnore
 */
class Save extends Action
{
    /** @var TypologyRepositoryInterface  */
    private $typologyRepository;

    /**
     * Save constructor.
     * @param Context                     $context
     * @param TypologyRepositoryInterface $typologyRepository
     */
    public function __construct(
        Context $context,
        TypologyRepositoryInterface $typologyRepository
    ) {
        $this->typologyRepository = $typologyRepository;
        parent::__construct($context);
    }

    /**
     * Save typology form processing
     *
     * @return Redirect
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $typology = $this->typologyRepository->get($data['id']);
        $typology->setEnabled(array_key_exists('enabled', $data) ? $data['enabled'] : 0);
        $typology->setStoreValues($data['store_values']);
        $this->typologyRepository->save($typology);

        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/');
    }
}
