<?php
namespace Maas\Grc\Controller\Adminhtml\Typology;

use Maas\Grc\Model\Typology;
use Maas\Grc\Model\TypologyRepository;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Edit
 * @package Maas\Grc\Controller\Adminhtml\Typology
 * @codeCoverageIgnore
 */
class Edit extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var TypologyRepository
     */
    protected $entityRepository;

    /**
     * Edit constructor.
     * @param Context            $context
     * @param PageFactory        $resultPageFactory
     * @param TypologyRepository $entityRepository
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        TypologyRepository $entityRepository
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->entityRepository = $entityRepository;
    }

    /**
     * Editing existing status form
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var Page $resultPage */
        $this->_view->loadLayout();
        $id = $this->getRequest()->getParam('id');

        try {
            /** @var Typology $typology */
            $typology = $this->entityRepository->get($id);

            $this->_view->getPage()->getConfig()->getTitle()->prepend($typology->getMaasCode());
        } catch (NoSuchEntityException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/');
        }

        return $this->resultFactory->create(ResultFactory::TYPE_PAGE);
    }
}
