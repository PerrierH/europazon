<?php

namespace Maas\Grc\Setup;

use Maas\Grc\Model\ResourceModel\Typology;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Zend_Db_Exception;

/**
 * Class InstallSchema
 *
 * @package Mass\Grc\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     *
     * @throws Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        $this->createTypologyTable($setup, $connection);
        $this->createTypologyStoreTable($setup, $connection);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param $connection
     */
    private function createTypologyTable(SchemaSetupInterface $setup, $connection)
    {
        /** @var Table $offerTable */
        $table = $connection->newTable(
            $setup->getTable(Typology::TYPOLOGY_TABLE_NAME)
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true,],
            'Entity Id'
        )->addColumn(
            'maas_code',
            Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'Maas typology code'
        )->addColumn(
            'enabled',
            Table::TYPE_INTEGER,
            null,
            ['unsigned' => true],
            'Is the typology enabled'
        );

        $connection->createTable($table);
    }

    private function createTypologyStoreTable(SchemaSetupInterface $setup, $connection)
    {
        /** @var Table $offerTable */
        $table = $connection->newTable(
            $setup->getTable(Typology::TYPOLOGY_STORE_TABLE_NAME)
        )->addColumn(
            'typology_id',
            Table::TYPE_INTEGER,
            null,
            ['unsigned' => true, 'nullable' => false, 'primary' => true,],
            'Typlology Id'
        )->addColumn(
            'store_id',
            Table::TYPE_SMALLINT,
            5,
            ['unsigned' => true, 'nullable' => false, 'primary' => true,],
            'Store view id'
        )->addColumn(
            'value',
            Table::TYPE_TEXT,
            255,
            [],
            'Typology value as displayed on the store view'
        );

        $table->addForeignKey(
            $setup->getFkName(
                $setup->getTable(Typology::TYPOLOGY_STORE_TABLE_NAME),
                'typology_id',
                Typology::TYPOLOGY_TABLE_NAME,
                'entity_id'
            ),
            'typology_id',
            $setup->getTable(Typology::TYPOLOGY_TABLE_NAME),
            'entity_id',
            Table::ACTION_CASCADE,
            Table::ACTION_CASCADE
        );

        $table->addForeignKey(
            $setup->getFkName(
                $setup->getTable(Typology::TYPOLOGY_STORE_TABLE_NAME),
                'store_id',
                'store',
                'store_id'
            ),
            'store_id',
            $setup->getTable('store'),
            'store_id',
            Table::ACTION_CASCADE,
            Table::ACTION_CASCADE
        );

        $connection->createTable($table);
    }
}
