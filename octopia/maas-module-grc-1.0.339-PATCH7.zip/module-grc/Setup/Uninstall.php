<?php

namespace Maas\Grc\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 *
 * @package Maas\Grc\Setup
 * @SuppressWarnings(PHPMD)
 * @codeCoverageIgnore
 */
class Uninstall implements UninstallInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $uninstaller = $setup;
        $connection = $setup->getConnection();

        $emailTemplateTable = $uninstaller->getTable('email_template');
        $connection->delete($emailTemplateTable,
            "`orig_template_code` = 'maas_grc_email_new_message_notification_template'");

        $configTable = $uninstaller->getTable('core_config_data');
        $connection->delete($configTable, "`path` like 'maas_grc/%' or `path` like 'trans_email/ident_maas_grc/%'");
        $connection->delete($configTable, "`path` like '%/identity' and `value` = 'maas_grc'");
        $connection->delete($configTable,
            "`path` like '%/template' and `value` = 'maas_grc_email_new_message_notification_template'");
        $connection->delete($configTable,
            "`path` like '%/guest_template' and `value` = 'maas_grc_email_new_message_notification_template'");


        $connection->dropTable($setup->getTable('maas_grc_order_typology_store'));
        $connection->dropTable($setup->getTable('maas_grc_order_typology'));

        $setup->endSetup();
    }
}
