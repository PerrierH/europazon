<?php

namespace Maas\Grc\Ui\DataProvider;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Maas\Grc\Model\ResourceModel\Typology\MissingStoreValues\Collection;
use Maas\Grc\Model\ResourceModel\Typology\MissingStoreValues\CollectionFactory;

/**
 * Class TypologyProvider
 * @package Maas\Grc\Ui\DataProvider
 * @codeCoverageIgnore
 */
class TypologyProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * Construct
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (!$this->getCollection()->isLoaded()) {
            $this->getCollection()->load();
        }
        return $this->getCollection()->toArray();
    }
}
