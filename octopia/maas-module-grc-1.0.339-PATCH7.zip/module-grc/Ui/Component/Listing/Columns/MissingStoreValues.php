<?php

namespace Maas\Grc\Ui\Component\Listing\Columns;

use Maas\Grc\Block\Adminhtml\Typology\Grid\MissingStoreValue;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class MissingStoreValues
 * @package Maas\Grc\Ui\Component\Listing\Columns
 * @codeCoverageIgnore
 */
class MissingStoreValues extends Column
{
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                if ($item['missing_store_value']) {
                    $class = 'grid-severity-major';
                    $message = __('Warning - Missing translations');
                } else {
                    $class = 'grid-severity-notice';
                    $message = __('OK');
                }
                $item[$this->getData('name')] = '<span class="' . $class . '">' . $message . '</span>';
            }
        }
        return $dataSource;
    }

}
