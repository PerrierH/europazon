<?php

namespace Maas\Grc\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface TypologySearchResultsInterface
 *
 * @package Maas\Grc\Api\Data
 */
interface TypologySearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get typologys list.
     *
     * @return TypologyInterface[]
     */
    public function getItems();

    /**
     * Set typologys list.
     *
     * @param TypologyInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
