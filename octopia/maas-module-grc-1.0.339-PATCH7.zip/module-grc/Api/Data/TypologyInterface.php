<?php

namespace Maas\Grc\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

/**
 * Interface TypologyInterface
 *
 * @package Maas\Grc\Api\Data
 */
interface TypologyInterface extends ExtensibleDataInterface
{
    const MAAS_CODE = 'maas_code';

    const STORE_VALUES = 'store_values';

    const ENABLED = 'enabled';

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @param int $id
     *
     * @return this
     */
    public function setId($id);

    /**
     * @return int|null
     */
    public function getMaasCode();

    /**
     * @param string $code
     *
     * @return this
     */
    public function setMaasCode($code);

    /**
     * @return array|null
     */
    public function getStoreValues();

    /**
     * @param null|int $storeId
     * @return string
     */
    public function getStoreValue($storeId = null);

    /**
     * @param array $value
     *
     * @return this
     */
    public function setStoreValues($value);

    /**
     * @return bool|null
     */
    public function getEnabled();

    /**
     * @param boolean $enabled
     *
     * @return this
     */
    public function setEnabled($enabled);
}
