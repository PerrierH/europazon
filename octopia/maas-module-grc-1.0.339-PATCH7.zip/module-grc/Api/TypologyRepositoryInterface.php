<?php

namespace Maas\Grc\Api;

use Maas\Grc\Api\Data\TypologyInterface;
use Maas\Grc\Api\Data\TypologySearchResultsInterface;
use Magento\Framework\Api\SearchCriteriaInterface;


/**
 * Interface TypologyRepositoryInterface
 *
 * @package Maas\Grc\Api
 */
interface TypologyRepositoryInterface
{
    /**
     * @param TypologyInterface $typology
     *
     * @return TypologyInterface
     */
    public function save(TypologyInterface $typology);

    /**
     * @param int $id
     *
     * @return TypologyInterface
     */
    public function get($id);

    /**
     * @param TypologyInterface $typology
     */
    public function delete(TypologyInterface $typology);

    /**
     * @param int $id
     */
    public function deleteById($id);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     *
     * @return TypologySearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @return \Magento\Framework\DataObject[]
     */
    public function getTypologyWithMissingValue();

    /**
     * @return bool
     */
    public function hasTypologyWithMissingValue();
}
