<?php

namespace Maas\Grc\Console\Command;

use Maas\Core\Model\Config as ConfigProxy;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Maas\Grc\Model\Discussion\Notify as NotifyAlias;
use Magento\Framework\App\Area;
use Magento\Framework\App\State;


/**
 * Class Notify
 *
 * @package Maas\Grc\Console\Command
 * @codeCoverageIgnore
 */
class Notify extends Command
{
    /** @var ConfigProxy */
    public $configModel;

    /** @var NotifyAlias */
    public $notify;

    /** @var State * */
    protected $state;

    /**
     * Notify constructor.
     *
     * @param ConfigProxy $config
     * @param NotifyAlias $notify
     */
    public function __construct(
        ConfigProxy $config,
        NotifyAlias $notify,
        State       $state
    )
    {
        $this->state = $state;
        $this->configModel = $config;
        $this->notify = $notify;
        parent::__construct();
    }

    /**
     * @inheritDoc
     */
    protected function configure()
    {
        $this->setName('maas:grc:notify');
        $this->setDescription('Notify customer of new GRC message');

        parent::configure();
    }

    /**
     * Execute the command
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return null|int
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if ($this->configModel->isModuleEnabled()) {
            $this->state->setAreaCode(Area::AREA_CRONTAB);
            $this->notify->execute();
        } else {
            $output->writeln('<info>You cannot execute this command because Maas module is disabled </info>');
        }
    }

}
