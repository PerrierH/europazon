<?php

namespace Maas\Grc\Console\Command;

use Maas\Grc\Model\Service\UpdateTypology\Proxy as UpdateService;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;


/**
 * Class Typology
 *
 * @package Maas\Grc\Console\Command
 * @codeCoverageIgnore
 */
class Typology extends Command
{
    /**
     * @var UpdateService
     */
    private $updateService;

    public function __construct(
        UpdateService $updateService
    )
    {
        $this->updateService = $updateService;
        parent::__construct();
    }

    /**
     * @inheritDoc
     */
    protected function configure()
    {
        $this->setName('maas:grc:typology');
        $this->setDescription('Import GRC Typologies');
        parent::configure();
    }

    /**
     * Execute the command
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     *
     * @return null|int
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            $this->updateService->execute();
            $output->writeln('<info>All typlogies imported</info>');
        } catch (\Exception $exception) {
            $output->writeln(sprintf('<error>Error occured:%s</error>', $exception->getMessage()));
        }

    }
}
