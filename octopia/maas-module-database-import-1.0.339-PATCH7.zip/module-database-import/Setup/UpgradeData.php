<?php

namespace Maas\DatabaseImport\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;


class UpgradeData implements UpgradeDataInterface
{
    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            $connection = $setup->getConnection();
            $connection->query(
                "UPDATE " . $connection->getTableName('maas_offer') . " AS mo
                 INNER JOIN " . $connection->getTableName('maas_seller_entity') . " AS mse ON mo.seller_id = mse.entity_id
                  SET mo.seller_id = mse.maas_entity_id"
            );
        }

        $setup->endSetup();
    }

}
