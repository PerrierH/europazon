<?php

use Magento\Framework\Component\ComponentRegistrar;

/**
 * @codeCoverageIgnore
 */
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Maas_DatabaseImport', __DIR__);
