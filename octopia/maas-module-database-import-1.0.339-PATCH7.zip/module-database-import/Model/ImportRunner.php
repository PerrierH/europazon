<?php

namespace Maas\DatabaseImport\Model;

use InvalidArgumentException;
use Maas\DatabaseImport\Model\Logger\AbstractLogger;
use Maas\DatabaseImport\Model\Logger\EchoLoggerFactory;
use Maas\DatabaseImport\Model\Logger\ReportLoggerFactory;
use Maas\DatabaseImport\Model\Logger\ReportLoggerLightFactory;
use Maas\DatabaseImport\Model\Xml\Reader;
use Maas\Log\Api\Data\ReportInterface;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Monolog\Logger;
use PDOException;
use Exception;

/**
 * Class ImportRunner
 *
 * Use this to initialize and start imports.
 * Uses ObjectManager in order to process XML.
 *
 * @package Maas\DatabaseImport\Model
 */
class ImportRunner
{
    const CACHE_KEY = 'maas_dbimport_config';

    /** @var Reader */
    protected $xmlReader;

    /** @var ObjectManagerInterface */
    protected $objectManager;

    /** @var array */
    protected $config = [];

    /** @var string|null */
    protected $code = null;

    /** @var AbstractStep */
    protected $instance = null;

    /** @var CacheInterface */
    protected $cache;

    /** @var SerializerInterface */
    protected $serializer;

    /** @var AbstractLogger */
    protected $logger;

    /** @var EchoLoggerFactory */
    protected $echoLoggerFactory;

    /** @var ReportLoggerFactory */
    protected $reportLoggerFactory;

    /** @var ReportLoggerLightFactory */
    protected $reportLoggerLightFactory;

    /**
     * ImportRunner constructor
     *
     * @param Reader $xmlReader
     * @param ObjectManagerInterface $objectManager
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param EchoLoggerFactory $echoLoggerFactory
     * @param ReportLoggerFactory $reportLoggerFactory
     * @param ReportLoggerLightFactory $reportLoggerLightFactory
     */
    public function __construct(
        Reader                   $xmlReader,
        ObjectManagerInterface   $objectManager,
        CacheInterface           $cache,
        SerializerInterface      $serializer,
        EchoLoggerFactory        $echoLoggerFactory,
        ReportLoggerFactory      $reportLoggerFactory,
        ReportLoggerLightFactory $reportLoggerLightFactory
    )
    {
        $this->xmlReader = $xmlReader;
        $this->objectManager = $objectManager;
        $this->cache = $cache;
        $this->serializer = $serializer;
        $this->echoLoggerFactory = $echoLoggerFactory;
        $this->reportLoggerFactory = $reportLoggerFactory;
        $this->reportLoggerLightFactory = $reportLoggerLightFactory;
    }

    /**
     * @param string $code
     *
     * @return array
     */
    public function initialize($code)
    {
        if ($this->code == $code) {
            return $this->config;
        }

        try {
            $config = $this->serializer->unserialize($this->cache->load(self::CACHE_KEY));
        } catch (InvalidArgumentException $iae) {
            $config = $this->xmlReader->read();
            $this->cache->save($this->serializer->serialize($config), self::CACHE_KEY);
        }
        if (isset($config[$code])) {
            $this->config = $config[$code];
            $this->code = $code;
            $this->instance = $this->instantiateStep($this->config);
        }
        return $config;
    }

    /**
     * @param array $stepConfig
     *
     * @return mixed
     */
    protected function instantiateStep($stepConfig)
    {
        $children = [];
        foreach ($stepConfig['children'] as $key => $childStepConfig) {
            $children[$key] = $this->instantiateStep($childStepConfig);
        }
        return $this->objectManager->create($stepConfig['type'], [
            'config' => $stepConfig['config'],
            'children' => $children
        ]);
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function run(&$rows, &$context = [])
    {
        if (is_null($this->code)) {
            return $this;
        }
        if (is_null($this->logger)) {
            $this->logger = $this->echoLoggerFactory->create();
        }
        $this->instance->setLogger($this->logger);
        $this->logger->initialize();
        try {
            $this->instance->execute($rows, $context);
        } catch (PDOException $e) {
            $this->logger->log($e->getMessage(), Logger::ERROR);
        } catch (Exception $e) {
            $this->logger->log($e->getMessage(), Logger::CRITICAL);
        }
        return $this;
    }

    /**
     * Replaces the echo (console output) logger with one using reports from Maas_Log
     *
     * Two loggers are available: a regular one which saves as often as possible, and a light one, which saves less
     * frequently
     *
     * @param ReportInterface $report
     * @param bool $useLightLogger
     * @param bool $replaceLogger If false and a logger is already instantiated, do nothing
     *
     * @return $this
     */
    public function setReport(ReportInterface $report, $useLightLogger = true, $replaceLogger = false)
    {
        if ($this->logger && (!$replaceLogger)) {
            return $this;
        }
        $reportLogger = $useLightLogger ? $this->reportLoggerLightFactory->create() : $this->reportLoggerFactory->create();
        $reportLogger->setReport($report);
        $this->logger = $reportLogger;
        return $this;
    }
}
