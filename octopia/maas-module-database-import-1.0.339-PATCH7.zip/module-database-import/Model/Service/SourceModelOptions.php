<?php

namespace Maas\DatabaseImport\Model\Service;

use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Eav\Model\Entity\Attribute\Option;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Phrase;

/**
 * Class SourceModelOptions
 *
 * Calls on different source models to fetch available options for each attribute
 *
 * @package Maas\DatabaseImport\Model\Service
 */
class SourceModelOptions
{
    /**
     * @var AttributeRepositoryInterface
     */
    protected $attributeRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var OptionKey
     */
    protected $optionKeyService;

    /**
     * SourceModelOptions constructor
     *
     * @param AttributeRepositoryInterface $attributeRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OptionKey $optionKeyService
     */
    public function __construct(
        AttributeRepositoryInterface $attributeRepository,
        SearchCriteriaBuilder        $searchCriteriaBuilder,
        OptionKey                    $optionKeyService
    )
    {
        $this->attributeRepository = $attributeRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->optionKeyService = $optionKeyService;
    }

    /**
     * @param string $entityTypeCode
     *
     * @return array
     */
    public function getAllAttributeOptions($entityTypeCode)
    {
        $attributes = $this->attributeRepository->getList($entityTypeCode,
            $this->searchCriteriaBuilder
                ->addFilter('source_model', '', 'notnull')
                ->addFilter('source_model', '', 'neq')->create()
        )->getItems();

        $result = [];
        foreach ($attributes as $attribute) {
            $code = $attribute->getAttributeCode();
            $result[$code] = [];
            $options = $attribute->getOptions();
            foreach ($options as $option) {
                $label = $this->optionKeyService->filter($this->getOptionLabel($option));
                $result[$code][$label] = $option->getValue();
            }
        }
        return $result;
    }

    /**
     * @param Option $option
     *
     * @return string
     */
    protected function getOptionLabel($option)
    {
        $label = $option->getLabel();
        if (is_object($label) && $label instanceof Phrase) {
            $label = $label->getText();
        }
        return $label;
    }
}