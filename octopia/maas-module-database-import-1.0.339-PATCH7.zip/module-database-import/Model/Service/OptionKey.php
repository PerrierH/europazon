<?php

namespace Maas\DatabaseImport\Model\Service;

use Magento\Framework\Filter\Translit;

/**
 * Class OptionKey
 *
 * Used to unify operations in transforming option values to usable and easily comparable keys
 *
 * @package Maas\DatabaseImport\Model\Service
 */
class OptionKey
{
    /**
     * @var Translit
     */
    protected $translit;

    /**
     * @param Translit $translit
     */
    public function __construct(Translit $translit)
    {
        $this->translit = $translit;
    }

    /**
     * @param string $string
     *
     * @return string
     */
    public function filter($string)
    {
        return strtolower($this->translit->filter($string));
    }
}