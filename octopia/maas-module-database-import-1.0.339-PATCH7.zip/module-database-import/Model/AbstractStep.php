<?php

namespace Maas\DatabaseImport\Model;

use Maas\DatabaseImport\Model\Logger\AbstractLogger;

/**
 * Class AbstractStep
 *
 * Base class for all steps
 *
 * @package Maas\DatabaseImport\Model
 */
abstract class AbstractStep
{
    /**
     * @var array
     */
    protected $config;

    /** @var AbstractStep[] */
    protected $children;

    /** @var AbstractLogger */
    protected $logger;

    /**
     * AbstractStep constructor
     *
     * @param array $children
     * @param array $config
     */
    public function __construct(
        array $config = [],
        array $children = []
    ) {
        $this->config = $config;
        $this->children = $children;
    }

    /**
     * @param AbstractLogger $logger
     *
     * @return $this
     */
    public function setLogger(AbstractLogger $logger)
    {
        $this->logger = $logger;
        foreach ($this->children as $child) {
            $child->setLogger($logger);
        }
        return $this;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    abstract public function execute(&$rows, &$context);

    /**
     * Not used yet
     *
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function reinit()
    {
        return $this;
    }

    /**
     * @return array
     */
    public function getConfig()
    {
        return $this->config;
    }

    /**
     * @param array $config
     *
     * @return $this
     */
    public function setConfig($config)
    {
        $this->config = $config;
        return $this;
    }

    /**
     * @param array $configItems
     *
     * @return $this
     */
    public function updateConfig($configItems)
    {
        $this->config = array_merge($this->config, $configItems);
        return $this;
    }

    /**
     * Converts a comma-separated value to an array
     *
     * @param string|array $value
     * @param string $separator
     *
     * @return array
     */
    protected function getValueAsArray($value, $separator = ',')
    {
        if (!$value) {
            return [];
        }
        if (is_string($value)) {
            return explode($separator, $value);
        }
        return $value;
    }

    /**
     * Gets a config as a boolean
     *
     * @param string $value
     *
     * @return bool
     */
    protected function getValueAsBool($value)
    {
        return ($value && $value !== '0' && $value !== 'false');
    }
}

