<?php

namespace Maas\DatabaseImport\Model\Logger;

use Maas\Log\Model\Logger\Logger;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Class ReportLogger
 *
 * @package Maas\DatabaseImport\Model\Logger
 */
class ReportLogger extends AbstractReportLogger
{
    /**
     * @param int $count
     *
     * @return $this
     *
     */
    public function addSuccessCount($count = 1)
    {
        $this->report->setDeltaSuccessItemsCount($count);
        $this->save();
        return $this;
    }

    /**
     * @return $this
     */
    private function save()
    {
        $this->report = $this->reportRepository->save($this->report);
        return $this;
    }

    /**
     * @param int $count
     *
     * @return $this
     */
    public function addWarningCount($count = 1)
    {
        $this->report->setDeltaWarningItemsCount($count);
        $this->save();
        return $this;
    }

    /**
     * @param int $count
     *
     * @return $this
     */
    public function addErrorCount($count = 1)
    {
        $this->report->setDeltaErrorItemsCount($count);
        $this->save();
        return $this;
    }

    /**
     * @return $this
     */
    public function initialize()
    {
        return $this;
    }

    /**
     * @return $this|ReportLogger
     * @throws AlreadyExistsException
     */
    public function finalize()
    {
        if ($this->report->getItemsCount() == $this->getSuccessCount() + $this->getWarningCount() + $this->getErrorCount()) {
            $report = $this->report;
            $this->reportManagement->close($report);
        }
        return $this;
    }

    /**
     * @return int
     */
    public function getSuccessCount()
    {
        return $this->report->getSuccessItemsCount();
    }

    /**
     * @return int
     */
    public function getWarningCount()
    {
        return $this->report->getWarningItemsCount();
    }

    /**
     * @return int
     */
    public function getErrorCount()
    {
        return $this->report->getErrorItemsCount();
    }

    /**
     * @inheritDoc
     */
    public function log($message, $level = Logger::DEBUG)
    {
        $this->report->log($message, false, $level);
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function success($message, $level = Logger::INFO)
    {
        $this->report->log($message, false, $level);
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function error($message, $level = Logger::ERROR)
    {
        $this->report->log($message, false, $level);
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function warning($message, $level = Logger::WARNING)
    {
        $this->report->log($message, false, $level);
        return $this;
    }
}
