<?php

namespace Maas\DatabaseImport\Model\Logger;

use Maas\Log\Model\Logger\Logger;

/**
 * Class AbstractLogger
 *
 * @package Maas\DatabaseImport\Model\Logger
 */
abstract class AbstractLogger
{
    /**
     * @return $this
     */
    abstract public function initialize();

    /**
     * @return $this
     */
    abstract public function finalize();

    /**
     * @param int $count
     *
     * @return $this
     */
    abstract public function addSuccessCount($count = 1);

    /**
     * @param int $count
     *
     * @return $this
     */
    abstract public function addWarningCount($count = 1);

    /**
     * @param int $count
     *
     * @return $this
     */
    abstract public function addErrorCount($count = 1);

    /**
     * @return int
     */
    abstract public function getSuccessCount();

    /**
     * @return int
     */
    abstract public function getWarningCount();

    /**
     * @return int
     */
    abstract public function getErrorCount();

    /**
     * @param string $message
     * @param int $level *
     * @return mixed
     */
    abstract public function log($message, $level = Logger::DEBUG);

    /**
     * @param string $message
     * @param int $level *
     * @return mixed
     */
    abstract public function success($message, $level = Logger::INFO);

    /**
     * @param string $message
     * @param int $level *
     * @return mixed
     */
    abstract public function error($message, $level = Logger::ERROR);

    /**
     * @param string $message
     * @param int $level *
     * @return mixed
     */
    abstract public function warning($message, $level = Logger::WARNING);
}
