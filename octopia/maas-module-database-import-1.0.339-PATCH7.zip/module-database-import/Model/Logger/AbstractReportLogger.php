<?php

namespace Maas\DatabaseImport\Model\Logger;

use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Report;

/**
 * Class AbstractReportLogger
 *
 * @package Maas\DatabaseImport\Model\Logger
 */
abstract class AbstractReportLogger extends AbstractLogger
{
    /** @var Report */
    protected $report;

    /** @var ReportRepositoryInterface */
    protected $reportRepository;
    protected ReportManagementInterface $reportManagement;

    /**
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     */
    public function __construct(
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement
    )
    {
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
    }

    /**
     * @return Report
     */
    public function getReport()
    {
        return $this->report;
    }

    /**
     * @param ReportInterface $report
     *
     * @return $this
     */
    public function setReport(ReportInterface $report)
    {
        $this->report = $report;
        return $this;
    }
}