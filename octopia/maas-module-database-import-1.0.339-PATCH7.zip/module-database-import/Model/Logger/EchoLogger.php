<?php

namespace Maas\DatabaseImport\Model\Logger;

use Maas\Log\Model\Logger\Logger;

/**
 * Class EchoLogger
 *
 * @package Maas\DatabaseImport\Model\Logger
 */
class EchoLogger extends AbstractLogger
{
    /** @var int */
    private $success = 0;

    /** @var int */
    private $warning = 0;

    /** @var int */
    private $error = 0;

    /**
     * @return $this
     */
    public function initialize()
    {
        $this->success = 0;
        $this->warning = 0;
        $this->error = 0;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function finalize()
    {
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function addSuccessCount($count = 1)
    {
        $this->success += $count;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function addWarningCount($count = 1)
    {
        $this->warning += $count;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function addErrorCount($count = 1)
    {
        $this->error += $count;
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getSuccessCount()
    {
        return $this->success;
    }

    /**
     * @inheritDoc
     */
    public function getWarningCount()
    {
        return $this->warning;
    }

    /**
     * @inheritDoc
     */
    public function getErrorCount()
    {
        return $this->error;
    }

    /**
     * @inheritDoc
     */
    public function log($message, $level = Logger::DEBUG)
    {
        echo "[$level] $message\n";
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function success($message, $level = Logger::INFO)
    {
        echo "[$level] $message\n";
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function error($message, $level = Logger::ERROR)
    {
        echo "[$level] $message\n";
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function warning($message, $level = Logger::WARNING)
    {
        echo "[$level] $message\n";
        return $this;
    }
}
