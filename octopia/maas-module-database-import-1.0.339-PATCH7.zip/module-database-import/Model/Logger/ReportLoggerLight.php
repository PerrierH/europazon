<?php

namespace Maas\DatabaseImport\Model\Logger;

use Maas\Log\Model\Logger\Logger;
use Magento\Framework\Exception\AlreadyExistsException;

/**
 * Class ReportLoggerLight
 *
 * @package Maas\DatabaseImport\Model\Logger
 */
class ReportLoggerLight extends AbstractReportLogger
{
    /** @var int */
    protected $success;

    /** @var int */
    protected $warning;

    /** @var int */
    protected $error;

    /** @var array[] */
    protected $messages = [];

    /**
     * @param int $count
     *
     * @return $this
     */
    public function addSuccessCount($count = 1)
    {
        $this->success += $count;
        return $this;
    }

    /**
     * @param int $count
     *
     * @return $this
     */
    public function addWarningCount($count = 1)
    {
        $this->warning += $count;
        return $this;
    }

    /**
     * @param int $count
     *
     * @return $this
     */
    public function addErrorCount($count = 1)
    {
        $this->error += $count;
        return $this;
    }

    /**
     * @return $this
     */
    public function initialize()
    {
        $this->success = 0;
        $this->warning = 0;
        $this->error = 0;
        return $this;
    }

    /**
     * @return $this
     * @throws AlreadyExistsException
     */
    public function finalize()
    {
        $this->report->setDeltaWarningItemsCount($this->warning)
            ->setDeltaErrorItemsCount($this->error)
            ->setDeltaSuccessItemsCount($this->success);
        if ($this->report->getItemsCount() == $this->getSuccessCount() + $this->getWarningCount() + $this->getErrorCount()) {
            $report = $this->report;
            $this->reportManagement->close($report);
        } else {
            $this->reportRepository->save($this->report);
        }
        foreach ($this->messages as $messageArray) {
            $this->report->log($messageArray[0], false, $messageArray[1]);
        }
        return $this;
    }

    /**
     * @return int
     */
    public function getSuccessCount()
    {
        return $this->success + $this->report->getSuccessItemsCount();
    }

    /**
     * @return int
     */
    public function getWarningCount()
    {
        return $this->warning + $this->report->getWarningItemsCount();
    }

    /**
     * @return int
     */
    public function getErrorCount()
    {
        return $this->error + $this->report->getErrorItemsCount();
    }

    /**
     * @inheritDoc
     */
    public function log($message, $level = Logger::DEBUG)
    {
        $this->messages[] = func_get_args();
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function success($message, $level = Logger::INFO)
    {
        $this->messages[] = func_get_args();
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function error($message, $level = Logger::ERROR)
    {
        $this->messages[] = func_get_args();
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function warning($message, $level = Logger::WARNING)
    {
        $this->messages[] = func_get_args();
        return $this;
    }
}
