<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Connection;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\Core\Api\Data\EditionInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\Pdo\Mysql;
use PDO;
use PDOStatement;

/**
 * Class Db
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Connection
 */
class Db
{
    const SELECT_SIMPLE_QUERY_TEMPLATE = 'select `@cols@` from `@table@` @join@ @where@';
    const INSERT_SIMPLE_QUERY_TEMPLATE = 'insert ignore into `@table@`(`@cols@`) values @values@';
    const UPDATE_SIMPLE_QUERY_TEMPLATE = 'update `@table@` set @values@ @where@';
    const DELETE_SIMPLE_QUERY_TEMPLATE = 'delete from `@table@` @where@';

    const INSERTED_ROWS_SELECT_WHERE_TEMPLATE = 'where (`@keys@`) in (@combinations@)';

    static $tablesColumns = [];
    static $insertCachedQueries = [];
    static $insertMultipleCachedQueries = [];
    static $updateCachedQueries = [];
    static $deleteCachedQueries = [];

    /**
     * @var ResourceConnection
     */
    protected $connection;

    /**
     * @var PDO
     */
    protected $pdo;

    /**
     * @var Placeholder
     */
    protected $placeholderService;

    /**
     * @var EditionInterface
     */
    public $edition;

    /**
     * DB Constructor
     *
     * @param ResourceConnection $connection
     * @param Placeholder $placeholderService
     * @param EditionInterface $edition
     */
    public function __construct(
        ResourceConnection $connection,
        Placeholder        $placeholderService,
        EditionInterface $edition
    )
    {
        $this->connection = $connection;
        /** @var Mysql $mysql */
        $mysql = $this->connection->getConnection();
        $this->pdo = $mysql->getConnection();
        $this->placeholderService = $placeholderService;
        $this->edition = $edition;
    }

    /**
     * @param string $table
     *
     * @return string[]
     */
    public function getTableColumns($table)
    {
        if (!isset(self::$tablesColumns[$table])) {
            self::$tablesColumns[$table] = array_keys($this->connection->getConnection()->describeTable(
                $this->connection->getTableName($table)
            ));
        }
        return self::$tablesColumns[$table];
    }

    /**
     * @param string $table
     * @param string $primaryKey
     * @param string[] $cols
     * @param string|null $where
     * @param string|null $join
     * @param string[]|null $params
     *
     * @return array|false
     */
    public function selectAndFetchAll($table, $primaryKey, $cols, $where = null, $join = null, $params = [])
    {
        try {
            $cols = $this->formatColsWithPrefixedPrimaryKey($table, $primaryKey, $cols);
            $table = $this->getTableName($this->getTableName($table));

            // add prefix table to field for resolve ambiguity (EE)
            if ($this->edition->isEnterprise() && $table == 'catalog_category_entity_varchar') {
                $cols = $this->strReplace('`row_id`', sprintf('`%s`.`row_id`', $table), $cols);
                $join = $this->strReplace('row_id =', sprintf('%s.row_id =', $table), $join);
                $where = $this->strReplace('row_id in', sprintf('%s.row_id in', $table), $where);
            }

            $query = $this->placeholderService->replace(self::SELECT_SIMPLE_QUERY_TEMPLATE, [
                'cols' => $cols,
                'table' => $table,
                'where' => $where, 'join' => $join
            ]);

            $st = $this->execute($query, $params);
            return $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            var_dump('Error sql :', $e->getMessage());
        }
        return false;
    }

    /**
     * @param string[] $cols
     *
     * @return string
     */
    protected function formatCols($cols)
    {
        return implode('`,`', $cols);
    }

    /**
     * @param string $table
     * @param string $primaryKey
     * @param string[] $cols
     *
     * @return string
     */
    protected function formatColsWithPrefixedPrimaryKey($table, $primaryKey, $cols)
    {
        return ($primaryKey ? sprintf('%s`.`%s`, `', $table, $primaryKey) : '') . implode('`,`', $cols);
    }

    /**
     * @param string $table
     *
     * @return string
     */
    public function getTableName($table)
    {
        return $this->connection->getTableName($table);
    }

    /**
     * @param string $query
     * @param array $parameters
     *
     * @return false|PDOStatement
     */
    public function execute(string $query, $parameters = [])
    {
        return $this->executionAttempt($query, $parameters);
    }

    /**
     * @param string $query
     * @param array $parameters
     *
     * @return false|PDOStatement
     */
    public function executionAttempt(string $query, $parameters = [])
    {
        $st = $this->pdo->prepare($query);
        $result = $st->execute($parameters);

        if (!$result) {
            throw new \PDOException('Query fail : ' . $query);
        }
        return $st;
    }

    /**
     * @param string $table
     * @param string $primaryKey
     * @param string[] $cols
     * @param string[] $keys
     * @param string[][] $insertedRows
     * @param string|null $join
     *
     * @return array|false
     */
    public function selectAndFetchIdsFromInsertedRows($table, $primaryKey, $cols, $keys, &$insertedRows, $join = null)
    {
        $table = $this->getTableName($table);

        $where = $this->placeholderService->replace(self::INSERTED_ROWS_SELECT_WHERE_TEMPLATE, [
            'keys' => implode('`,`', $keys),
            'combinations' => $this->generateQuestionMarksInsertString(count($insertedRows), count($keys))
        ]);
        $whereValues = [];
        foreach ($insertedRows as $row) {
            foreach ($keys as $key) {
                $whereValues[] = $row[$key];
            }
        }
        $cols = array_merge($cols, $keys);

        $query = $this->placeholderService->replace(self::SELECT_SIMPLE_QUERY_TEMPLATE, [
            'cols' => $this->formatColsWithPrefixedPrimaryKey($table, $primaryKey, $cols),
            'table' => $this->getTableName($table),
            'where' => $where, 'join' => $join
        ]);

        $st = $this->execute($query, $whereValues);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * @param int $rowCount
     * @param int $rowSize
     *
     * @return string
     */
    protected function generateQuestionMarksInsertString($rowCount, $rowSize)
    {
        $rowQuestionMarks = '(' . implode(',', array_fill(0, $rowSize, '?')) . ')';
        return implode(',', array_fill(0, $rowCount, $rowQuestionMarks));
    }

    /**
     * @param string $table
     * @param string[][] $rows
     * @param string[]|null $onUpdateCols
     *
     * @return false|PDOStatement|null
     */
    public function insertMultiple($table, &$rows, $onUpdateCols = null)
    {
        if ((!$rows) || (!reset($rows))) {
            return null;
        }
        if (!isset(self::$insertMultipleCachedQueries[$table])) {
            self::$insertMultipleCachedQueries[$table] = [];
        }
        if (!isset(self::$insertMultipleCachedQueries[$table][count($rows)])) {
            $firstRow = reset($rows);
            self::$insertMultipleCachedQueries[$table][count($rows)] = $this->placeholderService->replace(self::INSERT_SIMPLE_QUERY_TEMPLATE,
                [
                    'cols' => $this->formatCols(array_keys($firstRow)),
                    'table' => $this->getTableName($this->getTableName($table)),
                    'values' => $this->generateQuestionMarksInsertString(count($rows), count($firstRow))
                ]);
        }
        return $this->execute(
            self::$insertMultipleCachedQueries[$table][count($rows)],
            $this->flattenRows($rows)
        );
    }

    /**
     * @param string $table
     * @param string[] $row
     *
     * @return false|PDOStatement
     */
    public function insert($table, &$row)
    {
        if (!isset(self::$insertCachedQueries[$table])) {
            self::$insertMultipleCachedQueries[$table] = $this->placeholderService->replace(self::INSERT_SIMPLE_QUERY_TEMPLATE,
                [
                    'cols' => $this->formatCols(array_keys($row)),
                    'table' => $this->getTableName($this->getTableName($table)),
                    'values' => $this->generateQuestionMarksInsertString(1, count($row))
                ]);
        }
        return $this->execute(
            self::$insertMultipleCachedQueries[$table],
            array_values($row)
        );
    }

    /**
     * @param array[]
     *
     * @return array
     */
    protected function flattenRows($rows)
    {
        $flattened = [];
        foreach ($rows as $row) {
            $flattened = array_merge($flattened, array_values($row));
        }
        return $flattened;
    }

    /**
     * @param string $table
     *
     * @return $this
     */
    public function clearUpdateQueriesCache($table)
    {
        unset(self::$updateCachedQueries[$table]);
        return $this;
    }

    /**
     * @param string $table
     * @param string[] $keys
     * @param string[] $row
     * @param string[] $fieldsToOmit
     *
     * @return false|PDOStatement
     */
    public function update($table, $keys, &$row, $fieldsToOmit)
    {
        if ($fieldsToOmit) {
            $usedRow = array_diff_key($row, array_flip($fieldsToOmit));
        } else {
            $usedRow = &$row;
        }
        if (!isset(self::$updateCachedQueries[$table])) {
            self::$updateCachedQueries[$table] = $this->placeholderService->replace(self::UPDATE_SIMPLE_QUERY_TEMPLATE, [
                'table' => $this->getTableName($this->getTableName($table)),
                'values' => $this->generateQuestionMarksUpdateString(array_keys($usedRow), ', '),
                'where' => ' where ' . $this->generateQuestionMarksUpdateString(array_keys($keys), ' AND ')
            ]);
        }
        return $this->execute(
            self::$updateCachedQueries[$table],
            array_merge(array_values($usedRow), array_values($keys))
        );
    }

    /**
     * @param string[] $columns
     * @param string $separator
     *
     * @return string
     */
    protected function generateQuestionMarksUpdateString($columns, $separator)
    {
        $result = [];
        foreach ($columns as $column) {
            $result[] = "`$column` = ?";
        }
        return implode($separator, $result);
    }

    /**
     * @return mixed
     */
    public function getLastInsertId()
    {
        return $this->execute('select last_insert_id();')->fetch(\PDO::FETCH_ASSOC)['last_insert_id()'];
    }

    /**
     * @param $table
     *
     * @return $this
     */
    public function clearDeleteQueryCache($table)
    {
        unset(self::$deleteCachedQueries[$table]);
        return $this;
    }

    /**
     * @param string $table
     * @param string[] $keys
     * @param string[][] $rows
     *
     * @return false|PDOStatement
     */
    public function delete($table, $keys, &$rows)
    {
        $rowCount = count($rows);
        if (!isset(self::$deleteCachedQueries[$table][$rowCount])) {
            $where = $this->placeholderService->replace(self::INSERTED_ROWS_SELECT_WHERE_TEMPLATE, [
                'keys' => implode('`,`', $keys),
                'combinations' => $this->generateQuestionMarksInsertString(count($rows), count($keys))
            ]);
            self::$deleteCachedQueries[$table][$rowCount] = $this->placeholderService->replace(self::DELETE_SIMPLE_QUERY_TEMPLATE, [
                'table' => $this->getTableName($this->getTableName($table)),
                'where' => $where
            ]);
        }
        return $this->execute(
            self::$deleteCachedQueries[$table][$rowCount], $this->flattenRows($rows)
        );
    }

    /**
     * @param $search
     * @param $replace
     * @param $subject
     * @return array|string|string[]
     */
    public function strReplace($search, $replace, $subject)
    {
        return str_replace($search, $replace, $subject);
    }

}
