<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Eav;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use PDO;

/**
 * Class LoadAttributes
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Eav
 */
class LoadAttributes
{
    /** @var string */
    const GET_ENTITY_TYPE_FROM_ID_QUERY_TEMPLATE = 'select * from @eet@ where entity_type_id = @et_id@';

    /** @var string */
    const GET_ENTITY_TYPE_FROM_CODE_QUERY_TEMPLATE = 'select * from @eet@ where entity_type_code = \'@etc@\'';

    /** @var string */
    const GET_ATTRIBUTES_QUERY_TEMPLATE = 'select * from @ea@ where entity_type_id = @et_id@';

    /** @var string */
    const GET_ATTRIBUTES_QUERY_TEMPLATE_WITH_JOIN = 'select * from @ea@ as ea left join @additional@ as additional on ea.attribute_id = additional.attribute_id where entity_type_id = @et_id@';

    const GET_ATTRIBUTES_IN_SET_BY_NAME_QUERY_TEMPLATE = 'select attribute_code from @ea@ as ea
join @eea@ as eea on ea.attribute_id = eea.attribute_id
join @eas@ as eas on eea.attribute_set_id = eas.attribute_set_id
where ea.entity_type_id = ? and attribute_set_name = ?';

    /**
     * @var Db
     */
    protected $db;

    /**
     * @var Placeholder
     */
    protected $placeholderService;

    /**
     *
     * LoadAttributes constructor
     *
     * @param Db $db
     * @param Placeholder $placeholderService
     */
    public function __construct(
        Db          $db,
        Placeholder $placeholderService
    )
    {
        $this->db = $db;
        $this->placeholderService = $placeholderService;
    }

    /**
     * @param string $entityType
     *
     * @return string[]|null
     */
    public function loadEntityTypeByCode($entityType)
    {
        $query = $this->placeholderService->replace(self::GET_ENTITY_TYPE_FROM_CODE_QUERY_TEMPLATE, [
            'eet' => $this->db->getTableName('eav_entity_type'),
            'etc' => $entityType
        ]);
        $rows = $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
        return $rows ? reset($rows) : null;
    }

    /**
     * @param int $entityTypeId
     *
     * @return string[]|null
     */
    public function loadEntityTypeById($entityTypeId)
    {
        $query = $this->placeholderService->replace(self::GET_ENTITY_TYPE_FROM_ID_QUERY_TEMPLATE, [
            'eet' => $this->db->getTableName('eav_entity_type'),
            'et_id' => $entityTypeId
        ]);
        $rows = $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
        return $rows ? reset($rows) : null;
    }

    /**
     * @param int $entityTypeId
     *
     * @return string[][]|null
     */
    public function loadAttributes($entityTypeId)
    {
        $entityTypeData = $this->loadEntityTypeById($entityTypeId);
        if ($entityTypeData && $entityTypeData['additional_attribute_table']) {
            $query = $this->placeholderService->replace(self::GET_ATTRIBUTES_QUERY_TEMPLATE_WITH_JOIN, [
                'ea' => $this->db->getTableName('eav_attribute'),
                'et_id' => $entityTypeId,
                'additional' => $this->db->getTableName($entityTypeData['additional_attribute_table'])
            ]);
        } else {
            $query = $this->placeholderService->replace(self::GET_ATTRIBUTES_QUERY_TEMPLATE, [
                'ea' => $this->db->getTableName('eav_attribute'),
                'et_id' => $entityTypeId
            ]);
        }
        $rows = $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
        return $rows;
    }

    /**
     * @param int $entityTypeId
     * @param string $attributeSetName
     *
     * @return array
     */
    public function getAttributeSetAttributes($entityTypeId, $attributeSetName)
    {
        $query = $this->placeholderService->replace(self::GET_ATTRIBUTES_IN_SET_BY_NAME_QUERY_TEMPLATE, [
            'ea' => $this->db->getTableName('eav_attribute'),
            'eea' => $this->db->getTableName('eav_entity_attribute'),
            'eas' => $this->db->getTableName('eav_attribute_set'),
        ]);
        $rows = $this->db->execute($query, [$entityTypeId, $attributeSetName])->fetchAll(PDO::FETCH_ASSOC);
        $codes = [];
        foreach ($rows as $row) {
            $codes[] = $row['attribute_code'];
        }
        return $codes;
    }
}