<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step;

use PDO;

/**
 * Class TableWithFetch
 *
 * Uses the parent class Table to insert data into rows, fetches back the primary key and other values if necessary
 * and stored them in rows.
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step
 */
class TableWithFetch extends Table
{
    const CONFIG_TABLE_FETCH_COLS = 'fetch_columns';

    /** @var array */
    protected $fetchCachedQueries = [];

    /** @var array */
    protected $valuesToFetchCache = [];

    /** @var array */
    protected $fetchedColumns = [];

    /** @var bool */
    protected $fetchedColumnsUseAlias = false;

    public function reinit()
    {
        $this->valuesToFetchCache = [];
        $this->fetchCachedQueries = [];

        return parent::reinit();
    }

    /**
     * @param array $rows
     *
     * @return $this
     */
    protected function executeForTable(&$rows)
    {
        $this->initFetchedCols();
        if (!isset($this->context['new_ids'])) {
            $this->context['new_ids'] = [$this->config[self::CONFIG_TABLE] => []];
        } else {
            if (!isset($this->context['new_ids'][$this->config[self::CONFIG_TABLE]])) {
                $this->context['new_ids'][$this->config[self::CONFIG_TABLE]] = [];
            }
        }
        parent::executeForTable($rows);
        $this->updateRowsWithFetchedColumns($rows);
        return $this;
    }

    /**
     * @return $this
     */
    protected function initFetchedCols()
    {
        if (empty($this->fetchedColumns)) {
            $this->fetchedColumnsUseAlias = false;
            $this->fetchedColumns = [];
            $fetchedColumnsRaw = $this->getValueAsArray($this->config[self::CONFIG_TABLE_FETCH_COLS]);
            foreach ($fetchedColumnsRaw as $columnRaw) {
                $columnRawParts = explode(':', $columnRaw);
                if (count($columnRawParts) == 2) {
                    $this->fetchedColumns[$columnRawParts[0]] = $columnRawParts[1];
                    $this->fetchedColumnsUseAlias = true;
                } else {
                    $this->fetchedColumns[$columnRaw] = $columnRaw;
                }
            }
        }
        return $this;
    }

    /**
     * @param array $rows
     *
     * @return $this
     */
    protected function updateRowsWithFetchedColumns(&$rows)
    {
        foreach ($rows as $i => &$row) {
            $key = $this->getKey($row);
            if (isset($this->valuesToFetchCache[$key])) {
                $row = array_merge($row, $this->valuesToFetchCache[$key]);
            }
        }
        return $this;
    }

    /**
     * @param string[][] $toInsert
     *
     * @return $this
     */
    protected function insertChunk(&$toInsert)
    {
        $primaryKey = $this->config[self::CONFIG_TABLE_PRIMARY_KEY];
        parent::insertChunk($toInsert);

        $keys = $this->getValueAsArray($this->config[self::CONFIG_TABLE_KEYS]);

        $result = $this->db->selectAndFetchIdsFromInsertedRows($this->config[self::CONFIG_TABLE],
            $this->config[self::CONFIG_TABLE_PRIMARY_KEY],
            array_values($this->fetchedColumns), $keys, $toInsert);
        foreach ($result as $row) {
            $cacheKey = $this->getKey($row);
            foreach ($keys as $key) {
                unset($row[$key]);
            }
            if ($this->fetchedColumnsUseAlias) {
                foreach ($this->fetchedColumns as $alias => $column) {
                    if ($alias != $column) {
                        $row[$alias] = $row[$column];
                        if ($column == $this->config[self::CONFIG_TABLE_PRIMARY_KEY]) {
                            $primaryKey = $alias;
                        }
                        unset($row[$column]);
                    }
                }
            }

            $this->valuesToFetchCache[$cacheKey] = $row;
            $this->context['new_ids'][$this->config[self::CONFIG_TABLE]][$cacheKey] = $row[$primaryKey];
        }
        return $this;
    }
}