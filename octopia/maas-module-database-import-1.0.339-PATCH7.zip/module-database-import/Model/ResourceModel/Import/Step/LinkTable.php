<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step;

/**
 * Class LinkTable
 *
 * Inserts rows into link tables - tables without a primary key
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step
 */
class LinkTable extends AbstractStepResource
{
    const CONFIG_TABLE = 'table';
    const CONFIG_KEYS = 'keys';
    const CONFIG_ADDITIONAL_COLUMNS = 'additional_columns';

    /** @var string[]|null */
    protected $primaryKeyCols = null;

    /** @var string[]|null */
    protected $additionalCols = null;

    /** @var string[]|null */
    protected $allCols = null;

    /** @var array|null */
    protected $existingValuesCache = null;

    /**
     * @inheritDoc
     */
    public function execute(&$rows, &$context)
    {
        $this->initCols();

        $toInsert = [];
        $toUpdate = [];
        $keysFlipped = array_flip($this->db->getTableColumns($this->config[self::CONFIG_TABLE]));

        $existing = $this->db->selectAndFetchAll($this->config[self::CONFIG_TABLE], null, $this->allCols);
        foreach ($existing as $row) {
            $this->existingValuesCache[$this->getPrimaryKeyFromRow($row)] = true;
        }
        foreach ($rows as $row) {
            if (isset($this->existingValuesCache[$this->getPrimaryKeyFromRow($row)])) {
                if ($this->additionalCols) {
                    $toUpdate[] = array_intersect_key($row, $keysFlipped);
                }
            } else {
                $row_to_insert = array_intersect_key($row, $keysFlipped);
                if (sizeof($row_to_insert) >= sizeof($this->primaryKeyCols)) {
                    $toInsert[] = $row_to_insert;
                }
            }
        }
        if ($toInsert) {
            $toInsert = array_chunk($toInsert, $this->config[self::CHUNK_SIZE]);
            foreach ($toInsert as $toInsertChunk) {
                $this->insertChunk($toInsertChunk);
            }
        }

        if ($toUpdate) {
            $toUpdate = array_chunk($toUpdate, $this->config[self::CHUNK_SIZE], true);
            foreach ($toUpdate as $toUpdateChunk) {
                $this->updateChunk($toUpdateChunk);
            }
        }
        return $this;
    }

    /**
     * @return $this
     */
    protected function initCols()
    {
        if (is_null($this->allCols)) {
            $this->primaryKeyCols = $this->getValueAsArray($this->config[self::CONFIG_KEYS]);
            $this->additionalCols = $this->getValueAsArray($this->config[self::CONFIG_ADDITIONAL_COLUMNS]);
            $this->allCols = array_merge($this->primaryKeyCols, $this->additionalCols);
        }
        return $this;
    }

    /**
     * @param array $row
     *
     * @return string
     */
    protected function getPrimaryKeyFromRow($row)
    {
        return $this->extractKey($row, $this->primaryKeyCols);
    }

    /**
     * @param string[][] $toInsert
     */
    protected function insertChunk(&$toInsert)
    {
        $this->db->insertMultiple($this->config[self::CONFIG_TABLE], $toInsert);
        return $this;
    }

    /**
     * @param string[][] $toUpdate
     */
    protected function updateChunk(&$toUpdate)
    {
        $table = $this->config[self::CONFIG_TABLE];
        $this->db->clearUpdateQueriesCache($table);
        foreach ($toUpdate as $row) {
            $keyValues = [];
            foreach ($this->primaryKeyCols as $primaryKeyCol) {
                $keyValues[$primaryKeyCol] = $row[$primaryKeyCol];
            }
            $this->db->update(
                $table, [
                $keyValues
            ], $row, []);
        }
        return $this;
    }

    /**
     * @inheritDoc
     */
    public function reinit()
    {
        $this->existingValuesCache = null;
        return $this;
    }
}
