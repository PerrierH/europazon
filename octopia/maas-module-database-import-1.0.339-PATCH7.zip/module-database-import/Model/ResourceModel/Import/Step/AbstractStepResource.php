<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step;

use Maas\DatabaseImport\Model\AbstractStep;
use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Magento\Framework\App\ResourceConnection;

/**
 * Class AbstractStepResource
 * Abstract class for all Steps that use the Database
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step
 */
abstract class AbstractStepResource extends AbstractStep
{
    const CHUNK_SIZE = 'chunk_size';

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var Db
     */
    protected $db;

    /**
     * @var array
     */
    protected $config;

    /**
     * @var Placeholder
     */
    protected $placeholderService;

    /**
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db $db,
        Placeholder $placeholderService,
        array $config = [],
        array $children = []
    ) {
        parent::__construct($config, $children);

        $this->resource = $resource;
        $this->db = $db;
        $this->placeholderService = $placeholderService;

        if (!isset($this->config[self::CHUNK_SIZE])) {
            $this->config[self::CHUNK_SIZE] = 50;
        }
    }

    /**
     * @param array $row
     * @param string[] $keyColumns
     *
     * @return string
     */
    protected function extractKey($row, $keyColumns)
    {
        $row = array_intersect_key($row, array_flip($keyColumns));
        ksort($row);
        foreach ($row as $key => $value) {
            if (is_numeric($value)) {
                $row[$key] = str_replace('"', '""', $value);
            }
        }
        return '"' . implode('","', $row) . '"';
    }

    /**
     * @param string $tableName
     * @param string $key
     * @param array $ids
     */
    protected function deleteRecords(string $tableName, string $key, array $ids)
    {
        if ($tableName && $key && count($ids) !== 0) {
            $this->db->delete($tableName, [$key], $ids);
        }
    }
}
