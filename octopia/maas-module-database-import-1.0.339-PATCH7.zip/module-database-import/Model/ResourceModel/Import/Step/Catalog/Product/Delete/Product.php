<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product\Delete;

use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Maas\Core\Api\Data\EditionInterface;
use Zend_Db_Expr;
use PDO;

/**
 * Class Product
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product\Delete;
 */
class Product extends AbstractStepResource
{
    /**
     * @param array $rows
     * @param array $context
     * @return Product|void
     */
    public function execute(&$rows, &$context)
    {
        //merge configurable products to deletion list
        $this->mergeConfigurablesForRemove($rows);

        foreach ($this->children as $child) {
            $child->execute($rows, $context);
        }
    }

    /**
     * @param $rows
     */
    private function mergeConfigurablesForRemove(&$rows)
    {
        if (count($rows)) {
            //get parent_entity_id array
            $parentIds = array_column($rows, 'parent_entity_id');
            //count parent_entity_id occurences
            $eligibleForDelete = array_count_values(array_filter($parentIds));
            $configurables = count($eligibleForDelete) ? $this->getConfigurableChildrenCount(array_keys($eligibleForDelete)) : [];

            $confPrd = [];
            $linkField = $this->db->edition->getLinkField();
            foreach ($configurables as $configurable) {
                $confPrd[$configurable[$linkField]] = $configurable['childrenCount'];
            }

            foreach ($eligibleForDelete as $key => $value) {
                if ($confPrd[$key] == $value) {
                    $rows[] = [$linkField => $key];
                }
            }
        }
    }

    /**
     * @param $ids
     * @return array|false
     */
    private function getConfigurableChildrenCount($ids)
    {
        $linkField = $this->db->edition->getLinkField();
        $cpeTableName = $this->db->getTableName('catalog_product_entity');
        $cpslTableName = $this->db->getTableName('catalog_product_super_link');
        $query = sprintf("SELECT pt.%s, COUNT(sl.product_id) AS childrenCount
                  FROM %s pt
                  LEFT JOIN %s sl ON sl.parent_id = %s
                  WHERE pt.%s in (" . implode(',', $ids) . ") GROUP BY pt.%s",
            $linkField,
            $cpeTableName,
            $cpslTableName,
            $linkField,
            $linkField,
            $linkField
        );

        return $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
    }
}
