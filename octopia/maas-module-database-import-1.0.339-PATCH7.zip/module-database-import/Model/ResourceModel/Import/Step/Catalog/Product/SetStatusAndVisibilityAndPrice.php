<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;

/**
 * Class SetStatusAndVisibilityAndPrice
 *
 * Initiate Status, Price and Visibility for new Products. Skip this step in update
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product
 */
class SetStatusAndVisibilityAndPrice extends AbstractStepResource
{

    /**
     * @var array
     */
    protected static $productsCachedValue = null;

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $this->loadExistingProducts();
        foreach ($rows as &$row) {
            if ($this->isProductExists($row['sku'])) {
                continue;
            }
            $row['price'] = 0;
            $row['status'] = 2;
            $row['visibility'] = 1;
        }

        return $this;
    }

    protected function loadExistingProducts()
    {
        $products = $this->db->selectAndFetchAll($this->db->getTableName('catalog_product_entity'), $this->db->edition->getLinkField(), ['sku']);
        self::$productsCachedValue = array_values($products);
    }

    /**
     * @param string $sku
     *
     * @return bool
     */
    protected function isProductExists($sku)
    {
        return in_array($sku, self::$productsCachedValue);
    }

    /**
     * @return $this
     */
    public function reinit()
    {
        self::$websitesCachedValue = null;
        return $this;
    }
}
