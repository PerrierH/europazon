<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\Catalog\Model\Service\AttributeCode;
use Maas\DatabaseImport\Model\Import\Registry\Eav;
use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Magento\Framework\App\ResourceConnection;

/**
 * Class ExtractAttributes
 *
 * Extracts attribute values from attribute group objects passed in the row.
 * The values are stored either in separate column or in "additional_values"
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product
 */
class ExtractAttributes extends AbstractStepResource
{
    /**
     * @var AttributeCode
     */
    protected $attributeCodeService;

    /**
     * @var Eav
     */
    protected $eavRegistry;

    /**
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param AttributeCode $attributeCodeService
     * @param Eav $eavRegistry
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db $db,
        Placeholder $placeholderService,
        AttributeCode $attributeCodeService,
        Eav $eavRegistry,
        array $config = [],
        array $children = []
    ) {
        parent::__construct($resource, $db, $placeholderService, $config, $children);
        $this->attributeCodeService = $attributeCodeService;
        $this->eavRegistry = $eavRegistry;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        foreach ($rows as &$row) {
            $this->extractAttributeValues($row, $context);
        }
        return $this;
    }

    /**
     * @return $this
     */
    public function reinit()
    {
        return $this;
    }

    /**
     * @param array $row
     * @param array $context
     *
     * @return $this
     */
    protected function extractAttributeValues(&$row, &$context)
    {
        $attributeValues = [];
        $additionalInformationValues = [];

        foreach ($row['attribute_group_objects'] as $attributeGroup) {
            $attributes = $attributeGroup->getAttributes();
            if (!$attributes) {
                continue;
            }
            foreach ($attributes as $attribute) {
                $code = $this->attributeCodeService->generate($attribute->getLabel());
                if (isset($row['_attribute_set']) && $this->eavRegistry->isAttributeInSet($context['entity_type_id'], $code, $row['_attribute_set'])) {
                    $attributeValues[$code] = $attribute->getValue();
                } else {
                    $additionalInformationValues[$attribute->getLabel()] = implode(',', $attribute->getValue());
                }
            }
        }

        if ($additionalInformationValues) {
            $attributeValues['maas_additional_information'] = json_encode($additionalInformationValues);
        }
        $row = array_merge($row, $attributeValues);
        unset($row['attribute_group_objects']);

        return $this;
    }

}
