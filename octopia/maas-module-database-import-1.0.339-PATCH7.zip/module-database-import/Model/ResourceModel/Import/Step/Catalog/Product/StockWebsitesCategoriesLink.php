<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;


use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;

/**
 * Class StockWebsitesCategoriesLink
 *
 * Initiate Stock item to 0 for every new Product. Skip this step in update
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product
 */
class StockWebsitesCategoriesLink extends AbstractStepResource
{
    /**
     * @var array
     */
    protected static $websitesCachedValue = null;

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $stockItems = [];
        $productWebsites = [];
        $productCategories = [];

        $this->initProductWebsiteIds();

        foreach ($rows as &$row) {
            /** Array to link product to stock item */
            if (array_key_exists('stockItems', $row)) {
                $row['stockItems']['product_id'] = $row['entity_id'];
                $stockItems[] = $row['stockItems'];
            }
            /** Array to link product to categories */
            $productCategories[] = [
                'product_id' => $row['entity_id'],
                'category_id' => $row['category']
            ];

            /** Array to link product to websites */
            foreach (self::$websitesCachedValue as $website) {
                $productWebsites[] = [
                    'product_id' => $row['entity_id'],
                    'website_id' => $website['website_id']
                ];
            }
        }

        $this->children['03.4.01.cataloginventory_stock_item']->execute($stockItems, $context);
        $this->children['03.4.02.add_product_websites']->execute($productWebsites, $context);
        $this->children['03.4.03.link_products_to_categories']->execute($productCategories, $context);

        return $this;
    }

    /**
     * @return $this
     */
    public function initProductWebsiteIds()
    {
        if (is_null(self::$websitesCachedValue)) {
            self::$websitesCachedValue = $this->db->selectAndFetchAll($this->db->getTableName('store_website'), 'website_id', ['website_id'], 'where website_id > 0');
        }
        return $this;
    }

    public function reinit()
    {
        foreach ($this->children as $child) {
            $child->reinit();
        }
        return $this;
    }
}
