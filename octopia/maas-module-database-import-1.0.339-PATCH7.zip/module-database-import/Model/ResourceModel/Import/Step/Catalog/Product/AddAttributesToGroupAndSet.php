<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\Catalog\Model\Product;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\Table;

/**
 * Class AddAttributesToGroupAndSet
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Step\Catalog\Product
 */
class AddAttributesToGroupAndSet extends Table
{
    const SETS_AND_GROUPS_QUERY = 'select eag.attribute_group_id, eas.attribute_set_id, max(eea.sort_order) from @eag@ as eag
                                   join @eas@ as eas on eas.attribute_set_id = eag.attribute_set_id
                                   left join @eea@ as eea on eea.attribute_group_id = eag.attribute_group_id
                                   where eas.attribute_set_name like \'Maas %\'
                                   and attribute_group_code = \'octopia\'
                                   group by eag.attribute_group_id, eas.attribute_set_id';

    /**
     * @var null
     */
    protected $entityTypeId = null;

    /**
     * @var null
     */
    protected $cachedIds = null;

    /**
     * @param array $rows
     * @param array $context
     * @return AddAttributesToGroupAndSet|void
     */
    public function execute(&$rows, &$context)
    {
        $this->context = $context;
        $newAttributeIds = $context['new_ids']['eav_attribute'] ?? [];
        $toInsert = [];
        if ($newAttributeIds) {
            $cachedIds = $this->getSetsAndGroupsIds();
            foreach ($cachedIds as $setId => $setData) {
                $order = $setData['sort_order'];
                foreach ($newAttributeIds as $newAttributeId) {
                    $order++;
                    $toInsert[] = [
                        'entity_type_id' => $context['entity_type_id'],
                        'attribute_set_id' => $setId,
                        'attribute_group_id' => $setData['group'],
                        'attribute_id' => $newAttributeId,
                        'sort_order' => $order
                    ];
                }
            }
        }

        $this->config = array_merge($this->config, [
            self::CONFIG_TABLE => 'eav_entity_attribute',
            self::CONFIG_TABLE_KEYS => 'attribute_id',
            self::CONFIG_TABLE_PRIMARY_KEY => 'entity_attribute_id',
            self::CONFIG_TABLE_NOT_UPDATED_COLS => ''
        ]);
        $this->executeForTable($toInsert);
        $context = $this->context;
    }

    protected function getSetsAndGroupsIds()
    {
        if (is_null($this->cachedIds)) {
            $query = $this->placeholderService->replace(self::SETS_AND_GROUPS_QUERY, [
                'eag' => $this->db->getTableName('eav_attribute_group'),
                'eas' => $this->db->getTableName('eav_attribute_set'),
                'eea' => $this->db->getTableName('eav_entity_attribute'),
            ]);
            $st = $this->db->execute($query);
            $this->cachedIds = [];
            foreach ($st->fetchAll() as $row) {
                $this->cachedIds[$row['attribute_set_id']] = [
                    'group' => $row['attribute_group_id'],
                    'sort_order' => $row['sort_order'] ?? -1
                ];
            }
        }
        return $this->cachedIds;
    }
}
