<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Magento\Framework\App\ResourceConnection;
use Maas\ImportExport\Model\Service\ProductImage;
use Magento\CatalogImportExport\Model\Import\Product\MediaGalleryProcessor;
use Magento\CatalogImportExport\Model\Import\Product as StandardProductImport;
use Magento\Framework\App\ProductMetadataInterface;
use Maas\ImportExport\Model\Config;

class ProcessImages extends AbstractStepResource
{
    /**
     * @var MediaGalleryProcessor
     */
    private $mediaGalleryProcessor;

    /**
     * @var ProductImage
     */
    private $productImageService;

    /**
     * @var ProductMetadataInterface
     */
    private $productMetadata;

    /**
     * @var Config
     */
    private $importExportConfig;

    /**
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param MediaGalleryProcessor $mediaGalleryProcessor
     * @param ProductImage $productImageService
     * @param ProductMetadataInterface $productMetadata
     * @param Config $importExportConfig
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection       $resource,
        Db                       $db,
        Placeholder              $placeholderService,
        MediaGalleryProcessor    $mediaGalleryProcessor,
        ProductImage             $productImageService,
        ProductMetadataInterface $productMetadata,
        Config                   $importExportConfig,
        array                    $config = [],
        array                    $children = []
    )
    {
        $this->mediaGalleryProcessor = $mediaGalleryProcessor;
        $this->productImageService = $productImageService;
        $this->productMetadata = $productMetadata;
        $this->importExportConfig = $importExportConfig;
        parent::__construct($resource, $db, $placeholderService, $config, $children);
    }


    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this|MapCategoryData
     */
    public function execute(&$rows, &$context)
    {
        if ($this->importExportConfig->isProductsImportingImagesDisabled()) {
            array_map(function (&$row) {
                unset($row['images']);
                return $row;
            }, $rows);
            return $this;
        }

        $existingImages = $this->getExistingImages($rows);
        foreach ($rows as &$row) {
            $this->processImages($row, $existingImages);
        }
        return $this;
    }

    /**
     * @param $rows
     * @return array
     */
    protected function getExistingImages($rows)
    {
        $bunchesWithSkus = [];
        foreach ($rows as $row) {
            $bunchesWithSkus[] = [StandardProductImport::COL_SKU => $row['sku']];
        }

        $existingImages = $this->mediaGalleryProcessor->getExistingImages($bunchesWithSkus);
        $versionParts = explode('.', $this->productMetadata->getVersion());
        if ($versionParts[0] == 2 && $versionParts[1] >= 4) {
            $combined = [];
            foreach ($existingImages as $existingImagesPerStore) {
                $combined = array_merge_recursive($combined, $existingImagesPerStore);
            }
            $existingImages = $combined;
        }
        foreach ($existingImages as $sku => $images) {
            $images = array_keys($images);
            array_walk($images, function (&$val) {
                $val = basename($val);
            });
            $existingImages[$sku] = $images;
        }
        return $existingImages;
    }


    /**
     * @param $row
     * @param $existingImages
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function processImages(&$row, $existingImages)
    {
        $dataImages = $row['images'];
        $additionalImages = [];
        $additionalImageLabels = [];
        foreach ($dataImages as $key => $dataImage) {
            $targetName = $this->productImageService->getTargetFileName($dataImage->getUrl());
            if (in_array($targetName, $existingImages)) {
                continue;
            }
            $imageName = $this->productImageService->uploadToImport($dataImage->getUrl(), $targetName);
            if ($imageName !== false) {
                if ($key == 0) {
                    $row['image'] = $imageName;
                    $row['image_label'] = $dataImage->getTitle();
                    $row['small_image'] = $imageName;
                    $row['small_image_label'] = $dataImage->getTitle();
                    $row['thumbnail'] = $imageName;
                    $row['thumbnail_label'] = $dataImage->getTitle();
                } else {
                    $additionalImages[] = $imageName;
                    $additionalImageLabels[] = $dataImage->getTitle();
                }
            }
        }
        if (!empty($additionalImages)) {
            $row['_media_image'] = implode(',', $additionalImages);
            $row['_media_image_label'] = implode(',', $additionalImageLabels);
        }

        unset($row['images']);
        return $this;
    }
}
