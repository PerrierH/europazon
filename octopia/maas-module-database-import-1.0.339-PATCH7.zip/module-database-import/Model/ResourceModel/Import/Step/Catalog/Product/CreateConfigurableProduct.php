<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Maas\DatabaseImport\Model\Import\Registry\Eav as EavRegistry;
use Magento\Catalog\Model\Product\Visibility;
use Magento\Framework\App\ResourceConnection;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Maas\ImportExport\Model\ResourceModel\Product as ProductResource;
use PDO;
use Monolog\Logger;

/**
 * Class CreateConfigurableProduct
 */
class CreateConfigurableProduct extends AbstractStepResource
{
    /**
     * @var null
     */
    protected static $configurableCachedValue = null;
    /**
     * @var EavRegistry
     */
    private $eavRegistry;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var SearchCriteriaBuilder
     */
    private $criteriaBuilder;

    /**
     * @var ProductResource
     */
    private $productResource;

    /**
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param ProductRepositoryInterface $productRepository
     * @param SearchCriteriaBuilder $criteriaBuilder
     * @param EavRegistry $eavRegistry
     * @param ProductResource $productResource
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection         $resource,
        Db                         $db,
        Placeholder                $placeholderService,
        ProductRepositoryInterface $productRepository,
        SearchCriteriaBuilder      $criteriaBuilder,
        EavRegistry                $eavRegistry,
        ProductResource            $productResource,
        array                      $config = [],
        array                      $children = []
    )
    {
        $this->eavRegistry = $eavRegistry;
        $this->productRepository = $productRepository;
        $this->criteriaBuilder = $criteriaBuilder;
        $this->productResource = $productResource;
        parent::__construct($resource, $db, $placeholderService, $config, $children);
    }

    /**
     * @param array $rows
     * @param array $context
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $configurableProducts = [];
        $ChildProductsLinks = [];
        $superLinks = [];
        $confProductsSuperAttrs = [];

        $this->initConfigurableProductsIds();

        $confRows = $this->getChildrenData($context['orphans']);

        $bulk = array_merge($rows, $confRows);
        $linkField = $this->db->edition->getLinkField();
        foreach ($bulk as $row) {
            if (!empty($row['maas_variation_group_id'])) {
                $sku = $row['sku'] . '_group';
                $ChildProductsLinks[$row['maas_variation_group_id']][] = ['child_id' => $row[$linkField]];
                if (!array_key_exists($row['maas_variation_group_id'], self::$configurableCachedValue)) {
                    $configurableProducts[] = $this->prepareConfigurableArray($sku, $row);
                    self::$configurableCachedValue[$row['maas_variation_group_id']] = null;
                }
            }
        }

        $this->children['03.8.01.catalog_product_entity']->execute($configurableProducts, $context);

        foreach ($configurableProducts as $configurableProduct) {

            self::$configurableCachedValue[$configurableProduct['maas_variation_group_id']] =
                $configurableProduct[$linkField];

            // prepare data super attributes
            $confProductsSuperAttrs = array_merge($confProductsSuperAttrs,
                $this->prepareSuperAttributesLink($configurableProduct));

            $this->logger->log(sprintf("Create/Update Configurable Product with Sku :%s",
                $configurableProduct['sku']), Logger::INFO);
        }

        // prepare data configurableProductsJoin
        foreach ($ChildProductsLinks as $key => $links) {
            if (array_key_exists($key, self::$configurableCachedValue)) {
                foreach ($links as $link) {
                    $child['parent_id'] = self::$configurableCachedValue[$key];
                    $child['product_id'] = $child['child_id'] = $link['child_id'];
                    $superLinks[] = $child;
                }
            }
        }

        $this->children['03.8.05.catalog_product_relation']->execute($superLinks, $context);
        $this->children['03.8.06.catalog_product_super_link']->execute($superLinks, $context);

        $this->children['03.8.07.catalog_product_super_attribute']->execute($confProductsSuperAttrs, $context);
        $this->children['03.8.08.catalog_product_super_attribute_label']->execute($confProductsSuperAttrs, $context);

        $rows = array_merge($rows, $configurableProducts);

        return $this;
    }

    /**
     * @return $this
     */
    private function initConfigurableProductsIds()
    {
        if (is_null(self::$configurableCachedValue)) {
            $cpe_table = $this->db->getTableName('catalog_product_entity');
            $eava_table = $this->db->getTableName('eav_attribute');
            $cpet_table = $this->db->getTableName('catalog_product_entity_text');
            $linkField = $this->db->edition->getLinkField();

            $query = sprintf('SELECT cpet.value, cpe.entity_id FROM %s AS cpe
                            INNER JOIN %s eava ON eava.attribute_code = "maas_variation_group_id"
                            INNER JOIN %s cpet ON cpet.' . $linkField . ' = cpe.' . $linkField . ' AND eava.attribute_id = cpet.attribute_id
                            WHERE cpe.type_id = "configurable"', $cpe_table, $eava_table, $cpet_table);

            self::$configurableCachedValue = $this->db->execute($query)->fetchAll(PDO::FETCH_KEY_PAIR);
        }
        return $this;
    }

    /**
     * @param $id
     * @return array|\Magento\Catalog\Api\Data\ProductInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function getChildrenData($orphans)
    {
        $rows = [];
        $orphanIds = array_keys($orphans);

        if ($orphanIds) {
            $criteria = $this->criteriaBuilder
                ->addFilter('entity_id', $orphanIds, 'in')
                ->addFilter('status', [Status::STATUS_DISABLED, Status::STATUS_ENABLED], 'in')
                ->create();

            $items = $this->productRepository->getList($criteria)->getItems();

            foreach ($items as $item) {

                $data = $item->getData();

                $row = [
                    'entity_id' => $data['entity_id'],
                    'sku' => $data['sku'],
                    'status' => Status::STATUS_DISABLED,
                    'visibility' => Visibility::VISIBILITY_NOT_VISIBLE,
                    'attribute_set_id' => $data['attribute_set_id'],
                    'maas_variation_group_id' => $data['maas_variation_group_id'],
                    'maas_variation_attributes' => $data['maas_variation_attributes'],
                    'name' => $data['name'],
                    'description' => $data['description'],
                    'short_description' => $data['short_description'],
                    'weight' => $data['weight'],
                    'category_id' => $data['category_ids'][0],
                    'maas_brand' => $data['maas_brand'],
                    'maas_brand_code' => $data['maas_brand_code'],
                    'maas_sync_date' => $data['maas_sync_date'],
                    'maas_updated_at' => $data['maas_updated_at'],
                    'maas_level3_category' => null,
                    'url_key' => $data['url_key'],
                    'category' => $data['category_ids'][0]
                ];

                if ($this->db->edition->isEnterprise()) {
                    $row['row_id'] = $data['row_id'];
                }

                $rows[] = $row;
            }
        }
        return $rows;
    }

    /**
     * @param string $sku
     * @param array $row
     * @return array
     */
    private function prepareConfigurableArray(string $sku, array $row)
    {
        $configurableData = [
            'sku' => $sku,
            'status' => $row['status'] ?? null,
            'visibility' => $row['visibility'] ?? null,
            'attribute_set_id' => $row['attribute_set_id'] ?? 0,
            'type_id' => 'configurable',
            'has_options' => true,
            'required_options' => true,
            'url_key' => $row['url_key'] . '-group',
            'maas_is_maas_product' => 1,
            'category_id' => $row['category']

        ];
        $commonAttributes = [
            'maas_variation_group_id', 'maas_variation_attributes', 'name', 'description', 'short_description',
            'weight', 'maas_brand', 'maas_brand_code', 'maas_sync_date', 'maas_updated_at',
            'maas_level3_category', 'category', 'category_path',
            'image', 'image_label', 'small_image', 'small_image_label', 'thumbnail', 'thumbnail_label'
        ];

        foreach ($commonAttributes as $attribute) {
            $configurableData[$attribute] = $row[$attribute];
        }

        // create sequence product (EE)
        if ($this->db->edition->isEnterprise()) {
            $configurableData['entity_id'] = $this->productResource->createSequenceProduct();
        }

        return $configurableData;
    }

    /**
     * @param array $product
     * @return array
     */
    private function prepareSuperAttributesLink(array $product)
    {
        $variationsAttributes = $product['maas_variation_attributes'] ? json_decode($product['maas_variation_attributes'] ?? '', true) : [];
        $variations = $this->eavRegistry->getVariationsAttributes();
        $confProductsSuperAttrs = [];
        foreach ($variationsAttributes as $code => $variationsAttribute) {
            if (array_key_exists($code, $variations)) {
                $confProductsSuperAttrs[] =
                    [
                        'product_id' => $product[$this->db->edition->getLinkField()],
                        'attribute_id' => $variations[$code]['attribute_id'],
                        'position' => 0,
                        'value' => $variationsAttribute['label']
                    ];
            }
        }
        return $confProductsSuperAttrs;
    }

    /**
     * @return $this|CreateConfigurableProduct
     */
    public function reinit()
    {
        foreach ($this->children as $child) {
            $child->reinit();
        }
        return $this;
    }
}
