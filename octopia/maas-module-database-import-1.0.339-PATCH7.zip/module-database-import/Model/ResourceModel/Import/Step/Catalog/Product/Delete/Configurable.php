<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product\Delete;

use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use PDO;

/**
 * Class Configurable
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product\Delete;
 */
class Configurable extends AbstractStepResource
{
    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */


    public function execute(&$rows, &$context)
    {
        $configurables = $this->getConfigurables();
        if (count($configurables)) {
            $toDelete = [];
            $linkField = $this->db->edition->getLinkField();
            foreach ($configurables as $configurable) {
                $toDelete[] = [$linkField => $configurable[$linkField]];
            }
            $this->deleteRecords('catalog_product_entity',$linkField, $toDelete);
        }
        return $this;
    }

    /**
     * @return array
     */
    private function getConfigurables()
    {
        $linkField = $this->db->edition->getLinkField();
        $cpeTableName = $this->db->getTableName('catalog_product_entity');
        $cpslTableName = $this->db->getTableName('catalog_product_super_link');
        $query = sprintf("SELECT distinct(pt.%s), COUNT(sl.parent_id) AS childCount
                  FROM %s pt
                  LEFT JOIN %s sl ON sl.parent_id = %s
                  WHERE pt.type_id=\'configurable\'
                  GROUP BY pt.%s
                  HAVING childCount = 0",
            $linkField,
            $cpeTableName,
            $cpslTableName,
            $linkField,
            $linkField
        );

        return $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function reinit()
    {
        return $this;
    }
}
