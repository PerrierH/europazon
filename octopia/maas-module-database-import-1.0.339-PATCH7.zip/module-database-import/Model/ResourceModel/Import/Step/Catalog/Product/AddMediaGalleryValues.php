<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Maas\ImportExport\Model\Config;
use Magento\Framework\App\ResourceConnection;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class AddMediaGalleryValues
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Step\Catalog\Product
 */
class AddMediaGalleryValues extends AbstractStepResource
{
    const IMAGE_ATTRIBUTES = 'image_attributes';
    const MEDIA_ATTRIBUTE = 'media_attribute';
    const ATTRIBUTE_SELECT_WHERE_TEMPLATE = 'where attribute_code = \'@code@\' and entity_type_id = @etid@';

    /**
     * @var null|int
     */
    protected static $mediaGalleryAttribute = null;

    /**
     * @var string[]
     */
    protected $imageAttributes = null;

    /**
     * @var Config
     */
    private $importExportConfig;

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param Config $importExportConfig
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db                 $db,
        Placeholder        $placeholderService,
        Config             $importExportConfig,
        EditionInterface   $edition,
        array $config = [],
        array $children = []
    ) {
        $this->importExportConfig = $importExportConfig;
        $this->edition = $edition;
        parent::__construct($resource, $db, $placeholderService, $config, $children);
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        if ($this->importExportConfig->isProductsImportingImagesDisabled()) {
            return $this;
        }

        $this->initMediaGalleryAttributes($context);
        $mediaGalleryRows = [];
        foreach ($rows as &$row) {
            foreach ($this->imageAttributes as $attributeCode) {
                $this->extractMediaFromImageAttribute($attributeCode, $row, $mediaGalleryRows);
            }
            $this->extractMediaFromGalleryAttribute($row, $mediaGalleryRows);
        }
        $mediaGalleryRows = $this->flattenMediaGalleryArray($mediaGalleryRows);

        foreach ($this->children as $child) {
            $child->execute($mediaGalleryRows, $context);
        }

        return $this;
    }

    /**
     * @param array $context
     *
     * @return $this
     */
    protected function initMediaGalleryAttributes(&$context)
    {
        if (is_null(self::$mediaGalleryAttribute)) {
            $where = $this->placeholderService->replace(
                self::ATTRIBUTE_SELECT_WHERE_TEMPLATE, [
                    'code' => $this->config[self::MEDIA_ATTRIBUTE],
                    'etid' => $context['entity_type_id']
                ]
            );
            $attributeResults = $this->db->selectAndFetchAll('eav_attribute', 'attribute_id', ['attribute_code'],
                $where);
            self::$mediaGalleryAttribute = reset($attributeResults)['attribute_id'];
        }
        if (is_null($this->imageAttributes)) {
            $this->imageAttributes = $this->getValueAsArray($this->config[self::IMAGE_ATTRIBUTES]);
        }
        return $this;
    }

    /**
     * @param string $attributeCode
     * @param string[] $row
     * @param string[][] $mediaGalleryRows
     *
     * @return $this
     */
    protected function extractMediaFromImageAttribute($attributeCode, $row, &$mediaGalleryRows)
    {
        if (isset($row[$attributeCode])) {
            $this->addMediaGalleryRow($mediaGalleryRows,
                $row[$this->edition->getLinkField()], $row[$attributeCode], $row[$attributeCode . '_label'] ?? $row['name']
            );
        }
        return $this;
    }

    /**
     * @param int $entityId
     * @param string $value
     * @param string $label
     *
     * @return $this
     */
    protected function addMediaGalleryRow(&$mediaGalleryRows, $entityId, $value, $label)
    {
        $mediaGalleryRows[$entityId][$value] = [
            'attribute_id' => self::$mediaGalleryAttribute,
            'value' => $value,
            'media_type' => 'image',
            'disabled' => 0,
            'store_id' => 0,
            $this->edition->getLinkField() => $entityId,
            'label' => $label,
            'position' => 0
        ];
        return $this;
    }

    /**
     * @param string[] $row
     * @param string[][] $mediaGalleryRows
     *
     * @return $this
     */
    protected function extractMediaFromGalleryAttribute($row, &$mediaGalleryRows)
    {
        if (isset($row['_media_image']) && isset($row['_media_image_label'])) {
            $images = explode(',', $row['_media_image']);
            $imageLabels = explode(',', $row['_media_image_label']);
            foreach ($images as $i => $image) {
                $this->addMediaGalleryRow($mediaGalleryRows,
                    $row[$this->edition->getLinkField()], $image, $imageLabels[$i] ?? $row['name']
                );
            }
        }
        return $this;
    }

    /**
     * @param string[][] $mediaGalleryRows
     *
     * @return string[]
     */
    protected function flattenMediaGalleryArray($mediaGalleryRows)
    {
        $flattened = [];
        foreach ($mediaGalleryRows as $mediaForProduct) {
            foreach ($mediaForProduct as $mediaRow) {
                $flattened[] = $mediaRow;
            }
        }
        return $flattened;
    }

    /**
     * @return $this
     */
    public function reinit()
    {
        self::$mediaGalleryAttribute = null;
        foreach ($this->children as $child) {
            $child->reinit();
        }
        return $this;
    }
}
