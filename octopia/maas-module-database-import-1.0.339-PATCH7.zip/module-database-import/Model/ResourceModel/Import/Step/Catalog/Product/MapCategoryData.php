<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product;

use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;

/**
 * Class MapCategoryData
 *
 * Based on maas_category stored on rows, replaces it with category path and attribute set name
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource
 */
class MapCategoryData extends AbstractStepResource
{
    protected const SELECT_CATEGORY_IDS_WHERE_TEMPLATE = 'where store_id = 0 and attribute_id = ? and value in (@values@)';
    protected const SELECT_CATEGORY_PATHS_WHERE_TEMPLATE = 'where entity_id in (@values@)';
    protected const SELECT_CATEGORY_NAMES_WHERE_TEMPLATE = 'where store_id = 0 and attribute_id = ? and %link_field% in (@values@)';
    protected const VALIDATE_SET_NAME_JOIN_TEMPLATE = 'join @eet@ on @eas@.entity_type_id = @eet@.entity_type_id';
    protected const CATEGORY_ENTITY_JOIN_TEMPLATE = 'join @cce@  on  %link_field% = @cce@.%link_field%';

    /**
     * @var array[]
     */
    protected static $cachedData = [];

    /**
     * @var int[]
     */
    protected static $cachedCategoryEntityIdByMaasId = [];

    /**
     * @var string[]
     */
    protected static $cachedCategoryNamesByEntityId = [];

    /**
     * @var string[]
     */
    protected static $cachedCategoryUrlPathsByEntityId = [];

    /**
     * @var string
     */
    protected static $maasAttributeIdName = null;

    /**
     * @var int
     */
    protected static $maasAttributeIdCategoryId = null;

    /**
     * @var int
     */
    protected static $maasAttributeIdUrlPath = null;

    /**
     * @var null
     */
    protected static $cachedCategoryMapping = null;

    /**
     * @param $rows
     * @param $context
     *
     * @return $this|MapCategoryData
     */
    public function execute(&$rows, &$context)
    {
        $codesToLoad = [];
        foreach ($rows as $row) {
            $codesToLoad[] = $row['maas_category'];
        }
        $codesToLoad = array_unique($codesToLoad);

        $this->preloadCategoryData($codesToLoad);

        foreach ($rows as &$row) {
            $this->replaceCategoryDataInRow($row);
        }
        return $this;
    }

    /**
     * @param string[] $categoryMaasIds
     *
     * @return $this
     */
    protected function preloadCategoryData($categoryMaasIds)
    {
        //Check if all categories are already loaded
        $categoryMaasIds = array_diff($categoryMaasIds, array_keys(self::$cachedData));
        if (!$categoryMaasIds) {
            return $this;
        }
        $this->preloadAttributes();
        $categoryMappings = $this->loadCategoryIdMappings($categoryMaasIds);
        $this->loadCategoryUrlPath($categoryMappings);

        foreach ($categoryMaasIds as $categoryMaasId) {
            if (!array_key_exists('maas_' . $categoryMaasId, self::$cachedCategoryEntityIdByMaasId)) {
                self::$cachedData[$categoryMaasId] = [
                    'category' => '',
                    'category_path' => ''
                ];
                continue;
            }
            $categoryEntityId = self::$cachedCategoryEntityIdByMaasId['maas_' . $categoryMaasId];

            if ($this->db->edition->isEnterprise()) {
                $categoryEntityId = self::$cachedCategoryMapping[$categoryEntityId];
            }
            self::$cachedData[$categoryMaasId] = [
                'category' => $categoryEntityId,
                'category_path' => self::$cachedCategoryUrlPathsByEntityId[$categoryEntityId]
            ];
        }
        return $this;
    }

    /**
     * @return $this
     */
    protected function preloadAttributes()
    {
        if (is_null(self::$maasAttributeIdName) || is_null(self::$maasAttributeIdCategoryId) || is_null(self::$maasAttributeIdUrlPath)) {
            $join = $this->placeholderService->replace('join @eet@ on @ea@.entity_type_id = @eet@.entity_type_id', [
                'ea' => $this->db->getTableName('eav_attribute'),
                'eet' => $this->db->getTableName('eav_entity_type'),
            ]);

            // querying entity type
            $attributesResult = $this->db->selectAndFetchAll('eav_attribute', 'attribute_id', ['attribute_code'],
                'where entity_type_code = \'catalog_category\' and attribute_code in (\'name\', \'maas_category_id\', \'url_path\')',
                $join);

            foreach ($attributesResult as $resultRow) {
                switch ($resultRow['attribute_code']) {
                    case 'name':
                        self::$maasAttributeIdName = $resultRow['attribute_id'];
                        break;
                    case 'maas_category_id':
                        self::$maasAttributeIdCategoryId = $resultRow['attribute_id'];
                        break;
                    case 'url_path':
                        self::$maasAttributeIdUrlPath = $resultRow['attribute_id'];
                        break;
                }
            }
        }
        return $this;
    }

    /**
     * @param int[] $categoryIds
     *
     * @return array
     */
    protected function loadCategoryIdMappings($categoryIds)
    {
        $params = $categoryIds;
        array_unshift($params, self::$maasAttributeIdCategoryId);

        $template = $this->db->strReplace('%link_field%', $this->db->edition->getLinkField(), self::CATEGORY_ENTITY_JOIN_TEMPLATE);
        if ($this->db->edition->isEnterprise()) {
            $join = $this->placeholderService->replace($template, [
                'cce' => $this->db->getTableName('catalog_category_entity'),
            ]);
            $cols = ['entity_id', $this->db->edition->getLinkField(), 'value'];
        } else {
            $cols = ['entity_id', 'value'];
            $join = null;
        }

        // select category IDs
        sort($categoryIds);
        $categoryIdsResults = $this->db->selectAndFetchAll('catalog_category_entity_varchar', 'value_id',
            $cols,
            $this->placeholderService->replace(self::SELECT_CATEGORY_IDS_WHERE_TEMPLATE, [
                'values' => implode(',', array_fill(0, count($categoryIds), '?'))
            ]), $join, $params);
        $categoryIds = [];
        foreach ($categoryIdsResults as $categoryIdsResult) {
            $categoryIds['maas_' . $categoryIdsResult['value']] = $categoryIdsResult[$this->db->edition->getLinkField()];
            self::$cachedCategoryMapping[$categoryIdsResult[$this->db->edition->getLinkField()]] = $categoryIdsResult['entity_id'];
        }
        self::$cachedCategoryEntityIdByMaasId = array_merge(self::$cachedCategoryEntityIdByMaasId, $categoryIds);
        return $categoryIds;
    }

    /**
     * @param int[] $categoryEntityIds
     *
     * @return array
     */
    protected function loadCategoryPaths($categoryEntityIds)
    {
        if (!count($categoryEntityIds)) {
            return [];
        }

        // For enterprise edition
        if ($this->db->edition->isEnterprise()) {
            $categoryIds = [];
            foreach ($categoryEntityIds as $id) {
                $categoryIds [] = self::$cachedCategoryMapping[$id];
            }
            $categoryEntityIds = $categoryIds;
        }

        // load raw paths
        $rawPathResults = $this->db->selectAndFetchAll('catalog_category_entity', 'entity_id', ['path'],
            $this->placeholderService->replace(self::SELECT_CATEGORY_PATHS_WHERE_TEMPLATE, [
                'values' => implode(',', array_fill(0, count($categoryEntityIds), '?'))
            ]), null, array_values($categoryEntityIds)
        );
        $categoryIdNamesToPreload = [];
        if (!$rawPathResults) {
            return [];
        }

        $pathPartsByCategory = [];
        foreach ($rawPathResults as $rawPathResultRow) {
            $categoryIdNamesToPreload[$rawPathResultRow['entity_id']] = true;
            $pathPartsByCategory[$rawPathResultRow['entity_id']] = [];
            foreach (explode('/', $rawPathResultRow['path']) as $pathPart) {
                $categoryIdNamesToPreload[$pathPart] = true;
                $pathPartsByCategory[$rawPathResultRow['entity_id']][] = $pathPart;
            }
        }

        $rootCategoryId = reset($pathPartsByCategory)[0];
        $this->loadCategoryNames(array_keys($categoryIdNamesToPreload));
        $result = [];
        foreach ($categoryEntityIds as $maasCategoryId => $categoryEntityId) {
            $namedParts = [];
            foreach ($pathPartsByCategory[$categoryEntityId] as $part) {
                if ($part == $rootCategoryId or !isset(self::$cachedCategoryNamesByEntityId[$part])) {
                    continue;
                }
                $namedParts[] = self::$cachedCategoryNamesByEntityId[$part];
            }
            $result[$categoryEntityId] = implode('/', $namedParts);
        }

        return $result;
    }

    /**
     * @param int[] $categoryIdNamesToPreload
     *
     * @return $this
     */
    protected function loadCategoryNames($categoryIdNamesToPreload)
    {
        $params = $categoryIdNamesToPreload;
        array_unshift($params, self::$maasAttributeIdName);
        $template = $this->db->strReplace('%link_field%', $this->db->edition->getLinkField(), self::CATEGORY_ENTITY_JOIN_TEMPLATE);
        if ($this->db->edition->isEnterprise()) {
            $join = $this->placeholderService->replace($template, [
                'cce' => $this->db->getTableName('catalog_category_entity')
            ]);
            $cols = ['entity_id', $this->db->edition->getLinkField(), 'value'];
            $categoriesRowIds = [];
            $categoryIdsFlipped = array_flip(self::$cachedCategoryMapping);
            foreach ($categoryIdNamesToPreload as $id) {
                if (!isset($categoryIdsFlipped[$id])) continue;
                $categoriesRowIds[] = (string)$categoryIdsFlipped[$id];
            }
            $categoryIdNamesToPreload = $categoriesRowIds;

            array_unshift($categoriesRowIds, self::$maasAttributeIdName);
            $params = $categoriesRowIds;
        } else {
            $cols = ['entity_id', 'value'];
            $join = null;
        }

        $template = $this->db->strReplace('%link_field%', $this->db->edition->getLinkField(), self::SELECT_CATEGORY_NAMES_WHERE_TEMPLATE);

        $namesResults = $this->db->selectAndFetchAll('catalog_category_entity_varchar', 'value_id',
            $cols,
            $this->placeholderService->replace($template, [
                'values' => implode(',', array_fill(0, count($categoryIdNamesToPreload), '?'))
            ]), $join, $params);
        foreach ($namesResults as $namesResultRow) {
            self::$cachedCategoryNamesByEntityId[$namesResultRow['entity_id']] = $namesResultRow['value'];
        }

        return $this;
    }

    /**
     * @param int[] $categoryUrlPathsToPreload
     *
     * @return $this
     */
    protected function loadCategoryUrlPath($categoryUrlPathsToPreload)
    {
        $params = $categoryUrlPathsToPreload;
        array_unshift($params, self::$maasAttributeIdUrlPath);
        $template = $this->db->strReplace('%link_field%', $this->db->edition->getLinkField(), self::CATEGORY_ENTITY_JOIN_TEMPLATE);
        if ($this->db->edition->isEnterprise()) {
            $join = $this->placeholderService->replace($template, [
                'cce' => $this->db->getTableName('catalog_category_entity')
            ]);
            $cols = ['entity_id', $this->db->edition->getLinkField(), 'value'];
        } else {
            $cols = ['entity_id', 'value'];
            $join = null;
        }

        $template = $this->db->strReplace('%link_field%', $this->db->edition->getLinkField(), self::SELECT_CATEGORY_NAMES_WHERE_TEMPLATE);
        if (!count($categoryUrlPathsToPreload)) {
            return $this;
        }

        $pathsResults = $this->db->selectAndFetchAll('catalog_category_entity_varchar', 'value_id',
            $cols,
            $this->placeholderService->replace($template, [
                'values' => implode(',', array_fill(0, count($categoryUrlPathsToPreload), '?'))
            ]), $join, array_values($params));

        foreach ($pathsResults as $pathsResultsRow) {
            self::$cachedCategoryUrlPathsByEntityId[$pathsResultsRow['entity_id']] = $pathsResultsRow['value'];
        }
        return $this;
    }

    /**
     * @param string[] $row
     *
     * @return $this
     */
    protected function replaceCategoryDataInRow(&$row)
    {
        $row = array_merge($row, self::$cachedData[$row['maas_category']] ?? []);
        unset($row['maas_category']);
        return $this;
    }

    /**
     * @return $this
     */
    public function reinit()
    {
        self::$cachedData = [];
        self::$cachedCategoryEntityIdByMaasId = [];
        self::$cachedCategoryNamesByEntityId = [];
        return $this;
    }
}
