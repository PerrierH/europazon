<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product\Delete;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Maas\ImportExport\Model\ResourceModel\Product as ProductResource;
use Magento\Catalog\Model\Indexer\Product\Eav\Processor as EavProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\Processor as FlatProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\State as FlatState;
use Magento\CatalogInventory\Model\Indexer\Stock\Processor as StockProcessor;
use Magento\Framework\App\ResourceConnection;

/**
 * Class Offer
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Catalog\Product\Delete
 */
class Offer extends AbstractStepResource
{
    /**
     * @var ProductResource
     */
    private $productResource;


    /**
     * Product constructor.
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param ProductResource $productResource
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db $db,
        Placeholder $placeholderService,
        ProductResource $productResource,
        array $config = [],
        array $children = []
    ) {
        $this->productResource = $productResource;
        parent::__construct($resource, $db, $placeholderService, $config, $children);
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $skuToDelete = [];
        /** preload product entity_id  by sku */
        foreach ($rows as $row) {
            if (array_key_exists('sku', $row)) {
                $skuToDelete[] = ['sku' => $row['sku']];
				$this->logger->success(sprintf("P : %s deleted", $row['sku']));
            }
        }
        if (count($skuToDelete)) {
            $this->deleteRecords('maas_offer', 'product_id', $skuToDelete);
        }

        return $this;
    }

    public function reinit()
    {
        return $this;
    }
}
