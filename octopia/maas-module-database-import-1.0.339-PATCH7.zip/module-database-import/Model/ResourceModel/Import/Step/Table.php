<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step;

use Exception;

/**
 * Class Table
 *
 * Configurable step, used to insert data into a table, based on unique values, eventually different from the primary key.
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step
 */
class Table extends AbstractStepResource
{
    const CONFIG_TABLE = 'table';
    const CONFIG_TABLE_KEYS = 'keys';
    const CONFIG_TABLE_PRIMARY_KEY = 'primary_key';
    const CONFIG_TABLE_NOT_UPDATED_COLS = 'not_updated_columns';
    const CONFIG_TABLE_WHERE = 'where';

    const REGEX_SELECT_WHERE_MACRO = '/\{\{(\S+) ([^\}]+)\}\}/';

    /**
     * @var array
     */
    protected $existingValuesCache = null;

    /**
     * @var array
     */
    protected $context;

    /**
     * @return $this
     */
    public function reinit()
    {
        $this->existingValuesCache = null;
        return $this;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        if (!$rows) {
            return $this;
        }
        $this->context = $context;
        $this->executeForTable($rows);
        $context = $this->context;
        return $this;
    }

    /**
     * @param array $rows
     *
     * @return $this
     */
    protected function executeForTable(&$rows)
    {
        $this->loadExistingValues();
        $toInsert = [];
        $toUpdate = [];
        $keysFlipped = array_flip($this->db->getTableColumns($this->config[self::CONFIG_TABLE]));
        foreach ($rows as &$row) {
            $primaryKey = $this->getPrimaryKey($row);
            if (is_null($primaryKey)) {
                $toInsert[] = array_intersect_key($row, $keysFlipped);
            } else {
                $row[$this->config[self::CONFIG_TABLE_PRIMARY_KEY]] = $primaryKey;
                $toUpdate[$primaryKey] = array_intersect_key($row, $keysFlipped);
            }
        }
        if ($toInsert) {
            $toInsert = array_chunk($toInsert, $this->config[self::CHUNK_SIZE]);

            foreach ($toInsert as $toInsertChunk) {
                $this->insertChunk($toInsertChunk);
            }
        }

        if ($toUpdate) {
            $toUpdate = array_chunk($toUpdate, $this->config[self::CHUNK_SIZE], true);
            foreach ($toUpdate as $toUpdateChunk) {
                $this->updateChunk($toUpdateChunk);
            }
        }
        return $this;
    }

    /**
     * @return $this
     */
    protected function loadExistingValues()
    {
        if (is_null($this->existingValuesCache)) {
            $rows = $this->db->selectAndFetchAll($this->config[self::CONFIG_TABLE],
                $this->config[self::CONFIG_TABLE_PRIMARY_KEY],
                $this->getValueAsArray($this->config[self::CONFIG_TABLE_KEYS]),
                $this->parseQueryConfigValue(
                    self::CONFIG_TABLE_WHERE, ' where '
                )
            );
            foreach ($rows as $row) {
                $this->registerExistingValue($row);
            }
        }
        return $this;
    }

    /**
     * @param string $configKey
     * @param string $prefix
     *
     * @return string
     */
    protected function parseQueryConfigValue($configKey, $prefix)
    {
        $where = $this->config[$configKey] ?? false;
        if (!$where) {
            return '';
        }
        $match = [];
        while (preg_match(self::REGEX_SELECT_WHERE_MACRO, $where, $match)) {
            switch ($match[1]) {
                case 'table':
                    $where = str_replace($match[0], $this->db->getTableName($match[2]), $where);
                    break;
                case 'context':
                    if (isset($this->context[$match[2]]) && is_scalar($this->context[$match[2]])) {
                        $where = str_replace($match[0], $this->context[$match[2]], $where);
                    } else {
                        $where = str_replace($match[0], '', $where);
                    }
                    break;
            }
        }
        return $prefix . $where;
    }

    /**
     * @param array $values
     *
     * @return $this
     */
    protected function registerExistingValue($values)
    {
        $primaryKey = $values[$this->config[self::CONFIG_TABLE_PRIMARY_KEY]];
        $keys = $this->getKey($values);
        $this->existingValuesCache[$keys] = $primaryKey;
        return $this;
    }

    /**
     * @param $row
     *
     * @return string
     */
    protected function getKey($row)
    {
        return $this->extractKey($row, $this->getValueAsArray($this->config[self::CONFIG_TABLE_KEYS]));
    }

    /**
     * @param array $row
     *
     * @return int|null
     */
    protected function getPrimaryKey($row)
    {
        $k = $this->getKey($row);
        return $this->existingValuesCache[$k] ?? null;
    }

    /**
     * @param string[][] $toInsert
     *
     * @return $this
     */
    protected function insertChunk(&$toInsert)
    {
        try {
            $this->db->insertMultiple($this->config[self::CONFIG_TABLE], $toInsert);
        } catch (Exception $e) {
            $this->logger->error(sprintf("Error Insert into table[%s] : %s", $this->config[self::CONFIG_TABLE], $e->getMessage()));
        }
        return $this;
    }

    /**
     * @param string[][] $toUpdate
     *
     * @return $this
     */
    protected function updateChunk(&$toUpdate)
    {
        $table = $this->config[self::CONFIG_TABLE];
        $fieldsToOmit = $this->getValueAsArray($this->config[self::CONFIG_TABLE_NOT_UPDATED_COLS]);
        $this->db->clearUpdateQueriesCache($table);
        foreach ($toUpdate as $primaryKey => $row) {
            try {
                $this->db->update(
                    $table, [
                    $this->config[self::CONFIG_TABLE_PRIMARY_KEY] => $primaryKey
                ], $row, $fieldsToOmit);
            } catch (Exception $e) {
                $this->logger->error(sprintf("Error update into table[%s] : %s", $table, $e->getMessage()));
            }
        }
        return $this;
    }
}
