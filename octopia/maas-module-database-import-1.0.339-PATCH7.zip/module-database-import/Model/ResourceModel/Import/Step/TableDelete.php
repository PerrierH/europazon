<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step;

/**
 * Class TableDelete
 *
 * Configurable step used to delete rows based on values from rows
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step
 */
class TableDelete extends AbstractStepResource
{
    const CONFIG_TABLE = 'table';
    const CONFIG_TABLE_KEYS = 'keys';

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        if (!$rows) {
            return $this;
        }
        $toDelete = [];
        $keys = $this->getValueAsArray($this->config[self::CONFIG_TABLE_KEYS]);
        $keysFlipped = array_flip($keys);
        foreach ($rows as $row) {
            $arrayIntersect = array_intersect_key($row, $keysFlipped);
            if (count($arrayIntersect)) {
                $toDelete[] = $arrayIntersect;
            }
        }
        $toDelete = array_chunk($toDelete, $this->config[self::CHUNK_SIZE]);
        foreach ($toDelete as $toDeleteChunk) {
            $this->db->delete($this->config[self::CONFIG_TABLE], $keys, $toDeleteChunk);
        }
        return $this;
    }
}