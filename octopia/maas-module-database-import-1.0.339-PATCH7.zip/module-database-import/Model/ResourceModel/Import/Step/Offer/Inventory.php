<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Offer;

use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;

/**
 * Class Inventory
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Offer\Inventory
 */
class Inventory extends AbstractStepResource
{
    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $inventories = [];
        foreach ($rows as $row) {
            $inventories[] = $row['inventory'];
        }
        foreach ($this->children as $child) {
            $child->execute($inventories, $context);
        }
        return $this;
    }

    /**
     * @return $this|Inventory
     */
    public function reinit()
    {
        return $this;
    }
}
