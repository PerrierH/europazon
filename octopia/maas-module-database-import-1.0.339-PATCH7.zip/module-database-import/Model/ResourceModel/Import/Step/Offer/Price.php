<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Offer;

use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;

/**
 * Class Price
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Offer\Price
 */
class Price extends AbstractStepResource
{

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $prices = [];
        foreach ($rows as $row) {
            $prices[] = $row['price'];
        }
        foreach ($this->children as $child) {
            $child->execute($prices, $context);
        }
        return $this;
    }

    /**
     * @return $this|Price
     */
    public function reinit()
    {
        return $this;
    }
}
