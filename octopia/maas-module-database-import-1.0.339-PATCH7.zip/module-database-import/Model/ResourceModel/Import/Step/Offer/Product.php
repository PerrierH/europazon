<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Offer;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Maas\ImportExport\Model\ResourceModel\Product as ProductResource;
use Magento\Catalog\Model\Indexer\Product\Eav\Processor as EavProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\Processor as FlatProcessor;
use Magento\Catalog\Model\Indexer\Product\Flat\State as FlatState;
use Magento\CatalogInventory\Model\Indexer\Stock\Processor as StockProcessor;
use Magento\Framework\App\ResourceConnection;

/**
 * Class Product
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Offer\Product
 */
class Product extends AbstractStepResource
{
    /**
     * @var EavProcessor
     */
    protected $_indexerEavProcessor;

    /**
     * @var State
     */
    private $flatState;

    /**
     * @var FlatProcessor
     */
    protected $_productFlatIndexerProcessor;
    /**
     * @var StockProcessor
     */
    protected $_stockIndexerProcessor;
    /**
     * @var ProductResource
     */
    private $productResource;


    /**
     * Product constructor.
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param ProductResource $productResource
     * @param EavProcessor $indexerEavProcessor
     * @param FlatState $flatState
     * @param FlatProcessor $productFlatIndexerProcessor
     * @param StockProcessor $stockIndexerProcessor
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db                 $db,
        Placeholder        $placeholderService,
        ProductResource    $productResource,
        EavProcessor       $indexerEavProcessor,
        FlatState          $flatState,
        FlatProcessor      $productFlatIndexerProcessor,
        StockProcessor     $stockIndexerProcessor,
        array              $config = [],
        array              $children = []
    )
    {
        $this->productResource = $productResource;
        $this->_indexerEavProcessor = $indexerEavProcessor;
        $this->flatState = $flatState;
        $this->_productFlatIndexerProcessor = $productFlatIndexerProcessor;
        $this->_stockIndexerProcessor = $stockIndexerProcessor;
        parent::__construct($resource, $db, $placeholderService, $config, $children);
    }

    /**
     * @param $rows
     * @param $context
     * @return $this|Product
     */
    public function execute(&$rows, &$context)
    {
        $context['entity_type_id'] = 4;
        $stockItems = [];
        $productsIds = [];
        $offersIds = [];

        /** preload product entity_id  by offer id */
        foreach ($rows as $row) {
            $offersIds [] = $row['maas_entity_id'];
        }

        $productExists = $this->productResource->preloadProductIdsByOfferIds($offersIds);

        if ($productExists) {
            foreach ($rows as $row) {
                if (isset($productExists[$row['maas_entity_id']])) {
                    $productId = $productExists[$row['maas_entity_id']];
                    $productsIds [] = $productId;
                    $stockItems[] = [
                        'product_id' => $productId,
                        'entity_id' => $productId,
                        'stock_id' => 1,
                        'website_id' => 0,
                        'qty' => 0,
                        'is_in_stock' => 0,
                        'stock_status' => 0,
                        'status' => 2,
                        'visibility' => 1
                    ];
                }
            }

            foreach ($this->children as $child) {
                $child->execute($stockItems, $context);
            }
            // Reindexing all products
            if (sizeof($productsIds)) {
                $this->reindexProducts($productsIds);
            }
        }
        return $this;
    }

    /**
     * products reindexation
     * @param array $ids
     */
    private function reindexProducts(array $ids)
    {
        if (!$this->_indexerEavProcessor->isIndexerScheduled()) {
            $this->_indexerEavProcessor->markIndexerAsInvalid();
        } else {
            $this->_indexerEavProcessor->reindexList($ids);
        }

        if ($this->flatState->isFlatEnabled() && !$this->_productFlatIndexerProcessor->isIndexerScheduled()) {
            $this->_productFlatIndexerProcessor->markIndexerAsInvalid();
        } else {
            $this->_productFlatIndexerProcessor->reindexList($ids);
        }

        if (!$this->_stockIndexerProcessor->isIndexerScheduled()) {
            $this->_stockIndexerProcessor->markIndexerAsInvalid();
        } else {
            $this->_stockIndexerProcessor->reindexList($ids);
        }
    }

    public function reinit()
    {
        return $this;
    }
}
