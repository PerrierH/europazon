<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Eav\Attribute;

use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\AbstractStepResource;
use Maas\DatabaseImport\Model\Service\OptionKey;
use Magento\Framework\App\ResourceConnection;
use PDO;

/**
 * Class AddOptions
 *
 * Adds options to a select or multiselect EAV attribute
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Eav\Attribute
 */
class AddOptions extends AbstractStepResource
{
    const SELECT_EXISTING_OPTIONS_AND_VALUES = 'select eao.option_id, eao.attribute_id, eaov.value
    from @eao@ as eao
    join @ea@ as ea on eao.attribute_id = ea.attribute_id
    join @eaov@ as eaov on eao.option_id = eaov.option_id
    where ea.entity_type_id = @et_id@ and eaov.store_id = 0';

    protected $existingOptionsCache = null;

    protected $optionKeyService;

    /**
     * AddOptions constructor.
     * @param ResourceConnection $resource
     * @param Db $db
     * @param OptionKey $optionKeyService
     * @param Placeholder $placeholderService
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db $db,
        OptionKey $optionKeyService,
        Placeholder $placeholderService,
        array$config = [],
        array$children = []
    ) {
        parent::__construct($resource, $db, $placeholderService, $config, $children);
        $this->optionKeyService = $optionKeyService;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $this->loadExisting($context['entity_type_id']);
        $optionCols = array_flip($this->db->getTableColumns('eav_attribute_option'));
        $valueCols = array_flip($this->db->getTableColumns('eav_attribute_option_value'));
        foreach ($rows as &$row) {
            $key = $this->getRowKey($row);
            if (!isset($this->existingOptionsCache[$key])) {
                $optionToInsert = array_intersect_key($row, $optionCols);
                $this->db->insert('eav_attribute_option', $optionToInsert);
                $lastInsertId = $this->db->getLastInsertId();
                $row['option_id'] = $lastInsertId;
                $valueToInsert = array_intersect_key($row, $valueCols);
                $this->db->insert('eav_attribute_option_value', $valueToInsert);
                $this->existingOptionsCache[$key] = $row['option_id'];
            }
        }
        return $this;
    }

    /**
     * @param int $entityTypeId
     *
     * @return $this
     */
    protected function loadExisting($entityTypeId)
    {
        if (is_null($this->existingOptionsCache)) {
            $query = $this->placeholderService->replace(self::SELECT_EXISTING_OPTIONS_AND_VALUES, [
                'eao' => $this->db->getTableName('eav_attribute_option'),
                'ea' => $this->db->getTableName('eav_attribute'),
                'eaov' => $this->db->getTableName('eav_attribute_option_value'),
                'et_id' => $entityTypeId,
            ]);
            $rows = $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                $key = $this->getRowKey($row);
                $this->existingOptionsCache[$key] = $row['option_id'];
            }
        }
        return $this;
    }

    /**
     * @param array $row
     *
     * @return string
     */
    protected function getRowKey($row)
    {
        return $row['attribute_id'] . '-' . $this->optionKeyService->filter($row['value']);
    }

    /**
     * @return $this
     */
    public function reinit()
    {
        $this->existingOptionsCache = null;
        return $this;
    }
}
