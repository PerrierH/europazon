<?php

namespace Maas\DatabaseImport\Model\ResourceModel\Import\Step\Eav\Attribute;

use Maas\DatabaseImport\Model\Import\Registry\Eav;
use Maas\DatabaseImport\Model\Placeholder;
use Maas\DatabaseImport\Model\ResourceModel\Connection\Db;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\Table;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\TableDelete;
use Maas\DatabaseImport\Model\ResourceModel\Import\Step\TableDeleteFactory;
use Maas\DatabaseImport\Model\Service\OptionKey;
use Magento\Framework\App\ResourceConnection;
use Maas\Core\Api\Data\EditionInterface;
use PDO;

/**
 * Class AddValues
 *
 * Adds attribute values to an injected EAV entity
 *
 * @package Maas\DatabaseImport\Model\ResourceModel\Import\Step\Eav\Attribute
 */
class AddValues extends Table
{

    const SELECT_EXISTING_OPTIONS_AND_VALUES = 'select eao.option_id, eao.attribute_id, eaov.value_id, eaov.value
    from @eao@ as eao
    join @ea@ as ea on eao.attribute_id = ea.attribute_id
    join @eaov@ as eaov on eao.option_id = eaov.option_id
    where ea.entity_type_id = @et_id@ and eaov.store_id = 0';

    /**
     * @var array|null
     */
    protected $existingOptionsCache = null;

    /**
     * @var OptionKey
     */
    protected $optionKeyService;

    /**
     * @var Eav
     */
    protected $eavRegistry;

    /**
     * @var null|TableDelete
     */
    protected $tableDelete = null;

    /**
     * @var TableDeleteFactory
     */
    private $tableDeleteFactory;

    /**
     * @param ResourceConnection $resource
     * @param Db $db
     * @param Placeholder $placeholderService
     * @param Eav $eavRegistry
     * @param TableDeleteFactory $tableDeleteFactory
     * @param OptionKey $optionKeyService
     * @param array $config
     * @param array $children
     */
    public function __construct(
        ResourceConnection $resource,
        Db                 $db,
        Placeholder        $placeholderService,
        Eav                $eavRegistry,
        TableDeleteFactory $tableDeleteFactory,
        OptionKey          $optionKeyService,
        array              $config = [],
        array              $children = []
    )
    {
        parent::__construct($resource, $db, $placeholderService, $config, $children);
        $this->eavRegistry = $eavRegistry;
        $this->optionKeyService = $optionKeyService;
        $this->tableDeleteFactory = $tableDeleteFactory;
    }


    /**
     * @param array $rows
     * @param array $context
     * @return AddValues|void
     */
    public function execute(&$rows, &$context)
    {
        $this->loadExisting($context['entity_type_id']);
        $entityType = $this->eavRegistry->getEntityType($context['entity_type_id']);
        $attributes = $this->eavRegistry->getAttributes($context['entity_type_id']);
        $toInsertByType = [];
        $toDeleteByType = [];
        foreach ($rows as &$row) {
            $this->processRow($toInsertByType, $toDeleteByType, $attributes, $row);
        }

        $this->context = $context;
        $keys = ($this->db->edition->isEnterprise()) ? 'row_id,attribute_id,store_id' : 'entity_id,attribute_id,store_id';
        foreach ($toInsertByType as $backendType => &$typeRows) {
            $this->config = array_merge($this->config, [
                self::CONFIG_TABLE => $entityType['entity_table'] . '_' . $backendType,
                self::CONFIG_TABLE_KEYS => $keys,
                self::CONFIG_TABLE_PRIMARY_KEY => 'value_id',
                self::CONFIG_TABLE_NOT_UPDATED_COLS => ''
            ]);
            parent::reinit();
            $this->executeForTable($typeRows);
            $context = $this->context;
        }
        if (!$this->tableDelete) {
            $this->tableDelete = $this->tableDeleteFactory->create();
        }
        foreach ($toDeleteByType as $backendType => &$typeRows) {
            $this->tableDelete->updateConfig([
                TableDelete::CONFIG_TABLE => $entityType['entity_table'] . '_' . $backendType,
                TableDelete::CONFIG_TABLE_KEYS => $keys
            ]);
            $this->tableDelete->reinit();
            $this->tableDelete->execute($typeRows, $this->context);
        }
        $context = $this->context;
    }

    /**
     * @param int $entityTypeId
     *
     * @return $this
     */
    protected function loadExisting($entityTypeId)
    {
        if (is_null($this->existingOptionsCache)) {
            $query = $this->placeholderService->replace(self::SELECT_EXISTING_OPTIONS_AND_VALUES, [
                'eao' => $this->db->getTableName('eav_attribute_option'),
                'ea' => $this->db->getTableName('eav_attribute'),
                'eaov' => $this->db->getTableName('eav_attribute_option_value'),
                'et_id' => $entityTypeId,
            ]);
            $rows = $this->db->execute($query)->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) {
                foreach ($rows as $row) {
                    $key = $this->getRowKey($row);
                    $this->existingOptionsCache[$key] = ['value_id' => $row['value_id'], 'option_id' => $row['option_id'], 'value' => $row['value']];
                }
            }
        }
        return $this;
    }

    /**
     * @param array $row
     *
     * @return string
     */
    protected function getRowKey($row)
    {
        return $row['attribute_id'] . '-' . $this->optionKeyService->filter($row['value']);
    }


    /**
     * @param $toInsertByType
     * @param $toDeleteByType
     * @param $attributes
     * @param $row
     */
    protected function processRow(&$toInsertByType, &$toDeleteByType, &$attributes, $row)
    {
        $linkField = $this->db->edition->getLinkField();
        foreach ($row as $key => $attributeValue) {

            $values = is_array($attributeValue) ? $attributeValue : [$attributeValue];

            if (isset($attributes[$key]) && $attributes[$key]['backend_type'] != 'static') {
                $optionAndValue = implode("\n", $values);
                if ($attributes[$key]['frontend_input'] == 'multiselect') {
                    sort($values);
                    $optionAndValues = [];
                    foreach ($values as $value) {
                        if ($value) {
                            $attributes[$key]['value'] = $value;
                            if ($attributes[$key]['is_user_defined']) {
                                $optionAndValues[] = $this->addOptionAndValue($attributes[$key]);
                            }
                        } else {
                            $toDeleteByType[$attributes[$key]['backend_type']][] = [
                                'attribute_id' => $attributes[$key]['attribute_id'],
                                'store_id' => 0,
                                $linkField => $row[$linkField],
                            ];
                        }
                    }
                    $optionAndValue = implode(',', $optionAndValues);
                } elseif ($attributes[$key]['frontend_input'] == 'select') {
                    sort($values);
                    $optionAndValue = implode(', ', $values);
                    if ($optionAndValue) {
                        $attributes[$key]['value'] = $optionAndValue;
                        if ($attributes[$key]['is_user_defined']) {
                            $optionAndValue = $this->addOptionAndValue($attributes[$key]);
                        }
                    } else {
                        $toDeleteByType[$attributes[$key]['backend_type']][] = [
                            'attribute_id' => $attributes[$key]['attribute_id'],
                            'store_id' => 0,
                            $linkField => $row[$linkField],
                        ];
                    }
                }
                $toInsertByType[$attributes[$key]['backend_type']][] = [
                    'attribute_id' => $attributes[$key]['attribute_id'],
                    'store_id' => 0,
                    $linkField => $row[$linkField],
                    'value' => $optionAndValue
                ];
            }
        }
    }


    /**
     * @param array $attribute
     * @return int
     */
    private function addOptionAndValue(array $attribute)
    {
        $key = $this->getRowKey($attribute);
        if (!isset($this->existingOptionsCache[$key])) {
            $optionToInsert = [
                'attribute_id' => $attribute['attribute_id']
            ];
            $this->db->insert('eav_attribute_option', $optionToInsert);
            $optionLastInsertId = $this->db->getLastInsertId();
            $valueToInsert = [
                'option_id' => $optionLastInsertId,
                'store_id' => 0,
                'value' => $attribute['value']
            ];
            $this->db->insert('eav_attribute_option_value', $valueToInsert);
            $valueId = $this->db->getLastInsertId();
            $this->existingOptionsCache[$key] = ['value_id' => $valueId, 'option_id' => $optionLastInsertId, 'value' => $attribute['value']];
            return $optionLastInsertId;
        } else {
            return $this->existingOptionsCache[$key]['option_id'];
        }
    }

    /**
     * @return $this|AddValues
     */
    public function reinit()
    {
        $this->existingOptionsCache = null;
        return $this;
    }
}
