<?php

namespace Maas\DatabaseImport\Model\Import\Consumer;

use Maas\Catalog\Model\Service\AttributeCode;
use Maas\Core\Model\Config;
use Maas\Core\Model\Service\MessageQueue\ConsumerInterface;
use Maas\DatabaseImport\Model\Import\Registry\Eav;
use Maas\DatabaseImport\Model\ImportRunner;
use Maas\DatabaseImport\Model\ImportRunnerFactory;
use Maas\ImportExport\Api\Data\Catalog\ProductInterface;
use Maas\ImportExport\Api\Data\ProductImportMessageInterface;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Import\AbstractConsumer;
use Maas\ImportExport\Model\Import\Catalog\Product as ProductImport;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Log\Model\Csv;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\Offer\Api\OfferRepositoryInterface;
use Magento\Catalog\Model\Indexer\Product\Category as CategoryIndexer;
use Magento\Catalog\Model\Product\Type;
use Magento\Catalog\Model\Product\Url;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Indexer\IndexerRegistry;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\ImportExport\Model\ResourceModel\Import\Data as ImportData;
use Maas\ImportExport\Model\ResourceModel\Product as ProductResource;
use Maas\Log\Model\ResourceModel\Report as ReportResource;
use Maas\DatabaseImport\Model\Import\Registry\Eav as EavRegistry;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\Product\Visibility;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class Product
 */
class Product extends AbstractConsumer implements ConsumerInterface
{
    /**
     * @var ImportData
     */
    protected $importData;
    /**
     * @var CacheInterface
     */
    protected $cache;
    /**
     * @var ReportInterface
     */
    protected $report;
    /**
     * @var ImportRunner
     */
    protected $importAttributeRunner;
    /**
     * @var ImportRunner
     */
    protected $importProductRunner;

    /**
     * @var ImportRunner
     */
    protected $deleteProductRunner;
    /**
     * @var ReportResource
     */
    protected $reportResource;
    /**
     * @var ReportRepositoryInterface
     */
    private $reportRepository;
    /**
     * @var ProductResource
     */
    private $productResource;
    /**
     * @var IndexerRegistry
     */
    private $indexerRegistry;
    /**
     * @var Url
     */
    private $productUrl;

    /**
     * @var AttributeCode
     */
    private $attributeCodeService;

    /**
     * @var EavRegistry
     */
    private $eavRegistry;

    /**
     * @var EditionInterface
     */
    protected $edition;
    protected ReportManagementInterface $reportManagement;

    /**
     * @param ModuleListProxy $moduleList
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OfferRepositoryInterface $offerRepository
     * @param DateTime $dateTime
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param Config $coreConfig
     * @param ImportData $importData
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param ProductResource $productResource
     * @param IndexerRegistry $indexerRegistry
     * @param ImportRunnerFactory $importRunnerFactory
     * @param Url $productUrl
     * @param ReportResource $reportResource
     * @param AttributeCode $attributeCodeService
     * @param EavRegistry $eavRegistry
     * @param EditionInterface $edition
     */
    public function __construct(
        ModuleListProxy           $moduleList,
        FilterBuilder             $filterBuilder,
        SearchCriteriaBuilder     $searchCriteriaBuilder,
        OfferRepositoryInterface  $offerRepository,
        DateTime                  $dateTime,
        CsvLoggerManagement       $csvLoggerManagement,
        Config                    $coreConfig,
        ImportData                $importData,
        CacheInterface            $cache,
        SerializerInterface       $serializer,
        ReportCollectionFactory   $reportCollectionFactory,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        ProductResource           $productResource,
        IndexerRegistry           $indexerRegistry,
        ImportRunnerFactory       $importRunnerFactory,
        Url                       $productUrl,
        ReportResource            $reportResource,
        AttributeCode             $attributeCodeService,
        EavRegistry               $eavRegistry,
        EditionInterface          $edition
    )
    {
        parent::__construct(
            $moduleList,
            $filterBuilder,
            $searchCriteriaBuilder,
            $offerRepository,
            $dateTime,
            $csvLoggerManagement,
            $cache,
            $coreConfig,
            $serializer,
            $reportCollectionFactory
        );
        $this->importData = $importData;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->productResource = $productResource;
        $this->indexerRegistry = $indexerRegistry;
        $this->productUrl = $productUrl;
        $this->reportResource = $reportResource;
        $this->attributeCodeService = $attributeCodeService;
        $this->eavRegistry = $eavRegistry;
        $this->edition = $edition;
        $this->importAttributeRunner = $importRunnerFactory->create();
        $this->importAttributeRunner->initialize('maas_catalog_attribute_import');
        $this->importProductRunner = $importRunnerFactory->create();
        $this->importProductRunner->initialize('maas_catalog_product_import');
        $this->deleteProductRunner = $importRunnerFactory->create();
        $this->deleteProductRunner->initialize('maas_catalog_product_delete');
        $this->coreConfig = $coreConfig;
    }

    /**
     * @param ProductImportMessageInterface $message
     *
     * @throws NoSuchEntityException
     */
    public function process($message)
    {
        $this->reportId = $message->getReportId();
        if ($this->reportId == 0) {
            $this->report = $this->getStartedImportReportObject(ProductImport::MAAS_LOG_MODULE, ProductImport::MAAS_LOG_ACTION);
            $this->reportId = $this->report->getId();
        } else {
            $this->report = $this->reportRepository->get($this->reportId);
        }
        // import products flagged as active
        $this->importProducts($message);
        // Update Report Status when all messages are consumed
        if ($this->report->isJobOver()) {
            $report = $this->report;
            $this->reportManagement->close($report);
            /** Clean cache */
            $this->cache->remove(ProductImport::CACHE_KEY_MAAS_REPORT_ID);
            $this->clearCacheOnJobOver();
        }
    }

    /**
     * @param ProductImportMessageInterface $message
     *
     * @throws NoSuchEntityException
     */
    protected function importProducts($message)
    {
        $dataToImport = [];
        $dataToDelete = [];
        $attributesToCreate = [];
        $dataOrphans = [];
        $isDelta = ($this->report->getIsDelta()) ?? false;
        $this->productResource->clearIdsToPreload();

        foreach ($message->getEntities() as $productData) {
            $this->productResource->addIdToPreload($productData->getProductId());
        }

        $this->productResource->preloadProductIdStatus();
        foreach ($message->getEntities() as $productData) {
            $this->importProduct($productData, $dataToImport, $attributesToCreate, $dataToDelete, $dataOrphans, $isDelta);
        }

        $this->processDataToImport($dataToImport, $attributesToCreate, $dataToDelete, $dataOrphans);
    }

    /**
     * @param ProductInterface $productData
     * @param array $dataToImport
     * @param array $attributesToCreate
     * @param array $dataToDelete
     * @param array $dataOrphans
     *
     * @throws NoSuchEntityException
     */
    protected function importProduct($productData, &$dataToImport, &$attributesToCreate, &$dataToDelete, &$dataOrphans, $isDelta = false)
    {
        $new = false;
        $productExists = $this->productResource->productSkuExists($productData->getProductId());
        $this->report->log(sprintf('candidate SKU %s', $productData->getProductId()));

        if (is_array($productExists)) {
            $productData['parent_entity_id'] = $productExists['parent_entity_id'];
            $productData['entity_id'] = $productExists['entity_id'];
            if ($this->edition->isEnterprise()) {
                $productData['row_id'] = $productExists['row_id'];
            }
            $new = true;
        } else {
            $productData['entity_id'] = null;
            $productData['parent_entity_id'] = null;
            if ($this->edition->isEnterprise()) {
                $productData['entity_id'] = $this->productResource->createSequenceProduct();
            }
        }

        if ($this->handleProductIsInactive($productData, $productExists, $dataToDelete)
            || $this->handleProductIsUpToDate($productData, $productExists, $isDelta)
            || $this->handleVariantProductCase($productData)) {

            $this->report->setDeltaSuccessItemsCount(1);
            $this->reportRepository->save($this->report);

            return;
        }

        $productToImport = [
            'sku' => $productData->getProductId(),
            'name' => $productData->getTitle(),
            'description' => $productData->getDescription(),
            'short_description' => $this->getShortDescription($productData->getDescription()),
            'weight' => (float)$productData->getWeight(),
            'maas_category' => $productData->getCategoryId(),
            'attribute_set_id' => $productData->getAttributeSetId(),
            'product_type' => Type::TYPE_SIMPLE,
            'url_key' => $this->productUrl->formatUrlKey($productData->getTitle() . '-' . $productData->getProductId()),
            'attribute_group_objects' => $productData->getAttributesGroup(),
            'maas_variation_attributes' => json_encode($productData->getVariationAttributes() ?
        $this->processVariationAttributes($productData->getVariationAttributes()) : []),
            'maas_variation_group_id' => $productData->getVariationGroupId(),
            'maas_brand' => $productData->getBrand()->getLabel(),
            'maas_brand_code' => $productData->getBrand()->getCode(),
            'maas_is_maas_product' => 1,
            'maas_sync_date' => $this->dateTime->date(),
            'updated_at' => $productData->getUpdatedAt(),
            'maas_updated_at' => $productData->getMaasUpdatedAt(),
            'maas_offer_updated_at' => '1900-01-01 00:00:00',
            'maas_level3_category' => $productData->getThirdLevelCategoryLabel(),
            'images' => $productData->getImages()->getLarge(),
        ];

        // check if new product for init price,stock,status & visibility
        if ($new) {
            $productToImport ['price'] = 0;
            $productToImport ['stockItems'] = ['stock_id' => 1, 'website_id' => 0, 'qty' => 0];
            $productToImport ['status'] = Status::STATUS_DISABLED;
            $productToImport ['created_at'] = $productData->getCreatedAt();
            $productToImport ['visibility'] = Visibility::VISIBILITY_NOT_VISIBLE;
        }


        if ($productData->getEntityId()) {
            $productToImport['entity_id'] = $productData->getEntityId();
        }

        $dataToImport[] = $productToImport;

        if ($productData->getVariationAttributes()) {
            $attributesToCreate = $this->attributesToCreate($productData->getVariationAttributes());
        }

        if (is_array($productExists)
            && !empty($productExists['maas_variation_group_id'])
            && ($productData->getVariationGroupId() !== $productExists['maas_variation_group_id'])
            && !empty($productExists['parent_entity_id'])) {

            if ($productData->getProductId() . '_group' === $productExists['parent_sku']) {

                $dataToDelete[] =
                    [
                        'entity_id' => $productExists['parent_entity_id']
                    ];
                $this->report->log(sprintf('SKU %s is obsolete', $productExists['parent_sku']));

                if (!empty($productExists['brother_id'])) {
                    foreach (explode(',', $productExists['brother_id']) as $child) {
                        $exploded = explode('=>', $child);
                        if ($exploded[0] !== $productExists['entity_id']) {
                            $dataOrphans[$exploded[0]] =
                                [
                                    'sku' => $exploded[1],
                                    'maas_variation_group_id' => $productExists['maas_variation_group_id'],
                                ];
                        }
                    }
                }
            } else {
                $dataToDelete[] =
                    [
                        'product_id' => $productExists['entity_id'],
                        'child_id' => $productExists['entity_id'],
                        'parent_id' => $productExists['parent_entity_id'],
                    ];
            }
        }
    }

    /**
     * @param ProductInterface $productData
     * @param bool $productExists
     * @param array $dataToDelete
     *
     * @return bool
     */
    protected function handleProductIsInactive($productData, $productExists, &$dataToDelete)
    {
        if (strtolower($productData->getStatus()) != 'active') {
            if ($productExists) {
                $dataToDelete[] = [
                    'entity_id' => $productExists['entity_id'],
                    'parent_entity_id' => $productExists['parent_entity_id']
                ];
                $this->report->log(sprintf('SKU %s is inactive', $productData->getProductId()));

                if ($productData->getProductId() . '_group' === $productExists['parent_sku']) {

                    $dataToDelete[] =
                        [
                            'entity_id' => $productExists['parent_entity_id']
                        ];
                    $this->report->log(sprintf('SKU %s is obsolete', $productExists['parent_sku']));
                }
            } else {
                $this->report->log(sprintf('SKU %s already removed', $productData->getProductId()));
            }
            return true;
        }
        return false;
    }

    /**
     * @param $productData
     * @return array
     */
    protected function productToDelete($productData)
    {
        $productData = [
            'parent_entity_id' => $productData->getParentEntityId(),
            'sku' => $productData->getProductId(),
            'name' => $productData->getTitle(),
            '_attribute_set' => 'Maas',
            'attribute_set_code' => 'Maas',
            'product_type' => Type::TYPE_SIMPLE,
            'price' => 0
        ];

        if ($this->edition->isEnterprise()) {
            $productData['row_id'] = $productData->getRowId();
        } else {
            $productData['entity_id'] = $productData->getEntityId();
        }

        return $productData;
    }

    /**
     * @param $productData
     * @param $productExists
     * @return bool
     */
    protected function handleProductIsUpToDate($productData, $productExists, $isDelta)
    {
        /** if updatedAt is lower or equal it must return */
        if (($productExists !== false) && ($productData->getUpdatedAt() <= $productExists['maas_updated_at'] && !$isDelta)) {
            $this->report->log(sprintf('SKU %s already up to date', $productData->getProductId()));
            return true;
        }
        return false;
    }

    /**
     * @param $productData
     * @return bool
     */
    protected function handleVariantProductCase($productData)
    {
        /** if variation group is present and config is disabled it must return */
        if ($productData->getVariationGroupId() && !$this->coreConfig->isVariantProductsImportIncluded()) {
            $this->report->log(sprintf('SKU %s variant must not be imported', $productData->getProductId()));
            return true;
        }
        return false;
    }

    /**
     * @param $description
     * @return string
     */
    private function getShortDescription($description)
    {
        return (strlen($description) > 200) ? substr($description, 0, strrpos(substr($description, 0, 200), ' ')) . '...' : $description;
    }

    /**
     * @param $variationAttributes
     * @return array
     */
    private function processVariationAttributes($variationAttributes)
    {
        $variations = [];
        foreach ($variationAttributes as $variation) {
            $code = $this->attributeCodeService->generate($variation->getLabel());
            $variations[$code] = [
                'code' => $code,
                'label' => $variation->getLabel(),
            ];
        }
        return $variations;
    }

    /**
     * @param $variationAttributes
     * @return array
     */
    private function attributesToCreate($variationAttributes)
    {
        $variations = [];
        foreach ($variationAttributes as $variation) {
            $code = $this->attributeCodeService->generate($variation->getLabel());
            $variations[$code] = [
                'attribute_code' => $code,
                'frontend_label' => $variation->getLabel(),
                'frontend_input' => 'select',
                'backend_type' => 'int',
                'is_user_defined' => 1,
                'options' => []
            ];
        }
        return $variations;
    }

    /**
     * @param $dataToImport
     * @param $attributesToCreate
     * @param $dataToDelete
     * @param $dataOrphans
     * @return void
     */
    protected function processDataToImport($dataToImport, $attributesToCreate, $dataToDelete, $dataOrphans)
    {
        $context = [];
        $this->deleteProductRunner->setReport($this->report, false);
        $this->deleteProductRunner->run($dataToDelete, $context);

        $attributes = [
            'attributes' => &$attributesToCreate,
        ];
        $context = [];
        $this->importAttributeRunner->setReport($this->report, false);
        $this->importAttributeRunner->run($attributes, $context);
        $this->eavRegistry->setVariationsAttributes($attributesToCreate);
        $products = [
            'products' => &$dataToImport
        ];

        $context['orphans'] = $dataOrphans;
        $this->importProductRunner->setReport($this->report, false);
        $this->importProductRunner->run($products, $context);
    }

    /**
     * @param $reportId
     * @return Csv|mixed|null
     */
    public function getCsvLogger($reportId)
    {
        if (is_null($this->csvLogger)) {
            $this->csvLogger = $this->csvLoggerManagement->getCsvLogger(
                $reportId,
                ProductImport::CSV_LOG_HEADERS,
                ProductImport::MAAS_LOG_MODULE,
                ProductImport::MAAS_LOG_ACTION,
                ProductImport::CSV_LOG_FILE_PREFIX
            );
        }
        return $this->csvLogger;
    }

    /**
     * @return void
     * @throws \Exception
     */
    private function reindex()
    {
        $categoryIndexer = $this->indexerRegistry->get(CategoryIndexer::INDEXER_ID);
        $categoryIndexer->reindexAll();
    }
}
