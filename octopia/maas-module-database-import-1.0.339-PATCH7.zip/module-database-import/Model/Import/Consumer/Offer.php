<?php

namespace Maas\DatabaseImport\Model\Import\Consumer;

use Exception;
use Maas\Core\Model\Config;
use Maas\ImportExport\Api\Data\Offer\Inventory\DeliveryInterface;
use Maas\ImportExport\Api\Data\Offer\Inventory\InventoryInterface;
use Maas\ImportExport\Api\Data\Offer\Price\PriceInterface;
use Maas\ImportExport\Api\Data\Offer\Price\TaxInterface;
use Maas\ImportExport\Model\CsvLoggerManagement;
use Maas\ImportExport\Model\Import\AbstractConsumer;
use Maas\Core\Model\Service\MessageQueue\ConsumerInterface;
use Maas\ImportExport\Model\Import\Price\Data\Price;
use Maas\Log\Api\Data\ReportInterface;
use Maas\Log\Api\ReportManagementInterface;
use Maas\Log\Api\ReportRepositoryInterface;
use Maas\Offer\Api\OfferRepositoryInterface;
use Maas\ImportExport\Model\Registry;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Psr\Log\LogLevel;
use Magento\Framework\Module\ModuleListInterface\Proxy as ModuleListProxy;
use Maas\Log\Model\ResourceModel\Report\CollectionFactory as ReportCollectionFactory;
use Maas\ImportExport\Model\Import\Offer\Offer as OfferModel;
use Maas\DatabaseImport\Model\ImportRunner;
use Maas\DatabaseImport\Model\ImportRunnerFactory;
use Magento\Eav\Model\Config as EavConfig;
use Maas\ImportExport\Api\Data\OfferImportMessageInterface;
use Maas\Offer\Model\ResourceModel\Offer as OfferResource;


class Offer extends AbstractConsumer implements ConsumerInterface
{
    const STATUS_ACTIVE = 'active';
    /**
     * @var ImportRunner
     */
    protected $importRunner;
    /**
     * @var ImportRunner
     */
    protected $deleteRunner;
    /**
     * @var EavConfig
     */
    protected $eavConfig;
    /**
     * @var OfferResource
     */
    protected $offerResource;
    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var ReportRepositoryInterface
     */
    private $reportRepository;
    /**
     * @var ReportInterface
     */
    private $report;
    protected ReportManagementInterface $reportManagement;

    /**
     * @param ModuleListProxy $moduleList
     * @param OfferRepositoryInterface $offerRepository
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param Registry $registry
     * @param DateTime $dateTime
     * @param ReportRepositoryInterface $reportRepository
     * @param ReportManagementInterface $reportManagement
     * @param CsvLoggerManagement $csvLoggerManagement
     * @param Config $coreConfig
     * @param CacheInterface $cache
     * @param SerializerInterface $serializer
     * @param ReportCollectionFactory $reportCollectionFactory
     * @param ImportRunnerFactory $importRunnerFactory
     * @param EavConfig $eavConfig
     * @param OfferResource $offerResource
     */
    public function __construct(
        ModuleListProxy $moduleList,
        OfferRepositoryInterface $offerRepository,
        FilterBuilder $filterBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        Registry $registry,
        DateTime $dateTime,
        ReportRepositoryInterface $reportRepository,
        ReportManagementInterface $reportManagement,
        CsvLoggerManagement $csvLoggerManagement,
        Config $coreConfig,
        CacheInterface $cache,
        SerializerInterface $serializer,
        ReportCollectionFactory $reportCollectionFactory,
        ImportRunnerFactory $importRunnerFactory,
        EavConfig $eavConfig,
        OfferResource $offerResource
    )
    {
        $this->registry = $registry;
        $this->reportRepository = $reportRepository;
        $this->reportManagement = $reportManagement;
        $this->importRunner = $importRunnerFactory->create();
        $this->importRunner->initialize('maas_offer_import_without_staging');
        $this->deleteRunner = $importRunnerFactory->create();
        $this->deleteRunner->initialize('maas_offer_delete');
        $this->eavConfig = $eavConfig;
        $this->offerResource = $offerResource;

        parent::__construct(
            $moduleList,
            $filterBuilder,
            $searchCriteriaBuilder,
            $offerRepository,
            $dateTime,
            $csvLoggerManagement,
            $cache,
            $coreConfig,
            $serializer,
            $reportCollectionFactory
        );
    }

    /**
     * @param $reportId
     * @return mixed|void
     */
    public function getCsvLogger($reportId)
    {
    }

    /**
     * @param string $message
     * @throws AlreadyExistsException
     */
    public function process($message)
    {
        $this->registry->setCurrentlyImporting(true);
        $this->reportId = $message->getReportId();
        if ($this->reportId == 0) {
            $this->report = $this->getStartedImportReportObject(OfferModel::MAAS_LOG_MODULE, OfferModel::MAAS_LOG_ACTION);
        } else {
            $this->report = $this->reportRepository->get($this->reportId);
        }

        /** @var OfferImportMessageInterface $message */
        foreach ($message->getEntities() as $offerData) {
            $this->offerResource->addEntityIdToPreload($offerData->getOfferId());
        }

        $this->offerResource->preloadOffers();

        foreach ($message->getEntities() as $offerData) {
            // import offer flagged as active
            $this->processEntity($offerData, $dataToImport, $dataToDelete);
        }

        if (!empty($dataToDelete)) {
            $this->processDataToDelete($dataToDelete);
        }

        if (!empty($dataToImport)) {
            $this->processDataToImport($dataToImport);
        }

        if ($this->report->isJobOver()) {
            $report = $this->report;
            $this->reportManagement->close($report);
            $this->cache->remove(OfferModel::CACHE_KEY_MAAS_REPORT_ID);
            $this->clearCacheOnJobOver();
        }
    }

    /**
     * @param $offerData
     * @param $dataToImport
     * @param $dataToDelete
     * @return array|void
     */
    public function processEntity($offerData, &$dataToImport, &$dataToDelete)
    {
        try {
            $offerMaasId = $offerData->getOfferId();
            $offer = $this->offerResource->offerExists($offerMaasId);
            if (strtolower($offerData->getStatus()) != self::STATUS_ACTIVE) {
                if ($offer) {
                    $this->deleteOffer($offer, $dataToDelete);
                } else {
                    $this->report->log(
                        sprintf('Offer %s inactive', $offerMaasId),
                        false,
                        LogLevel::INFO
                    );
                    $this->report->setDeltaSuccessItemsCount(1);
                    $this->reportRepository->save($this->report);
                }
                return [];
            } elseif (empty($offerData->getBestOfferRank())) {
                if ($offer) {
                    $this->deleteOffer($offer, $dataToDelete);
                } else {
                    $this->report->log(
                        sprintf('Offer %s null best_offer rank', $offerMaasId),
                        false,
                        LogLevel::WARNING
                    );
                    $this->report->setDeltaWarningItemsCount(1);
                    $this->reportRepository->save($this->report);
                }
                return [];
            } else {
                if ($offer && !$this->isNewer($offerData->getUpdatedAt(), $offer['sync_date'])) {
                    $this->report->log(
                        sprintf('Offer %s up to date', $offerMaasId),
                        false,
                        LogLevel::INFO
                    );
                    $this->report->setDeltaSuccessItemsCount(1);
                    $this->reportRepository->save($this->report);
                    return [];
                }
            }

            // Get seller data
            $dataSeller = $offerData->getSeller();
            $dataCondition = $offerData->getCondition();
            $priceData = $offerData->getPrice()->setMaasEntityId($offerMaasId);
            $inventoryData = $offerData->getInventory()->setMaasEntityId($offerMaasId);
            $dataToImport [] = [
                'maas_entity_id' => $offerMaasId,
                'product_id' => $offerData->getProductId(),
                'condition' => $dataCondition->getCondition(),
                'sub_condition' => $dataCondition->getSubCondition(),
                'comment' => $dataCondition->getComment(),
                'best_offer' => $offerData->getBestOfferRank(),
                'sync_date' => $offerData->getUpdatedAt(),
                'warranty_duration' => $offerData->getWarrantyDuration(),
                'seller_id' => $dataSeller->getId(),
                'price' => $this->processOfferPrice($priceData),
                'inventory' => $this->processOfferInventory($inventoryData)
            ];

            $this->report->log(sprintf('Offer %s %s', $offerMaasId, $offer ? 'updated' : 'created'),
                false,
                LogLevel::INFO
            );

            $this->report->setDeltaSuccessItemsCount(1);
            $this->registry->setCurrentlyImporting(false);

        } catch (Exception $e) {
            $this->report->log(
                sprintf('error when processing offer: %s. %s %s',
                    $offerMaasId,
                    $e->getMessage(),
                    $e->getTraceAsString()),
                false,
                LogLevel::ERROR
            );
            $this->report->setDeltaErrorItemsCount(1);
            $this->report->setMessage($e->getMessage());
        }
        $this->reportRepository->save($this->report);
    }

    /**
     * @param array $offerMaasEntityId
     * @param $dataToDelete
     */
    private function deleteOffer($offer, &$dataToDelete)
    {
        $rowToDelete['maas_entity_id'] = $offer['maas_entity_id'];
        $message = sprintf('Offer %s deleted. ', $offer['maas_entity_id']);
        if (!isset($offer['product_id'])) {
            $message .= printf("Offer %s has no product", $offer['maas_entity_id']);
        } else {
            $rowToDelete['product_id'] = $offer['product_id'];
            $message .= sprintf('Product %s out of stock', $offer['product_id']);
        }
        $dataToDelete[] = $rowToDelete;
        $this->report->log($message , false, LogLevel::INFO);
        $this->report->setDeltaSuccessItemsCount(1);
        $this->reportRepository->save($this->report);
    }

    /**
     * @param PriceInterface $priceData
     * @return array
     */
    private function processOfferPrice(PriceInterface $priceData)
    {
        return [
            'maas_entity_id' => $priceData->getOfferId(),
            'price' => $priceData->getPrice(),
            'currency' => $priceData->getCurrency(),
            'original_price' => $priceData->getOriginalPrice(),
            'start_date' => $priceData->getStartDate(),
            'end_date' => $priceData->getEndDate(),
            'discount_id' => $priceData->getDiscountId(),
            'sync_date' => $priceData->getUpdatedAt(),
            'taxes' => $this->processOfferTaxes($priceData->getTaxes())
        ];
    }

    /**
     * @param TaxInterface[] $taxesData
     * @return string
     */
    private function processOfferTaxes($taxesData)
    {
        $taxes = [];
        foreach ($taxesData as $tax) {
            $taxes[] = [
                'code' => $tax->getCode(),
                'type' => $tax->getType(),
                'value' => $tax->getValue()
            ];
        }
        return json_encode($taxes);
    }

    /**
     * @param InventoryInterface $inventoryData
     * @return array
     */
    private function processOfferInventory(InventoryInterface $inventoryData)
    {
        return [
            'maas_entity_id' => $inventoryData->getOfferId(),
            'stock' => $inventoryData->getStock(),
            'supply_mode' => $inventoryData->getSupplyMode(),
            'sync_date' => $inventoryData->getUpdatedAt(),
            'deliveries' => $this->processOfferDeliveries($inventoryData->getDeliveries())
        ];
    }

    /**
     * @param DeliveryInterface[] $deliveriesData
     * @return string
     */
    private function processOfferDeliveries($deliveriesData)
    {
        $offerDeliveries = [];
        foreach ($deliveriesData as $deliveryData) {
            $offerDeliveries[] = [
                'mode' => $deliveryData->getMode(),
                'min_delay' => $deliveryData->getMinDelay(),
                'max_delay' => $deliveryData->getMaxDelay(),
                'shipping_cost' => $deliveryData->getShippingCost(),
                'additional_shipping_cost' => $deliveryData->getAdditionalShippingCost()
            ];
        }

        return json_encode($offerDeliveries);
    }

    /**
     * @param $dataToDelete
     */
    protected function processDataToDelete($dataToDelete)
    {
        $this->deleteRunner->setReport($this->report, false);
        $this->deleteRunner->run($dataToDelete);
    }

    /**
     * @param $dataToImport
     */
    protected function processDataToImport($dataToImport)
    {
        $fullDataToImport = [
            'offers' => &$dataToImport
        ];

        $this->importRunner->setReport($this->report, false);
        $this->importRunner->run($fullDataToImport);
    }
}
