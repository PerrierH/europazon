<?php

namespace Maas\DatabaseImport\Model\Import\Step;

use Maas\DatabaseImport\Model\AbstractStep;
use Maas\DatabaseImport\Model\StepInterface;

/**
 * Class SubRow
 *
 * If a column contains arrays, treat them as a new set of rows.
 * If necessary, copy elements from parent row to the new one.
 *
 * Example: if an attribute has options:
 *
 * The original row:
 *
 * attribute_id: 123
 * attribute_code: color
 * options: array with elements:
 *   - value: red, order: 0
 *   - value: green, order: 1
 *   - value: blue, order: 2
 *   - value: yellow, order: 3
 *
 * By creating subrows with attribute_id copied over, the children will receive the following rows:
 *
 * - attribute_id: 123, value: red, order: 0
 * - attribute_id: 123, value: green, order: 1
 * - attribute_id: 123, value: blue, order: 2
 * - attribute_id: 123, value: yellow, order: 3
 *
 * @package Maas\DatabaseImport\Model\Import\Step
 */
class SubRow extends CompositeStep
{
    const CONFIG_ARRAY_COLUMN = 'array_column';
    const CONFIG_COPIED_COLUMNS = 'copied_columns';

    /** @var string */
    protected $arrayColumn = null;

    /** @var string[] */
    protected $copiedColumns = null;

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this|Subrow
     */
    public function execute(&$rows, &$context)
    {
        $subRows = [];
        foreach ($rows as $row) {
            $this->extractSubRows($subRows, $row);
        }

        foreach ($this->children as $child) {
            /** @var $step AbstractStep */
            $child->execute($subRows, $context);
        }
        return $this;
    }

    /**
     * @return $this
     */
    protected function parseConfiguration()
    {
        if (is_null($this->copiedColumns)) {
            $this->arrayColumn = $this->config[self::CONFIG_ARRAY_COLUMN];
            $this->copiedColumns = explode(',', $this->config[self::CONFIG_COPIED_COLUMNS]);
        }
        return $this;
    }

    /**
     * @param array $subRows
     * @param array $row
     *
     * @return $this
     */
    protected function extractSubRows(&$subRows, $row)
    {
        $this->parseConfiguration();
        if (isset($row[$this->arrayColumn]) && is_array($row[$this->arrayColumn])) {
            foreach ($row[$this->arrayColumn] as $subRow) {
                foreach ($this->copiedColumns as $col) {
                    $subRow[$col] = $row[$col];
                }
                $subRows[] = $subRow;
            }
        }
        return $this;
    }
}