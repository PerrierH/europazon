<?php

namespace Maas\DatabaseImport\Model\Import\Step;

use Maas\DatabaseImport\Model\AbstractStep;

/**
 * Class CompositeStep
 *
 * Parent class for multiple steps.
 * Calls its children.
 *
 * @package Maas\DatabaseImport\Model\Import\Step
 */
class CompositeStep extends AbstractStep
{
    /**
     * @return $this
     */
    public function reinit()
    {
        foreach ($this->children as $child) {
            /** @var $child AbstractStep */
            $child->reinit();
        }
        return $this;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        foreach ($this->children as $child) {
            /** @var $child AbstractStep */
            $child->execute($rows, $context);
        }
        return $this;
    }
}
