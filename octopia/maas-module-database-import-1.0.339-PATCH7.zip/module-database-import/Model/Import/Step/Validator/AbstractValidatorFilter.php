<?php

namespace Maas\DatabaseImport\Model\Import\Step\Validator;

use Maas\DatabaseImport\Model\AbstractStep;

/**
 * Class AbstractValidatorFilter
 *
 * Abstract class for validator that filters out invalidated columns
 *
 * @package Maas\DatabaseImport\Model\Import\Step\Validator
 */
abstract class AbstractValidatorFilter extends AbstractStep
{

    /**
     * @inheritDoc
     */
    public function execute(&$rows, &$context)
    {
        $rows = array_filter($rows, [$this, 'validate'], ARRAY_FILTER_USE_BOTH);
        return $this;
    }

    /**
     * @param array $row
     * @param int $index
     *
     * @return bool Wheether the row is valid
     */
    abstract public function validate($row, $index);
}