<?php

namespace Maas\DatabaseImport\Model\Import\Step;

use Maas\DatabaseImport\Model\AbstractStep;
use Maas\DatabaseImport\Model\StepInterface;

/**
 * Class Batch
 *
 * Splits rows into batches and forwards each batch to children
 *
 * @package Maas\DatabaseImport\Model\Import\Step
 */
class Batch extends CompositeStep
{
    const CHUNK_SIZE = 'chunk_size';
    const KEEP_KEYS = 'keep_keys';

    /**
     * @var null|int
     */
    protected $chunkSize = null;

    /**
     * @var null|bool
     */
    protected $keepKeys = null;

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $batches = [];
        $this->extractBatches($rows, $batches);
        foreach ($batches as &$batch) {
            foreach ($this->children as $child) {
                /** @var $step AbstractStep */
                $child->execute($batch, $context);
            }
        }
        return $this;
    }

    /**
     * Not using array chunk to keep using references
     *
     * @param array $rows
     * @param array[] $batches
     *
     * @return $this
     */
    protected function extractBatches(&$rows, &$batches)
    {
        $this->parseConfiguration();

        // not using array_chunk to keep references
        $batchNumber = 0;
        $batchCounter = 0;
        $batches[$batchNumber] = [];
        foreach ($rows as $key => &$row) {
            if ($this->keepKeys) {
                $batches[$batchNumber][$key] = $row;
            } else {
                $batches[$batchNumber][] = $row;
            }
            $batchCounter++;
            if ($batchCounter >= $this->chunkSize) {
                $batchCounter = 0;
                $batchNumber++;
                $batches[$batchNumber] = [];
            }
        }
        if (!$batches[$batchNumber]) {
            unset($batches[$batchNumber]);
        }
        return $this;
    }

    /**
     * @return $this
     */
    protected function parseConfiguration()
    {
        if (is_null($this->chunkSize)) {
            $this->chunkSize = $this->config[self::CHUNK_SIZE] ?? 100;
            $this->keepKeys = isset($this->config[self::KEEP_KEYS]) ? $this->getValueAsBool($this->config[self::KEEP_KEYS]) : false;
        }
        return $this;
    }
}