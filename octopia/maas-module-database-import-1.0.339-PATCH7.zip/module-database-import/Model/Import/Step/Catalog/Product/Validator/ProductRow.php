<?php

namespace Maas\DatabaseImport\Model\Import\Step\Catalog\Product\Validator;

use Maas\DatabaseImport\Model\Import\Step\Validator\AbstractValidatorFilter;
use Monolog\Logger;
use Exception;

/**
 * Class ProductRow
 *
 * Validates a product row, filters out invalid rows
 *
 * @package Maas\DatabaseImport\Model\Import\Step\Catalog\Product\Validator
 */
class ProductRow extends AbstractValidatorFilter
{

    /**
     * @inheritDoc
     */
    public function validate($row, $index)
    {
        $isError = false;
        if (!array_key_exists('sku', $row)) {
            $isError = true;
            $this->logger->warning(sprintf("Sku missing"));
        }
        elseif (!array_key_exists('name', $row)) {
            $isError = true;
            $this->logger->warning(sprintf("P:%s. Name is empty", $row['sku']));
        } elseif (!array_key_exists('category', $row) || !array_key_exists('category_path', $row)) {
            $isError = true;
            $this->logger->warning(sprintf("P:%s. Category missing", $row['sku']));
        } elseif (!array_key_exists('attribute_set_id', $row)) {
            $isError = true;
            $this->logger->warning(sprintf("P:%s. Attribute set missing", $row['sku']));
        }

        if ($isError) {
            $this->logger->addWarningCount(1);
            return false;
        }

        $this->logger->addSuccessCount(1);
        return true;
    }
}
