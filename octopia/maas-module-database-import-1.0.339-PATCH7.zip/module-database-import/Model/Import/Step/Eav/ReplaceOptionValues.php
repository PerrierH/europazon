<?php

namespace Maas\DatabaseImport\Model\Import\Step\Eav;

use Maas\DatabaseImport\Model\AbstractStep;
use Maas\DatabaseImport\Model\Import\Registry\Eav;
use Maas\DatabaseImport\Model\Service\OptionKey;

/**
 * Class ReplaceOptionValues
 *
 * Replaces values of attributes with a source model with technical ones
 *
 * @package Maas\DatabaseImport\Model\Import\Step\Eav
 */
class ReplaceOptionValues extends AbstractStep
{
    /** @var Eav */
    protected $eavRegistry;

    /** @var OptionKey */
    protected $optionKeyService;

    /**
     * ReplaceOptionValues constructor
     *
     * @param Eav $eavRegistry
     * @param OptionKey $optionKeyService
     * @param array $config
     * @param array $children
     */
    public function __construct(
        Eav       $eavRegistry,
        OptionKey $optionKeyService,
                  $config = [],
                  $children = []
    )
    {
        parent::__construct($config, $children);
        $this->optionKeyService = $optionKeyService;
        $this->eavRegistry = $eavRegistry;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return $this
     */
    public function execute(&$rows, &$context)
    {
        $options = $this->eavRegistry->getOptions($context['entity_type_id']);
        foreach ($rows as &$row) {
            foreach ($row as $key => $value) {
                if (isset($options[$key])) {
                    $valueToTest = $this->optionKeyService->filter($value);
                    if (isset($options[$key][$valueToTest])) {
                        $row[$key] = $options[$key][$valueToTest];
                    } else {
                        if (strpos($value, ',') !== false) {
                            $valueParts = explode(',', $value);
                            $replacedParts = [];
                            foreach ($valueParts as $valuePart) {
                                $valueToTest = $this->optionKeyService->filter($valuePart);
                                $replacedParts[] = $options[$key][$valueToTest] ?? $valuePart;
                            }
                            $row[$key] = implode(',', $replacedParts);
                        }
                    }
                }
            }
        }
        return $this;
    }
}