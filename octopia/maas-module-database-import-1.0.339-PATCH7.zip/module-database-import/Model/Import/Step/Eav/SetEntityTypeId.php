<?php

namespace Maas\DatabaseImport\Model\Import\Step\Eav;

use Maas\Catalog\Model\Product;
use Maas\DatabaseImport\Model\AbstractStep;
use Maas\DatabaseImport\Model\StepInterface;
use Magento\Eav\Model\Entity\Type;
use Magento\Eav\Model\Entity\TypeFactory;

/**
 * Class SetEntityTypeId
 *
 * Sets entity type id in context, and eventually in rows
 *
 * @package Maas\DatabaseImport\Model\Import\Step\Eav
 */
class SetEntityTypeId extends AbstractStep
{
    const CONFIG_ENTITY_TYPE_CODE = 'entity_type';
    const CONFIG_ADD_TO_ROW = 'add_to_row';

    /** @var array */
    static $entityTypeIds = [];

    /**
     * @param TypeFactory $entityTypeFactory
     * @param array $config
     * @param array $children
     */
    public function __construct(
        TypeFactory $entityTypeFactory,
        array $config = [],
        array $children = []
    ) {
        parent::__construct($config, $children);
        $this->entityTypeFactory = $entityTypeFactory;
    }

    /**
     * @param array $rows
     * @param array $context
     *
     * @return SetEntityTypeId
     */
    public function execute(&$rows, &$context)
    {
        $entityTypeId = $this->getEntityTypeId();
        if ($this->config[self::CONFIG_ADD_TO_ROW]) {

            foreach ($rows as &$row) {
                $row['entity_type_id'] = $entityTypeId;
            }
        }
        $context['entity_type_id'] = $entityTypeId;
        return $this;
    }

    /**
     * @return string[]
     */
    protected function getEntityTypeId()
    {
        $code = $this->config[self::CONFIG_ENTITY_TYPE_CODE];
        if (!isset(self::$entityTypeIds[$code])) {
            /** @var Type $entityType */
            $entityType = $this->entityTypeFactory->create();
            $entityType->loadByCode($code);
            self::$entityTypeIds[$code] = $entityType->getId();
        }
        return self::$entityTypeIds[$code];
    }
}
