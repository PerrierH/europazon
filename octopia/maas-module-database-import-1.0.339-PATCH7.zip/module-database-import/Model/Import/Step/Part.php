<?php

namespace Maas\DatabaseImport\Model\Import\Step;

use Maas\DatabaseImport\Model\AbstractStep;

/**
 * Class Part
 *
 * Extracts a named subarray and forwards it to children
 *
 * @package Maas\DatabaseImport\Model\Import\Step
 */
class Part extends CompositeStep
{
    const CONFIG_KEY = 'key';

    public function execute(&$rows, &$context)
    {
        foreach ($this->children as $child) {
            /** @var $step AbstractStep */
            $child->execute($rows[$this->config[self::CONFIG_KEY]], $context);
        }
    }
}