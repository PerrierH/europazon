<?php

namespace Maas\DatabaseImport\Model\Import\Registry;

use Maas\DatabaseImport\Model\ResourceModel\Eav\LoadAttributes;
use Maas\DatabaseImport\Model\Service\SourceModelOptions;

/**
 * Class Eav
 *
 * Centralizes selects from DB to get existing attribute sets, attributes and options.
 * Caches results.
 *
 * @package Maas\DatabaseImport\Model\Import\Registry
 */
class Eav
{
    /**
     * @var array cached entity types by ID and code, fetched from eav_entity_type
     *
     * Structure: key ("id-" and "code-") -> entity type properties
     */
    static $entityTypes = [];

    /**
     * @var array cached properties of all entity's attributes, fetched from eav_attribute and eventual additional table
     *
     * Structure: entity type ID -> attribute code -> attribute properties
     */
    static $attributesCache = [];

    /**
     * @var array cached properties of all allowed options for each entity type's attribute
     *
     * Structure: entity type ID -> attribute code -> option label, transliterated and in lowercase -> value
     */
    static $optionsCache = [];

    /**
     * @var array cached properties of all attributes in an attribute set
     *
     * Structure: entity type ID -> attribute set name -> attribute code -> (incremental key, can be ignored)
     */
    static $attributesInSetCache = [];
    static $variationsAttributesCache = [];
    protected $loadAttributesResource;
    protected $sourceModelOptions;

    /**
     * Eav Constructor
     *
     * @param LoadAttributes $loadAttributesResource
     * @param SourceModelOptions $sourceModelOptions
     */
    public function __construct(
        LoadAttributes $loadAttributesResource,
        SourceModelOptions $sourceModelOptions
    )
    {
        $this->loadAttributesResource = $loadAttributesResource;
        $this->sourceModelOptions = $sourceModelOptions;
    }

    /**
     * Reinitialize cached values
     */
    public function reinit()
    {
        self::$entityTypes = [];
        self::$attributesCache = [];
        self::$optionsCache = [];
        self::$attributesInSetCache = [];
        self::$variationsAttributesCache = [];
    }

    /**
     * Get properties of all attributes for an entity type
     *
     * @param string|int $entityType
     *
     * @return array|false|mixed
     */
    public function getAttributes($entityType)
    {
        $entityType = $this->getEntityType($entityType);
        if (!$entityType) {
            return [];
        }
        $entityTypeId = $entityType['entity_type_id'];
        if (!array_key_exists($entityTypeId, self::$attributesCache)) {
            self::$attributesCache[$entityTypeId] = [];
            $rows = $this->loadAttributesResource->loadAttributes($entityTypeId);
            foreach ($rows as &$row) {
                self::$attributesCache[$entityTypeId][$row['attribute_code']] = $row;
            }
        }
        return self::$attributesCache[$entityTypeId];
    }

    /**
     * Get properties of an entity type by ID or code
     *
     * @param int|string $entityType
     *
     * @return string[]|null
     */
    public function getEntityType($entityType)
    {
        $key = is_numeric($entityType) ? 'id-' . $entityType : 'code-' . $entityType;
        if (isset(self::$entityTypes[$key])) {
            return self::$entityTypes[$key];
        }
        if (is_numeric($entityType)) {
            $entityTypeData = $this->loadAttributesResource->loadEntityTypeById($entityType);
        } else {
            $entityTypeData = $this->loadAttributesResource->loadEntityTypeByCode($entityType);
        }
        if ($entityTypeData) {
            self::$entityTypes['id-' . $entityTypeData['entity_type_id']] = $entityTypeData;
            self::$entityTypes['code-' . $entityTypeData['entity_type_code']] = $entityTypeData;
            return $entityTypeData;
        } else {
            if ($key) {
                self::$entityTypes[$key] = null;
            }
        }
        return null;
    }

    /**
     * Get options of all attributes for an entity type
     *
     * @param int|string $entityType
     *
     * @return array
     */
    public function getOptions($entityType)
    {
        $entityType = $this->getEntityType($entityType);
        if (!$entityType) {
            return [];
        }
        $entityTypeId = $entityType['entity_type_id'];
        $entityTypeCode = $entityType['entity_type_code'];
        if (!array_key_exists($entityTypeId, self::$optionsCache)) {
            self::$optionsCache[$entityTypeId] = $this->sourceModelOptions->getAllAttributeOptions($entityTypeCode);
        }
        return self::$optionsCache[$entityTypeId];
    }

    /**
     * Tells whether an attribute is in an atttribute set
     *
     * @param int|string $entityType
     * @param string $attributeCode
     * @param string $attributeSetName
     *
     * @return bool
     */
    public function isAttributeInSet($entityType, $attributeCode, $attributeSetName)
    {
        $entityType = $this->getEntityType($entityType);
        if (!$entityType) {
            return false;
        }
        $entityTypeId = $entityType['entity_type_id'];

        if (!isset(self::$attributesInSetCache[$entityTypeId][$attributeSetName])) {
            self::$attributesInSetCache[$entityTypeId][$attributeSetName] = array_flip($this->loadAttributesResource->getAttributeSetAttributes($entityTypeId,
                $attributeSetName));
        }
        return isset(self::$attributesInSetCache[$entityTypeId][$attributeSetName][$attributeCode]);
    }

    /**
     * @param [] $variations
     */
    public function setVariationsAttributes($variations)
    {
        self::$variationsAttributesCache = $variations;
    }


    /**
     * @return array
     */
    public function getVariationsAttributes()
    {
        return self::$variationsAttributesCache;
    }
}