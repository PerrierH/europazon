<?php

namespace Maas\DatabaseImport\Model;

/**
 * Class Placeholder
 *
 * Used to replace @-delimited placeholders in queries
 *
 * @package Maas\DatabaseImport\Model
 */
class Placeholder
{
    /**
     * @param string $query
     * @param string[] $placeholders
     *
     * @return string
     */
    public function replace($query, $placeholders)
    {
        foreach ($placeholders as $key => $placeholder) {
            $query = str_replace('@' . $key . '@', $placeholder ?? '', $query);
        }
        return $query;
    }
}