<?php

namespace Maas\DatabaseImport\Model\Xml;

use Magento\Backend\Model\Menu\Config\Menu\Dom;
use Magento\Framework\Config\FileResolverInterface;
use Magento\Framework\Config\Reader\Filesystem;
use Magento\Framework\Config\ValidationStateInterface;

/**
 * Class Reader
 *
 * @package Maas\DatabaseImport\Model\Xml
 * @codeCoverageIgnore Delegates all to parent
 */
class Reader extends Filesystem
{
    /**
     * @param FileResolverInterface $fileResolver
     * @param Converter $converter
     * @param SchemaLocator $schemaLocator
     * @param ValidationStateInterface $validationState
     * @param string $fileName
     * @param array $idAttributes
     * @param string $domDocumentClass
     * @param string $defaultScope
     */
    public function __construct(
        FileResolverInterface    $fileResolver,
        Converter                $converter,
        SchemaLocator            $schemaLocator,
        ValidationStateInterface $validationState,
                                 $fileName = 'maas_db_imports.xml',
                                 $idAttributes = [],
                                 $domDocumentClass = Dom::class,
                                 $defaultScope = 'global'
    )
    {
        parent::__construct(
            $fileResolver,
            $converter,
            $schemaLocator,
            $validationState,
            $fileName,
            $idAttributes,
            $domDocumentClass,
            $defaultScope
        );
    }
}
