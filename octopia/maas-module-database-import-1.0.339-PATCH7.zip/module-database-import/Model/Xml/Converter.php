<?php

namespace Maas\DatabaseImport\Model\Xml;

use DOMDocument;
use DOMNode;
use DOMXpath;
use Maas\DatabaseImport\Model\Import\Step\CompositeStep;
use Magento\Framework\Config\ConverterInterface;
use Maas\Core\Api\Data\EditionInterface;

/**
 * Class Converter
 *
 * @package Maas\Sales\Model\OrderRestrictions
 * @codeCoverageIgnore relies on extenal XML files
 */
class Converter implements ConverterInterface
{
    /**
     * @var array
     */
    protected $aliases = [];

    /**
     * @var EditionInterface
     */
    protected $edition;

    /**
     * @param EditionInterface $edition
     */
    public function __construct(
        EditionInterface $edition
    )
    {
        $this->edition = $edition;
    }

    /**
     * Converts xml to appropriate array
     *
     * @param DOMDocument $dom
     *
     * @return array
     */
    public function convert($dom)
    {
        $imports = [];
        $xpath = new DOMXpath($dom);
        $elements = $xpath->query("/maas_db_contents/alias[@name][@type]");
        for ($i = 0; $i < $elements->length; $i++) {
            $node = $elements->item($i);
            $this->aliases[$node->getAttribute('name')] = $node->getAttribute('type');
        }
        $elements = $xpath->query("/maas_db_contents/section/import[@id]");
        for ($i = 0; $i < $elements->length; $i++) {
            $node = $elements->item($i);
            $imports[$node->getAttribute('id')] = $this->prepareStepConfig($node);
        }
        return $imports;
    }

    /**
     * @param DOMNode $node
     *
     * @return array
     */
    protected function prepareStepConfig(DOMNode $node)
    {
        $children = [];
        $config = [];
        $misc = [];
        $type = $this->getStepType($node);
        for ($i = 0; $i < $node->childNodes->length; $i++) {
            $child = $node->childNodes->item($i);
            switch ($child->nodeName) {
                case 'step':
                    $name = $this->getStepName($child);
                    if ($name) {
                        $children[$name] = $this->prepareStepConfig($child);
                    }
                    break;
                case 'config':
                    $name = $child->getAttribute('name');
                    if ($name) {
                        if (!$this->edition->isEnterprise()) {
                            $child->nodeValue = str_replace('row_id', 'entity_id', $child->nodeValue);
                        }
                        $config[$name] = $child->nodeValue;
                    }
                    break;
            }
        }

        return [
            'type' => $type,
            'children' => $children,
            'config' => $config
        ];
    }

    /**
     * @param DOMNode $node
     *
     * @return string
     */
    protected function getStepType(DOMNode $node)
    {
        $type = $node->getAttribute('type');
        if (!$type) {
            $type = CompositeStep::class;
        }
        if (isset($this->aliases[$type])) {
            $type = $this->aliases[$type];
        }
        return $type;
    }

    /**
     * @param DOMNode $node
     *
     * @return string
     */
    protected function getStepName(DOMNode $node)
    {
        if ($node->nodeName != 'step') {
            $name = null;
        } else {
            $name = $node->getAttribute('name');
        }
        return $name;
    }
}
